## matrix
- candidate vs 955: >5% R1=2 R2=3 both=2; median ratio R1=0.9981 R2=0.9984; faster>5% R1=138 R2=136
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '128'} R1=1.063 R2=1.054
    * BOTH {'type': 'INT8', 'metric': 'L2', 'rows': '2', 'columns': '1', 'dim': '128'} R1=1.085 R2=1.072
- candidate vs 7abc: >5% R1=17 R2=6 both=2; median ratio R1=0.9994 R2=0.9996; faster>5% R1=60 R2=65
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '16', 'columns': '4', 'dim': '128'} R1=1.057 R2=1.056
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '128'} R1=1.058 R2=1.082
- candidate vs Linux final: >5% R1=9 R2=2 both=0; median ratio R1=1.0002 R2=0.9996; faster>5% R1=1 R2=6
- candidate vs before: >5% R1=16 R2=15 both=15; median ratio R1=0.5049 R2=0.5040; faster>5% R1=353 R2=353
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '32', 'columns': '4', 'dim': '512'} R1=1.082 R2=1.084
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '1', 'dim': '128'} R1=1.060 R2=1.067
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '1', 'dim': '512'} R1=1.062 R2=1.058
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '2', 'dim': '128'} R1=1.366 R2=1.367
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '2', 'dim': '512'} R1=1.378 R2=1.383
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '4', 'dim': '128'} R1=1.366 R2=1.376
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '4', 'dim': '512'} R1=1.379 R2=1.377
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '1', 'dim': '128'} R1=2.096 R2=2.086
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '1', 'dim': '512'} R1=2.104 R2=2.101
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '16', 'dim': '128'} R1=1.058 R2=1.057
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '16', 'dim': '512'} R1=1.058 R2=1.058
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '2', 'dim': '128'} R1=1.068 R2=1.069
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '2', 'dim': '512'} R1=1.072 R2=1.072
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '8', 'dim': '128'} R1=1.060 R2=1.060
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '8', 'dim': '512'} R1=1.063 R2=1.065
- candidate vs parent: >5% R1=67 R2=68 both=66; median ratio R1=0.7551 R2=0.7582; faster>5% R1=327 R2=325
    * BOTH {'type': 'FP16', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '128'} R1=2.124 R2=2.110
    * BOTH {'type': 'FP16', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '512'} R1=3.237 R2=3.212
    * BOTH {'type': 'FP16', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '128'} R1=2.301 R2=2.337
    * BOTH {'type': 'FP16', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '512'} R1=3.242 R2=3.223
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '128'} R1=1.231 R2=1.223
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '16', 'columns': '1', 'dim': '128'} R1=1.620 R2=1.621
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '16', 'columns': '1', 'dim': '512'} R1=1.614 R2=1.613
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '4', 'columns': '1', 'dim': '128'} R1=1.280 R2=1.284
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '4', 'columns': '1', 'dim': '512'} R1=1.306 R2=1.301
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '8', 'columns': '1', 'dim': '128'} R1=1.486 R2=1.495
    * BOTH {'type': 'FP32', 'metric': 'IP', 'rows': '8', 'columns': '1', 'dim': '512'} R1=1.526 R2=1.527
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '128'} R1=1.232 R2=1.245
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '512'} R1=1.059 R2=1.062
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '16', 'columns': '1', 'dim': '128'} R1=1.445 R2=1.452
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '16', 'columns': '1', 'dim': '512'} R1=1.465 R2=1.475
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '16', 'columns': '8', 'dim': '128'} R1=1.171 R2=1.180
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '16', 'columns': '8', 'dim': '512'} R1=1.171 R2=1.167
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '4', 'columns': '1', 'dim': '128'} R1=1.184 R2=1.181
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '4', 'columns': '1', 'dim': '512'} R1=1.196 R2=1.195
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '8', 'columns': '1', 'dim': '128'} R1=1.339 R2=1.337
    * BOTH {'type': 'FP32', 'metric': 'L2', 'rows': '8', 'columns': '1', 'dim': '512'} R1=1.328 R2=1.328
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '16', 'columns': '16', 'dim': '128'} R1=1.312 R2=1.312
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '16', 'columns': '16', 'dim': '512'} R1=1.298 R2=1.299
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '16', 'dim': '128'} R1=1.220 R2=1.218
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '16', 'dim': '512'} R1=1.235 R2=1.205
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '2', 'dim': '128'} R1=1.134 R2=1.135
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '2', 'dim': '512'} R1=1.127 R2=1.128
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '4', 'dim': '128'} R1=1.217 R2=1.218
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '4', 'dim': '512'} R1=1.210 R2=1.207
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '8', 'dim': '128'} R1=1.213 R2=1.243
    * BOTH {'type': 'FP64', 'metric': 'IP', 'rows': '32', 'columns': '8', 'dim': '512'} R1=1.204 R2=1.202
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '16', 'columns': '16', 'dim': '128'} R1=1.189 R2=1.188
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '16', 'columns': '16', 'dim': '512'} R1=1.218 R2=1.219
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '32', 'columns': '16', 'dim': '128'} R1=1.071 R2=1.067
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '32', 'columns': '16', 'dim': '512'} R1=1.061 R2=1.062
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '32', 'columns': '4', 'dim': '128'} R1=1.055 R2=1.060
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '32', 'columns': '4', 'dim': '512'} R1=1.064 R2=1.069
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '32', 'columns': '8', 'dim': '128'} R1=1.054 R2=1.057
    * BOTH {'type': 'FP64', 'metric': 'L2', 'rows': '32', 'columns': '8', 'dim': '512'} R1=1.054 R2=1.053
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '2', 'columns': '1', 'dim': '128'} R1=1.306 R2=1.314
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '2', 'columns': '1', 'dim': '512'} R1=1.329 R2=1.328
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '32', 'columns': '16', 'dim': '128'} R1=1.110 R2=1.115
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '32', 'columns': '16', 'dim': '512'} R1=1.090 R2=1.089
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '32', 'columns': '8', 'dim': '128'} R1=1.070 R2=1.071
    * BOTH {'type': 'INT16', 'metric': 'IP', 'rows': '8', 'columns': '8', 'dim': '128'} R1=1.056 R2=1.051
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '512'} R1=1.115 R2=1.118
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '16', 'dim': '128'} R1=2.005 R2=2.005
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '16', 'dim': '512'} R1=2.009 R2=2.006
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '2', 'dim': '128'} R1=2.074 R2=2.076
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '2', 'dim': '512'} R1=2.082 R2=2.082
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '4', 'dim': '128'} R1=2.013 R2=2.003
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '4', 'dim': '512'} R1=2.008 R2=2.004
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '8', 'dim': '128'} R1=2.040 R2=2.037
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '16', 'columns': '8', 'dim': '512'} R1=2.048 R2=2.048
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '4', 'columns': '4', 'dim': '128'} R1=1.343 R2=1.344
    * BOTH {'type': 'INT16', 'metric': 'L2', 'rows': '4', 'columns': '4', 'dim': '512'} R1=1.343 R2=1.351
    * BOTH {'type': 'INT4', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '128'} R1=31.311 R2=31.302
    * BOTH {'type': 'INT4', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '512'} R1=46.587 R2=46.679
    * BOTH {'type': 'INT4', 'metric': 'IP', 'rows': '2', 'columns': '1', 'dim': '128'} R1=1.122 R2=1.113
    * BOTH {'type': 'INT4', 'metric': 'IP', 'rows': '2', 'columns': '1', 'dim': '512'} R1=1.067 R2=1.079
    * BOTH {'type': 'INT4', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '128'} R1=26.867 R2=26.908
    * BOTH {'type': 'INT4', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '512'} R1=36.675 R2=36.760
    * BOTH {'type': 'INT8', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '128'} R1=1.692 R2=1.688
    * BOTH {'type': 'INT8', 'metric': 'IP', 'rows': '1', 'columns': '1', 'dim': '512'} R1=1.487 R2=1.492
    * BOTH {'type': 'INT8', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '128'} R1=1.657 R2=1.656
    * BOTH {'type': 'INT8', 'metric': 'L2', 'rows': '1', 'columns': '1', 'dim': '512'} R1=1.125 R2=1.127
## adapter
- candidate vs 955: >5% R1=0 R2=0 both=0; median ratio R1=0.8469 R2=0.8859; faster>5% R1=16 R2=16
- candidate vs 7abc: >5% R1=0 R2=0 both=0; median ratio R1=0.9959 R2=0.9952; faster>5% R1=6 R2=6
- candidate vs Linux final: >5% R1=0 R2=0 both=0; median ratio R1=0.9998 R2=0.9977; faster>5% R1=0 R2=0
- candidate vs before: >5% R1=0 R2=0 both=0; median ratio R1=0.5323 R2=0.5265; faster>5% R1=20 R2=20
- candidate vs parent: >5% R1=0 R2=0 both=0; median ratio R1=0.3876 R2=0.3865; faster>5% R1=32 R2=32
## ivf
- candidate vs 955: >5% R1=0 R2=0 both=0; median ratio R1=0.9962 R2=1.0028; faster>5% R1=8 R2=8
- candidate vs 7abc: >5% R1=0 R2=0 both=0; median ratio R1=1.0011 R2=0.9918; faster>5% R1=4 R2=4
- candidate vs Linux final: >5% R1=0 R2=0 both=0; median ratio R1=1.0019 R2=0.9991; faster>5% R1=0 R2=1
- candidate vs before: >5% R1=0 R2=0 both=0; median ratio R1=0.4677 R2=0.4709; faster>5% R1=20 R2=20
- candidate vs parent: >5% R1=0 R2=1 both=0; median ratio R1=0.5672 R2=0.5654; faster>5% R1=20 R2=20
## root drift (parent/before spread across the four roots)
- matrix_round1: max=1.162 median=1.004 over1.05=43/1008
- matrix_round2: max=1.231 median=1.004 over1.05=59/1008
- adapter_round1: max=1.127 median=1.006 over1.05=4/64
- adapter_round2: max=1.052 median=1.007 over1.05=1/64
- ivf_round1: max=1.046 median=1.011 over1.05=0/48
- ivf_round2: max=1.102 median=1.008 over1.05=1/48
