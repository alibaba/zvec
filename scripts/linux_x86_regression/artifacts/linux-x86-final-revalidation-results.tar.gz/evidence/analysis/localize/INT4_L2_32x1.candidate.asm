endbr64
test   %rdx,%rdx
je     ADDR <void kernel<unsigned char, 32ul, 1ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18>
mov    $0x1,%r8d
jmp    ADDR <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]>
nopl   0x0(%rax)
lea    0x8(%rcx),%rdi
movq   $0x0,(%rcx)
mov    %rdx,%rax
and    $0xfffffffffffffff8,%rdi
movq   $0x0,0x78(%rcx)
sub    %rdi,%rcx
sub    $0xffffff80,%ecx
shr    $0x3,%ecx
rep stos %rax,%es:(%rdi)
ret
