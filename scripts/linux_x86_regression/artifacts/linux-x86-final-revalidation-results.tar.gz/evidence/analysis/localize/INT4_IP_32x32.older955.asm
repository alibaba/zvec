endbr64
push   %r15
mov    %rdx,%r15
push   %r14
push   %r13
push   %r12
push   %rbp
push   %rbx
test   %rdx,%rdx
je     ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2cb>
test   $0x7,%dl
je     ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x302>
mov    %rsi,%r8
mov    %r15,%rax
lea    0x1000(%rcx),%rsi
mov    %rdi,%r11
lea    DISP(%rip),%r14
mov    %r8,%r13
mov    %rcx,%r15
mov    %rax,%rdx
lea    0x8(%r15),%rdi
mov    %r15,%rcx
xor    %eax,%eax
movq   $0x0,(%r15)
and    $0xfffffffffffffff8,%rdi
movq   $0x0,0x78(%r15)
sub    %rdi,%rcx
sub    $0xffffff80,%ecx
shr    $0x3,%ecx
rep stos %rax,%es:(%rdi)
cmp    $0x7,%rdx
jbe    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c4>
mov    $0x8,%eax
lea    -0x8(%rax),%rdi
mov    %rax,-0x10(%rsp)
shr    $1,%rdi
shl    $0x5,%rdi
mov    0x0(%r13,%rdi,1),%ecx
add    %r11,%rdi
mov    %ecx,%r8d
mov    %ecx,%ebp
mov    %ecx,%ebx
mov    %ecx,%r10d
shr    $0x10,%r8d
mov    %ecx,%r9d
shr    $0x4,%ebp
shr    $0x1c,%r9d
and    $0xf,%r8d
shr    $0x8,%ebx
and    $0xf,%ebp
mov    %r8d,-0x24(%rsp)
mov    %ecx,%r8d
shr    $0xc,%r10d
and    $0xf,%ebx
shr    $0x14,%r8d
mov    %r9d,-0x18(%rsp)
and    $0xf,%r10d
xor    %r9d,%r9d
and    $0xf,%r8d
mov    %r8d,-0x20(%rsp)
mov    %ecx,%r8d
and    $0xf,%ecx
shr    $0x18,%r8d
mov    %ecx,-0x14(%rsp)
and    $0xf,%r8d
mov    %r8d,-0x1c(%rsp)
nopl   0x0(%rax,%rax,1)
mov    (%rdi,%r9,4),%ecx
mov    -0x14(%rsp),%eax
pxor   %xmm0,%xmm0
mov    %ecx,%r8d
and    $0xf0,%r8d
add    %ebp,%r8d
movsbl (%r14,%r8,1),%r12d
mov    %ecx,%r8d
and    $0xf,%r8d
shl    $0x4,%r8d
add    %eax,%r8d
mov    -0x24(%rsp),%eax
movsbl (%r14,%r8,1),%r8d
add    %r8d,%r12d
mov    %ecx,%r8d
shr    $0x4,%r8d
and    $0xf0,%r8d
add    %ebx,%r8d
movsbl (%r14,%r8,1),%r8d
add    %r8d,%r12d
mov    %ecx,%r8d
shr    $0x8,%r8d
and    $0xf0,%r8d
add    %r10d,%r8d
movsbl (%r14,%r8,1),%r8d
add    %r8d,%r12d
mov    %ecx,%r8d
shr    $0xc,%r8d
and    $0xf0,%r8d
add    %eax,%r8d
mov    -0x20(%rsp),%eax
movsbl (%r14,%r8,1),%r8d
add    %r8d,%r12d
mov    %ecx,%r8d
shr    $0x10,%r8d
and    $0xf0,%r8d
add    %eax,%r8d
mov    -0x1c(%rsp),%eax
movsbl (%r14,%r8,1),%r8d
add    %r8d,%r12d
mov    %ecx,%r8d
shr    $0x1c,%ecx
shr    $0x14,%r8d
shl    $0x4,%ecx
and    $0xf0,%r8d
add    %eax,%r8d
mov    -0x18(%rsp),%eax
movsbl (%r14,%r8,1),%r8d
add    %eax,%ecx
movsbl (%r14,%rcx,1),%ecx
add    %r12d,%r8d
add    %r8d,%ecx
cvtsi2ss %ecx,%xmm0
addss  (%r15,%r9,4),%xmm0
movss  %xmm0,(%r15,%r9,4)
add    $0x1,%r9
cmp    $0x20,%r9
jne    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf8>
mov    -0x10(%rsp),%rax
lea    0x8(%rax),%rcx
cmp    %rcx,%rdx
jb     ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1fd>
mov    %rcx,%rax
jmp    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7a>
cmp    %rdx,%rax
jae    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x29d>
mov    %rax,%rdi
mov    %rax,%rcx
shr    $0x3,%rdi
shr    $1,%rcx
and    $0x3,%ecx
shl    $0x7,%rdi
add    %rcx,%rdi
mov    %rax,%rcx
and    $0x1,%ecx
movzbl 0x0(%r13,%rdi,1),%r8d
shl    $0x2,%ecx
sar    %cl,%r8d
mov    %r8d,%r9d
and    $0xf,%r9d
and    $0x8,%r8d
je     ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b9>
sub    $0x10,%r9d
pxor   %xmm2,%xmm2
cvtsi2ss %r9d,%xmm2
lea    (%r11,%rdi,1),%r8
xor    %edi,%edi
nop
movzbl (%r8,%rdi,4),%r10d
sar    %cl,%r10d
mov    %r10d,%r9d
and    $0xf,%r9d
and    $0x8,%r10d
je     ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x269>
sub    $0x10,%r9d
pxor   %xmm1,%xmm1
movss  (%r15,%rdi,4),%xmm0
cvtsi2ss %r9d,%xmm1
mulss  %xmm2,%xmm1
subss  %xmm1,%xmm0
movss  %xmm0,(%r15,%rdi,4)
add    $0x1,%rdi
cmp    $0x20,%rdi
jne    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
add    $0x1,%rax
cmp    %rax,%rdx
jne    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x206>
sub    $0xffffffffffffff80,%r15
add    $0x4,%r13
cmp    %rsi,%r15
jne    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x43>
pop    %rbx
pop    %rbp
pop    %r12
pop    %r13
pop    %r14
pop    %r15
ret
pxor   %xmm2,%xmm2
cvtsi2ss %r9d,%xmm2
jmp    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x249>
xor    %eax,%eax
jmp    ADDR <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x206>
lea    0x8(%rcx),%rdi
movq   $0x0,(%rcx)
mov    %rdx,%rax
movq   $0x0,0xff8(%rcx)
and    $0xfffffffffffffff8,%rdi
sub    %rdi,%rcx
add    $0x1000,%ecx
shr    $0x3,%ecx
rep stos %rax,%es:(%rdi)
pop    %rbx
pop    %rbp
pop    %r12
pop    %r13
pop    %r14
pop    %r15
ret
pop    %rbx
pop    %rbp
pop    %r12
pop    %r13
pop    %r14
pop    %r15
jmp    ADDR <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>
