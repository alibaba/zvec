endbr64
push   %r15
push   %r14
lea    DISP(%rip),%r14
push   %r13
mov    %rdi,%r13
push   %r12
mov    %rsi,%r12
push   %rbp
mov    %rdx,%rbp
push   %rbx
mov    %rcx,%rbx
sub    $0x38,%rsp
mov    %fs:0x28,%rax
mov    %rax,0x28(%rsp)
xor    %eax,%eax
movzbl DISP(%rip),%eax
test   %al,%al
je     ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa8>
cmpq   $0x0,DISP(%rip)
mov    %r13,0x20(%rsp)
mov    %r12,0x18(%rsp)
mov    %rbp,0x10(%rsp)
mov    %rbx,0x8(%rsp)
je     ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x103>
lea    0x10(%rsp),%rcx
lea    0x18(%rsp),%rdx
mov    %r14,%rdi
lea    0x20(%rsp),%rsi
lea    0x8(%rsp),%r8
call   *DISP(%rip)
mov    0x28(%rsp),%rax
sub    %fs:0x28,%rax
jne    ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x130>
add    $0x38,%rsp
pop    %rbx
pop    %rbp
pop    %r12
pop    %r13
pop    %r14
pop    %r15
ret
nopw   0x0(%rax,%rax,1)
lea    DISP(%rip),%r15
lea    DISP(%rip),%r14
mov    %r15,%rdi
call   ADDR <__cxa_guard_acquire@plt>
test   %eax,%eax
je     ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x40>
xor    %r8d,%r8d
mov    $0x8,%ecx
mov    $0x2,%edx
mov    %r14,%rdi
mov    $0x2,%esi
call   ADDR <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
lea    DISP(%rip),%rdx
mov    %r14,%rsi
lea    -DISP(%rip),%rdi
call   ADDR <__cxa_atexit@plt>
mov    %r15,%rdi
call   ADDR <__cxa_guard_release@plt>
jmp    ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x40>
mov    0x28(%rsp),%rax
sub    %fs:0x28,%rax
jne    ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x130>
call   ADDR <std::__throw_bad_function_call()@plt>
mov    %r15,%rdi
call   ADDR <__cxa_guard_abort@plt>
mov    0x28(%rsp),%rax
sub    %fs:0x28,%rax
je     ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x13e>
call   ADDR <__stack_chk_fail@plt>
endbr64
mov    %rax,%rbx
jmp    ADDR <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x118>
mov    %rbx,%rdi
call   ADDR <_Unwind_Resume@plt>
