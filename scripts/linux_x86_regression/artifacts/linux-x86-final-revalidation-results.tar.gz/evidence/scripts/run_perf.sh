#!/bin/bash
set -euo pipefail
source /tmp/zvec_final_x86_env.sh
unset CFLAGS CXXFLAGS LDFLAGS
CPU=$(cat "$TASK/selected_cpu.txt")
snap() { { date +%FT%T; uptime; cat /proc/loadavg; grep MHz /proc/cpuinfo | sed -n "$((CPU+1))p;$((CPU))p"; } >> "$TASK/load_snapshots.txt"; }
for NAME in older955 reference7abc linux_final candidate; do
  ROOT="$TASK/$NAME"
  test -f "$ROOT/results/final_correctness_audit.json"
done
for NAME in older955 reference7abc linux_final candidate; do
  echo "=== round1 perf $NAME start $(date +%T)"; snap
  python3 "$BUNDLE/run.py" perf --root "$TASK/$NAME" --deps "$DEPS" --cpu "$CPU" > "$TASK/$NAME/perf_round1_driver.log" 2>&1
done
for NAME in older955 reference7abc linux_final candidate; do
  mv "$TASK/$NAME/results" "$TASK/$NAME/results_round1"
done
for NAME in candidate linux_final reference7abc older955; do
  echo "=== round2 perf $NAME start $(date +%T)"; snap
  python3 "$BUNDLE/run.py" perf --root "$TASK/$NAME" --deps "$DEPS" --cpu "$CPU" > "$TASK/$NAME/perf_round2_driver.log" 2>&1
done
snap
for NAME in older955 reference7abc linux_final candidate; do
  mv "$TASK/$NAME/results" "$TASK/$NAME/results_round2"
done
for ROUND in 1 2; do
  for BASE in older955 reference7abc linux_final; do
    python3 "$BUNDLE/compare_followup.py" \
      --baseline "$TASK/$BASE/results_round$ROUND" \
      --candidate "$TASK/candidate/results_round$ROUND" \
      --output "$TASK/comparisons/vs_${BASE}_round${ROUND}" > "$TASK/compare_${BASE}_round${ROUND}.log" 2>&1
  done
done
echo ALL_PERF_DONE $(date +%T)
