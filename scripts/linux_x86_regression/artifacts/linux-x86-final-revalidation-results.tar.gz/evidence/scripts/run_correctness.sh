#!/bin/bash
set -uo pipefail
source /tmp/zvec_final_x86_env.sh
unset CFLAGS CXXFLAGS LDFLAGS
for NAME in older955 reference7abc linux_final candidate; do
  ROOT="$TASK/$NAME"
  echo "=== correctness $NAME start $(date +%T)"
  if python3 "$BUNDLE/run.py" correctness --root "$ROOT" --deps "$DEPS" > "$ROOT/correctness_driver.log" 2>&1; then
    printf '0\n' > "$ROOT/correctness_driver.exit"
  else
    RC=$?
    printf '%s\n' "$RC" > "$ROOT/correctness_driver.exit"
    printf 'Review correctness failures under %s/results before proceeding\n' "$ROOT"
  fi
  echo "=== correctness $NAME exit $(cat $ROOT/correctness_driver.exit) $(date +%T)"
done
echo ALL_CORRECTNESS_DONE
