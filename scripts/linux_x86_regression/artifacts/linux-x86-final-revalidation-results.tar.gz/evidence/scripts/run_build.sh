#!/bin/bash
set -uo pipefail
source /tmp/zvec_final_x86_env.sh
unset CFLAGS CXXFLAGS LDFLAGS
JOBS=8
for NAME in older955 reference7abc linux_final candidate; do
  echo "=== build $NAME start $(date +%T)"
  python3 "$BUNDLE/run.py" build --root "$TASK/$NAME" --deps "$DEPS" --jobs "$JOBS" > "$TASK/$NAME/build_driver.log" 2>&1
  echo "=== build $NAME exit $? $(date +%T)"
done
echo ALL_BUILDS_DONE
