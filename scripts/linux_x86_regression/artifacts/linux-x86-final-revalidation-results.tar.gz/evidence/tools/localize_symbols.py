#!/usr/bin/env python3
"""Normalized per-symbol disassembly comparison across the four fixed matrix_sweep binaries."""
import json
import os
import re
import subprocess
from pathlib import Path

TASK = Path(os.environ['TASK'])
OUT = TASK / 'analysis' / 'localize'
OUT.mkdir(parents=True, exist_ok=True)
ROOTS = ['older955', 'reference7abc', 'linux_final', 'candidate']
# (label, demangled symbol substring)
SYMBOLS = [
    ('FP32_L2_1x1', 'kernel<float, 1ul, 1ul, false>'),
    ('FP32_IP_1x1', 'kernel<float, 1ul, 1ul, true>'),
    ('FP32_IP_16x4', 'kernel<float, 16ul, 4ul, true>'),
    ('INT8_L2_2x1', 'kernel<signed char, 2ul, 1ul, false>'),
    ('FP16_IP_1x1', 'kernel<zvec::ailego::Float16, 1ul, 1ul, true>'),
    ('INT4_L2_32x1', 'kernel<unsigned char, 32ul, 1ul, false>'),
    ('INT4_IP_32x32', 'kernel<unsigned char, 32ul, 32ul, true>'),
]
ADDR = re.compile(r'^\s*[0-9a-f]+:\s*')
HEX_TARGET = re.compile(r'\b[0-9a-f]{3,}\b(?= <)')
RIP = re.compile(r'(?<=# )[0-9a-f]+')
COMMENT = re.compile(r'\s*#.*$')
OFFSET = re.compile(r'<([^>+]+)\+0x[0-9a-f]+>')


def symbols(binary):
    out = subprocess.check_output(['nm', '-C', '-S', binary], text=True)
    table = {}
    for line in out.splitlines():
        parts = line.split(maxsplit=3)
        if len(parts) == 4 and parts[2] in 'tTW':
            table[parts[3]] = (int(parts[0], 16), int(parts[1], 16))
    return table


def disasm(binary, start, size):
    out = subprocess.check_output(
        ['objdump', '-d', '-C', '--no-show-raw-insn', f'--start-address={start:#x}',
         f'--stop-address={start + size:#x}', binary], text=True)
    lines = []
    for line in out.splitlines():
        if not ADDR.match(line):
            continue
        line = ADDR.sub('', line)
        line = COMMENT.sub('', line)
        line = HEX_TARGET.sub('ADDR', line)
        line = OFFSET.sub(r'<\1+OFF>', line)
        # rip-relative displacements already resolved by objdump to <sym>; raw
        # 0x... displacements remain only for non-symbol targets.
        line = re.sub(r'0x[0-9a-f]+\(%rip\)', 'DISP(%rip)', line)
        lines.append(line.rstrip())
    return lines


def main():
    report = {}
    for label, needle in SYMBOLS:
        texts = {}
        info = {}
        for root in ROOTS:
            binary = TASK / root / 'build-fixed' / 'bin' / 'matrix_sweep'
            table = symbols(str(binary))
            matches = [k for k in table if k.startswith('void ' + needle)]
            if len(matches) != 1:
                info[root] = {'error': f'{len(matches)} matches', 'matches': matches}
                continue
            start, size = table[matches[0]]
            lines = disasm(str(binary), start, size)
            texts[root] = lines
            info[root] = {'symbol': matches[0], 'address': hex(start), 'size': size,
                          'instructions': len(lines), 'align64': start % 64 == 0, 'align16': start % 16 == 0}
            (OUT / f'{label}.{root}.asm').write_text('\n'.join(lines) + '\n')
        same = {}
        base = texts.get('candidate')
        for root, lines in texts.items():
            same[root] = (lines == base)
        info['identical_to_candidate'] = same
        report[label] = info
    (OUT / 'localize.json').write_text(json.dumps(report, indent=2) + '\n')
    for label, info in report.items():
        print(label)
        for root in ROOTS:
            d = info[root]
            if 'error' in d:
                print('  ', root, d)
            else:
                print(f'   {root:14s} addr={d["address"]:>8s} size={d["size"]:5d} insns={d["instructions"]:4d} '
                      f'align64={d["align64"]} same_as_candidate={info["identical_to_candidate"][root]}')


if __name__ == '__main__':
    main()
