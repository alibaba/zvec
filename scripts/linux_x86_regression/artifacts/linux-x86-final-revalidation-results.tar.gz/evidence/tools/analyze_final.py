#!/usr/bin/env python3
"""Summarize two-round perf results for the final x86 revalidation."""
import csv
import json
import os
import statistics
from pathlib import Path

TASK = Path(os.environ['TASK'])
OUT = TASK / 'analysis'
OUT.mkdir(exist_ok=True)
BASES = ['older955', 'reference7abc', 'linux_final']
LABEL = {'older955': '955', 'reference7abc': '7abc', 'linux_final': 'Linux final',
         'parent': 'parent', 'before': 'before', 'candidate': 'candidate'}
KEYS = {'matrix': ['type', 'metric', 'rows', 'columns', 'dim'],
        'adapter': ['type', 'metric', 'rows', 'columns', 'dim'],
        'ivf': ['type', 'metric', 'dim', 'record']}
ADAPTER_TYPE = {'1': 'FP16', '2': 'FP32', '4': 'INT8', '6': 'INT4rec'}
IVF_TYPE = {'1': 'FP16', '2': 'FP32', '4': 'INT8', '6': 'INT4'}
ITEMS_13 = [('INT4', 'IP', '16', '2', '128'), ('INT4', 'IP', '16', '2', '512'),
            ('INT4', 'IP', '32', '32', '128'), ('INT4', 'IP', '32', '32', '512'),
            ('INT4', 'L2', '32', '1', '128'), ('INT4', 'L2', '32', '1', '512'),
            ('INT4', 'L2', '32', '16', '128'), ('INT4', 'L2', '32', '16', '512'),
            ('INT4', 'L2', '32', '2', '128'), ('INT4', 'L2', '32', '2', '512'),
            ('INT4', 'L2', '8', '8', '128'), ('INT4', 'L2', '8', '8', '512'),
            ('INT8', 'L2', '2', '2', '128')]


def load(group, rnd):
    """Return {key: {version: median}} for all six logical versions."""
    data = {}
    for base in BASES:
        path = TASK / 'comparisons' / f'vs_{base}_round{rnd}' / f'{group}_four_versions.csv'
        for row in csv.DictReader(path.open()):
            key = tuple(row[k] for k in KEYS[group])
            entry = data.setdefault(key, {'parent': [], 'before': [], 'candidate': []})
            entry['parent'].append(float(row['parent']))
            entry['before'].append(float(row['before']))
            entry['candidate'].append(float(row['candidate']))
            entry[base] = float(row['previous_fix'])
    return data


def fmt(v):
    return f'{v:.3f}' if v < 100 else f'{v:.1f}'


def ratio(a, b):
    return f'{a / b:.3f}'


def main():
    report = {}
    tables = []
    data = {g: {1: load(g, 1), 2: load(g, 2)} for g in KEYS}
    # Each root ran its own parent/before/candidate; the compare tool pairs the
    # candidate root's parent/before with each base root, so values repeat.
    for g in data:
        for rnd in (1, 2):
            for key, entry in data[g][rnd].items():
                for v in ('parent', 'before', 'candidate'):
                    assert len(set(entry[v])) == 1, (g, rnd, key, v, entry[v])
                    entry[v] = entry[v][0]

    # Per-root parent/before (drift between roots within a round).
    roots = ['older955', 'reference7abc', 'linux_final', 'candidate']
    drift = {}
    for g in KEYS:
        for rnd in (1, 2):
            per_root = {}
            for root in roots:
                path = TASK / root / f'results_round{rnd}' / f'{g}_comparison.csv'
                for row in csv.DictReader(path.open()):
                    key = tuple(row[k] for k in KEYS[g])
                    per_root.setdefault(key, {})[root] = (float(row['parent']), float(row['before']), float(row['fixed']))
            spreads = []
            for key, rows in per_root.items():
                for idx, name in enumerate(['parent', 'before']):
                    vals = [rows[r][idx] for r in roots]
                    spreads.append(max(vals) / min(vals))
            drift[f'{g}_round{rnd}'] = {'max_parent_before_spread_across_roots': max(spreads),
                                        'median_spread': statistics.median(spreads),
                                        'over_1.05': sum(s > 1.05 for s in spreads), 'n': len(spreads)}
    report['root_drift'] = drift

    # Regression counts and two-round intersections.
    summary = {}
    for g in KEYS:
        summary[g] = {}
        for comp in BASES + ['before', 'parent']:
            per_round = {}
            for rnd in (1, 2):
                over = {}
                ratios = []
                for key, e in data[g][rnd].items():
                    r = e['candidate'] / e[comp]
                    ratios.append(r)
                    if r > 1.05:
                        over[key] = r
                per_round[rnd] = {'over_5pct': over, 'median_ratio': statistics.median(ratios),
                                  'faster_5pct': sum(r < 0.95 for r in ratios)}
            both = sorted(set(per_round[1]['over_5pct']) & set(per_round[2]['over_5pct']))
            summary[g][comp] = {
                'round1_over_5pct': len(per_round[1]['over_5pct']),
                'round2_over_5pct': len(per_round[2]['over_5pct']),
                'both_rounds_over_5pct': [
                    {'key': dict(zip(KEYS[g], k)), 'round1': per_round[1]['over_5pct'][k],
                     'round2': per_round[2]['over_5pct'][k]} for k in both],
                'median_ratio_round1': per_round[1]['median_ratio'],
                'median_ratio_round2': per_round[2]['median_ratio'],
                'faster_5pct_round1': per_round[1]['faster_5pct'],
                'faster_5pct_round2': per_round[2]['faster_5pct'],
                'round1_items': [{'key': dict(zip(KEYS[g], k)), 'ratio': v} for k, v in sorted(per_round[1]['over_5pct'].items())],
                'round2_items': [{'key': dict(zip(KEYS[g], k)), 'ratio': v} for k, v in sorted(per_round[2]['over_5pct'].items())],
            }
    report['summary'] = summary

    def row_line(g, key):
        d1, d2 = data[g][1][key], data[g][2][key]
        if g == 'matrix':
            label = f'{key[0]} {key[1]} {key[2]}×{key[3]} d{key[4]}'
        elif g == 'adapter':
            label = f'{ADAPTER_TYPE.get(key[0], key[0])} {key[1]} {key[2]}×{key[3]} d{key[4]}'
        else:
            label = f'{IVF_TYPE.get(key[0], key[0])} {key[1]} d{key[2]} record={key[3]}'
        cells = [label]
        for v in ['parent', 'before', 'older955', 'reference7abc', 'linux_final', 'candidate']:
            cells.append(f'{fmt(d1[v])} / {fmt(d2[v])}')
        for v in ['linux_final', 'reference7abc', 'older955', 'before', 'parent']:
            cells.append(f'{ratio(d1["candidate"], d1[v])} / {ratio(d2["candidate"], d2[v])}')
        return '| ' + ' | '.join(cells) + ' |'

    header = ('| 类型 / 度量 / 形状 | parent R1/R2 | before R1/R2 | 955 R1/R2 | 7abc R1/R2 | Linux final R1/R2 | candidate R1/R2 '
              '| cand/Linux final | cand/7abc | cand/955 | cand/before | cand/parent |\n'
              '|---|---|---|---|---|---|---|---|---|---|---|---|')

    def table(title, g, keys, note=None):
        tables.append(f'\n### {title}\n')
        if note:
            tables.append(note + '\n')
        tables.append(header)
        for k in keys:
            tables.append(row_line(g, k))

    mk = data['matrix'][1]
    tables.append('# Linux x86 最终复验：两轮完整性能表\n')
    tables.append('单位：matrix/adapter 为单线程 CPU ns/matrix（每版本 3 进程轮换取中位数），IVF 为 wall-clock us/query。'
                  'R1/R2 为第一、二轮。比值 <1 表示 candidate 更快。parent/before 来自 candidate 根目录的同轮运行。\n')

    def sel(pred):
        return sorted((k for k in mk if pred(k)), key=lambda k: (k[0], k[1], int(k[2]), int(k[3]), int(k[4])))

    table('A. 此前 13 项整数目标', 'matrix', [k for k in ITEMS_13 if k in mk])
    table('B. FP16 全部形状', 'matrix', sel(lambda k: k[0] == 'FP16'))
    table('C. INT4 单列 2~32 行', 'matrix', sel(lambda k: k[0] == 'INT4' and k[3] == '1'))
    table('D. INT4 多列（含 16×16 / 32×16 / 32×32 与小多列）', 'matrix', sel(lambda k: k[0] == 'INT4' and k[3] != '1'))
    table('E. INT8 全部形状', 'matrix', sel(lambda k: k[0] == 'INT8'))
    table('F. INT16 全部形状', 'matrix', sel(lambda k: k[0] == 'INT16'))
    table('G. FP32 全部形状', 'matrix', sel(lambda k: k[0] == 'FP32'))
    table('H. FP64 全部形状', 'matrix', sel(lambda k: k[0] == 'FP64'))
    ak = data['adapter'][1]
    table('I. Adapter 32 用例（记录路径 / 融合 MIPS；type 1=FP16 2=FP32 4=INT8 6=INT4 record）', 'adapter',
          sorted(ak, key=lambda k: (k[0], k[1], int(k[2]), int(k[3]), int(k[4]))))
    ik = data['ivf'][1]
    table('J. 旧 IVF 24 用例（type 1=FP16 2=FP32 4=INT8 6=INT4）', 'ivf',
          sorted(ik, key=lambda k: (k[0], k[1], int(k[2]), int(k[3]))))

    # Complete raw table for completeness (504 rows).
    table('K. 全部 504 raw matrix 用例', 'matrix', sel(lambda k: True))

    (OUT / 'PERFORMANCE_TABLES.md').write_text('\n'.join(tables) + '\n')
    (OUT / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')

    # Short textual summary.
    lines = []
    for g in KEYS:
        lines.append(f'## {g}')
        for comp in BASES + ['before', 'parent']:
            s = summary[g][comp]
            lines.append(f'- candidate vs {LABEL[comp]}: >5% R1={s["round1_over_5pct"]} R2={s["round2_over_5pct"]} '
                         f'both={len(s["both_rounds_over_5pct"])}; median ratio R1={s["median_ratio_round1"]:.4f} '
                         f'R2={s["median_ratio_round2"]:.4f}; faster>5% R1={s["faster_5pct_round1"]} R2={s["faster_5pct_round2"]}')
            for item in s['both_rounds_over_5pct']:
                lines.append(f'    * BOTH {item["key"]} R1={item["round1"]:.3f} R2={item["round2"]:.3f}')
    lines.append('## root drift (parent/before spread across the four roots)')
    for k, v in drift.items():
        lines.append(f'- {k}: max={v["max_parent_before_spread_across_roots"]:.3f} median={v["median_spread"]:.3f} over1.05={v["over_1.05"]}/{v["n"]}')
    (OUT / 'summary.md').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
