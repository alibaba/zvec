#!/usr/bin/env python3
"""Recompile every non-identical build-fixed object with the root prefix mapped; compare bytes."""
import concurrent.futures, hashlib, json, os, pathlib, shlex, subprocess
TASK = pathlib.Path(os.environ['TASK']); OUT = TASK / 'codecheck/prefixmap_all'
OUT.mkdir(exist_ok=True)
objs = [r['object'] for r in json.load(open(TASK / 'codecheck/all_objects.json'))['objects'] if not r['file_identical']]
cmds = {}
for root in ('linux_final', 'candidate'):
    build = TASK / root / 'build-fixed'
    for e in json.load(open(build / 'compile_commands.json')):
        args = shlex.split(e['command']); o = args.index('-o')
        cmds[(root, args[o + 1])] = (e['directory'], args, o)


def build(job):
    root, obj = job
    directory, args, o = cmds[(root, obj)]
    out = OUT / root / obj
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = args[:1] + [f'-ffile-prefix-map={TASK / root}=/ROOT'] + args[1:o] + ['-o', str(out)] + args[o + 2:]
    r = subprocess.run(cmd, cwd=directory, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return root, obj, r.returncode, hashlib.sha256(out.read_bytes()).hexdigest() if r.returncode == 0 else None


jobs = [(root, obj) for obj in objs for root in ('linux_final', 'candidate')]
res = {}
with concurrent.futures.ThreadPoolExecutor(6) as pool:
    for root, obj, rc, digest in pool.map(build, jobs):
        res.setdefault(obj, {})[root] = (rc, digest)
rows = [dict(object=o, linux_final=v['linux_final'][1], candidate=v['candidate'][1],
             identical=v['linux_final'][1] is not None and v['linux_final'][1] == v['candidate'][1]) for o, v in sorted(res.items())]
summary = dict(recompiled=len(rows), identical=sum(r['identical'] for r in rows),
               not_identical=[r['object'] for r in rows if not r['identical']])
(TASK / 'codecheck/prefixmap_all.json').write_text(json.dumps(dict(summary=summary, objects=rows), indent=1) + '\n')
print(json.dumps(summary, indent=1))
