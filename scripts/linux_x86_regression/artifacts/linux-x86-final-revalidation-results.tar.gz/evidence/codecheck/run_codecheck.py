#!/usr/bin/env python3
"""candidate vs linux_final: preprocessed tokens, object sections, disassembly."""
import hashlib, json, os, pathlib, re, shlex, subprocess, sys

TASK = pathlib.Path(os.environ['TASK'])
OUT = TASK / 'codecheck'
TUS = ['matrix_sweep.cc', 'quantized_integer_metric.cc', 'mips_euclidean_metric.cc',
       'adapter_sweep.cc']
ROOTS = ['linux_final', 'candidate']
log = []
# C++ lexer: literals, pp-numbers, identifiers, operators; whitespace is not a token.
LEX = re.compile(r'''(?:u8|u|U|L)?R"([^()\\ ]{0,16})\((?:.|\n)*?\)\1"|(?:u8|u|U|L)?"(?:\\.|[^"\\\n])*"|(?:u8|u|U|L)?'(?:\\.|[^'\\\n])*'|\.?[0-9](?:[eEpP][+-]|[0-9A-Za-z_.']|)*|[A-Za-z_$][A-Za-z0-9_$]*|<=>|->\*|<<=|>>=|\.\.\.|::|->|\.\*|\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\||[-+*/%&|^]=|##|\S''', re.S)


def sh(cmd, cwd=None, out=None):
    log.append((str(cwd), cmd if isinstance(cmd, str) else shlex.join(map(str, cmd))))
    r = subprocess.run(cmd, cwd=cwd, shell=isinstance(cmd, str), stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE)
    if r.returncode:
        sys.stderr.write(r.stderr.decode()[-2000:])
        raise SystemExit(f'failed: {cmd}')
    if out:
        pathlib.Path(out).write_bytes(r.stdout)
    return r.stdout


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sections(obj):
    """name-indexed list of (index, name, type, flags, sha256) for an object."""
    import struct
    data = pathlib.Path(obj).read_bytes()
    shoff = struct.unpack_from('<Q', data, 0x28)[0]
    shentsize, shnum, shstrndx = struct.unpack_from('<HHH', data, 0x3A)
    hdrs = [struct.unpack_from('<IIQQQQIIQQ', data, shoff + i * shentsize) for i in range(shnum)]
    stroff = hdrs[shstrndx][4]
    out = []
    for i, h in enumerate(hdrs):
        name = data[stroff + h[0]:data.index(b'\0', stroff + h[0])].decode()
        body = b'' if h[1] == 8 else data[h[4]:h[4] + h[5]]   # SHT_NOBITS has no bytes
        out.append((i, name, h[1], h[2], h[5], hashlib.sha256(body).hexdigest(), body))
    return out


report = {}
for tu in TUS:
    entry = {}
    work = {}
    for root in ROOTS:
        build = TASK / root / 'build-fixed'
        cc = json.load(open(build / 'compile_commands.json'))
        e = [x for x in cc if x['file'].endswith('/' + tu)]
        assert len(e) == 1, (root, tu, len(e))
        e = e[0]
        args = shlex.split(e['command'])
        o = args.index('-o')
        obj_rel = args[o + 1]
        d = OUT / tu.replace('.cc', '') / root
        d.mkdir(parents=True, exist_ok=True)
        (d / 'compile_command.txt').write_text(e['command'] + '\n')
        # 1. preprocessed tokens without line markers
        pre = args[:o] + args[o + 2:]
        pre = [a for a in pre if a != '-c']
        pre_cmd = pre[:1] + ['-E', '-P'] + pre[1:]
        sh(pre_cmd, cwd=e['directory'], out=d / 'preprocessed.ii')
        text = (d / 'preprocessed.ii').read_text(errors='replace')
        tokens = [m.group(0) for m in LEX.finditer(text)]
        (d / 'preprocessed.tokens.sha256').write_text(
            hashlib.sha256('\n'.join(tokens).encode()).hexdigest() + f'  tokens={len(tokens)}\n')
        # 2. the object produced by the validated build itself
        built = build / obj_rel
        (d / 'built.o').write_bytes(built.read_bytes())
        # 3. reproduce the object with the recorded command (same flags)
        rep_cmd = args[:o] + ['-o', str(d / 'reproduced.o')] + args[o + 2:]
        sh(rep_cmd, cwd=e['directory'])
        # 4. reproduce with only the worktree prefix mapped (isolates __FILE__/path strings)
        map_cmd = args[:1] + [f'-ffile-prefix-map={TASK / root}=/ROOT'] + args[1:o] + \
            ['-o', str(d / 'prefixmapped.o')] + args[o + 2:]
        sh(map_cmd, cwd=e['directory'])
        for name in ('built.o', 'reproduced.o', 'prefixmapped.o'):
            sh(f'objdump -d -r -C -w --no-show-raw-insn {name} | sed 1,2d > {name}.disasm.txt', cwd=d)
            sh(f'objdump -d -r -w {name} | sed 1,2d > {name}.disasm_raw.txt', cwd=d)
        (d / 'preprocessed.tokens.txt').write_text('\n'.join(tokens) + '\n')
        work[root] = dict(dir=d, tokens=tokens)
    a, b = (work[r] for r in ROOTS)
    entry['preprocessed_token_count'] = [len(a['tokens']), len(b['tokens'])]
    entry['preprocessed_tokens_identical'] = a['tokens'] == b['tokens']
    if not entry['preprocessed_tokens_identical']:
        import difflib
        dtext = '\n'.join(difflib.unified_diff(a['tokens'], b['tokens'], 'linux_final', 'candidate', lineterm='', n=3))
        (OUT / tu.replace('.cc', '') / 'preprocessed_token.diff').write_text(dtext + '\n')
        entry['preprocessed_token_diff'] = dtext[:4000]
    for name in ('built.o', 'reproduced.o', 'prefixmapped.o'):
        sa, sb = sections(a['dir'] / name), sections(b['dir'] / name)
        diff_sections = []
        same_layout = [(x[1], x[2], x[3], x[4]) for x in sa] == [(x[1], x[2], x[3], x[4]) for x in sb]
        exec_same = True
        n_exec = 0
        for x, y in zip(sa, sb):
            is_exec = bool(x[3] & 4)
            n_exec += is_exec
            if x[5] != y[5] or x[1] != y[1]:
                diff_sections.append(dict(index=x[0], name_a=x[1], name_b=y[1], size_a=x[4], size_b=y[4], executable=is_exec))
                exec_same &= not is_exec
        da = (a['dir'] / f'{name}.disasm_raw.txt').read_bytes()
        db = (b['dir'] / f'{name}.disasm_raw.txt').read_bytes()
        entry[name] = dict(
            sha256=[sha(a['dir'] / name), sha(b['dir'] / name)],
            file_identical=sha(a['dir'] / name) == sha(b['dir'] / name),
            section_count=[len(sa), len(sb)], same_section_table=same_layout,
            executable_sections=n_exec, executable_section_bytes_identical=exec_same and len(sa) == len(sb),
            differing_sections=diff_sections[:20], differing_section_count=len(diff_sections),
            disassembly_with_relocations_identical=da == db,
            disassembly_lines=da.count(b'\n'))
        # show string-level difference for differing non-exec sections
        strings = []
        for x, y in zip(sa, sb):
            if x[5] != y[5] and not (x[3] & 4) and x[1].startswith('.rodata'):
                strings.append(dict(section=x[1], a=x[6][:300].decode('latin1'), b=y[6][:300].decode('latin1')))
        entry[name]['differing_rodata_samples'] = strings[:4]
    # built vs reproduced determinism inside each root
    for root in ROOTS:
        d = work[root]['dir']
        entry[f'{root}_built_equals_reproduced'] = sha(d / 'built.o') == sha(d / 'reproduced.o')
    report[tu] = entry

# linked executables: section hashes and normalized disassembly
norm = re.compile(r'^\s*[0-9a-f]+:\s*')
for binary in ['matrix_sweep', 'adapter_sweep', 'legacy_ivf_comparison']:
    entry = {}
    d = OUT / 'executables' / binary
    d.mkdir(parents=True, exist_ok=True)
    info = {}
    for root in ROOTS:
        path = TASK / root / 'build-fixed/bin' / binary
        secs = {s[1]: s for s in sections(path)}
        sh(f'objdump -d -w --no-show-raw-insn {path} | sed 1,2d > {d}/{root}.disasm.txt')
        sh(f'objdump -d -w {path} | sed 1,2d > {d}/{root}.disasm_raw.txt')
        info[root] = dict(sha256=sha(path), size=path.stat().st_size,
                          text_sha256=secs['.text'][5], text_size=secs['.text'][4],
                          rodata_sha256=secs['.rodata'][5], rodata_size=secs['.rodata'][4],
                          sections={n: [s[4], s[5]] for n, s in secs.items() if n})
    a, b = info['linux_final'], info['candidate']
    entry['file_sha256'] = [a['sha256'], b['sha256']]
    entry['file_size'] = [a['size'], b['size']]
    entry['text_size'] = [a['text_size'], b['text_size']]
    entry['text_bytes_identical'] = a['text_sha256'] == b['text_sha256']
    entry['rodata_size'] = [a['rodata_size'], b['rodata_size']]
    entry['rodata_bytes_identical'] = a['rodata_sha256'] == b['rodata_sha256']
    entry['sections_differing'] = sorted(n for n in a['sections'] if a['sections'][n] != b['sections'].get(n))
    entry['disassembly_identical'] = (d / 'linux_final.disasm.txt').read_bytes() == (d / 'candidate.disasm.txt').read_bytes()
    entry['disassembly_with_bytes_identical'] = (d / 'linux_final.disasm_raw.txt').read_bytes() == (d / 'candidate.disasm_raw.txt').read_bytes()
    sh(f'diff {d}/linux_final.disasm_raw.txt {d}/candidate.disasm_raw.txt > {d}/disasm_raw.diff; true')
    entry['disassembly_diff_lines'] = (d / 'disasm_raw.diff').read_text().count('\n')
    report['exe:' + binary] = entry

(OUT / 'codecheck.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'commands.log').write_text(''.join(f'[cwd={c}] {k}\n' for c, k in log))
for k, v in report.items():
    print('==', k)
    for kk, vv in v.items():
        if isinstance(vv, dict):
            print('  ', kk, {x: y for x, y in vv.items() if x not in ('differing_sections', 'differing_rodata_samples', 'sha256')})
        else:
            print('  ', kk, vv if not isinstance(vv, str) else vv[:500])
