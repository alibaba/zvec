# x86 代码一致性：candidate(008fbdc3 via candidate_vs_955.patch) vs linux_final(reference_linux_final_vs_955.patch)

编译器 GCC 13.3.0，参数取自各自 build-fixed/compile_commands.json（-O3 -march=x86-64 -std=c++17，fixed 树相同选项）。

源码差异（`candidate_vs_linux_final_src.diff`）：仅 src/turbo/distance/matrix.h 三处，全部位于 `#if defined(AILEGO_ARM64_GNU_LIKE)` / `#if defined(__aarch64__) || defined(_M_ARM64)` 之内；tests 无差异。

## 1. 指定三个翻译单元（另加 adapter_sweep.cc）

| TU | 预处理 token 数 | token 完全相同 | 非路径 token 差异 | built.o 可执行节字节相同 | built.o 反汇编(含重定位)相同 | built.o 差异节 | -ffile-prefix-map 后 .o 字节相同 |
|---|---|---|---|---|---|---|---|
| matrix_sweep.cc | 599566 / 599566 | 是 | 无 | 是（581 个可执行节） | 是 | 无 | 是 |
| quantized_integer_metric.cc | 986610 / 986610 | 否 | 无（差异仅为 __FILE__ 字符串中的工作树路径 linux_final/ vs candidate/） | 是（536 个可执行节） | 是 | .rodata._ZN4zvec4core22QuantizedIntegerMetric4initERKNS0_9IndexMetaERKNS_6ailego6ParamsE.str1.8 | 是 |
| mips_euclidean_metric.cc | 991561 / 991561 | 否 | 无（差异仅为 __FILE__ 字符串中的工作树路径 linux_final/ vs candidate/） | 是（1090 个可执行节） | 否（仅 .LC 标号/字符串偏移） | .rodata._ZNK4zvec4core26MipsSquaredEuclideanMetricILb1EE15sparse_distanceEv.str1.8, .symtab | 是 |
| adapter_sweep.cc | 983617 / 983617 | 是 | 无 | 是（34 个可执行节） | 是 | 无 | 是 |

说明：quantized_integer_metric.cc / mips_euclidean_metric.cc 的 .rodata.str1.8 含 `__FILE__`（日志宏），两套工作树路径长度不同（linux_final 11 字符 vs candidate 9 字符），导致该只读字符串节及符号表差异；mips 的 objdump 文本中 .LC 标号偏移随之不同。指令字节（全部可执行节）完全相同；加 `-ffile-prefix-map=<root>=/ROOT` 重新编译后目标文件逐字节相同。每套 built.o 与按记录命令重编的 reproduced.o 均逐字节相同（构建可复现）。

## 2. build-fixed 全部目标文件（257 个）

- 目标文件集合相同：True；原样字节相同 150/257；可执行节字节相同 253/257（可执行节总计 12509331 字节）。
- 可执行节有差异的 4 个均为测试程序 TU（mips_callback_lifetime_test.cc.o, opt_kmeans_cluster_test.cc.o, legacy_quantized_index_test.cc.o, turbo_neon_float_batch_test.cc.o）：差异为 `__FILE__` 字符串长度不同带来的立即数（如 `mov $0x8b` vs `$0x89` 为路径长度）和 .LC 偏移，见 `test_objects/*.diff`。
- 对 107 个非逐字节相同的目标文件加 `-ffile-prefix-map` 重编：107/107 逐字节相同（`prefixmap_all.json`）。

## 3. 链接后的三个基准可执行文件

| 可执行文件 | .text 大小 | .text 符号地址相同 | 指令数 | 原始反汇编差异行 | 差异全部为 RIP 相对位移 | 屏蔽 RIP 位移后差异行 |
|---|---|---|---|---|---|---|
| matrix_sweep | 1722795 / 1722795 | True | 395280 | 4728 | True | 0 |
| adapter_sweep | 1032427 / 1032427 | True | 242788 | 345 | True | 0 |
| legacy_ivf_comparison | 1434395 / 1434395 | True | 341927 | 4083 | True | 0 |

结论：x86 上 candidate 与 linux_final 的预处理 token（排除 __FILE__ 路径）、全部可执行节指令字节、链接后的 .text 符号布局与指令流完全相同；仅 .rodata 字符串（工作树路径）与由此产生的 RIP 相对位移/Build-ID 不同。ARM 新增分支在 x86 预处理阶段被完全排除。两套性能差异只能来自测量噪声或 .rodata 字符串引起的数据布局偏移（64 字节级，matrix_sweep .rodata 37620 vs 37556）。
