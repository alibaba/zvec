#!/usr/bin/env python3
"""All build-fixed objects and linked benchmark executables: candidate vs linux_final."""
import hashlib, json, os, pathlib, re, struct, subprocess
TASK = pathlib.Path(os.environ['TASK']); OUT = TASK / 'codecheck'


def sections(path):
    data = pathlib.Path(path).read_bytes()
    shoff = struct.unpack_from('<Q', data, 0x28)[0]
    shentsize, shnum, shstrndx = struct.unpack_from('<HHH', data, 0x3A)
    hdrs = [struct.unpack_from('<IIQQQQIIQQ', data, shoff + i * shentsize) for i in range(shnum)]
    stroff = hdrs[shstrndx][4]
    out = []
    for h in hdrs:
        name = data[stroff + h[0]:data.index(b'\0', stroff + h[0])].decode()
        body = b'' if h[1] == 8 else data[h[4]:h[4] + h[5]]
        out.append((name, h[1], h[2], h[3], h[5], hashlib.sha256(body).hexdigest()))
    return out


a_root, b_root = TASK / 'linux_final/build-fixed', TASK / 'candidate/build-fixed'
objs = sorted(p.relative_to(a_root) for p in a_root.rglob('*.o'))
objs_b = sorted(p.relative_to(b_root) for p in b_root.rglob('*.o'))
rows = []
summary = dict(objects_linux_final=len(objs), objects_candidate=len(objs_b), same_object_set=objs == objs_b,
               file_identical=0, exec_sections_identical=0, exec_sections_differ=[], nonexec_differ_only=0)
for rel in objs:
    sa, sb = sections(a_root / rel), sections(b_root / rel)
    same_file = (a_root / rel).read_bytes() == (b_root / rel).read_bytes()
    ea = [(s[0], s[4], s[5]) for s in sa if s[2] & 4]
    eb = [(s[0], s[4], s[5]) for s in sb if s[2] & 4]
    exec_same = ea == eb
    diff_names = sorted({x[0].split('._Z')[0] for x, y in zip(sa, sb) if x[5] != y[5]})
    rows.append(dict(object=str(rel), file_identical=same_file, exec_sections=len(ea),
                     exec_bytes=sum(x[1] for x in ea), exec_sections_identical=exec_same,
                     differing_section_kinds=diff_names))
    summary['file_identical'] += same_file
    summary['exec_sections_identical'] += exec_same
    if not exec_same:
        summary['exec_sections_differ'].append(str(rel))
    elif not same_file:
        summary['nonexec_differ_only'] += 1
summary['differing_section_kinds_overall'] = sorted({k for r in rows for k in r['differing_section_kinds']})
summary['total_exec_bytes'] = sum(r['exec_bytes'] for r in rows)

# linked executables
mask_rip = re.compile(r'[-]?0x[0-9a-f]+\(%rip\)')
strip_cmt = re.compile(r'\s+#.*$')
exes = {}
for binary in ['matrix_sweep', 'adapter_sweep', 'legacy_ivf_comparison']:
    d = OUT / 'executables' / binary
    info = {}
    for root in ('linux_final', 'candidate'):
        path = TASK / root / 'build-fixed/bin' / binary
        nm = subprocess.run(['nm', '-n', '--defined-only', str(path)], stdout=subprocess.PIPE, text=True).stdout
        text_syms = [tuple(l.split(None, 2)) for l in nm.splitlines() if len(l.split(None, 2)) == 3 and l.split(None, 2)[1] in 'tTwW']
        (d / f'{root}.text_symbols.txt').write_text('\n'.join(' '.join(t) for t in text_syms) + '\n')
        lines = (d / f'{root}.disasm.txt').read_text().splitlines()
        norm = [mask_rip.sub('RIPREL', strip_cmt.sub('', l)) for l in lines]
        (d / f'{root}.disasm_masked.txt').write_text('\n'.join(norm) + '\n')
        info[root] = dict(text_syms=text_syms, norm=norm, lines=lines)
    a, b = info['linux_final'], info['candidate']
    ndiff = sum(1 for x, y in zip(a['norm'], b['norm']) if x != y) + abs(len(a['norm']) - len(b['norm']))
    raw_diff = [(x, y) for x, y in zip(a['lines'], b['lines']) if x != y]
    only_rip = all(mask_rip.sub('R', strip_cmt.sub('', x)) == mask_rip.sub('R', strip_cmt.sub('', y)) for x, y in raw_diff)
    exes[binary] = dict(text_symbols=[len(a['text_syms']), len(b['text_syms'])],
                        text_symbol_addresses_identical=a['text_syms'] == b['text_syms'],
                        instructions=len(a['norm']), raw_lines_differing=len(raw_diff),
                        all_differences_are_rip_relative_displacements=only_rip,
                        masked_disassembly_lines_differing=ndiff,
                        sample_raw_difference=[list(raw_diff[0])] if raw_diff else [])
summary['executables'] = exes
(OUT / 'all_objects.json').write_text(json.dumps(dict(summary=summary, objects=rows), indent=1) + '\n')
print(json.dumps(summary, indent=1))
