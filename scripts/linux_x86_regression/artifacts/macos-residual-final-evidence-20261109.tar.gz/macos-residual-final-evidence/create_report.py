import csv,json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
summary=json.loads((root/'results/two_round_summary.json').read_text())
focus=json.loads((root/'results/fp16_focus_summary.json').read_text())
data={rnd:{g:list(csv.DictReader((root/rnd/(g+'_comparison.csv')).open())) for g in ['matrix','adapter','ivf']} for rnd in ['round1','round2']}
lines=['# macOS ARM64：x86 residual final 候选复验报告','',
'日期：2026-11-09。**结论：正确性、旧索引兼容通过；性能门槛未通过，不建议原样合入。**',
'相对 9819c706，两轮共同复现 12 项 INT4 大多列矩阵回退和 2 项 INT4 MIPS 32×32 适配器回退；另有 1 项 FP16 1×1 整程序布局相关微基准回退。IVF 24 项两轮均无 >5% 回退。','',
'## 1. 版本、输入与隔离','',
'- 已 fetch richyreachy/zvec 的 fix/legacy-matrix-distance-performance 并检查 fast-forward 状态；本地/远端分支为 c65ac8895baa8157566db3aeeab10b29284c4794，包含要求的 c65ac889。',
'- 已先阅读分支的 MACOS_RESIDUAL_FINAL_START_HERE_zh.txt 和包内 RESIDUAL_X86_REPORT_zh.md。',
'- 输入包 SHA256：`81a2909bc8ef474d33373127765e0988210d8ab3fe184744ef2d538a42c3de4a`；包内 SHA256SUMS 的 169 项全部通过，见 buildinfo/package_checksum_check.txt。',
'- 独立工作树 source/ 基于 9819c706e49d60150886cdefcc8592aa81b46019；应用 patches/final_vs_9819c706.patch，git apply --check 通过。仅 matrix.h 改动（58 insertions / 24 deletions），与包中 diagnostics/matrix_final.h 逐字一致。',
'- c65ac889 相对 9819c706 的 src/tests 无差异。主分支工作区仍干净，候选没有提交、推送或合入。未另改候选代码。','',
'## 2. 环境与方法','',
'- Apple M3 Pro，11 核，36 GiB；macOS 26.6.2；AppleClang 15.0.0；Release `-march=armv8 -O3 -DNDEBUG -std=c++17`，ENABLE_NATIVE=OFF，无全局对齐参数、无 LTO/OpenMP。编译记录见 buildinfo/。',
'- 候选重新独立构建，测试和基准静态 force_load 链接，避免 macOS 工厂注册库被裁掉。',
'- 三个基线复用先前保留的静态可执行文件，本次全部重新计时，未复用历史性能数值。来源和 SHA256 见 buildinfo/baseline_binaries.json。955 / 7abc / 9819 的原始矩阵 __text、__const、__cstring 地址与内容哈希完全一致，见 baseline_sections.json；两次已有修复的相关生产代码变动为 x86 分支。',
'- matrix_sweep.cc、adapter_sweep.cc 与分支提交的 toolkit 逐字一致，IVF 基准源码在 955 至 9819 间不变；统一 benchmark_qos.h。matrix/adapter 用线程 CPU 时间，IVF 用 warm search_impl 墙钟时间。',
'- 每轮各版本各 3 个独立进程，按版本交错、每次重复反转顺序；第二轮反转首轮起始顺序。每进程内部 matrix/adapter 5 次计时取中位数，IVF 7 次取中位数，再取 3 个进程的中位数。共 72 个完整基准进程；与构建及其他基准串行。',
'- **调度限制：macOS 使用统一 USER_INTERACTIVE QoS + taskpolicy -a，并未硬绑某个核心；不能把它描述成 Linux taskset 的固定核心测量。** 两轮复现、基线代码哈希和单项隔离验证用于控制/解释波动。',
'- 所有比值为 FINAL / 基线耗时，小于 1 为变快；原始日志、min/max 和中位数均保留。不将分组中位数持平当作所有形状通过。','',
'## 3. 正确性与旧索引兼容','',
'| 检查 | 本次 macOS 结果 |','|---|---|',
'| 44 个测试程序 | 498 通过 / 33 跳过 / 25 禁用 / 0 失败；全部退出 0 |',
'| 正确性范围 | 10 个 core metric、27 个 Turbo、2 个 flat、3 个 clustering、ivf_legacy_matrix_test、IVFSearcher 指定 13 项 |',
'| 新增旧记录矩统计测试 | TurboMetricAdapter.Int4RecordMatricesPreserveStoredMoments 通过 |',
'| parent 499eab89 重新写旧索引 | 200 个 .index；12 通过 / 4 跳过 / 16 禁用 / 0 失败，退出 0 |',
'| FINAL 读取上述索引 | 12 通过 / 4 跳过 / 16 禁用 / 0 失败，退出 0 |','',
'旧索引覆盖 FP32/FP16/INT8/INT4、L2/IP、INT8/INT4 record、维度 8/17/128/512（整数跳过 17）、31/32/33/65 以及多列表含空列表、3 种存储、2 个 topk、3 种过滤、普通/BF 搜索、批量与单查询。测试循环读取 200 个文件并校验 28,800 份查询结果列表；读取路径 copy_file 出错即断言失败，不会静默重建。文件哈希见 results/fixture_sha256.txt。这里未使用系统调用跟踪，200 文件覆盖由测试枚举与通过的断言确认。',
'测试 XML/日志和精确筛选见 results/、run_tests.py。33 跳过按 XML result="skipped" 计数，未误计为通过。25 禁用未计入正确性通过数；其中 warm IVF benchmark 在性能阶段单独启用。',
'本轮为交接说明限定的矩阵、度量、IVF 相关范围，非全仓或全产品端到端正确性/吞吐认证。','',
'## 4. 两轮总体性能','',
'| 组 | 基线 | 项数 | R1 >5% | R2 >5% | 两轮共同 >5% | 中位比值 R1 / R2 |','|---|---|---:|---:|---:|---:|---|']
for g in ['matrix','adapter','ivf']:
 for v in ['9819','7abc','955']:
  s=summary[g][v];lines.append(f"| {g} | {v} | {s['count']} | {s['round1_over5']} | {s['round2_over5']} | {len(s['both_rounds'])} | {s['round1_median']:.3f} / {s['round2_median']:.3f} |")
lines += ['', '两个轮次分别保存三组完整 CSV，包含 955、7abc、9819、FINAL 的原始中位数/min/max 与全部比值。两轮共同项在三个基线下相同：矩阵 13 项、适配器 2 项、IVF 0 项。单轮额外波动项也保留，未从 CSV 删除。','',
'## 5. 两轮复现的回退（相对 9819，ns）','',
'| 路径 | dim | 9819 R1 / R2 | FINAL R1 / R2 | 比值 R1 / R2 |','|---|---:|---|---|---|']
for g in ['matrix','adapter']:
 for r in summary[g]['9819']['both_rounds']:
  label=(r['type'] if g=='matrix' else {'1':'FP16','2':'FP32','4':'INT8','6':'INT4'}[r['type']])+' '+r['metric']+' '+r['rows']+'×'+r['columns']+(' adapter' if g=='adapter' else '')
  lines.append(f"| {label} | {r['dim']} | {r['round1_before']:.3f} / {r['round2_before']:.3f} | {r['round1_after']:.3f} / {r['round2_after']:.3f} | {r['round1_ratio']:.3f} / {r['round2_ratio']:.3f} |")
lines += ['', 'INT4 回退集中在 16×16、32×16、32×32，各含 L2/IP 与 128/512 维，共 12 项；两轮相对 9819 为 **+12.3%～+21.3%**。MIPS 32×32 为 **+12.5%～+19.6%**。','',
'## 6. 改善路径与 IVF 影响','',
'| 路径 | 项数 | FINAL/9819 中位数 R1 / R2 | 两轮比值范围 |','|---|---:|---|---|']
filters=[('INT4 单列 Rows≥4','matrix',lambda r:r['type']=='INT4' and r['columns']=='1' and int(r['rows'])>=4),('INT4 多列 Rows≥8、Columns=2/4/8','matrix',lambda r:r['type']=='INT4' and int(r['rows'])>=8 and 2<=int(r['columns'])<=8),('INT4 RecordL2/IP 32×1','adapter',lambda r:r['type']=='6' and r['columns']=='1' and r['metric'].startswith('Record')),('INT4 MIPS 32×1','adapter',lambda r:r['type']=='6' and r['columns']=='1' and r['metric']=='MIPS'),('旧 IVF INT4 raw','ivf',lambda r:r['type']=='6' and r['record']=='0'),('旧 IVF INT4 record','ivf',lambda r:r['type']=='6' and r['record']=='1')]
for label,g,pred in filters:
 vals=[[float(r['final_vs_9819']) for r in data[rnd][g] if pred(r)] for rnd in ['round1','round2']];flat=vals[0]+vals[1];lines.append(f'| {label} | {len(vals[0])} | {statistics.median(vals[0]):.3f} / {statistics.median(vals[1]):.3f} | {min(flat):.3f}～{max(flat):.3f} |')
lines += ['',
'INT4 Rows≤4 的多列保留旧算法，INT4 2×1 没有两轮共同 >5% 回退。FP32/FP64/INT8/INT16 的本轮矩阵项没有两轮共同 >5% 回退；FP16 仅下述 1×1 微形状。',
'**修正交接说明的一点预期：**x86-only 的 INT4 record n==1 batch 分支在 macOS 的确未启用，但 ARM64 的记录矩阵仍通过 MakeRawDistanceMatrix(IP) 调用这次修改的单列 INT4 核，所以 RecordL2/IP 32×1 和旧 IVF INT4 record 本次确实变快；不能据“batch 分支 x86-only”推导 macOS record 完全不受影响。INT4 record n>1 则先返回转置+pair fallback，未走新大多列核。',
'普通 INT4 MIPS 32×32 通过 mips_euclidean_metric.cc 的 raw IP/L2 矩阵，因此承接大多列回退。IVF warm 基准覆盖的是单查询列扫描：本轮 24 项没有 >5% 回退，不能据此掩盖通用 many-to-many / MIPS 32×32 的回退，也不能外推所有 IVF 服务负载。','',
'## 7. 反汇编定位','',
'### INT4 大多列：实际内核变化，非仅噪声','',
'`disasm/{9819,final}_{16x16,32x16,32x32}_{L2,IP}.asm` 覆盖全部 12 项（dim 在运行时传入，相同形状两种维度共用函数）；适配器见 *_adapter_int4_32x32.asm。',
'- 以 32×16 L2 为例，旧列循环每个向量对/8维读取 1 个打包 query word，再做 8 次查表；新循环先把 query_nibbles 写入栈，再每对做 8 次 query byte 读取 + 8 次查表。额外的 7 次 query load 及展开写入增加访存成本。',
'- 新版 8 个 table-row 指针在该形状主要保留在通用寄存器中；实际可见问题是展开后的 query 字节数组落栈，不能笼统说“rows[8] 指针全部溢出”。',
'- 32×16 的列循环静态指令数虽然 38→31，但内存 load 数增加；全函数 105→166 条，栈局部空间 sub sp 2064→2192，直接 [sp] 访问指令 8→26（仅静态统计，不是动态事件数）。32×32 全函数 111→229、直接 [sp] 访问 8→43。',
'- 因此 x86 上“少位运算”获益不能直接外推到 Apple M3/Clang。两轮一致回退 + load/栈访问证据支持其为新内核结构导致。未采集硬件性能计数器，未把具体端口/缓存瓶颈当作已证明的事实。','',
'### FP16 IP 1×1 d128：整程序布局相关回退','',
'- 完整 sweep 两轮 1.342 / 1.325×9819：约 8.96→12.03 ns 和 8.849→11.729 ns，原始记录保留，未按“噪声”删除。',
'- warm dispatch 前 31 条指令（重定位地址归一化）一致，调用的 NEON FP16 IP 完整 114 条指令归一化一致；初始化冷路径仅存在链接地址/符号地址差异。见 disasm/unchanged_comparison.json、*_fp16_*.normalized。',
'- 独立 50ms 采样窗口、各版本 10 进程交错验证：两个可执行文件 __text 地址/长度/SHA256 完全一致；d128 FINAL/9819='+f"{focus['128']['ratio']:.4f}"+'，d512='+f"{focus['512']['ratio']:.4f}"+'。见 results/fp16_focus_summary.json 和 fp16_focus_*.csv。',
'- 该证据支持整程序布局/调用热点影响，不是 FP16 算术或转置逻辑变化；没有进一步隔离具体指令缓存、分支预测或其他微架构原因。按交接要求，不为此添加对齐参数或改 FP16 内核。完整 sweep 的可复现回退仍是本轮结果的一部分。','',
'## 8. 最小调整建议与两平台结论','',
'建议后续修复仅在 ARM64 的 ComputePackedColumns 中让 Columns≥16 返回旧直接提取循环（原 Rows≤4 继续旧循环）；保留 ARM64 单列查询表行提升、Columns=2/4/8 的新循环以及 x86 全部最终优化。这样直接针对 12 个大多列项及 MIPS 32×32，同时保留已测到的单列/IVF收益。**这只是建议，本轮没有应用或验证这一调整**；实际改动仍需两平台重新跑正确性、兼容和两轮性能，尤其注意小形状布局变化。',
'Linux x86 的结果来自已校验交接包，并非本机重跑：511 正确性通过、200 fixtures；主要目标回退已解决，adapter/IVF 两轮 0 项 >5%，raw 仍有报告中已归因相同指令流的微形状布局项。',
'**综合状态：x86 交接结果良好，但本轮 macOS 性能验证未通过。不能宣称两平台无退化；应先调整 ARM64 大多列策略，再决定合入。**','',
'## 9. 证据入口','',
'- round1/、round2/：三组完整对比 CSV + 每版本每进程原始日志；两轮完整表见 PERFORMANCE_TABLES.md。',
'- results/：44 程序测试 XML/日志、旧索引读写、两轮摘要、FP16 隔离数据。',
'- parent_fixtures/：本次 parent 生成的 200 个旧索引；results/fixture_sha256.txt 为对应哈希。',
'- disasm/：INT4 全部相关形状、MIPS 适配器及 FP16 指令证据。',
'- buildinfo/：原始补丁、编译环境/参数/命令、基线二进制来源与哈希。',
'- local_reproduction/ 或根目录的构建/执行脚本保留本机路径；跨机复现时应从指定提交建立工作树并按实际 deps 路径重新配置，不能直接使用本机二进制/绝对路径。',
'']
(root/'MACOS_RESIDUAL_FINAL_REPORT_zh.md').write_text('\n'.join(lines))
table=['# macOS 两轮完整性能表','', '耗时单位：matrix/adapter 为 ns，IVF 为 µs；R1 / R2 为两轮各 3 个进程的中位数。完整 min/max 与三个基线的比值见 CSV。','']
for g in ['matrix','adapter','ivf']:
 table += [f'## {g}','', '| 类型 / 度量 / 形状或 record / dim | 955 R1 / R2 | 7abc R1 / R2 | 9819 R1 / R2 | FINAL R1 / R2 | FINAL/9819 R1 / R2 |','|---|---|---|---|---|---|']
 for a,b in zip(data['round1'][g],data['round2'][g]):
  label=' / '.join([a['type'],a['metric'],('record='+a['record']) if g=='ivf' else a['rows']+'×'+a['columns'],a['dim']])
  table.append('| '+label+' | '+' | '.join(f'{float(a[v]):.3f} / {float(b[v]):.3f}' for v in ['955','7abc','9819','final','final_vs_9819'])+' |')
 table.append('')
(root/'PERFORMANCE_TABLES.md').write_text('\n'.join(table))
