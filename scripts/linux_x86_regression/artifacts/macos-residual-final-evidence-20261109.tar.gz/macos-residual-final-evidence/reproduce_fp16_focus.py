"""Local diagnostic reproduction; requires this evidence root's source/ and build/."""
import csv, hashlib, json, shlex, statistics, struct, subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
c=next(x for x in json.loads((r/'build/compile_commands.json').read_text()) if x['file'].endswith('turbo_matrix_test.cc') and 'sanitized' not in x['command'])
overlay=r/'baseline_9819/turbo/distance';overlay.mkdir(parents=True,exist_ok=True)
(overlay/'matrix.h').write_bytes(subprocess.check_output(['git','show','9819c706:src/turbo/distance/matrix.h'],cwd=r/'source'))
commands={}
for v in ['9819','final']:
 a=shlex.split(c['command']);a[1:1]=['-include',str(r/'benchmark_qos.h')]
 if v=='9819':a[1:1]=['-I'+str(r/'baseline_9819')]
 obj=r/(v+'_fp16_focus.o');a[a.index('-c')+1]=str(r/'fp16_focus.cc');a[a.index('-o')+1]=str(obj);commands[v]=a
 subprocess.run(a,cwd=c['directory'],check=True)
 subprocess.run([a[0],'-isysroot',a[a.index('-isysroot')+1],str(obj),str(r/'build/lib/libzvec_turbo.a'),str(r/'build/lib/libzvec_ailego.a'),'-o',str(r/'bin'/f'{v}_fp16_focus')],check=True)
(r/'buildinfo/fp16_focus_compile.json').write_text(json.dumps(commands,indent=2))
values={}
for i in range(10):
 for v in (['9819','final'] if i%2==0 else ['final','9819']):
  text=subprocess.check_output(['/usr/sbin/taskpolicy','-a',str(r/'bin'/f'{v}_fp16_focus')],cwd=r/'runtime',text=True)
  (r/'results'/f'fp16_focus_{v}_{i}.csv').write_text(text)
  for row in csv.DictReader(text.splitlines()):values.setdefault(row['dim'],{}).setdefault(v,[]).append(float(row['ns_per_matrix']))
summary={d:{'samples':x,'9819_median':statistics.median(x['9819']),'final_median':statistics.median(x['final']),'ratio':statistics.median(x['final'])/statistics.median(x['9819'])} for d,x in values.items()}
for v in ['9819','final']:
 b=(r/'bin'/f'{v}_fp16_focus').read_bytes();off=32
 for i in range(struct.unpack_from('<I',b,16)[0]):
  cmd,sz=struct.unpack_from('<2I',b,off)
  if cmd==0x19:
   for j in range(struct.unpack_from('<I',b,off+64)[0]):
    pos=off+72+j*80
    if b[pos:pos+16].split(b'\0')[0]==b'__text':
     addr,size,foff=struct.unpack_from('<QQI',b,pos+32);summary[v+'_text']={'address':hex(addr),'size':size,'sha256':hashlib.sha256(b[foff:foff+size]).hexdigest()}
  off+=sz
(r/'results/fp16_focus_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
