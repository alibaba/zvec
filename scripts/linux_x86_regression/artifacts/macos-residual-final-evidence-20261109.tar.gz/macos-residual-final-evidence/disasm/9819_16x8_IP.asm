00000001000c9cf4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c9cf4:     	stp	x22, x21, [sp, #-48]!
1000c9cf8:     	stp	x20, x19, [sp, #16]
1000c9cfc:     	stp	x29, x30, [sp, #32]
1000c9d00:     	add	x29, sp, #32
1000c9d04:     	sub	sp, sp, #528
1000c9d08:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0xc8>
1000c9d0c:     	ldr	x8, [x8, #392]
1000c9d10:     	ldr	x8, [x8]
1000c9d14:     	stur	x8, [x29, #-40]
1000c9d18:     	movi.2d	v0, #0000000000000000
1000c9d1c:     	stp	q0, q0, [sp, #480]
1000c9d20:     	lsl	x8, x2, #2
1000c9d24:     	stp	q0, q0, [sp, #448]
1000c9d28:     	stp	q0, q0, [sp, #416]
1000c9d2c:     	stp	q0, q0, [sp, #384]
1000c9d30:     	stp	q0, q0, [sp, #352]
1000c9d34:     	stp	q0, q0, [sp, #320]
1000c9d38:     	stp	q0, q0, [sp, #288]
1000c9d3c:     	stp	q0, q0, [sp, #256]
1000c9d40:     	stp	q0, q0, [sp, #224]
1000c9d44:     	stp	q0, q0, [sp, #192]
1000c9d48:     	stp	q0, q0, [sp, #160]
1000c9d4c:     	stp	q0, q0, [sp, #128]
1000c9d50:     	stp	q0, q0, [sp, #96]
1000c9d54:     	stp	q0, q0, [sp, #64]
1000c9d58:     	stp	q0, q0, [sp, #32]
1000c9d5c:     	stp	q0, q0, [sp]
1000c9d60:     	ands	x8, x8, #0xfffffffffffffff8
1000c9d64:     	b.eq	0x1000c9e7c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x188>
1000c9d68:     	add	x8, x1, x8
1000c9d6c:     	adrp	x9, 0x100166000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x124>
1000c9d70:     	add	x9, x9, #1500
1000c9d74:     	mov	x10, #0
1000c9d78:     	mov	x11, sp
1000c9d7c:     	mov	x12, #0
1000c9d80:     	ldr	w5, [x0, x10, lsl #2]
1000c9d84:     	lsl	w13, w5, #4
1000c9d88:     	and	x13, x13, #0xf0
1000c9d8c:     	and	x14, x5, #0xf0
1000c9d90:     	lsr	x15, x5, #4
1000c9d94:     	and	x15, x15, #0xf0
1000c9d98:     	lsr	x16, x5, #8
1000c9d9c:     	and	x16, x16, #0xf0
1000c9da0:     	lsr	x17, x5, #12
1000c9da4:     	and	x17, x17, #0xf0
1000c9da8:     	lsr	x2, x5, #16
1000c9dac:     	and	x2, x2, #0xf0
1000c9db0:     	lsr	x4, x5, #20
1000c9db4:     	and	x4, x4, #0xf0
1000c9db8:     	lsr	x5, x5, #24
1000c9dbc:     	and	x5, x5, #0xf0
1000c9dc0:     	mov	x6, x11
1000c9dc4:     	ldr	w7, [x1, x12]
1000c9dc8:     	and	x19, x7, #0xf
1000c9dcc:     	orr	x19, x13, x19
1000c9dd0:     	ldrsb	w19, [x9, x19]
1000c9dd4:     	ubfx	x20, x7, #4, #4
1000c9dd8:     	orr	x20, x14, x20
1000c9ddc:     	ldrsb	w20, [x9, x20]
1000c9de0:     	ubfx	x21, x7, #8, #4
1000c9de4:     	orr	x21, x15, x21
1000c9de8:     	ldrsb	w21, [x9, x21]
1000c9dec:     	add	w19, w19, w20
1000c9df0:     	add	w19, w19, w21
1000c9df4:     	ubfx	x20, x7, #12, #4
1000c9df8:     	orr	x20, x16, x20
1000c9dfc:     	ldrsb	w20, [x9, x20]
1000c9e00:     	ubfx	x21, x7, #16, #4
1000c9e04:     	orr	x21, x17, x21
1000c9e08:     	ldrsb	w21, [x9, x21]
1000c9e0c:     	add	w19, w19, w20
1000c9e10:     	add	w19, w19, w21
1000c9e14:     	ubfx	x20, x7, #20, #4
1000c9e18:     	orr	x20, x2, x20
1000c9e1c:     	ldrsb	w20, [x9, x20]
1000c9e20:     	ubfx	x21, x7, #24, #4
1000c9e24:     	orr	x21, x4, x21
1000c9e28:     	ldrsb	w21, [x9, x21]
1000c9e2c:     	add	w19, w19, w20
1000c9e30:     	add	w19, w19, w21
1000c9e34:     	orr	x7, x5, x7, lsr #28
1000c9e38:     	ldrsb	w7, [x9, x7]
1000c9e3c:     	add	w7, w19, w7
1000c9e40:     	scvtf	s0, w7
1000c9e44:     	ldr	s1, [x6]
1000c9e48:     	fadd	s0, s1, s0
1000c9e4c:     	str	s0, [x6], #64
1000c9e50:     	add	x12, x12, #4
1000c9e54:     	cmp	x12, #32
1000c9e58:     	b.ne	0x1000c9dc4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c9e5c:     	add	x10, x10, #1
1000c9e60:     	add	x11, x11, #4
1000c9e64:     	cmp	x10, #16
1000c9e68:     	b.ne	0x1000c9d7c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x88>
1000c9e6c:     	add	x0, x0, #64
1000c9e70:     	add	x1, x1, #32
1000c9e74:     	cmp	x1, x8
1000c9e78:     	b.ne	0x1000c9d74 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x80>
1000c9e7c:     	mov	x1, sp
1000c9e80:     	mov	x0, x3
1000c9e84:     	mov	w2, #512
1000c9e88:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000c9e8c:     	ldur	x8, [x29, #-40]
1000c9e90:     	adrp	x9, 0x100168000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x250>
1000c9e94:     	ldr	x9, [x9, #392]
1000c9e98:     	ldr	x9, [x9]
1000c9e9c:     	cmp	x9, x8
1000c9ea0:     	b.ne	0x1000c9eb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c4>
1000c9ea4:     	add	sp, sp, #528
1000c9ea8:     	ldp	x29, x30, [sp, #32]
1000c9eac:     	ldp	x20, x19, [sp, #16]
1000c9eb0:     	ldp	x22, x21, [sp], #48
1000c9eb4:     	ret
1000c9eb8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

