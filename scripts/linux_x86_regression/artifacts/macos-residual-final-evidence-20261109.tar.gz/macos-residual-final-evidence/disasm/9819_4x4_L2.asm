00000001000bb548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bb548:     	sub	sp, sp, #352
1000bb54c:     	stp	x28, x27, [sp, #256]
1000bb550:     	stp	x26, x25, [sp, #272]
1000bb554:     	stp	x24, x23, [sp, #288]
1000bb558:     	stp	x22, x21, [sp, #304]
1000bb55c:     	stp	x20, x19, [sp, #320]
1000bb560:     	stp	x29, x30, [sp, #336]
1000bb564:     	add	x29, sp, #336
1000bb568:     	str	x3, [sp]
1000bb56c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2d8>
1000bb570:     	ldr	x8, [x8, #392]
1000bb574:     	ldr	x8, [x8]
1000bb578:     	stur	x8, [x29, #-96]
1000bb57c:     	movi.2d	v0, #0000000000000000
1000bb580:     	stp	q0, q0, [x29, #-128]
1000bb584:     	lsl	x8, x2, #1
1000bb588:     	stp	q0, q0, [x29, #-160]
1000bb58c:     	ands	x8, x8, #0xfffffffffffffffc
1000bb590:     	b.eq	0x1000bb8b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bb594:     	add	x8, x1, x8
1000bb598:     	str	x8, [sp, #8]
1000bb59c:     	sub	x8, x29, #160
1000bb5a0:     	add	x27, x8, #32
1000bb5a4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000bb5a8:     	add	x11, x11, #220
1000bb5ac:     	mov	x12, #0
1000bb5b0:     	ldp	w8, w9, [x1]
1000bb5b4:     	ubfx	x10, x8, #4, #4
1000bb5b8:     	str	x10, [sp, #168]
1000bb5bc:     	ubfx	x10, x8, #8, #4
1000bb5c0:     	str	x10, [sp, #160]
1000bb5c4:     	and	x10, x8, #0xf
1000bb5c8:     	str	x10, [sp, #152]
1000bb5cc:     	ubfx	x10, x8, #12, #4
1000bb5d0:     	str	x10, [sp, #144]
1000bb5d4:     	ubfx	x10, x8, #16, #4
1000bb5d8:     	str	x10, [sp, #136]
1000bb5dc:     	ubfx	x10, x8, #20, #4
1000bb5e0:     	str	x10, [sp, #128]
1000bb5e4:     	ubfx	x10, x8, #24, #4
1000bb5e8:     	lsr	x8, x8, #28
1000bb5ec:     	stp	x8, x10, [sp, #112]
1000bb5f0:     	and	x10, x9, #0xf
1000bb5f4:     	ubfx	x8, x9, #4, #4
1000bb5f8:     	stp	x8, x10, [sp, #96]
1000bb5fc:     	ubfx	x10, x9, #8, #4
1000bb600:     	ubfx	x8, x9, #12, #4
1000bb604:     	stp	x8, x10, [sp, #80]
1000bb608:     	ubfx	x10, x9, #16, #4
1000bb60c:     	ubfx	x8, x9, #20, #4
1000bb610:     	stp	x8, x10, [sp, #64]
1000bb614:     	ubfx	x10, x9, #24, #4
1000bb618:     	lsr	x8, x9, #28
1000bb61c:     	stp	x8, x10, [sp, #48]
1000bb620:     	ldp	w9, w17, [x1, #8]
1000bb624:     	and	x10, x9, #0xf
1000bb628:     	ubfx	x8, x9, #4, #4
1000bb62c:     	stp	x8, x10, [sp, #32]
1000bb630:     	ubfx	x8, x9, #8, #4
1000bb634:     	stp	x1, x8, [sp, #16]
1000bb638:     	ubfx	x28, x9, #12, #4
1000bb63c:     	ubfx	x30, x9, #16, #4
1000bb640:     	ubfx	x8, x9, #20, #4
1000bb644:     	ubfx	x3, x9, #24, #4
1000bb648:     	lsr	x9, x9, #28
1000bb64c:     	and	x1, x17, #0xf
1000bb650:     	ubfx	x10, x17, #4, #4
1000bb654:     	ubfx	x13, x17, #8, #4
1000bb658:     	ubfx	x26, x17, #12, #4
1000bb65c:     	ubfx	x14, x17, #16, #4
1000bb660:     	ubfx	x15, x17, #20, #4
1000bb664:     	ubfx	x16, x17, #24, #4
1000bb668:     	lsr	x17, x17, #28
1000bb66c:     	ldr	w21, [x0, x12]
1000bb670:     	lsl	w2, w21, #4
1000bb674:     	and	x2, x2, #0xf0
1000bb678:     	ldp	x4, x19, [sp, #152]
1000bb67c:     	orr	x4, x2, x4
1000bb680:     	ldrb	w6, [x11, x4]
1000bb684:     	and	x4, x21, #0xf0
1000bb688:     	ldr	x5, [sp, #168]
1000bb68c:     	orr	x5, x4, x5
1000bb690:     	ldrb	w7, [x11, x5]
1000bb694:     	lsr	x5, x21, #4
1000bb698:     	and	x5, x5, #0xf0
1000bb69c:     	orr	x19, x5, x19
1000bb6a0:     	ldrb	w19, [x11, x19]
1000bb6a4:     	add	w6, w6, w7
1000bb6a8:     	add	w19, w6, w19
1000bb6ac:     	lsr	x6, x21, #8
1000bb6b0:     	and	x6, x6, #0xf0
1000bb6b4:     	ldp	x22, x7, [sp, #136]
1000bb6b8:     	orr	x7, x6, x7
1000bb6bc:     	ldrb	w20, [x11, x7]
1000bb6c0:     	lsr	x7, x21, #12
1000bb6c4:     	and	x7, x7, #0xf0
1000bb6c8:     	orr	x22, x7, x22
1000bb6cc:     	ldrb	w22, [x11, x22]
1000bb6d0:     	add	w19, w19, w20
1000bb6d4:     	add	w22, w19, w22
1000bb6d8:     	lsr	x19, x21, #16
1000bb6dc:     	and	x19, x19, #0xf0
1000bb6e0:     	ldp	x24, x20, [sp, #120]
1000bb6e4:     	orr	x20, x19, x20
1000bb6e8:     	ldrb	w23, [x11, x20]
1000bb6ec:     	lsr	x20, x21, #20
1000bb6f0:     	and	x20, x20, #0xf0
1000bb6f4:     	orr	x24, x20, x24
1000bb6f8:     	ldrb	w24, [x11, x24]
1000bb6fc:     	add	w22, w22, w23
1000bb700:     	add	w22, w22, w24
1000bb704:     	lsr	x21, x21, #24
1000bb708:     	and	x21, x21, #0xf0
1000bb70c:     	ldr	x23, [sp, #112]
1000bb710:     	orr	x23, x21, x23
1000bb714:     	ldrb	w23, [x11, x23]
1000bb718:     	add	w22, w22, w23
1000bb71c:     	scvtf	s0, w22
1000bb720:     	ldp	x23, x22, [sp, #96]
1000bb724:     	orr	x22, x2, x22
1000bb728:     	ldrb	w22, [x11, x22]
1000bb72c:     	orr	x23, x4, x23
1000bb730:     	ldrb	w23, [x11, x23]
1000bb734:     	ldr	x24, [sp, #88]
1000bb738:     	orr	x24, x5, x24
1000bb73c:     	ldrb	w24, [x11, x24]
1000bb740:     	add	w22, w22, w23
1000bb744:     	add	w22, w22, w24
1000bb748:     	ldp	x24, x23, [sp, #72]
1000bb74c:     	orr	x23, x6, x23
1000bb750:     	ldrb	w23, [x11, x23]
1000bb754:     	orr	x24, x7, x24
1000bb758:     	ldrb	w24, [x11, x24]
1000bb75c:     	ldr	x25, [sp, #64]
1000bb760:     	orr	x25, x19, x25
1000bb764:     	ldrb	w25, [x11, x25]
1000bb768:     	add	w22, w22, w23
1000bb76c:     	add	w22, w22, w24
1000bb770:     	ldr	x23, [sp, #56]
1000bb774:     	orr	x23, x20, x23
1000bb778:     	ldrb	w23, [x11, x23]
1000bb77c:     	add	w22, w22, w25
1000bb780:     	add	w22, w22, w23
1000bb784:     	ldr	x23, [sp, #48]
1000bb788:     	orr	x23, x21, x23
1000bb78c:     	ldrb	w23, [x11, x23]
1000bb790:     	add	w22, w22, w23
1000bb794:     	scvtf	s1, w22
1000bb798:     	ldp	x23, x22, [sp, #32]
1000bb79c:     	orr	x22, x2, x22
1000bb7a0:     	ldrb	w22, [x11, x22]
1000bb7a4:     	orr	x23, x4, x23
1000bb7a8:     	ldrb	w23, [x11, x23]
1000bb7ac:     	ldr	x24, [sp, #24]
1000bb7b0:     	orr	x24, x5, x24
1000bb7b4:     	ldrb	w24, [x11, x24]
1000bb7b8:     	add	w22, w22, w23
1000bb7bc:     	add	w22, w22, w24
1000bb7c0:     	orr	x23, x6, x28
1000bb7c4:     	ldrb	w23, [x11, x23]
1000bb7c8:     	orr	x24, x7, x30
1000bb7cc:     	ldrb	w24, [x11, x24]
1000bb7d0:     	orr	x25, x19, x8
1000bb7d4:     	ldrb	w25, [x11, x25]
1000bb7d8:     	add	w22, w22, w23
1000bb7dc:     	orr	x23, x20, x3
1000bb7e0:     	ldrb	w23, [x11, x23]
1000bb7e4:     	add	w22, w22, w24
1000bb7e8:     	add	w22, w22, w25
1000bb7ec:     	add	w22, w22, w23
1000bb7f0:     	orr	x23, x21, x9
1000bb7f4:     	ldrb	w23, [x11, x23]
1000bb7f8:     	add	w22, w22, w23
1000bb7fc:     	scvtf	s2, w22
1000bb800:     	orr	x2, x2, x1
1000bb804:     	ldrb	w2, [x11, x2]
1000bb808:     	orr	x4, x4, x10
1000bb80c:     	ldrb	w4, [x11, x4]
1000bb810:     	orr	x5, x5, x13
1000bb814:     	ldrb	w5, [x11, x5]
1000bb818:     	add	w2, w2, w4
1000bb81c:     	add	w2, w2, w5
1000bb820:     	orr	x4, x6, x26
1000bb824:     	ldrb	w4, [x11, x4]
1000bb828:     	orr	x5, x7, x14
1000bb82c:     	ldrb	w5, [x11, x5]
1000bb830:     	add	w2, w2, w4
1000bb834:     	orr	x4, x19, x15
1000bb838:     	ldrb	w4, [x11, x4]
1000bb83c:     	add	w2, w2, w5
1000bb840:     	orr	x5, x20, x16
1000bb844:     	ldrb	w5, [x11, x5]
1000bb848:     	add	w2, w2, w4
1000bb84c:     	add	w2, w2, w5
1000bb850:     	orr	x4, x21, x17
1000bb854:     	ldrb	w4, [x11, x4]
1000bb858:     	add	w2, w2, w4
1000bb85c:     	sub	x4, x29, #160
1000bb860:     	scvtf	s3, w2
1000bb864:     	add	x2, x27, x12
1000bb868:     	ldur	s4, [x2, #-16]
1000bb86c:     	fadd	s1, s4, s1
1000bb870:     	stur	s1, [x2, #-16]
1000bb874:     	ldr	s1, [x2]
1000bb878:     	fadd	s1, s1, s2
1000bb87c:     	str	s1, [x2]
1000bb880:     	ldr	s1, [x2, #16]
1000bb884:     	fadd	s1, s1, s3
1000bb888:     	ldr	s2, [x4, x12]
1000bb88c:     	str	s1, [x2, #16]
1000bb890:     	fadd	s0, s2, s0
1000bb894:     	str	s0, [x4, x12]
1000bb898:     	add	x12, x12, #4
1000bb89c:     	cmp	x12, #16
1000bb8a0:     	b.ne	0x1000bb66c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bb8a4:     	add	x0, x0, #16
1000bb8a8:     	ldp	x8, x1, [sp, #8]
1000bb8ac:     	add	x1, x1, #16
1000bb8b0:     	cmp	x1, x8
1000bb8b4:     	b.ne	0x1000bb5ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bb8b8:     	ldp	q0, q1, [x29, #-160]
1000bb8bc:     	ldr	x8, [sp]
1000bb8c0:     	stp	q0, q1, [x8]
1000bb8c4:     	ldp	q0, q1, [x29, #-128]
1000bb8c8:     	stp	q0, q1, [x8, #32]
1000bb8cc:     	ldur	x8, [x29, #-96]
1000bb8d0:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x184>
1000bb8d4:     	ldr	x9, [x9, #392]
1000bb8d8:     	ldr	x9, [x9]
1000bb8dc:     	cmp	x9, x8
1000bb8e0:     	b.ne	0x1000bb904 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bb8e4:     	ldp	x29, x30, [sp, #336]
1000bb8e8:     	ldp	x20, x19, [sp, #320]
1000bb8ec:     	ldp	x22, x21, [sp, #304]
1000bb8f0:     	ldp	x24, x23, [sp, #288]
1000bb8f4:     	ldp	x26, x25, [sp, #272]
1000bb8f8:     	ldp	x28, x27, [sp, #256]
1000bb8fc:     	add	sp, sp, #352
1000bb900:     	ret
1000bb904:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

