00000001000d9c64 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9c64:     	stp	x28, x27, [sp, #-80]!
1000d9c68:     	stp	x24, x23, [sp, #16]
1000d9c6c:     	stp	x22, x21, [sp, #32]
1000d9c70:     	stp	x20, x19, [sp, #48]
1000d9c74:     	stp	x29, x30, [sp, #64]
1000d9c78:     	add	x29, sp, #64
1000d9c7c:     	mov	w9, #4368
1000d9c80:     	adrp	x16, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x268>
1000d9c84:     	ldr	x16, [x16, #304]
1000d9c88:     	blr	x16
1000d9c8c:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9c90:     	sub	sp, sp, #272
1000d9c94:     	mov	x19, x3
1000d9c98:     	mov	x20, x1
1000d9c9c:     	mov	x21, x0
1000d9ca0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d9ca4:     	ldr	x8, [x8, #392]
1000d9ca8:     	ldr	x8, [x8]
1000d9cac:     	stur	x8, [x29, #-72]
1000d9cb0:     	lsl	x8, x2, #4
1000d9cb4:     	and	x22, x8, #0xffffffffffffffe0
1000d9cb8:     	add	x0, sp, #264
1000d9cbc:     	mov	w1, #4096
1000d9cc0:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9cc4:     	cbz	x22, 0x1000d9fac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x348>
1000d9cc8:     	add	x8, x20, x22
1000d9ccc:     	mov	w9, #252645135
1000d9cd0:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d9cd4:     	add	x10, x10, #1980
1000d9cd8:     	add	x11, sp, #8
1000d9cdc:     	mov	x12, #0
1000d9ce0:     	ldp	w13, w14, [x20]
1000d9ce4:     	and	w15, w13, w9
1000d9ce8:     	and	w13, w9, w13, lsr #4
1000d9cec:     	stp	w15, w13, [sp, #8]
1000d9cf0:     	and	w13, w14, w9
1000d9cf4:     	and	w14, w9, w14, lsr #4
1000d9cf8:     	stp	w13, w14, [sp, #16]
1000d9cfc:     	ldp	w13, w14, [x20, #8]
1000d9d00:     	and	w15, w13, w9
1000d9d04:     	and	w13, w9, w13, lsr #4
1000d9d08:     	stp	w15, w13, [sp, #24]
1000d9d0c:     	and	w13, w14, w9
1000d9d10:     	and	w14, w9, w14, lsr #4
1000d9d14:     	stp	w13, w14, [sp, #32]
1000d9d18:     	ldp	w13, w14, [x20, #16]
1000d9d1c:     	and	w15, w13, w9
1000d9d20:     	and	w13, w9, w13, lsr #4
1000d9d24:     	stp	w15, w13, [sp, #40]
1000d9d28:     	and	w13, w14, w9
1000d9d2c:     	and	w14, w9, w14, lsr #4
1000d9d30:     	stp	w13, w14, [sp, #48]
1000d9d34:     	ldp	w13, w14, [x20, #24]
1000d9d38:     	and	w15, w13, w9
1000d9d3c:     	and	w13, w9, w13, lsr #4
1000d9d40:     	stp	w15, w13, [sp, #56]
1000d9d44:     	and	w13, w14, w9
1000d9d48:     	and	w14, w9, w14, lsr #4
1000d9d4c:     	stp	w13, w14, [sp, #64]
1000d9d50:     	ldp	w13, w14, [x20, #32]
1000d9d54:     	and	w15, w13, w9
1000d9d58:     	and	w13, w9, w13, lsr #4
1000d9d5c:     	stp	w15, w13, [sp, #72]
1000d9d60:     	and	w13, w14, w9
1000d9d64:     	and	w14, w9, w14, lsr #4
1000d9d68:     	stp	w13, w14, [sp, #80]
1000d9d6c:     	ldp	w13, w14, [x20, #40]
1000d9d70:     	and	w15, w13, w9
1000d9d74:     	and	w13, w9, w13, lsr #4
1000d9d78:     	stp	w15, w13, [sp, #88]
1000d9d7c:     	and	w13, w14, w9
1000d9d80:     	and	w14, w9, w14, lsr #4
1000d9d84:     	stp	w13, w14, [sp, #96]
1000d9d88:     	ldp	w13, w14, [x20, #48]
1000d9d8c:     	and	w15, w13, w9
1000d9d90:     	and	w13, w9, w13, lsr #4
1000d9d94:     	stp	w15, w13, [sp, #104]
1000d9d98:     	and	w13, w14, w9
1000d9d9c:     	and	w14, w9, w14, lsr #4
1000d9da0:     	stp	w13, w14, [sp, #112]
1000d9da4:     	ldp	w13, w14, [x20, #56]
1000d9da8:     	and	w15, w13, w9
1000d9dac:     	and	w13, w9, w13, lsr #4
1000d9db0:     	stp	w15, w13, [sp, #120]
1000d9db4:     	and	w13, w14, w9
1000d9db8:     	and	w14, w9, w14, lsr #4
1000d9dbc:     	stp	w13, w14, [sp, #128]
1000d9dc0:     	ldp	w13, w14, [x20, #64]
1000d9dc4:     	and	w15, w13, w9
1000d9dc8:     	and	w13, w9, w13, lsr #4
1000d9dcc:     	stp	w15, w13, [sp, #136]
1000d9dd0:     	and	w13, w14, w9
1000d9dd4:     	and	w14, w9, w14, lsr #4
1000d9dd8:     	stp	w13, w14, [sp, #144]
1000d9ddc:     	ldp	w13, w14, [x20, #72]
1000d9de0:     	and	w15, w13, w9
1000d9de4:     	and	w13, w9, w13, lsr #4
1000d9de8:     	stp	w15, w13, [sp, #152]
1000d9dec:     	and	w13, w14, w9
1000d9df0:     	and	w14, w9, w14, lsr #4
1000d9df4:     	stp	w13, w14, [sp, #160]
1000d9df8:     	ldp	w13, w14, [x20, #80]
1000d9dfc:     	and	w15, w13, w9
1000d9e00:     	and	w13, w9, w13, lsr #4
1000d9e04:     	stp	w15, w13, [sp, #168]
1000d9e08:     	and	w13, w14, w9
1000d9e0c:     	and	w14, w9, w14, lsr #4
1000d9e10:     	stp	w13, w14, [sp, #176]
1000d9e14:     	ldp	w13, w14, [x20, #88]
1000d9e18:     	and	w15, w13, w9
1000d9e1c:     	and	w13, w9, w13, lsr #4
1000d9e20:     	stp	w15, w13, [sp, #184]
1000d9e24:     	and	w13, w14, w9
1000d9e28:     	and	w14, w9, w14, lsr #4
1000d9e2c:     	stp	w13, w14, [sp, #192]
1000d9e30:     	ldp	w13, w14, [x20, #96]
1000d9e34:     	and	w15, w13, w9
1000d9e38:     	and	w13, w9, w13, lsr #4
1000d9e3c:     	stp	w15, w13, [sp, #200]
1000d9e40:     	and	w13, w14, w9
1000d9e44:     	and	w14, w9, w14, lsr #4
1000d9e48:     	stp	w13, w14, [sp, #208]
1000d9e4c:     	ldp	w13, w14, [x20, #104]
1000d9e50:     	and	w15, w13, w9
1000d9e54:     	and	w13, w9, w13, lsr #4
1000d9e58:     	stp	w15, w13, [sp, #216]
1000d9e5c:     	and	w13, w14, w9
1000d9e60:     	and	w14, w9, w14, lsr #4
1000d9e64:     	stp	w13, w14, [sp, #224]
1000d9e68:     	ldp	w13, w14, [x20, #112]
1000d9e6c:     	and	w15, w13, w9
1000d9e70:     	and	w13, w9, w13, lsr #4
1000d9e74:     	stp	w15, w13, [sp, #232]
1000d9e78:     	and	w13, w14, w9
1000d9e7c:     	and	w14, w9, w14, lsr #4
1000d9e80:     	stp	w13, w14, [sp, #240]
1000d9e84:     	ldp	w13, w14, [x20, #120]
1000d9e88:     	and	w15, w13, w9
1000d9e8c:     	and	w13, w9, w13, lsr #4
1000d9e90:     	stp	w15, w13, [sp, #248]
1000d9e94:     	and	w13, w14, w9
1000d9e98:     	and	w14, w9, w14, lsr #4
1000d9e9c:     	str	w13, [sp, #256]
1000d9ea0:     	str	w14, [sp, #260]
1000d9ea4:     	add	x13, sp, #264
1000d9ea8:     	mov	x14, #0
1000d9eac:     	ldr	w4, [x21, x12, lsl #2]
1000d9eb0:     	lsl	w15, w4, #4
1000d9eb4:     	and	x15, x15, #0xf0
1000d9eb8:     	add	x15, x10, x15
1000d9ebc:     	and	x16, x4, #0xf0
1000d9ec0:     	add	x16, x10, x16
1000d9ec4:     	lsr	x17, x4, #4
1000d9ec8:     	and	x17, x17, #0xf0
1000d9ecc:     	add	x17, x10, x17
1000d9ed0:     	lsr	x0, x4, #8
1000d9ed4:     	and	x0, x0, #0xf0
1000d9ed8:     	add	x0, x10, x0
1000d9edc:     	lsr	x1, x4, #12
1000d9ee0:     	and	x1, x1, #0xf0
1000d9ee4:     	add	x1, x10, x1
1000d9ee8:     	lsr	x2, x4, #16
1000d9eec:     	and	x2, x2, #0xf0
1000d9ef0:     	add	x2, x10, x2
1000d9ef4:     	lsr	x3, x4, #20
1000d9ef8:     	and	x3, x3, #0xf0
1000d9efc:     	add	x3, x10, x3
1000d9f00:     	lsr	x4, x4, #24
1000d9f04:     	and	x4, x4, #0xf0
1000d9f08:     	add	x4, x10, x4
1000d9f0c:     	mov	x5, x13
1000d9f10:     	add	x6, x11, x14
1000d9f14:     	ldrb	w7, [x6]
1000d9f18:     	ldrsb	w7, [x15, x7]
1000d9f1c:     	ldrb	w22, [x6, #1]
1000d9f20:     	ldrsb	w22, [x17, x22]
1000d9f24:     	ldrb	w23, [x6, #2]
1000d9f28:     	ldrsb	w23, [x1, x23]
1000d9f2c:     	add	w7, w7, w22
1000d9f30:     	add	w7, w7, w23
1000d9f34:     	ldrb	w22, [x6, #3]
1000d9f38:     	ldrsb	w22, [x3, x22]
1000d9f3c:     	ldrb	w23, [x6, #4]
1000d9f40:     	ldrsb	w23, [x16, x23]
1000d9f44:     	ldrb	w24, [x6, #5]
1000d9f48:     	ldrsb	w24, [x0, x24]
1000d9f4c:     	add	w7, w7, w22
1000d9f50:     	add	w7, w7, w23
1000d9f54:     	ldrb	w22, [x6, #6]
1000d9f58:     	ldrsb	w22, [x2, x22]
1000d9f5c:     	add	w7, w7, w24
1000d9f60:     	add	w7, w7, w22
1000d9f64:     	ldrb	w6, [x6, #7]
1000d9f68:     	ldrsb	w6, [x4, x6]
1000d9f6c:     	add	w6, w7, w6
1000d9f70:     	scvtf	s0, w6
1000d9f74:     	ldr	s1, [x5]
1000d9f78:     	fadd	s0, s1, s0
1000d9f7c:     	str	s0, [x5], #128
1000d9f80:     	add	x14, x14, #8
1000d9f84:     	cmp	x14, #256
1000d9f88:     	b.ne	0x1000d9f10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d9f8c:     	add	x12, x12, #1
1000d9f90:     	add	x13, x13, #4
1000d9f94:     	cmp	x12, #32
1000d9f98:     	b.ne	0x1000d9ea8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000d9f9c:     	add	x21, x21, #128
1000d9fa0:     	add	x20, x20, #128
1000d9fa4:     	cmp	x20, x8
1000d9fa8:     	b.ne	0x1000d9cdc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x78>
1000d9fac:     	add	x1, sp, #264
1000d9fb0:     	mov	x0, x19
1000d9fb4:     	mov	w2, #4096
1000d9fb8:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9fbc:     	ldur	x8, [x29, #-72]
1000d9fc0:     	adrp	x9, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x1a0>
1000d9fc4:     	ldr	x9, [x9, #392]
1000d9fc8:     	ldr	x9, [x9]
1000d9fcc:     	cmp	x9, x8
1000d9fd0:     	b.ne	0x1000d9ff4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x390>
1000d9fd4:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9fd8:     	add	sp, sp, #272
1000d9fdc:     	ldp	x29, x30, [sp, #64]
1000d9fe0:     	ldp	x20, x19, [sp, #48]
1000d9fe4:     	ldp	x22, x21, [sp, #32]
1000d9fe8:     	ldp	x24, x23, [sp, #16]
1000d9fec:     	ldp	x28, x27, [sp], #80
1000d9ff0:     	ret
1000d9ff4:     	bl	0x100163694 <_strcmp+0x100163694>
