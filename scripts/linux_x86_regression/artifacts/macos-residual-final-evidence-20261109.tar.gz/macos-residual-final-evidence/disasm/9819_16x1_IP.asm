00000001000c4584 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c4584:     	stp	x22, x21, [sp, #-32]!
1000c4588:     	stp	x20, x19, [sp, #16]
1000c458c:     	movi.2d	v0, #0000000000000000
1000c4590:     	stp	q0, q0, [x3, #32]
1000c4594:     	stp	q0, q0, [x3]
1000c4598:     	cmp	x2, #8
1000c459c:     	b.hs	0x1000c45a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c45a0:     	mov	x8, #0
1000c45a4:     	b	0x1000c46b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c45a8:     	mov	x8, #0
1000c45ac:     	mov	w14, #8
1000c45b0:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b4>
1000c45b4:     	add	x9, x9, #1500
1000c45b8:     	mov	x10, x0
1000c45bc:     	mov	x11, #0
1000c45c0:     	lsr	x8, x8, #1
1000c45c4:     	mul	x8, x8, x4
1000c45c8:     	ldr	w6, [x1, x8]
1000c45cc:     	ubfx	x12, x6, #4, #4
1000c45d0:     	ubfx	x13, x6, #8, #4
1000c45d4:     	mov	x8, x14
1000c45d8:     	ubfx	x14, x6, #12, #4
1000c45dc:     	and	x15, x6, #0xf
1000c45e0:     	ubfx	x16, x6, #16, #4
1000c45e4:     	ubfx	x17, x6, #20, #4
1000c45e8:     	ubfx	x5, x6, #24, #4
1000c45ec:     	lsr	x6, x6, #28
1000c45f0:     	ldr	w7, [x10, x11]
1000c45f4:     	lsl	w19, w7, #4
1000c45f8:     	and	x19, x19, #0xf0
1000c45fc:     	orr	x19, x19, x15
1000c4600:     	ldrsb	w19, [x9, x19]
1000c4604:     	and	x20, x7, #0xf0
1000c4608:     	orr	x20, x20, x12
1000c460c:     	ldrsb	w20, [x9, x20]
1000c4610:     	lsr	x21, x7, #4
1000c4614:     	and	x21, x21, #0xf0
1000c4618:     	orr	x21, x21, x13
1000c461c:     	ldrsb	w21, [x9, x21]
1000c4620:     	lsr	x22, x7, #8
1000c4624:     	and	x22, x22, #0xf0
1000c4628:     	orr	x22, x22, x14
1000c462c:     	ldrsb	w22, [x9, x22]
1000c4630:     	add	w19, w19, w20
1000c4634:     	add	w19, w19, w21
1000c4638:     	lsr	x20, x7, #12
1000c463c:     	and	x20, x20, #0xf0
1000c4640:     	orr	x20, x20, x16
1000c4644:     	ldrsb	w20, [x9, x20]
1000c4648:     	lsr	x21, x7, #16
1000c464c:     	and	x21, x21, #0xf0
1000c4650:     	orr	x21, x21, x17
1000c4654:     	ldrsb	w21, [x9, x21]
1000c4658:     	add	w19, w19, w22
1000c465c:     	add	w19, w19, w20
1000c4660:     	lsr	x20, x7, #20
1000c4664:     	and	x20, x20, #0xf0
1000c4668:     	orr	x20, x20, x5
1000c466c:     	ldrsb	w20, [x9, x20]
1000c4670:     	lsr	x7, x7, #24
1000c4674:     	and	x7, x7, #0xf0
1000c4678:     	orr	x7, x7, x6
1000c467c:     	ldrsb	w7, [x9, x7]
1000c4680:     	add	w19, w19, w21
1000c4684:     	add	w19, w19, w20
1000c4688:     	add	w7, w19, w7
1000c468c:     	scvtf	s0, w7
1000c4690:     	ldr	s1, [x3, x11]
1000c4694:     	fadd	s0, s1, s0
1000c4698:     	str	s0, [x3, x11]
1000c469c:     	add	x11, x11, #4
1000c46a0:     	cmp	x11, #64
1000c46a4:     	b.ne	0x1000c45f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x6c>
1000c46a8:     	add	x14, x8, #8
1000c46ac:     	add	x10, x10, #64
1000c46b0:     	cmp	x14, x2
1000c46b4:     	b.ls	0x1000c45bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c46b8:     	cmp	x8, x2
1000c46bc:     	b.hs	0x1000c4974 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000c46c0:     	lsl	x9, x4, #2
1000c46c4:     	lsl	w10, w8, #2
1000c46c8:     	mov	w11, #-16
1000c46cc:     	lsr	x13, x8, #3
1000c46d0:     	mul	x12, x9, x13
1000c46d4:     	ubfx	x14, x8, #1, #2
1000c46d8:     	orr	x12, x12, x14
1000c46dc:     	ldrb	w15, [x1, x12]
1000c46e0:     	and	w12, w10, #0x4
1000c46e4:     	lsr	w15, w15, w12
1000c46e8:     	and	w16, w15, #0xf
1000c46ec:     	cmp	w16, #8
1000c46f0:     	csel	w16, wzr, w11, lo
1000c46f4:     	bfi	x14, x13, #6, #58
1000c46f8:     	add	x13, x0, x14
1000c46fc:     	ldrb	w14, [x13]
1000c4700:     	lsr	w14, w14, w12
1000c4704:     	bfxil	w16, w15, #0, #4
1000c4708:     	and	w15, w14, #0xf
1000c470c:     	cmp	w15, #8
1000c4710:     	csel	w15, wzr, w11, lo
1000c4714:     	bfxil	w15, w14, #0, #4
1000c4718:     	scvtf	s0, w16
1000c471c:     	scvtf	s1, w15
1000c4720:     	ldp	s2, s3, [x3]
1000c4724:     	fmsub	s1, s1, s0, s2
1000c4728:     	str	s1, [x3]
1000c472c:     	ldrb	w14, [x13, #4]
1000c4730:     	lsr	w14, w14, w12
1000c4734:     	and	w15, w14, #0xf
1000c4738:     	cmp	w15, #8
1000c473c:     	csel	w15, wzr, w11, lo
1000c4740:     	bfxil	w15, w14, #0, #4
1000c4744:     	scvtf	s1, w15
1000c4748:     	fmsub	s1, s1, s0, s3
1000c474c:     	str	s1, [x3, #4]
1000c4750:     	ldrb	w14, [x13, #8]
1000c4754:     	lsr	w14, w14, w12
1000c4758:     	and	w15, w14, #0xf
1000c475c:     	cmp	w15, #8
1000c4760:     	csel	w15, wzr, w11, lo
1000c4764:     	bfxil	w15, w14, #0, #4
1000c4768:     	scvtf	s1, w15
1000c476c:     	ldp	s2, s3, [x3, #8]
1000c4770:     	fmsub	s1, s1, s0, s2
1000c4774:     	str	s1, [x3, #8]
1000c4778:     	ldrb	w14, [x13, #12]
1000c477c:     	lsr	w14, w14, w12
1000c4780:     	and	w15, w14, #0xf
1000c4784:     	cmp	w15, #8
1000c4788:     	csel	w15, wzr, w11, lo
1000c478c:     	bfxil	w15, w14, #0, #4
1000c4790:     	scvtf	s1, w15
1000c4794:     	fmsub	s1, s1, s0, s3
1000c4798:     	str	s1, [x3, #12]
1000c479c:     	ldrb	w14, [x13, #16]
1000c47a0:     	lsr	w14, w14, w12
1000c47a4:     	and	w15, w14, #0xf
1000c47a8:     	cmp	w15, #8
1000c47ac:     	csel	w15, wzr, w11, lo
1000c47b0:     	bfxil	w15, w14, #0, #4
1000c47b4:     	scvtf	s1, w15
1000c47b8:     	ldp	s2, s3, [x3, #16]
1000c47bc:     	fmsub	s1, s1, s0, s2
1000c47c0:     	str	s1, [x3, #16]
1000c47c4:     	ldrb	w14, [x13, #20]
1000c47c8:     	lsr	w14, w14, w12
1000c47cc:     	and	w15, w14, #0xf
1000c47d0:     	cmp	w15, #8
1000c47d4:     	csel	w15, wzr, w11, lo
1000c47d8:     	bfxil	w15, w14, #0, #4
1000c47dc:     	scvtf	s1, w15
1000c47e0:     	fmsub	s1, s1, s0, s3
1000c47e4:     	str	s1, [x3, #20]
1000c47e8:     	ldrb	w14, [x13, #24]
1000c47ec:     	lsr	w14, w14, w12
1000c47f0:     	and	w15, w14, #0xf
1000c47f4:     	cmp	w15, #8
1000c47f8:     	csel	w15, wzr, w11, lo
1000c47fc:     	bfxil	w15, w14, #0, #4
1000c4800:     	scvtf	s1, w15
1000c4804:     	ldp	s2, s3, [x3, #24]
1000c4808:     	fmsub	s1, s1, s0, s2
1000c480c:     	str	s1, [x3, #24]
1000c4810:     	ldrb	w14, [x13, #28]
1000c4814:     	lsr	w14, w14, w12
1000c4818:     	and	w15, w14, #0xf
1000c481c:     	cmp	w15, #8
1000c4820:     	csel	w15, wzr, w11, lo
1000c4824:     	bfxil	w15, w14, #0, #4
1000c4828:     	scvtf	s1, w15
1000c482c:     	fmsub	s1, s1, s0, s3
1000c4830:     	str	s1, [x3, #28]
1000c4834:     	ldrb	w14, [x13, #32]
1000c4838:     	lsr	w14, w14, w12
1000c483c:     	and	w15, w14, #0xf
1000c4840:     	cmp	w15, #8
1000c4844:     	csel	w15, wzr, w11, lo
1000c4848:     	bfxil	w15, w14, #0, #4
1000c484c:     	scvtf	s1, w15
1000c4850:     	ldp	s2, s3, [x3, #32]
1000c4854:     	fmsub	s1, s1, s0, s2
1000c4858:     	str	s1, [x3, #32]
1000c485c:     	ldrb	w14, [x13, #36]
1000c4860:     	lsr	w14, w14, w12
1000c4864:     	and	w15, w14, #0xf
1000c4868:     	cmp	w15, #8
1000c486c:     	csel	w15, wzr, w11, lo
1000c4870:     	bfxil	w15, w14, #0, #4
1000c4874:     	scvtf	s1, w15
1000c4878:     	fmsub	s1, s1, s0, s3
1000c487c:     	str	s1, [x3, #36]
1000c4880:     	ldrb	w14, [x13, #40]
1000c4884:     	lsr	w14, w14, w12
1000c4888:     	and	w15, w14, #0xf
1000c488c:     	cmp	w15, #8
1000c4890:     	csel	w15, wzr, w11, lo
1000c4894:     	bfxil	w15, w14, #0, #4
1000c4898:     	scvtf	s1, w15
1000c489c:     	ldp	s2, s3, [x3, #40]
1000c48a0:     	fmsub	s1, s1, s0, s2
1000c48a4:     	str	s1, [x3, #40]
1000c48a8:     	ldrb	w14, [x13, #44]
1000c48ac:     	lsr	w14, w14, w12
1000c48b0:     	and	w15, w14, #0xf
1000c48b4:     	cmp	w15, #8
1000c48b8:     	csel	w15, wzr, w11, lo
1000c48bc:     	bfxil	w15, w14, #0, #4
1000c48c0:     	scvtf	s1, w15
1000c48c4:     	fmsub	s1, s1, s0, s3
1000c48c8:     	str	s1, [x3, #44]
1000c48cc:     	ldrb	w14, [x13, #48]
1000c48d0:     	lsr	w14, w14, w12
1000c48d4:     	and	w15, w14, #0xf
1000c48d8:     	cmp	w15, #8
1000c48dc:     	csel	w15, wzr, w11, lo
1000c48e0:     	bfxil	w15, w14, #0, #4
1000c48e4:     	scvtf	s1, w15
1000c48e8:     	ldp	s2, s3, [x3, #48]
1000c48ec:     	fmsub	s1, s1, s0, s2
1000c48f0:     	str	s1, [x3, #48]
1000c48f4:     	ldrb	w14, [x13, #52]
1000c48f8:     	lsr	w14, w14, w12
1000c48fc:     	and	w15, w14, #0xf
1000c4900:     	cmp	w15, #8
1000c4904:     	csel	w15, wzr, w11, lo
1000c4908:     	bfxil	w15, w14, #0, #4
1000c490c:     	scvtf	s1, w15
1000c4910:     	fmsub	s1, s1, s0, s3
1000c4914:     	str	s1, [x3, #52]
1000c4918:     	ldrb	w14, [x13, #56]
1000c491c:     	lsr	w14, w14, w12
1000c4920:     	and	w15, w14, #0xf
1000c4924:     	cmp	w15, #8
1000c4928:     	csel	w15, wzr, w11, lo
1000c492c:     	bfxil	w15, w14, #0, #4
1000c4930:     	scvtf	s1, w15
1000c4934:     	ldp	s2, s3, [x3, #56]
1000c4938:     	fmsub	s1, s1, s0, s2
1000c493c:     	str	s1, [x3, #56]
1000c4940:     	ldrb	w13, [x13, #60]
1000c4944:     	lsr	w12, w13, w12
1000c4948:     	and	w13, w12, #0xf
1000c494c:     	cmp	w13, #8
1000c4950:     	csel	w13, wzr, w11, lo
1000c4954:     	bfxil	w13, w12, #0, #4
1000c4958:     	scvtf	s1, w13
1000c495c:     	fmsub	s0, s1, s0, s3
1000c4960:     	str	s0, [x3, #60]
1000c4964:     	add	x8, x8, #1
1000c4968:     	add	w10, w10, #4
1000c496c:     	cmp	x2, x8
1000c4970:     	b.ne	0x1000c46cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c4974:     	ldp	x20, x19, [sp, #16]
1000c4978:     	ldp	x22, x21, [sp], #32
1000c497c:     	ret

