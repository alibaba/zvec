
bin/9819_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000422c8 <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000422c8:     	b	0x1000422cc <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>

0000000100114ed8 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
100114ed8:     	cbz	x2, 0x100114f38 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x60>
100114edc:     	ldrsh	w8, [x1]
100114ee0:     	fmov	s0, w8
100114ee4:     	ldrsh	w8, [x1, #2]
100114ee8:     	mov.s	v0[1], w8
100114eec:     	scvtf.2s	v0, v0
100114ef0:     	zip1.4s	v0, v0, v0
100114ef4:     	ldrsh	w8, [x0]
100114ef8:     	fmov	s1, w8
100114efc:     	ldrsh	w8, [x0, #2]
100114f00:     	mov.s	v1[1], w8
100114f04:     	scvtf.2s	v1, v1
100114f08:     	mov.d	v1[1], v1[0]
100114f0c:     	fsub.4s	v0, v1, v0
100114f10:     	fmul.4s	v0, v0, v0
100114f14:     	str	q0, [x3]
100114f18:     	subs	x11, x2, #1
100114f1c:     	b.eq	0x10011514c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x274>
100114f20:     	cmp	x2, #9
100114f24:     	b.hs	0x100114f40 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x68>
100114f28:     	mov	w8, #1
100114f2c:     	mov	x9, x1
100114f30:     	mov	x10, x0
100114f34:     	b	0x1001150f0 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x218>
100114f38:     	stp	xzr, xzr, [x3]
100114f3c:     	ret
100114f40:     	and	x12, x11, #0xfffffffffffffff8
100114f44:     	lsl	x8, x12, #2
100114f48:     	add	x9, x1, x8
100114f4c:     	add	x10, x0, x8
100114f50:     	orr	x8, x12, #0x1
100114f54:     	mov	s3, v0[1]
100114f58:     	mov	s2, v0[2]
100114f5c:     	mov	s1, v0[3]
100114f60:     	add	x13, x0, #4
100114f64:     	add	x14, x1, #4
100114f68:     	mov	x15, x12
100114f6c:     	ld2.8h	{ v4, v5 }, [x13], #32
100114f70:     	sshll2.4s	v6, v4, #0
100114f74:     	scvtf.4s	v6, v6
100114f78:     	sshll.4s	v7, v4, #0
100114f7c:     	scvtf.4s	v7, v7
100114f80:     	ld2.8h	{ v16, v17 }, [x14], #32
100114f84:     	sshll2.4s	v18, v16, #0
100114f88:     	scvtf.4s	v18, v18
100114f8c:     	sshll.4s	v19, v16, #0
100114f90:     	scvtf.4s	v19, v19
100114f94:     	sshll2.4s	v20, v17, #0
100114f98:     	sshll.4s	v16, v17, #0
100114f9c:     	sshll2.4s	v17, v5, #0
100114fa0:     	sshll.4s	v4, v5, #0
100114fa4:     	fsub.4s	v5, v7, v19
100114fa8:     	scvtf.4s	v16, v16
100114fac:     	fsub.4s	v7, v7, v16
100114fb0:     	scvtf.4s	v4, v4
100114fb4:     	fsub.4s	v19, v4, v19
100114fb8:     	fsub.4s	v4, v4, v16
100114fbc:     	fsub.4s	v16, v6, v18
100114fc0:     	scvtf.4s	v20, v20
100114fc4:     	fsub.4s	v6, v6, v20
100114fc8:     	scvtf.4s	v17, v17
100114fcc:     	fsub.4s	v18, v17, v18
100114fd0:     	fsub.4s	v17, v17, v20
100114fd4:     	fmul.4s	v4, v4, v4
100114fd8:     	mov	s20, v4[1]
100114fdc:     	fadd	s1, s1, s4
100114fe0:     	fadd	s1, s1, s20
100114fe4:     	mov	s20, v4[2]
100114fe8:     	fadd	s1, s1, s20
100114fec:     	fmul.4s	v17, v17, v17
100114ff0:     	mov	s4, v4[3]
100114ff4:     	fadd	s1, s1, s4
100114ff8:     	mov	s4, v17[1]
100114ffc:     	fadd	s1, s1, s17
100115000:     	fadd	s1, s1, s4
100115004:     	mov	s4, v17[2]
100115008:     	fadd	s1, s1, s4
10011500c:     	fmul.4s	v4, v19, v19
100115010:     	mov	s17, v17[3]
100115014:     	fadd	s1, s1, s17
100115018:     	mov	s17, v4[1]
10011501c:     	fadd	s3, s3, s4
100115020:     	fadd	s3, s3, s17
100115024:     	mov	s17, v4[2]
100115028:     	fadd	s3, s3, s17
10011502c:     	fmul.4s	v17, v18, v18
100115030:     	mov	s4, v4[3]
100115034:     	fadd	s3, s3, s4
100115038:     	mov	s4, v17[1]
10011503c:     	fadd	s3, s3, s17
100115040:     	fadd	s3, s3, s4
100115044:     	mov	s4, v17[2]
100115048:     	fadd	s3, s3, s4
10011504c:     	fmul.4s	v4, v7, v7
100115050:     	mov	s7, v17[3]
100115054:     	fadd	s3, s3, s7
100115058:     	mov	s7, v4[1]
10011505c:     	fadd	s2, s2, s4
100115060:     	fadd	s2, s2, s7
100115064:     	mov	s7, v4[2]
100115068:     	fadd	s2, s2, s7
10011506c:     	fmul.4s	v6, v6, v6
100115070:     	mov	s4, v4[3]
100115074:     	fadd	s2, s2, s4
100115078:     	mov	s4, v6[1]
10011507c:     	fadd	s2, s2, s6
100115080:     	fadd	s2, s2, s4
100115084:     	mov	s4, v6[2]
100115088:     	fadd	s2, s2, s4
10011508c:     	fmul.4s	v4, v5, v5
100115090:     	mov	s5, v6[3]
100115094:     	fadd	s2, s2, s5
100115098:     	mov	s5, v4[1]
10011509c:     	fadd	s0, s0, s4
1001150a0:     	fadd	s0, s0, s5
1001150a4:     	mov	s5, v4[2]
1001150a8:     	fadd	s0, s0, s5
1001150ac:     	fmul.4s	v5, v16, v16
1001150b0:     	mov	s4, v4[3]
1001150b4:     	fadd	s0, s0, s4
1001150b8:     	mov	s4, v5[1]
1001150bc:     	fadd	s0, s0, s5
1001150c0:     	fadd	s0, s0, s4
1001150c4:     	mov	s4, v5[3]
1001150c8:     	mov	s5, v5[2]
1001150cc:     	fadd	s0, s0, s5
1001150d0:     	fadd	s0, s0, s4
1001150d4:     	subs	x15, x15, #8
1001150d8:     	b.ne	0x100114f6c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x94>
1001150dc:     	mov.s	v0[1], v3[0]
1001150e0:     	mov.s	v0[2], v2[0]
1001150e4:     	mov.s	v0[3], v1[0]
1001150e8:     	cmp	x11, x12
1001150ec:     	b.eq	0x100115148 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x270>
1001150f0:     	add	x9, x9, #4
1001150f4:     	add	x10, x10, #4
1001150f8:     	sub	x8, x2, x8
1001150fc:     	ldrsh	w11, [x9]
100115100:     	fmov	s1, w11
100115104:     	ldrsh	w11, [x9, #2]
100115108:     	mov.s	v1[1], w11
10011510c:     	scvtf.2s	v1, v1
100115110:     	zip1.4s	v1, v1, v1
100115114:     	ldrsh	w11, [x10]
100115118:     	fmov	s2, w11
10011511c:     	ldrsh	w11, [x10, #2]
100115120:     	mov.s	v2[1], w11
100115124:     	scvtf.2s	v2, v2
100115128:     	mov.d	v2[1], v2[0]
10011512c:     	fsub.4s	v1, v2, v1
100115130:     	fmul.4s	v1, v1, v1
100115134:     	fadd.4s	v0, v0, v1
100115138:     	add	x9, x9, #4
10011513c:     	add	x10, x10, #4
100115140:     	subs	x8, x8, #1
100115144:     	b.ne	0x1001150fc <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x224>
100115148:     	str	q0, [x3]
10011514c:     	ret

0000000100115150 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100115150:     	cbz	x2, 0x1001151f0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0xa0>
100115154:     	ldrsh	w8, [x1, #2]
100115158:     	ldrsh	w9, [x1]
10011515c:     	fmov	s0, w9
100115160:     	mov.s	v0[1], w8
100115164:     	ldrsh	w8, [x0, #2]
100115168:     	ldrsh	w9, [x0]
10011516c:     	fmov	s1, w9
100115170:     	mov.s	v1[1], w8
100115174:     	mov.s	v1[2], w9
100115178:     	mov.s	v1[3], w8
10011517c:     	zip1.4s	v0, v0, v0
100115180:     	mul.4s	v0, v1, v0
100115184:     	scvtf.4s	v0, v0
100115188:     	fneg.4s	v0, v0
10011518c:     	str	q0, [x3]
100115190:     	subs	x8, x2, #1
100115194:     	b.eq	0x1001151ec <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x9c>
100115198:     	add	x9, x0, #4
10011519c:     	add	x10, x1, #4
1001151a0:     	ldrsh	w11, [x10, #2]
1001151a4:     	ldrsh	w12, [x10]
1001151a8:     	fmov	s1, w12
1001151ac:     	mov.s	v1[1], w11
1001151b0:     	zip1.4s	v1, v1, v1
1001151b4:     	ldrsh	w11, [x9, #2]
1001151b8:     	ldrsh	w12, [x9]
1001151bc:     	fmov	s2, w12
1001151c0:     	mov.s	v2[1], w11
1001151c4:     	mov.s	v2[2], w12
1001151c8:     	mov.s	v2[3], w11
1001151cc:     	mul.4s	v1, v2, v1
1001151d0:     	scvtf.4s	v1, v1
1001151d4:     	fsub.4s	v0, v0, v1
1001151d8:     	add	x9, x9, #4
1001151dc:     	add	x10, x10, #4
1001151e0:     	subs	x8, x8, #1
1001151e4:     	b.ne	0x1001151a0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x50>
1001151e8:     	str	q0, [x3]
1001151ec:     	ret
1001151f0:     	stp	xzr, xzr, [x3]
1001151f4:     	ret
