00000001000d8110 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d8110:     	stp	x28, x27, [sp, #-80]!
1000d8114:     	stp	x24, x23, [sp, #16]
1000d8118:     	stp	x22, x21, [sp, #32]
1000d811c:     	stp	x20, x19, [sp, #48]
1000d8120:     	stp	x29, x30, [sp, #64]
1000d8124:     	add	x29, sp, #64
1000d8128:     	sub	sp, sp, #2192
1000d812c:     	mov	x19, x3
1000d8130:     	mov	x20, x1
1000d8134:     	mov	x21, x0
1000d8138:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x278>
1000d813c:     	ldr	x8, [x8, #392]
1000d8140:     	ldr	x8, [x8]
1000d8144:     	stur	x8, [x29, #-72]
1000d8148:     	lsl	x8, x2, #3
1000d814c:     	and	x22, x8, #0xfffffffffffffff0
1000d8150:     	add	x0, sp, #136
1000d8154:     	mov	w1, #2048
1000d8158:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d815c:     	cbz	x22, 0x1000d8360 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000d8160:     	add	x8, x20, x22
1000d8164:     	mov	w9, #252645135
1000d8168:     	adrp	x10, 0x10016a000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x8>
1000d816c:     	add	x10, x10, #1980
1000d8170:     	add	x11, sp, #8
1000d8174:     	mov	x12, #0
1000d8178:     	ldp	w13, w14, [x20]
1000d817c:     	and	w15, w13, w9
1000d8180:     	and	w13, w9, w13, lsr #4
1000d8184:     	stp	w15, w13, [sp, #8]
1000d8188:     	and	w13, w14, w9
1000d818c:     	and	w14, w9, w14, lsr #4
1000d8190:     	stp	w13, w14, [sp, #16]
1000d8194:     	ldp	w13, w14, [x20, #8]
1000d8198:     	and	w15, w13, w9
1000d819c:     	and	w13, w9, w13, lsr #4
1000d81a0:     	stp	w15, w13, [sp, #24]
1000d81a4:     	and	w13, w14, w9
1000d81a8:     	and	w14, w9, w14, lsr #4
1000d81ac:     	stp	w13, w14, [sp, #32]
1000d81b0:     	ldp	w13, w14, [x20, #16]
1000d81b4:     	and	w15, w13, w9
1000d81b8:     	and	w13, w9, w13, lsr #4
1000d81bc:     	stp	w15, w13, [sp, #40]
1000d81c0:     	and	w13, w14, w9
1000d81c4:     	and	w14, w9, w14, lsr #4
1000d81c8:     	stp	w13, w14, [sp, #48]
1000d81cc:     	ldp	w13, w14, [x20, #24]
1000d81d0:     	and	w15, w13, w9
1000d81d4:     	and	w13, w9, w13, lsr #4
1000d81d8:     	stp	w15, w13, [sp, #56]
1000d81dc:     	and	w13, w14, w9
1000d81e0:     	and	w14, w9, w14, lsr #4
1000d81e4:     	stp	w13, w14, [sp, #64]
1000d81e8:     	ldp	w13, w14, [x20, #32]
1000d81ec:     	and	w15, w13, w9
1000d81f0:     	and	w13, w9, w13, lsr #4
1000d81f4:     	stp	w15, w13, [sp, #72]
1000d81f8:     	and	w13, w14, w9
1000d81fc:     	and	w14, w9, w14, lsr #4
1000d8200:     	stp	w13, w14, [sp, #80]
1000d8204:     	ldp	w13, w14, [x20, #40]
1000d8208:     	and	w15, w13, w9
1000d820c:     	and	w13, w9, w13, lsr #4
1000d8210:     	stp	w15, w13, [sp, #88]
1000d8214:     	and	w13, w14, w9
1000d8218:     	and	w14, w9, w14, lsr #4
1000d821c:     	stp	w13, w14, [sp, #96]
1000d8220:     	ldp	w13, w14, [x20, #48]
1000d8224:     	and	w15, w13, w9
1000d8228:     	and	w13, w9, w13, lsr #4
1000d822c:     	stp	w15, w13, [sp, #104]
1000d8230:     	and	w13, w14, w9
1000d8234:     	and	w14, w9, w14, lsr #4
1000d8238:     	stp	w13, w14, [sp, #112]
1000d823c:     	ldp	w13, w14, [x20, #56]
1000d8240:     	and	w15, w13, w9
1000d8244:     	and	w13, w9, w13, lsr #4
1000d8248:     	stp	w15, w13, [sp, #120]
1000d824c:     	and	w13, w14, w9
1000d8250:     	and	w14, w9, w14, lsr #4
1000d8254:     	stp	w13, w14, [sp, #128]
1000d8258:     	add	x13, sp, #136
1000d825c:     	mov	x14, #0
1000d8260:     	ldr	w4, [x21, x12, lsl #2]
1000d8264:     	lsl	w15, w4, #4
1000d8268:     	and	x15, x15, #0xf0
1000d826c:     	add	x15, x10, x15
1000d8270:     	and	x16, x4, #0xf0
1000d8274:     	add	x16, x10, x16
1000d8278:     	lsr	x17, x4, #4
1000d827c:     	and	x17, x17, #0xf0
1000d8280:     	add	x17, x10, x17
1000d8284:     	lsr	x0, x4, #8
1000d8288:     	and	x0, x0, #0xf0
1000d828c:     	add	x0, x10, x0
1000d8290:     	lsr	x1, x4, #12
1000d8294:     	and	x1, x1, #0xf0
1000d8298:     	add	x1, x10, x1
1000d829c:     	lsr	x2, x4, #16
1000d82a0:     	and	x2, x2, #0xf0
1000d82a4:     	add	x2, x10, x2
1000d82a8:     	lsr	x3, x4, #20
1000d82ac:     	and	x3, x3, #0xf0
1000d82b0:     	add	x3, x10, x3
1000d82b4:     	lsr	x4, x4, #24
1000d82b8:     	and	x4, x4, #0xf0
1000d82bc:     	add	x4, x10, x4
1000d82c0:     	mov	x5, x13
1000d82c4:     	add	x6, x11, x14
1000d82c8:     	ldrb	w7, [x6]
1000d82cc:     	ldrsb	w7, [x15, x7]
1000d82d0:     	ldrb	w22, [x6, #1]
1000d82d4:     	ldrsb	w22, [x17, x22]
1000d82d8:     	ldrb	w23, [x6, #2]
1000d82dc:     	ldrsb	w23, [x1, x23]
1000d82e0:     	add	w7, w7, w22
1000d82e4:     	add	w7, w7, w23
1000d82e8:     	ldrb	w22, [x6, #3]
1000d82ec:     	ldrsb	w22, [x3, x22]
1000d82f0:     	ldrb	w23, [x6, #4]
1000d82f4:     	ldrsb	w23, [x16, x23]
1000d82f8:     	ldrb	w24, [x6, #5]
1000d82fc:     	ldrsb	w24, [x0, x24]
1000d8300:     	add	w7, w7, w22
1000d8304:     	add	w7, w7, w23
1000d8308:     	ldrb	w22, [x6, #6]
1000d830c:     	ldrsb	w22, [x2, x22]
1000d8310:     	add	w7, w7, w24
1000d8314:     	add	w7, w7, w22
1000d8318:     	ldrb	w6, [x6, #7]
1000d831c:     	ldrsb	w6, [x4, x6]
1000d8320:     	add	w6, w7, w6
1000d8324:     	scvtf	s0, w6
1000d8328:     	ldr	s1, [x5]
1000d832c:     	fadd	s0, s1, s0
1000d8330:     	str	s0, [x5], #128
1000d8334:     	add	x14, x14, #8
1000d8338:     	cmp	x14, #128
1000d833c:     	b.ne	0x1000d82c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000d8340:     	add	x12, x12, #1
1000d8344:     	add	x13, x13, #4
1000d8348:     	cmp	x12, #32
1000d834c:     	b.ne	0x1000d825c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000d8350:     	add	x21, x21, #128
1000d8354:     	add	x20, x20, #64
1000d8358:     	cmp	x20, x8
1000d835c:     	b.ne	0x1000d8174 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d8360:     	add	x1, sp, #136
1000d8364:     	mov	x0, x19
1000d8368:     	mov	w2, #2048
1000d836c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d8370:     	ldur	x8, [x29, #-72]
1000d8374:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x21c>
1000d8378:     	ldr	x9, [x9, #392]
1000d837c:     	ldr	x9, [x9]
1000d8380:     	cmp	x9, x8
1000d8384:     	b.ne	0x1000d83a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000d8388:     	add	sp, sp, #2192
1000d838c:     	ldp	x29, x30, [sp, #64]
1000d8390:     	ldp	x20, x19, [sp, #48]
1000d8394:     	ldp	x22, x21, [sp, #32]
1000d8398:     	ldp	x24, x23, [sp, #16]
1000d839c:     	ldp	x28, x27, [sp], #80
1000d83a0:     	ret
1000d83a4:     	bl	0x100163694 <_strcmp+0x100163694>

