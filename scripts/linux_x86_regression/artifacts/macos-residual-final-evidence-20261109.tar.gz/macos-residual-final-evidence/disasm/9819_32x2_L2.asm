00000001000ce2c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce2c4:     	sub	sp, sp, #400
1000ce2c8:     	stp	x28, x27, [sp, #304]
1000ce2cc:     	stp	x26, x25, [sp, #320]
1000ce2d0:     	stp	x24, x23, [sp, #336]
1000ce2d4:     	stp	x22, x21, [sp, #352]
1000ce2d8:     	stp	x20, x19, [sp, #368]
1000ce2dc:     	stp	x29, x30, [sp, #384]
1000ce2e0:     	add	x29, sp, #384
1000ce2e4:     	str	x3, [sp]
1000ce2e8:     	adrp	x8, 0x100168000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xc>
1000ce2ec:     	ldr	x8, [x8, #392]
1000ce2f0:     	ldr	x8, [x8]
1000ce2f4:     	stur	x8, [x29, #-96]
1000ce2f8:     	movi.2d	v0, #0000000000000000
1000ce2fc:     	stp	q0, q0, [sp, #256]
1000ce300:     	stp	q0, q0, [sp, #224]
1000ce304:     	stp	q0, q0, [sp, #192]
1000ce308:     	stp	q0, q0, [sp, #160]
1000ce30c:     	stp	q0, q0, [sp, #128]
1000ce310:     	stp	q0, q0, [sp, #96]
1000ce314:     	stp	q0, q0, [sp, #64]
1000ce318:     	stp	q0, q0, [sp, #32]
1000ce31c:     	ands	x8, x2, #0xfffffffffffffffe
1000ce320:     	b.eq	0x1000ce4c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x200>
1000ce324:     	add	x8, x1, x8
1000ce328:     	str	x8, [sp, #8]
1000ce32c:     	adrp	x9, 0x100166000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x48>
1000ce330:     	add	x9, x9, #1756
1000ce334:     	mov	x11, #0
1000ce338:     	ldp	w4, w23, [x1]
1000ce33c:     	ubfx	x8, x4, #4, #4
1000ce340:     	stp	x1, x8, [sp, #16]
1000ce344:     	ubfx	x13, x4, #8, #4
1000ce348:     	and	x14, x4, #0xf
1000ce34c:     	ubfx	x15, x4, #12, #4
1000ce350:     	ubfx	x16, x4, #16, #4
1000ce354:     	ubfx	x17, x4, #20, #4
1000ce358:     	ubfx	x2, x4, #24, #4
1000ce35c:     	lsr	x4, x4, #28
1000ce360:     	and	x5, x23, #0xf
1000ce364:     	ubfx	x6, x23, #4, #4
1000ce368:     	ubfx	x7, x23, #8, #4
1000ce36c:     	ubfx	x19, x23, #12, #4
1000ce370:     	ubfx	x20, x23, #16, #4
1000ce374:     	ubfx	x21, x23, #20, #4
1000ce378:     	ubfx	x22, x23, #24, #4
1000ce37c:     	lsr	x23, x23, #28
1000ce380:     	ldr	w24, [x0, x11]
1000ce384:     	lsl	w25, w24, #4
1000ce388:     	and	x25, x25, #0xf0
1000ce38c:     	orr	x26, x25, x14
1000ce390:     	ldrb	w26, [x9, x26]
1000ce394:     	and	x27, x24, #0xf0
1000ce398:     	ldr	x8, [sp, #24]
1000ce39c:     	orr	x28, x27, x8
1000ce3a0:     	ldrb	w28, [x9, x28]
1000ce3a4:     	lsr	x30, x24, #4
1000ce3a8:     	and	x30, x30, #0xf0
1000ce3ac:     	orr	x8, x30, x13
1000ce3b0:     	ldrb	w8, [x9, x8]
1000ce3b4:     	add	w26, w26, w28
1000ce3b8:     	add	w8, w26, w8
1000ce3bc:     	lsr	x26, x24, #8
1000ce3c0:     	and	x26, x26, #0xf0
1000ce3c4:     	orr	x28, x26, x15
1000ce3c8:     	ldrb	w28, [x9, x28]
1000ce3cc:     	lsr	x3, x24, #12
1000ce3d0:     	and	x3, x3, #0xf0
1000ce3d4:     	orr	x10, x3, x16
1000ce3d8:     	ldrb	w10, [x9, x10]
1000ce3dc:     	add	w8, w8, w28
1000ce3e0:     	add	w8, w8, w10
1000ce3e4:     	lsr	x10, x24, #16
1000ce3e8:     	and	x10, x10, #0xf0
1000ce3ec:     	orr	x28, x10, x17
1000ce3f0:     	ldrb	w28, [x9, x28]
1000ce3f4:     	lsr	x1, x24, #20
1000ce3f8:     	and	x1, x1, #0xf0
1000ce3fc:     	orr	x12, x1, x2
1000ce400:     	ldrb	w12, [x9, x12]
1000ce404:     	add	w8, w8, w28
1000ce408:     	add	x28, sp, #32
1000ce40c:     	add	w8, w8, w12
1000ce410:     	lsr	x12, x24, #24
1000ce414:     	and	x12, x12, #0xf0
1000ce418:     	orr	x24, x12, x4
1000ce41c:     	ldrb	w24, [x9, x24]
1000ce420:     	add	w8, w8, w24
1000ce424:     	scvtf	s0, w8
1000ce428:     	add	x8, x28, x11
1000ce42c:     	ldr	s1, [x8]
1000ce430:     	fadd	s0, s1, s0
1000ce434:     	orr	x24, x25, x5
1000ce438:     	ldrb	w24, [x9, x24]
1000ce43c:     	orr	x25, x27, x6
1000ce440:     	ldrb	w25, [x9, x25]
1000ce444:     	orr	x27, x30, x7
1000ce448:     	ldrb	w27, [x9, x27]
1000ce44c:     	add	w24, w24, w25
1000ce450:     	add	w24, w24, w27
1000ce454:     	orr	x25, x26, x19
1000ce458:     	ldrb	w25, [x9, x25]
1000ce45c:     	orr	x3, x3, x20
1000ce460:     	ldrb	w3, [x9, x3]
1000ce464:     	orr	x10, x10, x21
1000ce468:     	ldrb	w10, [x9, x10]
1000ce46c:     	add	w24, w24, w25
1000ce470:     	add	w3, w24, w3
1000ce474:     	orr	x1, x1, x22
1000ce478:     	ldrb	w1, [x9, x1]
1000ce47c:     	add	w10, w3, w10
1000ce480:     	add	w10, w10, w1
1000ce484:     	orr	x12, x12, x23
1000ce488:     	ldrb	w12, [x9, x12]
1000ce48c:     	add	w10, w10, w12
1000ce490:     	scvtf	s1, w10
1000ce494:     	str	s0, [x8]
1000ce498:     	ldr	s0, [x8, #128]
1000ce49c:     	fadd	s0, s0, s1
1000ce4a0:     	str	s0, [x8, #128]
1000ce4a4:     	add	x11, x11, #4
1000ce4a8:     	cmp	x11, #128
1000ce4ac:     	b.ne	0x1000ce380 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000ce4b0:     	add	x0, x0, #128
1000ce4b4:     	ldp	x8, x1, [sp, #8]
1000ce4b8:     	add	x1, x1, #8
1000ce4bc:     	cmp	x1, x8
1000ce4c0:     	b.ne	0x1000ce334 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000ce4c4:     	ldp	q0, q1, [sp, #224]
1000ce4c8:     	ldr	x8, [sp]
1000ce4cc:     	stp	q0, q1, [x8, #192]
1000ce4d0:     	ldp	q0, q1, [sp, #256]
1000ce4d4:     	stp	q0, q1, [x8, #224]
1000ce4d8:     	ldp	q0, q1, [sp, #160]
1000ce4dc:     	stp	q0, q1, [x8, #128]
1000ce4e0:     	ldp	q0, q1, [sp, #192]
1000ce4e4:     	stp	q0, q1, [x8, #160]
1000ce4e8:     	ldp	q0, q1, [sp, #96]
1000ce4ec:     	stp	q0, q1, [x8, #64]
1000ce4f0:     	ldp	q0, q1, [sp, #128]
1000ce4f4:     	stp	q0, q1, [x8, #96]
1000ce4f8:     	ldp	q0, q1, [sp, #32]
1000ce4fc:     	stp	q0, q1, [x8]
1000ce500:     	ldp	q0, q1, [sp, #64]
1000ce504:     	stp	q0, q1, [x8, #32]
1000ce508:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000ce50c:     	ldr	x8, [x8, #392]
1000ce510:     	ldr	x8, [x8]
1000ce514:     	ldur	x9, [x29, #-96]
1000ce518:     	cmp	x8, x9
1000ce51c:     	b.ne	0x1000ce540 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x27c>
1000ce520:     	ldp	x29, x30, [sp, #384]
1000ce524:     	ldp	x20, x19, [sp, #368]
1000ce528:     	ldp	x22, x21, [sp, #352]
1000ce52c:     	ldp	x24, x23, [sp, #336]
1000ce530:     	ldp	x26, x25, [sp, #320]
1000ce534:     	ldp	x28, x27, [sp, #304]
1000ce538:     	add	sp, sp, #400
1000ce53c:     	ret
1000ce540:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

