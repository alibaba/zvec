00000001000c7708 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c7708:     	stp	x28, x27, [sp, #-96]!
1000c770c:     	stp	x26, x25, [sp, #16]
1000c7710:     	stp	x24, x23, [sp, #32]
1000c7714:     	stp	x22, x21, [sp, #48]
1000c7718:     	stp	x20, x19, [sp, #64]
1000c771c:     	stp	x29, x30, [sp, #80]
1000c7720:     	add	x29, sp, #80
1000c7724:     	sub	sp, sp, #448
1000c7728:     	str	x3, [sp]
1000c772c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a8>
1000c7730:     	ldr	x8, [x8, #392]
1000c7734:     	ldr	x8, [x8]
1000c7738:     	stur	x8, [x29, #-96]
1000c773c:     	movi.2d	v0, #0000000000000000
1000c7740:     	stp	q0, q0, [sp, #400]
1000c7744:     	lsl	x8, x2, #1
1000c7748:     	stp	q0, q0, [sp, #368]
1000c774c:     	stp	q0, q0, [sp, #336]
1000c7750:     	stp	q0, q0, [sp, #304]
1000c7754:     	stp	q0, q0, [sp, #272]
1000c7758:     	stp	q0, q0, [sp, #240]
1000c775c:     	stp	q0, q0, [sp, #208]
1000c7760:     	stp	q0, q0, [sp, #176]
1000c7764:     	ands	x8, x8, #0xfffffffffffffffc
1000c7768:     	b.eq	0x1000c7a90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c776c:     	add	x8, x1, x8
1000c7770:     	str	x8, [sp, #8]
1000c7774:     	add	x8, sp, #176
1000c7778:     	add	x27, x8, #128
1000c777c:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000c7780:     	add	x11, x11, #1244
1000c7784:     	mov	x12, #0
1000c7788:     	ldp	w8, w9, [x1]
1000c778c:     	ubfx	x10, x8, #4, #4
1000c7790:     	str	x10, [sp, #168]
1000c7794:     	ubfx	x10, x8, #8, #4
1000c7798:     	str	x10, [sp, #160]
1000c779c:     	and	x10, x8, #0xf
1000c77a0:     	str	x10, [sp, #152]
1000c77a4:     	ubfx	x10, x8, #12, #4
1000c77a8:     	str	x10, [sp, #144]
1000c77ac:     	ubfx	x10, x8, #16, #4
1000c77b0:     	str	x10, [sp, #136]
1000c77b4:     	ubfx	x10, x8, #20, #4
1000c77b8:     	str	x10, [sp, #128]
1000c77bc:     	ubfx	x10, x8, #24, #4
1000c77c0:     	lsr	x8, x8, #28
1000c77c4:     	stp	x8, x10, [sp, #112]
1000c77c8:     	and	x10, x9, #0xf
1000c77cc:     	ubfx	x8, x9, #4, #4
1000c77d0:     	stp	x8, x10, [sp, #96]
1000c77d4:     	ubfx	x10, x9, #8, #4
1000c77d8:     	ubfx	x8, x9, #12, #4
1000c77dc:     	stp	x8, x10, [sp, #80]
1000c77e0:     	ubfx	x10, x9, #16, #4
1000c77e4:     	ubfx	x8, x9, #20, #4
1000c77e8:     	stp	x8, x10, [sp, #64]
1000c77ec:     	ubfx	x10, x9, #24, #4
1000c77f0:     	lsr	x8, x9, #28
1000c77f4:     	stp	x8, x10, [sp, #48]
1000c77f8:     	ldp	w9, w17, [x1, #8]
1000c77fc:     	and	x10, x9, #0xf
1000c7800:     	ubfx	x8, x9, #4, #4
1000c7804:     	stp	x8, x10, [sp, #32]
1000c7808:     	ubfx	x8, x9, #8, #4
1000c780c:     	stp	x1, x8, [sp, #16]
1000c7810:     	ubfx	x28, x9, #12, #4
1000c7814:     	ubfx	x30, x9, #16, #4
1000c7818:     	ubfx	x8, x9, #20, #4
1000c781c:     	ubfx	x3, x9, #24, #4
1000c7820:     	lsr	x9, x9, #28
1000c7824:     	and	x1, x17, #0xf
1000c7828:     	ubfx	x10, x17, #4, #4
1000c782c:     	ubfx	x13, x17, #8, #4
1000c7830:     	ubfx	x26, x17, #12, #4
1000c7834:     	ubfx	x14, x17, #16, #4
1000c7838:     	ubfx	x15, x17, #20, #4
1000c783c:     	ubfx	x16, x17, #24, #4
1000c7840:     	lsr	x17, x17, #28
1000c7844:     	ldr	w21, [x0, x12]
1000c7848:     	lsl	w2, w21, #4
1000c784c:     	and	x2, x2, #0xf0
1000c7850:     	ldp	x4, x19, [sp, #152]
1000c7854:     	orr	x4, x2, x4
1000c7858:     	ldrb	w6, [x11, x4]
1000c785c:     	and	x4, x21, #0xf0
1000c7860:     	ldr	x5, [sp, #168]
1000c7864:     	orr	x5, x4, x5
1000c7868:     	ldrb	w7, [x11, x5]
1000c786c:     	lsr	x5, x21, #4
1000c7870:     	and	x5, x5, #0xf0
1000c7874:     	orr	x19, x5, x19
1000c7878:     	ldrb	w19, [x11, x19]
1000c787c:     	add	w6, w6, w7
1000c7880:     	add	w19, w6, w19
1000c7884:     	lsr	x6, x21, #8
1000c7888:     	and	x6, x6, #0xf0
1000c788c:     	ldp	x22, x7, [sp, #136]
1000c7890:     	orr	x7, x6, x7
1000c7894:     	ldrb	w20, [x11, x7]
1000c7898:     	lsr	x7, x21, #12
1000c789c:     	and	x7, x7, #0xf0
1000c78a0:     	orr	x22, x7, x22
1000c78a4:     	ldrb	w22, [x11, x22]
1000c78a8:     	add	w19, w19, w20
1000c78ac:     	add	w22, w19, w22
1000c78b0:     	lsr	x19, x21, #16
1000c78b4:     	and	x19, x19, #0xf0
1000c78b8:     	ldp	x24, x20, [sp, #120]
1000c78bc:     	orr	x20, x19, x20
1000c78c0:     	ldrb	w23, [x11, x20]
1000c78c4:     	lsr	x20, x21, #20
1000c78c8:     	and	x20, x20, #0xf0
1000c78cc:     	orr	x24, x20, x24
1000c78d0:     	ldrb	w24, [x11, x24]
1000c78d4:     	add	w22, w22, w23
1000c78d8:     	add	w22, w22, w24
1000c78dc:     	lsr	x21, x21, #24
1000c78e0:     	and	x21, x21, #0xf0
1000c78e4:     	ldr	x23, [sp, #112]
1000c78e8:     	orr	x23, x21, x23
1000c78ec:     	ldrb	w23, [x11, x23]
1000c78f0:     	add	w22, w22, w23
1000c78f4:     	scvtf	s0, w22
1000c78f8:     	ldp	x23, x22, [sp, #96]
1000c78fc:     	orr	x22, x2, x22
1000c7900:     	ldrb	w22, [x11, x22]
1000c7904:     	orr	x23, x4, x23
1000c7908:     	ldrb	w23, [x11, x23]
1000c790c:     	ldr	x24, [sp, #88]
1000c7910:     	orr	x24, x5, x24
1000c7914:     	ldrb	w24, [x11, x24]
1000c7918:     	add	w22, w22, w23
1000c791c:     	add	w22, w22, w24
1000c7920:     	ldp	x24, x23, [sp, #72]
1000c7924:     	orr	x23, x6, x23
1000c7928:     	ldrb	w23, [x11, x23]
1000c792c:     	orr	x24, x7, x24
1000c7930:     	ldrb	w24, [x11, x24]
1000c7934:     	ldr	x25, [sp, #64]
1000c7938:     	orr	x25, x19, x25
1000c793c:     	ldrb	w25, [x11, x25]
1000c7940:     	add	w22, w22, w23
1000c7944:     	add	w22, w22, w24
1000c7948:     	ldr	x23, [sp, #56]
1000c794c:     	orr	x23, x20, x23
1000c7950:     	ldrb	w23, [x11, x23]
1000c7954:     	add	w22, w22, w25
1000c7958:     	add	w22, w22, w23
1000c795c:     	ldr	x23, [sp, #48]
1000c7960:     	orr	x23, x21, x23
1000c7964:     	ldrb	w23, [x11, x23]
1000c7968:     	add	w22, w22, w23
1000c796c:     	scvtf	s1, w22
1000c7970:     	ldp	x23, x22, [sp, #32]
1000c7974:     	orr	x22, x2, x22
1000c7978:     	ldrb	w22, [x11, x22]
1000c797c:     	orr	x23, x4, x23
1000c7980:     	ldrb	w23, [x11, x23]
1000c7984:     	ldr	x24, [sp, #24]
1000c7988:     	orr	x24, x5, x24
1000c798c:     	ldrb	w24, [x11, x24]
1000c7990:     	add	w22, w22, w23
1000c7994:     	add	w22, w22, w24
1000c7998:     	orr	x23, x6, x28
1000c799c:     	ldrb	w23, [x11, x23]
1000c79a0:     	orr	x24, x7, x30
1000c79a4:     	ldrb	w24, [x11, x24]
1000c79a8:     	orr	x25, x19, x8
1000c79ac:     	ldrb	w25, [x11, x25]
1000c79b0:     	add	w22, w22, w23
1000c79b4:     	orr	x23, x20, x3
1000c79b8:     	ldrb	w23, [x11, x23]
1000c79bc:     	add	w22, w22, w24
1000c79c0:     	add	w22, w22, w25
1000c79c4:     	add	w22, w22, w23
1000c79c8:     	orr	x23, x21, x9
1000c79cc:     	ldrb	w23, [x11, x23]
1000c79d0:     	add	w22, w22, w23
1000c79d4:     	scvtf	s2, w22
1000c79d8:     	orr	x2, x2, x1
1000c79dc:     	ldrb	w2, [x11, x2]
1000c79e0:     	orr	x4, x4, x10
1000c79e4:     	ldrb	w4, [x11, x4]
1000c79e8:     	orr	x5, x5, x13
1000c79ec:     	ldrb	w5, [x11, x5]
1000c79f0:     	add	w2, w2, w4
1000c79f4:     	add	w2, w2, w5
1000c79f8:     	orr	x4, x6, x26
1000c79fc:     	ldrb	w4, [x11, x4]
1000c7a00:     	orr	x5, x7, x14
1000c7a04:     	ldrb	w5, [x11, x5]
1000c7a08:     	add	w2, w2, w4
1000c7a0c:     	orr	x4, x19, x15
1000c7a10:     	ldrb	w4, [x11, x4]
1000c7a14:     	add	w2, w2, w5
1000c7a18:     	orr	x5, x20, x16
1000c7a1c:     	ldrb	w5, [x11, x5]
1000c7a20:     	add	w2, w2, w4
1000c7a24:     	add	w2, w2, w5
1000c7a28:     	orr	x4, x21, x17
1000c7a2c:     	ldrb	w4, [x11, x4]
1000c7a30:     	add	w2, w2, w4
1000c7a34:     	add	x4, sp, #176
1000c7a38:     	scvtf	s3, w2
1000c7a3c:     	add	x2, x27, x12
1000c7a40:     	ldur	s4, [x2, #-64]
1000c7a44:     	fadd	s1, s4, s1
1000c7a48:     	stur	s1, [x2, #-64]
1000c7a4c:     	ldr	s1, [x2]
1000c7a50:     	fadd	s1, s1, s2
1000c7a54:     	str	s1, [x2]
1000c7a58:     	ldr	s1, [x2, #64]
1000c7a5c:     	fadd	s1, s1, s3
1000c7a60:     	ldr	s2, [x4, x12]
1000c7a64:     	str	s1, [x2, #64]
1000c7a68:     	fadd	s0, s2, s0
1000c7a6c:     	str	s0, [x4, x12]
1000c7a70:     	add	x12, x12, #4
1000c7a74:     	cmp	x12, #64
1000c7a78:     	b.ne	0x1000c7844 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c7a7c:     	add	x0, x0, #64
1000c7a80:     	ldp	x8, x1, [sp, #8]
1000c7a84:     	add	x1, x1, #16
1000c7a88:     	cmp	x1, x8
1000c7a8c:     	b.ne	0x1000c7784 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c7a90:     	ldp	q0, q1, [sp, #368]
1000c7a94:     	ldr	x8, [sp]
1000c7a98:     	stp	q0, q1, [x8, #192]
1000c7a9c:     	ldp	q0, q1, [sp, #400]
1000c7aa0:     	stp	q0, q1, [x8, #224]
1000c7aa4:     	ldp	q0, q1, [sp, #304]
1000c7aa8:     	stp	q0, q1, [x8, #128]
1000c7aac:     	ldp	q0, q1, [sp, #336]
1000c7ab0:     	stp	q0, q1, [x8, #160]
1000c7ab4:     	ldp	q0, q1, [sp, #240]
1000c7ab8:     	stp	q0, q1, [x8, #64]
1000c7abc:     	ldp	q0, q1, [sp, #272]
1000c7ac0:     	stp	q0, q1, [x8, #96]
1000c7ac4:     	ldp	q0, q1, [sp, #176]
1000c7ac8:     	stp	q0, q1, [x8]
1000c7acc:     	ldp	q0, q1, [sp, #208]
1000c7ad0:     	stp	q0, q1, [x8, #32]
1000c7ad4:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x138>
1000c7ad8:     	ldr	x8, [x8, #392]
1000c7adc:     	ldr	x8, [x8]
1000c7ae0:     	ldur	x9, [x29, #-96]
1000c7ae4:     	cmp	x8, x9
1000c7ae8:     	b.ne	0x1000c7b0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x404>
1000c7aec:     	add	sp, sp, #448
1000c7af0:     	ldp	x29, x30, [sp, #80]
1000c7af4:     	ldp	x20, x19, [sp, #64]
1000c7af8:     	ldp	x22, x21, [sp, #48]
1000c7afc:     	ldp	x24, x23, [sp, #32]
1000c7b00:     	ldp	x26, x25, [sp, #16]
1000c7b04:     	ldp	x28, x27, [sp], #96
1000c7b08:     	ret
1000c7b0c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

