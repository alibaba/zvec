00000001000c11a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c11a0:     	sub	sp, sp, #208
1000c11a4:     	stp	x28, x27, [sp, #112]
1000c11a8:     	stp	x26, x25, [sp, #128]
1000c11ac:     	stp	x24, x23, [sp, #144]
1000c11b0:     	stp	x22, x21, [sp, #160]
1000c11b4:     	stp	x20, x19, [sp, #176]
1000c11b8:     	stp	x29, x30, [sp, #192]
1000c11bc:     	add	x29, sp, #192
1000c11c0:     	str	x3, [sp]
1000c11c4:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000c11c8:     	ldr	x8, [x8, #392]
1000c11cc:     	ldr	x8, [x8]
1000c11d0:     	stur	x8, [x29, #-88]
1000c11d4:     	movi.2d	v0, #0000000000000000
1000c11d8:     	stp	q0, q0, [sp, #64]
1000c11dc:     	stp	q0, q0, [sp, #32]
1000c11e0:     	ands	x8, x2, #0xfffffffffffffffe
1000c11e4:     	b.eq	0x1000c1368 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c11e8:     	add	x8, x1, x8
1000c11ec:     	str	x8, [sp, #8]
1000c11f0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x28>
1000c11f4:     	add	x9, x9, #700
1000c11f8:     	mov	x11, #0
1000c11fc:     	ldp	w4, w23, [x1]
1000c1200:     	ubfx	x8, x4, #8, #4
1000c1204:     	stp	x1, x8, [sp, #16]
1000c1208:     	ubfx	x13, x4, #16, #4
1000c120c:     	and	x14, x4, #0xf
1000c1210:     	ubfx	x15, x4, #24, #4
1000c1214:     	ubfx	x16, x4, #4, #4
1000c1218:     	ubfx	x17, x4, #12, #4
1000c121c:     	ubfx	x2, x4, #20, #4
1000c1220:     	lsr	x4, x4, #28
1000c1224:     	and	x5, x23, #0xf
1000c1228:     	ubfx	x6, x23, #8, #4
1000c122c:     	ubfx	x7, x23, #16, #4
1000c1230:     	ubfx	x19, x23, #24, #4
1000c1234:     	ubfx	x20, x23, #4, #4
1000c1238:     	ubfx	x21, x23, #12, #4
1000c123c:     	ubfx	x22, x23, #20, #4
1000c1240:     	lsr	x23, x23, #28
1000c1244:     	ldr	w24, [x0, x11]
1000c1248:     	lsl	w25, w24, #4
1000c124c:     	and	x25, x25, #0xf0
1000c1250:     	add	x25, x9, x25
1000c1254:     	and	x26, x24, #0xf0
1000c1258:     	add	x26, x9, x26
1000c125c:     	lsr	x27, x24, #4
1000c1260:     	and	x27, x27, #0xf0
1000c1264:     	add	x27, x9, x27
1000c1268:     	lsr	x28, x24, #8
1000c126c:     	and	x28, x28, #0xf0
1000c1270:     	add	x28, x9, x28
1000c1274:     	lsr	x30, x24, #12
1000c1278:     	and	x30, x30, #0xf0
1000c127c:     	add	x30, x9, x30
1000c1280:     	lsr	x8, x24, #16
1000c1284:     	and	x8, x8, #0xf0
1000c1288:     	add	x8, x9, x8
1000c128c:     	lsr	x3, x24, #20
1000c1290:     	and	x3, x3, #0xf0
1000c1294:     	add	x3, x9, x3
1000c1298:     	lsr	x24, x24, #24
1000c129c:     	and	x24, x24, #0xf0
1000c12a0:     	ldrb	w10, [x25, x14]
1000c12a4:     	ldr	x12, [sp, #24]
1000c12a8:     	ldrb	w1, [x27, x12]
1000c12ac:     	ldrb	w12, [x30, x13]
1000c12b0:     	add	w10, w10, w1
1000c12b4:     	add	w10, w10, w12
1000c12b8:     	ldrb	w12, [x3, x15]
1000c12bc:     	ldrb	w1, [x26, x16]
1000c12c0:     	add	w10, w10, w12
1000c12c4:     	add	w10, w10, w1
1000c12c8:     	ldrb	w12, [x28, x17]
1000c12cc:     	ldrb	w1, [x8, x2]
1000c12d0:     	add	x24, x9, x24
1000c12d4:     	add	w10, w10, w12
1000c12d8:     	add	w10, w10, w1
1000c12dc:     	ldrb	w12, [x24, x4]
1000c12e0:     	add	w10, w10, w12
1000c12e4:     	scvtf	s0, w10
1000c12e8:     	add	x10, sp, #32
1000c12ec:     	add	x10, x10, x11
1000c12f0:     	ldr	s1, [x10]
1000c12f4:     	ldrb	w12, [x25, x5]
1000c12f8:     	fadd	s0, s1, s0
1000c12fc:     	ldrb	w1, [x27, x6]
1000c1300:     	ldrb	w25, [x30, x7]
1000c1304:     	add	w12, w12, w1
1000c1308:     	add	w12, w12, w25
1000c130c:     	ldrb	w1, [x3, x19]
1000c1310:     	ldrb	w3, [x26, x20]
1000c1314:     	add	w12, w12, w1
1000c1318:     	add	w12, w12, w3
1000c131c:     	ldrb	w1, [x28, x21]
1000c1320:     	ldrb	w8, [x8, x22]
1000c1324:     	add	w12, w12, w1
1000c1328:     	add	w8, w12, w8
1000c132c:     	ldrb	w12, [x24, x23]
1000c1330:     	add	w8, w8, w12
1000c1334:     	scvtf	s1, w8
1000c1338:     	str	s0, [x10]
1000c133c:     	ldr	s0, [x10, #32]
1000c1340:     	fadd	s0, s0, s1
1000c1344:     	str	s0, [x10, #32]
1000c1348:     	add	x11, x11, #4
1000c134c:     	cmp	x11, #32
1000c1350:     	b.ne	0x1000c1244 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1354:     	add	x0, x0, #32
1000c1358:     	ldp	x8, x1, [sp, #8]
1000c135c:     	add	x1, x1, #8
1000c1360:     	cmp	x1, x8
1000c1364:     	b.ne	0x1000c11f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1368:     	ldp	q0, q1, [sp, #32]
1000c136c:     	ldr	x8, [sp]
1000c1370:     	stp	q0, q1, [x8]
1000c1374:     	ldp	q0, q1, [sp, #64]
1000c1378:     	stp	q0, q1, [x8, #32]
1000c137c:     	ldur	x8, [x29, #-88]
1000c1380:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c0>
1000c1384:     	ldr	x9, [x9, #392]
1000c1388:     	ldr	x9, [x9]
1000c138c:     	cmp	x9, x8
1000c1390:     	b.ne	0x1000c13b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1394:     	ldp	x29, x30, [sp, #192]
1000c1398:     	ldp	x20, x19, [sp, #176]
1000c139c:     	ldp	x22, x21, [sp, #160]
1000c13a0:     	ldp	x24, x23, [sp, #144]
1000c13a4:     	ldp	x26, x25, [sp, #128]
1000c13a8:     	ldp	x28, x27, [sp, #112]
1000c13ac:     	add	sp, sp, #208
1000c13b0:     	ret
1000c13b4:     	bl	0x100163694 <_strcmp+0x100163694>

