00000001000b9704 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b9704:     	stp	x24, x23, [sp, #-48]!
1000b9708:     	stp	x22, x21, [sp, #16]
1000b970c:     	stp	x20, x19, [sp, #32]
1000b9710:     	stp	xzr, xzr, [x3]
1000b9714:     	lsl	x8, x4, #2
1000b9718:     	cmp	x2, #8
1000b971c:     	b.hs	0x1000b9730 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b9720:     	mov	x13, #0
1000b9724:     	movi	d1, #0000000000000000
1000b9728:     	movi	d0, #0000000000000000
1000b972c:     	b	0x1000b9978 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000b9730:     	mov	x10, #0
1000b9734:     	add	x9, x0, #8
1000b9738:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f8>
1000b973c:     	add	x11, x11, #188
1000b9740:     	mov	x12, x1
1000b9744:     	ldr	w5, [x12]
1000b9748:     	lsl	w13, w5, #4
1000b974c:     	and	x14, x13, #0xf0
1000b9750:     	and	x13, x5, #0xf0
1000b9754:     	add	x13, x11, x13
1000b9758:     	add	x14, x11, x14
1000b975c:     	lsr	x15, x5, #4
1000b9760:     	and	x15, x15, #0xf0
1000b9764:     	add	x15, x11, x15
1000b9768:     	lsr	x16, x5, #8
1000b976c:     	and	x16, x16, #0xf0
1000b9770:     	add	x16, x11, x16
1000b9774:     	lsr	x17, x5, #12
1000b9778:     	and	x17, x17, #0xf0
1000b977c:     	add	x17, x11, x17
1000b9780:     	lsr	x4, x5, #16
1000b9784:     	and	x4, x4, #0xf0
1000b9788:     	add	x4, x11, x4
1000b978c:     	lsr	x6, x5, #20
1000b9790:     	and	x6, x6, #0xf0
1000b9794:     	lsr	x5, x5, #24
1000b9798:     	and	x7, x5, #0xf0
1000b979c:     	ldur	w19, [x9, #-8]
1000b97a0:     	add	x5, x11, x6
1000b97a4:     	and	x6, x19, #0xf
1000b97a8:     	ubfx	x20, x19, #4, #4
1000b97ac:     	ldrb	w20, [x13, x20]
1000b97b0:     	ldrb	w21, [x14, x6]
1000b97b4:     	ubfx	x6, x19, #8, #4
1000b97b8:     	ldrb	w22, [x15, x6]
1000b97bc:     	ubfx	x6, x19, #12, #4
1000b97c0:     	ldrb	w23, [x16, x6]
1000b97c4:     	add	x6, x11, x7
1000b97c8:     	ubfx	x7, x19, #16, #4
1000b97cc:     	ldrb	w7, [x17, x7]
1000b97d0:     	add	w20, w21, w20
1000b97d4:     	add	w20, w20, w22
1000b97d8:     	ubfx	x21, x19, #20, #4
1000b97dc:     	ldrb	w21, [x4, x21]
1000b97e0:     	ubfx	x22, x19, #24, #4
1000b97e4:     	add	w20, w20, w23
1000b97e8:     	add	w7, w20, w7
1000b97ec:     	ldrb	w20, [x5, x22]
1000b97f0:     	lsr	x19, x19, #28
1000b97f4:     	ldrb	w19, [x6, x19]
1000b97f8:     	add	w7, w7, w21
1000b97fc:     	add	w7, w7, w20
1000b9800:     	add	w7, w7, w19
1000b9804:     	scvtf	s0, w7
1000b9808:     	ldp	s1, s2, [x3]
1000b980c:     	fadd	s0, s1, s0
1000b9810:     	str	s0, [x3]
1000b9814:     	ldur	w7, [x9, #-4]
1000b9818:     	and	x19, x7, #0xf
1000b981c:     	ldrb	w19, [x14, x19]
1000b9820:     	ubfx	x20, x7, #4, #4
1000b9824:     	ldrb	w20, [x13, x20]
1000b9828:     	ubfx	x21, x7, #8, #4
1000b982c:     	ldrb	w21, [x15, x21]
1000b9830:     	ubfx	x22, x7, #12, #4
1000b9834:     	ldrb	w22, [x16, x22]
1000b9838:     	ubfx	x23, x7, #16, #4
1000b983c:     	add	w19, w19, w20
1000b9840:     	add	w19, w19, w21
1000b9844:     	ldrb	w20, [x17, x23]
1000b9848:     	ubfx	x21, x7, #20, #4
1000b984c:     	ldrb	w21, [x4, x21]
1000b9850:     	add	w19, w19, w22
1000b9854:     	add	w19, w19, w20
1000b9858:     	ubfx	x20, x7, #24, #4
1000b985c:     	ldrb	w20, [x5, x20]
1000b9860:     	add	w19, w19, w21
1000b9864:     	add	w19, w19, w20
1000b9868:     	lsr	x7, x7, #28
1000b986c:     	ldrb	w7, [x6, x7]
1000b9870:     	add	w7, w19, w7
1000b9874:     	scvtf	s0, w7
1000b9878:     	fadd	s0, s2, s0
1000b987c:     	str	s0, [x3, #4]
1000b9880:     	ldr	w7, [x9]
1000b9884:     	and	x19, x7, #0xf
1000b9888:     	ldrb	w19, [x14, x19]
1000b988c:     	ubfx	x20, x7, #4, #4
1000b9890:     	ldrb	w20, [x13, x20]
1000b9894:     	ubfx	x21, x7, #8, #4
1000b9898:     	ldrb	w21, [x15, x21]
1000b989c:     	ubfx	x22, x7, #12, #4
1000b98a0:     	ldrb	w22, [x16, x22]
1000b98a4:     	ubfx	x23, x7, #16, #4
1000b98a8:     	add	w19, w19, w20
1000b98ac:     	add	w19, w19, w21
1000b98b0:     	ldrb	w20, [x17, x23]
1000b98b4:     	ubfx	x21, x7, #20, #4
1000b98b8:     	ldrb	w21, [x4, x21]
1000b98bc:     	add	w19, w19, w22
1000b98c0:     	add	w19, w19, w20
1000b98c4:     	ubfx	x20, x7, #24, #4
1000b98c8:     	ldrb	w20, [x5, x20]
1000b98cc:     	add	w19, w19, w21
1000b98d0:     	add	w19, w19, w20
1000b98d4:     	lsr	x7, x7, #28
1000b98d8:     	ldrb	w7, [x6, x7]
1000b98dc:     	add	w7, w19, w7
1000b98e0:     	scvtf	s0, w7
1000b98e4:     	ldp	s1, s2, [x3, #8]
1000b98e8:     	fadd	s0, s1, s0
1000b98ec:     	str	s0, [x3, #8]
1000b98f0:     	ldr	w7, [x9, #4]
1000b98f4:     	and	x19, x7, #0xf
1000b98f8:     	ldrb	w14, [x14, x19]
1000b98fc:     	ubfx	x19, x7, #4, #4
1000b9900:     	ldrb	w13, [x13, x19]
1000b9904:     	ubfx	x19, x7, #8, #4
1000b9908:     	ldrb	w15, [x15, x19]
1000b990c:     	ubfx	x19, x7, #12, #4
1000b9910:     	ldrb	w16, [x16, x19]
1000b9914:     	ubfx	x19, x7, #16, #4
1000b9918:     	ldrb	w17, [x17, x19]
1000b991c:     	add	w13, w14, w13
1000b9920:     	add	w13, w13, w15
1000b9924:     	ubfx	x14, x7, #20, #4
1000b9928:     	ldrb	w14, [x4, x14]
1000b992c:     	ubfx	x15, x7, #24, #4
1000b9930:     	add	w13, w13, w16
1000b9934:     	add	w13, w13, w17
1000b9938:     	ldrb	w15, [x5, x15]
1000b993c:     	lsr	x16, x7, #28
1000b9940:     	ldrb	w16, [x6, x16]
1000b9944:     	add	w13, w13, w14
1000b9948:     	add	w13, w13, w15
1000b994c:     	add	w13, w13, w16
1000b9950:     	scvtf	s1, w13
1000b9954:     	fadd	s1, s2, s1
1000b9958:     	str	s1, [x3, #12]
1000b995c:     	add	x13, x10, #8
1000b9960:     	add	x12, x12, x8
1000b9964:     	add	x9, x9, #16
1000b9968:     	add	x14, x10, #16
1000b996c:     	mov	x10, x13
1000b9970:     	cmp	x14, x2
1000b9974:     	b.ls	0x1000b9744 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000b9978:     	cmp	x13, x2
1000b997c:     	b.hs	0x1000b9a74 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x370>
1000b9980:     	ldp	s2, s3, [x3]
1000b9984:     	lsl	w9, w13, #2
1000b9988:     	mov	w10, #-16
1000b998c:     	lsr	x11, x13, #3
1000b9990:     	mul	x12, x8, x11
1000b9994:     	ubfx	x14, x13, #1, #2
1000b9998:     	orr	x12, x12, x14
1000b999c:     	ldrb	w12, [x1, x12]
1000b99a0:     	and	w15, w9, #0x4
1000b99a4:     	lsr	w12, w12, w15
1000b99a8:     	and	w16, w12, #0xf
1000b99ac:     	cmp	w16, #8
1000b99b0:     	csel	w16, wzr, w10, lo
1000b99b4:     	bfxil	w16, w12, #0, #4
1000b99b8:     	bfi	x14, x11, #4, #60
1000b99bc:     	add	x11, x0, x14
1000b99c0:     	ldrb	w12, [x11]
1000b99c4:     	lsr	w12, w12, w15
1000b99c8:     	scvtf	s4, w16
1000b99cc:     	and	w14, w12, #0xf
1000b99d0:     	cmp	w14, #8
1000b99d4:     	csel	w14, wzr, w10, lo
1000b99d8:     	bfxil	w14, w12, #0, #4
1000b99dc:     	scvtf	s5, w14
1000b99e0:     	fsub	s5, s5, s4
1000b99e4:     	fmadd	s2, s5, s5, s2
1000b99e8:     	str	s2, [x3]
1000b99ec:     	ldrb	w12, [x11, #4]
1000b99f0:     	lsr	w12, w12, w15
1000b99f4:     	and	w14, w12, #0xf
1000b99f8:     	cmp	w14, #8
1000b99fc:     	csel	w14, wzr, w10, lo
1000b9a00:     	bfxil	w14, w12, #0, #4
1000b9a04:     	scvtf	s5, w14
1000b9a08:     	fsub	s5, s5, s4
1000b9a0c:     	fmadd	s3, s5, s5, s3
1000b9a10:     	str	s3, [x3, #4]
1000b9a14:     	ldrb	w12, [x11, #8]
1000b9a18:     	lsr	w12, w12, w15
1000b9a1c:     	and	w14, w12, #0xf
1000b9a20:     	cmp	w14, #8
1000b9a24:     	csel	w14, wzr, w10, lo
1000b9a28:     	bfxil	w14, w12, #0, #4
1000b9a2c:     	scvtf	s5, w14
1000b9a30:     	fsub	s5, s5, s4
1000b9a34:     	fmadd	s0, s5, s5, s0
1000b9a38:     	str	s0, [x3, #8]
1000b9a3c:     	ldrb	w11, [x11, #12]
1000b9a40:     	lsr	w11, w11, w15
1000b9a44:     	and	w12, w11, #0xf
1000b9a48:     	cmp	w12, #8
1000b9a4c:     	csel	w12, wzr, w10, lo
1000b9a50:     	bfxil	w12, w11, #0, #4
1000b9a54:     	scvtf	s5, w12
1000b9a58:     	fsub	s4, s5, s4
1000b9a5c:     	fmadd	s1, s4, s4, s1
1000b9a60:     	str	s1, [x3, #12]
1000b9a64:     	add	x13, x13, #1
1000b9a68:     	add	w9, w9, #4
1000b9a6c:     	cmp	x2, x13
1000b9a70:     	b.ne	0x1000b998c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000b9a74:     	ldp	x20, x19, [sp, #32]
1000b9a78:     	ldp	x22, x21, [sp, #16]
1000b9a7c:     	ldp	x24, x23, [sp], #48
1000b9a80:     	ret

