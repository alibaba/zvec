00000001000b4890 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b4890:     	str	xzr, [x3]
1000b4894:     	lsl	x8, x4, #2
1000b4898:     	cmp	x2, #8
1000b489c:     	b.hs	0x1000b48b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000b48a0:     	mov	x12, #0
1000b48a4:     	movi	d1, #0000000000000000
1000b48a8:     	movi	d0, #0000000000000000
1000b48ac:     	b	0x1000b4a3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1ac>
1000b48b0:     	mov	x11, #0
1000b48b4:     	movi	d0, #0000000000000000
1000b48b8:     	adrp	x9, 0x100165000 <void run<unsigned char, 2ul, 2ul, false>(char const*)+0x98>
1000b48bc:     	add	x9, x9, #4060
1000b48c0:     	mov	x10, x1
1000b48c4:     	ldr	w12, [x10]
1000b48c8:     	add	x13, x0, x11
1000b48cc:     	ldr	w14, [x13]
1000b48d0:     	lsl	w15, w14, #4
1000b48d4:     	and	x15, x15, #0xf0
1000b48d8:     	bfxil	x15, x12, #0, #4
1000b48dc:     	and	x16, x14, #0xf0
1000b48e0:     	bfxil	x16, x12, #4, #4
1000b48e4:     	ldrsb	w16, [x9, x16]
1000b48e8:     	ldrsb	w15, [x9, x15]
1000b48ec:     	lsr	x17, x14, #4
1000b48f0:     	and	x17, x17, #0xf0
1000b48f4:     	bfxil	x17, x12, #8, #4
1000b48f8:     	ldrsb	w17, [x9, x17]
1000b48fc:     	lsr	x4, x14, #8
1000b4900:     	and	x4, x4, #0xf0
1000b4904:     	bfxil	x4, x12, #12, #4
1000b4908:     	ldrsb	w4, [x9, x4]
1000b490c:     	lsr	x5, x14, #12
1000b4910:     	and	x5, x5, #0xf0
1000b4914:     	bfxil	x5, x12, #16, #4
1000b4918:     	lsr	x6, x14, #16
1000b491c:     	ldrsb	w5, [x9, x5]
1000b4920:     	and	x6, x6, #0xf0
1000b4924:     	bfxil	x6, x12, #20, #4
1000b4928:     	ldrsb	w6, [x9, x6]
1000b492c:     	add	w15, w15, w16
1000b4930:     	add	w15, w15, w17
1000b4934:     	lsr	x16, x14, #20
1000b4938:     	and	x16, x16, #0xf0
1000b493c:     	bfxil	x16, x12, #24, #4
1000b4940:     	ldrsb	w16, [x9, x16]
1000b4944:     	add	w15, w15, w4
1000b4948:     	add	w15, w15, w5
1000b494c:     	lsr	x14, x14, #24
1000b4950:     	and	x14, x14, #0xf0
1000b4954:     	lsr	x17, x12, #28
1000b4958:     	add	w15, w15, w6
1000b495c:     	add	w15, w15, w16
1000b4960:     	orr	x14, x14, x17
1000b4964:     	ldrsb	w14, [x9, x14]
1000b4968:     	add	w14, w15, w14
1000b496c:     	scvtf	s1, w14
1000b4970:     	fadd	s0, s0, s1
1000b4974:     	str	s0, [x3]
1000b4978:     	ldr	w13, [x13, #4]
1000b497c:     	lsl	w14, w13, #4
1000b4980:     	and	x14, x14, #0xf0
1000b4984:     	bfxil	x14, x12, #0, #4
1000b4988:     	and	x15, x13, #0xf0
1000b498c:     	bfxil	x15, x12, #4, #4
1000b4990:     	lsr	x16, x13, #4
1000b4994:     	and	x16, x16, #0xf0
1000b4998:     	bfxil	x16, x12, #8, #4
1000b499c:     	lsr	x4, x13, #8
1000b49a0:     	and	x4, x4, #0xf0
1000b49a4:     	bfxil	x4, x12, #12, #4
1000b49a8:     	lsr	x5, x13, #12
1000b49ac:     	and	x5, x5, #0xf0
1000b49b0:     	bfxil	x5, x12, #16, #4
1000b49b4:     	lsr	x6, x13, #16
1000b49b8:     	and	x6, x6, #0xf0
1000b49bc:     	bfxil	x6, x12, #20, #4
1000b49c0:     	lsr	x7, x13, #20
1000b49c4:     	and	x7, x7, #0xf0
1000b49c8:     	bfxil	x7, x12, #24, #4
1000b49cc:     	ldrsb	w12, [x9, x14]
1000b49d0:     	ldrsb	w14, [x9, x15]
1000b49d4:     	ldrsb	w15, [x9, x16]
1000b49d8:     	ldrsb	w16, [x9, x4]
1000b49dc:     	ldrsb	w4, [x9, x5]
1000b49e0:     	add	w12, w12, w14
1000b49e4:     	add	w12, w12, w15
1000b49e8:     	ldrsb	w14, [x9, x6]
1000b49ec:     	ldrsb	w15, [x9, x7]
1000b49f0:     	add	w12, w12, w16
1000b49f4:     	add	w12, w12, w4
1000b49f8:     	lsr	x13, x13, #24
1000b49fc:     	and	x13, x13, #0xf0
1000b4a00:     	orr	x13, x13, x17
1000b4a04:     	ldrsb	w13, [x9, x13]
1000b4a08:     	add	w12, w12, w14
1000b4a0c:     	add	w12, w12, w15
1000b4a10:     	add	w12, w12, w13
1000b4a14:     	scvtf	s1, w12
1000b4a18:     	ldr	s2, [x3, #4]
1000b4a1c:     	fadd	s1, s2, s1
1000b4a20:     	str	s1, [x3, #4]
1000b4a24:     	add	x12, x11, #8
1000b4a28:     	add	x10, x10, x8
1000b4a2c:     	add	x13, x11, #16
1000b4a30:     	mov	x11, x12
1000b4a34:     	cmp	x13, x2
1000b4a38:     	b.ls	0x1000b48c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000b4a3c:     	cmp	x12, x2
1000b4a40:     	b.hs	0x1000b4ae0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x250>
1000b4a44:     	lsl	w9, w12, #2
1000b4a48:     	mov	w10, #-16
1000b4a4c:     	lsr	x11, x12, #3
1000b4a50:     	mul	x11, x8, x11
1000b4a54:     	ubfx	x13, x12, #1, #2
1000b4a58:     	orr	x11, x11, x13
1000b4a5c:     	ldrb	w11, [x1, x11]
1000b4a60:     	and	w13, w9, #0x4
1000b4a64:     	lsr	w11, w11, w13
1000b4a68:     	and	w14, w11, #0xf
1000b4a6c:     	cmp	w14, #8
1000b4a70:     	csel	w14, wzr, w10, lo
1000b4a74:     	and	x15, x12, #0xfffffffffffffff8
1000b4a78:     	bfxil	x15, x12, #1, #2
1000b4a7c:     	add	x15, x0, x15
1000b4a80:     	ldrb	w16, [x15]
1000b4a84:     	lsr	w16, w16, w13
1000b4a88:     	bfxil	w14, w11, #0, #4
1000b4a8c:     	and	w11, w16, #0xf
1000b4a90:     	cmp	w11, #8
1000b4a94:     	csel	w11, wzr, w10, lo
1000b4a98:     	bfxil	w11, w16, #0, #4
1000b4a9c:     	scvtf	s2, w14
1000b4aa0:     	scvtf	s3, w11
1000b4aa4:     	fmsub	s0, s3, s2, s0
1000b4aa8:     	str	s0, [x3]
1000b4aac:     	ldrb	w11, [x15, #4]
1000b4ab0:     	lsr	w11, w11, w13
1000b4ab4:     	and	w13, w11, #0xf
1000b4ab8:     	cmp	w13, #8
1000b4abc:     	csel	w13, wzr, w10, lo
1000b4ac0:     	bfxil	w13, w11, #0, #4
1000b4ac4:     	scvtf	s3, w13
1000b4ac8:     	fmsub	s1, s3, s2, s1
1000b4acc:     	str	s1, [x3, #4]
1000b4ad0:     	add	x12, x12, #1
1000b4ad4:     	add	w9, w9, #4
1000b4ad8:     	cmp	x2, x12
1000b4adc:     	b.ne	0x1000b4a4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1bc>
1000b4ae0:     	ret

