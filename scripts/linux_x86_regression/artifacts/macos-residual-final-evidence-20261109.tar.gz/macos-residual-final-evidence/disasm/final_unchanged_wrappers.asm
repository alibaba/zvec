
bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100043f50 <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
100043f50:     	b	0x100043f54 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>

0000000100118eb8 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
100118eb8:     	cbz	x2, 0x100118f18 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x60>
100118ebc:     	ldrsh	w8, [x1]
100118ec0:     	fmov	s0, w8
100118ec4:     	ldrsh	w8, [x1, #2]
100118ec8:     	mov.s	v0[1], w8
100118ecc:     	scvtf.2s	v0, v0
100118ed0:     	zip1.4s	v0, v0, v0
100118ed4:     	ldrsh	w8, [x0]
100118ed8:     	fmov	s1, w8
100118edc:     	ldrsh	w8, [x0, #2]
100118ee0:     	mov.s	v1[1], w8
100118ee4:     	scvtf.2s	v1, v1
100118ee8:     	mov.d	v1[1], v1[0]
100118eec:     	fsub.4s	v0, v1, v0
100118ef0:     	fmul.4s	v0, v0, v0
100118ef4:     	str	q0, [x3]
100118ef8:     	subs	x11, x2, #1
100118efc:     	b.eq	0x10011912c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x274>
100118f00:     	cmp	x2, #9
100118f04:     	b.hs	0x100118f20 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x68>
100118f08:     	mov	w8, #1
100118f0c:     	mov	x9, x1
100118f10:     	mov	x10, x0
100118f14:     	b	0x1001190d0 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x218>
100118f18:     	stp	xzr, xzr, [x3]
100118f1c:     	ret
100118f20:     	and	x12, x11, #0xfffffffffffffff8
100118f24:     	lsl	x8, x12, #2
100118f28:     	add	x9, x1, x8
100118f2c:     	add	x10, x0, x8
100118f30:     	orr	x8, x12, #0x1
100118f34:     	mov	s3, v0[1]
100118f38:     	mov	s2, v0[2]
100118f3c:     	mov	s1, v0[3]
100118f40:     	add	x13, x0, #4
100118f44:     	add	x14, x1, #4
100118f48:     	mov	x15, x12
100118f4c:     	ld2.8h	{ v4, v5 }, [x13], #32
100118f50:     	sshll2.4s	v6, v4, #0
100118f54:     	scvtf.4s	v6, v6
100118f58:     	sshll.4s	v7, v4, #0
100118f5c:     	scvtf.4s	v7, v7
100118f60:     	ld2.8h	{ v16, v17 }, [x14], #32
100118f64:     	sshll2.4s	v18, v16, #0
100118f68:     	scvtf.4s	v18, v18
100118f6c:     	sshll.4s	v19, v16, #0
100118f70:     	scvtf.4s	v19, v19
100118f74:     	sshll2.4s	v20, v17, #0
100118f78:     	sshll.4s	v16, v17, #0
100118f7c:     	sshll2.4s	v17, v5, #0
100118f80:     	sshll.4s	v4, v5, #0
100118f84:     	fsub.4s	v5, v7, v19
100118f88:     	scvtf.4s	v16, v16
100118f8c:     	fsub.4s	v7, v7, v16
100118f90:     	scvtf.4s	v4, v4
100118f94:     	fsub.4s	v19, v4, v19
100118f98:     	fsub.4s	v4, v4, v16
100118f9c:     	fsub.4s	v16, v6, v18
100118fa0:     	scvtf.4s	v20, v20
100118fa4:     	fsub.4s	v6, v6, v20
100118fa8:     	scvtf.4s	v17, v17
100118fac:     	fsub.4s	v18, v17, v18
100118fb0:     	fsub.4s	v17, v17, v20
100118fb4:     	fmul.4s	v4, v4, v4
100118fb8:     	mov	s20, v4[1]
100118fbc:     	fadd	s1, s1, s4
100118fc0:     	fadd	s1, s1, s20
100118fc4:     	mov	s20, v4[2]
100118fc8:     	fadd	s1, s1, s20
100118fcc:     	fmul.4s	v17, v17, v17
100118fd0:     	mov	s4, v4[3]
100118fd4:     	fadd	s1, s1, s4
100118fd8:     	mov	s4, v17[1]
100118fdc:     	fadd	s1, s1, s17
100118fe0:     	fadd	s1, s1, s4
100118fe4:     	mov	s4, v17[2]
100118fe8:     	fadd	s1, s1, s4
100118fec:     	fmul.4s	v4, v19, v19
100118ff0:     	mov	s17, v17[3]
100118ff4:     	fadd	s1, s1, s17
100118ff8:     	mov	s17, v4[1]
100118ffc:     	fadd	s3, s3, s4
100119000:     	fadd	s3, s3, s17
100119004:     	mov	s17, v4[2]
100119008:     	fadd	s3, s3, s17
10011900c:     	fmul.4s	v17, v18, v18
100119010:     	mov	s4, v4[3]
100119014:     	fadd	s3, s3, s4
100119018:     	mov	s4, v17[1]
10011901c:     	fadd	s3, s3, s17
100119020:     	fadd	s3, s3, s4
100119024:     	mov	s4, v17[2]
100119028:     	fadd	s3, s3, s4
10011902c:     	fmul.4s	v4, v7, v7
100119030:     	mov	s7, v17[3]
100119034:     	fadd	s3, s3, s7
100119038:     	mov	s7, v4[1]
10011903c:     	fadd	s2, s2, s4
100119040:     	fadd	s2, s2, s7
100119044:     	mov	s7, v4[2]
100119048:     	fadd	s2, s2, s7
10011904c:     	fmul.4s	v6, v6, v6
100119050:     	mov	s4, v4[3]
100119054:     	fadd	s2, s2, s4
100119058:     	mov	s4, v6[1]
10011905c:     	fadd	s2, s2, s6
100119060:     	fadd	s2, s2, s4
100119064:     	mov	s4, v6[2]
100119068:     	fadd	s2, s2, s4
10011906c:     	fmul.4s	v4, v5, v5
100119070:     	mov	s5, v6[3]
100119074:     	fadd	s2, s2, s5
100119078:     	mov	s5, v4[1]
10011907c:     	fadd	s0, s0, s4
100119080:     	fadd	s0, s0, s5
100119084:     	mov	s5, v4[2]
100119088:     	fadd	s0, s0, s5
10011908c:     	fmul.4s	v5, v16, v16
100119090:     	mov	s4, v4[3]
100119094:     	fadd	s0, s0, s4
100119098:     	mov	s4, v5[1]
10011909c:     	fadd	s0, s0, s5
1001190a0:     	fadd	s0, s0, s4
1001190a4:     	mov	s4, v5[3]
1001190a8:     	mov	s5, v5[2]
1001190ac:     	fadd	s0, s0, s5
1001190b0:     	fadd	s0, s0, s4
1001190b4:     	subs	x15, x15, #8
1001190b8:     	b.ne	0x100118f4c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x94>
1001190bc:     	mov.s	v0[1], v3[0]
1001190c0:     	mov.s	v0[2], v2[0]
1001190c4:     	mov.s	v0[3], v1[0]
1001190c8:     	cmp	x11, x12
1001190cc:     	b.eq	0x100119128 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x270>
1001190d0:     	add	x9, x9, #4
1001190d4:     	add	x10, x10, #4
1001190d8:     	sub	x8, x2, x8
1001190dc:     	ldrsh	w11, [x9]
1001190e0:     	fmov	s1, w11
1001190e4:     	ldrsh	w11, [x9, #2]
1001190e8:     	mov.s	v1[1], w11
1001190ec:     	scvtf.2s	v1, v1
1001190f0:     	zip1.4s	v1, v1, v1
1001190f4:     	ldrsh	w11, [x10]
1001190f8:     	fmov	s2, w11
1001190fc:     	ldrsh	w11, [x10, #2]
100119100:     	mov.s	v2[1], w11
100119104:     	scvtf.2s	v2, v2
100119108:     	mov.d	v2[1], v2[0]
10011910c:     	fsub.4s	v1, v2, v1
100119110:     	fmul.4s	v1, v1, v1
100119114:     	fadd.4s	v0, v0, v1
100119118:     	add	x9, x9, #4
10011911c:     	add	x10, x10, #4
100119120:     	subs	x8, x8, #1
100119124:     	b.ne	0x1001190dc <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x224>
100119128:     	str	q0, [x3]
10011912c:     	ret

0000000100119130 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100119130:     	cbz	x2, 0x1001191d0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0xa0>
100119134:     	ldrsh	w8, [x1, #2]
100119138:     	ldrsh	w9, [x1]
10011913c:     	fmov	s0, w9
100119140:     	mov.s	v0[1], w8
100119144:     	ldrsh	w8, [x0, #2]
100119148:     	ldrsh	w9, [x0]
10011914c:     	fmov	s1, w9
100119150:     	mov.s	v1[1], w8
100119154:     	mov.s	v1[2], w9
100119158:     	mov.s	v1[3], w8
10011915c:     	zip1.4s	v0, v0, v0
100119160:     	mul.4s	v0, v1, v0
100119164:     	scvtf.4s	v0, v0
100119168:     	fneg.4s	v0, v0
10011916c:     	str	q0, [x3]
100119170:     	subs	x8, x2, #1
100119174:     	b.eq	0x1001191cc <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x9c>
100119178:     	add	x9, x0, #4
10011917c:     	add	x10, x1, #4
100119180:     	ldrsh	w11, [x10, #2]
100119184:     	ldrsh	w12, [x10]
100119188:     	fmov	s1, w12
10011918c:     	mov.s	v1[1], w11
100119190:     	zip1.4s	v1, v1, v1
100119194:     	ldrsh	w11, [x9, #2]
100119198:     	ldrsh	w12, [x9]
10011919c:     	fmov	s2, w12
1001191a0:     	mov.s	v2[1], w11
1001191a4:     	mov.s	v2[2], w12
1001191a8:     	mov.s	v2[3], w11
1001191ac:     	mul.4s	v1, v2, v1
1001191b0:     	scvtf.4s	v1, v1
1001191b4:     	fsub.4s	v0, v0, v1
1001191b8:     	add	x9, x9, #4
1001191bc:     	add	x10, x10, #4
1001191c0:     	subs	x8, x8, #1
1001191c4:     	b.ne	0x100119180 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x50>
1001191c8:     	str	q0, [x3]
1001191cc:     	ret
1001191d0:     	stp	xzr, xzr, [x3]
1001191d4:     	ret
