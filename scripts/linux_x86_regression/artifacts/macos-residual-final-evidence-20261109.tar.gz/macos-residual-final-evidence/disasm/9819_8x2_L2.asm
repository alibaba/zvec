00000001000bf050 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bf050:     	sub	sp, sp, #208
1000bf054:     	stp	x28, x27, [sp, #112]
1000bf058:     	stp	x26, x25, [sp, #128]
1000bf05c:     	stp	x24, x23, [sp, #144]
1000bf060:     	stp	x22, x21, [sp, #160]
1000bf064:     	stp	x20, x19, [sp, #176]
1000bf068:     	stp	x29, x30, [sp, #192]
1000bf06c:     	add	x29, sp, #192
1000bf070:     	str	x3, [sp]
1000bf074:     	adrp	x8, 0x100168000 <void kernel<unsigned char, 8ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x90>
1000bf078:     	ldr	x8, [x8, #392]
1000bf07c:     	ldr	x8, [x8]
1000bf080:     	stur	x8, [x29, #-88]
1000bf084:     	movi.2d	v0, #0000000000000000
1000bf088:     	stp	q0, q0, [sp, #64]
1000bf08c:     	stp	q0, q0, [sp, #32]
1000bf090:     	ands	x8, x2, #0xfffffffffffffffe
1000bf094:     	b.eq	0x1000bf238 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e8>
1000bf098:     	add	x8, x1, x8
1000bf09c:     	str	x8, [sp, #8]
1000bf0a0:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>
1000bf0a4:     	add	x9, x9, #732
1000bf0a8:     	mov	x11, #0
1000bf0ac:     	ldp	w4, w23, [x1]
1000bf0b0:     	ubfx	x8, x4, #4, #4
1000bf0b4:     	stp	x1, x8, [sp, #16]
1000bf0b8:     	ubfx	x13, x4, #8, #4
1000bf0bc:     	and	x14, x4, #0xf
1000bf0c0:     	ubfx	x15, x4, #12, #4
1000bf0c4:     	ubfx	x16, x4, #16, #4
1000bf0c8:     	ubfx	x17, x4, #20, #4
1000bf0cc:     	ubfx	x2, x4, #24, #4
1000bf0d0:     	lsr	x4, x4, #28
1000bf0d4:     	and	x5, x23, #0xf
1000bf0d8:     	ubfx	x6, x23, #4, #4
1000bf0dc:     	ubfx	x7, x23, #8, #4
1000bf0e0:     	ubfx	x19, x23, #12, #4
1000bf0e4:     	ubfx	x20, x23, #16, #4
1000bf0e8:     	ubfx	x21, x23, #20, #4
1000bf0ec:     	ubfx	x22, x23, #24, #4
1000bf0f0:     	lsr	x23, x23, #28
1000bf0f4:     	ldr	w24, [x0, x11]
1000bf0f8:     	lsl	w25, w24, #4
1000bf0fc:     	and	x25, x25, #0xf0
1000bf100:     	orr	x26, x25, x14
1000bf104:     	ldrb	w26, [x9, x26]
1000bf108:     	and	x27, x24, #0xf0
1000bf10c:     	ldr	x8, [sp, #24]
1000bf110:     	orr	x28, x27, x8
1000bf114:     	ldrb	w28, [x9, x28]
1000bf118:     	lsr	x30, x24, #4
1000bf11c:     	and	x30, x30, #0xf0
1000bf120:     	orr	x8, x30, x13
1000bf124:     	ldrb	w8, [x9, x8]
1000bf128:     	add	w26, w26, w28
1000bf12c:     	add	w8, w26, w8
1000bf130:     	lsr	x26, x24, #8
1000bf134:     	and	x26, x26, #0xf0
1000bf138:     	orr	x28, x26, x15
1000bf13c:     	ldrb	w28, [x9, x28]
1000bf140:     	lsr	x3, x24, #12
1000bf144:     	and	x3, x3, #0xf0
1000bf148:     	orr	x10, x3, x16
1000bf14c:     	ldrb	w10, [x9, x10]
1000bf150:     	add	w8, w8, w28
1000bf154:     	add	w8, w8, w10
1000bf158:     	lsr	x10, x24, #16
1000bf15c:     	and	x10, x10, #0xf0
1000bf160:     	orr	x28, x10, x17
1000bf164:     	ldrb	w28, [x9, x28]
1000bf168:     	lsr	x1, x24, #20
1000bf16c:     	and	x1, x1, #0xf0
1000bf170:     	orr	x12, x1, x2
1000bf174:     	ldrb	w12, [x9, x12]
1000bf178:     	add	w8, w8, w28
1000bf17c:     	add	x28, sp, #32
1000bf180:     	add	w8, w8, w12
1000bf184:     	lsr	x12, x24, #24
1000bf188:     	and	x12, x12, #0xf0
1000bf18c:     	orr	x24, x12, x4
1000bf190:     	ldrb	w24, [x9, x24]
1000bf194:     	add	w8, w8, w24
1000bf198:     	scvtf	s0, w8
1000bf19c:     	add	x8, x28, x11
1000bf1a0:     	ldr	s1, [x8]
1000bf1a4:     	fadd	s0, s1, s0
1000bf1a8:     	orr	x24, x25, x5
1000bf1ac:     	ldrb	w24, [x9, x24]
1000bf1b0:     	orr	x25, x27, x6
1000bf1b4:     	ldrb	w25, [x9, x25]
1000bf1b8:     	orr	x27, x30, x7
1000bf1bc:     	ldrb	w27, [x9, x27]
1000bf1c0:     	add	w24, w24, w25
1000bf1c4:     	add	w24, w24, w27
1000bf1c8:     	orr	x25, x26, x19
1000bf1cc:     	ldrb	w25, [x9, x25]
1000bf1d0:     	orr	x3, x3, x20
1000bf1d4:     	ldrb	w3, [x9, x3]
1000bf1d8:     	orr	x10, x10, x21
1000bf1dc:     	ldrb	w10, [x9, x10]
1000bf1e0:     	add	w24, w24, w25
1000bf1e4:     	add	w3, w24, w3
1000bf1e8:     	orr	x1, x1, x22
1000bf1ec:     	ldrb	w1, [x9, x1]
1000bf1f0:     	add	w10, w3, w10
1000bf1f4:     	add	w10, w10, w1
1000bf1f8:     	orr	x12, x12, x23
1000bf1fc:     	ldrb	w12, [x9, x12]
1000bf200:     	add	w10, w10, w12
1000bf204:     	scvtf	s1, w10
1000bf208:     	str	s0, [x8]
1000bf20c:     	ldr	s0, [x8, #32]
1000bf210:     	fadd	s0, s0, s1
1000bf214:     	str	s0, [x8, #32]
1000bf218:     	add	x11, x11, #4
1000bf21c:     	cmp	x11, #32
1000bf220:     	b.ne	0x1000bf0f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000bf224:     	add	x0, x0, #32
1000bf228:     	ldp	x8, x1, [sp, #8]
1000bf22c:     	add	x1, x1, #8
1000bf230:     	cmp	x1, x8
1000bf234:     	b.ne	0x1000bf0a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000bf238:     	ldp	q0, q1, [sp, #32]
1000bf23c:     	ldr	x8, [sp]
1000bf240:     	stp	q0, q1, [x8]
1000bf244:     	ldp	q0, q1, [sp, #64]
1000bf248:     	stp	q0, q1, [x8, #32]
1000bf24c:     	ldur	x8, [x29, #-88]
1000bf250:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000bf254:     	ldr	x9, [x9, #392]
1000bf258:     	ldr	x9, [x9]
1000bf25c:     	cmp	x9, x8
1000bf260:     	b.ne	0x1000bf284 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x234>
1000bf264:     	ldp	x29, x30, [sp, #192]
1000bf268:     	ldp	x20, x19, [sp, #176]
1000bf26c:     	ldp	x22, x21, [sp, #160]
1000bf270:     	ldp	x24, x23, [sp, #144]
1000bf274:     	ldp	x26, x25, [sp, #128]
1000bf278:     	ldp	x28, x27, [sp, #112]
1000bf27c:     	add	sp, sp, #208
1000bf280:     	ret
1000bf284:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

