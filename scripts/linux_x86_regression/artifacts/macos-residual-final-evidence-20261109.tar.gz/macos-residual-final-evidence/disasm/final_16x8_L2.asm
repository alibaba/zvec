00000001000cc1c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cc1c4:     	stp	x28, x27, [sp, #-96]!
1000cc1c8:     	stp	x26, x25, [sp, #16]
1000cc1cc:     	stp	x24, x23, [sp, #32]
1000cc1d0:     	stp	x22, x21, [sp, #48]
1000cc1d4:     	stp	x20, x19, [sp, #64]
1000cc1d8:     	stp	x29, x30, [sp, #80]
1000cc1dc:     	add	x29, sp, #80
1000cc1e0:     	sub	sp, sp, #976
1000cc1e4:     	str	x3, [sp, #8]
1000cc1e8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a4>
1000cc1ec:     	ldr	x8, [x8, #392]
1000cc1f0:     	ldr	x8, [x8]
1000cc1f4:     	stur	x8, [x29, #-96]
1000cc1f8:     	movi.2d	v0, #0000000000000000
1000cc1fc:     	stp	q0, q0, [sp, #928]
1000cc200:     	lsl	x8, x2, #2
1000cc204:     	stp	q0, q0, [sp, #896]
1000cc208:     	stp	q0, q0, [sp, #864]
1000cc20c:     	stp	q0, q0, [sp, #832]
1000cc210:     	stp	q0, q0, [sp, #800]
1000cc214:     	stp	q0, q0, [sp, #768]
1000cc218:     	stp	q0, q0, [sp, #736]
1000cc21c:     	stp	q0, q0, [sp, #704]
1000cc220:     	stp	q0, q0, [sp, #672]
1000cc224:     	stp	q0, q0, [sp, #640]
1000cc228:     	stp	q0, q0, [sp, #608]
1000cc22c:     	stp	q0, q0, [sp, #576]
1000cc230:     	stp	q0, q0, [sp, #544]
1000cc234:     	stp	q0, q0, [sp, #512]
1000cc238:     	stp	q0, q0, [sp, #480]
1000cc23c:     	stp	q0, q0, [sp, #448]
1000cc240:     	ands	x8, x8, #0xfffffffffffffff8
1000cc244:     	b.eq	0x1000cc794 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cc248:     	add	x8, x1, x8
1000cc24c:     	str	x8, [sp, #16]
1000cc250:     	add	x8, sp, #448
1000cc254:     	add	x19, x8, #256
1000cc258:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000cc25c:     	add	x11, x11, #1212
1000cc260:     	mov	x12, #0
1000cc264:     	ldp	w8, w9, [x1]
1000cc268:     	ubfx	x10, x8, #8, #4
1000cc26c:     	str	x10, [sp, #440]
1000cc270:     	ubfx	x10, x8, #16, #4
1000cc274:     	str	x10, [sp, #432]
1000cc278:     	ubfx	x10, x8, #24, #4
1000cc27c:     	str	x10, [sp, #424]
1000cc280:     	ldp	w10, w13, [x1, #8]
1000cc284:     	and	x15, x8, #0xf
1000cc288:     	ubfx	x14, x8, #4, #4
1000cc28c:     	stp	x14, x15, [sp, #408]
1000cc290:     	ubfx	x15, x8, #12, #4
1000cc294:     	ubfx	x14, x8, #20, #4
1000cc298:     	stp	x14, x15, [sp, #392]
1000cc29c:     	lsr	x8, x8, #28
1000cc2a0:     	str	x8, [sp, #384]
1000cc2a4:     	and	x8, x9, #0xf
1000cc2a8:     	str	x8, [sp, #376]
1000cc2ac:     	ubfx	x8, x9, #8, #4
1000cc2b0:     	str	x8, [sp, #368]
1000cc2b4:     	ubfx	x8, x9, #16, #4
1000cc2b8:     	str	x8, [sp, #360]
1000cc2bc:     	ubfx	x8, x9, #24, #4
1000cc2c0:     	str	x8, [sp, #352]
1000cc2c4:     	ubfx	x8, x9, #4, #4
1000cc2c8:     	str	x8, [sp, #344]
1000cc2cc:     	ubfx	x8, x9, #12, #4
1000cc2d0:     	str	x8, [sp, #336]
1000cc2d4:     	ubfx	x8, x9, #20, #4
1000cc2d8:     	str	x8, [sp, #328]
1000cc2dc:     	lsr	x8, x9, #28
1000cc2e0:     	str	x8, [sp, #320]
1000cc2e4:     	and	x9, x10, #0xf
1000cc2e8:     	ubfx	x8, x10, #8, #4
1000cc2ec:     	stp	x8, x9, [sp, #304]
1000cc2f0:     	ubfx	x9, x10, #16, #4
1000cc2f4:     	ubfx	x8, x10, #24, #4
1000cc2f8:     	stp	x8, x9, [sp, #288]
1000cc2fc:     	ubfx	x9, x10, #4, #4
1000cc300:     	ubfx	x8, x10, #12, #4
1000cc304:     	stp	x8, x9, [sp, #272]
1000cc308:     	ubfx	x9, x10, #20, #4
1000cc30c:     	lsr	x8, x10, #28
1000cc310:     	stp	x8, x9, [sp, #256]
1000cc314:     	and	x9, x13, #0xf
1000cc318:     	ubfx	x8, x13, #8, #4
1000cc31c:     	stp	x8, x9, [sp, #240]
1000cc320:     	ubfx	x9, x13, #16, #4
1000cc324:     	ubfx	x8, x13, #24, #4
1000cc328:     	stp	x8, x9, [sp, #224]
1000cc32c:     	ubfx	x9, x13, #4, #4
1000cc330:     	ubfx	x8, x13, #12, #4
1000cc334:     	stp	x8, x9, [sp, #208]
1000cc338:     	ubfx	x9, x13, #20, #4
1000cc33c:     	lsr	x8, x13, #28
1000cc340:     	stp	x8, x9, [sp, #192]
1000cc344:     	ldp	w8, w9, [x1, #16]
1000cc348:     	and	x10, x8, #0xf
1000cc34c:     	str	x10, [sp, #184]
1000cc350:     	ubfx	x10, x8, #8, #4
1000cc354:     	str	x10, [sp, #176]
1000cc358:     	ubfx	x10, x8, #16, #4
1000cc35c:     	str	x10, [sp, #168]
1000cc360:     	ubfx	x10, x8, #24, #4
1000cc364:     	str	x10, [sp, #160]
1000cc368:     	ubfx	x10, x8, #4, #4
1000cc36c:     	str	x10, [sp, #152]
1000cc370:     	ubfx	x10, x8, #12, #4
1000cc374:     	str	x10, [sp, #144]
1000cc378:     	ubfx	x10, x8, #20, #4
1000cc37c:     	lsr	x8, x8, #28
1000cc380:     	stp	x8, x10, [sp, #128]
1000cc384:     	and	x10, x9, #0xf
1000cc388:     	ubfx	x8, x9, #8, #4
1000cc38c:     	stp	x8, x10, [sp, #112]
1000cc390:     	ubfx	x10, x9, #16, #4
1000cc394:     	ubfx	x8, x9, #24, #4
1000cc398:     	stp	x8, x10, [sp, #96]
1000cc39c:     	ubfx	x10, x9, #4, #4
1000cc3a0:     	ubfx	x8, x9, #12, #4
1000cc3a4:     	stp	x8, x10, [sp, #80]
1000cc3a8:     	ubfx	x10, x9, #20, #4
1000cc3ac:     	lsr	x8, x9, #28
1000cc3b0:     	stp	x8, x10, [sp, #64]
1000cc3b4:     	ldp	w14, w7, [x1, #24]
1000cc3b8:     	and	x9, x14, #0xf
1000cc3bc:     	ubfx	x8, x14, #8, #4
1000cc3c0:     	stp	x8, x9, [sp, #48]
1000cc3c4:     	ubfx	x8, x14, #16, #4
1000cc3c8:     	str	x8, [sp, #40]
1000cc3cc:     	ubfx	x8, x14, #24, #4
1000cc3d0:     	stp	x1, x8, [sp, #24]
1000cc3d4:     	ubfx	x10, x14, #4, #4
1000cc3d8:     	ubfx	x13, x14, #12, #4
1000cc3dc:     	ubfx	x9, x14, #20, #4
1000cc3e0:     	lsr	x14, x14, #28
1000cc3e4:     	and	x15, x7, #0xf
1000cc3e8:     	ubfx	x16, x7, #8, #4
1000cc3ec:     	ubfx	x17, x7, #16, #4
1000cc3f0:     	ubfx	x2, x7, #24, #4
1000cc3f4:     	ubfx	x4, x7, #4, #4
1000cc3f8:     	ubfx	x5, x7, #12, #4
1000cc3fc:     	ubfx	x6, x7, #20, #4
1000cc400:     	lsr	x7, x7, #28
1000cc404:     	ldr	w26, [x0, x12]
1000cc408:     	mov	x1, x19
1000cc40c:     	lsl	w19, w26, #4
1000cc410:     	and	x19, x19, #0xf0
1000cc414:     	add	x19, x11, x19
1000cc418:     	ldr	x8, [sp, #416]
1000cc41c:     	ldrb	w25, [x19, x8]
1000cc420:     	lsr	x20, x26, #4
1000cc424:     	and	x20, x20, #0xf0
1000cc428:     	add	x20, x11, x20
1000cc42c:     	ldr	x8, [sp, #440]
1000cc430:     	ldrb	w27, [x20, x8]
1000cc434:     	lsr	x21, x26, #12
1000cc438:     	and	x21, x21, #0xf0
1000cc43c:     	add	x21, x11, x21
1000cc440:     	ldr	x8, [sp, #432]
1000cc444:     	ldrb	w28, [x21, x8]
1000cc448:     	lsr	x22, x26, #20
1000cc44c:     	and	x22, x22, #0xf0
1000cc450:     	add	x23, x11, x22
1000cc454:     	ldr	x8, [sp, #424]
1000cc458:     	ldrb	w30, [x23, x8]
1000cc45c:     	and	x22, x26, #0xf0
1000cc460:     	add	x22, x11, x22
1000cc464:     	ldr	x8, [sp, #408]
1000cc468:     	ldrb	w3, [x22, x8]
1000cc46c:     	lsr	x24, x26, #8
1000cc470:     	and	x24, x24, #0xf0
1000cc474:     	add	x24, x11, x24
1000cc478:     	ldr	x8, [sp, #400]
1000cc47c:     	ldrb	w8, [x24, x8]
1000cc480:     	add	w27, w25, w27
1000cc484:     	lsr	x25, x26, #16
1000cc488:     	and	x25, x25, #0xf0
1000cc48c:     	add	x25, x11, x25
1000cc490:     	add	w27, w27, w28
1000cc494:     	ldr	x28, [sp, #392]
1000cc498:     	ldrb	w28, [x25, x28]
1000cc49c:     	lsr	x26, x26, #24
1000cc4a0:     	and	x26, x26, #0xf0
1000cc4a4:     	add	x26, x11, x26
1000cc4a8:     	add	w27, w27, w30
1000cc4ac:     	ldr	x30, [sp, #384]
1000cc4b0:     	ldrb	w30, [x26, x30]
1000cc4b4:     	add	w3, w27, w3
1000cc4b8:     	add	w8, w3, w8
1000cc4bc:     	add	w8, w8, w28
1000cc4c0:     	add	w8, w8, w30
1000cc4c4:     	scvtf	s0, w8
1000cc4c8:     	ldp	x3, x8, [sp, #368]
1000cc4cc:     	ldrb	w8, [x19, x8]
1000cc4d0:     	ldrb	w3, [x20, x3]
1000cc4d4:     	ldp	x28, x27, [sp, #352]
1000cc4d8:     	ldrb	w27, [x21, x27]
1000cc4dc:     	ldrb	w28, [x23, x28]
1000cc4e0:     	ldr	x30, [sp, #344]
1000cc4e4:     	ldrb	w30, [x22, x30]
1000cc4e8:     	add	w8, w8, w3
1000cc4ec:     	ldr	x3, [sp, #336]
1000cc4f0:     	ldrb	w3, [x24, x3]
1000cc4f4:     	add	w8, w8, w27
1000cc4f8:     	ldr	x27, [sp, #328]
1000cc4fc:     	ldrb	w27, [x25, x27]
1000cc500:     	add	w8, w8, w28
1000cc504:     	ldr	x28, [sp, #320]
1000cc508:     	ldrb	w28, [x26, x28]
1000cc50c:     	add	w8, w8, w30
1000cc510:     	add	w8, w8, w3
1000cc514:     	add	w8, w8, w27
1000cc518:     	add	w8, w8, w28
1000cc51c:     	scvtf	s1, w8
1000cc520:     	ldp	x3, x8, [sp, #304]
1000cc524:     	ldrb	w8, [x19, x8]
1000cc528:     	ldrb	w3, [x20, x3]
1000cc52c:     	ldp	x28, x27, [sp, #288]
1000cc530:     	ldrb	w27, [x21, x27]
1000cc534:     	ldrb	w28, [x23, x28]
1000cc538:     	add	w8, w8, w3
1000cc53c:     	ldr	x3, [sp, #280]
1000cc540:     	ldrb	w3, [x22, x3]
1000cc544:     	add	w8, w8, w27
1000cc548:     	ldr	x27, [sp, #272]
1000cc54c:     	ldrb	w27, [x24, x27]
1000cc550:     	add	w8, w8, w28
1000cc554:     	ldr	x28, [sp, #264]
1000cc558:     	ldrb	w28, [x25, x28]
1000cc55c:     	add	w8, w8, w3
1000cc560:     	ldr	x3, [sp, #256]
1000cc564:     	ldrb	w3, [x26, x3]
1000cc568:     	add	w8, w8, w27
1000cc56c:     	add	w8, w8, w28
1000cc570:     	add	w8, w8, w3
1000cc574:     	scvtf	s2, w8
1000cc578:     	ldp	x3, x8, [sp, #240]
1000cc57c:     	ldrb	w8, [x19, x8]
1000cc580:     	ldrb	w3, [x20, x3]
1000cc584:     	ldp	x28, x27, [sp, #224]
1000cc588:     	ldrb	w27, [x21, x27]
1000cc58c:     	ldrb	w28, [x23, x28]
1000cc590:     	add	w8, w8, w3
1000cc594:     	ldr	x3, [sp, #216]
1000cc598:     	ldrb	w3, [x22, x3]
1000cc59c:     	add	w8, w8, w27
1000cc5a0:     	ldr	x27, [sp, #208]
1000cc5a4:     	ldrb	w27, [x24, x27]
1000cc5a8:     	add	w8, w8, w28
1000cc5ac:     	ldr	x28, [sp, #200]
1000cc5b0:     	ldrb	w28, [x25, x28]
1000cc5b4:     	add	w8, w8, w3
1000cc5b8:     	ldr	x3, [sp, #192]
1000cc5bc:     	ldrb	w3, [x26, x3]
1000cc5c0:     	add	w8, w8, w27
1000cc5c4:     	add	w8, w8, w28
1000cc5c8:     	add	w8, w8, w3
1000cc5cc:     	scvtf	s3, w8
1000cc5d0:     	ldp	x3, x8, [sp, #176]
1000cc5d4:     	ldrb	w8, [x19, x8]
1000cc5d8:     	ldrb	w3, [x20, x3]
1000cc5dc:     	ldp	x28, x27, [sp, #160]
1000cc5e0:     	ldrb	w27, [x21, x27]
1000cc5e4:     	ldrb	w28, [x23, x28]
1000cc5e8:     	add	w8, w8, w3
1000cc5ec:     	add	w8, w8, w27
1000cc5f0:     	ldr	x3, [sp, #152]
1000cc5f4:     	ldrb	w3, [x22, x3]
1000cc5f8:     	add	w8, w8, w28
1000cc5fc:     	add	w8, w8, w3
1000cc600:     	ldp	x27, x3, [sp, #136]
1000cc604:     	ldrb	w3, [x24, x3]
1000cc608:     	ldrb	w27, [x25, x27]
1000cc60c:     	add	w8, w8, w3
1000cc610:     	add	w8, w8, w27
1000cc614:     	ldr	x3, [sp, #128]
1000cc618:     	ldrb	w3, [x26, x3]
1000cc61c:     	add	w8, w8, w3
1000cc620:     	scvtf	s4, w8
1000cc624:     	ldp	x3, x8, [sp, #112]
1000cc628:     	ldrb	w8, [x19, x8]
1000cc62c:     	ldrb	w3, [x20, x3]
1000cc630:     	ldp	x28, x27, [sp, #96]
1000cc634:     	ldrb	w27, [x21, x27]
1000cc638:     	ldrb	w28, [x23, x28]
1000cc63c:     	add	w8, w8, w3
1000cc640:     	ldr	x3, [sp, #88]
1000cc644:     	ldrb	w3, [x22, x3]
1000cc648:     	add	w8, w8, w27
1000cc64c:     	ldr	x27, [sp, #80]
1000cc650:     	ldrb	w27, [x24, x27]
1000cc654:     	add	w8, w8, w28
1000cc658:     	ldr	x28, [sp, #72]
1000cc65c:     	ldrb	w28, [x25, x28]
1000cc660:     	add	w8, w8, w3
1000cc664:     	add	w8, w8, w27
1000cc668:     	add	w8, w8, w28
1000cc66c:     	ldr	x3, [sp, #64]
1000cc670:     	ldrb	w3, [x26, x3]
1000cc674:     	add	w8, w8, w3
1000cc678:     	scvtf	s5, w8
1000cc67c:     	ldp	x3, x8, [sp, #48]
1000cc680:     	ldrb	w8, [x19, x8]
1000cc684:     	ldrb	w3, [x20, x3]
1000cc688:     	ldr	x27, [sp, #40]
1000cc68c:     	ldrb	w27, [x21, x27]
1000cc690:     	add	w8, w8, w3
1000cc694:     	ldr	x3, [sp, #32]
1000cc698:     	ldrb	w3, [x23, x3]
1000cc69c:     	add	w8, w8, w27
1000cc6a0:     	ldrb	w27, [x22, x10]
1000cc6a4:     	add	w8, w8, w3
1000cc6a8:     	ldrb	w3, [x24, x13]
1000cc6ac:     	add	w8, w8, w27
1000cc6b0:     	ldrb	w27, [x25, x9]
1000cc6b4:     	add	w8, w8, w3
1000cc6b8:     	ldrb	w3, [x26, x14]
1000cc6bc:     	add	w8, w8, w27
1000cc6c0:     	add	w8, w8, w3
1000cc6c4:     	scvtf	s6, w8
1000cc6c8:     	ldrb	w8, [x19, x15]
1000cc6cc:     	ldrb	w3, [x20, x16]
1000cc6d0:     	ldrb	w19, [x21, x17]
1000cc6d4:     	add	w8, w8, w3
1000cc6d8:     	add	w8, w8, w19
1000cc6dc:     	ldrb	w3, [x23, x2]
1000cc6e0:     	ldrb	w19, [x22, x4]
1000cc6e4:     	add	w8, w8, w3
1000cc6e8:     	add	w8, w8, w19
1000cc6ec:     	ldrb	w3, [x24, x5]
1000cc6f0:     	ldrb	w19, [x25, x6]
1000cc6f4:     	add	w8, w8, w3
1000cc6f8:     	add	w8, w8, w19
1000cc6fc:     	mov	x19, x1
1000cc700:     	ldrb	w3, [x26, x7]
1000cc704:     	add	w8, w8, w3
1000cc708:     	add	x3, sp, #448
1000cc70c:     	scvtf	s7, w8
1000cc710:     	add	x8, x1, x12
1000cc714:     	ldur	s16, [x8, #-192]
1000cc718:     	fadd	s1, s16, s1
1000cc71c:     	stur	s1, [x8, #-192]
1000cc720:     	ldur	s1, [x8, #-128]
1000cc724:     	fadd	s1, s1, s2
1000cc728:     	stur	s1, [x8, #-128]
1000cc72c:     	ldur	s1, [x8, #-64]
1000cc730:     	fadd	s1, s1, s3
1000cc734:     	stur	s1, [x8, #-64]
1000cc738:     	ldr	s1, [x8]
1000cc73c:     	fadd	s1, s1, s4
1000cc740:     	str	s1, [x8]
1000cc744:     	ldr	s1, [x8, #64]
1000cc748:     	fadd	s1, s1, s5
1000cc74c:     	str	s1, [x8, #64]
1000cc750:     	ldr	s1, [x8, #128]
1000cc754:     	fadd	s1, s1, s6
1000cc758:     	str	s1, [x8, #128]
1000cc75c:     	ldr	s1, [x8, #192]
1000cc760:     	fadd	s1, s1, s7
1000cc764:     	ldr	s2, [x3, x12]
1000cc768:     	str	s1, [x8, #192]
1000cc76c:     	fadd	s0, s2, s0
1000cc770:     	str	s0, [x3, x12]
1000cc774:     	add	x12, x12, #4
1000cc778:     	cmp	x12, #64
1000cc77c:     	b.ne	0x1000cc404 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000cc780:     	add	x0, x0, #64
1000cc784:     	ldp	x8, x1, [sp, #16]
1000cc788:     	add	x1, x1, #32
1000cc78c:     	cmp	x1, x8
1000cc790:     	b.ne	0x1000cc260 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000cc794:     	add	x1, sp, #448
1000cc798:     	ldr	x0, [sp, #8]
1000cc79c:     	mov	w2, #512
1000cc7a0:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000cc7a4:     	ldur	x8, [x29, #-96]
1000cc7a8:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x98>
1000cc7ac:     	ldr	x9, [x9, #392]
1000cc7b0:     	ldr	x9, [x9]
1000cc7b4:     	cmp	x9, x8
1000cc7b8:     	b.ne	0x1000cc7dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000cc7bc:     	add	sp, sp, #976
1000cc7c0:     	ldp	x29, x30, [sp, #80]
1000cc7c4:     	ldp	x20, x19, [sp, #64]
1000cc7c8:     	ldp	x22, x21, [sp, #48]
1000cc7cc:     	ldp	x24, x23, [sp, #32]
1000cc7d0:     	ldp	x26, x25, [sp, #16]
1000cc7d4:     	ldp	x28, x27, [sp], #96
1000cc7d8:     	ret
1000cc7dc:     	bl	0x100163694 <_strcmp+0x100163694>

