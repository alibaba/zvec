00000001000bba00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bba00:     	sub	sp, sp, #352
1000bba04:     	stp	x28, x27, [sp, #256]
1000bba08:     	stp	x26, x25, [sp, #272]
1000bba0c:     	stp	x24, x23, [sp, #288]
1000bba10:     	stp	x22, x21, [sp, #304]
1000bba14:     	stp	x20, x19, [sp, #320]
1000bba18:     	stp	x29, x30, [sp, #336]
1000bba1c:     	add	x29, sp, #336
1000bba20:     	str	x3, [sp]
1000bba24:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2d8>
1000bba28:     	ldr	x8, [x8, #392]
1000bba2c:     	ldr	x8, [x8]
1000bba30:     	stur	x8, [x29, #-96]
1000bba34:     	movi.2d	v0, #0000000000000000
1000bba38:     	stp	q0, q0, [x29, #-128]
1000bba3c:     	lsl	x8, x2, #1
1000bba40:     	stp	q0, q0, [x29, #-160]
1000bba44:     	ands	x8, x8, #0xfffffffffffffffc
1000bba48:     	b.eq	0x1000bbd70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bba4c:     	add	x8, x1, x8
1000bba50:     	str	x8, [sp, #8]
1000bba54:     	sub	x8, x29, #160
1000bba58:     	add	x27, x8, #32
1000bba5c:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000bba60:     	add	x11, x11, #476
1000bba64:     	mov	x12, #0
1000bba68:     	ldp	w8, w9, [x1]
1000bba6c:     	ubfx	x10, x8, #4, #4
1000bba70:     	str	x10, [sp, #168]
1000bba74:     	ubfx	x10, x8, #8, #4
1000bba78:     	str	x10, [sp, #160]
1000bba7c:     	and	x10, x8, #0xf
1000bba80:     	str	x10, [sp, #152]
1000bba84:     	ubfx	x10, x8, #12, #4
1000bba88:     	str	x10, [sp, #144]
1000bba8c:     	ubfx	x10, x8, #16, #4
1000bba90:     	str	x10, [sp, #136]
1000bba94:     	ubfx	x10, x8, #20, #4
1000bba98:     	str	x10, [sp, #128]
1000bba9c:     	ubfx	x10, x8, #24, #4
1000bbaa0:     	lsr	x8, x8, #28
1000bbaa4:     	stp	x8, x10, [sp, #112]
1000bbaa8:     	and	x10, x9, #0xf
1000bbaac:     	ubfx	x8, x9, #4, #4
1000bbab0:     	stp	x8, x10, [sp, #96]
1000bbab4:     	ubfx	x10, x9, #8, #4
1000bbab8:     	ubfx	x8, x9, #12, #4
1000bbabc:     	stp	x8, x10, [sp, #80]
1000bbac0:     	ubfx	x10, x9, #16, #4
1000bbac4:     	ubfx	x8, x9, #20, #4
1000bbac8:     	stp	x8, x10, [sp, #64]
1000bbacc:     	ubfx	x10, x9, #24, #4
1000bbad0:     	lsr	x8, x9, #28
1000bbad4:     	stp	x8, x10, [sp, #48]
1000bbad8:     	ldp	w9, w17, [x1, #8]
1000bbadc:     	and	x10, x9, #0xf
1000bbae0:     	ubfx	x8, x9, #4, #4
1000bbae4:     	stp	x8, x10, [sp, #32]
1000bbae8:     	ubfx	x8, x9, #8, #4
1000bbaec:     	stp	x1, x8, [sp, #16]
1000bbaf0:     	ubfx	x28, x9, #12, #4
1000bbaf4:     	ubfx	x30, x9, #16, #4
1000bbaf8:     	ubfx	x8, x9, #20, #4
1000bbafc:     	ubfx	x3, x9, #24, #4
1000bbb00:     	lsr	x9, x9, #28
1000bbb04:     	and	x1, x17, #0xf
1000bbb08:     	ubfx	x10, x17, #4, #4
1000bbb0c:     	ubfx	x13, x17, #8, #4
1000bbb10:     	ubfx	x26, x17, #12, #4
1000bbb14:     	ubfx	x14, x17, #16, #4
1000bbb18:     	ubfx	x15, x17, #20, #4
1000bbb1c:     	ubfx	x16, x17, #24, #4
1000bbb20:     	lsr	x17, x17, #28
1000bbb24:     	ldr	w21, [x0, x12]
1000bbb28:     	lsl	w2, w21, #4
1000bbb2c:     	and	x2, x2, #0xf0
1000bbb30:     	ldp	x4, x19, [sp, #152]
1000bbb34:     	orr	x4, x2, x4
1000bbb38:     	ldrsb	w6, [x11, x4]
1000bbb3c:     	and	x4, x21, #0xf0
1000bbb40:     	ldr	x5, [sp, #168]
1000bbb44:     	orr	x5, x4, x5
1000bbb48:     	ldrsb	w7, [x11, x5]
1000bbb4c:     	lsr	x5, x21, #4
1000bbb50:     	and	x5, x5, #0xf0
1000bbb54:     	orr	x19, x5, x19
1000bbb58:     	ldrsb	w19, [x11, x19]
1000bbb5c:     	add	w6, w6, w7
1000bbb60:     	add	w19, w6, w19
1000bbb64:     	lsr	x6, x21, #8
1000bbb68:     	and	x6, x6, #0xf0
1000bbb6c:     	ldp	x22, x7, [sp, #136]
1000bbb70:     	orr	x7, x6, x7
1000bbb74:     	ldrsb	w20, [x11, x7]
1000bbb78:     	lsr	x7, x21, #12
1000bbb7c:     	and	x7, x7, #0xf0
1000bbb80:     	orr	x22, x7, x22
1000bbb84:     	ldrsb	w22, [x11, x22]
1000bbb88:     	add	w19, w19, w20
1000bbb8c:     	add	w22, w19, w22
1000bbb90:     	lsr	x19, x21, #16
1000bbb94:     	and	x19, x19, #0xf0
1000bbb98:     	ldp	x24, x20, [sp, #120]
1000bbb9c:     	orr	x20, x19, x20
1000bbba0:     	ldrsb	w23, [x11, x20]
1000bbba4:     	lsr	x20, x21, #20
1000bbba8:     	and	x20, x20, #0xf0
1000bbbac:     	orr	x24, x20, x24
1000bbbb0:     	ldrsb	w24, [x11, x24]
1000bbbb4:     	add	w22, w22, w23
1000bbbb8:     	add	w22, w22, w24
1000bbbbc:     	lsr	x21, x21, #24
1000bbbc0:     	and	x21, x21, #0xf0
1000bbbc4:     	ldr	x23, [sp, #112]
1000bbbc8:     	orr	x23, x21, x23
1000bbbcc:     	ldrsb	w23, [x11, x23]
1000bbbd0:     	add	w22, w22, w23
1000bbbd4:     	scvtf	s0, w22
1000bbbd8:     	ldp	x23, x22, [sp, #96]
1000bbbdc:     	orr	x22, x2, x22
1000bbbe0:     	ldrsb	w22, [x11, x22]
1000bbbe4:     	orr	x23, x4, x23
1000bbbe8:     	ldrsb	w23, [x11, x23]
1000bbbec:     	ldr	x24, [sp, #88]
1000bbbf0:     	orr	x24, x5, x24
1000bbbf4:     	ldrsb	w24, [x11, x24]
1000bbbf8:     	add	w22, w22, w23
1000bbbfc:     	add	w22, w22, w24
1000bbc00:     	ldp	x24, x23, [sp, #72]
1000bbc04:     	orr	x23, x6, x23
1000bbc08:     	ldrsb	w23, [x11, x23]
1000bbc0c:     	orr	x24, x7, x24
1000bbc10:     	ldrsb	w24, [x11, x24]
1000bbc14:     	ldr	x25, [sp, #64]
1000bbc18:     	orr	x25, x19, x25
1000bbc1c:     	ldrsb	w25, [x11, x25]
1000bbc20:     	add	w22, w22, w23
1000bbc24:     	add	w22, w22, w24
1000bbc28:     	ldr	x23, [sp, #56]
1000bbc2c:     	orr	x23, x20, x23
1000bbc30:     	ldrsb	w23, [x11, x23]
1000bbc34:     	add	w22, w22, w25
1000bbc38:     	add	w22, w22, w23
1000bbc3c:     	ldr	x23, [sp, #48]
1000bbc40:     	orr	x23, x21, x23
1000bbc44:     	ldrsb	w23, [x11, x23]
1000bbc48:     	add	w22, w22, w23
1000bbc4c:     	scvtf	s1, w22
1000bbc50:     	ldp	x23, x22, [sp, #32]
1000bbc54:     	orr	x22, x2, x22
1000bbc58:     	ldrsb	w22, [x11, x22]
1000bbc5c:     	orr	x23, x4, x23
1000bbc60:     	ldrsb	w23, [x11, x23]
1000bbc64:     	ldr	x24, [sp, #24]
1000bbc68:     	orr	x24, x5, x24
1000bbc6c:     	ldrsb	w24, [x11, x24]
1000bbc70:     	add	w22, w22, w23
1000bbc74:     	add	w22, w22, w24
1000bbc78:     	orr	x23, x6, x28
1000bbc7c:     	ldrsb	w23, [x11, x23]
1000bbc80:     	orr	x24, x7, x30
1000bbc84:     	ldrsb	w24, [x11, x24]
1000bbc88:     	orr	x25, x19, x8
1000bbc8c:     	ldrsb	w25, [x11, x25]
1000bbc90:     	add	w22, w22, w23
1000bbc94:     	orr	x23, x20, x3
1000bbc98:     	ldrsb	w23, [x11, x23]
1000bbc9c:     	add	w22, w22, w24
1000bbca0:     	add	w22, w22, w25
1000bbca4:     	add	w22, w22, w23
1000bbca8:     	orr	x23, x21, x9
1000bbcac:     	ldrsb	w23, [x11, x23]
1000bbcb0:     	add	w22, w22, w23
1000bbcb4:     	scvtf	s2, w22
1000bbcb8:     	orr	x2, x2, x1
1000bbcbc:     	ldrsb	w2, [x11, x2]
1000bbcc0:     	orr	x4, x4, x10
1000bbcc4:     	ldrsb	w4, [x11, x4]
1000bbcc8:     	orr	x5, x5, x13
1000bbccc:     	ldrsb	w5, [x11, x5]
1000bbcd0:     	add	w2, w2, w4
1000bbcd4:     	add	w2, w2, w5
1000bbcd8:     	orr	x4, x6, x26
1000bbcdc:     	ldrsb	w4, [x11, x4]
1000bbce0:     	orr	x5, x7, x14
1000bbce4:     	ldrsb	w5, [x11, x5]
1000bbce8:     	add	w2, w2, w4
1000bbcec:     	orr	x4, x19, x15
1000bbcf0:     	ldrsb	w4, [x11, x4]
1000bbcf4:     	add	w2, w2, w5
1000bbcf8:     	orr	x5, x20, x16
1000bbcfc:     	ldrsb	w5, [x11, x5]
1000bbd00:     	add	w2, w2, w4
1000bbd04:     	add	w2, w2, w5
1000bbd08:     	orr	x4, x21, x17
1000bbd0c:     	ldrsb	w4, [x11, x4]
1000bbd10:     	add	w2, w2, w4
1000bbd14:     	sub	x4, x29, #160
1000bbd18:     	scvtf	s3, w2
1000bbd1c:     	add	x2, x27, x12
1000bbd20:     	ldur	s4, [x2, #-16]
1000bbd24:     	fadd	s1, s4, s1
1000bbd28:     	stur	s1, [x2, #-16]
1000bbd2c:     	ldr	s1, [x2]
1000bbd30:     	fadd	s1, s1, s2
1000bbd34:     	str	s1, [x2]
1000bbd38:     	ldr	s1, [x2, #16]
1000bbd3c:     	fadd	s1, s1, s3
1000bbd40:     	ldr	s2, [x4, x12]
1000bbd44:     	str	s1, [x2, #16]
1000bbd48:     	fadd	s0, s2, s0
1000bbd4c:     	str	s0, [x4, x12]
1000bbd50:     	add	x12, x12, #4
1000bbd54:     	cmp	x12, #16
1000bbd58:     	b.ne	0x1000bbb24 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bbd5c:     	add	x0, x0, #16
1000bbd60:     	ldp	x8, x1, [sp, #8]
1000bbd64:     	add	x1, x1, #16
1000bbd68:     	cmp	x1, x8
1000bbd6c:     	b.ne	0x1000bba64 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bbd70:     	ldp	q0, q1, [x29, #-160]
1000bbd74:     	ldr	x8, [sp]
1000bbd78:     	stp	q0, q1, [x8]
1000bbd7c:     	ldp	q0, q1, [x29, #-128]
1000bbd80:     	stp	q0, q1, [x8, #32]
1000bbd84:     	ldur	x8, [x29, #-96]
1000bbd88:     	adrp	x9, 0x100168000 <void run<unsigned char, 8ul, 1ul, false>(char const*)+0x27c>
1000bbd8c:     	ldr	x9, [x9, #392]
1000bbd90:     	ldr	x9, [x9]
1000bbd94:     	cmp	x9, x8
1000bbd98:     	b.ne	0x1000bbdbc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bbd9c:     	ldp	x29, x30, [sp, #336]
1000bbda0:     	ldp	x20, x19, [sp, #320]
1000bbda4:     	ldp	x22, x21, [sp, #304]
1000bbda8:     	ldp	x24, x23, [sp, #288]
1000bbdac:     	ldp	x26, x25, [sp, #272]
1000bbdb0:     	ldp	x28, x27, [sp, #256]
1000bbdb4:     	add	sp, sp, #352
1000bbdb8:     	ret
1000bbdbc:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

