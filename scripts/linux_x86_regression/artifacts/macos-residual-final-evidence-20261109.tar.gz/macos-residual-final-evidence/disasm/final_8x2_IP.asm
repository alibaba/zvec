00000001000c146c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c146c:     	sub	sp, sp, #208
1000c1470:     	stp	x28, x27, [sp, #112]
1000c1474:     	stp	x26, x25, [sp, #128]
1000c1478:     	stp	x24, x23, [sp, #144]
1000c147c:     	stp	x22, x21, [sp, #160]
1000c1480:     	stp	x20, x19, [sp, #176]
1000c1484:     	stp	x29, x30, [sp, #192]
1000c1488:     	add	x29, sp, #192
1000c148c:     	str	x3, [sp]
1000c1490:     	adrp	x8, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xb8>
1000c1494:     	ldr	x8, [x8, #392]
1000c1498:     	ldr	x8, [x8]
1000c149c:     	stur	x8, [x29, #-88]
1000c14a0:     	movi.2d	v0, #0000000000000000
1000c14a4:     	stp	q0, q0, [sp, #64]
1000c14a8:     	stp	q0, q0, [sp, #32]
1000c14ac:     	ands	x8, x2, #0xfffffffffffffffe
1000c14b0:     	b.eq	0x1000c1634 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c14b4:     	add	x8, x1, x8
1000c14b8:     	str	x8, [sp, #8]
1000c14bc:     	adrp	x9, 0x10016a000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xdc>
1000c14c0:     	add	x9, x9, #956
1000c14c4:     	mov	x11, #0
1000c14c8:     	ldp	w4, w23, [x1]
1000c14cc:     	ubfx	x8, x4, #8, #4
1000c14d0:     	stp	x1, x8, [sp, #16]
1000c14d4:     	ubfx	x13, x4, #16, #4
1000c14d8:     	and	x14, x4, #0xf
1000c14dc:     	ubfx	x15, x4, #24, #4
1000c14e0:     	ubfx	x16, x4, #4, #4
1000c14e4:     	ubfx	x17, x4, #12, #4
1000c14e8:     	ubfx	x2, x4, #20, #4
1000c14ec:     	lsr	x4, x4, #28
1000c14f0:     	and	x5, x23, #0xf
1000c14f4:     	ubfx	x6, x23, #8, #4
1000c14f8:     	ubfx	x7, x23, #16, #4
1000c14fc:     	ubfx	x19, x23, #24, #4
1000c1500:     	ubfx	x20, x23, #4, #4
1000c1504:     	ubfx	x21, x23, #12, #4
1000c1508:     	ubfx	x22, x23, #20, #4
1000c150c:     	lsr	x23, x23, #28
1000c1510:     	ldr	w24, [x0, x11]
1000c1514:     	lsl	w25, w24, #4
1000c1518:     	and	x25, x25, #0xf0
1000c151c:     	add	x25, x9, x25
1000c1520:     	and	x26, x24, #0xf0
1000c1524:     	add	x26, x9, x26
1000c1528:     	lsr	x27, x24, #4
1000c152c:     	and	x27, x27, #0xf0
1000c1530:     	add	x27, x9, x27
1000c1534:     	lsr	x28, x24, #8
1000c1538:     	and	x28, x28, #0xf0
1000c153c:     	add	x28, x9, x28
1000c1540:     	lsr	x30, x24, #12
1000c1544:     	and	x30, x30, #0xf0
1000c1548:     	add	x30, x9, x30
1000c154c:     	lsr	x8, x24, #16
1000c1550:     	and	x8, x8, #0xf0
1000c1554:     	add	x8, x9, x8
1000c1558:     	lsr	x3, x24, #20
1000c155c:     	and	x3, x3, #0xf0
1000c1560:     	add	x3, x9, x3
1000c1564:     	lsr	x24, x24, #24
1000c1568:     	and	x24, x24, #0xf0
1000c156c:     	ldrsb	w10, [x25, x14]
1000c1570:     	ldr	x12, [sp, #24]
1000c1574:     	ldrsb	w1, [x27, x12]
1000c1578:     	ldrsb	w12, [x30, x13]
1000c157c:     	add	w10, w10, w1
1000c1580:     	add	w10, w10, w12
1000c1584:     	ldrsb	w12, [x3, x15]
1000c1588:     	ldrsb	w1, [x26, x16]
1000c158c:     	add	w10, w10, w12
1000c1590:     	add	w10, w10, w1
1000c1594:     	ldrsb	w12, [x28, x17]
1000c1598:     	ldrsb	w1, [x8, x2]
1000c159c:     	add	x24, x9, x24
1000c15a0:     	add	w10, w10, w12
1000c15a4:     	add	w10, w10, w1
1000c15a8:     	ldrsb	w12, [x24, x4]
1000c15ac:     	add	w10, w10, w12
1000c15b0:     	scvtf	s0, w10
1000c15b4:     	add	x10, sp, #32
1000c15b8:     	add	x10, x10, x11
1000c15bc:     	ldr	s1, [x10]
1000c15c0:     	ldrsb	w12, [x25, x5]
1000c15c4:     	fadd	s0, s1, s0
1000c15c8:     	ldrsb	w1, [x27, x6]
1000c15cc:     	ldrsb	w25, [x30, x7]
1000c15d0:     	add	w12, w12, w1
1000c15d4:     	add	w12, w12, w25
1000c15d8:     	ldrsb	w1, [x3, x19]
1000c15dc:     	ldrsb	w3, [x26, x20]
1000c15e0:     	add	w12, w12, w1
1000c15e4:     	add	w12, w12, w3
1000c15e8:     	ldrsb	w1, [x28, x21]
1000c15ec:     	ldrsb	w8, [x8, x22]
1000c15f0:     	add	w12, w12, w1
1000c15f4:     	add	w8, w12, w8
1000c15f8:     	ldrsb	w12, [x24, x23]
1000c15fc:     	add	w8, w8, w12
1000c1600:     	scvtf	s1, w8
1000c1604:     	str	s0, [x10]
1000c1608:     	ldr	s0, [x10, #32]
1000c160c:     	fadd	s0, s0, s1
1000c1610:     	str	s0, [x10, #32]
1000c1614:     	add	x11, x11, #4
1000c1618:     	cmp	x11, #32
1000c161c:     	b.ne	0x1000c1510 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1620:     	add	x0, x0, #32
1000c1624:     	ldp	x8, x1, [sp, #8]
1000c1628:     	add	x1, x1, #8
1000c162c:     	cmp	x1, x8
1000c1630:     	b.ne	0x1000c14c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1634:     	ldp	q0, q1, [sp, #32]
1000c1638:     	ldr	x8, [sp]
1000c163c:     	stp	q0, q1, [x8]
1000c1640:     	ldp	q0, q1, [sp, #64]
1000c1644:     	stp	q0, q1, [x8, #32]
1000c1648:     	ldur	x8, [x29, #-88]
1000c164c:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x274>
1000c1650:     	ldr	x9, [x9, #392]
1000c1654:     	ldr	x9, [x9]
1000c1658:     	cmp	x9, x8
1000c165c:     	b.ne	0x1000c1680 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1660:     	ldp	x29, x30, [sp, #192]
1000c1664:     	ldp	x20, x19, [sp, #176]
1000c1668:     	ldp	x22, x21, [sp, #160]
1000c166c:     	ldp	x24, x23, [sp, #144]
1000c1670:     	ldp	x26, x25, [sp, #128]
1000c1674:     	ldp	x28, x27, [sp, #112]
1000c1678:     	add	sp, sp, #208
1000c167c:     	ret
1000c1680:     	bl	0x100163694 <_strcmp+0x100163694>

