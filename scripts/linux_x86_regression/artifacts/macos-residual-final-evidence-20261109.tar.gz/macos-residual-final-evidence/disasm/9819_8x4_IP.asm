00000001000c1348 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c1348:     	sub	sp, sp, #416
1000c134c:     	stp	x28, x27, [sp, #320]
1000c1350:     	stp	x26, x25, [sp, #336]
1000c1354:     	stp	x24, x23, [sp, #352]
1000c1358:     	stp	x22, x21, [sp, #368]
1000c135c:     	stp	x20, x19, [sp, #384]
1000c1360:     	stp	x29, x30, [sp, #400]
1000c1364:     	add	x29, sp, #400
1000c1368:     	str	x3, [sp]
1000c136c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c1370:     	ldr	x8, [x8, #392]
1000c1374:     	ldr	x8, [x8]
1000c1378:     	stur	x8, [x29, #-96]
1000c137c:     	movi.2d	v0, #0000000000000000
1000c1380:     	stp	q0, q0, [sp, #272]
1000c1384:     	lsl	x8, x2, #1
1000c1388:     	stp	q0, q0, [sp, #240]
1000c138c:     	stp	q0, q0, [sp, #208]
1000c1390:     	stp	q0, q0, [sp, #176]
1000c1394:     	ands	x8, x8, #0xfffffffffffffffc
1000c1398:     	b.eq	0x1000c16c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x378>
1000c139c:     	add	x8, x1, x8
1000c13a0:     	str	x8, [sp, #8]
1000c13a4:     	add	x8, sp, #176
1000c13a8:     	add	x27, x8, #64
1000c13ac:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f8>
1000c13b0:     	add	x11, x11, #988
1000c13b4:     	mov	x12, #0
1000c13b8:     	ldp	w8, w9, [x1]
1000c13bc:     	ubfx	x10, x8, #4, #4
1000c13c0:     	str	x10, [sp, #168]
1000c13c4:     	ubfx	x10, x8, #8, #4
1000c13c8:     	str	x10, [sp, #160]
1000c13cc:     	and	x10, x8, #0xf
1000c13d0:     	str	x10, [sp, #152]
1000c13d4:     	ubfx	x10, x8, #12, #4
1000c13d8:     	str	x10, [sp, #144]
1000c13dc:     	ubfx	x10, x8, #16, #4
1000c13e0:     	str	x10, [sp, #136]
1000c13e4:     	ubfx	x10, x8, #20, #4
1000c13e8:     	str	x10, [sp, #128]
1000c13ec:     	ubfx	x10, x8, #24, #4
1000c13f0:     	lsr	x8, x8, #28
1000c13f4:     	stp	x8, x10, [sp, #112]
1000c13f8:     	and	x10, x9, #0xf
1000c13fc:     	ubfx	x8, x9, #4, #4
1000c1400:     	stp	x8, x10, [sp, #96]
1000c1404:     	ubfx	x10, x9, #8, #4
1000c1408:     	ubfx	x8, x9, #12, #4
1000c140c:     	stp	x8, x10, [sp, #80]
1000c1410:     	ubfx	x10, x9, #16, #4
1000c1414:     	ubfx	x8, x9, #20, #4
1000c1418:     	stp	x8, x10, [sp, #64]
1000c141c:     	ubfx	x10, x9, #24, #4
1000c1420:     	lsr	x8, x9, #28
1000c1424:     	stp	x8, x10, [sp, #48]
1000c1428:     	ldp	w9, w17, [x1, #8]
1000c142c:     	and	x10, x9, #0xf
1000c1430:     	ubfx	x8, x9, #4, #4
1000c1434:     	stp	x8, x10, [sp, #32]
1000c1438:     	ubfx	x8, x9, #8, #4
1000c143c:     	stp	x1, x8, [sp, #16]
1000c1440:     	ubfx	x28, x9, #12, #4
1000c1444:     	ubfx	x30, x9, #16, #4
1000c1448:     	ubfx	x8, x9, #20, #4
1000c144c:     	ubfx	x3, x9, #24, #4
1000c1450:     	lsr	x9, x9, #28
1000c1454:     	and	x1, x17, #0xf
1000c1458:     	ubfx	x10, x17, #4, #4
1000c145c:     	ubfx	x13, x17, #8, #4
1000c1460:     	ubfx	x26, x17, #12, #4
1000c1464:     	ubfx	x14, x17, #16, #4
1000c1468:     	ubfx	x15, x17, #20, #4
1000c146c:     	ubfx	x16, x17, #24, #4
1000c1470:     	lsr	x17, x17, #28
1000c1474:     	ldr	w21, [x0, x12]
1000c1478:     	lsl	w2, w21, #4
1000c147c:     	and	x2, x2, #0xf0
1000c1480:     	ldp	x4, x19, [sp, #152]
1000c1484:     	orr	x4, x2, x4
1000c1488:     	ldrsb	w6, [x11, x4]
1000c148c:     	and	x4, x21, #0xf0
1000c1490:     	ldr	x5, [sp, #168]
1000c1494:     	orr	x5, x4, x5
1000c1498:     	ldrsb	w7, [x11, x5]
1000c149c:     	lsr	x5, x21, #4
1000c14a0:     	and	x5, x5, #0xf0
1000c14a4:     	orr	x19, x5, x19
1000c14a8:     	ldrsb	w19, [x11, x19]
1000c14ac:     	add	w6, w6, w7
1000c14b0:     	add	w19, w6, w19
1000c14b4:     	lsr	x6, x21, #8
1000c14b8:     	and	x6, x6, #0xf0
1000c14bc:     	ldp	x22, x7, [sp, #136]
1000c14c0:     	orr	x7, x6, x7
1000c14c4:     	ldrsb	w20, [x11, x7]
1000c14c8:     	lsr	x7, x21, #12
1000c14cc:     	and	x7, x7, #0xf0
1000c14d0:     	orr	x22, x7, x22
1000c14d4:     	ldrsb	w22, [x11, x22]
1000c14d8:     	add	w19, w19, w20
1000c14dc:     	add	w22, w19, w22
1000c14e0:     	lsr	x19, x21, #16
1000c14e4:     	and	x19, x19, #0xf0
1000c14e8:     	ldp	x24, x20, [sp, #120]
1000c14ec:     	orr	x20, x19, x20
1000c14f0:     	ldrsb	w23, [x11, x20]
1000c14f4:     	lsr	x20, x21, #20
1000c14f8:     	and	x20, x20, #0xf0
1000c14fc:     	orr	x24, x20, x24
1000c1500:     	ldrsb	w24, [x11, x24]
1000c1504:     	add	w22, w22, w23
1000c1508:     	add	w22, w22, w24
1000c150c:     	lsr	x21, x21, #24
1000c1510:     	and	x21, x21, #0xf0
1000c1514:     	ldr	x23, [sp, #112]
1000c1518:     	orr	x23, x21, x23
1000c151c:     	ldrsb	w23, [x11, x23]
1000c1520:     	add	w22, w22, w23
1000c1524:     	scvtf	s0, w22
1000c1528:     	ldp	x23, x22, [sp, #96]
1000c152c:     	orr	x22, x2, x22
1000c1530:     	ldrsb	w22, [x11, x22]
1000c1534:     	orr	x23, x4, x23
1000c1538:     	ldrsb	w23, [x11, x23]
1000c153c:     	ldr	x24, [sp, #88]
1000c1540:     	orr	x24, x5, x24
1000c1544:     	ldrsb	w24, [x11, x24]
1000c1548:     	add	w22, w22, w23
1000c154c:     	add	w22, w22, w24
1000c1550:     	ldp	x24, x23, [sp, #72]
1000c1554:     	orr	x23, x6, x23
1000c1558:     	ldrsb	w23, [x11, x23]
1000c155c:     	orr	x24, x7, x24
1000c1560:     	ldrsb	w24, [x11, x24]
1000c1564:     	ldr	x25, [sp, #64]
1000c1568:     	orr	x25, x19, x25
1000c156c:     	ldrsb	w25, [x11, x25]
1000c1570:     	add	w22, w22, w23
1000c1574:     	add	w22, w22, w24
1000c1578:     	ldr	x23, [sp, #56]
1000c157c:     	orr	x23, x20, x23
1000c1580:     	ldrsb	w23, [x11, x23]
1000c1584:     	add	w22, w22, w25
1000c1588:     	add	w22, w22, w23
1000c158c:     	ldr	x23, [sp, #48]
1000c1590:     	orr	x23, x21, x23
1000c1594:     	ldrsb	w23, [x11, x23]
1000c1598:     	add	w22, w22, w23
1000c159c:     	scvtf	s1, w22
1000c15a0:     	ldp	x23, x22, [sp, #32]
1000c15a4:     	orr	x22, x2, x22
1000c15a8:     	ldrsb	w22, [x11, x22]
1000c15ac:     	orr	x23, x4, x23
1000c15b0:     	ldrsb	w23, [x11, x23]
1000c15b4:     	ldr	x24, [sp, #24]
1000c15b8:     	orr	x24, x5, x24
1000c15bc:     	ldrsb	w24, [x11, x24]
1000c15c0:     	add	w22, w22, w23
1000c15c4:     	add	w22, w22, w24
1000c15c8:     	orr	x23, x6, x28
1000c15cc:     	ldrsb	w23, [x11, x23]
1000c15d0:     	orr	x24, x7, x30
1000c15d4:     	ldrsb	w24, [x11, x24]
1000c15d8:     	orr	x25, x19, x8
1000c15dc:     	ldrsb	w25, [x11, x25]
1000c15e0:     	add	w22, w22, w23
1000c15e4:     	orr	x23, x20, x3
1000c15e8:     	ldrsb	w23, [x11, x23]
1000c15ec:     	add	w22, w22, w24
1000c15f0:     	add	w22, w22, w25
1000c15f4:     	add	w22, w22, w23
1000c15f8:     	orr	x23, x21, x9
1000c15fc:     	ldrsb	w23, [x11, x23]
1000c1600:     	add	w22, w22, w23
1000c1604:     	scvtf	s2, w22
1000c1608:     	orr	x2, x2, x1
1000c160c:     	ldrsb	w2, [x11, x2]
1000c1610:     	orr	x4, x4, x10
1000c1614:     	ldrsb	w4, [x11, x4]
1000c1618:     	orr	x5, x5, x13
1000c161c:     	ldrsb	w5, [x11, x5]
1000c1620:     	add	w2, w2, w4
1000c1624:     	add	w2, w2, w5
1000c1628:     	orr	x4, x6, x26
1000c162c:     	ldrsb	w4, [x11, x4]
1000c1630:     	orr	x5, x7, x14
1000c1634:     	ldrsb	w5, [x11, x5]
1000c1638:     	add	w2, w2, w4
1000c163c:     	orr	x4, x19, x15
1000c1640:     	ldrsb	w4, [x11, x4]
1000c1644:     	add	w2, w2, w5
1000c1648:     	orr	x5, x20, x16
1000c164c:     	ldrsb	w5, [x11, x5]
1000c1650:     	add	w2, w2, w4
1000c1654:     	add	w2, w2, w5
1000c1658:     	orr	x4, x21, x17
1000c165c:     	ldrsb	w4, [x11, x4]
1000c1660:     	add	w2, w2, w4
1000c1664:     	add	x4, sp, #176
1000c1668:     	scvtf	s3, w2
1000c166c:     	add	x2, x27, x12
1000c1670:     	ldur	s4, [x2, #-32]
1000c1674:     	fadd	s1, s4, s1
1000c1678:     	stur	s1, [x2, #-32]
1000c167c:     	ldr	s1, [x2]
1000c1680:     	fadd	s1, s1, s2
1000c1684:     	str	s1, [x2]
1000c1688:     	ldr	s1, [x2, #32]
1000c168c:     	fadd	s1, s1, s3
1000c1690:     	ldr	s2, [x4, x12]
1000c1694:     	str	s1, [x2, #32]
1000c1698:     	fadd	s0, s2, s0
1000c169c:     	str	s0, [x4, x12]
1000c16a0:     	add	x12, x12, #4
1000c16a4:     	cmp	x12, #32
1000c16a8:     	b.ne	0x1000c1474 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x12c>
1000c16ac:     	add	x0, x0, #32
1000c16b0:     	ldp	x8, x1, [sp, #8]
1000c16b4:     	add	x1, x1, #16
1000c16b8:     	cmp	x1, x8
1000c16bc:     	b.ne	0x1000c13b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c16c0:     	ldp	q0, q1, [sp, #240]
1000c16c4:     	ldr	x8, [sp]
1000c16c8:     	stp	q0, q1, [x8, #64]
1000c16cc:     	ldp	q0, q1, [sp, #272]
1000c16d0:     	stp	q0, q1, [x8, #96]
1000c16d4:     	ldp	q0, q1, [sp, #176]
1000c16d8:     	stp	q0, q1, [x8]
1000c16dc:     	ldp	q0, q1, [sp, #208]
1000c16e0:     	stp	q0, q1, [x8, #32]
1000c16e4:     	ldur	x8, [x29, #-96]
1000c16e8:     	adrp	x9, 0x100168000 <void run<unsigned char, 8ul, 8ul, false>(char const*)+0x264>
1000c16ec:     	ldr	x9, [x9, #392]
1000c16f0:     	ldr	x9, [x9]
1000c16f4:     	cmp	x9, x8
1000c16f8:     	b.ne	0x1000c171c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3d4>
1000c16fc:     	ldp	x29, x30, [sp, #400]
1000c1700:     	ldp	x20, x19, [sp, #384]
1000c1704:     	ldp	x22, x21, [sp, #368]
1000c1708:     	ldp	x24, x23, [sp, #352]
1000c170c:     	ldp	x26, x25, [sp, #336]
1000c1710:     	ldp	x28, x27, [sp, #320]
1000c1714:     	add	sp, sp, #416
1000c1718:     	ret
1000c171c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

