
bin/9819_adapter:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100091140 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
100091140:     	stp	x28, x27, [sp, #-64]!
100091144:     	stp	x22, x21, [sp, #16]
100091148:     	stp	x20, x19, [sp, #32]
10009114c:     	stp	x29, x30, [sp, #48]
100091150:     	add	x29, sp, #48
100091154:     	mov	w9, #4112
100091158:     	adrp	x16, 0x10031d000 <zvec::core::EuclideanMetric::batch_distance() const+0x1a4>
10009115c:     	ldr	x16, [x16, #2152]
100091160:     	blr	x16
100091164:     	sub	sp, sp, #1, lsl #12     ; =4096
100091168:     	sub	sp, sp, #16
10009116c:     	mov	x19, x3
100091170:     	mov	x20, x1
100091174:     	mov	x21, x0
100091178:     	adrp	x8, 0x10031d000 <zvec::core::EuclideanMetric::batch_distance() const+0x1c4>
10009117c:     	ldr	x8, [x8, #2296]
100091180:     	ldr	x8, [x8]
100091184:     	stur	x8, [x29, #-56]
100091188:     	lsl	x8, x2, #4
10009118c:     	and	x22, x8, #0xffffffffffffffe0
100091190:     	add	x0, sp, #8
100091194:     	mov	w1, #4096
100091198:     	bl	0x1002a6134 <_write+0x1002a6134>
10009119c:     	cbz	x22, 0x1000912b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000911a0:     	add	x8, x20, x22
1000911a4:     	adrp	x9, 0x1002d9000 <zvec::core::EuclideanMetric::batch_distance() const+0xe0>
1000911a8:     	add	x9, x9, #1456
1000911ac:     	mov	x10, #0
1000911b0:     	add	x11, sp, #8
1000911b4:     	mov	x12, #0
1000911b8:     	ldr	w2, [x21, x10, lsl #2]
1000911bc:     	lsl	w13, w2, #4
1000911c0:     	and	x13, x13, #0xf0
1000911c4:     	and	x14, x2, #0xf0
1000911c8:     	lsr	x15, x2, #4
1000911cc:     	and	x15, x15, #0xf0
1000911d0:     	lsr	x16, x2, #8
1000911d4:     	and	x16, x16, #0xf0
1000911d8:     	lsr	x17, x2, #12
1000911dc:     	and	x17, x17, #0xf0
1000911e0:     	lsr	x0, x2, #16
1000911e4:     	and	x0, x0, #0xf0
1000911e8:     	lsr	x1, x2, #20
1000911ec:     	and	x1, x1, #0xf0
1000911f0:     	lsr	x2, x2, #24
1000911f4:     	and	x2, x2, #0xf0
1000911f8:     	mov	x3, x11
1000911fc:     	ldr	w4, [x20, x12]
100091200:     	and	x5, x4, #0xf
100091204:     	orr	x5, x13, x5
100091208:     	ldrb	w5, [x9, x5]
10009120c:     	ubfx	x6, x4, #4, #4
100091210:     	orr	x6, x14, x6
100091214:     	ldrb	w6, [x9, x6]
100091218:     	ubfx	x7, x4, #8, #4
10009121c:     	orr	x7, x15, x7
100091220:     	ldrb	w7, [x9, x7]
100091224:     	add	w5, w5, w6
100091228:     	add	w5, w5, w7
10009122c:     	ubfx	x6, x4, #12, #4
100091230:     	orr	x6, x16, x6
100091234:     	ldrb	w6, [x9, x6]
100091238:     	ubfx	x7, x4, #16, #4
10009123c:     	orr	x7, x17, x7
100091240:     	ldrb	w7, [x9, x7]
100091244:     	add	w5, w5, w6
100091248:     	add	w5, w5, w7
10009124c:     	ubfx	x6, x4, #20, #4
100091250:     	orr	x6, x0, x6
100091254:     	ldrb	w6, [x9, x6]
100091258:     	ubfx	x7, x4, #24, #4
10009125c:     	orr	x7, x1, x7
100091260:     	ldrb	w7, [x9, x7]
100091264:     	add	w5, w5, w6
100091268:     	add	w5, w5, w7
10009126c:     	orr	x4, x2, x4, lsr #28
100091270:     	ldrb	w4, [x9, x4]
100091274:     	add	w4, w5, w4
100091278:     	scvtf	s0, w4
10009127c:     	ldr	s1, [x3]
100091280:     	fadd	s0, s1, s0
100091284:     	str	s0, [x3], #128
100091288:     	add	x12, x12, #4
10009128c:     	cmp	x12, #128
100091290:     	b.ne	0x1000911fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
100091294:     	add	x10, x10, #1
100091298:     	add	x11, x11, #4
10009129c:     	cmp	x10, #32
1000912a0:     	b.ne	0x1000911b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000912a4:     	add	x21, x21, #128
1000912a8:     	add	x20, x20, #128
1000912ac:     	cmp	x20, x8
1000912b0:     	b.ne	0x1000911ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000912b4:     	add	x1, sp, #8
1000912b8:     	mov	x0, x19
1000912bc:     	mov	w2, #4096
1000912c0:     	bl	0x1002a6278 <_write+0x1002a6278>
1000912c4:     	ldur	x8, [x29, #-56]
1000912c8:     	adrp	x9, 0x10031d000 <zvec::core::EuclideanMetric::distance_matrix(unsigned long, unsigned long) const+0x44>
1000912cc:     	ldr	x9, [x9, #2296]
1000912d0:     	ldr	x9, [x9]
1000912d4:     	cmp	x9, x8
1000912d8:     	b.ne	0x1000912f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000912dc:     	add	sp, sp, #1, lsl #12     ; =4096
1000912e0:     	add	sp, sp, #16
1000912e4:     	ldp	x29, x30, [sp, #48]
1000912e8:     	ldp	x20, x19, [sp, #32]
1000912ec:     	ldp	x22, x21, [sp, #16]
1000912f0:     	ldp	x28, x27, [sp], #64
1000912f4:     	ret
1000912f8:     	bl	0x1002a6104 <_write+0x1002a6104>

00000001000b8644 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b8644:     	stp	x28, x27, [sp, #-64]!
1000b8648:     	stp	x22, x21, [sp, #16]
1000b864c:     	stp	x20, x19, [sp, #32]
1000b8650:     	stp	x29, x30, [sp, #48]
1000b8654:     	add	x29, sp, #48
1000b8658:     	mov	w9, #4112
1000b865c:     	adrp	x16, 0x10031d000 <zvec::core::InnerProductSparseMetric::sparse_distance() const+0x8>
1000b8660:     	ldr	x16, [x16, #2152]
1000b8664:     	blr	x16
1000b8668:     	sub	sp, sp, #1, lsl #12     ; =4096
1000b866c:     	sub	sp, sp, #16
1000b8670:     	mov	x19, x3
1000b8674:     	mov	x20, x1
1000b8678:     	mov	x21, x0
1000b867c:     	adrp	x8, 0x10031d000 <zvec::core::InnerProductSparseMetric::sparse_distance() const+0x28>
1000b8680:     	ldr	x8, [x8, #2296]
1000b8684:     	ldr	x8, [x8]
1000b8688:     	stur	x8, [x29, #-56]
1000b868c:     	lsl	x8, x2, #4
1000b8690:     	and	x22, x8, #0xffffffffffffffe0
1000b8694:     	add	x0, sp, #8
1000b8698:     	mov	w1, #4096
1000b869c:     	bl	0x1002a6134 <_write+0x1002a6134>
1000b86a0:     	cbz	x22, 0x1000b87b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000b86a4:     	add	x8, x20, x22
1000b86a8:     	adrp	x9, 0x1002dd000 <zvec::core::InnerProductSparseMetric::init(zvec::core::IndexMeta const&, zvec::ailego::Params const&)+0x48>
1000b86ac:     	add	x9, x9, #2344
1000b86b0:     	mov	x10, #0
1000b86b4:     	add	x11, sp, #8
1000b86b8:     	mov	x12, #0
1000b86bc:     	ldr	w2, [x21, x10, lsl #2]
1000b86c0:     	lsl	w13, w2, #4
1000b86c4:     	and	x13, x13, #0xf0
1000b86c8:     	and	x14, x2, #0xf0
1000b86cc:     	lsr	x15, x2, #4
1000b86d0:     	and	x15, x15, #0xf0
1000b86d4:     	lsr	x16, x2, #8
1000b86d8:     	and	x16, x16, #0xf0
1000b86dc:     	lsr	x17, x2, #12
1000b86e0:     	and	x17, x17, #0xf0
1000b86e4:     	lsr	x0, x2, #16
1000b86e8:     	and	x0, x0, #0xf0
1000b86ec:     	lsr	x1, x2, #20
1000b86f0:     	and	x1, x1, #0xf0
1000b86f4:     	lsr	x2, x2, #24
1000b86f8:     	and	x2, x2, #0xf0
1000b86fc:     	mov	x3, x11
1000b8700:     	ldr	w4, [x20, x12]
1000b8704:     	and	x5, x4, #0xf
1000b8708:     	orr	x5, x13, x5
1000b870c:     	ldrsb	w5, [x9, x5]
1000b8710:     	ubfx	x6, x4, #4, #4
1000b8714:     	orr	x6, x14, x6
1000b8718:     	ldrsb	w6, [x9, x6]
1000b871c:     	ubfx	x7, x4, #8, #4
1000b8720:     	orr	x7, x15, x7
1000b8724:     	ldrsb	w7, [x9, x7]
1000b8728:     	add	w5, w5, w6
1000b872c:     	add	w5, w5, w7
1000b8730:     	ubfx	x6, x4, #12, #4
1000b8734:     	orr	x6, x16, x6
1000b8738:     	ldrsb	w6, [x9, x6]
1000b873c:     	ubfx	x7, x4, #16, #4
1000b8740:     	orr	x7, x17, x7
1000b8744:     	ldrsb	w7, [x9, x7]
1000b8748:     	add	w5, w5, w6
1000b874c:     	add	w5, w5, w7
1000b8750:     	ubfx	x6, x4, #20, #4
1000b8754:     	orr	x6, x0, x6
1000b8758:     	ldrsb	w6, [x9, x6]
1000b875c:     	ubfx	x7, x4, #24, #4
1000b8760:     	orr	x7, x1, x7
1000b8764:     	ldrsb	w7, [x9, x7]
1000b8768:     	add	w5, w5, w6
1000b876c:     	add	w5, w5, w7
1000b8770:     	orr	x4, x2, x4, lsr #28
1000b8774:     	ldrsb	w4, [x9, x4]
1000b8778:     	add	w4, w5, w4
1000b877c:     	scvtf	s0, w4
1000b8780:     	ldr	s1, [x3]
1000b8784:     	fadd	s0, s1, s0
1000b8788:     	str	s0, [x3], #128
1000b878c:     	add	x12, x12, #4
1000b8790:     	cmp	x12, #128
1000b8794:     	b.ne	0x1000b8700 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000b8798:     	add	x10, x10, #1
1000b879c:     	add	x11, x11, #4
1000b87a0:     	cmp	x10, #32
1000b87a4:     	b.ne	0x1000b86b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000b87a8:     	add	x21, x21, #128
1000b87ac:     	add	x20, x20, #128
1000b87b0:     	cmp	x20, x8
1000b87b4:     	b.ne	0x1000b86b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000b87b8:     	add	x1, sp, #8
1000b87bc:     	mov	x0, x19
1000b87c0:     	mov	w2, #4096
1000b87c4:     	bl	0x1002a6278 <_write+0x1002a6278>
1000b87c8:     	ldur	x8, [x29, #-56]
1000b87cc:     	adrp	x9, 0x10031d000 <zvec::ailego::Factory<zvec::core::IndexMetric>::Register<zvec::core::MipsSquaredEuclideanMetric<false>, void>::Register(char const*)+0x94>
1000b87d0:     	ldr	x9, [x9, #2296]
1000b87d4:     	ldr	x9, [x9]
1000b87d8:     	cmp	x9, x8
1000b87dc:     	b.ne	0x1000b87fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000b87e0:     	add	sp, sp, #1, lsl #12     ; =4096
1000b87e4:     	add	sp, sp, #16
1000b87e8:     	ldp	x29, x30, [sp, #48]
1000b87ec:     	ldp	x20, x19, [sp, #32]
1000b87f0:     	ldp	x22, x21, [sp, #16]
1000b87f4:     	ldp	x28, x27, [sp], #64
1000b87f8:     	ret
1000b87fc:     	bl	0x1002a6104 <_write+0x1002a6104>
