00000001000c340c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c340c:     	sub	sp, sp, #416
1000c3410:     	stp	x28, x27, [sp, #320]
1000c3414:     	stp	x26, x25, [sp, #336]
1000c3418:     	stp	x24, x23, [sp, #352]
1000c341c:     	stp	x22, x21, [sp, #368]
1000c3420:     	stp	x20, x19, [sp, #384]
1000c3424:     	stp	x29, x30, [sp, #400]
1000c3428:     	add	x29, sp, #400
1000c342c:     	str	x3, [sp]
1000c3430:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
1000c3434:     	ldr	x8, [x8, #392]
1000c3438:     	ldr	x8, [x8]
1000c343c:     	stur	x8, [x29, #-96]
1000c3440:     	movi.2d	v0, #0000000000000000
1000c3444:     	stp	q0, q0, [sp, #272]
1000c3448:     	lsl	x8, x2, #1
1000c344c:     	stp	q0, q0, [sp, #240]
1000c3450:     	stp	q0, q0, [sp, #208]
1000c3454:     	stp	q0, q0, [sp, #176]
1000c3458:     	ands	x8, x8, #0xfffffffffffffffc
1000c345c:     	b.eq	0x1000c3738 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c3460:     	add	x8, x1, x8
1000c3464:     	str	x8, [sp, #8]
1000c3468:     	add	x8, sp, #176
1000c346c:     	add	x27, x8, #64
1000c3470:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x300>
1000c3474:     	add	x11, x11, #956
1000c3478:     	mov	x12, #0
1000c347c:     	ldp	w8, w9, [x1]
1000c3480:     	ubfx	x10, x8, #8, #4
1000c3484:     	str	x10, [sp, #168]
1000c3488:     	ubfx	x10, x8, #16, #4
1000c348c:     	str	x10, [sp, #160]
1000c3490:     	ubfx	x10, x8, #24, #4
1000c3494:     	str	x10, [sp, #152]
1000c3498:     	ldp	w10, w17, [x1, #8]
1000c349c:     	str	x1, [sp, #16]
1000c34a0:     	and	x14, x8, #0xf
1000c34a4:     	ubfx	x13, x8, #4, #4
1000c34a8:     	stp	x13, x14, [sp, #136]
1000c34ac:     	ubfx	x14, x8, #12, #4
1000c34b0:     	ubfx	x13, x8, #20, #4
1000c34b4:     	stp	x13, x14, [sp, #120]
1000c34b8:     	lsr	x8, x8, #28
1000c34bc:     	str	x8, [sp, #112]
1000c34c0:     	and	x8, x9, #0xf
1000c34c4:     	str	x8, [sp, #104]
1000c34c8:     	ubfx	x8, x9, #8, #4
1000c34cc:     	str	x8, [sp, #96]
1000c34d0:     	ubfx	x8, x9, #16, #4
1000c34d4:     	str	x8, [sp, #88]
1000c34d8:     	ubfx	x8, x9, #24, #4
1000c34dc:     	str	x8, [sp, #80]
1000c34e0:     	ubfx	x8, x9, #4, #4
1000c34e4:     	str	x8, [sp, #72]
1000c34e8:     	ubfx	x8, x9, #12, #4
1000c34ec:     	str	x8, [sp, #64]
1000c34f0:     	ubfx	x8, x9, #20, #4
1000c34f4:     	str	x8, [sp, #56]
1000c34f8:     	lsr	x8, x9, #28
1000c34fc:     	str	x8, [sp, #48]
1000c3500:     	and	x9, x10, #0xf
1000c3504:     	ubfx	x8, x10, #8, #4
1000c3508:     	stp	x8, x9, [sp, #32]
1000c350c:     	ubfx	x8, x10, #16, #4
1000c3510:     	str	x8, [sp, #24]
1000c3514:     	ubfx	x28, x10, #24, #4
1000c3518:     	ubfx	x30, x10, #4, #4
1000c351c:     	ubfx	x8, x10, #12, #4
1000c3520:     	ubfx	x3, x10, #20, #4
1000c3524:     	lsr	x9, x10, #28
1000c3528:     	and	x1, x17, #0xf
1000c352c:     	ubfx	x10, x17, #8, #4
1000c3530:     	ubfx	x13, x17, #16, #4
1000c3534:     	ubfx	x26, x17, #24, #4
1000c3538:     	ubfx	x14, x17, #4, #4
1000c353c:     	ubfx	x15, x17, #12, #4
1000c3540:     	ubfx	x16, x17, #20, #4
1000c3544:     	lsr	x17, x17, #28
1000c3548:     	ldr	w20, [x0, x12]
1000c354c:     	lsl	w2, w20, #4
1000c3550:     	and	x2, x2, #0xf0
1000c3554:     	add	x5, x11, x2
1000c3558:     	and	x2, x20, #0xf0
1000c355c:     	add	x2, x11, x2
1000c3560:     	lsr	x4, x20, #4
1000c3564:     	and	x4, x4, #0xf0
1000c3568:     	add	x7, x11, x4
1000c356c:     	lsr	x4, x20, #8
1000c3570:     	and	x4, x4, #0xf0
1000c3574:     	add	x4, x11, x4
1000c3578:     	lsr	x6, x20, #12
1000c357c:     	and	x6, x6, #0xf0
1000c3580:     	add	x19, x11, x6
1000c3584:     	lsr	x6, x20, #16
1000c3588:     	and	x6, x6, #0xf0
1000c358c:     	add	x6, x11, x6
1000c3590:     	lsr	x21, x20, #20
1000c3594:     	and	x21, x21, #0xf0
1000c3598:     	add	x21, x11, x21
1000c359c:     	lsr	x20, x20, #24
1000c35a0:     	and	x20, x20, #0xf0
1000c35a4:     	ldr	x22, [sp, #144]
1000c35a8:     	ldrsb	w22, [x5, x22]
1000c35ac:     	add	x20, x11, x20
1000c35b0:     	ldp	x24, x23, [sp, #160]
1000c35b4:     	ldrsb	w23, [x7, x23]
1000c35b8:     	ldrsb	w24, [x19, x24]
1000c35bc:     	add	w22, w22, w23
1000c35c0:     	add	w22, w22, w24
1000c35c4:     	ldr	x23, [sp, #152]
1000c35c8:     	ldrsb	w23, [x21, x23]
1000c35cc:     	ldr	x24, [sp, #136]
1000c35d0:     	ldrsb	w24, [x2, x24]
1000c35d4:     	add	w22, w22, w23
1000c35d8:     	add	w22, w22, w24
1000c35dc:     	ldp	x24, x23, [sp, #120]
1000c35e0:     	ldrsb	w23, [x4, x23]
1000c35e4:     	ldrsb	w24, [x6, x24]
1000c35e8:     	add	w22, w22, w23
1000c35ec:     	add	w22, w22, w24
1000c35f0:     	ldr	x23, [sp, #112]
1000c35f4:     	ldrsb	w23, [x20, x23]
1000c35f8:     	add	w22, w22, w23
1000c35fc:     	scvtf	s0, w22
1000c3600:     	ldp	x23, x22, [sp, #96]
1000c3604:     	ldrsb	w22, [x5, x22]
1000c3608:     	ldrsb	w23, [x7, x23]
1000c360c:     	ldp	x25, x24, [sp, #80]
1000c3610:     	ldrsb	w24, [x19, x24]
1000c3614:     	ldrsb	w25, [x21, x25]
1000c3618:     	add	w22, w22, w23
1000c361c:     	ldr	x23, [sp, #72]
1000c3620:     	ldrsb	w23, [x2, x23]
1000c3624:     	add	w22, w22, w24
1000c3628:     	ldr	x24, [sp, #64]
1000c362c:     	ldrsb	w24, [x4, x24]
1000c3630:     	add	w22, w22, w25
1000c3634:     	ldr	x25, [sp, #56]
1000c3638:     	ldrsb	w25, [x6, x25]
1000c363c:     	add	w22, w22, w23
1000c3640:     	add	w22, w22, w24
1000c3644:     	add	w22, w22, w25
1000c3648:     	ldr	x23, [sp, #48]
1000c364c:     	ldrsb	w23, [x20, x23]
1000c3650:     	add	w22, w22, w23
1000c3654:     	scvtf	s1, w22
1000c3658:     	ldp	x23, x22, [sp, #32]
1000c365c:     	ldrsb	w22, [x5, x22]
1000c3660:     	ldrsb	w23, [x7, x23]
1000c3664:     	ldr	x24, [sp, #24]
1000c3668:     	ldrsb	w24, [x19, x24]
1000c366c:     	add	w22, w22, w23
1000c3670:     	ldrsb	w23, [x21, x28]
1000c3674:     	add	w22, w22, w24
1000c3678:     	ldrsb	w24, [x2, x30]
1000c367c:     	add	w22, w22, w23
1000c3680:     	ldrsb	w23, [x4, x8]
1000c3684:     	add	w22, w22, w24
1000c3688:     	ldrsb	w24, [x6, x3]
1000c368c:     	add	w22, w22, w23
1000c3690:     	ldrsb	w23, [x20, x9]
1000c3694:     	add	w22, w22, w24
1000c3698:     	add	w22, w22, w23
1000c369c:     	scvtf	s2, w22
1000c36a0:     	ldrsb	w5, [x5, x1]
1000c36a4:     	ldrsb	w7, [x7, x10]
1000c36a8:     	ldrsb	w19, [x19, x13]
1000c36ac:     	add	w5, w5, w7
1000c36b0:     	add	w5, w5, w19
1000c36b4:     	ldrsb	w7, [x21, x26]
1000c36b8:     	ldrsb	w2, [x2, x14]
1000c36bc:     	add	w5, w5, w7
1000c36c0:     	add	w2, w5, w2
1000c36c4:     	ldrsb	w4, [x4, x15]
1000c36c8:     	ldrsb	w5, [x6, x16]
1000c36cc:     	add	w2, w2, w4
1000c36d0:     	add	w2, w2, w5
1000c36d4:     	ldrsb	w4, [x20, x17]
1000c36d8:     	add	w2, w2, w4
1000c36dc:     	add	x4, sp, #176
1000c36e0:     	scvtf	s3, w2
1000c36e4:     	add	x2, x27, x12
1000c36e8:     	ldur	s4, [x2, #-32]
1000c36ec:     	fadd	s1, s4, s1
1000c36f0:     	stur	s1, [x2, #-32]
1000c36f4:     	ldr	s1, [x2]
1000c36f8:     	fadd	s1, s1, s2
1000c36fc:     	str	s1, [x2]
1000c3700:     	ldr	s1, [x2, #32]
1000c3704:     	fadd	s1, s1, s3
1000c3708:     	ldr	s2, [x4, x12]
1000c370c:     	str	s1, [x2, #32]
1000c3710:     	fadd	s0, s2, s0
1000c3714:     	str	s0, [x4, x12]
1000c3718:     	add	x12, x12, #4
1000c371c:     	cmp	x12, #32
1000c3720:     	b.ne	0x1000c3548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3724:     	add	x0, x0, #32
1000c3728:     	ldp	x8, x1, [sp, #8]
1000c372c:     	add	x1, x1, #16
1000c3730:     	cmp	x1, x8
1000c3734:     	b.ne	0x1000c3478 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c3738:     	ldp	q0, q1, [sp, #240]
1000c373c:     	ldr	x8, [sp]
1000c3740:     	stp	q0, q1, [x8, #64]
1000c3744:     	ldp	q0, q1, [sp, #272]
1000c3748:     	stp	q0, q1, [x8, #96]
1000c374c:     	ldp	q0, q1, [sp, #176]
1000c3750:     	stp	q0, q1, [x8]
1000c3754:     	ldp	q0, q1, [sp, #208]
1000c3758:     	stp	q0, q1, [x8, #32]
1000c375c:     	ldur	x8, [x29, #-96]
1000c3760:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 8ul, false>(char const*)+0x26c>
1000c3764:     	ldr	x9, [x9, #392]
1000c3768:     	ldr	x9, [x9]
1000c376c:     	cmp	x9, x8
1000c3770:     	b.ne	0x1000c3794 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c3774:     	ldp	x29, x30, [sp, #400]
1000c3778:     	ldp	x20, x19, [sp, #384]
1000c377c:     	ldp	x22, x21, [sp, #368]
1000c3780:     	ldp	x24, x23, [sp, #352]
1000c3784:     	ldp	x26, x25, [sp, #336]
1000c3788:     	ldp	x28, x27, [sp, #320]
1000c378c:     	add	sp, sp, #416
1000c3790:     	ret
1000c3794:     	bl	0x100163694 <_strcmp+0x100163694>

