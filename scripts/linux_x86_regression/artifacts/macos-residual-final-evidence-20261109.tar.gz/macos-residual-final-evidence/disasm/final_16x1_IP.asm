00000001000c6ea4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c6ea4:     	stp	x22, x21, [sp, #-32]!
1000c6ea8:     	stp	x20, x19, [sp, #16]
1000c6eac:     	movi.2d	v0, #0000000000000000
1000c6eb0:     	stp	q0, q0, [x3, #32]
1000c6eb4:     	stp	q0, q0, [x3]
1000c6eb8:     	cmp	x2, #8
1000c6ebc:     	b.hs	0x1000c6ec8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c6ec0:     	mov	x8, #0
1000c6ec4:     	b	0x1000c6fd8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c6ec8:     	mov	x8, #0
1000c6ecc:     	mov	w12, #8
1000c6ed0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2bc>
1000c6ed4:     	add	x9, x9, #1468
1000c6ed8:     	mov	x10, x0
1000c6edc:     	mov	x11, #0
1000c6ee0:     	lsr	x8, x8, #1
1000c6ee4:     	mul	x8, x8, x4
1000c6ee8:     	ldr	w6, [x1, x8]
1000c6eec:     	mov	x8, x12
1000c6ef0:     	lsl	w12, w6, #4
1000c6ef4:     	and	x12, x12, #0xf0
1000c6ef8:     	add	x12, x9, x12
1000c6efc:     	and	x13, x6, #0xf0
1000c6f00:     	add	x13, x9, x13
1000c6f04:     	lsr	x14, x6, #4
1000c6f08:     	and	x14, x14, #0xf0
1000c6f0c:     	add	x14, x9, x14
1000c6f10:     	lsr	x15, x6, #8
1000c6f14:     	and	x15, x15, #0xf0
1000c6f18:     	add	x15, x9, x15
1000c6f1c:     	lsr	x16, x6, #12
1000c6f20:     	and	x16, x16, #0xf0
1000c6f24:     	add	x16, x9, x16
1000c6f28:     	lsr	x17, x6, #16
1000c6f2c:     	and	x17, x17, #0xf0
1000c6f30:     	add	x17, x9, x17
1000c6f34:     	lsr	x5, x6, #20
1000c6f38:     	and	x5, x5, #0xf0
1000c6f3c:     	add	x5, x9, x5
1000c6f40:     	lsr	x6, x6, #24
1000c6f44:     	and	x6, x6, #0xf0
1000c6f48:     	add	x6, x9, x6
1000c6f4c:     	ldr	w7, [x10, x11]
1000c6f50:     	and	x19, x7, #0xf
1000c6f54:     	ldrsb	w19, [x12, x19]
1000c6f58:     	ubfx	x20, x7, #4, #4
1000c6f5c:     	ldrsb	w20, [x13, x20]
1000c6f60:     	ubfx	x21, x7, #8, #4
1000c6f64:     	ldrsb	w21, [x14, x21]
1000c6f68:     	add	w19, w19, w20
1000c6f6c:     	add	w19, w19, w21
1000c6f70:     	ubfx	x20, x7, #12, #4
1000c6f74:     	ldrsb	w20, [x15, x20]
1000c6f78:     	ubfx	x21, x7, #16, #4
1000c6f7c:     	ldrsb	w21, [x16, x21]
1000c6f80:     	add	w19, w19, w20
1000c6f84:     	add	w19, w19, w21
1000c6f88:     	ubfx	x20, x7, #20, #4
1000c6f8c:     	ldrsb	w20, [x17, x20]
1000c6f90:     	ubfx	x21, x7, #24, #4
1000c6f94:     	ldrsb	w21, [x5, x21]
1000c6f98:     	lsr	x7, x7, #28
1000c6f9c:     	ldrsb	w7, [x6, x7]
1000c6fa0:     	add	w19, w19, w20
1000c6fa4:     	add	w19, w19, w21
1000c6fa8:     	add	w7, w19, w7
1000c6fac:     	scvtf	s0, w7
1000c6fb0:     	ldr	s1, [x3, x11]
1000c6fb4:     	fadd	s0, s1, s0
1000c6fb8:     	str	s0, [x3, x11]
1000c6fbc:     	add	x11, x11, #4
1000c6fc0:     	cmp	x11, #64
1000c6fc4:     	b.ne	0x1000c6f4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c6fc8:     	add	x12, x8, #8
1000c6fcc:     	add	x10, x10, #64
1000c6fd0:     	cmp	x12, x2
1000c6fd4:     	b.ls	0x1000c6edc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c6fd8:     	cmp	x8, x2
1000c6fdc:     	b.hs	0x1000c7294 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000c6fe0:     	lsl	x9, x4, #2
1000c6fe4:     	lsl	w10, w8, #2
1000c6fe8:     	mov	w11, #-16
1000c6fec:     	lsr	x13, x8, #3
1000c6ff0:     	mul	x12, x9, x13
1000c6ff4:     	ubfx	x14, x8, #1, #2
1000c6ff8:     	orr	x12, x12, x14
1000c6ffc:     	ldrb	w15, [x1, x12]
1000c7000:     	and	w12, w10, #0x4
1000c7004:     	lsr	w15, w15, w12
1000c7008:     	and	w16, w15, #0xf
1000c700c:     	cmp	w16, #8
1000c7010:     	csel	w16, wzr, w11, lo
1000c7014:     	bfi	x14, x13, #6, #58
1000c7018:     	add	x13, x0, x14
1000c701c:     	ldrb	w14, [x13]
1000c7020:     	lsr	w14, w14, w12
1000c7024:     	bfxil	w16, w15, #0, #4
1000c7028:     	and	w15, w14, #0xf
1000c702c:     	cmp	w15, #8
1000c7030:     	csel	w15, wzr, w11, lo
1000c7034:     	bfxil	w15, w14, #0, #4
1000c7038:     	scvtf	s0, w16
1000c703c:     	scvtf	s1, w15
1000c7040:     	ldp	s2, s3, [x3]
1000c7044:     	fmsub	s1, s1, s0, s2
1000c7048:     	str	s1, [x3]
1000c704c:     	ldrb	w14, [x13, #4]
1000c7050:     	lsr	w14, w14, w12
1000c7054:     	and	w15, w14, #0xf
1000c7058:     	cmp	w15, #8
1000c705c:     	csel	w15, wzr, w11, lo
1000c7060:     	bfxil	w15, w14, #0, #4
1000c7064:     	scvtf	s1, w15
1000c7068:     	fmsub	s1, s1, s0, s3
1000c706c:     	str	s1, [x3, #4]
1000c7070:     	ldrb	w14, [x13, #8]
1000c7074:     	lsr	w14, w14, w12
1000c7078:     	and	w15, w14, #0xf
1000c707c:     	cmp	w15, #8
1000c7080:     	csel	w15, wzr, w11, lo
1000c7084:     	bfxil	w15, w14, #0, #4
1000c7088:     	scvtf	s1, w15
1000c708c:     	ldp	s2, s3, [x3, #8]
1000c7090:     	fmsub	s1, s1, s0, s2
1000c7094:     	str	s1, [x3, #8]
1000c7098:     	ldrb	w14, [x13, #12]
1000c709c:     	lsr	w14, w14, w12
1000c70a0:     	and	w15, w14, #0xf
1000c70a4:     	cmp	w15, #8
1000c70a8:     	csel	w15, wzr, w11, lo
1000c70ac:     	bfxil	w15, w14, #0, #4
1000c70b0:     	scvtf	s1, w15
1000c70b4:     	fmsub	s1, s1, s0, s3
1000c70b8:     	str	s1, [x3, #12]
1000c70bc:     	ldrb	w14, [x13, #16]
1000c70c0:     	lsr	w14, w14, w12
1000c70c4:     	and	w15, w14, #0xf
1000c70c8:     	cmp	w15, #8
1000c70cc:     	csel	w15, wzr, w11, lo
1000c70d0:     	bfxil	w15, w14, #0, #4
1000c70d4:     	scvtf	s1, w15
1000c70d8:     	ldp	s2, s3, [x3, #16]
1000c70dc:     	fmsub	s1, s1, s0, s2
1000c70e0:     	str	s1, [x3, #16]
1000c70e4:     	ldrb	w14, [x13, #20]
1000c70e8:     	lsr	w14, w14, w12
1000c70ec:     	and	w15, w14, #0xf
1000c70f0:     	cmp	w15, #8
1000c70f4:     	csel	w15, wzr, w11, lo
1000c70f8:     	bfxil	w15, w14, #0, #4
1000c70fc:     	scvtf	s1, w15
1000c7100:     	fmsub	s1, s1, s0, s3
1000c7104:     	str	s1, [x3, #20]
1000c7108:     	ldrb	w14, [x13, #24]
1000c710c:     	lsr	w14, w14, w12
1000c7110:     	and	w15, w14, #0xf
1000c7114:     	cmp	w15, #8
1000c7118:     	csel	w15, wzr, w11, lo
1000c711c:     	bfxil	w15, w14, #0, #4
1000c7120:     	scvtf	s1, w15
1000c7124:     	ldp	s2, s3, [x3, #24]
1000c7128:     	fmsub	s1, s1, s0, s2
1000c712c:     	str	s1, [x3, #24]
1000c7130:     	ldrb	w14, [x13, #28]
1000c7134:     	lsr	w14, w14, w12
1000c7138:     	and	w15, w14, #0xf
1000c713c:     	cmp	w15, #8
1000c7140:     	csel	w15, wzr, w11, lo
1000c7144:     	bfxil	w15, w14, #0, #4
1000c7148:     	scvtf	s1, w15
1000c714c:     	fmsub	s1, s1, s0, s3
1000c7150:     	str	s1, [x3, #28]
1000c7154:     	ldrb	w14, [x13, #32]
1000c7158:     	lsr	w14, w14, w12
1000c715c:     	and	w15, w14, #0xf
1000c7160:     	cmp	w15, #8
1000c7164:     	csel	w15, wzr, w11, lo
1000c7168:     	bfxil	w15, w14, #0, #4
1000c716c:     	scvtf	s1, w15
1000c7170:     	ldp	s2, s3, [x3, #32]
1000c7174:     	fmsub	s1, s1, s0, s2
1000c7178:     	str	s1, [x3, #32]
1000c717c:     	ldrb	w14, [x13, #36]
1000c7180:     	lsr	w14, w14, w12
1000c7184:     	and	w15, w14, #0xf
1000c7188:     	cmp	w15, #8
1000c718c:     	csel	w15, wzr, w11, lo
1000c7190:     	bfxil	w15, w14, #0, #4
1000c7194:     	scvtf	s1, w15
1000c7198:     	fmsub	s1, s1, s0, s3
1000c719c:     	str	s1, [x3, #36]
1000c71a0:     	ldrb	w14, [x13, #40]
1000c71a4:     	lsr	w14, w14, w12
1000c71a8:     	and	w15, w14, #0xf
1000c71ac:     	cmp	w15, #8
1000c71b0:     	csel	w15, wzr, w11, lo
1000c71b4:     	bfxil	w15, w14, #0, #4
1000c71b8:     	scvtf	s1, w15
1000c71bc:     	ldp	s2, s3, [x3, #40]
1000c71c0:     	fmsub	s1, s1, s0, s2
1000c71c4:     	str	s1, [x3, #40]
1000c71c8:     	ldrb	w14, [x13, #44]
1000c71cc:     	lsr	w14, w14, w12
1000c71d0:     	and	w15, w14, #0xf
1000c71d4:     	cmp	w15, #8
1000c71d8:     	csel	w15, wzr, w11, lo
1000c71dc:     	bfxil	w15, w14, #0, #4
1000c71e0:     	scvtf	s1, w15
1000c71e4:     	fmsub	s1, s1, s0, s3
1000c71e8:     	str	s1, [x3, #44]
1000c71ec:     	ldrb	w14, [x13, #48]
1000c71f0:     	lsr	w14, w14, w12
1000c71f4:     	and	w15, w14, #0xf
1000c71f8:     	cmp	w15, #8
1000c71fc:     	csel	w15, wzr, w11, lo
1000c7200:     	bfxil	w15, w14, #0, #4
1000c7204:     	scvtf	s1, w15
1000c7208:     	ldp	s2, s3, [x3, #48]
1000c720c:     	fmsub	s1, s1, s0, s2
1000c7210:     	str	s1, [x3, #48]
1000c7214:     	ldrb	w14, [x13, #52]
1000c7218:     	lsr	w14, w14, w12
1000c721c:     	and	w15, w14, #0xf
1000c7220:     	cmp	w15, #8
1000c7224:     	csel	w15, wzr, w11, lo
1000c7228:     	bfxil	w15, w14, #0, #4
1000c722c:     	scvtf	s1, w15
1000c7230:     	fmsub	s1, s1, s0, s3
1000c7234:     	str	s1, [x3, #52]
1000c7238:     	ldrb	w14, [x13, #56]
1000c723c:     	lsr	w14, w14, w12
1000c7240:     	and	w15, w14, #0xf
1000c7244:     	cmp	w15, #8
1000c7248:     	csel	w15, wzr, w11, lo
1000c724c:     	bfxil	w15, w14, #0, #4
1000c7250:     	scvtf	s1, w15
1000c7254:     	ldp	s2, s3, [x3, #56]
1000c7258:     	fmsub	s1, s1, s0, s2
1000c725c:     	str	s1, [x3, #56]
1000c7260:     	ldrb	w13, [x13, #60]
1000c7264:     	lsr	w12, w13, w12
1000c7268:     	and	w13, w12, #0xf
1000c726c:     	cmp	w13, #8
1000c7270:     	csel	w13, wzr, w11, lo
1000c7274:     	bfxil	w13, w12, #0, #4
1000c7278:     	scvtf	s1, w13
1000c727c:     	fmsub	s0, s1, s0, s3
1000c7280:     	str	s0, [x3, #60]
1000c7284:     	add	x8, x8, #1
1000c7288:     	add	w10, w10, #4
1000c728c:     	cmp	x2, x8
1000c7290:     	b.ne	0x1000c6fec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c7294:     	ldp	x20, x19, [sp, #16]
1000c7298:     	ldp	x22, x21, [sp], #32
1000c729c:     	ret

