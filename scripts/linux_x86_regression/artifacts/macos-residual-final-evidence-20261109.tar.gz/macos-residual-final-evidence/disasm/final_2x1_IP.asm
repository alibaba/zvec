00000001000b650c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b650c:     	stp	x24, x23, [sp, #-48]!
1000b6510:     	stp	x22, x21, [sp, #16]
1000b6514:     	stp	x20, x19, [sp, #32]
1000b6518:     	str	xzr, [x3]
1000b651c:     	lsl	x8, x4, #2
1000b6520:     	cmp	x2, #8
1000b6524:     	b.hs	0x1000b6538 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b6528:     	mov	x12, #0
1000b652c:     	movi	d1, #0000000000000000
1000b6530:     	movi	d0, #0000000000000000
1000b6534:     	b	0x1000b66a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b6538:     	mov	x10, #0
1000b653c:     	adrp	x9, 0x100169000 <void run<unsigned char, 2ul, 2ul, false>(char const*)+0xb4>
1000b6540:     	add	x9, x9, #4028
1000b6544:     	mov	x11, x1
1000b6548:     	ldr	w4, [x11]
1000b654c:     	lsl	w12, w4, #4
1000b6550:     	and	x13, x12, #0xf0
1000b6554:     	and	x12, x4, #0xf0
1000b6558:     	add	x12, x9, x12
1000b655c:     	lsr	x14, x4, #4
1000b6560:     	and	x15, x14, #0xf0
1000b6564:     	add	x14, x9, x13
1000b6568:     	add	x13, x9, x15
1000b656c:     	lsr	x15, x4, #8
1000b6570:     	and	x15, x15, #0xf0
1000b6574:     	lsr	x16, x4, #12
1000b6578:     	and	x17, x16, #0xf0
1000b657c:     	add	x16, x9, x15
1000b6580:     	add	x15, x9, x17
1000b6584:     	lsr	x17, x4, #16
1000b6588:     	and	x17, x17, #0xf0
1000b658c:     	lsr	x5, x4, #20
1000b6590:     	and	x5, x5, #0xf0
1000b6594:     	add	x17, x9, x17
1000b6598:     	lsr	x4, x4, #24
1000b659c:     	and	x6, x4, #0xf0
1000b65a0:     	add	x7, x0, x10
1000b65a4:     	ldr	w19, [x7]
1000b65a8:     	and	x20, x19, #0xf
1000b65ac:     	add	x4, x9, x5
1000b65b0:     	ldrsb	w5, [x14, x20]
1000b65b4:     	ubfx	x20, x19, #4, #4
1000b65b8:     	ubfx	x21, x19, #8, #4
1000b65bc:     	ldrsb	w20, [x12, x20]
1000b65c0:     	ldrsb	w21, [x13, x21]
1000b65c4:     	ubfx	x22, x19, #12, #4
1000b65c8:     	ubfx	x23, x19, #16, #4
1000b65cc:     	ldrsb	w22, [x16, x22]
1000b65d0:     	ldrsb	w23, [x15, x23]
1000b65d4:     	ubfx	x24, x19, #20, #4
1000b65d8:     	ldrsb	w24, [x17, x24]
1000b65dc:     	add	w5, w5, w20
1000b65e0:     	add	w5, w5, w21
1000b65e4:     	ubfx	x20, x19, #24, #4
1000b65e8:     	ldrsb	w20, [x4, x20]
1000b65ec:     	add	w5, w5, w22
1000b65f0:     	add	w5, w5, w23
1000b65f4:     	add	x6, x9, x6
1000b65f8:     	lsr	x19, x19, #28
1000b65fc:     	ldrsb	w19, [x6, x19]
1000b6600:     	add	w5, w5, w24
1000b6604:     	add	w5, w5, w20
1000b6608:     	add	w5, w5, w19
1000b660c:     	scvtf	s0, w5
1000b6610:     	ldp	s1, s2, [x3]
1000b6614:     	fadd	s0, s1, s0
1000b6618:     	str	s0, [x3]
1000b661c:     	ldr	w5, [x7, #4]
1000b6620:     	and	x7, x5, #0xf
1000b6624:     	ubfx	x19, x5, #4, #4
1000b6628:     	ldrsb	w14, [x14, x7]
1000b662c:     	ldrsb	w12, [x12, x19]
1000b6630:     	ubfx	x7, x5, #8, #4
1000b6634:     	ubfx	x19, x5, #12, #4
1000b6638:     	ldrsb	w13, [x13, x7]
1000b663c:     	ldrsb	w16, [x16, x19]
1000b6640:     	ubfx	x7, x5, #16, #4
1000b6644:     	ldrsb	w15, [x15, x7]
1000b6648:     	add	w12, w14, w12
1000b664c:     	add	w12, w12, w13
1000b6650:     	ubfx	x13, x5, #20, #4
1000b6654:     	ldrsb	w13, [x17, x13]
1000b6658:     	add	w12, w12, w16
1000b665c:     	add	w12, w12, w15
1000b6660:     	ubfx	x14, x5, #24, #4
1000b6664:     	ldrsb	w14, [x4, x14]
1000b6668:     	lsr	x15, x5, #28
1000b666c:     	add	w12, w12, w13
1000b6670:     	add	w12, w12, w14
1000b6674:     	ldrsb	w13, [x6, x15]
1000b6678:     	add	w12, w12, w13
1000b667c:     	scvtf	s1, w12
1000b6680:     	fadd	s1, s2, s1
1000b6684:     	str	s1, [x3, #4]
1000b6688:     	add	x12, x10, #8
1000b668c:     	add	x11, x11, x8
1000b6690:     	add	x13, x10, #16
1000b6694:     	mov	x10, x12
1000b6698:     	cmp	x13, x2
1000b669c:     	b.ls	0x1000b6548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b66a0:     	cmp	x12, x2
1000b66a4:     	b.hs	0x1000b6744 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x238>
1000b66a8:     	lsl	w9, w12, #2
1000b66ac:     	mov	w10, #-16
1000b66b0:     	lsr	x11, x12, #3
1000b66b4:     	mul	x11, x8, x11
1000b66b8:     	ubfx	x13, x12, #1, #2
1000b66bc:     	orr	x11, x11, x13
1000b66c0:     	ldrb	w11, [x1, x11]
1000b66c4:     	and	w13, w9, #0x4
1000b66c8:     	lsr	w11, w11, w13
1000b66cc:     	and	w14, w11, #0xf
1000b66d0:     	cmp	w14, #8
1000b66d4:     	csel	w14, wzr, w10, lo
1000b66d8:     	and	x15, x12, #0xfffffffffffffff8
1000b66dc:     	bfxil	x15, x12, #1, #2
1000b66e0:     	add	x15, x0, x15
1000b66e4:     	ldrb	w16, [x15]
1000b66e8:     	lsr	w16, w16, w13
1000b66ec:     	bfxil	w14, w11, #0, #4
1000b66f0:     	and	w11, w16, #0xf
1000b66f4:     	cmp	w11, #8
1000b66f8:     	csel	w11, wzr, w10, lo
1000b66fc:     	bfxil	w11, w16, #0, #4
1000b6700:     	scvtf	s2, w14
1000b6704:     	scvtf	s3, w11
1000b6708:     	fmsub	s0, s3, s2, s0
1000b670c:     	str	s0, [x3]
1000b6710:     	ldrb	w11, [x15, #4]
1000b6714:     	lsr	w11, w11, w13
1000b6718:     	and	w13, w11, #0xf
1000b671c:     	cmp	w13, #8
1000b6720:     	csel	w13, wzr, w10, lo
1000b6724:     	bfxil	w13, w11, #0, #4
1000b6728:     	scvtf	s3, w13
1000b672c:     	fmsub	s1, s3, s2, s1
1000b6730:     	str	s1, [x3, #4]
1000b6734:     	add	x12, x12, #1
1000b6738:     	add	w9, w9, #4
1000b673c:     	cmp	x2, x12
1000b6740:     	b.ne	0x1000b66b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b6744:     	ldp	x20, x19, [sp, #32]
1000b6748:     	ldp	x22, x21, [sp, #16]
1000b674c:     	ldp	x24, x23, [sp], #48
1000b6750:     	ret

