00000001000b7eb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b7eb8:     	stp	x20, x19, [sp, #-16]!
1000b7ebc:     	stp	xzr, xzr, [x3]
1000b7ec0:     	lsl	x8, x4, #2
1000b7ec4:     	cmp	x2, #8
1000b7ec8:     	b.hs	0x1000b7edc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000b7ecc:     	mov	x13, #0
1000b7ed0:     	movi	d1, #0000000000000000
1000b7ed4:     	movi	d0, #0000000000000000
1000b7ed8:     	b	0x1000b81bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x304>
1000b7edc:     	mov	x10, #0
1000b7ee0:     	add	x9, x0, #8
1000b7ee4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2e8>
1000b7ee8:     	add	x11, x11, #476
1000b7eec:     	mov	x12, x1
1000b7ef0:     	ldr	w13, [x12]
1000b7ef4:     	ldur	w14, [x9, #-8]
1000b7ef8:     	lsl	w15, w14, #4
1000b7efc:     	and	x15, x15, #0xf0
1000b7f00:     	bfxil	x15, x13, #0, #4
1000b7f04:     	and	x16, x14, #0xf0
1000b7f08:     	bfxil	x16, x13, #4, #4
1000b7f0c:     	ldrsb	w16, [x11, x16]
1000b7f10:     	ldrsb	w15, [x11, x15]
1000b7f14:     	lsr	x17, x14, #4
1000b7f18:     	and	x17, x17, #0xf0
1000b7f1c:     	bfxil	x17, x13, #8, #4
1000b7f20:     	lsr	x4, x14, #8
1000b7f24:     	ldrsb	w17, [x11, x17]
1000b7f28:     	and	x4, x4, #0xf0
1000b7f2c:     	bfxil	x4, x13, #12, #4
1000b7f30:     	lsr	x5, x14, #12
1000b7f34:     	and	x5, x5, #0xf0
1000b7f38:     	ldrsb	w4, [x11, x4]
1000b7f3c:     	bfxil	x5, x13, #16, #4
1000b7f40:     	lsr	x6, x14, #16
1000b7f44:     	and	x6, x6, #0xf0
1000b7f48:     	bfxil	x6, x13, #20, #4
1000b7f4c:     	ldrsb	w5, [x11, x5]
1000b7f50:     	ldrsb	w6, [x11, x6]
1000b7f54:     	lsr	x7, x14, #20
1000b7f58:     	and	x7, x7, #0xf0
1000b7f5c:     	add	w15, w15, w16
1000b7f60:     	add	w15, w15, w17
1000b7f64:     	bfxil	x7, x13, #24, #4
1000b7f68:     	ldrsb	w16, [x11, x7]
1000b7f6c:     	lsr	x14, x14, #24
1000b7f70:     	add	w15, w15, w4
1000b7f74:     	add	w15, w15, w5
1000b7f78:     	and	x17, x14, #0xf0
1000b7f7c:     	lsr	x14, x13, #28
1000b7f80:     	orr	x17, x17, x14
1000b7f84:     	ldrsb	w17, [x11, x17]
1000b7f88:     	add	w15, w15, w6
1000b7f8c:     	add	w15, w15, w16
1000b7f90:     	add	w15, w15, w17
1000b7f94:     	scvtf	s0, w15
1000b7f98:     	ldp	s1, s2, [x3]
1000b7f9c:     	fadd	s0, s1, s0
1000b7fa0:     	str	s0, [x3]
1000b7fa4:     	ldur	w15, [x9, #-4]
1000b7fa8:     	lsl	w16, w15, #4
1000b7fac:     	and	x16, x16, #0xf0
1000b7fb0:     	bfxil	x16, x13, #0, #4
1000b7fb4:     	and	x17, x15, #0xf0
1000b7fb8:     	bfxil	x17, x13, #4, #4
1000b7fbc:     	ldrsb	w17, [x11, x17]
1000b7fc0:     	ldrsb	w16, [x11, x16]
1000b7fc4:     	lsr	x4, x15, #4
1000b7fc8:     	and	x4, x4, #0xf0
1000b7fcc:     	bfxil	x4, x13, #8, #4
1000b7fd0:     	ldrsb	w4, [x11, x4]
1000b7fd4:     	lsr	x5, x15, #8
1000b7fd8:     	and	x5, x5, #0xf0
1000b7fdc:     	bfxil	x5, x13, #12, #4
1000b7fe0:     	ldrsb	w5, [x11, x5]
1000b7fe4:     	lsr	x6, x15, #12
1000b7fe8:     	and	x6, x6, #0xf0
1000b7fec:     	bfxil	x6, x13, #16, #4
1000b7ff0:     	ldrsb	w6, [x11, x6]
1000b7ff4:     	lsr	x7, x15, #16
1000b7ff8:     	and	x7, x7, #0xf0
1000b7ffc:     	bfxil	x7, x13, #20, #4
1000b8000:     	ldrsb	w7, [x11, x7]
1000b8004:     	add	w16, w16, w17
1000b8008:     	add	w16, w16, w4
1000b800c:     	lsr	x17, x15, #20
1000b8010:     	and	x17, x17, #0xf0
1000b8014:     	bfxil	x17, x13, #24, #4
1000b8018:     	add	w16, w16, w5
1000b801c:     	add	w16, w16, w6
1000b8020:     	ldrsb	w17, [x11, x17]
1000b8024:     	lsr	x15, x15, #24
1000b8028:     	and	x15, x15, #0xf0
1000b802c:     	add	w16, w16, w7
1000b8030:     	add	w16, w16, w17
1000b8034:     	orr	x15, x15, x14
1000b8038:     	ldrsb	w15, [x11, x15]
1000b803c:     	add	w15, w16, w15
1000b8040:     	scvtf	s0, w15
1000b8044:     	fadd	s0, s2, s0
1000b8048:     	str	s0, [x3, #4]
1000b804c:     	ldr	w15, [x9]
1000b8050:     	lsl	w16, w15, #4
1000b8054:     	and	x16, x16, #0xf0
1000b8058:     	bfxil	x16, x13, #0, #4
1000b805c:     	and	x17, x15, #0xf0
1000b8060:     	bfxil	x17, x13, #4, #4
1000b8064:     	ldrsb	w17, [x11, x17]
1000b8068:     	ldrsb	w16, [x11, x16]
1000b806c:     	lsr	x4, x15, #4
1000b8070:     	and	x4, x4, #0xf0
1000b8074:     	bfxil	x4, x13, #8, #4
1000b8078:     	ldrsb	w4, [x11, x4]
1000b807c:     	lsr	x5, x15, #8
1000b8080:     	and	x5, x5, #0xf0
1000b8084:     	bfxil	x5, x13, #12, #4
1000b8088:     	ldrsb	w5, [x11, x5]
1000b808c:     	lsr	x6, x15, #12
1000b8090:     	and	x6, x6, #0xf0
1000b8094:     	bfxil	x6, x13, #16, #4
1000b8098:     	lsr	x7, x15, #16
1000b809c:     	ldrsb	w6, [x11, x6]
1000b80a0:     	and	x7, x7, #0xf0
1000b80a4:     	bfxil	x7, x13, #20, #4
1000b80a8:     	ldrsb	w7, [x11, x7]
1000b80ac:     	add	w16, w16, w17
1000b80b0:     	add	w16, w16, w4
1000b80b4:     	lsr	x17, x15, #20
1000b80b8:     	and	x17, x17, #0xf0
1000b80bc:     	bfxil	x17, x13, #24, #4
1000b80c0:     	ldrsb	w17, [x11, x17]
1000b80c4:     	add	w16, w16, w5
1000b80c8:     	add	w16, w16, w6
1000b80cc:     	lsr	x15, x15, #24
1000b80d0:     	and	x15, x15, #0xf0
1000b80d4:     	orr	x15, x15, x14
1000b80d8:     	add	w16, w16, w7
1000b80dc:     	add	w16, w16, w17
1000b80e0:     	ldrsb	w15, [x11, x15]
1000b80e4:     	add	w15, w16, w15
1000b80e8:     	scvtf	s0, w15
1000b80ec:     	ldp	s1, s2, [x3, #8]
1000b80f0:     	fadd	s0, s1, s0
1000b80f4:     	str	s0, [x3, #8]
1000b80f8:     	ldr	w15, [x9, #4]
1000b80fc:     	lsl	w16, w15, #4
1000b8100:     	and	x16, x16, #0xf0
1000b8104:     	bfxil	x16, x13, #0, #4
1000b8108:     	and	x17, x15, #0xf0
1000b810c:     	bfxil	x17, x13, #4, #4
1000b8110:     	lsr	x4, x15, #4
1000b8114:     	and	x4, x4, #0xf0
1000b8118:     	bfxil	x4, x13, #8, #4
1000b811c:     	lsr	x5, x15, #8
1000b8120:     	and	x5, x5, #0xf0
1000b8124:     	bfxil	x5, x13, #12, #4
1000b8128:     	lsr	x6, x15, #12
1000b812c:     	and	x6, x6, #0xf0
1000b8130:     	bfxil	x6, x13, #16, #4
1000b8134:     	lsr	x7, x15, #16
1000b8138:     	and	x7, x7, #0xf0
1000b813c:     	bfxil	x7, x13, #20, #4
1000b8140:     	lsr	x19, x15, #20
1000b8144:     	and	x19, x19, #0xf0
1000b8148:     	bfxil	x19, x13, #24, #4
1000b814c:     	ldrsb	w13, [x11, x16]
1000b8150:     	ldrsb	w16, [x11, x17]
1000b8154:     	ldrsb	w17, [x11, x4]
1000b8158:     	ldrsb	w4, [x11, x5]
1000b815c:     	ldrsb	w5, [x11, x6]
1000b8160:     	add	w13, w13, w16
1000b8164:     	add	w13, w13, w17
1000b8168:     	ldrsb	w16, [x11, x7]
1000b816c:     	ldrsb	w17, [x11, x19]
1000b8170:     	add	w13, w13, w4
1000b8174:     	add	w13, w13, w5
1000b8178:     	lsr	x15, x15, #24
1000b817c:     	and	x15, x15, #0xf0
1000b8180:     	orr	x14, x15, x14
1000b8184:     	ldrsb	w14, [x11, x14]
1000b8188:     	add	w13, w13, w16
1000b818c:     	add	w13, w13, w17
1000b8190:     	add	w13, w13, w14
1000b8194:     	scvtf	s1, w13
1000b8198:     	fadd	s1, s2, s1
1000b819c:     	str	s1, [x3, #12]
1000b81a0:     	add	x13, x10, #8
1000b81a4:     	add	x12, x12, x8
1000b81a8:     	add	x9, x9, #16
1000b81ac:     	add	x14, x10, #16
1000b81b0:     	mov	x10, x13
1000b81b4:     	cmp	x14, x2
1000b81b8:     	b.ls	0x1000b7ef0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000b81bc:     	cmp	x13, x2
1000b81c0:     	b.hs	0x1000b82a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000b81c4:     	ldp	s2, s3, [x3]
1000b81c8:     	lsl	w9, w13, #2
1000b81cc:     	mov	w10, #-16
1000b81d0:     	lsr	x11, x13, #3
1000b81d4:     	mul	x12, x8, x11
1000b81d8:     	ubfx	x14, x13, #1, #2
1000b81dc:     	orr	x12, x12, x14
1000b81e0:     	ldrb	w12, [x1, x12]
1000b81e4:     	and	w15, w9, #0x4
1000b81e8:     	lsr	w12, w12, w15
1000b81ec:     	and	w16, w12, #0xf
1000b81f0:     	cmp	w16, #8
1000b81f4:     	csel	w16, wzr, w10, lo
1000b81f8:     	bfxil	w16, w12, #0, #4
1000b81fc:     	bfi	x14, x11, #4, #60
1000b8200:     	add	x11, x0, x14
1000b8204:     	ldrb	w12, [x11]
1000b8208:     	lsr	w12, w12, w15
1000b820c:     	scvtf	s4, w16
1000b8210:     	and	w14, w12, #0xf
1000b8214:     	cmp	w14, #8
1000b8218:     	csel	w14, wzr, w10, lo
1000b821c:     	bfxil	w14, w12, #0, #4
1000b8220:     	scvtf	s5, w14
1000b8224:     	fmsub	s2, s5, s4, s2
1000b8228:     	str	s2, [x3]
1000b822c:     	ldrb	w12, [x11, #4]
1000b8230:     	lsr	w12, w12, w15
1000b8234:     	and	w14, w12, #0xf
1000b8238:     	cmp	w14, #8
1000b823c:     	csel	w14, wzr, w10, lo
1000b8240:     	bfxil	w14, w12, #0, #4
1000b8244:     	scvtf	s5, w14
1000b8248:     	fmsub	s3, s5, s4, s3
1000b824c:     	str	s3, [x3, #4]
1000b8250:     	ldrb	w12, [x11, #8]
1000b8254:     	lsr	w12, w12, w15
1000b8258:     	and	w14, w12, #0xf
1000b825c:     	cmp	w14, #8
1000b8260:     	csel	w14, wzr, w10, lo
1000b8264:     	bfxil	w14, w12, #0, #4
1000b8268:     	scvtf	s5, w14
1000b826c:     	fmsub	s0, s5, s4, s0
1000b8270:     	str	s0, [x3, #8]
1000b8274:     	ldrb	w11, [x11, #12]
1000b8278:     	lsr	w11, w11, w15
1000b827c:     	and	w12, w11, #0xf
1000b8280:     	cmp	w12, #8
1000b8284:     	csel	w12, wzr, w10, lo
1000b8288:     	bfxil	w12, w11, #0, #4
1000b828c:     	scvtf	s5, w12
1000b8290:     	fmsub	s1, s5, s4, s1
1000b8294:     	str	s1, [x3, #12]
1000b8298:     	add	x13, x13, #1
1000b829c:     	add	w9, w9, #4
1000b82a0:     	cmp	x2, x13
1000b82a4:     	b.ne	0x1000b81d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x318>
1000b82a8:     	ldp	x20, x19, [sp], #16
1000b82ac:     	ret

