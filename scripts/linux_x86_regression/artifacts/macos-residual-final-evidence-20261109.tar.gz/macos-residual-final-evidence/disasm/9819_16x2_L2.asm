00000001000c5d60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c5d60:     	sub	sp, sp, #272
1000c5d64:     	stp	x28, x27, [sp, #176]
1000c5d68:     	stp	x26, x25, [sp, #192]
1000c5d6c:     	stp	x24, x23, [sp, #208]
1000c5d70:     	stp	x22, x21, [sp, #224]
1000c5d74:     	stp	x20, x19, [sp, #240]
1000c5d78:     	stp	x29, x30, [sp, #256]
1000c5d7c:     	add	x29, sp, #256
1000c5d80:     	str	x3, [sp]
1000c5d84:     	adrp	x8, 0x100168000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c5d88:     	ldr	x8, [x8, #392]
1000c5d8c:     	ldr	x8, [x8]
1000c5d90:     	stur	x8, [x29, #-96]
1000c5d94:     	movi.2d	v0, #0000000000000000
1000c5d98:     	stp	q0, q0, [sp, #128]
1000c5d9c:     	stp	q0, q0, [sp, #96]
1000c5da0:     	stp	q0, q0, [sp, #64]
1000c5da4:     	stp	q0, q0, [sp, #32]
1000c5da8:     	ands	x8, x2, #0xfffffffffffffffe
1000c5dac:     	b.eq	0x1000c5f50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1f0>
1000c5db0:     	add	x8, x1, x8
1000c5db4:     	str	x8, [sp, #8]
1000c5db8:     	adrp	x9, 0x100166000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x8c>
1000c5dbc:     	add	x9, x9, #1244
1000c5dc0:     	mov	x11, #0
1000c5dc4:     	ldp	w4, w23, [x1]
1000c5dc8:     	ubfx	x8, x4, #4, #4
1000c5dcc:     	stp	x1, x8, [sp, #16]
1000c5dd0:     	ubfx	x13, x4, #8, #4
1000c5dd4:     	and	x14, x4, #0xf
1000c5dd8:     	ubfx	x15, x4, #12, #4
1000c5ddc:     	ubfx	x16, x4, #16, #4
1000c5de0:     	ubfx	x17, x4, #20, #4
1000c5de4:     	ubfx	x2, x4, #24, #4
1000c5de8:     	lsr	x4, x4, #28
1000c5dec:     	and	x5, x23, #0xf
1000c5df0:     	ubfx	x6, x23, #4, #4
1000c5df4:     	ubfx	x7, x23, #8, #4
1000c5df8:     	ubfx	x19, x23, #12, #4
1000c5dfc:     	ubfx	x20, x23, #16, #4
1000c5e00:     	ubfx	x21, x23, #20, #4
1000c5e04:     	ubfx	x22, x23, #24, #4
1000c5e08:     	lsr	x23, x23, #28
1000c5e0c:     	ldr	w24, [x0, x11]
1000c5e10:     	lsl	w25, w24, #4
1000c5e14:     	and	x25, x25, #0xf0
1000c5e18:     	orr	x26, x25, x14
1000c5e1c:     	ldrb	w26, [x9, x26]
1000c5e20:     	and	x27, x24, #0xf0
1000c5e24:     	ldr	x8, [sp, #24]
1000c5e28:     	orr	x28, x27, x8
1000c5e2c:     	ldrb	w28, [x9, x28]
1000c5e30:     	lsr	x30, x24, #4
1000c5e34:     	and	x30, x30, #0xf0
1000c5e38:     	orr	x8, x30, x13
1000c5e3c:     	ldrb	w8, [x9, x8]
1000c5e40:     	add	w26, w26, w28
1000c5e44:     	add	w8, w26, w8
1000c5e48:     	lsr	x26, x24, #8
1000c5e4c:     	and	x26, x26, #0xf0
1000c5e50:     	orr	x28, x26, x15
1000c5e54:     	ldrb	w28, [x9, x28]
1000c5e58:     	lsr	x3, x24, #12
1000c5e5c:     	and	x3, x3, #0xf0
1000c5e60:     	orr	x10, x3, x16
1000c5e64:     	ldrb	w10, [x9, x10]
1000c5e68:     	add	w8, w8, w28
1000c5e6c:     	add	w8, w8, w10
1000c5e70:     	lsr	x10, x24, #16
1000c5e74:     	and	x10, x10, #0xf0
1000c5e78:     	orr	x28, x10, x17
1000c5e7c:     	ldrb	w28, [x9, x28]
1000c5e80:     	lsr	x1, x24, #20
1000c5e84:     	and	x1, x1, #0xf0
1000c5e88:     	orr	x12, x1, x2
1000c5e8c:     	ldrb	w12, [x9, x12]
1000c5e90:     	add	w8, w8, w28
1000c5e94:     	add	x28, sp, #32
1000c5e98:     	add	w8, w8, w12
1000c5e9c:     	lsr	x12, x24, #24
1000c5ea0:     	and	x12, x12, #0xf0
1000c5ea4:     	orr	x24, x12, x4
1000c5ea8:     	ldrb	w24, [x9, x24]
1000c5eac:     	add	w8, w8, w24
1000c5eb0:     	scvtf	s0, w8
1000c5eb4:     	add	x8, x28, x11
1000c5eb8:     	ldr	s1, [x8]
1000c5ebc:     	fadd	s0, s1, s0
1000c5ec0:     	orr	x24, x25, x5
1000c5ec4:     	ldrb	w24, [x9, x24]
1000c5ec8:     	orr	x25, x27, x6
1000c5ecc:     	ldrb	w25, [x9, x25]
1000c5ed0:     	orr	x27, x30, x7
1000c5ed4:     	ldrb	w27, [x9, x27]
1000c5ed8:     	add	w24, w24, w25
1000c5edc:     	add	w24, w24, w27
1000c5ee0:     	orr	x25, x26, x19
1000c5ee4:     	ldrb	w25, [x9, x25]
1000c5ee8:     	orr	x3, x3, x20
1000c5eec:     	ldrb	w3, [x9, x3]
1000c5ef0:     	orr	x10, x10, x21
1000c5ef4:     	ldrb	w10, [x9, x10]
1000c5ef8:     	add	w24, w24, w25
1000c5efc:     	add	w3, w24, w3
1000c5f00:     	orr	x1, x1, x22
1000c5f04:     	ldrb	w1, [x9, x1]
1000c5f08:     	add	w10, w3, w10
1000c5f0c:     	add	w10, w10, w1
1000c5f10:     	orr	x12, x12, x23
1000c5f14:     	ldrb	w12, [x9, x12]
1000c5f18:     	add	w10, w10, w12
1000c5f1c:     	scvtf	s1, w10
1000c5f20:     	str	s0, [x8]
1000c5f24:     	ldr	s0, [x8, #64]
1000c5f28:     	fadd	s0, s0, s1
1000c5f2c:     	str	s0, [x8, #64]
1000c5f30:     	add	x11, x11, #4
1000c5f34:     	cmp	x11, #64
1000c5f38:     	b.ne	0x1000c5e0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c5f3c:     	add	x0, x0, #64
1000c5f40:     	ldp	x8, x1, [sp, #8]
1000c5f44:     	add	x1, x1, #8
1000c5f48:     	cmp	x1, x8
1000c5f4c:     	b.ne	0x1000c5dc0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c5f50:     	ldp	q0, q1, [sp, #96]
1000c5f54:     	ldr	x8, [sp]
1000c5f58:     	stp	q0, q1, [x8, #64]
1000c5f5c:     	ldp	q0, q1, [sp, #128]
1000c5f60:     	stp	q0, q1, [x8, #96]
1000c5f64:     	ldp	q0, q1, [sp, #32]
1000c5f68:     	stp	q0, q1, [x8]
1000c5f6c:     	ldp	q0, q1, [sp, #64]
1000c5f70:     	stp	q0, q1, [x8, #32]
1000c5f74:     	ldur	x8, [x29, #-96]
1000c5f78:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x198>
1000c5f7c:     	ldr	x9, [x9, #392]
1000c5f80:     	ldr	x9, [x9]
1000c5f84:     	cmp	x9, x8
1000c5f88:     	b.ne	0x1000c5fac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24c>
1000c5f8c:     	ldp	x29, x30, [sp, #256]
1000c5f90:     	ldp	x20, x19, [sp, #240]
1000c5f94:     	ldp	x22, x21, [sp, #224]
1000c5f98:     	ldp	x24, x23, [sp, #208]
1000c5f9c:     	ldp	x26, x25, [sp, #192]
1000c5fa0:     	ldp	x28, x27, [sp, #176]
1000c5fa4:     	add	sp, sp, #272
1000c5fa8:     	ret
1000c5fac:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

