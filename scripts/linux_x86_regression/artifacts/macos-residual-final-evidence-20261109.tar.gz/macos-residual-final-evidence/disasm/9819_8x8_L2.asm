00000001000c2cac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c2cac:     	sub	sp, sp, #320
1000c2cb0:     	stp	x22, x21, [sp, #272]
1000c2cb4:     	stp	x20, x19, [sp, #288]
1000c2cb8:     	stp	x29, x30, [sp, #304]
1000c2cbc:     	add	x29, sp, #304
1000c2cc0:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c2cc4:     	ldr	x8, [x8, #392]
1000c2cc8:     	ldr	x8, [x8]
1000c2ccc:     	stur	x8, [x29, #-40]
1000c2cd0:     	movi.2d	v0, #0000000000000000
1000c2cd4:     	stp	q0, q0, [sp, #224]
1000c2cd8:     	lsl	x8, x2, #2
1000c2cdc:     	stp	q0, q0, [sp, #192]
1000c2ce0:     	stp	q0, q0, [sp, #160]
1000c2ce4:     	stp	q0, q0, [sp, #128]
1000c2ce8:     	stp	q0, q0, [sp, #96]
1000c2cec:     	stp	q0, q0, [sp, #64]
1000c2cf0:     	stp	q0, q0, [sp, #32]
1000c2cf4:     	stp	q0, q0, [sp]
1000c2cf8:     	ands	x8, x8, #0xfffffffffffffff8
1000c2cfc:     	b.eq	0x1000c2e14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x168>
1000c2d00:     	add	x8, x1, x8
1000c2d04:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x10c>
1000c2d08:     	add	x9, x9, #732
1000c2d0c:     	mov	x10, #0
1000c2d10:     	mov	x11, sp
1000c2d14:     	mov	x12, #0
1000c2d18:     	ldr	w5, [x0, x10, lsl #2]
1000c2d1c:     	lsl	w13, w5, #4
1000c2d20:     	and	x13, x13, #0xf0
1000c2d24:     	and	x14, x5, #0xf0
1000c2d28:     	lsr	x15, x5, #4
1000c2d2c:     	and	x15, x15, #0xf0
1000c2d30:     	lsr	x16, x5, #8
1000c2d34:     	and	x16, x16, #0xf0
1000c2d38:     	lsr	x17, x5, #12
1000c2d3c:     	and	x17, x17, #0xf0
1000c2d40:     	lsr	x2, x5, #16
1000c2d44:     	and	x2, x2, #0xf0
1000c2d48:     	lsr	x4, x5, #20
1000c2d4c:     	and	x4, x4, #0xf0
1000c2d50:     	lsr	x5, x5, #24
1000c2d54:     	and	x5, x5, #0xf0
1000c2d58:     	mov	x6, x11
1000c2d5c:     	ldr	w7, [x1, x12]
1000c2d60:     	and	x19, x7, #0xf
1000c2d64:     	orr	x19, x13, x19
1000c2d68:     	ldrb	w19, [x9, x19]
1000c2d6c:     	ubfx	x20, x7, #4, #4
1000c2d70:     	orr	x20, x14, x20
1000c2d74:     	ldrb	w20, [x9, x20]
1000c2d78:     	ubfx	x21, x7, #8, #4
1000c2d7c:     	orr	x21, x15, x21
1000c2d80:     	ldrb	w21, [x9, x21]
1000c2d84:     	add	w19, w19, w20
1000c2d88:     	add	w19, w19, w21
1000c2d8c:     	ubfx	x20, x7, #12, #4
1000c2d90:     	orr	x20, x16, x20
1000c2d94:     	ldrb	w20, [x9, x20]
1000c2d98:     	ubfx	x21, x7, #16, #4
1000c2d9c:     	orr	x21, x17, x21
1000c2da0:     	ldrb	w21, [x9, x21]
1000c2da4:     	add	w19, w19, w20
1000c2da8:     	add	w19, w19, w21
1000c2dac:     	ubfx	x20, x7, #20, #4
1000c2db0:     	orr	x20, x2, x20
1000c2db4:     	ldrb	w20, [x9, x20]
1000c2db8:     	ubfx	x21, x7, #24, #4
1000c2dbc:     	orr	x21, x4, x21
1000c2dc0:     	ldrb	w21, [x9, x21]
1000c2dc4:     	add	w19, w19, w20
1000c2dc8:     	add	w19, w19, w21
1000c2dcc:     	orr	x7, x5, x7, lsr #28
1000c2dd0:     	ldrb	w7, [x9, x7]
1000c2dd4:     	add	w7, w19, w7
1000c2dd8:     	scvtf	s0, w7
1000c2ddc:     	ldr	s1, [x6]
1000c2de0:     	fadd	s0, s1, s0
1000c2de4:     	str	s0, [x6], #32
1000c2de8:     	add	x12, x12, #4
1000c2dec:     	cmp	x12, #32
1000c2df0:     	b.ne	0x1000c2d5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c2df4:     	add	x10, x10, #1
1000c2df8:     	add	x11, x11, #4
1000c2dfc:     	cmp	x10, #8
1000c2e00:     	b.ne	0x1000c2d14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x68>
1000c2e04:     	add	x0, x0, #32
1000c2e08:     	add	x1, x1, #32
1000c2e0c:     	cmp	x1, x8
1000c2e10:     	b.ne	0x1000c2d0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c2e14:     	ldp	q0, q1, [sp, #192]
1000c2e18:     	stp	q0, q1, [x3, #192]
1000c2e1c:     	ldp	q0, q1, [sp, #224]
1000c2e20:     	stp	q0, q1, [x3, #224]
1000c2e24:     	ldp	q0, q1, [sp, #128]
1000c2e28:     	stp	q0, q1, [x3, #128]
1000c2e2c:     	ldp	q0, q1, [sp, #160]
1000c2e30:     	stp	q0, q1, [x3, #160]
1000c2e34:     	ldp	q0, q1, [sp, #64]
1000c2e38:     	stp	q0, q1, [x3, #64]
1000c2e3c:     	ldp	q0, q1, [sp, #96]
1000c2e40:     	stp	q0, q1, [x3, #96]
1000c2e44:     	ldp	q0, q1, [sp]
1000c2e48:     	stp	q0, q1, [x3]
1000c2e4c:     	ldp	q0, q1, [sp, #32]
1000c2e50:     	stp	q0, q1, [x3, #32]
1000c2e54:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd8>
1000c2e58:     	ldr	x8, [x8, #392]
1000c2e5c:     	ldr	x8, [x8]
1000c2e60:     	ldur	x9, [x29, #-40]
1000c2e64:     	cmp	x8, x9
1000c2e68:     	b.ne	0x1000c2e80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d4>
1000c2e6c:     	ldp	x29, x30, [sp, #304]
1000c2e70:     	ldp	x20, x19, [sp, #288]
1000c2e74:     	ldp	x22, x21, [sp, #272]
1000c2e78:     	add	sp, sp, #320
1000c2e7c:     	ret
1000c2e80:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

