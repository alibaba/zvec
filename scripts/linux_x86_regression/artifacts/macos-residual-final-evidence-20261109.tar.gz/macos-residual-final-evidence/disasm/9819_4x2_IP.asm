00000001000ba098 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ba098:     	sub	sp, sp, #176
1000ba09c:     	stp	x28, x27, [sp, #80]
1000ba0a0:     	stp	x26, x25, [sp, #96]
1000ba0a4:     	stp	x24, x23, [sp, #112]
1000ba0a8:     	stp	x22, x21, [sp, #128]
1000ba0ac:     	stp	x20, x19, [sp, #144]
1000ba0b0:     	stp	x29, x30, [sp, #160]
1000ba0b4:     	add	x29, sp, #160
1000ba0b8:     	str	x3, [sp]
1000ba0bc:     	adrp	x8, 0x100168000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xb0>
1000ba0c0:     	ldr	x8, [x8, #392]
1000ba0c4:     	ldr	x8, [x8]
1000ba0c8:     	str	x8, [sp, #72]
1000ba0cc:     	movi.2d	v0, #0000000000000000
1000ba0d0:     	stp	q0, q0, [sp, #32]
1000ba0d4:     	ands	x8, x2, #0xfffffffffffffffe
1000ba0d8:     	b.eq	0x1000ba27c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000ba0dc:     	add	x8, x1, x8
1000ba0e0:     	str	x8, [sp, #8]
1000ba0e4:     	adrp	x9, 0x100166000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xd0>
1000ba0e8:     	add	x9, x9, #476
1000ba0ec:     	mov	x11, #0
1000ba0f0:     	ldp	w4, w23, [x1]
1000ba0f4:     	ubfx	x8, x4, #4, #4
1000ba0f8:     	stp	x1, x8, [sp, #16]
1000ba0fc:     	ubfx	x13, x4, #8, #4
1000ba100:     	and	x14, x4, #0xf
1000ba104:     	ubfx	x15, x4, #12, #4
1000ba108:     	ubfx	x16, x4, #16, #4
1000ba10c:     	ubfx	x17, x4, #20, #4
1000ba110:     	ubfx	x2, x4, #24, #4
1000ba114:     	lsr	x4, x4, #28
1000ba118:     	and	x5, x23, #0xf
1000ba11c:     	ubfx	x6, x23, #4, #4
1000ba120:     	ubfx	x7, x23, #8, #4
1000ba124:     	ubfx	x19, x23, #12, #4
1000ba128:     	ubfx	x20, x23, #16, #4
1000ba12c:     	ubfx	x21, x23, #20, #4
1000ba130:     	ubfx	x22, x23, #24, #4
1000ba134:     	lsr	x23, x23, #28
1000ba138:     	ldr	w24, [x0, x11]
1000ba13c:     	lsl	w25, w24, #4
1000ba140:     	and	x25, x25, #0xf0
1000ba144:     	orr	x26, x25, x14
1000ba148:     	ldrsb	w26, [x9, x26]
1000ba14c:     	and	x27, x24, #0xf0
1000ba150:     	ldr	x8, [sp, #24]
1000ba154:     	orr	x28, x27, x8
1000ba158:     	ldrsb	w28, [x9, x28]
1000ba15c:     	lsr	x30, x24, #4
1000ba160:     	and	x30, x30, #0xf0
1000ba164:     	orr	x8, x30, x13
1000ba168:     	ldrsb	w8, [x9, x8]
1000ba16c:     	add	w26, w26, w28
1000ba170:     	add	w8, w26, w8
1000ba174:     	lsr	x26, x24, #8
1000ba178:     	and	x26, x26, #0xf0
1000ba17c:     	orr	x28, x26, x15
1000ba180:     	ldrsb	w28, [x9, x28]
1000ba184:     	lsr	x3, x24, #12
1000ba188:     	and	x3, x3, #0xf0
1000ba18c:     	orr	x10, x3, x16
1000ba190:     	ldrsb	w10, [x9, x10]
1000ba194:     	add	w8, w8, w28
1000ba198:     	add	w8, w8, w10
1000ba19c:     	lsr	x10, x24, #16
1000ba1a0:     	and	x10, x10, #0xf0
1000ba1a4:     	orr	x28, x10, x17
1000ba1a8:     	ldrsb	w28, [x9, x28]
1000ba1ac:     	lsr	x1, x24, #20
1000ba1b0:     	and	x1, x1, #0xf0
1000ba1b4:     	orr	x12, x1, x2
1000ba1b8:     	ldrsb	w12, [x9, x12]
1000ba1bc:     	add	w8, w8, w28
1000ba1c0:     	add	x28, sp, #32
1000ba1c4:     	add	w8, w8, w12
1000ba1c8:     	lsr	x12, x24, #24
1000ba1cc:     	and	x12, x12, #0xf0
1000ba1d0:     	orr	x24, x12, x4
1000ba1d4:     	ldrsb	w24, [x9, x24]
1000ba1d8:     	add	w8, w8, w24
1000ba1dc:     	scvtf	s0, w8
1000ba1e0:     	add	x8, x28, x11
1000ba1e4:     	ldr	s1, [x8]
1000ba1e8:     	fadd	s0, s1, s0
1000ba1ec:     	orr	x24, x25, x5
1000ba1f0:     	ldrsb	w24, [x9, x24]
1000ba1f4:     	orr	x25, x27, x6
1000ba1f8:     	ldrsb	w25, [x9, x25]
1000ba1fc:     	orr	x27, x30, x7
1000ba200:     	ldrsb	w27, [x9, x27]
1000ba204:     	add	w24, w24, w25
1000ba208:     	add	w24, w24, w27
1000ba20c:     	orr	x25, x26, x19
1000ba210:     	ldrsb	w25, [x9, x25]
1000ba214:     	orr	x3, x3, x20
1000ba218:     	ldrsb	w3, [x9, x3]
1000ba21c:     	orr	x10, x10, x21
1000ba220:     	ldrsb	w10, [x9, x10]
1000ba224:     	add	w24, w24, w25
1000ba228:     	add	w3, w24, w3
1000ba22c:     	orr	x1, x1, x22
1000ba230:     	ldrsb	w1, [x9, x1]
1000ba234:     	add	w10, w3, w10
1000ba238:     	add	w10, w10, w1
1000ba23c:     	orr	x12, x12, x23
1000ba240:     	ldrsb	w12, [x9, x12]
1000ba244:     	add	w10, w10, w12
1000ba248:     	scvtf	s1, w10
1000ba24c:     	str	s0, [x8]
1000ba250:     	ldr	s0, [x8, #16]
1000ba254:     	fadd	s0, s0, s1
1000ba258:     	str	s0, [x8, #16]
1000ba25c:     	add	x11, x11, #4
1000ba260:     	cmp	x11, #16
1000ba264:     	b.ne	0x1000ba138 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000ba268:     	add	x0, x0, #16
1000ba26c:     	ldp	x8, x1, [sp, #8]
1000ba270:     	add	x1, x1, #8
1000ba274:     	cmp	x1, x8
1000ba278:     	b.ne	0x1000ba0ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000ba27c:     	ldp	q0, q1, [sp, #32]
1000ba280:     	ldr	x8, [sp]
1000ba284:     	stp	q0, q1, [x8]
1000ba288:     	ldr	x8, [sp, #72]
1000ba28c:     	adrp	x9, 0x100168000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0x280>
1000ba290:     	ldr	x9, [x9, #392]
1000ba294:     	ldr	x9, [x9]
1000ba298:     	cmp	x9, x8
1000ba29c:     	b.ne	0x1000ba2c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000ba2a0:     	ldp	x29, x30, [sp, #160]
1000ba2a4:     	ldp	x20, x19, [sp, #144]
1000ba2a8:     	ldp	x22, x21, [sp, #128]
1000ba2ac:     	ldp	x24, x23, [sp, #112]
1000ba2b0:     	ldp	x26, x25, [sp, #96]
1000ba2b4:     	ldp	x28, x27, [sp, #80]
1000ba2b8:     	add	sp, sp, #176
1000ba2bc:     	ret
1000ba2c0:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

