00000001000d5be8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5be8:     	stp	x28, x27, [sp, #-64]!
1000d5bec:     	stp	x22, x21, [sp, #16]
1000d5bf0:     	stp	x20, x19, [sp, #32]
1000d5bf4:     	stp	x29, x30, [sp, #48]
1000d5bf8:     	add	x29, sp, #48
1000d5bfc:     	mov	w9, #4112
1000d5c00:     	adrp	x16, 0x100168000 <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d5c04:     	ldr	x16, [x16, #304]
1000d5c08:     	blr	x16
1000d5c0c:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d5c10:     	sub	sp, sp, #16
1000d5c14:     	mov	x19, x3
1000d5c18:     	mov	x20, x1
1000d5c1c:     	mov	x21, x0
1000d5c20:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x10>
1000d5c24:     	ldr	x8, [x8, #392]
1000d5c28:     	ldr	x8, [x8]
1000d5c2c:     	stur	x8, [x29, #-56]
1000d5c30:     	lsl	x8, x2, #4
1000d5c34:     	and	x22, x8, #0xffffffffffffffe0
1000d5c38:     	add	x0, sp, #8
1000d5c3c:     	mov	w1, #4096
1000d5c40:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d5c44:     	cbz	x22, 0x1000d5d5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d5c48:     	add	x8, x20, x22
1000d5c4c:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x34>
1000d5c50:     	add	x9, x9, #1756
1000d5c54:     	mov	x10, #0
1000d5c58:     	add	x11, sp, #8
1000d5c5c:     	mov	x12, #0
1000d5c60:     	ldr	w2, [x21, x10, lsl #2]
1000d5c64:     	lsl	w13, w2, #4
1000d5c68:     	and	x13, x13, #0xf0
1000d5c6c:     	and	x14, x2, #0xf0
1000d5c70:     	lsr	x15, x2, #4
1000d5c74:     	and	x15, x15, #0xf0
1000d5c78:     	lsr	x16, x2, #8
1000d5c7c:     	and	x16, x16, #0xf0
1000d5c80:     	lsr	x17, x2, #12
1000d5c84:     	and	x17, x17, #0xf0
1000d5c88:     	lsr	x0, x2, #16
1000d5c8c:     	and	x0, x0, #0xf0
1000d5c90:     	lsr	x1, x2, #20
1000d5c94:     	and	x1, x1, #0xf0
1000d5c98:     	lsr	x2, x2, #24
1000d5c9c:     	and	x2, x2, #0xf0
1000d5ca0:     	mov	x3, x11
1000d5ca4:     	ldr	w4, [x20, x12]
1000d5ca8:     	and	x5, x4, #0xf
1000d5cac:     	orr	x5, x13, x5
1000d5cb0:     	ldrb	w5, [x9, x5]
1000d5cb4:     	ubfx	x6, x4, #4, #4
1000d5cb8:     	orr	x6, x14, x6
1000d5cbc:     	ldrb	w6, [x9, x6]
1000d5cc0:     	ubfx	x7, x4, #8, #4
1000d5cc4:     	orr	x7, x15, x7
1000d5cc8:     	ldrb	w7, [x9, x7]
1000d5ccc:     	add	w5, w5, w6
1000d5cd0:     	add	w5, w5, w7
1000d5cd4:     	ubfx	x6, x4, #12, #4
1000d5cd8:     	orr	x6, x16, x6
1000d5cdc:     	ldrb	w6, [x9, x6]
1000d5ce0:     	ubfx	x7, x4, #16, #4
1000d5ce4:     	orr	x7, x17, x7
1000d5ce8:     	ldrb	w7, [x9, x7]
1000d5cec:     	add	w5, w5, w6
1000d5cf0:     	add	w5, w5, w7
1000d5cf4:     	ubfx	x6, x4, #20, #4
1000d5cf8:     	orr	x6, x0, x6
1000d5cfc:     	ldrb	w6, [x9, x6]
1000d5d00:     	ubfx	x7, x4, #24, #4
1000d5d04:     	orr	x7, x1, x7
1000d5d08:     	ldrb	w7, [x9, x7]
1000d5d0c:     	add	w5, w5, w6
1000d5d10:     	add	w5, w5, w7
1000d5d14:     	orr	x4, x2, x4, lsr #28
1000d5d18:     	ldrb	w4, [x9, x4]
1000d5d1c:     	add	w4, w5, w4
1000d5d20:     	scvtf	s0, w4
1000d5d24:     	ldr	s1, [x3]
1000d5d28:     	fadd	s0, s1, s0
1000d5d2c:     	str	s0, [x3], #128
1000d5d30:     	add	x12, x12, #4
1000d5d34:     	cmp	x12, #128
1000d5d38:     	b.ne	0x1000d5ca4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d5d3c:     	add	x10, x10, #1
1000d5d40:     	add	x11, x11, #4
1000d5d44:     	cmp	x10, #32
1000d5d48:     	b.ne	0x1000d5c5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d5d4c:     	add	x21, x21, #128
1000d5d50:     	add	x20, x20, #128
1000d5d54:     	cmp	x20, x8
1000d5d58:     	b.ne	0x1000d5c54 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d5d5c:     	add	x1, sp, #8
1000d5d60:     	mov	x0, x19
1000d5d64:     	mov	w2, #4096
1000d5d68:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d5d6c:     	ldur	x8, [x29, #-56]
1000d5d70:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d5d74:     	ldr	x9, [x9, #392]
1000d5d78:     	ldr	x9, [x9]
1000d5d7c:     	cmp	x9, x8
1000d5d80:     	b.ne	0x1000d5da0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d5d84:     	add	sp, sp, #1, lsl #12     ; =4096
1000d5d88:     	add	sp, sp, #16
1000d5d8c:     	ldp	x29, x30, [sp, #48]
1000d5d90:     	ldp	x20, x19, [sp, #32]
1000d5d94:     	ldp	x22, x21, [sp, #16]
1000d5d98:     	ldp	x28, x27, [sp], #64
1000d5d9c:     	ret
1000d5da0:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

