00000001000b6504 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b6504:     	stp	x22, x21, [sp, #-32]!
1000b6508:     	stp	x20, x19, [sp, #16]
1000b650c:     	ands	x8, x2, #0xfffffffffffffffe
1000b6510:     	b.eq	0x1000b6794 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b6514:     	add	x8, x1, x8
1000b6518:     	movi	d0, #0000000000000000
1000b651c:     	adrp	x9, 0x100165000 <void run<unsigned char, 4ul, 1ul, false>(char const*)+0x18>
1000b6520:     	add	x9, x9, #4060
1000b6524:     	movi	d1, #0000000000000000
1000b6528:     	movi	d2, #0000000000000000
1000b652c:     	movi	d3, #0000000000000000
1000b6530:     	ldp	w10, w11, [x0]
1000b6534:     	lsl	w12, w10, #4
1000b6538:     	and	x14, x12, #0xf0
1000b653c:     	mov	x15, x14
1000b6540:     	ldp	w12, w13, [x1]
1000b6544:     	bfxil	x15, x12, #0, #4
1000b6548:     	ldrsb	w15, [x9, x15]
1000b654c:     	and	x16, x10, #0xf0
1000b6550:     	mov	x17, x16
1000b6554:     	bfxil	x17, x12, #4, #4
1000b6558:     	ldrsb	w17, [x9, x17]
1000b655c:     	lsr	x2, x10, #4
1000b6560:     	and	x2, x2, #0xf0
1000b6564:     	mov	x4, x2
1000b6568:     	bfxil	x4, x12, #8, #4
1000b656c:     	ldrsb	w4, [x9, x4]
1000b6570:     	lsr	x5, x10, #8
1000b6574:     	and	x5, x5, #0xf0
1000b6578:     	mov	x6, x5
1000b657c:     	bfxil	x6, x12, #12, #4
1000b6580:     	ldrsb	w6, [x9, x6]
1000b6584:     	lsr	x7, x10, #12
1000b6588:     	and	x7, x7, #0xf0
1000b658c:     	mov	x19, x7
1000b6590:     	bfxil	x19, x12, #16, #4
1000b6594:     	ldrsb	w19, [x9, x19]
1000b6598:     	add	w15, w15, w17
1000b659c:     	add	w15, w15, w4
1000b65a0:     	lsr	x17, x10, #16
1000b65a4:     	and	x17, x17, #0xf0
1000b65a8:     	mov	x4, x17
1000b65ac:     	bfxil	x4, x12, #20, #4
1000b65b0:     	add	w15, w15, w6
1000b65b4:     	add	w15, w15, w19
1000b65b8:     	ldrsb	w4, [x9, x4]
1000b65bc:     	lsr	x6, x10, #20
1000b65c0:     	and	x6, x6, #0xf0
1000b65c4:     	mov	x19, x6
1000b65c8:     	bfxil	x19, x12, #24, #4
1000b65cc:     	ldrsb	w19, [x9, x19]
1000b65d0:     	add	w15, w15, w4
1000b65d4:     	add	w15, w15, w19
1000b65d8:     	lsr	x10, x10, #24
1000b65dc:     	and	x4, x10, #0xf0
1000b65e0:     	lsr	x10, x12, #28
1000b65e4:     	orr	x19, x4, x10
1000b65e8:     	ldrsb	w19, [x9, x19]
1000b65ec:     	add	w15, w15, w19
1000b65f0:     	scvtf	s4, w15
1000b65f4:     	fadd	s0, s0, s4
1000b65f8:     	bfxil	x14, x13, #0, #4
1000b65fc:     	ldrsb	w14, [x9, x14]
1000b6600:     	and	x15, x13, #0xf
1000b6604:     	ubfx	x19, x13, #4, #4
1000b6608:     	bfxil	x16, x13, #4, #4
1000b660c:     	ldrsb	w16, [x9, x16]
1000b6610:     	ubfx	x20, x13, #8, #4
1000b6614:     	bfxil	x2, x13, #8, #4
1000b6618:     	ldrsb	w2, [x9, x2]
1000b661c:     	add	w14, w14, w16
1000b6620:     	add	w14, w14, w2
1000b6624:     	ubfx	x16, x13, #12, #4
1000b6628:     	bfxil	x5, x13, #12, #4
1000b662c:     	ldrsb	w2, [x9, x5]
1000b6630:     	bfxil	x7, x13, #16, #4
1000b6634:     	ldrsb	w5, [x9, x7]
1000b6638:     	ubfx	x7, x13, #16, #4
1000b663c:     	add	w14, w14, w2
1000b6640:     	add	w14, w14, w5
1000b6644:     	bfxil	x17, x13, #20, #4
1000b6648:     	ldrsb	w17, [x9, x17]
1000b664c:     	bfxil	x6, x13, #24, #4
1000b6650:     	ldrsb	w2, [x9, x6]
1000b6654:     	add	w14, w14, w17
1000b6658:     	add	w17, w14, w2
1000b665c:     	lsr	x14, x13, #28
1000b6660:     	orr	x2, x4, x14
1000b6664:     	ldrsb	w2, [x9, x2]
1000b6668:     	add	w17, w17, w2
1000b666c:     	scvtf	s4, w17
1000b6670:     	ubfx	x17, x13, #20, #4
1000b6674:     	fadd	s2, s2, s4
1000b6678:     	lsl	w2, w11, #4
1000b667c:     	and	x2, x2, #0xf0
1000b6680:     	orr	w15, w2, w15
1000b6684:     	bfxil	x2, x12, #0, #4
1000b6688:     	ldrsb	w2, [x9, x2]
1000b668c:     	and	x4, x11, #0xf0
1000b6690:     	orr	w5, w4, w19
1000b6694:     	bfxil	x4, x12, #4, #4
1000b6698:     	ldrsb	w4, [x9, x4]
1000b669c:     	lsr	x6, x11, #4
1000b66a0:     	and	x6, x6, #0xf0
1000b66a4:     	orr	w19, w6, w20
1000b66a8:     	bfxil	x6, x12, #8, #4
1000b66ac:     	ldrsb	w6, [x9, x6]
1000b66b0:     	add	w2, w2, w4
1000b66b4:     	add	w2, w2, w6
1000b66b8:     	lsr	x4, x11, #8
1000b66bc:     	and	x4, x4, #0xf0
1000b66c0:     	orr	w16, w4, w16
1000b66c4:     	lsr	x6, x11, #12
1000b66c8:     	and	x6, x6, #0xf0
1000b66cc:     	orr	w7, w6, w7
1000b66d0:     	lsr	x20, x11, #16
1000b66d4:     	and	x20, x20, #0xf0
1000b66d8:     	orr	w17, w20, w17
1000b66dc:     	lsr	x21, x11, #20
1000b66e0:     	and	x21, x21, #0xf0
1000b66e4:     	ubfx	x13, x13, #24, #4
1000b66e8:     	orr	w13, w21, w13
1000b66ec:     	bfxil	x4, x12, #12, #4
1000b66f0:     	ldrsb	w4, [x9, x4]
1000b66f4:     	bfxil	x6, x12, #16, #4
1000b66f8:     	ldrsb	w6, [x9, x6]
1000b66fc:     	bfxil	x20, x12, #20, #4
1000b6700:     	ldrsb	w20, [x9, x20]
1000b6704:     	bfxil	x21, x12, #24, #4
1000b6708:     	ldrsb	w12, [x9, x21]
1000b670c:     	add	w2, w2, w4
1000b6710:     	add	w2, w2, w6
1000b6714:     	add	w2, w2, w20
1000b6718:     	add	w12, w2, w12
1000b671c:     	lsr	x11, x11, #24
1000b6720:     	and	x11, x11, #0xf0
1000b6724:     	orr	x10, x11, x10
1000b6728:     	ldrsb	w10, [x9, x10]
1000b672c:     	add	w10, w12, w10
1000b6730:     	scvtf	s4, w10
1000b6734:     	fadd	s1, s1, s4
1000b6738:     	ldrsb	w10, [x9, w15, uxtw]
1000b673c:     	ldrsb	w12, [x9, w5, uxtw]
1000b6740:     	ldrsb	w15, [x9, w19, uxtw]
1000b6744:     	add	w10, w10, w12
1000b6748:     	add	w10, w10, w15
1000b674c:     	ldrsb	w12, [x9, w16, uxtw]
1000b6750:     	ldrsb	w15, [x9, w7, uxtw]
1000b6754:     	add	w10, w10, w12
1000b6758:     	add	w10, w10, w15
1000b675c:     	ldrsb	w12, [x9, w17, uxtw]
1000b6760:     	ldrsb	w13, [x9, w13, uxtw]
1000b6764:     	add	w10, w10, w12
1000b6768:     	add	w10, w10, w13
1000b676c:     	orr	w11, w11, w14
1000b6770:     	ldrsb	w11, [x9, w11, uxtw]
1000b6774:     	add	w10, w10, w11
1000b6778:     	scvtf	s4, w10
1000b677c:     	fadd	s3, s3, s4
1000b6780:     	add	x0, x0, #8
1000b6784:     	add	x1, x1, #8
1000b6788:     	cmp	x1, x8
1000b678c:     	b.ne	0x1000b6530 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b6790:     	b	0x1000b67a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b6794:     	movi	d0, #0000000000000000
1000b6798:     	movi	d1, #0000000000000000
1000b679c:     	movi	d2, #0000000000000000
1000b67a0:     	movi	d3, #0000000000000000
1000b67a4:     	str	s0, [x3]
1000b67a8:     	str	s1, [x3, #4]
1000b67ac:     	str	s2, [x3, #8]
1000b67b0:     	str	s3, [x3, #12]
1000b67b4:     	ldp	x20, x19, [sp, #16]
1000b67b8:     	ldp	x22, x21, [sp], #32
1000b67bc:     	ret

