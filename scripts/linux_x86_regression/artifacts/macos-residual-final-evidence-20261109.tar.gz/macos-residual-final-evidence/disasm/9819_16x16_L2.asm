00000001000cb138 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cb138:     	stp	x28, x27, [sp, #-64]!
1000cb13c:     	stp	x22, x21, [sp, #16]
1000cb140:     	stp	x20, x19, [sp, #32]
1000cb144:     	stp	x29, x30, [sp, #48]
1000cb148:     	add	x29, sp, #48
1000cb14c:     	sub	sp, sp, #1040
1000cb150:     	mov	x19, x3
1000cb154:     	mov	x20, x1
1000cb158:     	mov	x21, x0
1000cb15c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf0>
1000cb160:     	ldr	x8, [x8, #392]
1000cb164:     	ldr	x8, [x8]
1000cb168:     	stur	x8, [x29, #-56]
1000cb16c:     	lsl	x8, x2, #3
1000cb170:     	and	x22, x8, #0xfffffffffffffff0
1000cb174:     	add	x0, sp, #8
1000cb178:     	mov	w1, #1024
1000cb17c:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000cb180:     	cbz	x22, 0x1000cb298 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000cb184:     	add	x8, x20, x22
1000cb188:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x114>
1000cb18c:     	add	x9, x9, #1244
1000cb190:     	mov	x10, #0
1000cb194:     	add	x11, sp, #8
1000cb198:     	mov	x12, #0
1000cb19c:     	ldr	w2, [x21, x10, lsl #2]
1000cb1a0:     	lsl	w13, w2, #4
1000cb1a4:     	and	x13, x13, #0xf0
1000cb1a8:     	and	x14, x2, #0xf0
1000cb1ac:     	lsr	x15, x2, #4
1000cb1b0:     	and	x15, x15, #0xf0
1000cb1b4:     	lsr	x16, x2, #8
1000cb1b8:     	and	x16, x16, #0xf0
1000cb1bc:     	lsr	x17, x2, #12
1000cb1c0:     	and	x17, x17, #0xf0
1000cb1c4:     	lsr	x0, x2, #16
1000cb1c8:     	and	x0, x0, #0xf0
1000cb1cc:     	lsr	x1, x2, #20
1000cb1d0:     	and	x1, x1, #0xf0
1000cb1d4:     	lsr	x2, x2, #24
1000cb1d8:     	and	x2, x2, #0xf0
1000cb1dc:     	mov	x3, x11
1000cb1e0:     	ldr	w4, [x20, x12]
1000cb1e4:     	and	x5, x4, #0xf
1000cb1e8:     	orr	x5, x13, x5
1000cb1ec:     	ldrb	w5, [x9, x5]
1000cb1f0:     	ubfx	x6, x4, #4, #4
1000cb1f4:     	orr	x6, x14, x6
1000cb1f8:     	ldrb	w6, [x9, x6]
1000cb1fc:     	ubfx	x7, x4, #8, #4
1000cb200:     	orr	x7, x15, x7
1000cb204:     	ldrb	w7, [x9, x7]
1000cb208:     	add	w5, w5, w6
1000cb20c:     	add	w5, w5, w7
1000cb210:     	ubfx	x6, x4, #12, #4
1000cb214:     	orr	x6, x16, x6
1000cb218:     	ldrb	w6, [x9, x6]
1000cb21c:     	ubfx	x7, x4, #16, #4
1000cb220:     	orr	x7, x17, x7
1000cb224:     	ldrb	w7, [x9, x7]
1000cb228:     	add	w5, w5, w6
1000cb22c:     	add	w5, w5, w7
1000cb230:     	ubfx	x6, x4, #20, #4
1000cb234:     	orr	x6, x0, x6
1000cb238:     	ldrb	w6, [x9, x6]
1000cb23c:     	ubfx	x7, x4, #24, #4
1000cb240:     	orr	x7, x1, x7
1000cb244:     	ldrb	w7, [x9, x7]
1000cb248:     	add	w5, w5, w6
1000cb24c:     	add	w5, w5, w7
1000cb250:     	orr	x4, x2, x4, lsr #28
1000cb254:     	ldrb	w4, [x9, x4]
1000cb258:     	add	w4, w5, w4
1000cb25c:     	scvtf	s0, w4
1000cb260:     	ldr	s1, [x3]
1000cb264:     	fadd	s0, s1, s0
1000cb268:     	str	s0, [x3], #64
1000cb26c:     	add	x12, x12, #4
1000cb270:     	cmp	x12, #64
1000cb274:     	b.ne	0x1000cb1e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000cb278:     	add	x10, x10, #1
1000cb27c:     	add	x11, x11, #4
1000cb280:     	cmp	x10, #16
1000cb284:     	b.ne	0x1000cb198 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000cb288:     	add	x21, x21, #64
1000cb28c:     	add	x20, x20, #64
1000cb290:     	cmp	x20, x8
1000cb294:     	b.ne	0x1000cb190 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000cb298:     	add	x1, sp, #8
1000cb29c:     	mov	x0, x19
1000cb2a0:     	mov	w2, #1024
1000cb2a4:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000cb2a8:     	ldur	x8, [x29, #-56]
1000cb2ac:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000cb2b0:     	ldr	x9, [x9, #392]
1000cb2b4:     	ldr	x9, [x9]
1000cb2b8:     	cmp	x9, x8
1000cb2bc:     	b.ne	0x1000cb2d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000cb2c0:     	add	sp, sp, #1040
1000cb2c4:     	ldp	x29, x30, [sp, #48]
1000cb2c8:     	ldp	x20, x19, [sp, #32]
1000cb2cc:     	ldp	x22, x21, [sp, #16]
1000cb2d0:     	ldp	x28, x27, [sp], #64
1000cb2d4:     	ret
1000cb2d8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

