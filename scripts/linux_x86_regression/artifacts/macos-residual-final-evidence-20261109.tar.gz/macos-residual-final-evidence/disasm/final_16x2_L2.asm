00000001000c8680 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c8680:     	sub	sp, sp, #272
1000c8684:     	stp	x28, x27, [sp, #176]
1000c8688:     	stp	x26, x25, [sp, #192]
1000c868c:     	stp	x24, x23, [sp, #208]
1000c8690:     	stp	x22, x21, [sp, #224]
1000c8694:     	stp	x20, x19, [sp, #240]
1000c8698:     	stp	x29, x30, [sp, #256]
1000c869c:     	add	x29, sp, #256
1000c86a0:     	str	x3, [sp]
1000c86a4:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x84>
1000c86a8:     	ldr	x8, [x8, #392]
1000c86ac:     	ldr	x8, [x8]
1000c86b0:     	stur	x8, [x29, #-96]
1000c86b4:     	movi.2d	v0, #0000000000000000
1000c86b8:     	stp	q0, q0, [sp, #128]
1000c86bc:     	stp	q0, q0, [sp, #96]
1000c86c0:     	stp	q0, q0, [sp, #64]
1000c86c4:     	stp	q0, q0, [sp, #32]
1000c86c8:     	ands	x8, x2, #0xfffffffffffffffe
1000c86cc:     	b.eq	0x1000c8850 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c86d0:     	add	x8, x1, x8
1000c86d4:     	str	x8, [sp, #8]
1000c86d8:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c86dc:     	add	x9, x9, #1212
1000c86e0:     	mov	x11, #0
1000c86e4:     	ldp	w4, w23, [x1]
1000c86e8:     	ubfx	x8, x4, #8, #4
1000c86ec:     	stp	x1, x8, [sp, #16]
1000c86f0:     	ubfx	x13, x4, #16, #4
1000c86f4:     	and	x14, x4, #0xf
1000c86f8:     	ubfx	x15, x4, #24, #4
1000c86fc:     	ubfx	x16, x4, #4, #4
1000c8700:     	ubfx	x17, x4, #12, #4
1000c8704:     	ubfx	x2, x4, #20, #4
1000c8708:     	lsr	x4, x4, #28
1000c870c:     	and	x5, x23, #0xf
1000c8710:     	ubfx	x6, x23, #8, #4
1000c8714:     	ubfx	x7, x23, #16, #4
1000c8718:     	ubfx	x19, x23, #24, #4
1000c871c:     	ubfx	x20, x23, #4, #4
1000c8720:     	ubfx	x21, x23, #12, #4
1000c8724:     	ubfx	x22, x23, #20, #4
1000c8728:     	lsr	x23, x23, #28
1000c872c:     	ldr	w24, [x0, x11]
1000c8730:     	lsl	w25, w24, #4
1000c8734:     	and	x25, x25, #0xf0
1000c8738:     	add	x25, x9, x25
1000c873c:     	and	x26, x24, #0xf0
1000c8740:     	add	x26, x9, x26
1000c8744:     	lsr	x27, x24, #4
1000c8748:     	and	x27, x27, #0xf0
1000c874c:     	add	x27, x9, x27
1000c8750:     	lsr	x28, x24, #8
1000c8754:     	and	x28, x28, #0xf0
1000c8758:     	add	x28, x9, x28
1000c875c:     	lsr	x30, x24, #12
1000c8760:     	and	x30, x30, #0xf0
1000c8764:     	add	x30, x9, x30
1000c8768:     	lsr	x8, x24, #16
1000c876c:     	and	x8, x8, #0xf0
1000c8770:     	add	x8, x9, x8
1000c8774:     	lsr	x3, x24, #20
1000c8778:     	and	x3, x3, #0xf0
1000c877c:     	add	x3, x9, x3
1000c8780:     	lsr	x24, x24, #24
1000c8784:     	and	x24, x24, #0xf0
1000c8788:     	ldrb	w10, [x25, x14]
1000c878c:     	ldr	x12, [sp, #24]
1000c8790:     	ldrb	w1, [x27, x12]
1000c8794:     	ldrb	w12, [x30, x13]
1000c8798:     	add	w10, w10, w1
1000c879c:     	add	w10, w10, w12
1000c87a0:     	ldrb	w12, [x3, x15]
1000c87a4:     	ldrb	w1, [x26, x16]
1000c87a8:     	add	w10, w10, w12
1000c87ac:     	add	w10, w10, w1
1000c87b0:     	ldrb	w12, [x28, x17]
1000c87b4:     	ldrb	w1, [x8, x2]
1000c87b8:     	add	x24, x9, x24
1000c87bc:     	add	w10, w10, w12
1000c87c0:     	add	w10, w10, w1
1000c87c4:     	ldrb	w12, [x24, x4]
1000c87c8:     	add	w10, w10, w12
1000c87cc:     	scvtf	s0, w10
1000c87d0:     	add	x10, sp, #32
1000c87d4:     	add	x10, x10, x11
1000c87d8:     	ldr	s1, [x10]
1000c87dc:     	ldrb	w12, [x25, x5]
1000c87e0:     	fadd	s0, s1, s0
1000c87e4:     	ldrb	w1, [x27, x6]
1000c87e8:     	ldrb	w25, [x30, x7]
1000c87ec:     	add	w12, w12, w1
1000c87f0:     	add	w12, w12, w25
1000c87f4:     	ldrb	w1, [x3, x19]
1000c87f8:     	ldrb	w3, [x26, x20]
1000c87fc:     	add	w12, w12, w1
1000c8800:     	add	w12, w12, w3
1000c8804:     	ldrb	w1, [x28, x21]
1000c8808:     	ldrb	w8, [x8, x22]
1000c880c:     	add	w12, w12, w1
1000c8810:     	add	w8, w12, w8
1000c8814:     	ldrb	w12, [x24, x23]
1000c8818:     	add	w8, w8, w12
1000c881c:     	scvtf	s1, w8
1000c8820:     	str	s0, [x10]
1000c8824:     	ldr	s0, [x10, #64]
1000c8828:     	fadd	s0, s0, s1
1000c882c:     	str	s0, [x10, #64]
1000c8830:     	add	x11, x11, #4
1000c8834:     	cmp	x11, #64
1000c8838:     	b.ne	0x1000c872c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c883c:     	add	x0, x0, #64
1000c8840:     	ldp	x8, x1, [sp, #8]
1000c8844:     	add	x1, x1, #8
1000c8848:     	cmp	x1, x8
1000c884c:     	b.ne	0x1000c86e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c8850:     	ldp	q0, q1, [sp, #96]
1000c8854:     	ldr	x8, [sp]
1000c8858:     	stp	q0, q1, [x8, #64]
1000c885c:     	ldp	q0, q1, [sp, #128]
1000c8860:     	stp	q0, q1, [x8, #96]
1000c8864:     	ldp	q0, q1, [sp, #32]
1000c8868:     	stp	q0, q1, [x8]
1000c886c:     	ldp	q0, q1, [sp, #64]
1000c8870:     	stp	q0, q1, [x8, #32]
1000c8874:     	ldur	x8, [x29, #-96]
1000c8878:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x19c>
1000c887c:     	ldr	x9, [x9, #392]
1000c8880:     	ldr	x9, [x9]
1000c8884:     	cmp	x9, x8
1000c8888:     	b.ne	0x1000c88ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c888c:     	ldp	x29, x30, [sp, #256]
1000c8890:     	ldp	x20, x19, [sp, #240]
1000c8894:     	ldp	x22, x21, [sp, #224]
1000c8898:     	ldp	x24, x23, [sp, #208]
1000c889c:     	ldp	x26, x25, [sp, #192]
1000c88a0:     	ldp	x28, x27, [sp, #176]
1000c88a4:     	add	sp, sp, #272
1000c88a8:     	ret
1000c88ac:     	bl	0x100163694 <_strcmp+0x100163694>

