00000001000bbbf8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bbbf8:     	sub	sp, sp, #176
1000bbbfc:     	stp	x28, x27, [sp, #80]
1000bbc00:     	stp	x26, x25, [sp, #96]
1000bbc04:     	stp	x24, x23, [sp, #112]
1000bbc08:     	stp	x22, x21, [sp, #128]
1000bbc0c:     	stp	x20, x19, [sp, #144]
1000bbc10:     	stp	x29, x30, [sp, #160]
1000bbc14:     	add	x29, sp, #160
1000bbc18:     	str	x3, [sp]
1000bbc1c:     	adrp	x8, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xbc>
1000bbc20:     	ldr	x8, [x8, #392]
1000bbc24:     	ldr	x8, [x8]
1000bbc28:     	str	x8, [sp, #72]
1000bbc2c:     	movi.2d	v0, #0000000000000000
1000bbc30:     	stp	q0, q0, [sp, #32]
1000bbc34:     	ands	x8, x2, #0xfffffffffffffffe
1000bbc38:     	b.eq	0x1000bbddc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bbc3c:     	add	x8, x1, x8
1000bbc40:     	str	x8, [sp, #8]
1000bbc44:     	adrp	x9, 0x10016a000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xdc>
1000bbc48:     	add	x9, x9, #444
1000bbc4c:     	mov	x11, #0
1000bbc50:     	ldp	w4, w23, [x1]
1000bbc54:     	ubfx	x8, x4, #4, #4
1000bbc58:     	stp	x1, x8, [sp, #16]
1000bbc5c:     	ubfx	x13, x4, #8, #4
1000bbc60:     	and	x14, x4, #0xf
1000bbc64:     	ubfx	x15, x4, #12, #4
1000bbc68:     	ubfx	x16, x4, #16, #4
1000bbc6c:     	ubfx	x17, x4, #20, #4
1000bbc70:     	ubfx	x2, x4, #24, #4
1000bbc74:     	lsr	x4, x4, #28
1000bbc78:     	and	x5, x23, #0xf
1000bbc7c:     	ubfx	x6, x23, #4, #4
1000bbc80:     	ubfx	x7, x23, #8, #4
1000bbc84:     	ubfx	x19, x23, #12, #4
1000bbc88:     	ubfx	x20, x23, #16, #4
1000bbc8c:     	ubfx	x21, x23, #20, #4
1000bbc90:     	ubfx	x22, x23, #24, #4
1000bbc94:     	lsr	x23, x23, #28
1000bbc98:     	ldr	w24, [x0, x11]
1000bbc9c:     	lsl	w25, w24, #4
1000bbca0:     	and	x25, x25, #0xf0
1000bbca4:     	orr	x26, x25, x14
1000bbca8:     	ldrsb	w26, [x9, x26]
1000bbcac:     	and	x27, x24, #0xf0
1000bbcb0:     	ldr	x8, [sp, #24]
1000bbcb4:     	orr	x28, x27, x8
1000bbcb8:     	ldrsb	w28, [x9, x28]
1000bbcbc:     	lsr	x30, x24, #4
1000bbcc0:     	and	x30, x30, #0xf0
1000bbcc4:     	orr	x8, x30, x13
1000bbcc8:     	ldrsb	w8, [x9, x8]
1000bbccc:     	add	w26, w26, w28
1000bbcd0:     	add	w8, w26, w8
1000bbcd4:     	lsr	x26, x24, #8
1000bbcd8:     	and	x26, x26, #0xf0
1000bbcdc:     	orr	x28, x26, x15
1000bbce0:     	ldrsb	w28, [x9, x28]
1000bbce4:     	lsr	x3, x24, #12
1000bbce8:     	and	x3, x3, #0xf0
1000bbcec:     	orr	x10, x3, x16
1000bbcf0:     	ldrsb	w10, [x9, x10]
1000bbcf4:     	add	w8, w8, w28
1000bbcf8:     	add	w8, w8, w10
1000bbcfc:     	lsr	x10, x24, #16
1000bbd00:     	and	x10, x10, #0xf0
1000bbd04:     	orr	x28, x10, x17
1000bbd08:     	ldrsb	w28, [x9, x28]
1000bbd0c:     	lsr	x1, x24, #20
1000bbd10:     	and	x1, x1, #0xf0
1000bbd14:     	orr	x12, x1, x2
1000bbd18:     	ldrsb	w12, [x9, x12]
1000bbd1c:     	add	w8, w8, w28
1000bbd20:     	add	x28, sp, #32
1000bbd24:     	add	w8, w8, w12
1000bbd28:     	lsr	x12, x24, #24
1000bbd2c:     	and	x12, x12, #0xf0
1000bbd30:     	orr	x24, x12, x4
1000bbd34:     	ldrsb	w24, [x9, x24]
1000bbd38:     	add	w8, w8, w24
1000bbd3c:     	scvtf	s0, w8
1000bbd40:     	add	x8, x28, x11
1000bbd44:     	ldr	s1, [x8]
1000bbd48:     	fadd	s0, s1, s0
1000bbd4c:     	orr	x24, x25, x5
1000bbd50:     	ldrsb	w24, [x9, x24]
1000bbd54:     	orr	x25, x27, x6
1000bbd58:     	ldrsb	w25, [x9, x25]
1000bbd5c:     	orr	x27, x30, x7
1000bbd60:     	ldrsb	w27, [x9, x27]
1000bbd64:     	add	w24, w24, w25
1000bbd68:     	add	w24, w24, w27
1000bbd6c:     	orr	x25, x26, x19
1000bbd70:     	ldrsb	w25, [x9, x25]
1000bbd74:     	orr	x3, x3, x20
1000bbd78:     	ldrsb	w3, [x9, x3]
1000bbd7c:     	orr	x10, x10, x21
1000bbd80:     	ldrsb	w10, [x9, x10]
1000bbd84:     	add	w24, w24, w25
1000bbd88:     	add	w3, w24, w3
1000bbd8c:     	orr	x1, x1, x22
1000bbd90:     	ldrsb	w1, [x9, x1]
1000bbd94:     	add	w10, w3, w10
1000bbd98:     	add	w10, w10, w1
1000bbd9c:     	orr	x12, x12, x23
1000bbda0:     	ldrsb	w12, [x9, x12]
1000bbda4:     	add	w10, w10, w12
1000bbda8:     	scvtf	s1, w10
1000bbdac:     	str	s0, [x8]
1000bbdb0:     	ldr	s0, [x8, #16]
1000bbdb4:     	fadd	s0, s0, s1
1000bbdb8:     	str	s0, [x8, #16]
1000bbdbc:     	add	x11, x11, #4
1000bbdc0:     	cmp	x11, #16
1000bbdc4:     	b.ne	0x1000bbc98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bbdc8:     	add	x0, x0, #16
1000bbdcc:     	ldp	x8, x1, [sp, #8]
1000bbdd0:     	add	x1, x1, #8
1000bbdd4:     	cmp	x1, x8
1000bbdd8:     	b.ne	0x1000bbc4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bbddc:     	ldp	q0, q1, [sp, #32]
1000bbde0:     	ldr	x8, [sp]
1000bbde4:     	stp	q0, q1, [x8]
1000bbde8:     	ldr	x8, [sp, #72]
1000bbdec:     	adrp	x9, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0x28c>
1000bbdf0:     	ldr	x9, [x9, #392]
1000bbdf4:     	ldr	x9, [x9]
1000bbdf8:     	cmp	x9, x8
1000bbdfc:     	b.ne	0x1000bbe20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bbe00:     	ldp	x29, x30, [sp, #160]
1000bbe04:     	ldp	x20, x19, [sp, #144]
1000bbe08:     	ldp	x22, x21, [sp, #128]
1000bbe0c:     	ldp	x24, x23, [sp, #112]
1000bbe10:     	ldp	x26, x25, [sp, #96]
1000bbe14:     	ldp	x28, x27, [sp, #80]
1000bbe18:     	add	sp, sp, #176
1000bbe1c:     	ret
1000bbe20:     	bl	0x100163694 <_strcmp+0x100163694>

