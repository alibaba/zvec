00000001000b7a94 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b7a94:     	stp	x20, x19, [sp, #-16]!
1000b7a98:     	stp	xzr, xzr, [x3]
1000b7a9c:     	lsl	x8, x4, #2
1000b7aa0:     	cmp	x2, #8
1000b7aa4:     	b.hs	0x1000b7ab8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000b7aa8:     	mov	x13, #0
1000b7aac:     	movi	d1, #0000000000000000
1000b7ab0:     	movi	d0, #0000000000000000
1000b7ab4:     	b	0x1000b7d98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x304>
1000b7ab8:     	mov	x10, #0
1000b7abc:     	add	x9, x0, #8
1000b7ac0:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2e8>
1000b7ac4:     	add	x11, x11, #220
1000b7ac8:     	mov	x12, x1
1000b7acc:     	ldr	w13, [x12]
1000b7ad0:     	ldur	w14, [x9, #-8]
1000b7ad4:     	lsl	w15, w14, #4
1000b7ad8:     	and	x15, x15, #0xf0
1000b7adc:     	bfxil	x15, x13, #0, #4
1000b7ae0:     	and	x16, x14, #0xf0
1000b7ae4:     	bfxil	x16, x13, #4, #4
1000b7ae8:     	ldrb	w16, [x11, x16]
1000b7aec:     	ldrb	w15, [x11, x15]
1000b7af0:     	lsr	x17, x14, #4
1000b7af4:     	and	x17, x17, #0xf0
1000b7af8:     	bfxil	x17, x13, #8, #4
1000b7afc:     	lsr	x4, x14, #8
1000b7b00:     	ldrb	w17, [x11, x17]
1000b7b04:     	and	x4, x4, #0xf0
1000b7b08:     	bfxil	x4, x13, #12, #4
1000b7b0c:     	lsr	x5, x14, #12
1000b7b10:     	and	x5, x5, #0xf0
1000b7b14:     	ldrb	w4, [x11, x4]
1000b7b18:     	bfxil	x5, x13, #16, #4
1000b7b1c:     	lsr	x6, x14, #16
1000b7b20:     	and	x6, x6, #0xf0
1000b7b24:     	bfxil	x6, x13, #20, #4
1000b7b28:     	ldrb	w5, [x11, x5]
1000b7b2c:     	ldrb	w6, [x11, x6]
1000b7b30:     	lsr	x7, x14, #20
1000b7b34:     	and	x7, x7, #0xf0
1000b7b38:     	add	w15, w15, w16
1000b7b3c:     	add	w15, w15, w17
1000b7b40:     	bfxil	x7, x13, #24, #4
1000b7b44:     	ldrb	w16, [x11, x7]
1000b7b48:     	lsr	x14, x14, #24
1000b7b4c:     	add	w15, w15, w4
1000b7b50:     	add	w15, w15, w5
1000b7b54:     	and	x17, x14, #0xf0
1000b7b58:     	lsr	x14, x13, #28
1000b7b5c:     	orr	x17, x17, x14
1000b7b60:     	ldrb	w17, [x11, x17]
1000b7b64:     	add	w15, w15, w6
1000b7b68:     	add	w15, w15, w16
1000b7b6c:     	add	w15, w15, w17
1000b7b70:     	scvtf	s0, w15
1000b7b74:     	ldp	s1, s2, [x3]
1000b7b78:     	fadd	s0, s1, s0
1000b7b7c:     	str	s0, [x3]
1000b7b80:     	ldur	w15, [x9, #-4]
1000b7b84:     	lsl	w16, w15, #4
1000b7b88:     	and	x16, x16, #0xf0
1000b7b8c:     	bfxil	x16, x13, #0, #4
1000b7b90:     	and	x17, x15, #0xf0
1000b7b94:     	bfxil	x17, x13, #4, #4
1000b7b98:     	ldrb	w17, [x11, x17]
1000b7b9c:     	ldrb	w16, [x11, x16]
1000b7ba0:     	lsr	x4, x15, #4
1000b7ba4:     	and	x4, x4, #0xf0
1000b7ba8:     	bfxil	x4, x13, #8, #4
1000b7bac:     	ldrb	w4, [x11, x4]
1000b7bb0:     	lsr	x5, x15, #8
1000b7bb4:     	and	x5, x5, #0xf0
1000b7bb8:     	bfxil	x5, x13, #12, #4
1000b7bbc:     	ldrb	w5, [x11, x5]
1000b7bc0:     	lsr	x6, x15, #12
1000b7bc4:     	and	x6, x6, #0xf0
1000b7bc8:     	bfxil	x6, x13, #16, #4
1000b7bcc:     	ldrb	w6, [x11, x6]
1000b7bd0:     	lsr	x7, x15, #16
1000b7bd4:     	and	x7, x7, #0xf0
1000b7bd8:     	bfxil	x7, x13, #20, #4
1000b7bdc:     	ldrb	w7, [x11, x7]
1000b7be0:     	add	w16, w16, w17
1000b7be4:     	add	w16, w16, w4
1000b7be8:     	lsr	x17, x15, #20
1000b7bec:     	and	x17, x17, #0xf0
1000b7bf0:     	bfxil	x17, x13, #24, #4
1000b7bf4:     	add	w16, w16, w5
1000b7bf8:     	add	w16, w16, w6
1000b7bfc:     	ldrb	w17, [x11, x17]
1000b7c00:     	lsr	x15, x15, #24
1000b7c04:     	and	x15, x15, #0xf0
1000b7c08:     	add	w16, w16, w7
1000b7c0c:     	add	w16, w16, w17
1000b7c10:     	orr	x15, x15, x14
1000b7c14:     	ldrb	w15, [x11, x15]
1000b7c18:     	add	w15, w16, w15
1000b7c1c:     	scvtf	s0, w15
1000b7c20:     	fadd	s0, s2, s0
1000b7c24:     	str	s0, [x3, #4]
1000b7c28:     	ldr	w15, [x9]
1000b7c2c:     	lsl	w16, w15, #4
1000b7c30:     	and	x16, x16, #0xf0
1000b7c34:     	bfxil	x16, x13, #0, #4
1000b7c38:     	and	x17, x15, #0xf0
1000b7c3c:     	bfxil	x17, x13, #4, #4
1000b7c40:     	ldrb	w17, [x11, x17]
1000b7c44:     	ldrb	w16, [x11, x16]
1000b7c48:     	lsr	x4, x15, #4
1000b7c4c:     	and	x4, x4, #0xf0
1000b7c50:     	bfxil	x4, x13, #8, #4
1000b7c54:     	ldrb	w4, [x11, x4]
1000b7c58:     	lsr	x5, x15, #8
1000b7c5c:     	and	x5, x5, #0xf0
1000b7c60:     	bfxil	x5, x13, #12, #4
1000b7c64:     	ldrb	w5, [x11, x5]
1000b7c68:     	lsr	x6, x15, #12
1000b7c6c:     	and	x6, x6, #0xf0
1000b7c70:     	bfxil	x6, x13, #16, #4
1000b7c74:     	lsr	x7, x15, #16
1000b7c78:     	ldrb	w6, [x11, x6]
1000b7c7c:     	and	x7, x7, #0xf0
1000b7c80:     	bfxil	x7, x13, #20, #4
1000b7c84:     	ldrb	w7, [x11, x7]
1000b7c88:     	add	w16, w16, w17
1000b7c8c:     	add	w16, w16, w4
1000b7c90:     	lsr	x17, x15, #20
1000b7c94:     	and	x17, x17, #0xf0
1000b7c98:     	bfxil	x17, x13, #24, #4
1000b7c9c:     	ldrb	w17, [x11, x17]
1000b7ca0:     	add	w16, w16, w5
1000b7ca4:     	add	w16, w16, w6
1000b7ca8:     	lsr	x15, x15, #24
1000b7cac:     	and	x15, x15, #0xf0
1000b7cb0:     	orr	x15, x15, x14
1000b7cb4:     	add	w16, w16, w7
1000b7cb8:     	add	w16, w16, w17
1000b7cbc:     	ldrb	w15, [x11, x15]
1000b7cc0:     	add	w15, w16, w15
1000b7cc4:     	scvtf	s0, w15
1000b7cc8:     	ldp	s1, s2, [x3, #8]
1000b7ccc:     	fadd	s0, s1, s0
1000b7cd0:     	str	s0, [x3, #8]
1000b7cd4:     	ldr	w15, [x9, #4]
1000b7cd8:     	lsl	w16, w15, #4
1000b7cdc:     	and	x16, x16, #0xf0
1000b7ce0:     	bfxil	x16, x13, #0, #4
1000b7ce4:     	and	x17, x15, #0xf0
1000b7ce8:     	bfxil	x17, x13, #4, #4
1000b7cec:     	lsr	x4, x15, #4
1000b7cf0:     	and	x4, x4, #0xf0
1000b7cf4:     	bfxil	x4, x13, #8, #4
1000b7cf8:     	lsr	x5, x15, #8
1000b7cfc:     	and	x5, x5, #0xf0
1000b7d00:     	bfxil	x5, x13, #12, #4
1000b7d04:     	lsr	x6, x15, #12
1000b7d08:     	and	x6, x6, #0xf0
1000b7d0c:     	bfxil	x6, x13, #16, #4
1000b7d10:     	lsr	x7, x15, #16
1000b7d14:     	and	x7, x7, #0xf0
1000b7d18:     	bfxil	x7, x13, #20, #4
1000b7d1c:     	lsr	x19, x15, #20
1000b7d20:     	and	x19, x19, #0xf0
1000b7d24:     	bfxil	x19, x13, #24, #4
1000b7d28:     	ldrb	w13, [x11, x16]
1000b7d2c:     	ldrb	w16, [x11, x17]
1000b7d30:     	ldrb	w17, [x11, x4]
1000b7d34:     	ldrb	w4, [x11, x5]
1000b7d38:     	ldrb	w5, [x11, x6]
1000b7d3c:     	add	w13, w13, w16
1000b7d40:     	add	w13, w13, w17
1000b7d44:     	ldrb	w16, [x11, x7]
1000b7d48:     	ldrb	w17, [x11, x19]
1000b7d4c:     	add	w13, w13, w4
1000b7d50:     	add	w13, w13, w5
1000b7d54:     	lsr	x15, x15, #24
1000b7d58:     	and	x15, x15, #0xf0
1000b7d5c:     	orr	x14, x15, x14
1000b7d60:     	ldrb	w14, [x11, x14]
1000b7d64:     	add	w13, w13, w16
1000b7d68:     	add	w13, w13, w17
1000b7d6c:     	add	w13, w13, w14
1000b7d70:     	scvtf	s1, w13
1000b7d74:     	fadd	s1, s2, s1
1000b7d78:     	str	s1, [x3, #12]
1000b7d7c:     	add	x13, x10, #8
1000b7d80:     	add	x12, x12, x8
1000b7d84:     	add	x9, x9, #16
1000b7d88:     	add	x14, x10, #16
1000b7d8c:     	mov	x10, x13
1000b7d90:     	cmp	x14, x2
1000b7d94:     	b.ls	0x1000b7acc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000b7d98:     	cmp	x13, x2
1000b7d9c:     	b.hs	0x1000b7e94 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x400>
1000b7da0:     	ldp	s2, s3, [x3]
1000b7da4:     	lsl	w9, w13, #2
1000b7da8:     	mov	w10, #-16
1000b7dac:     	lsr	x11, x13, #3
1000b7db0:     	mul	x12, x8, x11
1000b7db4:     	ubfx	x14, x13, #1, #2
1000b7db8:     	orr	x12, x12, x14
1000b7dbc:     	ldrb	w12, [x1, x12]
1000b7dc0:     	and	w15, w9, #0x4
1000b7dc4:     	lsr	w12, w12, w15
1000b7dc8:     	and	w16, w12, #0xf
1000b7dcc:     	cmp	w16, #8
1000b7dd0:     	csel	w16, wzr, w10, lo
1000b7dd4:     	bfxil	w16, w12, #0, #4
1000b7dd8:     	bfi	x14, x11, #4, #60
1000b7ddc:     	add	x11, x0, x14
1000b7de0:     	ldrb	w12, [x11]
1000b7de4:     	lsr	w12, w12, w15
1000b7de8:     	scvtf	s4, w16
1000b7dec:     	and	w14, w12, #0xf
1000b7df0:     	cmp	w14, #8
1000b7df4:     	csel	w14, wzr, w10, lo
1000b7df8:     	bfxil	w14, w12, #0, #4
1000b7dfc:     	scvtf	s5, w14
1000b7e00:     	fsub	s5, s5, s4
1000b7e04:     	fmadd	s2, s5, s5, s2
1000b7e08:     	str	s2, [x3]
1000b7e0c:     	ldrb	w12, [x11, #4]
1000b7e10:     	lsr	w12, w12, w15
1000b7e14:     	and	w14, w12, #0xf
1000b7e18:     	cmp	w14, #8
1000b7e1c:     	csel	w14, wzr, w10, lo
1000b7e20:     	bfxil	w14, w12, #0, #4
1000b7e24:     	scvtf	s5, w14
1000b7e28:     	fsub	s5, s5, s4
1000b7e2c:     	fmadd	s3, s5, s5, s3
1000b7e30:     	str	s3, [x3, #4]
1000b7e34:     	ldrb	w12, [x11, #8]
1000b7e38:     	lsr	w12, w12, w15
1000b7e3c:     	and	w14, w12, #0xf
1000b7e40:     	cmp	w14, #8
1000b7e44:     	csel	w14, wzr, w10, lo
1000b7e48:     	bfxil	w14, w12, #0, #4
1000b7e4c:     	scvtf	s5, w14
1000b7e50:     	fsub	s5, s5, s4
1000b7e54:     	fmadd	s0, s5, s5, s0
1000b7e58:     	str	s0, [x3, #8]
1000b7e5c:     	ldrb	w11, [x11, #12]
1000b7e60:     	lsr	w11, w11, w15
1000b7e64:     	and	w12, w11, #0xf
1000b7e68:     	cmp	w12, #8
1000b7e6c:     	csel	w12, wzr, w10, lo
1000b7e70:     	bfxil	w12, w11, #0, #4
1000b7e74:     	scvtf	s5, w12
1000b7e78:     	fsub	s4, s5, s4
1000b7e7c:     	fmadd	s1, s4, s4, s1
1000b7e80:     	str	s1, [x3, #12]
1000b7e84:     	add	x13, x13, #1
1000b7e88:     	add	w9, w9, #4
1000b7e8c:     	cmp	x2, x13
1000b7e90:     	b.ne	0x1000b7dac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x318>
1000b7e94:     	ldp	x20, x19, [sp], #16
1000b7e98:     	ret

