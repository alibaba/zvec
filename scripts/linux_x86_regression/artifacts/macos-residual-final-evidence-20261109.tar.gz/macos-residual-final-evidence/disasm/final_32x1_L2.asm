00000001000cfc14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000cfc14:     	stp	x22, x21, [sp, #-32]!
1000cfc18:     	stp	x20, x19, [sp, #16]
1000cfc1c:     	movi.2d	v0, #0000000000000000
1000cfc20:     	stp	q0, q0, [x3, #96]
1000cfc24:     	stp	q0, q0, [x3, #64]
1000cfc28:     	stp	q0, q0, [x3, #32]
1000cfc2c:     	stp	q0, q0, [x3]
1000cfc30:     	cmp	x2, #8
1000cfc34:     	b.hs	0x1000cfc40 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000cfc38:     	mov	x8, #0
1000cfc3c:     	b	0x1000cfd50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000cfc40:     	mov	x8, #0
1000cfc44:     	mov	w12, #8
1000cfc48:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x98>
1000cfc4c:     	add	x9, x9, #1724
1000cfc50:     	mov	x10, x0
1000cfc54:     	mov	x11, #0
1000cfc58:     	lsr	x8, x8, #1
1000cfc5c:     	mul	x8, x8, x4
1000cfc60:     	ldr	w6, [x1, x8]
1000cfc64:     	mov	x8, x12
1000cfc68:     	lsl	w12, w6, #4
1000cfc6c:     	and	x12, x12, #0xf0
1000cfc70:     	add	x12, x9, x12
1000cfc74:     	and	x13, x6, #0xf0
1000cfc78:     	add	x13, x9, x13
1000cfc7c:     	lsr	x14, x6, #4
1000cfc80:     	and	x14, x14, #0xf0
1000cfc84:     	add	x14, x9, x14
1000cfc88:     	lsr	x15, x6, #8
1000cfc8c:     	and	x15, x15, #0xf0
1000cfc90:     	add	x15, x9, x15
1000cfc94:     	lsr	x16, x6, #12
1000cfc98:     	and	x16, x16, #0xf0
1000cfc9c:     	add	x16, x9, x16
1000cfca0:     	lsr	x17, x6, #16
1000cfca4:     	and	x17, x17, #0xf0
1000cfca8:     	add	x17, x9, x17
1000cfcac:     	lsr	x5, x6, #20
1000cfcb0:     	and	x5, x5, #0xf0
1000cfcb4:     	add	x5, x9, x5
1000cfcb8:     	lsr	x6, x6, #24
1000cfcbc:     	and	x6, x6, #0xf0
1000cfcc0:     	add	x6, x9, x6
1000cfcc4:     	ldr	w7, [x10, x11]
1000cfcc8:     	and	x19, x7, #0xf
1000cfccc:     	ldrb	w19, [x12, x19]
1000cfcd0:     	ubfx	x20, x7, #4, #4
1000cfcd4:     	ldrb	w20, [x13, x20]
1000cfcd8:     	ubfx	x21, x7, #8, #4
1000cfcdc:     	ldrb	w21, [x14, x21]
1000cfce0:     	add	w19, w19, w20
1000cfce4:     	add	w19, w19, w21
1000cfce8:     	ubfx	x20, x7, #12, #4
1000cfcec:     	ldrb	w20, [x15, x20]
1000cfcf0:     	ubfx	x21, x7, #16, #4
1000cfcf4:     	ldrb	w21, [x16, x21]
1000cfcf8:     	add	w19, w19, w20
1000cfcfc:     	add	w19, w19, w21
1000cfd00:     	ubfx	x20, x7, #20, #4
1000cfd04:     	ldrb	w20, [x17, x20]
1000cfd08:     	ubfx	x21, x7, #24, #4
1000cfd0c:     	ldrb	w21, [x5, x21]
1000cfd10:     	lsr	x7, x7, #28
1000cfd14:     	ldrb	w7, [x6, x7]
1000cfd18:     	add	w19, w19, w20
1000cfd1c:     	add	w19, w19, w21
1000cfd20:     	add	w7, w19, w7
1000cfd24:     	scvtf	s0, w7
1000cfd28:     	ldr	s1, [x3, x11]
1000cfd2c:     	fadd	s0, s1, s0
1000cfd30:     	str	s0, [x3, x11]
1000cfd34:     	add	x11, x11, #4
1000cfd38:     	cmp	x11, #128
1000cfd3c:     	b.ne	0x1000cfcc4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000cfd40:     	add	x12, x8, #8
1000cfd44:     	add	x10, x10, #128
1000cfd48:     	cmp	x12, x2
1000cfd4c:     	b.ls	0x1000cfc54 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000cfd50:     	cmp	x8, x2
1000cfd54:     	b.hs	0x1000cfde4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1d0>
1000cfd58:     	lsl	x9, x4, #2
1000cfd5c:     	mov	w10, #-16
1000cfd60:     	mov	x11, #0
1000cfd64:     	lsr	x13, x8, #3
1000cfd68:     	lsl	x12, x13, #7
1000cfd6c:     	mul	x14, x9, x13
1000cfd70:     	ubfx	x13, x8, #1, #2
1000cfd74:     	orr	x14, x14, x13
1000cfd78:     	ldrb	w15, [x1, x14]
1000cfd7c:     	ubfiz	w14, w8, #2, #1
1000cfd80:     	lsr	w15, w15, w14
1000cfd84:     	and	w16, w15, #0xf
1000cfd88:     	cmp	w16, #8
1000cfd8c:     	csel	w16, wzr, w10, lo
1000cfd90:     	bfxil	w16, w15, #0, #4
1000cfd94:     	scvtf	s0, w16
1000cfd98:     	add	x15, x12, x11
1000cfd9c:     	orr	x15, x15, x13
1000cfda0:     	ldrb	w15, [x0, x15]
1000cfda4:     	lsr	w15, w15, w14
1000cfda8:     	and	w16, w15, #0xf
1000cfdac:     	cmp	w16, #8
1000cfdb0:     	csel	w16, wzr, w10, lo
1000cfdb4:     	bfxil	w16, w15, #0, #4
1000cfdb8:     	scvtf	s1, w16
1000cfdbc:     	ldr	s2, [x3, x11]
1000cfdc0:     	fsub	s1, s1, s0
1000cfdc4:     	fmadd	s1, s1, s1, s2
1000cfdc8:     	str	s1, [x3, x11]
1000cfdcc:     	add	x11, x11, #4
1000cfdd0:     	cmp	x11, #128
1000cfdd4:     	b.ne	0x1000cfd98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000cfdd8:     	add	x8, x8, #1
1000cfddc:     	cmp	x8, x2
1000cfde0:     	b.ne	0x1000cfd60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000cfde4:     	ldp	x20, x19, [sp, #16]
1000cfde8:     	ldp	x22, x21, [sp], #32
1000cfdec:     	ret

