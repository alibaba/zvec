00000001000c3014 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c3014:     	sub	sp, sp, #320
1000c3018:     	stp	x22, x21, [sp, #272]
1000c301c:     	stp	x20, x19, [sp, #288]
1000c3020:     	stp	x29, x30, [sp, #304]
1000c3024:     	add	x29, sp, #304
1000c3028:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0xd0>
1000c302c:     	ldr	x8, [x8, #392]
1000c3030:     	ldr	x8, [x8]
1000c3034:     	stur	x8, [x29, #-40]
1000c3038:     	movi.2d	v0, #0000000000000000
1000c303c:     	stp	q0, q0, [sp, #224]
1000c3040:     	lsl	x8, x2, #2
1000c3044:     	stp	q0, q0, [sp, #192]
1000c3048:     	stp	q0, q0, [sp, #160]
1000c304c:     	stp	q0, q0, [sp, #128]
1000c3050:     	stp	q0, q0, [sp, #96]
1000c3054:     	stp	q0, q0, [sp, #64]
1000c3058:     	stp	q0, q0, [sp, #32]
1000c305c:     	stp	q0, q0, [sp]
1000c3060:     	ands	x8, x8, #0xfffffffffffffff8
1000c3064:     	b.eq	0x1000c317c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x168>
1000c3068:     	add	x8, x1, x8
1000c306c:     	adrp	x9, 0x100166000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x10c>
1000c3070:     	add	x9, x9, #988
1000c3074:     	mov	x10, #0
1000c3078:     	mov	x11, sp
1000c307c:     	mov	x12, #0
1000c3080:     	ldr	w5, [x0, x10, lsl #2]
1000c3084:     	lsl	w13, w5, #4
1000c3088:     	and	x13, x13, #0xf0
1000c308c:     	and	x14, x5, #0xf0
1000c3090:     	lsr	x15, x5, #4
1000c3094:     	and	x15, x15, #0xf0
1000c3098:     	lsr	x16, x5, #8
1000c309c:     	and	x16, x16, #0xf0
1000c30a0:     	lsr	x17, x5, #12
1000c30a4:     	and	x17, x17, #0xf0
1000c30a8:     	lsr	x2, x5, #16
1000c30ac:     	and	x2, x2, #0xf0
1000c30b0:     	lsr	x4, x5, #20
1000c30b4:     	and	x4, x4, #0xf0
1000c30b8:     	lsr	x5, x5, #24
1000c30bc:     	and	x5, x5, #0xf0
1000c30c0:     	mov	x6, x11
1000c30c4:     	ldr	w7, [x1, x12]
1000c30c8:     	and	x19, x7, #0xf
1000c30cc:     	orr	x19, x13, x19
1000c30d0:     	ldrsb	w19, [x9, x19]
1000c30d4:     	ubfx	x20, x7, #4, #4
1000c30d8:     	orr	x20, x14, x20
1000c30dc:     	ldrsb	w20, [x9, x20]
1000c30e0:     	ubfx	x21, x7, #8, #4
1000c30e4:     	orr	x21, x15, x21
1000c30e8:     	ldrsb	w21, [x9, x21]
1000c30ec:     	add	w19, w19, w20
1000c30f0:     	add	w19, w19, w21
1000c30f4:     	ubfx	x20, x7, #12, #4
1000c30f8:     	orr	x20, x16, x20
1000c30fc:     	ldrsb	w20, [x9, x20]
1000c3100:     	ubfx	x21, x7, #16, #4
1000c3104:     	orr	x21, x17, x21
1000c3108:     	ldrsb	w21, [x9, x21]
1000c310c:     	add	w19, w19, w20
1000c3110:     	add	w19, w19, w21
1000c3114:     	ubfx	x20, x7, #20, #4
1000c3118:     	orr	x20, x2, x20
1000c311c:     	ldrsb	w20, [x9, x20]
1000c3120:     	ubfx	x21, x7, #24, #4
1000c3124:     	orr	x21, x4, x21
1000c3128:     	ldrsb	w21, [x9, x21]
1000c312c:     	add	w19, w19, w20
1000c3130:     	add	w19, w19, w21
1000c3134:     	orr	x7, x5, x7, lsr #28
1000c3138:     	ldrsb	w7, [x9, x7]
1000c313c:     	add	w7, w19, w7
1000c3140:     	scvtf	s0, w7
1000c3144:     	ldr	s1, [x6]
1000c3148:     	fadd	s0, s1, s0
1000c314c:     	str	s0, [x6], #32
1000c3150:     	add	x12, x12, #4
1000c3154:     	cmp	x12, #32
1000c3158:     	b.ne	0x1000c30c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c315c:     	add	x10, x10, #1
1000c3160:     	add	x11, x11, #4
1000c3164:     	cmp	x10, #8
1000c3168:     	b.ne	0x1000c307c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x68>
1000c316c:     	add	x0, x0, #32
1000c3170:     	add	x1, x1, #32
1000c3174:     	cmp	x1, x8
1000c3178:     	b.ne	0x1000c3074 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c317c:     	ldp	q0, q1, [sp, #192]
1000c3180:     	stp	q0, q1, [x3, #192]
1000c3184:     	ldp	q0, q1, [sp, #224]
1000c3188:     	stp	q0, q1, [x3, #224]
1000c318c:     	ldp	q0, q1, [sp, #128]
1000c3190:     	stp	q0, q1, [x3, #128]
1000c3194:     	ldp	q0, q1, [sp, #160]
1000c3198:     	stp	q0, q1, [x3, #160]
1000c319c:     	ldp	q0, q1, [sp, #64]
1000c31a0:     	stp	q0, q1, [x3, #64]
1000c31a4:     	ldp	q0, q1, [sp, #96]
1000c31a8:     	stp	q0, q1, [x3, #96]
1000c31ac:     	ldp	q0, q1, [sp]
1000c31b0:     	stp	q0, q1, [x3]
1000c31b4:     	ldp	q0, q1, [sp, #32]
1000c31b8:     	stp	q0, q1, [x3, #32]
1000c31bc:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x264>
1000c31c0:     	ldr	x8, [x8, #392]
1000c31c4:     	ldr	x8, [x8]
1000c31c8:     	ldur	x9, [x29, #-40]
1000c31cc:     	cmp	x8, x9
1000c31d0:     	b.ne	0x1000c31e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d4>
1000c31d4:     	ldp	x29, x30, [sp, #304]
1000c31d8:     	ldp	x20, x19, [sp, #288]
1000c31dc:     	ldp	x22, x21, [sp, #272]
1000c31e0:     	add	sp, sp, #320
1000c31e4:     	ret
1000c31e8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

