
bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100043e60 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
100043e60:     	sub	sp, sp, #80
100043e64:     	stp	x22, x21, [sp, #32]
100043e68:     	stp	x20, x19, [sp, #48]
100043e6c:     	stp	x29, x30, [sp, #64]
100043e70:     	add	x29, sp, #64
100043e74:     	mov	x19, x3
100043e78:     	mov	x20, x2
100043e7c:     	mov	x21, x1
100043e80:     	mov	x22, x0
100043e84:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2e4>
100043e88:     	ldr	x8, [x8, #16]
100043e8c:     	ldaprb	w8, [x8]
100043e90:     	tbz	w8, #0, 0x100043edc <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100043e94:     	stp	x21, x22, [sp, #16]
100043e98:     	stp	x19, x20, [sp]
100043e9c:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2fc>
100043ea0:     	ldr	x8, [x8, #192]
100043ea4:     	ldr	x0, [x8, #24]
100043ea8:     	cbz	x0, 0x100043f34 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100043eac:     	ldr	x8, [x0]
100043eb0:     	ldr	x8, [x8, #48]
100043eb4:     	add	x1, sp, #24
100043eb8:     	add	x2, sp, #16
100043ebc:     	add	x3, sp, #8
100043ec0:     	mov	x4, sp
100043ec4:     	blr	x8
100043ec8:     	ldp	x29, x30, [sp, #64]
100043ecc:     	ldp	x20, x19, [sp, #48]
100043ed0:     	ldp	x22, x21, [sp, #32]
100043ed4:     	add	sp, sp, #80
100043ed8:     	ret
100043edc:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x33c>
100043ee0:     	ldr	x0, [x0, #16]
100043ee4:     	bl	0x100163670 <_strcmp+0x100163670>
100043ee8:     	cbz	w0, 0x100043e94 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100043eec:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x34c>
100043ef0:     	ldr	x8, [x8, #192]
100043ef4:     	mov	w0, #0
100043ef8:     	mov	w1, #2
100043efc:     	mov	w2, #8
100043f00:     	mov	w3, #0
100043f04:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100043f08:     	adrp	x0, 0x100005000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa10>
100043f0c:     	add	x0, x0, #1080
100043f10:     	adrp	x1, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x370>
100043f14:     	ldr	x1, [x1, #192]
100043f18:     	adrp	x2, 0x100000000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa0c>
100043f1c:     	add	x2, x2, #0
100043f20:     	bl	0x100163640 <_strcmp+0x100163640>
100043f24:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x384>
100043f28:     	ldr	x0, [x0, #16]
100043f2c:     	bl	0x10016367c <_strcmp+0x10016367c>
100043f30:     	b	0x100043e94 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100043f34:     	bl	0x100005484 <std::__1::__throw_bad_function_call[abi:ue170006]()>
100043f38:     	mov	x19, x0
100043f3c:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x39c>
100043f40:     	ldr	x0, [x0, #16]
100043f44:     	bl	0x100163664 <_strcmp+0x100163664>
100043f48:     	mov	x0, x19
100043f4c:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

0000000100043f54 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
100043f54:     	sub	sp, sp, #80
100043f58:     	stp	x22, x21, [sp, #32]
100043f5c:     	stp	x20, x19, [sp, #48]
100043f60:     	stp	x29, x30, [sp, #64]
100043f64:     	add	x29, sp, #64
100043f68:     	mov	x19, x3
100043f6c:     	mov	x20, x2
100043f70:     	mov	x21, x1
100043f74:     	mov	x22, x0
100043f78:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3d8>
100043f7c:     	ldr	x8, [x8, #24]
100043f80:     	ldaprb	w8, [x8]
100043f84:     	tbz	w8, #0, 0x100043fd0 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100043f88:     	stp	x21, x22, [sp, #16]
100043f8c:     	stp	x19, x20, [sp]
100043f90:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3f0>
100043f94:     	ldr	x8, [x8, #200]
100043f98:     	ldr	x0, [x8, #24]
100043f9c:     	cbz	x0, 0x100044028 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100043fa0:     	ldr	x8, [x0]
100043fa4:     	ldr	x8, [x8, #48]
100043fa8:     	add	x1, sp, #24
100043fac:     	add	x2, sp, #16
100043fb0:     	add	x3, sp, #8
100043fb4:     	mov	x4, sp
100043fb8:     	blr	x8
100043fbc:     	ldp	x29, x30, [sp, #64]
100043fc0:     	ldp	x20, x19, [sp, #48]
100043fc4:     	ldp	x22, x21, [sp, #32]
100043fc8:     	add	sp, sp, #80
100043fcc:     	ret
100043fd0:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x430>
100043fd4:     	ldr	x0, [x0, #24]
100043fd8:     	bl	0x100163670 <_strcmp+0x100163670>
100043fdc:     	cbz	w0, 0x100043f88 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100043fe0:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x440>
100043fe4:     	ldr	x8, [x8, #200]
100043fe8:     	mov	w0, #2
100043fec:     	mov	w1, #2
100043ff0:     	mov	w2, #8
100043ff4:     	mov	w3, #0
100043ff8:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100043ffc:     	adrp	x0, 0x100005000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa4>
100044000:     	add	x0, x0, #1080
100044004:     	adrp	x1, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x460>
100044008:     	ldr	x1, [x1, #200]
10004400c:     	adrp	x2, 0x100000000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x9c>
100044010:     	add	x2, x2, #0
100044014:     	bl	0x100163640 <_strcmp+0x100163640>
100044018:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x474>
10004401c:     	ldr	x0, [x0, #24]
100044020:     	bl	0x10016367c <_strcmp+0x10016367c>
100044024:     	b	0x100043f88 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100044028:     	bl	0x100005484 <std::__1::__throw_bad_function_call[abi:ue170006]()>
10004402c:     	mov	x19, x0
100044030:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x48c>
100044034:     	ldr	x0, [x0, #24]
100044038:     	bl	0x100163664 <_strcmp+0x100163664>
10004403c:     	mov	x0, x19
100044040:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

000000010007f990 <void kernel<signed char, 1ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10007f990:     	b	0x10007f994 <zvec::turbo::DistanceMatrix<signed char, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(signed char const*, signed char const*, unsigned long, float*)>

000000010007fa84 <void kernel<signed char, 1ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10007fa84:     	b	0x10007fa88 <zvec::turbo::DistanceMatrix<signed char, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(signed char const*, signed char const*, unsigned long, float*)>

0000000100081078 <void kernel<signed char, 2ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100081078:     	cbz	x2, 0x10008108c <void kernel<signed char, 2ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
10008107c:     	mov	w4, #1
100081080:     	mov	x5, #0
100081084:     	mov	x6, #0
100081088:     	b	0x100081094 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008108c:     	str	xzr, [x3]
100081090:     	ret

00000001000811e4 <void kernel<signed char, 2ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000811e4:     	cbz	x2, 0x1000811f8 <void kernel<signed char, 2ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
1000811e8:     	mov	w4, #1
1000811ec:     	mov	x5, #0
1000811f0:     	mov	x6, #0
1000811f4:     	b	0x100081200 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000811f8:     	str	xzr, [x3]
1000811fc:     	ret

0000000100082ec4 <void kernel<signed char, 2ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100082ec4:     	stp	x22, x21, [sp, #-48]!
100082ec8:     	stp	x20, x19, [sp, #16]
100082ecc:     	stp	x29, x30, [sp, #32]
100082ed0:     	add	x29, sp, #32
100082ed4:     	mov	x19, x3
100082ed8:     	cbz	x2, 0x100082f28 <void kernel<signed char, 2ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100082edc:     	mov	x20, x2
100082ee0:     	mov	x22, x1
100082ee4:     	mov	x21, x0
100082ee8:     	mov	x3, x19
100082eec:     	mov	w4, #2
100082ef0:     	mov	x5, #0
100082ef4:     	mov	x6, #0
100082ef8:     	bl	0x100081094 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100082efc:     	add	x1, x22, #4
100082f00:     	add	x3, x19, #8
100082f04:     	mov	x0, x21
100082f08:     	mov	x2, x20
100082f0c:     	mov	w4, #2
100082f10:     	mov	x5, #0
100082f14:     	mov	x6, #0
100082f18:     	ldp	x29, x30, [sp, #32]
100082f1c:     	ldp	x20, x19, [sp, #16]
100082f20:     	ldp	x22, x21, [sp], #48
100082f24:     	b	0x100081094 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100082f28:     	stp	xzr, xzr, [x19]
100082f2c:     	ldp	x29, x30, [sp, #32]
100082f30:     	ldp	x20, x19, [sp, #16]
100082f34:     	ldp	x22, x21, [sp], #48
100082f38:     	ret

0000000100082f3c <void kernel<signed char, 2ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100082f3c:     	stp	x22, x21, [sp, #-48]!
100082f40:     	stp	x20, x19, [sp, #16]
100082f44:     	stp	x29, x30, [sp, #32]
100082f48:     	add	x29, sp, #32
100082f4c:     	mov	x19, x3
100082f50:     	cbz	x2, 0x100082fa0 <void kernel<signed char, 2ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100082f54:     	mov	x20, x2
100082f58:     	mov	x22, x1
100082f5c:     	mov	x21, x0
100082f60:     	mov	x3, x19
100082f64:     	mov	w4, #2
100082f68:     	mov	x5, #0
100082f6c:     	mov	x6, #0
100082f70:     	bl	0x100081200 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100082f74:     	add	x1, x22, #4
100082f78:     	add	x3, x19, #8
100082f7c:     	mov	x0, x21
100082f80:     	mov	x2, x20
100082f84:     	mov	w4, #2
100082f88:     	mov	x5, #0
100082f8c:     	mov	x6, #0
100082f90:     	ldp	x29, x30, [sp, #32]
100082f94:     	ldp	x20, x19, [sp, #16]
100082f98:     	ldp	x22, x21, [sp], #48
100082f9c:     	b	0x100081200 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100082fa0:     	stp	xzr, xzr, [x19]
100082fa4:     	ldp	x29, x30, [sp, #32]
100082fa8:     	ldp	x20, x19, [sp, #16]
100082fac:     	ldp	x22, x21, [sp], #48
100082fb0:     	ret

0000000100084958 <void kernel<signed char, 4ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100084958:     	cbz	x2, 0x10008496c <void kernel<signed char, 4ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
10008495c:     	mov	w4, #1
100084960:     	mov	x5, #0
100084964:     	mov	x6, #0
100084968:     	b	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008496c:     	stp	xzr, xzr, [x3]
100084970:     	ret

0000000100084b98 <void kernel<signed char, 4ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100084b98:     	cbz	x2, 0x100084bac <void kernel<signed char, 4ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100084b9c:     	mov	w4, #1
100084ba0:     	mov	x5, #0
100084ba4:     	mov	x6, #0
100084ba8:     	b	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100084bac:     	stp	xzr, xzr, [x3]
100084bb0:     	ret

0000000100087000 <void kernel<signed char, 4ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100087000:     	stp	x22, x21, [sp, #-48]!
100087004:     	stp	x20, x19, [sp, #16]
100087008:     	stp	x29, x30, [sp, #32]
10008700c:     	add	x29, sp, #32
100087010:     	mov	x19, x3
100087014:     	cbz	x2, 0x100087064 <void kernel<signed char, 4ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100087018:     	mov	x20, x2
10008701c:     	mov	x22, x1
100087020:     	mov	x21, x0
100087024:     	mov	x3, x19
100087028:     	mov	w4, #2
10008702c:     	mov	x5, #0
100087030:     	mov	x6, #0
100087034:     	bl	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087038:     	add	x1, x22, #4
10008703c:     	add	x3, x19, #16
100087040:     	mov	x0, x21
100087044:     	mov	x2, x20
100087048:     	mov	w4, #2
10008704c:     	mov	x5, #0
100087050:     	mov	x6, #0
100087054:     	ldp	x29, x30, [sp, #32]
100087058:     	ldp	x20, x19, [sp, #16]
10008705c:     	ldp	x22, x21, [sp], #48
100087060:     	b	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087064:     	movi.2d	v0, #0000000000000000
100087068:     	stp	q0, q0, [x19]
10008706c:     	ldp	x29, x30, [sp, #32]
100087070:     	ldp	x20, x19, [sp, #16]
100087074:     	ldp	x22, x21, [sp], #48
100087078:     	ret

000000010008707c <void kernel<signed char, 4ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10008707c:     	stp	x22, x21, [sp, #-48]!
100087080:     	stp	x20, x19, [sp, #16]
100087084:     	stp	x29, x30, [sp, #32]
100087088:     	add	x29, sp, #32
10008708c:     	mov	x19, x3
100087090:     	cbz	x2, 0x1000870e0 <void kernel<signed char, 4ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100087094:     	mov	x20, x2
100087098:     	mov	x22, x1
10008709c:     	mov	x21, x0
1000870a0:     	mov	x3, x19
1000870a4:     	mov	w4, #2
1000870a8:     	mov	x5, #0
1000870ac:     	mov	x6, #0
1000870b0:     	bl	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000870b4:     	add	x1, x22, #4
1000870b8:     	add	x3, x19, #16
1000870bc:     	mov	x0, x21
1000870c0:     	mov	x2, x20
1000870c4:     	mov	w4, #2
1000870c8:     	mov	x5, #0
1000870cc:     	mov	x6, #0
1000870d0:     	ldp	x29, x30, [sp, #32]
1000870d4:     	ldp	x20, x19, [sp, #16]
1000870d8:     	ldp	x22, x21, [sp], #48
1000870dc:     	b	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000870e0:     	movi.2d	v0, #0000000000000000
1000870e4:     	stp	q0, q0, [x19]
1000870e8:     	ldp	x29, x30, [sp, #32]
1000870ec:     	ldp	x20, x19, [sp, #16]
1000870f0:     	ldp	x22, x21, [sp], #48
1000870f4:     	ret

0000000100088d94 <void kernel<signed char, 4ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100088d94:     	stp	x22, x21, [sp, #-48]!
100088d98:     	stp	x20, x19, [sp, #16]
100088d9c:     	stp	x29, x30, [sp, #32]
100088da0:     	add	x29, sp, #32
100088da4:     	mov	x19, x3
100088da8:     	cbz	x2, 0x100088e38 <void kernel<signed char, 4ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
100088dac:     	mov	x20, x2
100088db0:     	mov	x22, x1
100088db4:     	mov	x21, x0
100088db8:     	mov	x3, x19
100088dbc:     	mov	w4, #4
100088dc0:     	mov	x5, #0
100088dc4:     	mov	x6, #0
100088dc8:     	bl	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088dcc:     	add	x1, x22, #4
100088dd0:     	add	x3, x19, #16
100088dd4:     	mov	x0, x21
100088dd8:     	mov	x2, x20
100088ddc:     	mov	w4, #4
100088de0:     	mov	x5, #0
100088de4:     	mov	x6, #0
100088de8:     	bl	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088dec:     	add	x1, x22, #8
100088df0:     	add	x3, x19, #32
100088df4:     	mov	x0, x21
100088df8:     	mov	x2, x20
100088dfc:     	mov	w4, #4
100088e00:     	mov	x5, #0
100088e04:     	mov	x6, #0
100088e08:     	bl	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088e0c:     	add	x1, x22, #12
100088e10:     	add	x3, x19, #48
100088e14:     	mov	x0, x21
100088e18:     	mov	x2, x20
100088e1c:     	mov	w4, #4
100088e20:     	mov	x5, #0
100088e24:     	mov	x6, #0
100088e28:     	ldp	x29, x30, [sp, #32]
100088e2c:     	ldp	x20, x19, [sp, #16]
100088e30:     	ldp	x22, x21, [sp], #48
100088e34:     	b	0x100084974 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088e38:     	movi.2d	v0, #0000000000000000
100088e3c:     	stp	q0, q0, [x19, #32]
100088e40:     	stp	q0, q0, [x19]
100088e44:     	ldp	x29, x30, [sp, #32]
100088e48:     	ldp	x20, x19, [sp, #16]
100088e4c:     	ldp	x22, x21, [sp], #48
100088e50:     	ret

0000000100088e54 <void kernel<signed char, 4ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100088e54:     	stp	x22, x21, [sp, #-48]!
100088e58:     	stp	x20, x19, [sp, #16]
100088e5c:     	stp	x29, x30, [sp, #32]
100088e60:     	add	x29, sp, #32
100088e64:     	mov	x19, x3
100088e68:     	cbz	x2, 0x100088ef8 <void kernel<signed char, 4ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
100088e6c:     	mov	x20, x2
100088e70:     	mov	x22, x1
100088e74:     	mov	x21, x0
100088e78:     	mov	x3, x19
100088e7c:     	mov	w4, #4
100088e80:     	mov	x5, #0
100088e84:     	mov	x6, #0
100088e88:     	bl	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088e8c:     	add	x1, x22, #4
100088e90:     	add	x3, x19, #16
100088e94:     	mov	x0, x21
100088e98:     	mov	x2, x20
100088e9c:     	mov	w4, #4
100088ea0:     	mov	x5, #0
100088ea4:     	mov	x6, #0
100088ea8:     	bl	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088eac:     	add	x1, x22, #8
100088eb0:     	add	x3, x19, #32
100088eb4:     	mov	x0, x21
100088eb8:     	mov	x2, x20
100088ebc:     	mov	w4, #4
100088ec0:     	mov	x5, #0
100088ec4:     	mov	x6, #0
100088ec8:     	bl	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088ecc:     	add	x1, x22, #12
100088ed0:     	add	x3, x19, #48
100088ed4:     	mov	x0, x21
100088ed8:     	mov	x2, x20
100088edc:     	mov	w4, #4
100088ee0:     	mov	x5, #0
100088ee4:     	mov	x6, #0
100088ee8:     	ldp	x29, x30, [sp, #32]
100088eec:     	ldp	x20, x19, [sp, #16]
100088ef0:     	ldp	x22, x21, [sp], #48
100088ef4:     	b	0x100084bb4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100088ef8:     	movi.2d	v0, #0000000000000000
100088efc:     	stp	q0, q0, [x19, #32]
100088f00:     	stp	q0, q0, [x19]
100088f04:     	ldp	x29, x30, [sp, #32]
100088f08:     	ldp	x20, x19, [sp, #16]
100088f0c:     	ldp	x22, x21, [sp], #48
100088f10:     	ret

000000010008b1fc <void kernel<signed char, 8ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10008b1fc:     	cbz	x2, 0x10008b210 <void kernel<signed char, 8ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
10008b200:     	mov	w4, #1
10008b204:     	mov	x5, #0
10008b208:     	mov	x6, #0
10008b20c:     	b	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008b210:     	movi.2d	v0, #0000000000000000
10008b214:     	stp	q0, q0, [x3]
10008b218:     	ret

000000010008b598 <void kernel<signed char, 8ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10008b598:     	cbz	x2, 0x10008b5ac <void kernel<signed char, 8ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
10008b59c:     	mov	w4, #1
10008b5a0:     	mov	x5, #0
10008b5a4:     	mov	x6, #0
10008b5a8:     	b	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008b5ac:     	movi.2d	v0, #0000000000000000
10008b5b0:     	stp	q0, q0, [x3]
10008b5b4:     	ret

000000010008dae0 <void kernel<signed char, 8ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10008dae0:     	stp	x22, x21, [sp, #-48]!
10008dae4:     	stp	x20, x19, [sp, #16]
10008dae8:     	stp	x29, x30, [sp, #32]
10008daec:     	add	x29, sp, #32
10008daf0:     	mov	x19, x3
10008daf4:     	cbz	x2, 0x10008db44 <void kernel<signed char, 8ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
10008daf8:     	mov	x20, x2
10008dafc:     	mov	x22, x1
10008db00:     	mov	x21, x0
10008db04:     	mov	x3, x19
10008db08:     	mov	w4, #2
10008db0c:     	mov	x5, #0
10008db10:     	mov	x6, #0
10008db14:     	bl	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008db18:     	add	x1, x22, #4
10008db1c:     	add	x3, x19, #32
10008db20:     	mov	x0, x21
10008db24:     	mov	x2, x20
10008db28:     	mov	w4, #2
10008db2c:     	mov	x5, #0
10008db30:     	mov	x6, #0
10008db34:     	ldp	x29, x30, [sp, #32]
10008db38:     	ldp	x20, x19, [sp, #16]
10008db3c:     	ldp	x22, x21, [sp], #48
10008db40:     	b	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008db44:     	movi.2d	v0, #0000000000000000
10008db48:     	stp	q0, q0, [x19, #32]
10008db4c:     	stp	q0, q0, [x19]
10008db50:     	ldp	x29, x30, [sp, #32]
10008db54:     	ldp	x20, x19, [sp, #16]
10008db58:     	ldp	x22, x21, [sp], #48
10008db5c:     	ret

000000010008db60 <void kernel<signed char, 8ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10008db60:     	stp	x22, x21, [sp, #-48]!
10008db64:     	stp	x20, x19, [sp, #16]
10008db68:     	stp	x29, x30, [sp, #32]
10008db6c:     	add	x29, sp, #32
10008db70:     	mov	x19, x3
10008db74:     	cbz	x2, 0x10008dbc4 <void kernel<signed char, 8ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
10008db78:     	mov	x20, x2
10008db7c:     	mov	x22, x1
10008db80:     	mov	x21, x0
10008db84:     	mov	x3, x19
10008db88:     	mov	w4, #2
10008db8c:     	mov	x5, #0
10008db90:     	mov	x6, #0
10008db94:     	bl	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008db98:     	add	x1, x22, #4
10008db9c:     	add	x3, x19, #32
10008dba0:     	mov	x0, x21
10008dba4:     	mov	x2, x20
10008dba8:     	mov	w4, #2
10008dbac:     	mov	x5, #0
10008dbb0:     	mov	x6, #0
10008dbb4:     	ldp	x29, x30, [sp, #32]
10008dbb8:     	ldp	x20, x19, [sp, #16]
10008dbbc:     	ldp	x22, x21, [sp], #48
10008dbc0:     	b	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008dbc4:     	movi.2d	v0, #0000000000000000
10008dbc8:     	stp	q0, q0, [x19, #32]
10008dbcc:     	stp	q0, q0, [x19]
10008dbd0:     	ldp	x29, x30, [sp, #32]
10008dbd4:     	ldp	x20, x19, [sp, #16]
10008dbd8:     	ldp	x22, x21, [sp], #48
10008dbdc:     	ret

00000001000903f4 <void kernel<signed char, 8ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000903f4:     	stp	x22, x21, [sp, #-48]!
1000903f8:     	stp	x20, x19, [sp, #16]
1000903fc:     	stp	x29, x30, [sp, #32]
100090400:     	add	x29, sp, #32
100090404:     	mov	x19, x3
100090408:     	cbz	x2, 0x100090498 <void kernel<signed char, 8ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
10009040c:     	mov	x20, x2
100090410:     	mov	x22, x1
100090414:     	mov	x21, x0
100090418:     	mov	x3, x19
10009041c:     	mov	w4, #4
100090420:     	mov	x5, #0
100090424:     	mov	x6, #0
100090428:     	bl	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009042c:     	add	x1, x22, #4
100090430:     	add	x3, x19, #32
100090434:     	mov	x0, x21
100090438:     	mov	x2, x20
10009043c:     	mov	w4, #4
100090440:     	mov	x5, #0
100090444:     	mov	x6, #0
100090448:     	bl	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009044c:     	add	x1, x22, #8
100090450:     	add	x3, x19, #64
100090454:     	mov	x0, x21
100090458:     	mov	x2, x20
10009045c:     	mov	w4, #4
100090460:     	mov	x5, #0
100090464:     	mov	x6, #0
100090468:     	bl	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009046c:     	add	x1, x22, #12
100090470:     	add	x3, x19, #96
100090474:     	mov	x0, x21
100090478:     	mov	x2, x20
10009047c:     	mov	w4, #4
100090480:     	mov	x5, #0
100090484:     	mov	x6, #0
100090488:     	ldp	x29, x30, [sp, #32]
10009048c:     	ldp	x20, x19, [sp, #16]
100090490:     	ldp	x22, x21, [sp], #48
100090494:     	b	0x10008b21c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100090498:     	movi.2d	v0, #0000000000000000
10009049c:     	stp	q0, q0, [x19, #96]
1000904a0:     	stp	q0, q0, [x19, #64]
1000904a4:     	stp	q0, q0, [x19, #32]
1000904a8:     	stp	q0, q0, [x19]
1000904ac:     	ldp	x29, x30, [sp, #32]
1000904b0:     	ldp	x20, x19, [sp, #16]
1000904b4:     	ldp	x22, x21, [sp], #48
1000904b8:     	ret

00000001000904bc <void kernel<signed char, 8ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000904bc:     	stp	x22, x21, [sp, #-48]!
1000904c0:     	stp	x20, x19, [sp, #16]
1000904c4:     	stp	x29, x30, [sp, #32]
1000904c8:     	add	x29, sp, #32
1000904cc:     	mov	x19, x3
1000904d0:     	cbz	x2, 0x100090560 <void kernel<signed char, 8ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
1000904d4:     	mov	x20, x2
1000904d8:     	mov	x22, x1
1000904dc:     	mov	x21, x0
1000904e0:     	mov	x3, x19
1000904e4:     	mov	w4, #4
1000904e8:     	mov	x5, #0
1000904ec:     	mov	x6, #0
1000904f0:     	bl	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000904f4:     	add	x1, x22, #4
1000904f8:     	add	x3, x19, #32
1000904fc:     	mov	x0, x21
100090500:     	mov	x2, x20
100090504:     	mov	w4, #4
100090508:     	mov	x5, #0
10009050c:     	mov	x6, #0
100090510:     	bl	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100090514:     	add	x1, x22, #8
100090518:     	add	x3, x19, #64
10009051c:     	mov	x0, x21
100090520:     	mov	x2, x20
100090524:     	mov	w4, #4
100090528:     	mov	x5, #0
10009052c:     	mov	x6, #0
100090530:     	bl	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100090534:     	add	x1, x22, #12
100090538:     	add	x3, x19, #96
10009053c:     	mov	x0, x21
100090540:     	mov	x2, x20
100090544:     	mov	w4, #4
100090548:     	mov	x5, #0
10009054c:     	mov	x6, #0
100090550:     	ldp	x29, x30, [sp, #32]
100090554:     	ldp	x20, x19, [sp, #16]
100090558:     	ldp	x22, x21, [sp], #48
10009055c:     	b	0x10008b5b8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100090560:     	movi.2d	v0, #0000000000000000
100090564:     	stp	q0, q0, [x19, #96]
100090568:     	stp	q0, q0, [x19, #64]
10009056c:     	stp	q0, q0, [x19, #32]
100090570:     	stp	q0, q0, [x19]
100090574:     	ldp	x29, x30, [sp, #32]
100090578:     	ldp	x20, x19, [sp, #16]
10009057c:     	ldp	x22, x21, [sp], #48
100090580:     	ret

0000000100092f28 <void kernel<signed char, 8ul, 8ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100092f28:     	b	0x100092f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

0000000100093084 <void kernel<signed char, 8ul, 8ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100093084:     	b	0x100093088 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000955b4 <void kernel<signed char, 16ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000955b4:     	cbz	x2, 0x1000955c8 <void kernel<signed char, 16ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
1000955b8:     	mov	w4, #1
1000955bc:     	mov	x5, #0
1000955c0:     	mov	x6, #0
1000955c4:     	b	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000955c8:     	movi.2d	v0, #0000000000000000
1000955cc:     	stp	q0, q0, [x3, #32]
1000955d0:     	stp	q0, q0, [x3]
1000955d4:     	ret

0000000100095c2c <void kernel<signed char, 16ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100095c2c:     	cbz	x2, 0x100095c40 <void kernel<signed char, 16ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100095c30:     	mov	w4, #1
100095c34:     	mov	x5, #0
100095c38:     	mov	x6, #0
100095c3c:     	b	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100095c40:     	movi.2d	v0, #0000000000000000
100095c44:     	stp	q0, q0, [x3, #32]
100095c48:     	stp	q0, q0, [x3]
100095c4c:     	ret

0000000100098cb0 <void kernel<signed char, 16ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100098cb0:     	stp	x22, x21, [sp, #-48]!
100098cb4:     	stp	x20, x19, [sp, #16]
100098cb8:     	stp	x29, x30, [sp, #32]
100098cbc:     	add	x29, sp, #32
100098cc0:     	mov	x19, x3
100098cc4:     	cbz	x2, 0x100098d14 <void kernel<signed char, 16ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100098cc8:     	mov	x20, x2
100098ccc:     	mov	x22, x1
100098cd0:     	mov	x21, x0
100098cd4:     	mov	x3, x19
100098cd8:     	mov	w4, #2
100098cdc:     	mov	x5, #0
100098ce0:     	mov	x6, #0
100098ce4:     	bl	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100098ce8:     	add	x1, x22, #4
100098cec:     	add	x3, x19, #64
100098cf0:     	mov	x0, x21
100098cf4:     	mov	x2, x20
100098cf8:     	mov	w4, #2
100098cfc:     	mov	x5, #0
100098d00:     	mov	x6, #0
100098d04:     	ldp	x29, x30, [sp, #32]
100098d08:     	ldp	x20, x19, [sp, #16]
100098d0c:     	ldp	x22, x21, [sp], #48
100098d10:     	b	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100098d14:     	movi.2d	v0, #0000000000000000
100098d18:     	stp	q0, q0, [x19, #96]
100098d1c:     	stp	q0, q0, [x19, #64]
100098d20:     	stp	q0, q0, [x19, #32]
100098d24:     	stp	q0, q0, [x19]
100098d28:     	ldp	x29, x30, [sp, #32]
100098d2c:     	ldp	x20, x19, [sp, #16]
100098d30:     	ldp	x22, x21, [sp], #48
100098d34:     	ret

0000000100098d38 <void kernel<signed char, 16ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100098d38:     	stp	x22, x21, [sp, #-48]!
100098d3c:     	stp	x20, x19, [sp, #16]
100098d40:     	stp	x29, x30, [sp, #32]
100098d44:     	add	x29, sp, #32
100098d48:     	mov	x19, x3
100098d4c:     	cbz	x2, 0x100098d9c <void kernel<signed char, 16ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100098d50:     	mov	x20, x2
100098d54:     	mov	x22, x1
100098d58:     	mov	x21, x0
100098d5c:     	mov	x3, x19
100098d60:     	mov	w4, #2
100098d64:     	mov	x5, #0
100098d68:     	mov	x6, #0
100098d6c:     	bl	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100098d70:     	add	x1, x22, #4
100098d74:     	add	x3, x19, #64
100098d78:     	mov	x0, x21
100098d7c:     	mov	x2, x20
100098d80:     	mov	w4, #2
100098d84:     	mov	x5, #0
100098d88:     	mov	x6, #0
100098d8c:     	ldp	x29, x30, [sp, #32]
100098d90:     	ldp	x20, x19, [sp, #16]
100098d94:     	ldp	x22, x21, [sp], #48
100098d98:     	b	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100098d9c:     	movi.2d	v0, #0000000000000000
100098da0:     	stp	q0, q0, [x19, #96]
100098da4:     	stp	q0, q0, [x19, #64]
100098da8:     	stp	q0, q0, [x19, #32]
100098dac:     	stp	q0, q0, [x19]
100098db0:     	ldp	x29, x30, [sp, #32]
100098db4:     	ldp	x20, x19, [sp, #16]
100098db8:     	ldp	x22, x21, [sp], #48
100098dbc:     	ret

000000010009bbd4 <void kernel<signed char, 16ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10009bbd4:     	stp	x22, x21, [sp, #-48]!
10009bbd8:     	stp	x20, x19, [sp, #16]
10009bbdc:     	stp	x29, x30, [sp, #32]
10009bbe0:     	add	x29, sp, #32
10009bbe4:     	mov	x19, x3
10009bbe8:     	cbz	x2, 0x10009bc78 <void kernel<signed char, 16ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
10009bbec:     	mov	x20, x2
10009bbf0:     	mov	x22, x1
10009bbf4:     	mov	x21, x0
10009bbf8:     	mov	x3, x19
10009bbfc:     	mov	w4, #4
10009bc00:     	mov	x5, #0
10009bc04:     	mov	x6, #0
10009bc08:     	bl	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bc0c:     	add	x1, x22, #4
10009bc10:     	add	x3, x19, #64
10009bc14:     	mov	x0, x21
10009bc18:     	mov	x2, x20
10009bc1c:     	mov	w4, #4
10009bc20:     	mov	x5, #0
10009bc24:     	mov	x6, #0
10009bc28:     	bl	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bc2c:     	add	x1, x22, #8
10009bc30:     	add	x3, x19, #128
10009bc34:     	mov	x0, x21
10009bc38:     	mov	x2, x20
10009bc3c:     	mov	w4, #4
10009bc40:     	mov	x5, #0
10009bc44:     	mov	x6, #0
10009bc48:     	bl	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bc4c:     	add	x1, x22, #12
10009bc50:     	add	x3, x19, #192
10009bc54:     	mov	x0, x21
10009bc58:     	mov	x2, x20
10009bc5c:     	mov	w4, #4
10009bc60:     	mov	x5, #0
10009bc64:     	mov	x6, #0
10009bc68:     	ldp	x29, x30, [sp, #32]
10009bc6c:     	ldp	x20, x19, [sp, #16]
10009bc70:     	ldp	x22, x21, [sp], #48
10009bc74:     	b	0x1000955d8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bc78:     	movi.2d	v0, #0000000000000000
10009bc7c:     	stp	q0, q0, [x19, #224]
10009bc80:     	stp	q0, q0, [x19, #192]
10009bc84:     	stp	q0, q0, [x19, #160]
10009bc88:     	stp	q0, q0, [x19, #128]
10009bc8c:     	stp	q0, q0, [x19, #96]
10009bc90:     	stp	q0, q0, [x19, #64]
10009bc94:     	stp	q0, q0, [x19, #32]
10009bc98:     	stp	q0, q0, [x19]
10009bc9c:     	ldp	x29, x30, [sp, #32]
10009bca0:     	ldp	x20, x19, [sp, #16]
10009bca4:     	ldp	x22, x21, [sp], #48
10009bca8:     	ret

000000010009bcac <void kernel<signed char, 16ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10009bcac:     	stp	x22, x21, [sp, #-48]!
10009bcb0:     	stp	x20, x19, [sp, #16]
10009bcb4:     	stp	x29, x30, [sp, #32]
10009bcb8:     	add	x29, sp, #32
10009bcbc:     	mov	x19, x3
10009bcc0:     	cbz	x2, 0x10009bd50 <void kernel<signed char, 16ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
10009bcc4:     	mov	x20, x2
10009bcc8:     	mov	x22, x1
10009bccc:     	mov	x21, x0
10009bcd0:     	mov	x3, x19
10009bcd4:     	mov	w4, #4
10009bcd8:     	mov	x5, #0
10009bcdc:     	mov	x6, #0
10009bce0:     	bl	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bce4:     	add	x1, x22, #4
10009bce8:     	add	x3, x19, #64
10009bcec:     	mov	x0, x21
10009bcf0:     	mov	x2, x20
10009bcf4:     	mov	w4, #4
10009bcf8:     	mov	x5, #0
10009bcfc:     	mov	x6, #0
10009bd00:     	bl	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bd04:     	add	x1, x22, #8
10009bd08:     	add	x3, x19, #128
10009bd0c:     	mov	x0, x21
10009bd10:     	mov	x2, x20
10009bd14:     	mov	w4, #4
10009bd18:     	mov	x5, #0
10009bd1c:     	mov	x6, #0
10009bd20:     	bl	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bd24:     	add	x1, x22, #12
10009bd28:     	add	x3, x19, #192
10009bd2c:     	mov	x0, x21
10009bd30:     	mov	x2, x20
10009bd34:     	mov	w4, #4
10009bd38:     	mov	x5, #0
10009bd3c:     	mov	x6, #0
10009bd40:     	ldp	x29, x30, [sp, #32]
10009bd44:     	ldp	x20, x19, [sp, #16]
10009bd48:     	ldp	x22, x21, [sp], #48
10009bd4c:     	b	0x100095c50 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009bd50:     	movi.2d	v0, #0000000000000000
10009bd54:     	stp	q0, q0, [x19, #224]
10009bd58:     	stp	q0, q0, [x19, #192]
10009bd5c:     	stp	q0, q0, [x19, #160]
10009bd60:     	stp	q0, q0, [x19, #128]
10009bd64:     	stp	q0, q0, [x19, #96]
10009bd68:     	stp	q0, q0, [x19, #64]
10009bd6c:     	stp	q0, q0, [x19, #32]
10009bd70:     	stp	q0, q0, [x19]
10009bd74:     	ldp	x29, x30, [sp, #32]
10009bd78:     	ldp	x20, x19, [sp, #16]
10009bd7c:     	ldp	x22, x21, [sp], #48
10009bd80:     	ret

000000010009f5c8 <void kernel<signed char, 16ul, 8ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10009f5c8:     	b	0x10009f5cc <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

000000010009f744 <void kernel<signed char, 16ul, 8ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10009f744:     	b	0x10009f748 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a3370 <void kernel<signed char, 16ul, 16ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a3370:     	b	0x1000a3374 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a35b0 <void kernel<signed char, 16ul, 16ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a35b0:     	b	0x1000a35b4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a47a4 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a47a4:     	movi.2d	v0, #0000000000000000
1000a47a8:     	stp	q0, q0, [x3, #96]
1000a47ac:     	stp	q0, q0, [x3, #64]
1000a47b0:     	stp	q0, q0, [x3, #32]
1000a47b4:     	stp	q0, q0, [x3]
1000a47b8:     	cbz	x2, 0x1000a4838 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x94>
1000a47bc:     	cmp	x2, #4
1000a47c0:     	b.hs	0x1000a483c <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x98>
1000a47c4:     	mov	x8, #0
1000a47c8:     	cmp	x8, x2
1000a47cc:     	b.hs	0x1000a4838 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x94>
1000a47d0:     	lsl	x9, x8, #3
1000a47d4:     	mov	x10, #0
1000a47d8:     	lsl	x11, x9, #2
1000a47dc:     	and	x11, x11, #0xffffffffffffff80
1000a47e0:     	and	x12, x8, #0x3
1000a47e4:     	ldr	b0, [x1, x8]
1000a47e8:     	sshll.8h	v0, v0, #0
1000a47ec:     	sshll.4s	v0, v0, #0
1000a47f0:     	scvtf	s0, s0
1000a47f4:     	add	x13, x11, x10
1000a47f8:     	orr	x13, x13, x12
1000a47fc:     	ldr	b1, [x0, x13]
1000a4800:     	sshll.8h	v1, v1, #0
1000a4804:     	sshll.4s	v1, v1, #0
1000a4808:     	scvtf	s1, s1
1000a480c:     	ldr	s2, [x3, x10]
1000a4810:     	fsub	s1, s1, s0
1000a4814:     	fmadd	s1, s1, s1, s2
1000a4818:     	str	s1, [x3, x10]
1000a481c:     	add	x10, x10, #4
1000a4820:     	cmp	x10, #128
1000a4824:     	b.ne	0x1000a47f4 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x50>
1000a4828:     	add	x8, x8, #1
1000a482c:     	add	x9, x9, #8
1000a4830:     	cmp	x8, x2
1000a4834:     	b.ne	0x1000a47d4 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x30>
1000a4838:     	ret
1000a483c:     	mov	x9, #0
1000a4840:     	mov	x8, #0
1000a4844:     	add	x10, x3, #128
1000a4848:     	mov	w12, #4
1000a484c:     	mov	x11, x0
1000a4850:     	b	0x1000a4aa4 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x300>
1000a4854:     	dup.4s	v0, v3[3]
1000a4858:     	dup.4s	v1, v3[2]
1000a485c:     	add	x12, x0, x13, lsl #5
1000a4860:     	dup.4s	v2, v3[1]
1000a4864:     	dup.4s	v3, v3[0]
1000a4868:     	ld4.16b	{ v4, v5, v6, v7 }, [x12], #64
1000a486c:     	sshll2.8h	v16, v4, #0
1000a4870:     	sshll2.4s	v17, v16, #0
1000a4874:     	sshll.4s	v16, v16, #0
1000a4878:     	sshll.8h	v18, v4, #0
1000a487c:     	sshll2.4s	v19, v18, #0
1000a4880:     	sshll.4s	v18, v18, #0
1000a4884:     	sub.4s	v18, v18, v3
1000a4888:     	sub.4s	v19, v19, v3
1000a488c:     	sub.4s	v16, v16, v3
1000a4890:     	sub.4s	v17, v17, v3
1000a4894:     	sshll2.8h	v20, v5, #0
1000a4898:     	sshll2.4s	v21, v20, #0
1000a489c:     	sshll.4s	v20, v20, #0
1000a48a0:     	sshll.8h	v22, v5, #0
1000a48a4:     	sshll2.4s	v23, v22, #0
1000a48a8:     	sshll.4s	v22, v22, #0
1000a48ac:     	sub.4s	v22, v22, v2
1000a48b0:     	sub.4s	v23, v23, v2
1000a48b4:     	sub.4s	v20, v20, v2
1000a48b8:     	sub.4s	v21, v21, v2
1000a48bc:     	sshll.8h	v24, v6, #0
1000a48c0:     	sshll.4s	v25, v24, #0
1000a48c4:     	sshll2.4s	v24, v24, #0
1000a48c8:     	sshll2.8h	v26, v6, #0
1000a48cc:     	sshll.4s	v27, v26, #0
1000a48d0:     	sshll2.4s	v26, v26, #0
1000a48d4:     	sub.4s	v26, v26, v1
1000a48d8:     	sub.4s	v27, v27, v1
1000a48dc:     	sub.4s	v24, v24, v1
1000a48e0:     	sub.4s	v25, v25, v1
1000a48e4:     	sshll2.8h	v28, v7, #0
1000a48e8:     	sshll2.4s	v29, v28, #0
1000a48ec:     	sshll.4s	v28, v28, #0
1000a48f0:     	sshll.8h	v4, v7, #0
1000a48f4:     	sshll2.4s	v5, v4, #0
1000a48f8:     	sshll.4s	v4, v4, #0
1000a48fc:     	sub.4s	v4, v4, v0
1000a4900:     	sub.4s	v5, v5, v0
1000a4904:     	sub.4s	v6, v28, v0
1000a4908:     	sub.4s	v7, v29, v0
1000a490c:     	mul.4s	v17, v17, v17
1000a4910:     	mul.4s	v16, v16, v16
1000a4914:     	mul.4s	v19, v19, v19
1000a4918:     	mul.4s	v18, v18, v18
1000a491c:     	mla.4s	v18, v22, v22
1000a4920:     	mla.4s	v19, v23, v23
1000a4924:     	mla.4s	v16, v20, v20
1000a4928:     	mla.4s	v17, v21, v21
1000a492c:     	mla.4s	v17, v26, v26
1000a4930:     	mla.4s	v16, v27, v27
1000a4934:     	mla.4s	v19, v24, v24
1000a4938:     	mla.4s	v18, v25, v25
1000a493c:     	mla.4s	v18, v4, v4
1000a4940:     	mla.4s	v19, v5, v5
1000a4944:     	mla.4s	v16, v6, v6
1000a4948:     	mla.4s	v17, v7, v7
1000a494c:     	scvtf.4s	v4, v17
1000a4950:     	scvtf.4s	v5, v16
1000a4954:     	scvtf.4s	v6, v19
1000a4958:     	scvtf.4s	v7, v18
1000a495c:     	ldp	q17, q16, [x3, #32]
1000a4960:     	ldp	q19, q18, [x3]
1000a4964:     	fadd.4s	v7, v19, v7
1000a4968:     	fadd.4s	v6, v18, v6
1000a496c:     	fadd.4s	v5, v17, v5
1000a4970:     	fadd.4s	v4, v16, v4
1000a4974:     	stp	q5, q4, [x3, #32]
1000a4978:     	stp	q7, q6, [x3]
1000a497c:     	ld4.16b	{ v4, v5, v6, v7 }, [x12]
1000a4980:     	sshll2.8h	v16, v4, #0
1000a4984:     	sshll2.4s	v17, v16, #0
1000a4988:     	sshll.4s	v16, v16, #0
1000a498c:     	sshll.8h	v18, v4, #0
1000a4990:     	sshll2.4s	v19, v18, #0
1000a4994:     	sshll.4s	v18, v18, #0
1000a4998:     	sub.4s	v18, v18, v3
1000a499c:     	sub.4s	v19, v19, v3
1000a49a0:     	sub.4s	v16, v16, v3
1000a49a4:     	sub.4s	v3, v17, v3
1000a49a8:     	sshll2.8h	v17, v5, #0
1000a49ac:     	sshll2.4s	v20, v17, #0
1000a49b0:     	sshll.4s	v17, v17, #0
1000a49b4:     	sshll.8h	v21, v5, #0
1000a49b8:     	sshll2.4s	v22, v21, #0
1000a49bc:     	sshll.4s	v21, v21, #0
1000a49c0:     	sub.4s	v21, v21, v2
1000a49c4:     	sub.4s	v22, v22, v2
1000a49c8:     	sub.4s	v17, v17, v2
1000a49cc:     	sub.4s	v2, v20, v2
1000a49d0:     	sshll.8h	v20, v6, #0
1000a49d4:     	sshll.4s	v23, v20, #0
1000a49d8:     	sshll2.4s	v20, v20, #0
1000a49dc:     	sshll2.8h	v24, v6, #0
1000a49e0:     	sshll.4s	v25, v24, #0
1000a49e4:     	sshll2.4s	v24, v24, #0
1000a49e8:     	sub.4s	v24, v24, v1
1000a49ec:     	sub.4s	v25, v25, v1
1000a49f0:     	sub.4s	v20, v20, v1
1000a49f4:     	sub.4s	v1, v23, v1
1000a49f8:     	sshll2.8h	v23, v7, #0
1000a49fc:     	sshll2.4s	v26, v23, #0
1000a4a00:     	sshll.4s	v23, v23, #0
1000a4a04:     	sshll.8h	v4, v7, #0
1000a4a08:     	sshll2.4s	v5, v4, #0
1000a4a0c:     	sshll.4s	v4, v4, #0
1000a4a10:     	sub.4s	v4, v4, v0
1000a4a14:     	sub.4s	v5, v5, v0
1000a4a18:     	sub.4s	v6, v23, v0
1000a4a1c:     	sub.4s	v0, v26, v0
1000a4a20:     	mul.4s	v3, v3, v3
1000a4a24:     	mul.4s	v7, v16, v16
1000a4a28:     	mul.4s	v16, v19, v19
1000a4a2c:     	mul.4s	v18, v18, v18
1000a4a30:     	mla.4s	v18, v21, v21
1000a4a34:     	mla.4s	v16, v22, v22
1000a4a38:     	mla.4s	v7, v17, v17
1000a4a3c:     	mla.4s	v3, v2, v2
1000a4a40:     	mla.4s	v3, v24, v24
1000a4a44:     	mla.4s	v7, v25, v25
1000a4a48:     	mla.4s	v16, v20, v20
1000a4a4c:     	mla.4s	v18, v1, v1
1000a4a50:     	mla.4s	v18, v4, v4
1000a4a54:     	mla.4s	v16, v5, v5
1000a4a58:     	mla.4s	v7, v6, v6
1000a4a5c:     	mla.4s	v3, v0, v0
1000a4a60:     	scvtf.4s	v0, v3
1000a4a64:     	scvtf.4s	v1, v7
1000a4a68:     	scvtf.4s	v2, v16
1000a4a6c:     	scvtf.4s	v3, v18
1000a4a70:     	ldp	q5, q4, [x3, #96]
1000a4a74:     	ldp	q7, q6, [x3, #64]
1000a4a78:     	fadd.4s	v3, v7, v3
1000a4a7c:     	fadd.4s	v1, v5, v1
1000a4a80:     	fadd.4s	v0, v4, v0
1000a4a84:     	stp	q1, q0, [x3, #96]
1000a4a88:     	fadd.4s	v0, v6, v2
1000a4a8c:     	stp	q3, q0, [x3, #64]
1000a4a90:     	add	x12, x8, #4
1000a4a94:     	add	x9, x9, #1
1000a4a98:     	add	x11, x11, #128
1000a4a9c:     	cmp	x12, x2
1000a4aa0:     	b.hi	0x1000a47c8 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x24>
1000a4aa4:     	mov	x13, x8
1000a4aa8:     	mov	x8, x12
1000a4aac:     	ldr	s0, [x1, x13]
1000a4ab0:     	sshll.8h	v0, v0, #0
1000a4ab4:     	sshll.4s	v3, v0, #0
1000a4ab8:     	add	x12, x0, x9, lsl #7
1000a4abc:     	add	x14, x12, #128
1000a4ac0:     	cmp	x14, x3
1000a4ac4:     	ccmp	x12, x10, #2, hi
1000a4ac8:     	b.hs	0x1000a4854 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xb0>
1000a4acc:     	mov	x12, #0
1000a4ad0:     	ldr	s0, [x11, x12]
1000a4ad4:     	sshll.8h	v0, v0, #0
1000a4ad8:     	sshll.4s	v0, v0, #0
1000a4adc:     	sub.4s	v0, v0, v3
1000a4ae0:     	mul.4s	v0, v0, v0
1000a4ae4:     	addv.4s	s0, v0
1000a4ae8:     	fmov	w13, s0
1000a4aec:     	scvtf	s0, w13
1000a4af0:     	ldr	s1, [x3, x12]
1000a4af4:     	fadd	s0, s1, s0
1000a4af8:     	str	s0, [x3, x12]
1000a4afc:     	add	x12, x12, #4
1000a4b00:     	cmp	x12, #128
1000a4b04:     	b.ne	0x1000a4ad0 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x32c>
1000a4b08:     	b	0x1000a4a90 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x2ec>

00000001000a4b0c <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a4b0c:     	movi.2d	v0, #0000000000000000
1000a4b10:     	stp	q0, q0, [x3, #96]
1000a4b14:     	stp	q0, q0, [x3, #64]
1000a4b18:     	stp	q0, q0, [x3, #32]
1000a4b1c:     	stp	q0, q0, [x3]
1000a4b20:     	cbz	x2, 0x1000a4b9c <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x90>
1000a4b24:     	cmp	x2, #4
1000a4b28:     	b.hs	0x1000a4ba0 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x94>
1000a4b2c:     	mov	x8, #0
1000a4b30:     	cmp	x8, x2
1000a4b34:     	b.hs	0x1000a4b9c <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x90>
1000a4b38:     	lsl	x9, x8, #3
1000a4b3c:     	mov	x10, #0
1000a4b40:     	lsl	x11, x9, #2
1000a4b44:     	and	x11, x11, #0xffffffffffffff80
1000a4b48:     	and	x12, x8, #0x3
1000a4b4c:     	ldr	b0, [x1, x8]
1000a4b50:     	sshll.8h	v0, v0, #0
1000a4b54:     	sshll.4s	v0, v0, #0
1000a4b58:     	scvtf	s0, s0
1000a4b5c:     	add	x13, x11, x10
1000a4b60:     	orr	x13, x13, x12
1000a4b64:     	ldr	b1, [x0, x13]
1000a4b68:     	sshll.8h	v1, v1, #0
1000a4b6c:     	sshll.4s	v1, v1, #0
1000a4b70:     	ldr	s2, [x3, x10]
1000a4b74:     	scvtf	s1, s1
1000a4b78:     	fmsub	s1, s1, s0, s2
1000a4b7c:     	str	s1, [x3, x10]
1000a4b80:     	add	x10, x10, #4
1000a4b84:     	cmp	x10, #128
1000a4b88:     	b.ne	0x1000a4b5c <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x50>
1000a4b8c:     	add	x8, x8, #1
1000a4b90:     	add	x9, x9, #8
1000a4b94:     	cmp	x8, x2
1000a4b98:     	b.ne	0x1000a4b3c <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x30>
1000a4b9c:     	ret
1000a4ba0:     	mov	x9, #0
1000a4ba4:     	mov	x8, #0
1000a4ba8:     	add	x10, x3, #128
1000a4bac:     	mov	w12, #4
1000a4bb0:     	mov	x11, x0
1000a4bb4:     	b	0x1000a4d78 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x26c>
1000a4bb8:     	add	x12, x0, x13, lsl #5
1000a4bbc:     	ld4.16b	{ v1, v2, v3, v4 }, [x12], #64
1000a4bc0:     	sshll.8h	v5, v1, #0
1000a4bc4:     	sshll.4s	v6, v5, #0
1000a4bc8:     	sshll2.4s	v5, v5, #0
1000a4bcc:     	sshll2.8h	v7, v1, #0
1000a4bd0:     	sshll.4s	v16, v7, #0
1000a4bd4:     	sshll2.4s	v7, v7, #0
1000a4bd8:     	mul.4s	v7, v7, v0[0]
1000a4bdc:     	mul.4s	v16, v16, v0[0]
1000a4be0:     	mul.4s	v5, v5, v0[0]
1000a4be4:     	mul.4s	v6, v6, v0[0]
1000a4be8:     	sshll.8h	v17, v2, #0
1000a4bec:     	sshll.4s	v18, v17, #0
1000a4bf0:     	sshll2.4s	v17, v17, #0
1000a4bf4:     	sshll2.8h	v19, v2, #0
1000a4bf8:     	sshll.4s	v20, v19, #0
1000a4bfc:     	sshll2.4s	v19, v19, #0
1000a4c00:     	mla.4s	v6, v18, v0[1]
1000a4c04:     	mla.4s	v5, v17, v0[1]
1000a4c08:     	mla.4s	v16, v20, v0[1]
1000a4c0c:     	mla.4s	v7, v19, v0[1]
1000a4c10:     	sshll2.8h	v17, v3, #0
1000a4c14:     	sshll2.4s	v18, v17, #0
1000a4c18:     	sshll.4s	v17, v17, #0
1000a4c1c:     	sshll.8h	v19, v3, #0
1000a4c20:     	sshll2.4s	v20, v19, #0
1000a4c24:     	sshll.4s	v19, v19, #0
1000a4c28:     	mla.4s	v7, v18, v0[2]
1000a4c2c:     	mla.4s	v16, v17, v0[2]
1000a4c30:     	mla.4s	v5, v20, v0[2]
1000a4c34:     	mla.4s	v6, v19, v0[2]
1000a4c38:     	sshll.8h	v17, v4, #0
1000a4c3c:     	sshll.4s	v18, v17, #0
1000a4c40:     	sshll2.4s	v17, v17, #0
1000a4c44:     	sshll2.8h	v1, v4, #0
1000a4c48:     	sshll.4s	v2, v1, #0
1000a4c4c:     	sshll2.4s	v1, v1, #0
1000a4c50:     	mla.4s	v6, v18, v0[3]
1000a4c54:     	mla.4s	v5, v17, v0[3]
1000a4c58:     	mla.4s	v16, v2, v0[3]
1000a4c5c:     	mla.4s	v7, v1, v0[3]
1000a4c60:     	scvtf.4s	v1, v7
1000a4c64:     	scvtf.4s	v2, v16
1000a4c68:     	scvtf.4s	v3, v5
1000a4c6c:     	scvtf.4s	v4, v6
1000a4c70:     	ldp	q6, q5, [x3, #32]
1000a4c74:     	ldp	q16, q7, [x3]
1000a4c78:     	fsub.4s	v4, v16, v4
1000a4c7c:     	fsub.4s	v3, v7, v3
1000a4c80:     	fsub.4s	v2, v6, v2
1000a4c84:     	fsub.4s	v1, v5, v1
1000a4c88:     	stp	q2, q1, [x3, #32]
1000a4c8c:     	stp	q4, q3, [x3]
1000a4c90:     	ld4.16b	{ v1, v2, v3, v4 }, [x12]
1000a4c94:     	sshll.8h	v5, v1, #0
1000a4c98:     	sshll.4s	v6, v5, #0
1000a4c9c:     	sshll2.4s	v5, v5, #0
1000a4ca0:     	sshll2.8h	v7, v1, #0
1000a4ca4:     	sshll.4s	v16, v7, #0
1000a4ca8:     	sshll2.4s	v7, v7, #0
1000a4cac:     	mul.4s	v7, v7, v0[0]
1000a4cb0:     	mul.4s	v16, v16, v0[0]
1000a4cb4:     	mul.4s	v5, v5, v0[0]
1000a4cb8:     	mul.4s	v6, v6, v0[0]
1000a4cbc:     	sshll.8h	v17, v2, #0
1000a4cc0:     	sshll.4s	v18, v17, #0
1000a4cc4:     	sshll2.4s	v17, v17, #0
1000a4cc8:     	sshll2.8h	v19, v2, #0
1000a4ccc:     	sshll.4s	v20, v19, #0
1000a4cd0:     	sshll2.4s	v19, v19, #0
1000a4cd4:     	mla.4s	v6, v18, v0[1]
1000a4cd8:     	mla.4s	v5, v17, v0[1]
1000a4cdc:     	mla.4s	v16, v20, v0[1]
1000a4ce0:     	mla.4s	v7, v19, v0[1]
1000a4ce4:     	sshll2.8h	v17, v3, #0
1000a4ce8:     	sshll2.4s	v18, v17, #0
1000a4cec:     	sshll.4s	v17, v17, #0
1000a4cf0:     	sshll.8h	v19, v3, #0
1000a4cf4:     	sshll2.4s	v20, v19, #0
1000a4cf8:     	sshll.4s	v19, v19, #0
1000a4cfc:     	mla.4s	v7, v18, v0[2]
1000a4d00:     	mla.4s	v16, v17, v0[2]
1000a4d04:     	mla.4s	v5, v20, v0[2]
1000a4d08:     	mla.4s	v6, v19, v0[2]
1000a4d0c:     	sshll.8h	v17, v4, #0
1000a4d10:     	sshll.4s	v18, v17, #0
1000a4d14:     	sshll2.4s	v17, v17, #0
1000a4d18:     	sshll2.8h	v1, v4, #0
1000a4d1c:     	sshll.4s	v2, v1, #0
1000a4d20:     	sshll2.4s	v1, v1, #0
1000a4d24:     	mla.4s	v6, v18, v0[3]
1000a4d28:     	mla.4s	v5, v17, v0[3]
1000a4d2c:     	mla.4s	v16, v2, v0[3]
1000a4d30:     	mla.4s	v7, v1, v0[3]
1000a4d34:     	scvtf.4s	v0, v7
1000a4d38:     	scvtf.4s	v1, v16
1000a4d3c:     	scvtf.4s	v2, v5
1000a4d40:     	scvtf.4s	v3, v6
1000a4d44:     	ldp	q5, q4, [x3, #96]
1000a4d48:     	ldp	q7, q6, [x3, #64]
1000a4d4c:     	fsub.4s	v3, v7, v3
1000a4d50:     	fsub.4s	v1, v5, v1
1000a4d54:     	fsub.4s	v0, v4, v0
1000a4d58:     	stp	q1, q0, [x3, #96]
1000a4d5c:     	fsub.4s	v0, v6, v2
1000a4d60:     	stp	q3, q0, [x3, #64]
1000a4d64:     	add	x12, x8, #4
1000a4d68:     	add	x9, x9, #1
1000a4d6c:     	add	x11, x11, #128
1000a4d70:     	cmp	x12, x2
1000a4d74:     	b.hi	0x1000a4b30 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x24>
1000a4d78:     	mov	x13, x8
1000a4d7c:     	mov	x8, x12
1000a4d80:     	ldr	s0, [x1, x13]
1000a4d84:     	ushll.8h	v0, v0, #0
1000a4d88:     	ushll.4s	v0, v0, #0
1000a4d8c:     	shl.4s	v0, v0, #24
1000a4d90:     	sshr.4s	v0, v0, #24
1000a4d94:     	add	x12, x0, x9, lsl #7
1000a4d98:     	add	x14, x12, #128
1000a4d9c:     	cmp	x14, x3
1000a4da0:     	ccmp	x12, x10, #2, hi
1000a4da4:     	b.hs	0x1000a4bb8 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xac>
1000a4da8:     	mov	x12, #0
1000a4dac:     	ldr	s1, [x11, x12]
1000a4db0:     	sshll.8h	v1, v1, #0
1000a4db4:     	sshll.4s	v1, v1, #0
1000a4db8:     	mul.4s	v1, v1, v0
1000a4dbc:     	addv.4s	s1, v1
1000a4dc0:     	fmov	w13, s1
1000a4dc4:     	scvtf	s1, w13
1000a4dc8:     	ldr	s2, [x3, x12]
1000a4dcc:     	fsub	s1, s2, s1
1000a4dd0:     	str	s1, [x3, x12]
1000a4dd4:     	add	x12, x12, #4
1000a4dd8:     	cmp	x12, #128
1000a4ddc:     	b.ne	0x1000a4dac <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x2a0>
1000a4de0:     	b	0x1000a4d64 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x258>

00000001000a6728 <void kernel<signed char, 32ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a6728:     	b	0x1000a672c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a6f78 <void kernel<signed char, 32ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a6f78:     	b	0x1000a6f7c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a952c <void kernel<signed char, 32ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a952c:     	b	0x1000a9530 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000aa550 <void kernel<signed char, 32ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000aa550:     	b	0x1000aa554 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000adad8 <void kernel<signed char, 32ul, 8ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000adad8:     	b	0x1000adadc <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000ae36c <void kernel<signed char, 32ul, 8ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000ae36c:     	b	0x1000ae370 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000b1678 <void kernel<signed char, 32ul, 16ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000b1678:     	b	0x1000b167c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000b1b2c <void kernel<signed char, 32ul, 16ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000b1b2c:     	b	0x1000b1b30 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000b369c <void kernel<signed char, 32ul, 32ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000b369c:     	b	0x1000b36a0 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000b3b50 <void kernel<signed char, 32ul, 32ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000b3b50:     	b	0x1000b3b54 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001001155ac <void kernel<short, 1ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
1001155ac:     	b	0x1001155b0 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(short const*, short const*, unsigned long, float*)>

00000001001156a0 <void kernel<short, 1ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001156a0:     	b	0x1001156a4 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(short const*, short const*, unsigned long, float*)>

0000000100116bb8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100116bb8:     	stp	d9, d8, [sp, #-16]!
100116bbc:     	cbz	x2, 0x100116bd8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x20>
100116bc0:     	cmp	x2, #32
100116bc4:     	b.hs	0x100116be4 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x2c>
100116bc8:     	mov	x8, #0
100116bcc:     	movi	d1, #0000000000000000
100116bd0:     	movi	d0, #0000000000000000
100116bd4:     	b	0x100116f38 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x380>
100116bd8:     	str	xzr, [x3]
100116bdc:     	ldp	d9, d8, [sp], #16
100116be0:     	ret
100116be4:     	and	x8, x2, #0xffffffffffffffe0
100116be8:     	add	x9, x1, #32
100116bec:     	add	x10, x0, #64
100116bf0:     	movi	d1, #0000000000000000
100116bf4:     	mov	x11, x8
100116bf8:     	movi	d0, #0000000000000000
100116bfc:     	ldp	q3, q2, [x9, #-32]
100116c00:     	sub	x12, x10, #64
100116c04:     	ld2.8h	{ v27, v28 }, [x12]
100116c08:     	ldp	q5, q4, [x9]
100116c0c:     	sub	x12, x10, #32
100116c10:     	ld2.8h	{ v23, v24 }, [x12]
100116c14:     	mov	x12, x10
100116c18:     	ld2.8h	{ v20, v21 }, [x12], #32
100116c1c:     	ld2.8h	{ v18, v19 }, [x12]
100116c20:     	sshll2.4s	v17, v27, #0
100116c24:     	sshll.4s	v26, v27, #0
100116c28:     	sshll2.4s	v16, v23, #0
100116c2c:     	sshll.4s	v25, v23, #0
100116c30:     	sshll2.4s	v7, v20, #0
100116c34:     	sshll.4s	v22, v20, #0
100116c38:     	sshll2.4s	v6, v18, #0
100116c3c:     	sshll2.4s	v29, v28, #0
100116c40:     	sshll.4s	v30, v18, #0
100116c44:     	sshll.4s	v27, v28, #0
100116c48:     	sshll2.4s	v28, v24, #0
100116c4c:     	sshll.4s	v23, v24, #0
100116c50:     	sshll2.4s	v24, v21, #0
100116c54:     	sshll.4s	v21, v21, #0
100116c58:     	sshll2.4s	v31, v19, #0
100116c5c:     	sshll.4s	v8, v19, #0
100116c60:     	sshll.4s	v18, v3, #0
100116c64:     	scvtf.4s	v18, v18
100116c68:     	scvtf.4s	v19, v26
100116c6c:     	scvtf.4s	v26, v27
100116c70:     	fsub.4s	v20, v19, v18
100116c74:     	fsub.4s	v26, v26, v18
100116c78:     	sshll2.4s	v3, v3, #0
100116c7c:     	scvtf.4s	v3, v3
100116c80:     	scvtf.4s	v17, v17
100116c84:     	scvtf.4s	v18, v29
100116c88:     	fsub.4s	v19, v17, v3
100116c8c:     	fsub.4s	v27, v18, v3
100116c90:     	sshll.4s	v3, v2, #0
100116c94:     	scvtf.4s	v3, v3
100116c98:     	scvtf.4s	v17, v25
100116c9c:     	scvtf.4s	v23, v23
100116ca0:     	fsub.4s	v18, v17, v3
100116ca4:     	fsub.4s	v23, v23, v3
100116ca8:     	sshll2.4s	v2, v2, #0
100116cac:     	scvtf.4s	v2, v2
100116cb0:     	scvtf.4s	v3, v16
100116cb4:     	scvtf.4s	v16, v28
100116cb8:     	fsub.4s	v17, v3, v2
100116cbc:     	fsub.4s	v25, v16, v2
100116cc0:     	sshll.4s	v2, v5, #0
100116cc4:     	scvtf.4s	v2, v2
100116cc8:     	scvtf.4s	v3, v22
100116ccc:     	scvtf.4s	v21, v21
100116cd0:     	fsub.4s	v16, v3, v2
100116cd4:     	fsub.4s	v21, v21, v2
100116cd8:     	sshll2.4s	v2, v5, #0
100116cdc:     	scvtf.4s	v2, v2
100116ce0:     	scvtf.4s	v3, v7
100116ce4:     	scvtf.4s	v7, v24
100116ce8:     	fsub.4s	v5, v3, v2
100116cec:     	fsub.4s	v7, v7, v2
100116cf0:     	sshll.4s	v2, v4, #0
100116cf4:     	scvtf.4s	v2, v2
100116cf8:     	scvtf.4s	v3, v30
100116cfc:     	scvtf.4s	v22, v8
100116d00:     	fsub.4s	v3, v3, v2
100116d04:     	fsub.4s	v22, v22, v2
100116d08:     	sshll2.4s	v2, v4, #0
100116d0c:     	scvtf.4s	v4, v2
100116d10:     	scvtf.4s	v2, v6
100116d14:     	scvtf.4s	v6, v31
100116d18:     	fsub.4s	v2, v2, v4
100116d1c:     	fsub.4s	v4, v6, v4
100116d20:     	fmul.4s	v6, v26, v26
100116d24:     	mov	s24, v6[1]
100116d28:     	fadd	s1, s1, s6
100116d2c:     	fadd	s1, s1, s24
100116d30:     	mov	s24, v6[2]
100116d34:     	fadd	s1, s1, s24
100116d38:     	fmul.4s	v24, v27, v27
100116d3c:     	mov	s6, v6[3]
100116d40:     	fadd	s1, s1, s6
100116d44:     	mov	s6, v24[1]
100116d48:     	fadd	s1, s1, s24
100116d4c:     	fadd	s1, s1, s6
100116d50:     	mov	s6, v24[2]
100116d54:     	fadd	s1, s1, s6
100116d58:     	mov	s6, v24[3]
100116d5c:     	fmul.4s	v23, v23, v23
100116d60:     	fadd	s1, s1, s6
100116d64:     	mov	s6, v23[1]
100116d68:     	fadd	s1, s1, s23
100116d6c:     	fadd	s1, s1, s6
100116d70:     	mov	s6, v23[2]
100116d74:     	fadd	s1, s1, s6
100116d78:     	fmul.4s	v6, v25, v25
100116d7c:     	mov	s23, v23[3]
100116d80:     	fadd	s1, s1, s23
100116d84:     	mov	s23, v6[1]
100116d88:     	fadd	s1, s1, s6
100116d8c:     	fadd	s1, s1, s23
100116d90:     	mov	s23, v6[2]
100116d94:     	fadd	s1, s1, s23
100116d98:     	mov	s6, v6[3]
100116d9c:     	fmul.4s	v21, v21, v21
100116da0:     	fadd	s1, s1, s6
100116da4:     	mov	s6, v21[1]
100116da8:     	fadd	s1, s1, s21
100116dac:     	fadd	s1, s1, s6
100116db0:     	mov	s6, v21[2]
100116db4:     	fadd	s1, s1, s6
100116db8:     	fmul.4s	v6, v7, v7
100116dbc:     	mov	s7, v21[3]
100116dc0:     	fadd	s1, s1, s7
100116dc4:     	mov	s7, v6[1]
100116dc8:     	fadd	s1, s1, s6
100116dcc:     	fadd	s1, s1, s7
100116dd0:     	mov	s7, v6[2]
100116dd4:     	fadd	s1, s1, s7
100116dd8:     	fmul.4s	v7, v20, v20
100116ddc:     	mov	s6, v6[3]
100116de0:     	fmul.4s	v20, v22, v22
100116de4:     	fadd	s1, s1, s6
100116de8:     	mov	s6, v20[1]
100116dec:     	fadd	s1, s1, s20
100116df0:     	fadd	s1, s1, s6
100116df4:     	mov	s6, v20[2]
100116df8:     	fadd	s1, s1, s6
100116dfc:     	mov	s6, v7[1]
100116e00:     	fadd	s0, s0, s7
100116e04:     	fadd	s0, s0, s6
100116e08:     	mov	s6, v7[2]
100116e0c:     	fadd	s0, s0, s6
100116e10:     	mov	s6, v7[3]
100116e14:     	fadd	s0, s0, s6
100116e18:     	fmul.4s	v6, v19, v19
100116e1c:     	mov	s7, v20[3]
100116e20:     	fadd	s1, s1, s7
100116e24:     	mov	s7, v6[1]
100116e28:     	fadd	s0, s0, s6
100116e2c:     	fadd	s0, s0, s7
100116e30:     	mov	s7, v6[2]
100116e34:     	fadd	s0, s0, s7
100116e38:     	mov	s6, v6[3]
100116e3c:     	fmul.4s	v7, v18, v18
100116e40:     	fmul.4s	v4, v4, v4
100116e44:     	fadd	s0, s0, s6
100116e48:     	mov	s6, v4[1]
100116e4c:     	fadd	s1, s1, s4
100116e50:     	fadd	s1, s1, s6
100116e54:     	mov	s6, v7[1]
100116e58:     	fadd	s0, s0, s7
100116e5c:     	fadd	s0, s0, s6
100116e60:     	mov	s6, v7[2]
100116e64:     	fadd	s0, s0, s6
100116e68:     	fmul.4s	v6, v17, v17
100116e6c:     	mov	s7, v7[3]
100116e70:     	fadd	s0, s0, s7
100116e74:     	mov	s7, v6[1]
100116e78:     	fadd	s0, s0, s6
100116e7c:     	fadd	s0, s0, s7
100116e80:     	mov	s7, v6[2]
100116e84:     	fadd	s0, s0, s7
100116e88:     	mov	s6, v6[3]
100116e8c:     	fmul.4s	v7, v16, v16
100116e90:     	fadd	s0, s0, s6
100116e94:     	mov	s6, v4[2]
100116e98:     	fadd	s1, s1, s6
100116e9c:     	mov	s6, v7[1]
100116ea0:     	fadd	s0, s0, s7
100116ea4:     	fadd	s0, s0, s6
100116ea8:     	mov	s6, v7[2]
100116eac:     	fadd	s0, s0, s6
100116eb0:     	fmul.4s	v5, v5, v5
100116eb4:     	mov	s6, v7[3]
100116eb8:     	fadd	s0, s0, s6
100116ebc:     	mov	s6, v5[1]
100116ec0:     	fadd	s0, s0, s5
100116ec4:     	fadd	s0, s0, s6
100116ec8:     	mov	s6, v5[2]
100116ecc:     	fadd	s0, s0, s6
100116ed0:     	mov	s5, v5[3]
100116ed4:     	fadd	s0, s0, s5
100116ed8:     	fmul.4s	v3, v3, v3
100116edc:     	mov	s4, v4[3]
100116ee0:     	fadd	s1, s1, s4
100116ee4:     	mov	s4, v3[1]
100116ee8:     	fadd	s0, s0, s3
100116eec:     	fadd	s0, s0, s4
100116ef0:     	mov	s4, v3[2]
100116ef4:     	fadd	s0, s0, s4
100116ef8:     	fmul.4s	v2, v2, v2
100116efc:     	mov	s3, v3[3]
100116f00:     	fadd	s0, s0, s3
100116f04:     	mov	s3, v2[1]
100116f08:     	fadd	s0, s0, s2
100116f0c:     	fadd	s0, s0, s3
100116f10:     	mov	s3, v2[2]
100116f14:     	fadd	s0, s0, s3
100116f18:     	mov	s2, v2[3]
100116f1c:     	fadd	s0, s0, s2
100116f20:     	add	x9, x9, #64
100116f24:     	add	x10, x10, #128
100116f28:     	subs	x11, x11, #32
100116f2c:     	b.ne	0x100116bfc <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x44>
100116f30:     	cmp	x8, x2
100116f34:     	b.eq	0x100116f84 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
100116f38:     	sub	x9, x2, x8
100116f3c:     	add	x10, x0, x8, lsl #2
100116f40:     	add	x10, x10, #2
100116f44:     	add	x8, x1, x8, lsl #1
100116f48:     	ldrsh	w11, [x8], #2
100116f4c:     	scvtf	s2, w11
100116f50:     	ldur	h3, [x10, #-2]
100116f54:     	sshll.4s	v3, v3, #0
100116f58:     	scvtf	s3, s3
100116f5c:     	fsub	s3, s3, s2
100116f60:     	fmadd	s0, s3, s3, s0
100116f64:     	ldr	h3, [x10]
100116f68:     	sshll.4s	v3, v3, #0
100116f6c:     	scvtf	s3, s3
100116f70:     	fsub	s2, s3, s2
100116f74:     	fmadd	s1, s2, s2, s1
100116f78:     	add	x10, x10, #4
100116f7c:     	subs	x9, x9, #1
100116f80:     	b.ne	0x100116f48 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
100116f84:     	stp	s0, s1, [x3]
100116f88:     	ldp	d9, d8, [sp], #16
100116f8c:     	ret

0000000100116f90 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100116f90:     	cbz	x2, 0x100116fac <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x1c>
100116f94:     	cmp	x2, #32
100116f98:     	b.hs	0x100116fb4 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x24>
100116f9c:     	mov	x8, #0
100116fa0:     	movi	d1, #0000000000000000
100116fa4:     	movi	d0, #0000000000000000
100116fa8:     	b	0x100117308 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x378>
100116fac:     	str	xzr, [x3]
100116fb0:     	ret
100116fb4:     	and	x8, x2, #0xffffffffffffffe0
100116fb8:     	add	x9, x1, #32
100116fbc:     	add	x10, x0, #64
100116fc0:     	movi	d1, #0000000000000000
100116fc4:     	mov	x11, x8
100116fc8:     	movi	d0, #0000000000000000
100116fcc:     	ldp	q4, q2, [x9, #-32]
100116fd0:     	sub	x12, x10, #64
100116fd4:     	ld2.8h	{ v27, v28 }, [x12]
100116fd8:     	ldp	q5, q3, [x9]
100116fdc:     	sub	x12, x10, #32
100116fe0:     	ld2.8h	{ v25, v26 }, [x12]
100116fe4:     	mov	x12, x10
100116fe8:     	ld2.8h	{ v22, v23 }, [x12], #32
100116fec:     	ld2.8h	{ v20, v21 }, [x12]
100116ff0:     	sshll2.4s	v24, v27, #0
100116ff4:     	sshll.4s	v19, v27, #0
100116ff8:     	sshll2.4s	v18, v25, #0
100116ffc:     	sshll.4s	v17, v25, #0
100117000:     	sshll2.4s	v16, v22, #0
100117004:     	sshll.4s	v7, v22, #0
100117008:     	sshll2.4s	v6, v20, #0
10011700c:     	sshll2.4s	v30, v28, #0
100117010:     	sshll.4s	v29, v20, #0
100117014:     	sshll.4s	v27, v28, #0
100117018:     	sshll2.4s	v28, v26, #0
10011701c:     	sshll.4s	v25, v26, #0
100117020:     	sshll2.4s	v26, v23, #0
100117024:     	sshll.4s	v22, v23, #0
100117028:     	sshll2.4s	v23, v21, #0
10011702c:     	sshll.4s	v21, v21, #0
100117030:     	sshll2.4s	v20, v4, #0
100117034:     	scvtf.4s	v31, v20
100117038:     	scvtf.4s	v20, v24
10011703c:     	fneg.4s	v20, v20
100117040:     	fmul.4s	v20, v20, v31
100117044:     	scvtf.4s	v24, v30
100117048:     	fneg.4s	v24, v24
10011704c:     	fmul.4s	v24, v24, v31
100117050:     	sshll.4s	v4, v4, #0
100117054:     	scvtf.4s	v4, v4
100117058:     	scvtf.4s	v19, v19
10011705c:     	fneg.4s	v19, v19
100117060:     	fmul.4s	v19, v19, v4
100117064:     	scvtf.4s	v27, v27
100117068:     	fneg.4s	v27, v27
10011706c:     	fmul.4s	v27, v27, v4
100117070:     	sshll2.4s	v4, v2, #0
100117074:     	scvtf.4s	v30, v4
100117078:     	scvtf.4s	v4, v18
10011707c:     	fneg.4s	v4, v4
100117080:     	scvtf.4s	v18, v28
100117084:     	fneg.4s	v18, v18
100117088:     	fmul.4s	v4, v4, v30
10011708c:     	fmul.4s	v18, v18, v30
100117090:     	sshll.4s	v2, v2, #0
100117094:     	scvtf.4s	v2, v2
100117098:     	scvtf.4s	v17, v17
10011709c:     	fneg.4s	v17, v17
1001170a0:     	fmul.4s	v17, v17, v2
1001170a4:     	scvtf.4s	v25, v25
1001170a8:     	fneg.4s	v25, v25
1001170ac:     	fmul.4s	v25, v25, v2
1001170b0:     	sshll2.4s	v2, v5, #0
1001170b4:     	scvtf.4s	v16, v16
1001170b8:     	scvtf.4s	v28, v2
1001170bc:     	fneg.4s	v2, v16
1001170c0:     	fmul.4s	v2, v2, v28
1001170c4:     	scvtf.4s	v16, v26
1001170c8:     	fneg.4s	v16, v16
1001170cc:     	fmul.4s	v16, v16, v28
1001170d0:     	sshll.4s	v5, v5, #0
1001170d4:     	scvtf.4s	v5, v5
1001170d8:     	scvtf.4s	v7, v7
1001170dc:     	fneg.4s	v7, v7
1001170e0:     	scvtf.4s	v22, v22
1001170e4:     	fneg.4s	v22, v22
1001170e8:     	fmul.4s	v7, v7, v5
1001170ec:     	fmul.4s	v22, v22, v5
1001170f0:     	sshll2.4s	v5, v3, #0
1001170f4:     	scvtf.4s	v26, v5
1001170f8:     	scvtf.4s	v5, v6
1001170fc:     	fneg.4s	v5, v5
100117100:     	fmul.4s	v5, v5, v26
100117104:     	scvtf.4s	v6, v23
100117108:     	fneg.4s	v6, v6
10011710c:     	fmul.4s	v6, v6, v26
100117110:     	sshll.4s	v3, v3, #0
100117114:     	scvtf.4s	v3, v3
100117118:     	scvtf.4s	v23, v29
10011711c:     	fneg.4s	v23, v23
100117120:     	fmul.4s	v23, v23, v3
100117124:     	scvtf.4s	v21, v21
100117128:     	fneg.4s	v21, v21
10011712c:     	fmul.4s	v3, v21, v3
100117130:     	mov	s21, v27[1]
100117134:     	fadd	s1, s1, s27
100117138:     	fadd	s1, s1, s21
10011713c:     	mov	s21, v27[2]
100117140:     	fadd	s1, s1, s21
100117144:     	mov	s21, v27[3]
100117148:     	fadd	s1, s1, s21
10011714c:     	mov	s21, v24[1]
100117150:     	fadd	s1, s1, s24
100117154:     	fadd	s1, s1, s21
100117158:     	mov	s21, v24[2]
10011715c:     	fadd	s1, s1, s21
100117160:     	mov	s21, v24[3]
100117164:     	fadd	s1, s1, s21
100117168:     	mov	s21, v25[1]
10011716c:     	fadd	s1, s1, s25
100117170:     	fadd	s1, s1, s21
100117174:     	mov	s21, v25[2]
100117178:     	fadd	s1, s1, s21
10011717c:     	mov	s21, v25[3]
100117180:     	fadd	s1, s1, s21
100117184:     	mov	s21, v18[1]
100117188:     	fadd	s1, s1, s18
10011718c:     	fadd	s1, s1, s21
100117190:     	mov	s21, v18[2]
100117194:     	fadd	s1, s1, s21
100117198:     	mov	s18, v18[3]
10011719c:     	fadd	s1, s1, s18
1001171a0:     	mov	s18, v22[1]
1001171a4:     	fadd	s1, s1, s22
1001171a8:     	fadd	s1, s1, s18
1001171ac:     	mov	s18, v22[2]
1001171b0:     	fadd	s1, s1, s18
1001171b4:     	mov	s18, v22[3]
1001171b8:     	fadd	s1, s1, s18
1001171bc:     	mov	s18, v16[1]
1001171c0:     	fadd	s1, s1, s16
1001171c4:     	fadd	s1, s1, s18
1001171c8:     	mov	s18, v16[2]
1001171cc:     	fadd	s1, s1, s18
1001171d0:     	mov	s16, v16[3]
1001171d4:     	fadd	s1, s1, s16
1001171d8:     	mov	s16, v3[1]
1001171dc:     	fadd	s1, s1, s3
1001171e0:     	fadd	s1, s1, s16
1001171e4:     	mov	s16, v3[2]
1001171e8:     	fadd	s1, s1, s16
1001171ec:     	fadd	s0, s0, s19
1001171f0:     	mov	s16, v19[1]
1001171f4:     	fadd	s0, s0, s16
1001171f8:     	mov	s16, v19[2]
1001171fc:     	fadd	s0, s0, s16
100117200:     	mov	s16, v19[3]
100117204:     	fadd	s0, s0, s16
100117208:     	mov	s16, v20[1]
10011720c:     	fadd	s0, s0, s20
100117210:     	fadd	s0, s0, s16
100117214:     	mov	s16, v20[2]
100117218:     	fadd	s0, s0, s16
10011721c:     	mov	s3, v3[3]
100117220:     	fadd	s1, s1, s3
100117224:     	mov	s3, v20[3]
100117228:     	fadd	s0, s0, s3
10011722c:     	mov	s3, v17[1]
100117230:     	fadd	s0, s0, s17
100117234:     	fadd	s0, s0, s3
100117238:     	mov	s3, v17[2]
10011723c:     	fadd	s0, s0, s3
100117240:     	mov	s3, v17[3]
100117244:     	fadd	s0, s0, s3
100117248:     	mov	s3, v6[1]
10011724c:     	fadd	s1, s1, s6
100117250:     	fadd	s1, s1, s3
100117254:     	mov	s3, v4[1]
100117258:     	fadd	s0, s0, s4
10011725c:     	fadd	s0, s0, s3
100117260:     	mov	s3, v4[2]
100117264:     	fadd	s0, s0, s3
100117268:     	mov	s3, v4[3]
10011726c:     	fadd	s0, s0, s3
100117270:     	mov	s3, v7[1]
100117274:     	fadd	s0, s0, s7
100117278:     	fadd	s0, s0, s3
10011727c:     	mov	s3, v6[2]
100117280:     	fadd	s1, s1, s3
100117284:     	mov	s3, v7[2]
100117288:     	fadd	s0, s0, s3
10011728c:     	mov	s3, v7[3]
100117290:     	fadd	s0, s0, s3
100117294:     	fadd	s0, s0, s2
100117298:     	mov	s3, v2[1]
10011729c:     	fadd	s0, s0, s3
1001172a0:     	mov	s3, v2[2]
1001172a4:     	fadd	s0, s0, s3
1001172a8:     	mov	s2, v2[3]
1001172ac:     	fadd	s0, s0, s2
1001172b0:     	mov	s2, v23[1]
1001172b4:     	fadd	s0, s0, s23
1001172b8:     	fadd	s0, s0, s2
1001172bc:     	mov	s2, v23[2]
1001172c0:     	fadd	s0, s0, s2
1001172c4:     	mov	s2, v6[3]
1001172c8:     	fadd	s1, s1, s2
1001172cc:     	mov	s2, v23[3]
1001172d0:     	fadd	s0, s0, s2
1001172d4:     	mov	s2, v5[1]
1001172d8:     	fadd	s0, s0, s5
1001172dc:     	fadd	s0, s0, s2
1001172e0:     	mov	s2, v5[2]
1001172e4:     	fadd	s0, s0, s2
1001172e8:     	mov	s2, v5[3]
1001172ec:     	fadd	s0, s0, s2
1001172f0:     	add	x9, x9, #64
1001172f4:     	add	x10, x10, #128
1001172f8:     	subs	x11, x11, #32
1001172fc:     	b.ne	0x100116fcc <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3c>
100117300:     	cmp	x8, x2
100117304:     	b.eq	0x10011734c <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3bc>
100117308:     	sub	x9, x2, x8
10011730c:     	add	x10, x0, x8, lsl #2
100117310:     	add	x10, x10, #2
100117314:     	add	x8, x1, x8, lsl #1
100117318:     	ldrsh	w11, [x8], #2
10011731c:     	scvtf	s2, w11
100117320:     	ldur	h3, [x10, #-2]
100117324:     	sshll.4s	v3, v3, #0
100117328:     	scvtf	s3, s3
10011732c:     	fmsub	s0, s3, s2, s0
100117330:     	ldr	h3, [x10]
100117334:     	sshll.4s	v3, v3, #0
100117338:     	scvtf	s3, s3
10011733c:     	fmsub	s1, s3, s2, s1
100117340:     	add	x10, x10, #4
100117344:     	subs	x9, x9, #1
100117348:     	b.ne	0x100117318 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x388>
10011734c:     	stp	s0, s1, [x3]
100117350:     	ret

0000000100118eb8 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
100118eb8:     	cbz	x2, 0x100118f18 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x60>
100118ebc:     	ldrsh	w8, [x1]
100118ec0:     	fmov	s0, w8
100118ec4:     	ldrsh	w8, [x1, #2]
100118ec8:     	mov.s	v0[1], w8
100118ecc:     	scvtf.2s	v0, v0
100118ed0:     	zip1.4s	v0, v0, v0
100118ed4:     	ldrsh	w8, [x0]
100118ed8:     	fmov	s1, w8
100118edc:     	ldrsh	w8, [x0, #2]
100118ee0:     	mov.s	v1[1], w8
100118ee4:     	scvtf.2s	v1, v1
100118ee8:     	mov.d	v1[1], v1[0]
100118eec:     	fsub.4s	v0, v1, v0
100118ef0:     	fmul.4s	v0, v0, v0
100118ef4:     	str	q0, [x3]
100118ef8:     	subs	x11, x2, #1
100118efc:     	b.eq	0x10011912c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x274>
100118f00:     	cmp	x2, #9
100118f04:     	b.hs	0x100118f20 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x68>
100118f08:     	mov	w8, #1
100118f0c:     	mov	x9, x1
100118f10:     	mov	x10, x0
100118f14:     	b	0x1001190d0 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x218>
100118f18:     	stp	xzr, xzr, [x3]
100118f1c:     	ret
100118f20:     	and	x12, x11, #0xfffffffffffffff8
100118f24:     	lsl	x8, x12, #2
100118f28:     	add	x9, x1, x8
100118f2c:     	add	x10, x0, x8
100118f30:     	orr	x8, x12, #0x1
100118f34:     	mov	s3, v0[1]
100118f38:     	mov	s2, v0[2]
100118f3c:     	mov	s1, v0[3]
100118f40:     	add	x13, x0, #4
100118f44:     	add	x14, x1, #4
100118f48:     	mov	x15, x12
100118f4c:     	ld2.8h	{ v4, v5 }, [x13], #32
100118f50:     	sshll2.4s	v6, v4, #0
100118f54:     	scvtf.4s	v6, v6
100118f58:     	sshll.4s	v7, v4, #0
100118f5c:     	scvtf.4s	v7, v7
100118f60:     	ld2.8h	{ v16, v17 }, [x14], #32
100118f64:     	sshll2.4s	v18, v16, #0
100118f68:     	scvtf.4s	v18, v18
100118f6c:     	sshll.4s	v19, v16, #0
100118f70:     	scvtf.4s	v19, v19
100118f74:     	sshll2.4s	v20, v17, #0
100118f78:     	sshll.4s	v16, v17, #0
100118f7c:     	sshll2.4s	v17, v5, #0
100118f80:     	sshll.4s	v4, v5, #0
100118f84:     	fsub.4s	v5, v7, v19
100118f88:     	scvtf.4s	v16, v16
100118f8c:     	fsub.4s	v7, v7, v16
100118f90:     	scvtf.4s	v4, v4
100118f94:     	fsub.4s	v19, v4, v19
100118f98:     	fsub.4s	v4, v4, v16
100118f9c:     	fsub.4s	v16, v6, v18
100118fa0:     	scvtf.4s	v20, v20
100118fa4:     	fsub.4s	v6, v6, v20
100118fa8:     	scvtf.4s	v17, v17
100118fac:     	fsub.4s	v18, v17, v18
100118fb0:     	fsub.4s	v17, v17, v20
100118fb4:     	fmul.4s	v4, v4, v4
100118fb8:     	mov	s20, v4[1]
100118fbc:     	fadd	s1, s1, s4
100118fc0:     	fadd	s1, s1, s20
100118fc4:     	mov	s20, v4[2]
100118fc8:     	fadd	s1, s1, s20
100118fcc:     	fmul.4s	v17, v17, v17
100118fd0:     	mov	s4, v4[3]
100118fd4:     	fadd	s1, s1, s4
100118fd8:     	mov	s4, v17[1]
100118fdc:     	fadd	s1, s1, s17
100118fe0:     	fadd	s1, s1, s4
100118fe4:     	mov	s4, v17[2]
100118fe8:     	fadd	s1, s1, s4
100118fec:     	fmul.4s	v4, v19, v19
100118ff0:     	mov	s17, v17[3]
100118ff4:     	fadd	s1, s1, s17
100118ff8:     	mov	s17, v4[1]
100118ffc:     	fadd	s3, s3, s4
100119000:     	fadd	s3, s3, s17
100119004:     	mov	s17, v4[2]
100119008:     	fadd	s3, s3, s17
10011900c:     	fmul.4s	v17, v18, v18
100119010:     	mov	s4, v4[3]
100119014:     	fadd	s3, s3, s4
100119018:     	mov	s4, v17[1]
10011901c:     	fadd	s3, s3, s17
100119020:     	fadd	s3, s3, s4
100119024:     	mov	s4, v17[2]
100119028:     	fadd	s3, s3, s4
10011902c:     	fmul.4s	v4, v7, v7
100119030:     	mov	s7, v17[3]
100119034:     	fadd	s3, s3, s7
100119038:     	mov	s7, v4[1]
10011903c:     	fadd	s2, s2, s4
100119040:     	fadd	s2, s2, s7
100119044:     	mov	s7, v4[2]
100119048:     	fadd	s2, s2, s7
10011904c:     	fmul.4s	v6, v6, v6
100119050:     	mov	s4, v4[3]
100119054:     	fadd	s2, s2, s4
100119058:     	mov	s4, v6[1]
10011905c:     	fadd	s2, s2, s6
100119060:     	fadd	s2, s2, s4
100119064:     	mov	s4, v6[2]
100119068:     	fadd	s2, s2, s4
10011906c:     	fmul.4s	v4, v5, v5
100119070:     	mov	s5, v6[3]
100119074:     	fadd	s2, s2, s5
100119078:     	mov	s5, v4[1]
10011907c:     	fadd	s0, s0, s4
100119080:     	fadd	s0, s0, s5
100119084:     	mov	s5, v4[2]
100119088:     	fadd	s0, s0, s5
10011908c:     	fmul.4s	v5, v16, v16
100119090:     	mov	s4, v4[3]
100119094:     	fadd	s0, s0, s4
100119098:     	mov	s4, v5[1]
10011909c:     	fadd	s0, s0, s5
1001190a0:     	fadd	s0, s0, s4
1001190a4:     	mov	s4, v5[3]
1001190a8:     	mov	s5, v5[2]
1001190ac:     	fadd	s0, s0, s5
1001190b0:     	fadd	s0, s0, s4
1001190b4:     	subs	x15, x15, #8
1001190b8:     	b.ne	0x100118f4c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x94>
1001190bc:     	mov.s	v0[1], v3[0]
1001190c0:     	mov.s	v0[2], v2[0]
1001190c4:     	mov.s	v0[3], v1[0]
1001190c8:     	cmp	x11, x12
1001190cc:     	b.eq	0x100119128 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x270>
1001190d0:     	add	x9, x9, #4
1001190d4:     	add	x10, x10, #4
1001190d8:     	sub	x8, x2, x8
1001190dc:     	ldrsh	w11, [x9]
1001190e0:     	fmov	s1, w11
1001190e4:     	ldrsh	w11, [x9, #2]
1001190e8:     	mov.s	v1[1], w11
1001190ec:     	scvtf.2s	v1, v1
1001190f0:     	zip1.4s	v1, v1, v1
1001190f4:     	ldrsh	w11, [x10]
1001190f8:     	fmov	s2, w11
1001190fc:     	ldrsh	w11, [x10, #2]
100119100:     	mov.s	v2[1], w11
100119104:     	scvtf.2s	v2, v2
100119108:     	mov.d	v2[1], v2[0]
10011910c:     	fsub.4s	v1, v2, v1
100119110:     	fmul.4s	v1, v1, v1
100119114:     	fadd.4s	v0, v0, v1
100119118:     	add	x9, x9, #4
10011911c:     	add	x10, x10, #4
100119120:     	subs	x8, x8, #1
100119124:     	b.ne	0x1001190dc <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x224>
100119128:     	str	q0, [x3]
10011912c:     	ret

0000000100119130 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100119130:     	cbz	x2, 0x1001191d0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0xa0>
100119134:     	ldrsh	w8, [x1, #2]
100119138:     	ldrsh	w9, [x1]
10011913c:     	fmov	s0, w9
100119140:     	mov.s	v0[1], w8
100119144:     	ldrsh	w8, [x0, #2]
100119148:     	ldrsh	w9, [x0]
10011914c:     	fmov	s1, w9
100119150:     	mov.s	v1[1], w8
100119154:     	mov.s	v1[2], w9
100119158:     	mov.s	v1[3], w8
10011915c:     	zip1.4s	v0, v0, v0
100119160:     	mul.4s	v0, v1, v0
100119164:     	scvtf.4s	v0, v0
100119168:     	fneg.4s	v0, v0
10011916c:     	str	q0, [x3]
100119170:     	subs	x8, x2, #1
100119174:     	b.eq	0x1001191cc <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x9c>
100119178:     	add	x9, x0, #4
10011917c:     	add	x10, x1, #4
100119180:     	ldrsh	w11, [x10, #2]
100119184:     	ldrsh	w12, [x10]
100119188:     	fmov	s1, w12
10011918c:     	mov.s	v1[1], w11
100119190:     	zip1.4s	v1, v1, v1
100119194:     	ldrsh	w11, [x9, #2]
100119198:     	ldrsh	w12, [x9]
10011919c:     	fmov	s2, w12
1001191a0:     	mov.s	v2[1], w11
1001191a4:     	mov.s	v2[2], w12
1001191a8:     	mov.s	v2[3], w11
1001191ac:     	mul.4s	v1, v2, v1
1001191b0:     	scvtf.4s	v1, v1
1001191b4:     	fsub.4s	v0, v0, v1
1001191b8:     	add	x9, x9, #4
1001191bc:     	add	x10, x10, #4
1001191c0:     	subs	x8, x8, #1
1001191c4:     	b.ne	0x100119180 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x50>
1001191c8:     	str	q0, [x3]
1001191cc:     	ret
1001191d0:     	stp	xzr, xzr, [x3]
1001191d4:     	ret

000000010011aa74 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
10011aa74:     	cbz	x2, 0x10011aabc <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x48>
10011aa78:     	ldr	h0, [x1]
10011aa7c:     	sshll.4s	v0, v0, #0
10011aa80:     	scvtf	s0, s0
10011aa84:     	ldr	d1, [x0]
10011aa88:     	sshll.4s	v1, v1, #0
10011aa8c:     	scvtf.4s	v1, v1
10011aa90:     	dup.4s	v0, v0[0]
10011aa94:     	fsub.4s	v0, v1, v0
10011aa98:     	fmul.4s	v0, v0, v0
10011aa9c:     	str	q0, [x3]
10011aaa0:     	subs	x10, x2, #1
10011aaa4:     	b.eq	0x10011ae40 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
10011aaa8:     	cmp	x2, #17
10011aaac:     	b.hs	0x10011aac4 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x50>
10011aab0:     	mov	w8, #1
10011aab4:     	mov	x9, x1
10011aab8:     	b	0x10011ae04 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
10011aabc:     	stp	xzr, xzr, [x3]
10011aac0:     	ret
10011aac4:     	and	x11, x10, #0xfffffffffffffff0
10011aac8:     	add	x9, x1, x11, lsl #1
10011aacc:     	orr	x8, x11, #0x1
10011aad0:     	mov	s1, v0[1]
10011aad4:     	mov	s2, v0[2]
10011aad8:     	mov	s3, v0[3]
10011aadc:     	add	x12, x0, #72
10011aae0:     	add	x13, x1, #18
10011aae4:     	mov	x14, x11
10011aae8:     	add	x0, x0, x11, lsl #3
10011aaec:     	sub	x15, x12, #64
10011aaf0:     	ld4.8h	{ v16, v17, v18, v19 }, [x15]
10011aaf4:     	ld4.8h	{ v20, v21, v22, v23 }, [x12]
10011aaf8:     	sshll2.4s	v5, v16, #0
10011aafc:     	sshll2.4s	v4, v20, #0
10011ab00:     	sshll.4s	v7, v16, #0
10011ab04:     	sshll.4s	v6, v20, #0
10011ab08:     	sshll2.4s	v25, v17, #0
10011ab0c:     	sshll.4s	v27, v17, #0
10011ab10:     	sshll2.4s	v24, v21, #0
10011ab14:     	sshll.4s	v26, v21, #0
10011ab18:     	sshll2.4s	v28, v18, #0
10011ab1c:     	sshll.4s	v29, v18, #0
10011ab20:     	sshll2.4s	v30, v19, #0
10011ab24:     	sshll.4s	v16, v19, #0
10011ab28:     	sshll2.4s	v17, v22, #0
10011ab2c:     	sshll.4s	v18, v22, #0
10011ab30:     	sshll2.4s	v19, v23, #0
10011ab34:     	sshll.4s	v20, v23, #0
10011ab38:     	ldur	q21, [x13, #-16]
10011ab3c:     	sshll.4s	v22, v21, #0
10011ab40:     	scvtf.4s	v22, v22
10011ab44:     	scvtf.4s	v7, v7
10011ab48:     	fsub.4s	v7, v7, v22
10011ab4c:     	scvtf.4s	v23, v27
10011ab50:     	fsub.4s	v23, v23, v22
10011ab54:     	scvtf.4s	v27, v29
10011ab58:     	fsub.4s	v27, v27, v22
10011ab5c:     	scvtf.4s	v16, v16
10011ab60:     	fsub.4s	v22, v16, v22
10011ab64:     	ldr	q29, [x13]
10011ab68:     	sshll2.4s	v16, v21, #0
10011ab6c:     	scvtf.4s	v21, v16
10011ab70:     	scvtf.4s	v5, v5
10011ab74:     	scvtf.4s	v25, v25
10011ab78:     	fsub.4s	v16, v5, v21
10011ab7c:     	fsub.4s	v25, v25, v21
10011ab80:     	scvtf.4s	v5, v28
10011ab84:     	fsub.4s	v28, v5, v21
10011ab88:     	scvtf.4s	v5, v30
10011ab8c:     	fsub.4s	v21, v5, v21
10011ab90:     	sshll.4s	v5, v29, #0
10011ab94:     	scvtf.4s	v30, v5
10011ab98:     	scvtf.4s	v5, v6
10011ab9c:     	fsub.4s	v5, v5, v30
10011aba0:     	scvtf.4s	v6, v26
10011aba4:     	scvtf.4s	v18, v18
10011aba8:     	fsub.4s	v6, v6, v30
10011abac:     	fsub.4s	v18, v18, v30
10011abb0:     	scvtf.4s	v20, v20
10011abb4:     	fsub.4s	v20, v20, v30
10011abb8:     	sshll2.4s	v26, v29, #0
10011abbc:     	scvtf.4s	v26, v26
10011abc0:     	scvtf.4s	v4, v4
10011abc4:     	fsub.4s	v4, v4, v26
10011abc8:     	scvtf.4s	v24, v24
10011abcc:     	fsub.4s	v24, v24, v26
10011abd0:     	scvtf.4s	v17, v17
10011abd4:     	scvtf.4s	v19, v19
10011abd8:     	fsub.4s	v17, v17, v26
10011abdc:     	fsub.4s	v19, v19, v26
10011abe0:     	fmul.4s	v22, v22, v22
10011abe4:     	mov	s26, v22[1]
10011abe8:     	fadd	s3, s3, s22
10011abec:     	fadd	s3, s3, s26
10011abf0:     	mov	s26, v22[2]
10011abf4:     	fadd	s3, s3, s26
10011abf8:     	fmul.4s	v21, v21, v21
10011abfc:     	mov	s22, v22[3]
10011ac00:     	fadd	s3, s3, s22
10011ac04:     	mov	s22, v21[1]
10011ac08:     	fadd	s3, s3, s21
10011ac0c:     	fadd	s3, s3, s22
10011ac10:     	mov	s22, v21[2]
10011ac14:     	fadd	s3, s3, s22
10011ac18:     	mov	s21, v21[3]
10011ac1c:     	fmul.4s	v20, v20, v20
10011ac20:     	fadd	s3, s3, s21
10011ac24:     	mov	s21, v20[1]
10011ac28:     	fadd	s3, s3, s20
10011ac2c:     	fadd	s3, s3, s21
10011ac30:     	mov	s21, v20[2]
10011ac34:     	fadd	s3, s3, s21
10011ac38:     	fmul.4s	v21, v27, v27
10011ac3c:     	fmul.4s	v19, v19, v19
10011ac40:     	mov	s20, v20[3]
10011ac44:     	fadd	s3, s3, s20
10011ac48:     	mov	s20, v19[1]
10011ac4c:     	fadd	s3, s3, s19
10011ac50:     	fadd	s3, s3, s20
10011ac54:     	mov	s20, v21[1]
10011ac58:     	fadd	s2, s2, s21
10011ac5c:     	fadd	s2, s2, s20
10011ac60:     	mov	s20, v21[2]
10011ac64:     	fadd	s2, s2, s20
10011ac68:     	fmul.4s	v20, v28, v28
10011ac6c:     	mov	s21, v21[3]
10011ac70:     	fadd	s2, s2, s21
10011ac74:     	mov	s21, v20[1]
10011ac78:     	fadd	s2, s2, s20
10011ac7c:     	fadd	s2, s2, s21
10011ac80:     	mov	s21, v20[2]
10011ac84:     	fadd	s2, s2, s21
10011ac88:     	mov	s20, v20[3]
10011ac8c:     	fmul.4s	v18, v18, v18
10011ac90:     	fadd	s2, s2, s20
10011ac94:     	mov	s20, v18[1]
10011ac98:     	fadd	s2, s2, s18
10011ac9c:     	fadd	s2, s2, s20
10011aca0:     	mov	s20, v18[2]
10011aca4:     	fadd	s2, s2, s20
10011aca8:     	fmul.4s	v20, v23, v23
10011acac:     	fmul.4s	v17, v17, v17
10011acb0:     	mov	s18, v18[3]
10011acb4:     	fadd	s2, s2, s18
10011acb8:     	mov	s18, v17[1]
10011acbc:     	fadd	s2, s2, s17
10011acc0:     	fadd	s2, s2, s18
10011acc4:     	mov	s18, v19[2]
10011acc8:     	fadd	s3, s3, s18
10011accc:     	mov	s18, v17[2]
10011acd0:     	fadd	s2, s2, s18
10011acd4:     	mov	s18, v20[1]
10011acd8:     	fadd	s1, s1, s20
10011acdc:     	fadd	s1, s1, s18
10011ace0:     	mov	s18, v20[2]
10011ace4:     	fadd	s1, s1, s18
10011ace8:     	mov	s18, v20[3]
10011acec:     	fadd	s1, s1, s18
10011acf0:     	fmul.4s	v18, v25, v25
10011acf4:     	mov	s19, v19[3]
10011acf8:     	fadd	s3, s3, s19
10011acfc:     	mov	s19, v18[1]
10011ad00:     	fadd	s1, s1, s18
10011ad04:     	fadd	s1, s1, s19
10011ad08:     	mov	s19, v18[2]
10011ad0c:     	fadd	s1, s1, s19
10011ad10:     	mov	s18, v18[3]
10011ad14:     	fmul.4s	v6, v6, v6
10011ad18:     	fadd	s1, s1, s18
10011ad1c:     	mov	s18, v6[1]
10011ad20:     	fadd	s1, s1, s6
10011ad24:     	fadd	s1, s1, s18
10011ad28:     	mov	s18, v6[2]
10011ad2c:     	fadd	s1, s1, s18
10011ad30:     	fmul.4s	v18, v24, v24
10011ad34:     	mov	s6, v6[3]
10011ad38:     	fadd	s1, s1, s6
10011ad3c:     	mov	s6, v18[1]
10011ad40:     	fadd	s1, s1, s18
10011ad44:     	fadd	s1, s1, s6
10011ad48:     	mov	s6, v18[2]
10011ad4c:     	fadd	s1, s1, s6
10011ad50:     	fmul.4s	v6, v7, v7
10011ad54:     	mov	s7, v17[3]
10011ad58:     	fadd	s2, s2, s7
10011ad5c:     	mov	s7, v6[1]
10011ad60:     	fadd	s0, s0, s6
10011ad64:     	fadd	s0, s0, s7
10011ad68:     	mov	s7, v6[2]
10011ad6c:     	fadd	s0, s0, s7
10011ad70:     	fmul.4s	v7, v16, v16
10011ad74:     	mov	s6, v6[3]
10011ad78:     	fadd	s0, s0, s6
10011ad7c:     	mov	s6, v7[1]
10011ad80:     	fadd	s0, s0, s7
10011ad84:     	fadd	s0, s0, s6
10011ad88:     	mov	s6, v7[2]
10011ad8c:     	fadd	s0, s0, s6
10011ad90:     	mov	s6, v7[3]
10011ad94:     	fadd	s0, s0, s6
10011ad98:     	fmul.4s	v5, v5, v5
10011ad9c:     	mov	s6, v18[3]
10011ada0:     	fadd	s1, s1, s6
10011ada4:     	mov	s6, v5[1]
10011ada8:     	fadd	s0, s0, s5
10011adac:     	fadd	s0, s0, s6
10011adb0:     	mov	s6, v5[2]
10011adb4:     	fadd	s0, s0, s6
10011adb8:     	fmul.4s	v4, v4, v4
10011adbc:     	mov	s5, v5[3]
10011adc0:     	fadd	s0, s0, s5
10011adc4:     	mov	s5, v4[1]
10011adc8:     	fadd	s0, s0, s4
10011adcc:     	fadd	s0, s0, s5
10011add0:     	mov	s5, v4[2]
10011add4:     	fadd	s0, s0, s5
10011add8:     	mov	s4, v4[3]
10011addc:     	fadd	s0, s0, s4
10011ade0:     	add	x12, x12, #128
10011ade4:     	add	x13, x13, #32
10011ade8:     	subs	x14, x14, #16
10011adec:     	b.ne	0x10011aaec <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x78>
10011adf0:     	mov.s	v0[1], v1[0]
10011adf4:     	mov.s	v0[2], v2[0]
10011adf8:     	mov.s	v0[3], v3[0]
10011adfc:     	cmp	x10, x11
10011ae00:     	b.eq	0x10011ae3c <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3c8>
10011ae04:     	add	x9, x9, #2
10011ae08:     	add	x10, x0, #8
10011ae0c:     	sub	x8, x2, x8
10011ae10:     	ldrsh	w11, [x9], #2
10011ae14:     	scvtf	s1, w11
10011ae18:     	ldr	d2, [x10], #8
10011ae1c:     	sshll.4s	v2, v2, #0
10011ae20:     	scvtf.4s	v2, v2
10011ae24:     	dup.4s	v1, v1[0]
10011ae28:     	fsub.4s	v1, v2, v1
10011ae2c:     	fmul.4s	v1, v1, v1
10011ae30:     	fadd.4s	v0, v0, v1
10011ae34:     	subs	x8, x8, #1
10011ae38:     	b.ne	0x10011ae10 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x39c>
10011ae3c:     	str	q0, [x3]
10011ae40:     	ret

000000010011ae44 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
10011ae44:     	cbz	x2, 0x10011ae9c <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x58>
10011ae48:     	ld1r.4h	{ v0 }, [x1]
10011ae4c:     	ldr	d1, [x0]
10011ae50:     	smull.4s	v0, v0, v1
10011ae54:     	scvtf.4s	v0, v0
10011ae58:     	fneg.4s	v0, v0
10011ae5c:     	str	q0, [x3]
10011ae60:     	cmp	x2, #1
10011ae64:     	b.eq	0x10011ae98 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x54>
10011ae68:     	add	x8, x1, #2
10011ae6c:     	add	x9, x0, #8
10011ae70:     	lsl	x10, x2, #1
10011ae74:     	sub	x10, x10, #2
10011ae78:     	ldr	d1, [x9], #8
10011ae7c:     	ld1r.4h	{ v2 }, [x8], #2
10011ae80:     	smull.4s	v1, v2, v1
10011ae84:     	scvtf.4s	v1, v1
10011ae88:     	fsub.4s	v0, v0, v1
10011ae8c:     	subs	x10, x10, #2
10011ae90:     	b.ne	0x10011ae78 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x34>
10011ae94:     	str	q0, [x3]
10011ae98:     	ret
10011ae9c:     	stp	xzr, xzr, [x3]
10011aea0:     	ret

000000010011d0c4 <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10011d0c4:     	cbz	x2, 0x10011d0cc <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10011d0c8:     	b	0x10011d0d8 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011d0cc:     	movi.2d	v0, #0000000000000000
10011d0d0:     	stp	q0, q0, [x3]
10011d0d4:     	ret

000000010011d4ac <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10011d4ac:     	cbz	x2, 0x10011d4b4 <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011d4b0:     	b	0x10011d4c0 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011d4b4:     	movi.2d	v0, #0000000000000000
10011d4b8:     	stp	q0, q0, [x3]
10011d4bc:     	ret

000000010011f16c <void kernel<short, 4ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10011f16c:     	b	0x10011f170 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010011f26c <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10011f26c:     	cbz	x2, 0x10011f274 <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011f270:     	b	0x10011f284 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
10011f274:     	movi.2d	v0, #0000000000000000
10011f278:     	stp	q0, q0, [x3, #32]
10011f27c:     	stp	q0, q0, [x3]
10011f280:     	ret

0000000100121508 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100121508:     	cbz	x2, 0x100121510 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10012150c:     	b	0x10012151c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
100121510:     	movi.2d	v0, #0000000000000000
100121514:     	stp	q0, q0, [x3]
100121518:     	ret

00000001001215b4 <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001215b4:     	cbz	x2, 0x1001215bc <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001215b8:     	b	0x1001215c8 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
1001215bc:     	movi.2d	v0, #0000000000000000
1001215c0:     	stp	q0, q0, [x3]
1001215c4:     	ret

00000001001237f4 <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
1001237f4:     	cbz	x2, 0x1001237fc <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001237f8:     	b	0x10012380c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
1001237fc:     	movi.2d	v0, #0000000000000000
100123800:     	stp	q0, q0, [x3, #32]
100123804:     	stp	q0, q0, [x3]
100123808:     	ret

000000010012394c <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10012394c:     	cbz	x2, 0x100123954 <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
100123950:     	b	0x100123964 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
100123954:     	movi.2d	v0, #0000000000000000
100123958:     	stp	q0, q0, [x3, #32]
10012395c:     	stp	q0, q0, [x3]
100123960:     	ret

00000001001261b0 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
1001261b0:     	cbz	x2, 0x1001261b8 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001261b4:     	b	0x1001261d0 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001261b8:     	movi.2d	v0, #0000000000000000
1001261bc:     	stp	q0, q0, [x3, #96]
1001261c0:     	stp	q0, q0, [x3, #64]
1001261c4:     	stp	q0, q0, [x3, #32]
1001261c8:     	stp	q0, q0, [x3]
1001261cc:     	ret

00000001001263c0 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
1001263c0:     	cbz	x2, 0x1001263c8 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001263c4:     	b	0x1001263e0 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001263c8:     	movi.2d	v0, #0000000000000000
1001263cc:     	stp	q0, q0, [x3, #96]
1001263d0:     	stp	q0, q0, [x3, #64]
1001263d4:     	stp	q0, q0, [x3, #32]
1001263d8:     	stp	q0, q0, [x3]
1001263dc:     	ret

0000000100128dfc <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100128dfc:     	cbz	x2, 0x100128e04 <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)+0x8>
100128e00:     	b	0x100128e2c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(short const*, short const*, unsigned long, float*)>
100128e04:     	movi.2d	v0, #0000000000000000
100128e08:     	stp	q0, q0, [x3, #224]
100128e0c:     	stp	q0, q0, [x3, #192]
100128e10:     	stp	q0, q0, [x3, #160]
100128e14:     	stp	q0, q0, [x3, #128]
100128e18:     	stp	q0, q0, [x3, #96]
100128e1c:     	stp	q0, q0, [x3, #64]
100128e20:     	stp	q0, q0, [x3, #32]
100128e24:     	stp	q0, q0, [x3]
100128e28:     	ret

0000000100129248 <void kernel<short, 8ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100129248:     	b	0x10012924c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

000000010012b674 <void kernel<short, 16ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
10012b674:     	b	0x10012b678 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010012b708 <void kernel<short, 16ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
10012b708:     	b	0x10012b70c <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010012e1a4 <void kernel<short, 16ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10012e1a4:     	b	0x10012e1a8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010012e2c4 <void kernel<short, 16ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10012e2c4:     	b	0x10012e2c8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

00000001001310d0 <void kernel<short, 16ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
1001310d0:     	b	0x1001310d4 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

0000000100131300 <void kernel<short, 16ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
100131300:     	b	0x100131304 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

0000000100134b54 <void kernel<short, 16ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100134b54:     	b	0x100134b58 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100134c44 <void kernel<short, 16ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100134c44:     	b	0x100134c48 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

00000001001385b8 <void kernel<short, 16ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
1001385b8:     	b	0x1001385bc <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010013866c <void kernel<short, 16ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10013866c:     	b	0x100138670 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

0000000100139608 <void kernel<short, 32ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100139608:     	b	0x10013960c <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

00000001001397bc <void kernel<short, 32ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001397bc:     	b	0x1001397c0 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010013b1c0 <void kernel<short, 32ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10013b1c0:     	b	0x10013b1c4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010013b520 <void kernel<short, 32ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10013b520:     	b	0x10013b524 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010013d524 <void kernel<short, 32ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10013d524:     	b	0x10013d528 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010013d72c <void kernel<short, 32ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10013d72c:     	b	0x10013d730 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

00000001001401c8 <void kernel<short, 32ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
1001401c8:     	b	0x1001401cc <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100140394 <void kernel<short, 32ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100140394:     	b	0x100140398 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100142eb0 <void kernel<short, 32ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
100142eb0:     	b	0x100142eb4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010014307c <void kernel<short, 32ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10014307c:     	b	0x100143080 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

00000001001448c8 <void kernel<short, 32ul, 32ul, false>(short const*, short const*, unsigned long, float*)>:
1001448c8:     	b	0x1001448cc <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100144a94 <void kernel<short, 32ul, 32ul, true>(short const*, short const*, unsigned long, float*)>:
100144a94:     	b	0x100144a98 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100146fcc <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>:
100146fcc:     	add	x8, x0, x2, lsl #1
100146fd0:     	ands	x9, x2, #0xfffffffffffffff8
100146fd4:     	b.eq	0x10014706c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xa0>
100146fd8:     	add	x11, x0, x9, lsl #1
100146fdc:     	lsl	x9, x2, #1
100146fe0:     	and	x9, x9, #0xfffffffffffffff0
100146fe4:     	movi.2d	v0, #0000000000000000
100146fe8:     	mov	x10, x0
100146fec:     	movi.2d	v1, #0000000000000000
100146ff0:     	ldr	q2, [x10], #16
100146ff4:     	ldr	q3, [x1], #16
100146ff8:     	fcvtl	v4.4s, v2.4h
100146ffc:     	fcvtl	v5.4s, v3.4h
100147000:     	fmla.4s	v0, v5, v4
100147004:     	fcvtl2	v2.4s, v2.8h
100147008:     	fcvtl2	v3.4s, v3.8h
10014700c:     	fmla.4s	v1, v3, v2
100147010:     	subs	x9, x9, #16
100147014:     	b.ne	0x100146ff0 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x24>
100147018:     	sub	x9, x8, x11
10014701c:     	cmp	x9, #7
100147020:     	b.lt	0x100147038 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147024:     	ldr	d2, [x11], #8
100147028:     	fcvtl	v2.4s, v2.4h
10014702c:     	ldr	d3, [x1], #8
100147030:     	fcvtl	v3.4s, v3.4h
100147034:     	fmla.4s	v0, v3, v2
100147038:     	fadd.4s	v0, v1, v0
10014703c:     	faddp.4s	v0, v0, v0
100147040:     	faddp.2s	s0, v0
100147044:     	cmp	x11, x8
100147048:     	b.eq	0x100147188 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014704c:     	add	x9, x0, x2, lsl #1
100147050:     	sub	x9, x9, x11
100147054:     	sub	x9, x9, #2
100147058:     	cmp	x9, #30
10014705c:     	b.hs	0x100147088 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xbc>
100147060:     	mov	x9, x11
100147064:     	mov	x10, x1
100147068:     	b	0x10014716c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
10014706c:     	movi.2d	v1, #0000000000000000
100147070:     	movi.2d	v0, #0000000000000000
100147074:     	mov	x11, x0
100147078:     	sub	x9, x8, x0
10014707c:     	cmp	x9, #7
100147080:     	b.ge	0x100147024 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x58>
100147084:     	b	0x100147038 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147088:     	lsr	x9, x9, #1
10014708c:     	add	x12, x9, #1
100147090:     	and	x13, x12, #0xfffffffffffffff0
100147094:     	lsl	x10, x13, #1
100147098:     	add	x9, x11, x10
10014709c:     	add	x10, x1, x10
1001470a0:     	add	x14, x1, #16
1001470a4:     	add	x11, x11, #16
1001470a8:     	mov	x15, x13
1001470ac:     	ldp	q1, q2, [x11, #-16]
1001470b0:     	fcvtl	v3.4s, v1.4h
1001470b4:     	fcvtl2	v1.4s, v1.8h
1001470b8:     	fcvtl	v4.4s, v2.4h
1001470bc:     	fcvtl2	v2.4s, v2.8h
1001470c0:     	ldp	q5, q6, [x14, #-16]
1001470c4:     	fcvtl	v7.4s, v5.4h
1001470c8:     	fcvtl2	v5.4s, v5.8h
1001470cc:     	fcvtl	v16.4s, v6.4h
1001470d0:     	fcvtl2	v6.4s, v6.8h
1001470d4:     	fmul.4s	v1, v1, v5
1001470d8:     	mov	s5, v1[3]
1001470dc:     	mov	s17, v1[2]
1001470e0:     	mov	s18, v1[1]
1001470e4:     	fmul.4s	v3, v3, v7
1001470e8:     	mov	s7, v3[3]
1001470ec:     	mov	s19, v3[2]
1001470f0:     	mov	s20, v3[1]
1001470f4:     	fmul.4s	v2, v2, v6
1001470f8:     	mov	s6, v2[3]
1001470fc:     	mov	s21, v2[2]
100147100:     	mov	s22, v2[1]
100147104:     	fmul.4s	v4, v4, v16
100147108:     	mov	s16, v4[3]
10014710c:     	mov	s23, v4[2]
100147110:     	mov	s24, v4[1]
100147114:     	fadd	s0, s0, s3
100147118:     	fadd	s0, s0, s20
10014711c:     	fadd	s0, s0, s19
100147120:     	fadd	s0, s0, s7
100147124:     	fadd	s0, s0, s1
100147128:     	fadd	s0, s0, s18
10014712c:     	fadd	s0, s0, s17
100147130:     	fadd	s0, s0, s5
100147134:     	fadd	s0, s0, s4
100147138:     	fadd	s0, s0, s24
10014713c:     	fadd	s0, s0, s23
100147140:     	fadd	s0, s0, s16
100147144:     	fadd	s0, s0, s2
100147148:     	fadd	s0, s0, s22
10014714c:     	fadd	s0, s0, s21
100147150:     	fadd	s0, s0, s6
100147154:     	add	x14, x14, #32
100147158:     	add	x11, x11, #32
10014715c:     	subs	x15, x15, #16
100147160:     	b.ne	0x1001470ac <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xe0>
100147164:     	cmp	x12, x13
100147168:     	b.eq	0x100147188 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014716c:     	ldr	h1, [x9], #2
100147170:     	fcvt	s1, h1
100147174:     	ldr	h2, [x10], #2
100147178:     	fcvt	s2, h2
10014717c:     	fmadd	s0, s1, s2, s0
100147180:     	cmp	x9, x8
100147184:     	b.ne	0x10014716c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
100147188:     	fneg	s0, s0
10014718c:     	str	s0, [x3]
100147190:     	ret
