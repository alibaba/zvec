00000001000b9dbc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b9dbc:     	sub	sp, sp, #176
1000b9dc0:     	stp	x28, x27, [sp, #80]
1000b9dc4:     	stp	x26, x25, [sp, #96]
1000b9dc8:     	stp	x24, x23, [sp, #112]
1000b9dcc:     	stp	x22, x21, [sp, #128]
1000b9dd0:     	stp	x20, x19, [sp, #144]
1000b9dd4:     	stp	x29, x30, [sp, #160]
1000b9dd8:     	add	x29, sp, #160
1000b9ddc:     	str	x3, [sp]
1000b9de0:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000b9de4:     	ldr	x8, [x8, #392]
1000b9de8:     	ldr	x8, [x8]
1000b9dec:     	str	x8, [sp, #72]
1000b9df0:     	movi.2d	v0, #0000000000000000
1000b9df4:     	stp	q0, q0, [sp, #32]
1000b9df8:     	ands	x8, x2, #0xfffffffffffffffe
1000b9dfc:     	b.eq	0x1000b9fa0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000b9e00:     	add	x8, x1, x8
1000b9e04:     	str	x8, [sp, #8]
1000b9e08:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24>
1000b9e0c:     	add	x9, x9, #220
1000b9e10:     	mov	x11, #0
1000b9e14:     	ldp	w4, w23, [x1]
1000b9e18:     	ubfx	x8, x4, #4, #4
1000b9e1c:     	stp	x1, x8, [sp, #16]
1000b9e20:     	ubfx	x13, x4, #8, #4
1000b9e24:     	and	x14, x4, #0xf
1000b9e28:     	ubfx	x15, x4, #12, #4
1000b9e2c:     	ubfx	x16, x4, #16, #4
1000b9e30:     	ubfx	x17, x4, #20, #4
1000b9e34:     	ubfx	x2, x4, #24, #4
1000b9e38:     	lsr	x4, x4, #28
1000b9e3c:     	and	x5, x23, #0xf
1000b9e40:     	ubfx	x6, x23, #4, #4
1000b9e44:     	ubfx	x7, x23, #8, #4
1000b9e48:     	ubfx	x19, x23, #12, #4
1000b9e4c:     	ubfx	x20, x23, #16, #4
1000b9e50:     	ubfx	x21, x23, #20, #4
1000b9e54:     	ubfx	x22, x23, #24, #4
1000b9e58:     	lsr	x23, x23, #28
1000b9e5c:     	ldr	w24, [x0, x11]
1000b9e60:     	lsl	w25, w24, #4
1000b9e64:     	and	x25, x25, #0xf0
1000b9e68:     	orr	x26, x25, x14
1000b9e6c:     	ldrb	w26, [x9, x26]
1000b9e70:     	and	x27, x24, #0xf0
1000b9e74:     	ldr	x8, [sp, #24]
1000b9e78:     	orr	x28, x27, x8
1000b9e7c:     	ldrb	w28, [x9, x28]
1000b9e80:     	lsr	x30, x24, #4
1000b9e84:     	and	x30, x30, #0xf0
1000b9e88:     	orr	x8, x30, x13
1000b9e8c:     	ldrb	w8, [x9, x8]
1000b9e90:     	add	w26, w26, w28
1000b9e94:     	add	w8, w26, w8
1000b9e98:     	lsr	x26, x24, #8
1000b9e9c:     	and	x26, x26, #0xf0
1000b9ea0:     	orr	x28, x26, x15
1000b9ea4:     	ldrb	w28, [x9, x28]
1000b9ea8:     	lsr	x3, x24, #12
1000b9eac:     	and	x3, x3, #0xf0
1000b9eb0:     	orr	x10, x3, x16
1000b9eb4:     	ldrb	w10, [x9, x10]
1000b9eb8:     	add	w8, w8, w28
1000b9ebc:     	add	w8, w8, w10
1000b9ec0:     	lsr	x10, x24, #16
1000b9ec4:     	and	x10, x10, #0xf0
1000b9ec8:     	orr	x28, x10, x17
1000b9ecc:     	ldrb	w28, [x9, x28]
1000b9ed0:     	lsr	x1, x24, #20
1000b9ed4:     	and	x1, x1, #0xf0
1000b9ed8:     	orr	x12, x1, x2
1000b9edc:     	ldrb	w12, [x9, x12]
1000b9ee0:     	add	w8, w8, w28
1000b9ee4:     	add	x28, sp, #32
1000b9ee8:     	add	w8, w8, w12
1000b9eec:     	lsr	x12, x24, #24
1000b9ef0:     	and	x12, x12, #0xf0
1000b9ef4:     	orr	x24, x12, x4
1000b9ef8:     	ldrb	w24, [x9, x24]
1000b9efc:     	add	w8, w8, w24
1000b9f00:     	scvtf	s0, w8
1000b9f04:     	add	x8, x28, x11
1000b9f08:     	ldr	s1, [x8]
1000b9f0c:     	fadd	s0, s1, s0
1000b9f10:     	orr	x24, x25, x5
1000b9f14:     	ldrb	w24, [x9, x24]
1000b9f18:     	orr	x25, x27, x6
1000b9f1c:     	ldrb	w25, [x9, x25]
1000b9f20:     	orr	x27, x30, x7
1000b9f24:     	ldrb	w27, [x9, x27]
1000b9f28:     	add	w24, w24, w25
1000b9f2c:     	add	w24, w24, w27
1000b9f30:     	orr	x25, x26, x19
1000b9f34:     	ldrb	w25, [x9, x25]
1000b9f38:     	orr	x3, x3, x20
1000b9f3c:     	ldrb	w3, [x9, x3]
1000b9f40:     	orr	x10, x10, x21
1000b9f44:     	ldrb	w10, [x9, x10]
1000b9f48:     	add	w24, w24, w25
1000b9f4c:     	add	w3, w24, w3
1000b9f50:     	orr	x1, x1, x22
1000b9f54:     	ldrb	w1, [x9, x1]
1000b9f58:     	add	w10, w3, w10
1000b9f5c:     	add	w10, w10, w1
1000b9f60:     	orr	x12, x12, x23
1000b9f64:     	ldrb	w12, [x9, x12]
1000b9f68:     	add	w10, w10, w12
1000b9f6c:     	scvtf	s1, w10
1000b9f70:     	str	s0, [x8]
1000b9f74:     	ldr	s0, [x8, #16]
1000b9f78:     	fadd	s0, s0, s1
1000b9f7c:     	str	s0, [x8, #16]
1000b9f80:     	add	x11, x11, #4
1000b9f84:     	cmp	x11, #16
1000b9f88:     	b.ne	0x1000b9e5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000b9f8c:     	add	x0, x0, #16
1000b9f90:     	ldp	x8, x1, [sp, #8]
1000b9f94:     	add	x1, x1, #8
1000b9f98:     	cmp	x1, x8
1000b9f9c:     	b.ne	0x1000b9e10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000b9fa0:     	ldp	q0, q1, [sp, #32]
1000b9fa4:     	ldr	x8, [sp]
1000b9fa8:     	stp	q0, q1, [x8]
1000b9fac:     	ldr	x8, [sp, #72]
1000b9fb0:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d4>
1000b9fb4:     	ldr	x9, [x9, #392]
1000b9fb8:     	ldr	x9, [x9]
1000b9fbc:     	cmp	x9, x8
1000b9fc0:     	b.ne	0x1000b9fe4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000b9fc4:     	ldp	x29, x30, [sp, #160]
1000b9fc8:     	ldp	x20, x19, [sp, #144]
1000b9fcc:     	ldp	x22, x21, [sp, #128]
1000b9fd0:     	ldp	x24, x23, [sp, #112]
1000b9fd4:     	ldp	x26, x25, [sp, #96]
1000b9fd8:     	ldp	x28, x27, [sp, #80]
1000b9fdc:     	add	sp, sp, #176
1000b9fe0:     	ret
1000b9fe4:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

