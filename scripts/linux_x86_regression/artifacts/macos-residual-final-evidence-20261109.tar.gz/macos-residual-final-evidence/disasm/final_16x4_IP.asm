00000001000ca4b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ca4b4:     	stp	x28, x27, [sp, #-96]!
1000ca4b8:     	stp	x26, x25, [sp, #16]
1000ca4bc:     	stp	x24, x23, [sp, #32]
1000ca4c0:     	stp	x22, x21, [sp, #48]
1000ca4c4:     	stp	x20, x19, [sp, #64]
1000ca4c8:     	stp	x29, x30, [sp, #80]
1000ca4cc:     	add	x29, sp, #80
1000ca4d0:     	sub	sp, sp, #448
1000ca4d4:     	str	x3, [sp]
1000ca4d8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000ca4dc:     	ldr	x8, [x8, #392]
1000ca4e0:     	ldr	x8, [x8]
1000ca4e4:     	stur	x8, [x29, #-96]
1000ca4e8:     	movi.2d	v0, #0000000000000000
1000ca4ec:     	stp	q0, q0, [sp, #400]
1000ca4f0:     	lsl	x8, x2, #1
1000ca4f4:     	stp	q0, q0, [sp, #368]
1000ca4f8:     	stp	q0, q0, [sp, #336]
1000ca4fc:     	stp	q0, q0, [sp, #304]
1000ca500:     	stp	q0, q0, [sp, #272]
1000ca504:     	stp	q0, q0, [sp, #240]
1000ca508:     	stp	q0, q0, [sp, #208]
1000ca50c:     	stp	q0, q0, [sp, #176]
1000ca510:     	ands	x8, x8, #0xfffffffffffffffc
1000ca514:     	b.eq	0x1000ca7f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000ca518:     	add	x8, x1, x8
1000ca51c:     	str	x8, [sp, #8]
1000ca520:     	add	x8, sp, #176
1000ca524:     	add	x27, x8, #128
1000ca528:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000ca52c:     	add	x11, x11, #1468
1000ca530:     	mov	x12, #0
1000ca534:     	ldp	w8, w9, [x1]
1000ca538:     	ubfx	x10, x8, #8, #4
1000ca53c:     	str	x10, [sp, #168]
1000ca540:     	ubfx	x10, x8, #16, #4
1000ca544:     	str	x10, [sp, #160]
1000ca548:     	ubfx	x10, x8, #24, #4
1000ca54c:     	str	x10, [sp, #152]
1000ca550:     	ldp	w10, w17, [x1, #8]
1000ca554:     	str	x1, [sp, #16]
1000ca558:     	and	x14, x8, #0xf
1000ca55c:     	ubfx	x13, x8, #4, #4
1000ca560:     	stp	x13, x14, [sp, #136]
1000ca564:     	ubfx	x14, x8, #12, #4
1000ca568:     	ubfx	x13, x8, #20, #4
1000ca56c:     	stp	x13, x14, [sp, #120]
1000ca570:     	lsr	x8, x8, #28
1000ca574:     	str	x8, [sp, #112]
1000ca578:     	and	x8, x9, #0xf
1000ca57c:     	str	x8, [sp, #104]
1000ca580:     	ubfx	x8, x9, #8, #4
1000ca584:     	str	x8, [sp, #96]
1000ca588:     	ubfx	x8, x9, #16, #4
1000ca58c:     	str	x8, [sp, #88]
1000ca590:     	ubfx	x8, x9, #24, #4
1000ca594:     	str	x8, [sp, #80]
1000ca598:     	ubfx	x8, x9, #4, #4
1000ca59c:     	str	x8, [sp, #72]
1000ca5a0:     	ubfx	x8, x9, #12, #4
1000ca5a4:     	str	x8, [sp, #64]
1000ca5a8:     	ubfx	x8, x9, #20, #4
1000ca5ac:     	str	x8, [sp, #56]
1000ca5b0:     	lsr	x8, x9, #28
1000ca5b4:     	str	x8, [sp, #48]
1000ca5b8:     	and	x9, x10, #0xf
1000ca5bc:     	ubfx	x8, x10, #8, #4
1000ca5c0:     	stp	x8, x9, [sp, #32]
1000ca5c4:     	ubfx	x8, x10, #16, #4
1000ca5c8:     	str	x8, [sp, #24]
1000ca5cc:     	ubfx	x28, x10, #24, #4
1000ca5d0:     	ubfx	x30, x10, #4, #4
1000ca5d4:     	ubfx	x8, x10, #12, #4
1000ca5d8:     	ubfx	x3, x10, #20, #4
1000ca5dc:     	lsr	x9, x10, #28
1000ca5e0:     	and	x1, x17, #0xf
1000ca5e4:     	ubfx	x10, x17, #8, #4
1000ca5e8:     	ubfx	x13, x17, #16, #4
1000ca5ec:     	ubfx	x26, x17, #24, #4
1000ca5f0:     	ubfx	x14, x17, #4, #4
1000ca5f4:     	ubfx	x15, x17, #12, #4
1000ca5f8:     	ubfx	x16, x17, #20, #4
1000ca5fc:     	lsr	x17, x17, #28
1000ca600:     	ldr	w20, [x0, x12]
1000ca604:     	lsl	w2, w20, #4
1000ca608:     	and	x2, x2, #0xf0
1000ca60c:     	add	x5, x11, x2
1000ca610:     	and	x2, x20, #0xf0
1000ca614:     	add	x2, x11, x2
1000ca618:     	lsr	x4, x20, #4
1000ca61c:     	and	x4, x4, #0xf0
1000ca620:     	add	x7, x11, x4
1000ca624:     	lsr	x4, x20, #8
1000ca628:     	and	x4, x4, #0xf0
1000ca62c:     	add	x4, x11, x4
1000ca630:     	lsr	x6, x20, #12
1000ca634:     	and	x6, x6, #0xf0
1000ca638:     	add	x19, x11, x6
1000ca63c:     	lsr	x6, x20, #16
1000ca640:     	and	x6, x6, #0xf0
1000ca644:     	add	x6, x11, x6
1000ca648:     	lsr	x21, x20, #20
1000ca64c:     	and	x21, x21, #0xf0
1000ca650:     	add	x21, x11, x21
1000ca654:     	lsr	x20, x20, #24
1000ca658:     	and	x20, x20, #0xf0
1000ca65c:     	ldr	x22, [sp, #144]
1000ca660:     	ldrsb	w22, [x5, x22]
1000ca664:     	add	x20, x11, x20
1000ca668:     	ldp	x24, x23, [sp, #160]
1000ca66c:     	ldrsb	w23, [x7, x23]
1000ca670:     	ldrsb	w24, [x19, x24]
1000ca674:     	add	w22, w22, w23
1000ca678:     	add	w22, w22, w24
1000ca67c:     	ldr	x23, [sp, #152]
1000ca680:     	ldrsb	w23, [x21, x23]
1000ca684:     	ldr	x24, [sp, #136]
1000ca688:     	ldrsb	w24, [x2, x24]
1000ca68c:     	add	w22, w22, w23
1000ca690:     	add	w22, w22, w24
1000ca694:     	ldp	x24, x23, [sp, #120]
1000ca698:     	ldrsb	w23, [x4, x23]
1000ca69c:     	ldrsb	w24, [x6, x24]
1000ca6a0:     	add	w22, w22, w23
1000ca6a4:     	add	w22, w22, w24
1000ca6a8:     	ldr	x23, [sp, #112]
1000ca6ac:     	ldrsb	w23, [x20, x23]
1000ca6b0:     	add	w22, w22, w23
1000ca6b4:     	scvtf	s0, w22
1000ca6b8:     	ldp	x23, x22, [sp, #96]
1000ca6bc:     	ldrsb	w22, [x5, x22]
1000ca6c0:     	ldrsb	w23, [x7, x23]
1000ca6c4:     	ldp	x25, x24, [sp, #80]
1000ca6c8:     	ldrsb	w24, [x19, x24]
1000ca6cc:     	ldrsb	w25, [x21, x25]
1000ca6d0:     	add	w22, w22, w23
1000ca6d4:     	ldr	x23, [sp, #72]
1000ca6d8:     	ldrsb	w23, [x2, x23]
1000ca6dc:     	add	w22, w22, w24
1000ca6e0:     	ldr	x24, [sp, #64]
1000ca6e4:     	ldrsb	w24, [x4, x24]
1000ca6e8:     	add	w22, w22, w25
1000ca6ec:     	ldr	x25, [sp, #56]
1000ca6f0:     	ldrsb	w25, [x6, x25]
1000ca6f4:     	add	w22, w22, w23
1000ca6f8:     	add	w22, w22, w24
1000ca6fc:     	add	w22, w22, w25
1000ca700:     	ldr	x23, [sp, #48]
1000ca704:     	ldrsb	w23, [x20, x23]
1000ca708:     	add	w22, w22, w23
1000ca70c:     	scvtf	s1, w22
1000ca710:     	ldp	x23, x22, [sp, #32]
1000ca714:     	ldrsb	w22, [x5, x22]
1000ca718:     	ldrsb	w23, [x7, x23]
1000ca71c:     	ldr	x24, [sp, #24]
1000ca720:     	ldrsb	w24, [x19, x24]
1000ca724:     	add	w22, w22, w23
1000ca728:     	ldrsb	w23, [x21, x28]
1000ca72c:     	add	w22, w22, w24
1000ca730:     	ldrsb	w24, [x2, x30]
1000ca734:     	add	w22, w22, w23
1000ca738:     	ldrsb	w23, [x4, x8]
1000ca73c:     	add	w22, w22, w24
1000ca740:     	ldrsb	w24, [x6, x3]
1000ca744:     	add	w22, w22, w23
1000ca748:     	ldrsb	w23, [x20, x9]
1000ca74c:     	add	w22, w22, w24
1000ca750:     	add	w22, w22, w23
1000ca754:     	scvtf	s2, w22
1000ca758:     	ldrsb	w5, [x5, x1]
1000ca75c:     	ldrsb	w7, [x7, x10]
1000ca760:     	ldrsb	w19, [x19, x13]
1000ca764:     	add	w5, w5, w7
1000ca768:     	add	w5, w5, w19
1000ca76c:     	ldrsb	w7, [x21, x26]
1000ca770:     	ldrsb	w2, [x2, x14]
1000ca774:     	add	w5, w5, w7
1000ca778:     	add	w2, w5, w2
1000ca77c:     	ldrsb	w4, [x4, x15]
1000ca780:     	ldrsb	w5, [x6, x16]
1000ca784:     	add	w2, w2, w4
1000ca788:     	add	w2, w2, w5
1000ca78c:     	ldrsb	w4, [x20, x17]
1000ca790:     	add	w2, w2, w4
1000ca794:     	add	x4, sp, #176
1000ca798:     	scvtf	s3, w2
1000ca79c:     	add	x2, x27, x12
1000ca7a0:     	ldur	s4, [x2, #-64]
1000ca7a4:     	fadd	s1, s4, s1
1000ca7a8:     	stur	s1, [x2, #-64]
1000ca7ac:     	ldr	s1, [x2]
1000ca7b0:     	fadd	s1, s1, s2
1000ca7b4:     	str	s1, [x2]
1000ca7b8:     	ldr	s1, [x2, #64]
1000ca7bc:     	fadd	s1, s1, s3
1000ca7c0:     	ldr	s2, [x4, x12]
1000ca7c4:     	str	s1, [x2, #64]
1000ca7c8:     	fadd	s0, s2, s0
1000ca7cc:     	str	s0, [x4, x12]
1000ca7d0:     	add	x12, x12, #4
1000ca7d4:     	cmp	x12, #64
1000ca7d8:     	b.ne	0x1000ca600 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ca7dc:     	add	x0, x0, #64
1000ca7e0:     	ldp	x8, x1, [sp, #8]
1000ca7e4:     	add	x1, x1, #16
1000ca7e8:     	cmp	x1, x8
1000ca7ec:     	b.ne	0x1000ca530 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000ca7f0:     	ldp	q0, q1, [sp, #368]
1000ca7f4:     	ldr	x8, [sp]
1000ca7f8:     	stp	q0, q1, [x8, #192]
1000ca7fc:     	ldp	q0, q1, [sp, #400]
1000ca800:     	stp	q0, q1, [x8, #224]
1000ca804:     	ldp	q0, q1, [sp, #304]
1000ca808:     	stp	q0, q1, [x8, #128]
1000ca80c:     	ldp	q0, q1, [sp, #336]
1000ca810:     	stp	q0, q1, [x8, #160]
1000ca814:     	ldp	q0, q1, [sp, #240]
1000ca818:     	stp	q0, q1, [x8, #64]
1000ca81c:     	ldp	q0, q1, [sp, #272]
1000ca820:     	stp	q0, q1, [x8, #96]
1000ca824:     	ldp	q0, q1, [sp, #176]
1000ca828:     	stp	q0, q1, [x8]
1000ca82c:     	ldp	q0, q1, [sp, #208]
1000ca830:     	stp	q0, q1, [x8, #32]
1000ca834:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 8ul, false>(char const*)+0x24c>
1000ca838:     	ldr	x8, [x8, #392]
1000ca83c:     	ldr	x8, [x8]
1000ca840:     	ldur	x9, [x29, #-96]
1000ca844:     	cmp	x8, x9
1000ca848:     	b.ne	0x1000ca86c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000ca84c:     	add	sp, sp, #448
1000ca850:     	ldp	x29, x30, [sp, #80]
1000ca854:     	ldp	x20, x19, [sp, #64]
1000ca858:     	ldp	x22, x21, [sp, #48]
1000ca85c:     	ldp	x24, x23, [sp, #32]
1000ca860:     	ldp	x26, x25, [sp, #16]
1000ca864:     	ldp	x28, x27, [sp], #96
1000ca868:     	ret
1000ca86c:     	bl	0x100163694 <_strcmp+0x100163694>

