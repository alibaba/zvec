00000001000bf020 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bf020:     	stp	x24, x23, [sp, #-48]!
1000bf024:     	stp	x22, x21, [sp, #16]
1000bf028:     	stp	x20, x19, [sp, #32]
1000bf02c:     	movi.2d	v0, #0000000000000000
1000bf030:     	stp	q0, q0, [x3]
1000bf034:     	lsl	x8, x4, #2
1000bf038:     	cmp	x2, #8
1000bf03c:     	b.hs	0x1000bf048 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bf040:     	mov	x13, #0
1000bf044:     	b	0x1000bf448 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bf048:     	mov	x10, #0
1000bf04c:     	add	x9, x0, #16
1000bf050:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bf054:     	add	x11, x11, #700
1000bf058:     	mov	x12, x1
1000bf05c:     	ldr	w5, [x12]
1000bf060:     	lsr	x13, x5, #24
1000bf064:     	and	x13, x13, #0xf0
1000bf068:     	lsr	x14, x5, #20
1000bf06c:     	and	x14, x14, #0xf0
1000bf070:     	add	x13, x11, x13
1000bf074:     	add	x14, x11, x14
1000bf078:     	lsr	x15, x5, #16
1000bf07c:     	and	x15, x15, #0xf0
1000bf080:     	lsr	x16, x5, #12
1000bf084:     	and	x6, x16, #0xf0
1000bf088:     	add	x15, x11, x15
1000bf08c:     	lsr	x16, x5, #8
1000bf090:     	and	x16, x16, #0xf0
1000bf094:     	add	x16, x11, x16
1000bf098:     	lsr	x17, x5, #4
1000bf09c:     	and	x17, x17, #0xf0
1000bf0a0:     	add	x17, x11, x17
1000bf0a4:     	and	x4, x5, #0xf0
1000bf0a8:     	add	x4, x11, x4
1000bf0ac:     	lsl	w5, w5, #4
1000bf0b0:     	and	x5, x5, #0xf0
1000bf0b4:     	ldur	w7, [x9, #-16]
1000bf0b8:     	add	x5, x11, x5
1000bf0bc:     	and	x19, x7, #0xf
1000bf0c0:     	ubfx	x20, x7, #4, #4
1000bf0c4:     	ldrb	w20, [x4, x20]
1000bf0c8:     	ldrb	w19, [x5, x19]
1000bf0cc:     	ubfx	x21, x7, #8, #4
1000bf0d0:     	ldrb	w21, [x17, x21]
1000bf0d4:     	ubfx	x22, x7, #12, #4
1000bf0d8:     	ldrb	w22, [x16, x22]
1000bf0dc:     	add	x6, x11, x6
1000bf0e0:     	ubfx	x23, x7, #16, #4
1000bf0e4:     	ldrb	w23, [x6, x23]
1000bf0e8:     	add	w19, w19, w20
1000bf0ec:     	add	w19, w19, w21
1000bf0f0:     	ubfx	x20, x7, #20, #4
1000bf0f4:     	ldrb	w20, [x15, x20]
1000bf0f8:     	ubfx	x21, x7, #24, #4
1000bf0fc:     	add	w19, w19, w22
1000bf100:     	add	w19, w19, w23
1000bf104:     	ldrb	w21, [x14, x21]
1000bf108:     	lsr	x7, x7, #28
1000bf10c:     	ldrb	w7, [x13, x7]
1000bf110:     	add	w19, w19, w20
1000bf114:     	add	w19, w19, w21
1000bf118:     	add	w7, w19, w7
1000bf11c:     	scvtf	s0, w7
1000bf120:     	ldp	s1, s2, [x3]
1000bf124:     	fadd	s0, s1, s0
1000bf128:     	str	s0, [x3]
1000bf12c:     	ldur	w7, [x9, #-12]
1000bf130:     	and	x19, x7, #0xf
1000bf134:     	ldrb	w19, [x5, x19]
1000bf138:     	ubfx	x20, x7, #4, #4
1000bf13c:     	ldrb	w20, [x4, x20]
1000bf140:     	ubfx	x21, x7, #8, #4
1000bf144:     	ldrb	w21, [x17, x21]
1000bf148:     	ubfx	x22, x7, #12, #4
1000bf14c:     	ldrb	w22, [x16, x22]
1000bf150:     	ubfx	x23, x7, #16, #4
1000bf154:     	add	w19, w19, w20
1000bf158:     	add	w19, w19, w21
1000bf15c:     	ldrb	w20, [x6, x23]
1000bf160:     	ubfx	x21, x7, #20, #4
1000bf164:     	ldrb	w21, [x15, x21]
1000bf168:     	add	w19, w19, w22
1000bf16c:     	add	w19, w19, w20
1000bf170:     	ubfx	x20, x7, #24, #4
1000bf174:     	ldrb	w20, [x14, x20]
1000bf178:     	add	w19, w19, w21
1000bf17c:     	add	w19, w19, w20
1000bf180:     	lsr	x7, x7, #28
1000bf184:     	ldrb	w7, [x13, x7]
1000bf188:     	add	w7, w19, w7
1000bf18c:     	scvtf	s0, w7
1000bf190:     	fadd	s0, s2, s0
1000bf194:     	str	s0, [x3, #4]
1000bf198:     	ldur	w7, [x9, #-8]
1000bf19c:     	and	x19, x7, #0xf
1000bf1a0:     	ldrb	w19, [x5, x19]
1000bf1a4:     	ubfx	x20, x7, #4, #4
1000bf1a8:     	ldrb	w20, [x4, x20]
1000bf1ac:     	ubfx	x21, x7, #8, #4
1000bf1b0:     	ldrb	w21, [x17, x21]
1000bf1b4:     	ubfx	x22, x7, #12, #4
1000bf1b8:     	ldrb	w22, [x16, x22]
1000bf1bc:     	ubfx	x23, x7, #16, #4
1000bf1c0:     	add	w19, w19, w20
1000bf1c4:     	add	w19, w19, w21
1000bf1c8:     	ldrb	w20, [x6, x23]
1000bf1cc:     	ubfx	x21, x7, #20, #4
1000bf1d0:     	ldrb	w21, [x15, x21]
1000bf1d4:     	add	w19, w19, w22
1000bf1d8:     	add	w19, w19, w20
1000bf1dc:     	ubfx	x20, x7, #24, #4
1000bf1e0:     	ldrb	w20, [x14, x20]
1000bf1e4:     	add	w19, w19, w21
1000bf1e8:     	add	w19, w19, w20
1000bf1ec:     	lsr	x7, x7, #28
1000bf1f0:     	ldrb	w7, [x13, x7]
1000bf1f4:     	add	w7, w19, w7
1000bf1f8:     	scvtf	s0, w7
1000bf1fc:     	ldp	s1, s2, [x3, #8]
1000bf200:     	fadd	s0, s1, s0
1000bf204:     	str	s0, [x3, #8]
1000bf208:     	ldur	w7, [x9, #-4]
1000bf20c:     	and	x19, x7, #0xf
1000bf210:     	ldrb	w19, [x5, x19]
1000bf214:     	ubfx	x20, x7, #4, #4
1000bf218:     	ldrb	w20, [x4, x20]
1000bf21c:     	ubfx	x21, x7, #8, #4
1000bf220:     	ldrb	w21, [x17, x21]
1000bf224:     	ubfx	x22, x7, #12, #4
1000bf228:     	ldrb	w22, [x16, x22]
1000bf22c:     	ubfx	x23, x7, #16, #4
1000bf230:     	ldrb	w23, [x6, x23]
1000bf234:     	ubfx	x24, x7, #20, #4
1000bf238:     	add	w19, w19, w20
1000bf23c:     	add	w19, w19, w21
1000bf240:     	ldrb	w20, [x15, x24]
1000bf244:     	ubfx	x21, x7, #24, #4
1000bf248:     	ldrb	w21, [x14, x21]
1000bf24c:     	add	w19, w19, w22
1000bf250:     	add	w19, w19, w23
1000bf254:     	lsr	x7, x7, #28
1000bf258:     	ldrb	w7, [x13, x7]
1000bf25c:     	add	w19, w19, w20
1000bf260:     	add	w19, w19, w21
1000bf264:     	add	w7, w19, w7
1000bf268:     	scvtf	s0, w7
1000bf26c:     	fadd	s0, s2, s0
1000bf270:     	str	s0, [x3, #12]
1000bf274:     	ldr	w7, [x9]
1000bf278:     	and	x19, x7, #0xf
1000bf27c:     	ldrb	w19, [x5, x19]
1000bf280:     	ubfx	x20, x7, #4, #4
1000bf284:     	ldrb	w20, [x4, x20]
1000bf288:     	ubfx	x21, x7, #8, #4
1000bf28c:     	ldrb	w21, [x17, x21]
1000bf290:     	ubfx	x22, x7, #12, #4
1000bf294:     	ldrb	w22, [x16, x22]
1000bf298:     	ubfx	x23, x7, #16, #4
1000bf29c:     	ldrb	w23, [x6, x23]
1000bf2a0:     	add	w19, w19, w20
1000bf2a4:     	add	w19, w19, w21
1000bf2a8:     	ubfx	x20, x7, #20, #4
1000bf2ac:     	ldrb	w20, [x15, x20]
1000bf2b0:     	ubfx	x21, x7, #24, #4
1000bf2b4:     	add	w19, w19, w22
1000bf2b8:     	add	w19, w19, w23
1000bf2bc:     	ldrb	w21, [x14, x21]
1000bf2c0:     	lsr	x7, x7, #28
1000bf2c4:     	ldrb	w7, [x13, x7]
1000bf2c8:     	add	w19, w19, w20
1000bf2cc:     	add	w19, w19, w21
1000bf2d0:     	add	w7, w19, w7
1000bf2d4:     	scvtf	s0, w7
1000bf2d8:     	ldp	s1, s2, [x3, #16]
1000bf2dc:     	fadd	s0, s1, s0
1000bf2e0:     	str	s0, [x3, #16]
1000bf2e4:     	ldr	w7, [x9, #4]
1000bf2e8:     	and	x19, x7, #0xf
1000bf2ec:     	ldrb	w19, [x5, x19]
1000bf2f0:     	ubfx	x20, x7, #4, #4
1000bf2f4:     	ldrb	w20, [x4, x20]
1000bf2f8:     	ubfx	x21, x7, #8, #4
1000bf2fc:     	ldrb	w21, [x17, x21]
1000bf300:     	ubfx	x22, x7, #12, #4
1000bf304:     	ldrb	w22, [x16, x22]
1000bf308:     	ubfx	x23, x7, #16, #4
1000bf30c:     	add	w19, w19, w20
1000bf310:     	add	w19, w19, w21
1000bf314:     	ldrb	w20, [x6, x23]
1000bf318:     	ubfx	x21, x7, #20, #4
1000bf31c:     	ldrb	w21, [x15, x21]
1000bf320:     	add	w19, w19, w22
1000bf324:     	add	w19, w19, w20
1000bf328:     	ubfx	x20, x7, #24, #4
1000bf32c:     	ldrb	w20, [x14, x20]
1000bf330:     	add	w19, w19, w21
1000bf334:     	add	w19, w19, w20
1000bf338:     	lsr	x7, x7, #28
1000bf33c:     	ldrb	w7, [x13, x7]
1000bf340:     	add	w7, w19, w7
1000bf344:     	scvtf	s0, w7
1000bf348:     	fadd	s0, s2, s0
1000bf34c:     	str	s0, [x3, #20]
1000bf350:     	ldr	w7, [x9, #8]
1000bf354:     	and	x19, x7, #0xf
1000bf358:     	ldrb	w19, [x5, x19]
1000bf35c:     	ubfx	x20, x7, #4, #4
1000bf360:     	ldrb	w20, [x4, x20]
1000bf364:     	ubfx	x21, x7, #8, #4
1000bf368:     	ldrb	w21, [x17, x21]
1000bf36c:     	ubfx	x22, x7, #12, #4
1000bf370:     	ldrb	w22, [x16, x22]
1000bf374:     	ubfx	x23, x7, #16, #4
1000bf378:     	add	w19, w19, w20
1000bf37c:     	add	w19, w19, w21
1000bf380:     	ldrb	w20, [x6, x23]
1000bf384:     	ubfx	x21, x7, #20, #4
1000bf388:     	ldrb	w21, [x15, x21]
1000bf38c:     	add	w19, w19, w22
1000bf390:     	add	w19, w19, w20
1000bf394:     	ubfx	x20, x7, #24, #4
1000bf398:     	ldrb	w20, [x14, x20]
1000bf39c:     	add	w19, w19, w21
1000bf3a0:     	add	w19, w19, w20
1000bf3a4:     	lsr	x7, x7, #28
1000bf3a8:     	ldrb	w7, [x13, x7]
1000bf3ac:     	add	w7, w19, w7
1000bf3b0:     	scvtf	s0, w7
1000bf3b4:     	ldp	s1, s2, [x3, #24]
1000bf3b8:     	fadd	s0, s1, s0
1000bf3bc:     	str	s0, [x3, #24]
1000bf3c0:     	ldr	w7, [x9, #12]
1000bf3c4:     	and	x19, x7, #0xf
1000bf3c8:     	ldrb	w5, [x5, x19]
1000bf3cc:     	ubfx	x19, x7, #4, #4
1000bf3d0:     	ldrb	w4, [x4, x19]
1000bf3d4:     	ubfx	x19, x7, #8, #4
1000bf3d8:     	ldrb	w17, [x17, x19]
1000bf3dc:     	ubfx	x19, x7, #12, #4
1000bf3e0:     	ldrb	w16, [x16, x19]
1000bf3e4:     	ubfx	x19, x7, #16, #4
1000bf3e8:     	ldrb	w6, [x6, x19]
1000bf3ec:     	add	w4, w5, w4
1000bf3f0:     	add	w17, w4, w17
1000bf3f4:     	ubfx	x4, x7, #20, #4
1000bf3f8:     	ldrb	w15, [x15, x4]
1000bf3fc:     	ubfx	x4, x7, #24, #4
1000bf400:     	add	w16, w17, w16
1000bf404:     	add	w16, w16, w6
1000bf408:     	ldrb	w14, [x14, x4]
1000bf40c:     	lsr	x17, x7, #28
1000bf410:     	ldrb	w13, [x13, x17]
1000bf414:     	add	w15, w16, w15
1000bf418:     	add	w14, w15, w14
1000bf41c:     	add	w13, w14, w13
1000bf420:     	scvtf	s0, w13
1000bf424:     	fadd	s0, s2, s0
1000bf428:     	str	s0, [x3, #28]
1000bf42c:     	add	x13, x10, #8
1000bf430:     	add	x12, x12, x8
1000bf434:     	add	x14, x10, #16
1000bf438:     	add	x9, x9, #32
1000bf43c:     	mov	x10, x13
1000bf440:     	cmp	x14, x2
1000bf444:     	b.ls	0x1000bf05c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000bf448:     	cmp	x13, x2
1000bf44c:     	b.hs	0x1000bf600 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5e0>
1000bf450:     	ldp	s0, s1, [x3, #8]
1000bf454:     	lsl	x9, x13, #2
1000bf458:     	mov	w10, #-16
1000bf45c:     	ldr	s2, [x3, #16]
1000bf460:     	lsr	x11, x13, #3
1000bf464:     	mul	x12, x8, x11
1000bf468:     	ubfx	x11, x13, #1, #2
1000bf46c:     	orr	x12, x12, x11
1000bf470:     	ldrb	w14, [x1, x12]
1000bf474:     	and	w12, w9, #0x4
1000bf478:     	lsr	w14, w14, w12
1000bf47c:     	and	w15, w14, #0xf
1000bf480:     	cmp	w15, #8
1000bf484:     	csel	w15, wzr, w10, lo
1000bf488:     	and	x16, x9, #0xffffffffffffffe0
1000bf48c:     	bfxil	x16, x13, #1, #2
1000bf490:     	bfxil	w15, w14, #0, #4
1000bf494:     	add	x14, x0, x16
1000bf498:     	ldrb	w16, [x14]
1000bf49c:     	lsr	w16, w16, w12
1000bf4a0:     	and	w17, w16, #0xf
1000bf4a4:     	scvtf	s3, w15
1000bf4a8:     	cmp	w17, #8
1000bf4ac:     	csel	w15, wzr, w10, lo
1000bf4b0:     	bfxil	w15, w16, #0, #4
1000bf4b4:     	scvtf	s4, w15
1000bf4b8:     	fsub	s4, s4, s3
1000bf4bc:     	ldp	s5, s6, [x3]
1000bf4c0:     	fmadd	s4, s4, s4, s5
1000bf4c4:     	str	s4, [x3]
1000bf4c8:     	ldrb	w15, [x14, #4]
1000bf4cc:     	lsr	w15, w15, w12
1000bf4d0:     	and	w16, w15, #0xf
1000bf4d4:     	cmp	w16, #8
1000bf4d8:     	csel	w16, wzr, w10, lo
1000bf4dc:     	bfxil	w16, w15, #0, #4
1000bf4e0:     	scvtf	s4, w16
1000bf4e4:     	fsub	s4, s4, s3
1000bf4e8:     	fmadd	s4, s4, s4, s6
1000bf4ec:     	str	s4, [x3, #4]
1000bf4f0:     	ldrb	w15, [x14, #8]
1000bf4f4:     	lsr	w15, w15, w12
1000bf4f8:     	and	w16, w15, #0xf
1000bf4fc:     	cmp	w16, #8
1000bf500:     	csel	w16, wzr, w10, lo
1000bf504:     	bfxil	w16, w15, #0, #4
1000bf508:     	scvtf	s4, w16
1000bf50c:     	fsub	s4, s4, s3
1000bf510:     	fmadd	s0, s4, s4, s0
1000bf514:     	str	s0, [x3, #8]
1000bf518:     	ldrb	w15, [x14, #12]
1000bf51c:     	lsr	w15, w15, w12
1000bf520:     	and	w16, w15, #0xf
1000bf524:     	cmp	w16, #8
1000bf528:     	csel	w16, wzr, w10, lo
1000bf52c:     	bfxil	w16, w15, #0, #4
1000bf530:     	scvtf	s4, w16
1000bf534:     	fsub	s4, s4, s3
1000bf538:     	fmadd	s1, s4, s4, s1
1000bf53c:     	str	s1, [x3, #12]
1000bf540:     	ldrb	w15, [x14, #16]
1000bf544:     	lsr	w15, w15, w12
1000bf548:     	and	w16, w15, #0xf
1000bf54c:     	cmp	w16, #8
1000bf550:     	csel	w16, wzr, w10, lo
1000bf554:     	bfxil	w16, w15, #0, #4
1000bf558:     	scvtf	s4, w16
1000bf55c:     	fsub	s4, s4, s3
1000bf560:     	fmadd	s2, s4, s4, s2
1000bf564:     	str	s2, [x3, #16]
1000bf568:     	ldrb	w15, [x14, #20]
1000bf56c:     	lsr	w15, w15, w12
1000bf570:     	and	w16, w15, #0xf
1000bf574:     	cmp	w16, #8
1000bf578:     	csel	w16, wzr, w10, lo
1000bf57c:     	bfxil	w16, w15, #0, #4
1000bf580:     	scvtf	s4, w16
1000bf584:     	fsub	s4, s4, s3
1000bf588:     	ldp	s5, s6, [x3, #20]
1000bf58c:     	fmadd	s4, s4, s4, s5
1000bf590:     	str	s4, [x3, #20]
1000bf594:     	ldrb	w14, [x14, #24]
1000bf598:     	lsr	w14, w14, w12
1000bf59c:     	and	w15, w14, #0xf
1000bf5a0:     	cmp	w15, #8
1000bf5a4:     	csel	w15, wzr, w10, lo
1000bf5a8:     	bfxil	w15, w14, #0, #4
1000bf5ac:     	scvtf	s4, w15
1000bf5b0:     	fsub	s4, s4, s3
1000bf5b4:     	fmadd	s4, s4, s4, s6
1000bf5b8:     	str	s4, [x3, #24]
1000bf5bc:     	orr	x11, x9, x11
1000bf5c0:     	orr	x11, x11, #0x1c
1000bf5c4:     	ldrb	w11, [x0, x11]
1000bf5c8:     	lsr	w11, w11, w12
1000bf5cc:     	and	w12, w11, #0xf
1000bf5d0:     	cmp	w12, #8
1000bf5d4:     	csel	w12, wzr, w10, lo
1000bf5d8:     	bfxil	w12, w11, #0, #4
1000bf5dc:     	scvtf	s4, w12
1000bf5e0:     	fsub	s3, s4, s3
1000bf5e4:     	ldr	s4, [x3, #28]
1000bf5e8:     	fmadd	s3, s3, s3, s4
1000bf5ec:     	str	s3, [x3, #28]
1000bf5f0:     	add	x13, x13, #1
1000bf5f4:     	add	x9, x9, #4
1000bf5f8:     	cmp	x2, x13
1000bf5fc:     	b.ne	0x1000bf460 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000bf600:     	ldp	x20, x19, [sp, #32]
1000bf604:     	ldp	x22, x21, [sp, #16]
1000bf608:     	ldp	x24, x23, [sp], #48
1000bf60c:     	ret

