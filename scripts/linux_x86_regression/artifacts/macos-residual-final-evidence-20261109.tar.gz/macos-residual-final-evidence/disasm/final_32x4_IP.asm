00000001000d386c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d386c:     	stp	x28, x27, [sp, #-96]!
1000d3870:     	stp	x26, x25, [sp, #16]
1000d3874:     	stp	x24, x23, [sp, #32]
1000d3878:     	stp	x22, x21, [sp, #48]
1000d387c:     	stp	x20, x19, [sp, #64]
1000d3880:     	stp	x29, x30, [sp, #80]
1000d3884:     	add	x29, sp, #80
1000d3888:     	sub	sp, sp, #704
1000d388c:     	str	x3, [sp]
1000d3890:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d3894:     	ldr	x8, [x8, #392]
1000d3898:     	ldr	x8, [x8]
1000d389c:     	stur	x8, [x29, #-96]
1000d38a0:     	movi.2d	v0, #0000000000000000
1000d38a4:     	stp	q0, q0, [sp, #656]
1000d38a8:     	lsl	x8, x2, #1
1000d38ac:     	stp	q0, q0, [sp, #624]
1000d38b0:     	stp	q0, q0, [sp, #592]
1000d38b4:     	stp	q0, q0, [sp, #560]
1000d38b8:     	stp	q0, q0, [sp, #528]
1000d38bc:     	stp	q0, q0, [sp, #496]
1000d38c0:     	stp	q0, q0, [sp, #464]
1000d38c4:     	stp	q0, q0, [sp, #432]
1000d38c8:     	stp	q0, q0, [sp, #400]
1000d38cc:     	stp	q0, q0, [sp, #368]
1000d38d0:     	stp	q0, q0, [sp, #336]
1000d38d4:     	stp	q0, q0, [sp, #304]
1000d38d8:     	stp	q0, q0, [sp, #272]
1000d38dc:     	stp	q0, q0, [sp, #240]
1000d38e0:     	stp	q0, q0, [sp, #208]
1000d38e4:     	stp	q0, q0, [sp, #176]
1000d38e8:     	ands	x8, x8, #0xfffffffffffffffc
1000d38ec:     	b.eq	0x1000d3bc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d38f0:     	add	x8, x1, x8
1000d38f4:     	str	x8, [sp, #8]
1000d38f8:     	add	x8, sp, #176
1000d38fc:     	add	x27, x8, #256
1000d3900:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d3904:     	add	x11, x11, #1980
1000d3908:     	mov	x12, #0
1000d390c:     	ldp	w8, w9, [x1]
1000d3910:     	ubfx	x10, x8, #8, #4
1000d3914:     	str	x10, [sp, #168]
1000d3918:     	ubfx	x10, x8, #16, #4
1000d391c:     	str	x10, [sp, #160]
1000d3920:     	ubfx	x10, x8, #24, #4
1000d3924:     	str	x10, [sp, #152]
1000d3928:     	ldp	w10, w17, [x1, #8]
1000d392c:     	str	x1, [sp, #16]
1000d3930:     	and	x14, x8, #0xf
1000d3934:     	ubfx	x13, x8, #4, #4
1000d3938:     	stp	x13, x14, [sp, #136]
1000d393c:     	ubfx	x14, x8, #12, #4
1000d3940:     	ubfx	x13, x8, #20, #4
1000d3944:     	stp	x13, x14, [sp, #120]
1000d3948:     	lsr	x8, x8, #28
1000d394c:     	str	x8, [sp, #112]
1000d3950:     	and	x8, x9, #0xf
1000d3954:     	str	x8, [sp, #104]
1000d3958:     	ubfx	x8, x9, #8, #4
1000d395c:     	str	x8, [sp, #96]
1000d3960:     	ubfx	x8, x9, #16, #4
1000d3964:     	str	x8, [sp, #88]
1000d3968:     	ubfx	x8, x9, #24, #4
1000d396c:     	str	x8, [sp, #80]
1000d3970:     	ubfx	x8, x9, #4, #4
1000d3974:     	str	x8, [sp, #72]
1000d3978:     	ubfx	x8, x9, #12, #4
1000d397c:     	str	x8, [sp, #64]
1000d3980:     	ubfx	x8, x9, #20, #4
1000d3984:     	str	x8, [sp, #56]
1000d3988:     	lsr	x8, x9, #28
1000d398c:     	str	x8, [sp, #48]
1000d3990:     	and	x9, x10, #0xf
1000d3994:     	ubfx	x8, x10, #8, #4
1000d3998:     	stp	x8, x9, [sp, #32]
1000d399c:     	ubfx	x8, x10, #16, #4
1000d39a0:     	str	x8, [sp, #24]
1000d39a4:     	ubfx	x28, x10, #24, #4
1000d39a8:     	ubfx	x30, x10, #4, #4
1000d39ac:     	ubfx	x3, x10, #12, #4
1000d39b0:     	ubfx	x8, x10, #20, #4
1000d39b4:     	lsr	x9, x10, #28
1000d39b8:     	and	x1, x17, #0xf
1000d39bc:     	ubfx	x10, x17, #8, #4
1000d39c0:     	ubfx	x13, x17, #16, #4
1000d39c4:     	ubfx	x26, x17, #24, #4
1000d39c8:     	ubfx	x14, x17, #4, #4
1000d39cc:     	ubfx	x15, x17, #12, #4
1000d39d0:     	ubfx	x16, x17, #20, #4
1000d39d4:     	lsr	x17, x17, #28
1000d39d8:     	ldr	w20, [x0, x12]
1000d39dc:     	lsl	w2, w20, #4
1000d39e0:     	and	x2, x2, #0xf0
1000d39e4:     	add	x5, x11, x2
1000d39e8:     	and	x2, x20, #0xf0
1000d39ec:     	add	x2, x11, x2
1000d39f0:     	lsr	x4, x20, #4
1000d39f4:     	and	x4, x4, #0xf0
1000d39f8:     	add	x7, x11, x4
1000d39fc:     	lsr	x4, x20, #8
1000d3a00:     	and	x4, x4, #0xf0
1000d3a04:     	add	x4, x11, x4
1000d3a08:     	lsr	x6, x20, #12
1000d3a0c:     	and	x6, x6, #0xf0
1000d3a10:     	add	x19, x11, x6
1000d3a14:     	lsr	x6, x20, #16
1000d3a18:     	and	x6, x6, #0xf0
1000d3a1c:     	add	x6, x11, x6
1000d3a20:     	lsr	x21, x20, #20
1000d3a24:     	and	x21, x21, #0xf0
1000d3a28:     	add	x21, x11, x21
1000d3a2c:     	lsr	x20, x20, #24
1000d3a30:     	and	x20, x20, #0xf0
1000d3a34:     	ldr	x22, [sp, #144]
1000d3a38:     	ldrsb	w22, [x5, x22]
1000d3a3c:     	add	x20, x11, x20
1000d3a40:     	ldp	x24, x23, [sp, #160]
1000d3a44:     	ldrsb	w23, [x7, x23]
1000d3a48:     	ldrsb	w24, [x19, x24]
1000d3a4c:     	add	w22, w22, w23
1000d3a50:     	add	w22, w22, w24
1000d3a54:     	ldr	x23, [sp, #152]
1000d3a58:     	ldrsb	w23, [x21, x23]
1000d3a5c:     	ldr	x24, [sp, #136]
1000d3a60:     	ldrsb	w24, [x2, x24]
1000d3a64:     	add	w22, w22, w23
1000d3a68:     	add	w22, w22, w24
1000d3a6c:     	ldp	x24, x23, [sp, #120]
1000d3a70:     	ldrsb	w23, [x4, x23]
1000d3a74:     	ldrsb	w24, [x6, x24]
1000d3a78:     	add	w22, w22, w23
1000d3a7c:     	add	w22, w22, w24
1000d3a80:     	ldr	x23, [sp, #112]
1000d3a84:     	ldrsb	w23, [x20, x23]
1000d3a88:     	add	w22, w22, w23
1000d3a8c:     	scvtf	s0, w22
1000d3a90:     	ldp	x23, x22, [sp, #96]
1000d3a94:     	ldrsb	w22, [x5, x22]
1000d3a98:     	ldrsb	w23, [x7, x23]
1000d3a9c:     	ldp	x25, x24, [sp, #80]
1000d3aa0:     	ldrsb	w24, [x19, x24]
1000d3aa4:     	ldrsb	w25, [x21, x25]
1000d3aa8:     	add	w22, w22, w23
1000d3aac:     	ldr	x23, [sp, #72]
1000d3ab0:     	ldrsb	w23, [x2, x23]
1000d3ab4:     	add	w22, w22, w24
1000d3ab8:     	ldr	x24, [sp, #64]
1000d3abc:     	ldrsb	w24, [x4, x24]
1000d3ac0:     	add	w22, w22, w25
1000d3ac4:     	ldr	x25, [sp, #56]
1000d3ac8:     	ldrsb	w25, [x6, x25]
1000d3acc:     	add	w22, w22, w23
1000d3ad0:     	add	w22, w22, w24
1000d3ad4:     	add	w22, w22, w25
1000d3ad8:     	ldr	x23, [sp, #48]
1000d3adc:     	ldrsb	w23, [x20, x23]
1000d3ae0:     	add	w22, w22, w23
1000d3ae4:     	scvtf	s1, w22
1000d3ae8:     	ldp	x23, x22, [sp, #32]
1000d3aec:     	ldrsb	w22, [x5, x22]
1000d3af0:     	ldrsb	w23, [x7, x23]
1000d3af4:     	ldr	x24, [sp, #24]
1000d3af8:     	ldrsb	w24, [x19, x24]
1000d3afc:     	add	w22, w22, w23
1000d3b00:     	ldrsb	w23, [x21, x28]
1000d3b04:     	add	w22, w22, w24
1000d3b08:     	ldrsb	w24, [x2, x30]
1000d3b0c:     	add	w22, w22, w23
1000d3b10:     	ldrsb	w23, [x4, x3]
1000d3b14:     	add	w22, w22, w24
1000d3b18:     	ldrsb	w24, [x6, x8]
1000d3b1c:     	add	w22, w22, w23
1000d3b20:     	ldrsb	w23, [x20, x9]
1000d3b24:     	add	w22, w22, w24
1000d3b28:     	add	w22, w22, w23
1000d3b2c:     	scvtf	s2, w22
1000d3b30:     	ldrsb	w5, [x5, x1]
1000d3b34:     	ldrsb	w7, [x7, x10]
1000d3b38:     	ldrsb	w19, [x19, x13]
1000d3b3c:     	add	w5, w5, w7
1000d3b40:     	add	w5, w5, w19
1000d3b44:     	ldrsb	w7, [x21, x26]
1000d3b48:     	ldrsb	w2, [x2, x14]
1000d3b4c:     	add	w5, w5, w7
1000d3b50:     	add	w2, w5, w2
1000d3b54:     	ldrsb	w4, [x4, x15]
1000d3b58:     	ldrsb	w5, [x6, x16]
1000d3b5c:     	add	w2, w2, w4
1000d3b60:     	add	w2, w2, w5
1000d3b64:     	ldrsb	w4, [x20, x17]
1000d3b68:     	add	w2, w2, w4
1000d3b6c:     	add	x4, sp, #176
1000d3b70:     	scvtf	s3, w2
1000d3b74:     	add	x2, x27, x12
1000d3b78:     	ldur	s4, [x2, #-128]
1000d3b7c:     	fadd	s1, s4, s1
1000d3b80:     	stur	s1, [x2, #-128]
1000d3b84:     	ldr	s1, [x2]
1000d3b88:     	fadd	s1, s1, s2
1000d3b8c:     	str	s1, [x2]
1000d3b90:     	ldr	s1, [x2, #128]
1000d3b94:     	fadd	s1, s1, s3
1000d3b98:     	ldr	s2, [x4, x12]
1000d3b9c:     	str	s1, [x2, #128]
1000d3ba0:     	fadd	s0, s2, s0
1000d3ba4:     	str	s0, [x4, x12]
1000d3ba8:     	add	x12, x12, #4
1000d3bac:     	cmp	x12, #128
1000d3bb0:     	b.ne	0x1000d39d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d3bb4:     	add	x0, x0, #128
1000d3bb8:     	ldp	x8, x1, [sp, #8]
1000d3bbc:     	add	x1, x1, #16
1000d3bc0:     	cmp	x1, x8
1000d3bc4:     	b.ne	0x1000d3908 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d3bc8:     	add	x1, sp, #176
1000d3bcc:     	ldr	x0, [sp]
1000d3bd0:     	mov	w2, #512
1000d3bd4:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d3bd8:     	ldur	x8, [x29, #-96]
1000d3bdc:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 8ul, false>(char const*)+0x22c>
1000d3be0:     	ldr	x9, [x9, #392]
1000d3be4:     	ldr	x9, [x9]
1000d3be8:     	cmp	x9, x8
1000d3bec:     	b.ne	0x1000d3c10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d3bf0:     	add	sp, sp, #704
1000d3bf4:     	ldp	x29, x30, [sp, #80]
1000d3bf8:     	ldp	x20, x19, [sp, #64]
1000d3bfc:     	ldp	x22, x21, [sp, #48]
1000d3c00:     	ldp	x24, x23, [sp, #32]
1000d3c04:     	ldp	x26, x25, [sp, #16]
1000d3c08:     	ldp	x28, x27, [sp], #96
1000d3c0c:     	ret
1000d3c10:     	bl	0x100163694 <_strcmp+0x100163694>

