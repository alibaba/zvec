00000001000ce228 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce228:     	stp	x28, x27, [sp, #-80]!
1000ce22c:     	stp	x24, x23, [sp, #16]
1000ce230:     	stp	x22, x21, [sp, #32]
1000ce234:     	stp	x20, x19, [sp, #48]
1000ce238:     	stp	x29, x30, [sp, #64]
1000ce23c:     	add	x29, sp, #64
1000ce240:     	sub	sp, sp, #1168
1000ce244:     	mov	x19, x3
1000ce248:     	mov	x20, x1
1000ce24c:     	mov	x21, x0
1000ce250:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000ce254:     	ldr	x8, [x8, #392]
1000ce258:     	ldr	x8, [x8]
1000ce25c:     	stur	x8, [x29, #-72]
1000ce260:     	lsl	x8, x2, #3
1000ce264:     	and	x22, x8, #0xfffffffffffffff0
1000ce268:     	add	x0, sp, #136
1000ce26c:     	mov	w1, #1024
1000ce270:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000ce274:     	cbz	x22, 0x1000ce478 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000ce278:     	add	x8, x20, x22
1000ce27c:     	mov	w9, #252645135
1000ce280:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000ce284:     	add	x10, x10, #1212
1000ce288:     	add	x11, sp, #8
1000ce28c:     	mov	x12, #0
1000ce290:     	ldp	w13, w14, [x20]
1000ce294:     	and	w15, w13, w9
1000ce298:     	and	w13, w9, w13, lsr #4
1000ce29c:     	stp	w15, w13, [sp, #8]
1000ce2a0:     	and	w13, w14, w9
1000ce2a4:     	and	w14, w9, w14, lsr #4
1000ce2a8:     	stp	w13, w14, [sp, #16]
1000ce2ac:     	ldp	w13, w14, [x20, #8]
1000ce2b0:     	and	w15, w13, w9
1000ce2b4:     	and	w13, w9, w13, lsr #4
1000ce2b8:     	stp	w15, w13, [sp, #24]
1000ce2bc:     	and	w13, w14, w9
1000ce2c0:     	and	w14, w9, w14, lsr #4
1000ce2c4:     	stp	w13, w14, [sp, #32]
1000ce2c8:     	ldp	w13, w14, [x20, #16]
1000ce2cc:     	and	w15, w13, w9
1000ce2d0:     	and	w13, w9, w13, lsr #4
1000ce2d4:     	stp	w15, w13, [sp, #40]
1000ce2d8:     	and	w13, w14, w9
1000ce2dc:     	and	w14, w9, w14, lsr #4
1000ce2e0:     	stp	w13, w14, [sp, #48]
1000ce2e4:     	ldp	w13, w14, [x20, #24]
1000ce2e8:     	and	w15, w13, w9
1000ce2ec:     	and	w13, w9, w13, lsr #4
1000ce2f0:     	stp	w15, w13, [sp, #56]
1000ce2f4:     	and	w13, w14, w9
1000ce2f8:     	and	w14, w9, w14, lsr #4
1000ce2fc:     	stp	w13, w14, [sp, #64]
1000ce300:     	ldp	w13, w14, [x20, #32]
1000ce304:     	and	w15, w13, w9
1000ce308:     	and	w13, w9, w13, lsr #4
1000ce30c:     	stp	w15, w13, [sp, #72]
1000ce310:     	and	w13, w14, w9
1000ce314:     	and	w14, w9, w14, lsr #4
1000ce318:     	stp	w13, w14, [sp, #80]
1000ce31c:     	ldp	w13, w14, [x20, #40]
1000ce320:     	and	w15, w13, w9
1000ce324:     	and	w13, w9, w13, lsr #4
1000ce328:     	stp	w15, w13, [sp, #88]
1000ce32c:     	and	w13, w14, w9
1000ce330:     	and	w14, w9, w14, lsr #4
1000ce334:     	stp	w13, w14, [sp, #96]
1000ce338:     	ldp	w13, w14, [x20, #48]
1000ce33c:     	and	w15, w13, w9
1000ce340:     	and	w13, w9, w13, lsr #4
1000ce344:     	stp	w15, w13, [sp, #104]
1000ce348:     	and	w13, w14, w9
1000ce34c:     	and	w14, w9, w14, lsr #4
1000ce350:     	stp	w13, w14, [sp, #112]
1000ce354:     	ldp	w13, w14, [x20, #56]
1000ce358:     	and	w15, w13, w9
1000ce35c:     	and	w13, w9, w13, lsr #4
1000ce360:     	stp	w15, w13, [sp, #120]
1000ce364:     	and	w13, w14, w9
1000ce368:     	and	w14, w9, w14, lsr #4
1000ce36c:     	stp	w13, w14, [sp, #128]
1000ce370:     	add	x13, sp, #136
1000ce374:     	mov	x14, #0
1000ce378:     	ldr	w4, [x21, x12, lsl #2]
1000ce37c:     	lsl	w15, w4, #4
1000ce380:     	and	x15, x15, #0xf0
1000ce384:     	add	x15, x10, x15
1000ce388:     	and	x16, x4, #0xf0
1000ce38c:     	add	x16, x10, x16
1000ce390:     	lsr	x17, x4, #4
1000ce394:     	and	x17, x17, #0xf0
1000ce398:     	add	x17, x10, x17
1000ce39c:     	lsr	x0, x4, #8
1000ce3a0:     	and	x0, x0, #0xf0
1000ce3a4:     	add	x0, x10, x0
1000ce3a8:     	lsr	x1, x4, #12
1000ce3ac:     	and	x1, x1, #0xf0
1000ce3b0:     	add	x1, x10, x1
1000ce3b4:     	lsr	x2, x4, #16
1000ce3b8:     	and	x2, x2, #0xf0
1000ce3bc:     	add	x2, x10, x2
1000ce3c0:     	lsr	x3, x4, #20
1000ce3c4:     	and	x3, x3, #0xf0
1000ce3c8:     	add	x3, x10, x3
1000ce3cc:     	lsr	x4, x4, #24
1000ce3d0:     	and	x4, x4, #0xf0
1000ce3d4:     	add	x4, x10, x4
1000ce3d8:     	mov	x5, x13
1000ce3dc:     	add	x6, x11, x14
1000ce3e0:     	ldrb	w7, [x6]
1000ce3e4:     	ldrb	w7, [x15, x7]
1000ce3e8:     	ldrb	w22, [x6, #1]
1000ce3ec:     	ldrb	w22, [x17, x22]
1000ce3f0:     	ldrb	w23, [x6, #2]
1000ce3f4:     	ldrb	w23, [x1, x23]
1000ce3f8:     	add	w7, w7, w22
1000ce3fc:     	add	w7, w7, w23
1000ce400:     	ldrb	w22, [x6, #3]
1000ce404:     	ldrb	w22, [x3, x22]
1000ce408:     	ldrb	w23, [x6, #4]
1000ce40c:     	ldrb	w23, [x16, x23]
1000ce410:     	ldrb	w24, [x6, #5]
1000ce414:     	ldrb	w24, [x0, x24]
1000ce418:     	add	w7, w7, w22
1000ce41c:     	add	w7, w7, w23
1000ce420:     	ldrb	w22, [x6, #6]
1000ce424:     	ldrb	w22, [x2, x22]
1000ce428:     	add	w7, w7, w24
1000ce42c:     	add	w7, w7, w22
1000ce430:     	ldrb	w6, [x6, #7]
1000ce434:     	ldrb	w6, [x4, x6]
1000ce438:     	add	w6, w7, w6
1000ce43c:     	scvtf	s0, w6
1000ce440:     	ldr	s1, [x5]
1000ce444:     	fadd	s0, s1, s0
1000ce448:     	str	s0, [x5], #64
1000ce44c:     	add	x14, x14, #8
1000ce450:     	cmp	x14, #128
1000ce454:     	b.ne	0x1000ce3dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000ce458:     	add	x12, x12, #1
1000ce45c:     	add	x13, x13, #4
1000ce460:     	cmp	x12, #16
1000ce464:     	b.ne	0x1000ce374 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ce468:     	add	x21, x21, #64
1000ce46c:     	add	x20, x20, #64
1000ce470:     	cmp	x20, x8
1000ce474:     	b.ne	0x1000ce28c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000ce478:     	add	x1, sp, #136
1000ce47c:     	mov	x0, x19
1000ce480:     	mov	w2, #1024
1000ce484:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ce488:     	ldur	x8, [x29, #-72]
1000ce48c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000ce490:     	ldr	x9, [x9, #392]
1000ce494:     	ldr	x9, [x9]
1000ce498:     	cmp	x9, x8
1000ce49c:     	b.ne	0x1000ce4bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000ce4a0:     	add	sp, sp, #1168
1000ce4a4:     	ldp	x29, x30, [sp, #64]
1000ce4a8:     	ldp	x20, x19, [sp, #48]
1000ce4ac:     	ldp	x22, x21, [sp, #32]
1000ce4b0:     	ldp	x24, x23, [sp, #16]
1000ce4b4:     	ldp	x28, x27, [sp], #80
1000ce4b8:     	ret
1000ce4bc:     	bl	0x100163694 <_strcmp+0x100163694>

