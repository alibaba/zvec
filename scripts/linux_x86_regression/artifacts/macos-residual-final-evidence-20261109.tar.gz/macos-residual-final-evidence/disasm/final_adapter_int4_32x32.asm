
bin/final_adapter:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100093040 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
100093040:     	stp	x28, x27, [sp, #-80]!
100093044:     	stp	x24, x23, [sp, #16]
100093048:     	stp	x22, x21, [sp, #32]
10009304c:     	stp	x20, x19, [sp, #48]
100093050:     	stp	x29, x30, [sp, #64]
100093054:     	add	x29, sp, #64
100093058:     	mov	w9, #4368
10009305c:     	adrp	x16, 0x100321000 <zvec::core::EuclideanMetric::distance() const+0x2a0>
100093060:     	ldr	x16, [x16, #2152]
100093064:     	blr	x16
100093068:     	sub	sp, sp, #1, lsl #12     ; =4096
10009306c:     	sub	sp, sp, #272
100093070:     	mov	x19, x3
100093074:     	mov	x20, x1
100093078:     	mov	x21, x0
10009307c:     	adrp	x8, 0x100321000 <zvec::core::EuclideanMetric::distance() const+0x2c0>
100093080:     	ldr	x8, [x8, #2296]
100093084:     	ldr	x8, [x8]
100093088:     	stur	x8, [x29, #-72]
10009308c:     	lsl	x8, x2, #4
100093090:     	and	x22, x8, #0xffffffffffffffe0
100093094:     	add	x0, sp, #264
100093098:     	mov	w1, #4096
10009309c:     	bl	0x1002a94cc <_write+0x1002a94cc>
1000930a0:     	cbz	x22, 0x100093388 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x348>
1000930a4:     	add	x8, x20, x22
1000930a8:     	mov	w9, #252645135
1000930ac:     	adrp	x10, 0x1002dc000 <zvec::core::EuclideanMetric::distance() const+0x1dc>
1000930b0:     	add	x10, x10, #2384
1000930b4:     	add	x11, sp, #8
1000930b8:     	mov	x12, #0
1000930bc:     	ldp	w13, w14, [x20]
1000930c0:     	and	w15, w13, w9
1000930c4:     	and	w13, w9, w13, lsr #4
1000930c8:     	stp	w15, w13, [sp, #8]
1000930cc:     	and	w13, w14, w9
1000930d0:     	and	w14, w9, w14, lsr #4
1000930d4:     	stp	w13, w14, [sp, #16]
1000930d8:     	ldp	w13, w14, [x20, #8]
1000930dc:     	and	w15, w13, w9
1000930e0:     	and	w13, w9, w13, lsr #4
1000930e4:     	stp	w15, w13, [sp, #24]
1000930e8:     	and	w13, w14, w9
1000930ec:     	and	w14, w9, w14, lsr #4
1000930f0:     	stp	w13, w14, [sp, #32]
1000930f4:     	ldp	w13, w14, [x20, #16]
1000930f8:     	and	w15, w13, w9
1000930fc:     	and	w13, w9, w13, lsr #4
100093100:     	stp	w15, w13, [sp, #40]
100093104:     	and	w13, w14, w9
100093108:     	and	w14, w9, w14, lsr #4
10009310c:     	stp	w13, w14, [sp, #48]
100093110:     	ldp	w13, w14, [x20, #24]
100093114:     	and	w15, w13, w9
100093118:     	and	w13, w9, w13, lsr #4
10009311c:     	stp	w15, w13, [sp, #56]
100093120:     	and	w13, w14, w9
100093124:     	and	w14, w9, w14, lsr #4
100093128:     	stp	w13, w14, [sp, #64]
10009312c:     	ldp	w13, w14, [x20, #32]
100093130:     	and	w15, w13, w9
100093134:     	and	w13, w9, w13, lsr #4
100093138:     	stp	w15, w13, [sp, #72]
10009313c:     	and	w13, w14, w9
100093140:     	and	w14, w9, w14, lsr #4
100093144:     	stp	w13, w14, [sp, #80]
100093148:     	ldp	w13, w14, [x20, #40]
10009314c:     	and	w15, w13, w9
100093150:     	and	w13, w9, w13, lsr #4
100093154:     	stp	w15, w13, [sp, #88]
100093158:     	and	w13, w14, w9
10009315c:     	and	w14, w9, w14, lsr #4
100093160:     	stp	w13, w14, [sp, #96]
100093164:     	ldp	w13, w14, [x20, #48]
100093168:     	and	w15, w13, w9
10009316c:     	and	w13, w9, w13, lsr #4
100093170:     	stp	w15, w13, [sp, #104]
100093174:     	and	w13, w14, w9
100093178:     	and	w14, w9, w14, lsr #4
10009317c:     	stp	w13, w14, [sp, #112]
100093180:     	ldp	w13, w14, [x20, #56]
100093184:     	and	w15, w13, w9
100093188:     	and	w13, w9, w13, lsr #4
10009318c:     	stp	w15, w13, [sp, #120]
100093190:     	and	w13, w14, w9
100093194:     	and	w14, w9, w14, lsr #4
100093198:     	stp	w13, w14, [sp, #128]
10009319c:     	ldp	w13, w14, [x20, #64]
1000931a0:     	and	w15, w13, w9
1000931a4:     	and	w13, w9, w13, lsr #4
1000931a8:     	stp	w15, w13, [sp, #136]
1000931ac:     	and	w13, w14, w9
1000931b0:     	and	w14, w9, w14, lsr #4
1000931b4:     	stp	w13, w14, [sp, #144]
1000931b8:     	ldp	w13, w14, [x20, #72]
1000931bc:     	and	w15, w13, w9
1000931c0:     	and	w13, w9, w13, lsr #4
1000931c4:     	stp	w15, w13, [sp, #152]
1000931c8:     	and	w13, w14, w9
1000931cc:     	and	w14, w9, w14, lsr #4
1000931d0:     	stp	w13, w14, [sp, #160]
1000931d4:     	ldp	w13, w14, [x20, #80]
1000931d8:     	and	w15, w13, w9
1000931dc:     	and	w13, w9, w13, lsr #4
1000931e0:     	stp	w15, w13, [sp, #168]
1000931e4:     	and	w13, w14, w9
1000931e8:     	and	w14, w9, w14, lsr #4
1000931ec:     	stp	w13, w14, [sp, #176]
1000931f0:     	ldp	w13, w14, [x20, #88]
1000931f4:     	and	w15, w13, w9
1000931f8:     	and	w13, w9, w13, lsr #4
1000931fc:     	stp	w15, w13, [sp, #184]
100093200:     	and	w13, w14, w9
100093204:     	and	w14, w9, w14, lsr #4
100093208:     	stp	w13, w14, [sp, #192]
10009320c:     	ldp	w13, w14, [x20, #96]
100093210:     	and	w15, w13, w9
100093214:     	and	w13, w9, w13, lsr #4
100093218:     	stp	w15, w13, [sp, #200]
10009321c:     	and	w13, w14, w9
100093220:     	and	w14, w9, w14, lsr #4
100093224:     	stp	w13, w14, [sp, #208]
100093228:     	ldp	w13, w14, [x20, #104]
10009322c:     	and	w15, w13, w9
100093230:     	and	w13, w9, w13, lsr #4
100093234:     	stp	w15, w13, [sp, #216]
100093238:     	and	w13, w14, w9
10009323c:     	and	w14, w9, w14, lsr #4
100093240:     	stp	w13, w14, [sp, #224]
100093244:     	ldp	w13, w14, [x20, #112]
100093248:     	and	w15, w13, w9
10009324c:     	and	w13, w9, w13, lsr #4
100093250:     	stp	w15, w13, [sp, #232]
100093254:     	and	w13, w14, w9
100093258:     	and	w14, w9, w14, lsr #4
10009325c:     	stp	w13, w14, [sp, #240]
100093260:     	ldp	w13, w14, [x20, #120]
100093264:     	and	w15, w13, w9
100093268:     	and	w13, w9, w13, lsr #4
10009326c:     	stp	w15, w13, [sp, #248]
100093270:     	and	w13, w14, w9
100093274:     	and	w14, w9, w14, lsr #4
100093278:     	str	w13, [sp, #256]
10009327c:     	str	w14, [sp, #260]
100093280:     	add	x13, sp, #264
100093284:     	mov	x14, #0
100093288:     	ldr	w4, [x21, x12, lsl #2]
10009328c:     	lsl	w15, w4, #4
100093290:     	and	x15, x15, #0xf0
100093294:     	add	x15, x10, x15
100093298:     	and	x16, x4, #0xf0
10009329c:     	add	x16, x10, x16
1000932a0:     	lsr	x17, x4, #4
1000932a4:     	and	x17, x17, #0xf0
1000932a8:     	add	x17, x10, x17
1000932ac:     	lsr	x0, x4, #8
1000932b0:     	and	x0, x0, #0xf0
1000932b4:     	add	x0, x10, x0
1000932b8:     	lsr	x1, x4, #12
1000932bc:     	and	x1, x1, #0xf0
1000932c0:     	add	x1, x10, x1
1000932c4:     	lsr	x2, x4, #16
1000932c8:     	and	x2, x2, #0xf0
1000932cc:     	add	x2, x10, x2
1000932d0:     	lsr	x3, x4, #20
1000932d4:     	and	x3, x3, #0xf0
1000932d8:     	add	x3, x10, x3
1000932dc:     	lsr	x4, x4, #24
1000932e0:     	and	x4, x4, #0xf0
1000932e4:     	add	x4, x10, x4
1000932e8:     	mov	x5, x13
1000932ec:     	add	x6, x11, x14
1000932f0:     	ldrb	w7, [x6]
1000932f4:     	ldrb	w7, [x15, x7]
1000932f8:     	ldrb	w22, [x6, #1]
1000932fc:     	ldrb	w22, [x17, x22]
100093300:     	ldrb	w23, [x6, #2]
100093304:     	ldrb	w23, [x1, x23]
100093308:     	add	w7, w7, w22
10009330c:     	add	w7, w7, w23
100093310:     	ldrb	w22, [x6, #3]
100093314:     	ldrb	w22, [x3, x22]
100093318:     	ldrb	w23, [x6, #4]
10009331c:     	ldrb	w23, [x16, x23]
100093320:     	ldrb	w24, [x6, #5]
100093324:     	ldrb	w24, [x0, x24]
100093328:     	add	w7, w7, w22
10009332c:     	add	w7, w7, w23
100093330:     	ldrb	w22, [x6, #6]
100093334:     	ldrb	w22, [x2, x22]
100093338:     	add	w7, w7, w24
10009333c:     	add	w7, w7, w22
100093340:     	ldrb	w6, [x6, #7]
100093344:     	ldrb	w6, [x4, x6]
100093348:     	add	w6, w7, w6
10009334c:     	scvtf	s0, w6
100093350:     	ldr	s1, [x5]
100093354:     	fadd	s0, s1, s0
100093358:     	str	s0, [x5], #128
10009335c:     	add	x14, x14, #8
100093360:     	cmp	x14, #256
100093364:     	b.ne	0x1000932ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
100093368:     	add	x12, x12, #1
10009336c:     	add	x13, x13, #4
100093370:     	cmp	x12, #32
100093374:     	b.ne	0x100093284 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
100093378:     	add	x21, x21, #128
10009337c:     	add	x20, x20, #128
100093380:     	cmp	x20, x8
100093384:     	b.ne	0x1000930b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x78>
100093388:     	add	x1, sp, #264
10009338c:     	mov	x0, x19
100093390:     	mov	w2, #4096
100093394:     	bl	0x1002a9610 <_write+0x1002a9610>
100093398:     	ldur	x8, [x29, #-72]
10009339c:     	adrp	x9, 0x100321000 <zvec::core::EuclideanMetric::distance_matrix(unsigned long, unsigned long) const+0x48>
1000933a0:     	ldr	x9, [x9, #2296]
1000933a4:     	ldr	x9, [x9]
1000933a8:     	cmp	x9, x8
1000933ac:     	b.ne	0x1000933d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x390>
1000933b0:     	add	sp, sp, #1, lsl #12     ; =4096
1000933b4:     	add	sp, sp, #272
1000933b8:     	ldp	x29, x30, [sp, #64]
1000933bc:     	ldp	x20, x19, [sp, #48]
1000933c0:     	ldp	x22, x21, [sp, #32]
1000933c4:     	ldp	x24, x23, [sp, #16]
1000933c8:     	ldp	x28, x27, [sp], #80
1000933cc:     	ret
1000933d0:     	bl	0x1002a949c <_write+0x1002a949c>

00000001000bbb9c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bbb9c:     	stp	x28, x27, [sp, #-80]!
1000bbba0:     	stp	x24, x23, [sp, #16]
1000bbba4:     	stp	x22, x21, [sp, #32]
1000bbba8:     	stp	x20, x19, [sp, #48]
1000bbbac:     	stp	x29, x30, [sp, #64]
1000bbbb0:     	add	x29, sp, #64
1000bbbb4:     	mov	w9, #4368
1000bbbb8:     	adrp	x16, 0x100321000 <std::__1::__function::__func<zvec::ailego::Factory<zvec::core::IndexMetric>::Register<zvec::core::InnerProductSparseMetric, void>::Register(char const*)::'lambda'(), std::__1::allocator<zvec::ailego::Factory<zvec::core::IndexMetric>::Register<zvec::core::InnerProductSparseMetric, void>::Register(char const*)::'lambda'()>, zvec::core::IndexMetric* ()>::target_type() const+0x8>
1000bbbbc:     	ldr	x16, [x16, #2152]
1000bbbc0:     	blr	x16
1000bbbc4:     	sub	sp, sp, #1, lsl #12     ; =4096
1000bbbc8:     	sub	sp, sp, #272
1000bbbcc:     	mov	x19, x3
1000bbbd0:     	mov	x20, x1
1000bbbd4:     	mov	x21, x0
1000bbbd8:     	adrp	x8, 0x100321000 <zvec::core::InnerProductSparseMetric::~InnerProductSparseMetric()+0x1c>
1000bbbdc:     	ldr	x8, [x8, #2296]
1000bbbe0:     	ldr	x8, [x8]
1000bbbe4:     	stur	x8, [x29, #-72]
1000bbbe8:     	lsl	x8, x2, #4
1000bbbec:     	and	x22, x8, #0xffffffffffffffe0
1000bbbf0:     	add	x0, sp, #264
1000bbbf4:     	mov	w1, #4096
1000bbbf8:     	bl	0x1002a94cc <_write+0x1002a94cc>
1000bbbfc:     	cbz	x22, 0x1000bbee4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x348>
1000bbc00:     	add	x8, x20, x22
1000bbc04:     	mov	w9, #252645135
1000bbc08:     	adrp	x10, 0x1002e0000 <std::__1::__function::__func<zvec::ailego::Factory<zvec::core::IndexMetric>::Register<zvec::core::InnerProductSparseMetric, void>::Register(char const*)::'lambda'(), std::__1::allocator<zvec::ailego::Factory<zvec::core::IndexMetric>::Register<zvec::core::InnerProductSparseMetric, void>::Register(char const*)::'lambda'()>, zvec::core::IndexMetric* ()>::operator()()+0x20>
1000bbc0c:     	add	x10, x10, #3272
1000bbc10:     	add	x11, sp, #8
1000bbc14:     	mov	x12, #0
1000bbc18:     	ldp	w13, w14, [x20]
1000bbc1c:     	and	w15, w13, w9
1000bbc20:     	and	w13, w9, w13, lsr #4
1000bbc24:     	stp	w15, w13, [sp, #8]
1000bbc28:     	and	w13, w14, w9
1000bbc2c:     	and	w14, w9, w14, lsr #4
1000bbc30:     	stp	w13, w14, [sp, #16]
1000bbc34:     	ldp	w13, w14, [x20, #8]
1000bbc38:     	and	w15, w13, w9
1000bbc3c:     	and	w13, w9, w13, lsr #4
1000bbc40:     	stp	w15, w13, [sp, #24]
1000bbc44:     	and	w13, w14, w9
1000bbc48:     	and	w14, w9, w14, lsr #4
1000bbc4c:     	stp	w13, w14, [sp, #32]
1000bbc50:     	ldp	w13, w14, [x20, #16]
1000bbc54:     	and	w15, w13, w9
1000bbc58:     	and	w13, w9, w13, lsr #4
1000bbc5c:     	stp	w15, w13, [sp, #40]
1000bbc60:     	and	w13, w14, w9
1000bbc64:     	and	w14, w9, w14, lsr #4
1000bbc68:     	stp	w13, w14, [sp, #48]
1000bbc6c:     	ldp	w13, w14, [x20, #24]
1000bbc70:     	and	w15, w13, w9
1000bbc74:     	and	w13, w9, w13, lsr #4
1000bbc78:     	stp	w15, w13, [sp, #56]
1000bbc7c:     	and	w13, w14, w9
1000bbc80:     	and	w14, w9, w14, lsr #4
1000bbc84:     	stp	w13, w14, [sp, #64]
1000bbc88:     	ldp	w13, w14, [x20, #32]
1000bbc8c:     	and	w15, w13, w9
1000bbc90:     	and	w13, w9, w13, lsr #4
1000bbc94:     	stp	w15, w13, [sp, #72]
1000bbc98:     	and	w13, w14, w9
1000bbc9c:     	and	w14, w9, w14, lsr #4
1000bbca0:     	stp	w13, w14, [sp, #80]
1000bbca4:     	ldp	w13, w14, [x20, #40]
1000bbca8:     	and	w15, w13, w9
1000bbcac:     	and	w13, w9, w13, lsr #4
1000bbcb0:     	stp	w15, w13, [sp, #88]
1000bbcb4:     	and	w13, w14, w9
1000bbcb8:     	and	w14, w9, w14, lsr #4
1000bbcbc:     	stp	w13, w14, [sp, #96]
1000bbcc0:     	ldp	w13, w14, [x20, #48]
1000bbcc4:     	and	w15, w13, w9
1000bbcc8:     	and	w13, w9, w13, lsr #4
1000bbccc:     	stp	w15, w13, [sp, #104]
1000bbcd0:     	and	w13, w14, w9
1000bbcd4:     	and	w14, w9, w14, lsr #4
1000bbcd8:     	stp	w13, w14, [sp, #112]
1000bbcdc:     	ldp	w13, w14, [x20, #56]
1000bbce0:     	and	w15, w13, w9
1000bbce4:     	and	w13, w9, w13, lsr #4
1000bbce8:     	stp	w15, w13, [sp, #120]
1000bbcec:     	and	w13, w14, w9
1000bbcf0:     	and	w14, w9, w14, lsr #4
1000bbcf4:     	stp	w13, w14, [sp, #128]
1000bbcf8:     	ldp	w13, w14, [x20, #64]
1000bbcfc:     	and	w15, w13, w9
1000bbd00:     	and	w13, w9, w13, lsr #4
1000bbd04:     	stp	w15, w13, [sp, #136]
1000bbd08:     	and	w13, w14, w9
1000bbd0c:     	and	w14, w9, w14, lsr #4
1000bbd10:     	stp	w13, w14, [sp, #144]
1000bbd14:     	ldp	w13, w14, [x20, #72]
1000bbd18:     	and	w15, w13, w9
1000bbd1c:     	and	w13, w9, w13, lsr #4
1000bbd20:     	stp	w15, w13, [sp, #152]
1000bbd24:     	and	w13, w14, w9
1000bbd28:     	and	w14, w9, w14, lsr #4
1000bbd2c:     	stp	w13, w14, [sp, #160]
1000bbd30:     	ldp	w13, w14, [x20, #80]
1000bbd34:     	and	w15, w13, w9
1000bbd38:     	and	w13, w9, w13, lsr #4
1000bbd3c:     	stp	w15, w13, [sp, #168]
1000bbd40:     	and	w13, w14, w9
1000bbd44:     	and	w14, w9, w14, lsr #4
1000bbd48:     	stp	w13, w14, [sp, #176]
1000bbd4c:     	ldp	w13, w14, [x20, #88]
1000bbd50:     	and	w15, w13, w9
1000bbd54:     	and	w13, w9, w13, lsr #4
1000bbd58:     	stp	w15, w13, [sp, #184]
1000bbd5c:     	and	w13, w14, w9
1000bbd60:     	and	w14, w9, w14, lsr #4
1000bbd64:     	stp	w13, w14, [sp, #192]
1000bbd68:     	ldp	w13, w14, [x20, #96]
1000bbd6c:     	and	w15, w13, w9
1000bbd70:     	and	w13, w9, w13, lsr #4
1000bbd74:     	stp	w15, w13, [sp, #200]
1000bbd78:     	and	w13, w14, w9
1000bbd7c:     	and	w14, w9, w14, lsr #4
1000bbd80:     	stp	w13, w14, [sp, #208]
1000bbd84:     	ldp	w13, w14, [x20, #104]
1000bbd88:     	and	w15, w13, w9
1000bbd8c:     	and	w13, w9, w13, lsr #4
1000bbd90:     	stp	w15, w13, [sp, #216]
1000bbd94:     	and	w13, w14, w9
1000bbd98:     	and	w14, w9, w14, lsr #4
1000bbd9c:     	stp	w13, w14, [sp, #224]
1000bbda0:     	ldp	w13, w14, [x20, #112]
1000bbda4:     	and	w15, w13, w9
1000bbda8:     	and	w13, w9, w13, lsr #4
1000bbdac:     	stp	w15, w13, [sp, #232]
1000bbdb0:     	and	w13, w14, w9
1000bbdb4:     	and	w14, w9, w14, lsr #4
1000bbdb8:     	stp	w13, w14, [sp, #240]
1000bbdbc:     	ldp	w13, w14, [x20, #120]
1000bbdc0:     	and	w15, w13, w9
1000bbdc4:     	and	w13, w9, w13, lsr #4
1000bbdc8:     	stp	w15, w13, [sp, #248]
1000bbdcc:     	and	w13, w14, w9
1000bbdd0:     	and	w14, w9, w14, lsr #4
1000bbdd4:     	str	w13, [sp, #256]
1000bbdd8:     	str	w14, [sp, #260]
1000bbddc:     	add	x13, sp, #264
1000bbde0:     	mov	x14, #0
1000bbde4:     	ldr	w4, [x21, x12, lsl #2]
1000bbde8:     	lsl	w15, w4, #4
1000bbdec:     	and	x15, x15, #0xf0
1000bbdf0:     	add	x15, x10, x15
1000bbdf4:     	and	x16, x4, #0xf0
1000bbdf8:     	add	x16, x10, x16
1000bbdfc:     	lsr	x17, x4, #4
1000bbe00:     	and	x17, x17, #0xf0
1000bbe04:     	add	x17, x10, x17
1000bbe08:     	lsr	x0, x4, #8
1000bbe0c:     	and	x0, x0, #0xf0
1000bbe10:     	add	x0, x10, x0
1000bbe14:     	lsr	x1, x4, #12
1000bbe18:     	and	x1, x1, #0xf0
1000bbe1c:     	add	x1, x10, x1
1000bbe20:     	lsr	x2, x4, #16
1000bbe24:     	and	x2, x2, #0xf0
1000bbe28:     	add	x2, x10, x2
1000bbe2c:     	lsr	x3, x4, #20
1000bbe30:     	and	x3, x3, #0xf0
1000bbe34:     	add	x3, x10, x3
1000bbe38:     	lsr	x4, x4, #24
1000bbe3c:     	and	x4, x4, #0xf0
1000bbe40:     	add	x4, x10, x4
1000bbe44:     	mov	x5, x13
1000bbe48:     	add	x6, x11, x14
1000bbe4c:     	ldrb	w7, [x6]
1000bbe50:     	ldrsb	w7, [x15, x7]
1000bbe54:     	ldrb	w22, [x6, #1]
1000bbe58:     	ldrsb	w22, [x17, x22]
1000bbe5c:     	ldrb	w23, [x6, #2]
1000bbe60:     	ldrsb	w23, [x1, x23]
1000bbe64:     	add	w7, w7, w22
1000bbe68:     	add	w7, w7, w23
1000bbe6c:     	ldrb	w22, [x6, #3]
1000bbe70:     	ldrsb	w22, [x3, x22]
1000bbe74:     	ldrb	w23, [x6, #4]
1000bbe78:     	ldrsb	w23, [x16, x23]
1000bbe7c:     	ldrb	w24, [x6, #5]
1000bbe80:     	ldrsb	w24, [x0, x24]
1000bbe84:     	add	w7, w7, w22
1000bbe88:     	add	w7, w7, w23
1000bbe8c:     	ldrb	w22, [x6, #6]
1000bbe90:     	ldrsb	w22, [x2, x22]
1000bbe94:     	add	w7, w7, w24
1000bbe98:     	add	w7, w7, w22
1000bbe9c:     	ldrb	w6, [x6, #7]
1000bbea0:     	ldrsb	w6, [x4, x6]
1000bbea4:     	add	w6, w7, w6
1000bbea8:     	scvtf	s0, w6
1000bbeac:     	ldr	s1, [x5]
1000bbeb0:     	fadd	s0, s1, s0
1000bbeb4:     	str	s0, [x5], #128
1000bbeb8:     	add	x14, x14, #8
1000bbebc:     	cmp	x14, #256
1000bbec0:     	b.ne	0x1000bbe48 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000bbec4:     	add	x12, x12, #1
1000bbec8:     	add	x13, x13, #4
1000bbecc:     	cmp	x12, #32
1000bbed0:     	b.ne	0x1000bbde0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000bbed4:     	add	x21, x21, #128
1000bbed8:     	add	x20, x20, #128
1000bbedc:     	cmp	x20, x8
1000bbee0:     	b.ne	0x1000bbc14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x78>
1000bbee4:     	add	x1, sp, #264
1000bbee8:     	mov	x0, x19
1000bbeec:     	mov	w2, #4096
1000bbef0:     	bl	0x1002a9610 <_write+0x1002a9610>
1000bbef4:     	ldur	x8, [x29, #-72]
1000bbef8:     	adrp	x9, 0x100321000 <zvec::ailego::Factory<zvec::core::IndexMetric>::Register<zvec::core::MipsSquaredEuclideanMetric<false>, void>::Register(char const*)+0x94>
1000bbefc:     	ldr	x9, [x9, #2296]
1000bbf00:     	ldr	x9, [x9]
1000bbf04:     	cmp	x9, x8
1000bbf08:     	b.ne	0x1000bbf2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x390>
1000bbf0c:     	add	sp, sp, #1, lsl #12     ; =4096
1000bbf10:     	add	sp, sp, #272
1000bbf14:     	ldp	x29, x30, [sp, #64]
1000bbf18:     	ldp	x20, x19, [sp, #48]
1000bbf1c:     	ldp	x22, x21, [sp, #32]
1000bbf20:     	ldp	x24, x23, [sp, #16]
1000bbf24:     	ldp	x28, x27, [sp], #80
1000bbf28:     	ret
1000bbf2c:     	bl	0x1002a949c <_write+0x1002a949c>
