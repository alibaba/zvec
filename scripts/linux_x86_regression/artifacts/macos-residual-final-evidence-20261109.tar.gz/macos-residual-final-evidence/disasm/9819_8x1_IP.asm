00000001000bd7d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bd7d8:     	stp	x22, x21, [sp, #-32]!
1000bd7dc:     	stp	x20, x19, [sp, #16]
1000bd7e0:     	movi.2d	v0, #0000000000000000
1000bd7e4:     	stp	q0, q0, [x3]
1000bd7e8:     	cmp	x2, #8
1000bd7ec:     	b.hs	0x1000bd7f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000bd7f0:     	mov	x8, #0
1000bd7f4:     	b	0x1000bd908 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x130>
1000bd7f8:     	mov	x8, #0
1000bd7fc:     	mov	w14, #8
1000bd800:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2cc>
1000bd804:     	add	x9, x9, #988
1000bd808:     	mov	x10, x0
1000bd80c:     	mov	x11, #0
1000bd810:     	lsr	x8, x8, #1
1000bd814:     	mul	x8, x8, x4
1000bd818:     	ldr	w6, [x1, x8]
1000bd81c:     	ubfx	x12, x6, #4, #4
1000bd820:     	ubfx	x13, x6, #8, #4
1000bd824:     	mov	x8, x14
1000bd828:     	ubfx	x14, x6, #12, #4
1000bd82c:     	and	x15, x6, #0xf
1000bd830:     	ubfx	x16, x6, #16, #4
1000bd834:     	ubfx	x17, x6, #20, #4
1000bd838:     	ubfx	x5, x6, #24, #4
1000bd83c:     	lsr	x6, x6, #28
1000bd840:     	ldr	w7, [x10, x11]
1000bd844:     	lsl	w19, w7, #4
1000bd848:     	and	x19, x19, #0xf0
1000bd84c:     	orr	x19, x19, x15
1000bd850:     	ldrsb	w19, [x9, x19]
1000bd854:     	and	x20, x7, #0xf0
1000bd858:     	orr	x20, x20, x12
1000bd85c:     	ldrsb	w20, [x9, x20]
1000bd860:     	lsr	x21, x7, #4
1000bd864:     	and	x21, x21, #0xf0
1000bd868:     	orr	x21, x21, x13
1000bd86c:     	ldrsb	w21, [x9, x21]
1000bd870:     	lsr	x22, x7, #8
1000bd874:     	and	x22, x22, #0xf0
1000bd878:     	orr	x22, x22, x14
1000bd87c:     	ldrsb	w22, [x9, x22]
1000bd880:     	add	w19, w19, w20
1000bd884:     	add	w19, w19, w21
1000bd888:     	lsr	x20, x7, #12
1000bd88c:     	and	x20, x20, #0xf0
1000bd890:     	orr	x20, x20, x16
1000bd894:     	ldrsb	w20, [x9, x20]
1000bd898:     	lsr	x21, x7, #16
1000bd89c:     	and	x21, x21, #0xf0
1000bd8a0:     	orr	x21, x21, x17
1000bd8a4:     	ldrsb	w21, [x9, x21]
1000bd8a8:     	add	w19, w19, w22
1000bd8ac:     	add	w19, w19, w20
1000bd8b0:     	lsr	x20, x7, #20
1000bd8b4:     	and	x20, x20, #0xf0
1000bd8b8:     	orr	x20, x20, x5
1000bd8bc:     	ldrsb	w20, [x9, x20]
1000bd8c0:     	lsr	x7, x7, #24
1000bd8c4:     	and	x7, x7, #0xf0
1000bd8c8:     	orr	x7, x7, x6
1000bd8cc:     	ldrsb	w7, [x9, x7]
1000bd8d0:     	add	w19, w19, w21
1000bd8d4:     	add	w19, w19, w20
1000bd8d8:     	add	w7, w19, w7
1000bd8dc:     	scvtf	s0, w7
1000bd8e0:     	ldr	s1, [x3, x11]
1000bd8e4:     	fadd	s0, s1, s0
1000bd8e8:     	str	s0, [x3, x11]
1000bd8ec:     	add	x11, x11, #4
1000bd8f0:     	cmp	x11, #32
1000bd8f4:     	b.ne	0x1000bd840 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x68>
1000bd8f8:     	add	x14, x8, #8
1000bd8fc:     	add	x10, x10, #32
1000bd900:     	cmp	x14, x2
1000bd904:     	b.ls	0x1000bd80c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000bd908:     	cmp	x8, x2
1000bd90c:     	b.hs	0x1000bdaa4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2cc>
1000bd910:     	lsl	x9, x4, #2
1000bd914:     	ldp	s0, s1, [x3, #8]
1000bd918:     	lsl	x10, x8, #2
1000bd91c:     	mov	w11, #-16
1000bd920:     	ldr	s2, [x3, #16]
1000bd924:     	lsr	x12, x8, #3
1000bd928:     	mul	x13, x9, x12
1000bd92c:     	ubfx	x12, x8, #1, #2
1000bd930:     	orr	x14, x13, x12
1000bd934:     	and	w13, w10, #0x4
1000bd938:     	ldrb	w14, [x1, x14]
1000bd93c:     	lsr	w14, w14, w13
1000bd940:     	and	w15, w14, #0xf
1000bd944:     	cmp	w15, #8
1000bd948:     	csel	w15, wzr, w11, lo
1000bd94c:     	and	x16, x10, #0xffffffffffffffe0
1000bd950:     	bfxil	w15, w14, #0, #4
1000bd954:     	bfxil	x16, x8, #1, #2
1000bd958:     	add	x14, x0, x16
1000bd95c:     	ldrb	w16, [x14]
1000bd960:     	lsr	w16, w16, w13
1000bd964:     	scvtf	s3, w15
1000bd968:     	and	w15, w16, #0xf
1000bd96c:     	cmp	w15, #8
1000bd970:     	csel	w15, wzr, w11, lo
1000bd974:     	bfxil	w15, w16, #0, #4
1000bd978:     	scvtf	s4, w15
1000bd97c:     	ldp	s5, s6, [x3]
1000bd980:     	fmsub	s4, s4, s3, s5
1000bd984:     	str	s4, [x3]
1000bd988:     	ldrb	w15, [x14, #4]
1000bd98c:     	lsr	w15, w15, w13
1000bd990:     	and	w16, w15, #0xf
1000bd994:     	cmp	w16, #8
1000bd998:     	csel	w16, wzr, w11, lo
1000bd99c:     	bfxil	w16, w15, #0, #4
1000bd9a0:     	scvtf	s4, w16
1000bd9a4:     	fmsub	s4, s4, s3, s6
1000bd9a8:     	str	s4, [x3, #4]
1000bd9ac:     	ldrb	w15, [x14, #8]
1000bd9b0:     	lsr	w15, w15, w13
1000bd9b4:     	and	w16, w15, #0xf
1000bd9b8:     	cmp	w16, #8
1000bd9bc:     	csel	w16, wzr, w11, lo
1000bd9c0:     	bfxil	w16, w15, #0, #4
1000bd9c4:     	scvtf	s4, w16
1000bd9c8:     	fmsub	s0, s4, s3, s0
1000bd9cc:     	str	s0, [x3, #8]
1000bd9d0:     	ldrb	w15, [x14, #12]
1000bd9d4:     	lsr	w15, w15, w13
1000bd9d8:     	and	w16, w15, #0xf
1000bd9dc:     	cmp	w16, #8
1000bd9e0:     	csel	w16, wzr, w11, lo
1000bd9e4:     	bfxil	w16, w15, #0, #4
1000bd9e8:     	scvtf	s4, w16
1000bd9ec:     	fmsub	s1, s4, s3, s1
1000bd9f0:     	str	s1, [x3, #12]
1000bd9f4:     	ldrb	w15, [x14, #16]
1000bd9f8:     	lsr	w15, w15, w13
1000bd9fc:     	and	w16, w15, #0xf
1000bda00:     	cmp	w16, #8
1000bda04:     	csel	w16, wzr, w11, lo
1000bda08:     	bfxil	w16, w15, #0, #4
1000bda0c:     	scvtf	s4, w16
1000bda10:     	fmsub	s2, s4, s3, s2
1000bda14:     	str	s2, [x3, #16]
1000bda18:     	ldrb	w15, [x14, #20]
1000bda1c:     	lsr	w15, w15, w13
1000bda20:     	and	w16, w15, #0xf
1000bda24:     	cmp	w16, #8
1000bda28:     	csel	w16, wzr, w11, lo
1000bda2c:     	bfxil	w16, w15, #0, #4
1000bda30:     	scvtf	s4, w16
1000bda34:     	ldp	s5, s6, [x3, #20]
1000bda38:     	fmsub	s4, s4, s3, s5
1000bda3c:     	str	s4, [x3, #20]
1000bda40:     	ldrb	w14, [x14, #24]
1000bda44:     	lsr	w14, w14, w13
1000bda48:     	and	w15, w14, #0xf
1000bda4c:     	cmp	w15, #8
1000bda50:     	csel	w15, wzr, w11, lo
1000bda54:     	bfxil	w15, w14, #0, #4
1000bda58:     	scvtf	s4, w15
1000bda5c:     	fmsub	s4, s4, s3, s6
1000bda60:     	str	s4, [x3, #24]
1000bda64:     	orr	x12, x10, x12
1000bda68:     	orr	x12, x12, #0x1c
1000bda6c:     	ldrb	w12, [x0, x12]
1000bda70:     	lsr	w12, w12, w13
1000bda74:     	and	w13, w12, #0xf
1000bda78:     	cmp	w13, #8
1000bda7c:     	csel	w13, wzr, w11, lo
1000bda80:     	bfxil	w13, w12, #0, #4
1000bda84:     	scvtf	s4, w13
1000bda88:     	ldr	s5, [x3, #28]
1000bda8c:     	fmsub	s3, s4, s3, s5
1000bda90:     	str	s3, [x3, #28]
1000bda94:     	add	x8, x8, #1
1000bda98:     	add	x10, x10, #4
1000bda9c:     	cmp	x2, x8
1000bdaa0:     	b.ne	0x1000bd924 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000bdaa4:     	ldp	x20, x19, [sp, #16]
1000bdaa8:     	ldp	x22, x21, [sp], #32
1000bdaac:     	ret

