00000001000d298c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d298c:     	stp	x28, x27, [sp, #-64]!
1000d2990:     	stp	x22, x21, [sp, #16]
1000d2994:     	stp	x20, x19, [sp, #32]
1000d2998:     	stp	x29, x30, [sp, #48]
1000d299c:     	add	x29, sp, #48
1000d29a0:     	sub	sp, sp, #1040
1000d29a4:     	mov	x19, x3
1000d29a8:     	mov	x20, x1
1000d29ac:     	mov	x21, x0
1000d29b0:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0xd8>
1000d29b4:     	ldr	x8, [x8, #392]
1000d29b8:     	ldr	x8, [x8]
1000d29bc:     	stur	x8, [x29, #-56]
1000d29c0:     	lsl	x8, x2, #2
1000d29c4:     	and	x22, x8, #0xfffffffffffffff8
1000d29c8:     	add	x0, sp, #8
1000d29cc:     	mov	w1, #1024
1000d29d0:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d29d4:     	cbz	x22, 0x1000d2aec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d29d8:     	add	x8, x20, x22
1000d29dc:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0xfc>
1000d29e0:     	add	x9, x9, #2012
1000d29e4:     	mov	x10, #0
1000d29e8:     	add	x11, sp, #8
1000d29ec:     	mov	x12, #0
1000d29f0:     	ldr	w2, [x21, x10, lsl #2]
1000d29f4:     	lsl	w13, w2, #4
1000d29f8:     	and	x13, x13, #0xf0
1000d29fc:     	and	x14, x2, #0xf0
1000d2a00:     	lsr	x15, x2, #4
1000d2a04:     	and	x15, x15, #0xf0
1000d2a08:     	lsr	x16, x2, #8
1000d2a0c:     	and	x16, x16, #0xf0
1000d2a10:     	lsr	x17, x2, #12
1000d2a14:     	and	x17, x17, #0xf0
1000d2a18:     	lsr	x0, x2, #16
1000d2a1c:     	and	x0, x0, #0xf0
1000d2a20:     	lsr	x1, x2, #20
1000d2a24:     	and	x1, x1, #0xf0
1000d2a28:     	lsr	x2, x2, #24
1000d2a2c:     	and	x2, x2, #0xf0
1000d2a30:     	mov	x3, x11
1000d2a34:     	ldr	w4, [x20, x12]
1000d2a38:     	and	x5, x4, #0xf
1000d2a3c:     	orr	x5, x13, x5
1000d2a40:     	ldrsb	w5, [x9, x5]
1000d2a44:     	ubfx	x6, x4, #4, #4
1000d2a48:     	orr	x6, x14, x6
1000d2a4c:     	ldrsb	w6, [x9, x6]
1000d2a50:     	ubfx	x7, x4, #8, #4
1000d2a54:     	orr	x7, x15, x7
1000d2a58:     	ldrsb	w7, [x9, x7]
1000d2a5c:     	add	w5, w5, w6
1000d2a60:     	add	w5, w5, w7
1000d2a64:     	ubfx	x6, x4, #12, #4
1000d2a68:     	orr	x6, x16, x6
1000d2a6c:     	ldrsb	w6, [x9, x6]
1000d2a70:     	ubfx	x7, x4, #16, #4
1000d2a74:     	orr	x7, x17, x7
1000d2a78:     	ldrsb	w7, [x9, x7]
1000d2a7c:     	add	w5, w5, w6
1000d2a80:     	add	w5, w5, w7
1000d2a84:     	ubfx	x6, x4, #20, #4
1000d2a88:     	orr	x6, x0, x6
1000d2a8c:     	ldrsb	w6, [x9, x6]
1000d2a90:     	ubfx	x7, x4, #24, #4
1000d2a94:     	orr	x7, x1, x7
1000d2a98:     	ldrsb	w7, [x9, x7]
1000d2a9c:     	add	w5, w5, w6
1000d2aa0:     	add	w5, w5, w7
1000d2aa4:     	orr	x4, x2, x4, lsr #28
1000d2aa8:     	ldrsb	w4, [x9, x4]
1000d2aac:     	add	w4, w5, w4
1000d2ab0:     	scvtf	s0, w4
1000d2ab4:     	ldr	s1, [x3]
1000d2ab8:     	fadd	s0, s1, s0
1000d2abc:     	str	s0, [x3], #128
1000d2ac0:     	add	x12, x12, #4
1000d2ac4:     	cmp	x12, #32
1000d2ac8:     	b.ne	0x1000d2a34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d2acc:     	add	x10, x10, #1
1000d2ad0:     	add	x11, x11, #4
1000d2ad4:     	cmp	x10, #32
1000d2ad8:     	b.ne	0x1000d29ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d2adc:     	add	x21, x21, #128
1000d2ae0:     	add	x20, x20, #32
1000d2ae4:     	cmp	x20, x8
1000d2ae8:     	b.ne	0x1000d29e4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d2aec:     	add	x1, sp, #8
1000d2af0:     	mov	x0, x19
1000d2af4:     	mov	w2, #1024
1000d2af8:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d2afc:     	ldur	x8, [x29, #-56]
1000d2b00:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0x228>
1000d2b04:     	ldr	x9, [x9, #392]
1000d2b08:     	ldr	x9, [x9]
1000d2b0c:     	cmp	x9, x8
1000d2b10:     	b.ne	0x1000d2b2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d2b14:     	add	sp, sp, #1040
1000d2b18:     	ldp	x29, x30, [sp, #48]
1000d2b1c:     	ldp	x20, x19, [sp, #32]
1000d2b20:     	ldp	x22, x21, [sp, #16]
1000d2b24:     	ldp	x28, x27, [sp], #64
1000d2b28:     	ret
1000d2b2c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

