00000001000c7c20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c7c20:     	stp	x28, x27, [sp, #-96]!
1000c7c24:     	stp	x26, x25, [sp, #16]
1000c7c28:     	stp	x24, x23, [sp, #32]
1000c7c2c:     	stp	x22, x21, [sp, #48]
1000c7c30:     	stp	x20, x19, [sp, #64]
1000c7c34:     	stp	x29, x30, [sp, #80]
1000c7c38:     	add	x29, sp, #80
1000c7c3c:     	sub	sp, sp, #448
1000c7c40:     	str	x3, [sp]
1000c7c44:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a8>
1000c7c48:     	ldr	x8, [x8, #392]
1000c7c4c:     	ldr	x8, [x8]
1000c7c50:     	stur	x8, [x29, #-96]
1000c7c54:     	movi.2d	v0, #0000000000000000
1000c7c58:     	stp	q0, q0, [sp, #400]
1000c7c5c:     	lsl	x8, x2, #1
1000c7c60:     	stp	q0, q0, [sp, #368]
1000c7c64:     	stp	q0, q0, [sp, #336]
1000c7c68:     	stp	q0, q0, [sp, #304]
1000c7c6c:     	stp	q0, q0, [sp, #272]
1000c7c70:     	stp	q0, q0, [sp, #240]
1000c7c74:     	stp	q0, q0, [sp, #208]
1000c7c78:     	stp	q0, q0, [sp, #176]
1000c7c7c:     	ands	x8, x8, #0xfffffffffffffffc
1000c7c80:     	b.eq	0x1000c7fa8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c7c84:     	add	x8, x1, x8
1000c7c88:     	str	x8, [sp, #8]
1000c7c8c:     	add	x8, sp, #176
1000c7c90:     	add	x27, x8, #128
1000c7c94:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000c7c98:     	add	x11, x11, #1500
1000c7c9c:     	mov	x12, #0
1000c7ca0:     	ldp	w8, w9, [x1]
1000c7ca4:     	ubfx	x10, x8, #4, #4
1000c7ca8:     	str	x10, [sp, #168]
1000c7cac:     	ubfx	x10, x8, #8, #4
1000c7cb0:     	str	x10, [sp, #160]
1000c7cb4:     	and	x10, x8, #0xf
1000c7cb8:     	str	x10, [sp, #152]
1000c7cbc:     	ubfx	x10, x8, #12, #4
1000c7cc0:     	str	x10, [sp, #144]
1000c7cc4:     	ubfx	x10, x8, #16, #4
1000c7cc8:     	str	x10, [sp, #136]
1000c7ccc:     	ubfx	x10, x8, #20, #4
1000c7cd0:     	str	x10, [sp, #128]
1000c7cd4:     	ubfx	x10, x8, #24, #4
1000c7cd8:     	lsr	x8, x8, #28
1000c7cdc:     	stp	x8, x10, [sp, #112]
1000c7ce0:     	and	x10, x9, #0xf
1000c7ce4:     	ubfx	x8, x9, #4, #4
1000c7ce8:     	stp	x8, x10, [sp, #96]
1000c7cec:     	ubfx	x10, x9, #8, #4
1000c7cf0:     	ubfx	x8, x9, #12, #4
1000c7cf4:     	stp	x8, x10, [sp, #80]
1000c7cf8:     	ubfx	x10, x9, #16, #4
1000c7cfc:     	ubfx	x8, x9, #20, #4
1000c7d00:     	stp	x8, x10, [sp, #64]
1000c7d04:     	ubfx	x10, x9, #24, #4
1000c7d08:     	lsr	x8, x9, #28
1000c7d0c:     	stp	x8, x10, [sp, #48]
1000c7d10:     	ldp	w9, w17, [x1, #8]
1000c7d14:     	and	x10, x9, #0xf
1000c7d18:     	ubfx	x8, x9, #4, #4
1000c7d1c:     	stp	x8, x10, [sp, #32]
1000c7d20:     	ubfx	x8, x9, #8, #4
1000c7d24:     	stp	x1, x8, [sp, #16]
1000c7d28:     	ubfx	x28, x9, #12, #4
1000c7d2c:     	ubfx	x30, x9, #16, #4
1000c7d30:     	ubfx	x8, x9, #20, #4
1000c7d34:     	ubfx	x3, x9, #24, #4
1000c7d38:     	lsr	x9, x9, #28
1000c7d3c:     	and	x1, x17, #0xf
1000c7d40:     	ubfx	x10, x17, #4, #4
1000c7d44:     	ubfx	x13, x17, #8, #4
1000c7d48:     	ubfx	x26, x17, #12, #4
1000c7d4c:     	ubfx	x14, x17, #16, #4
1000c7d50:     	ubfx	x15, x17, #20, #4
1000c7d54:     	ubfx	x16, x17, #24, #4
1000c7d58:     	lsr	x17, x17, #28
1000c7d5c:     	ldr	w21, [x0, x12]
1000c7d60:     	lsl	w2, w21, #4
1000c7d64:     	and	x2, x2, #0xf0
1000c7d68:     	ldp	x4, x19, [sp, #152]
1000c7d6c:     	orr	x4, x2, x4
1000c7d70:     	ldrsb	w6, [x11, x4]
1000c7d74:     	and	x4, x21, #0xf0
1000c7d78:     	ldr	x5, [sp, #168]
1000c7d7c:     	orr	x5, x4, x5
1000c7d80:     	ldrsb	w7, [x11, x5]
1000c7d84:     	lsr	x5, x21, #4
1000c7d88:     	and	x5, x5, #0xf0
1000c7d8c:     	orr	x19, x5, x19
1000c7d90:     	ldrsb	w19, [x11, x19]
1000c7d94:     	add	w6, w6, w7
1000c7d98:     	add	w19, w6, w19
1000c7d9c:     	lsr	x6, x21, #8
1000c7da0:     	and	x6, x6, #0xf0
1000c7da4:     	ldp	x22, x7, [sp, #136]
1000c7da8:     	orr	x7, x6, x7
1000c7dac:     	ldrsb	w20, [x11, x7]
1000c7db0:     	lsr	x7, x21, #12
1000c7db4:     	and	x7, x7, #0xf0
1000c7db8:     	orr	x22, x7, x22
1000c7dbc:     	ldrsb	w22, [x11, x22]
1000c7dc0:     	add	w19, w19, w20
1000c7dc4:     	add	w22, w19, w22
1000c7dc8:     	lsr	x19, x21, #16
1000c7dcc:     	and	x19, x19, #0xf0
1000c7dd0:     	ldp	x24, x20, [sp, #120]
1000c7dd4:     	orr	x20, x19, x20
1000c7dd8:     	ldrsb	w23, [x11, x20]
1000c7ddc:     	lsr	x20, x21, #20
1000c7de0:     	and	x20, x20, #0xf0
1000c7de4:     	orr	x24, x20, x24
1000c7de8:     	ldrsb	w24, [x11, x24]
1000c7dec:     	add	w22, w22, w23
1000c7df0:     	add	w22, w22, w24
1000c7df4:     	lsr	x21, x21, #24
1000c7df8:     	and	x21, x21, #0xf0
1000c7dfc:     	ldr	x23, [sp, #112]
1000c7e00:     	orr	x23, x21, x23
1000c7e04:     	ldrsb	w23, [x11, x23]
1000c7e08:     	add	w22, w22, w23
1000c7e0c:     	scvtf	s0, w22
1000c7e10:     	ldp	x23, x22, [sp, #96]
1000c7e14:     	orr	x22, x2, x22
1000c7e18:     	ldrsb	w22, [x11, x22]
1000c7e1c:     	orr	x23, x4, x23
1000c7e20:     	ldrsb	w23, [x11, x23]
1000c7e24:     	ldr	x24, [sp, #88]
1000c7e28:     	orr	x24, x5, x24
1000c7e2c:     	ldrsb	w24, [x11, x24]
1000c7e30:     	add	w22, w22, w23
1000c7e34:     	add	w22, w22, w24
1000c7e38:     	ldp	x24, x23, [sp, #72]
1000c7e3c:     	orr	x23, x6, x23
1000c7e40:     	ldrsb	w23, [x11, x23]
1000c7e44:     	orr	x24, x7, x24
1000c7e48:     	ldrsb	w24, [x11, x24]
1000c7e4c:     	ldr	x25, [sp, #64]
1000c7e50:     	orr	x25, x19, x25
1000c7e54:     	ldrsb	w25, [x11, x25]
1000c7e58:     	add	w22, w22, w23
1000c7e5c:     	add	w22, w22, w24
1000c7e60:     	ldr	x23, [sp, #56]
1000c7e64:     	orr	x23, x20, x23
1000c7e68:     	ldrsb	w23, [x11, x23]
1000c7e6c:     	add	w22, w22, w25
1000c7e70:     	add	w22, w22, w23
1000c7e74:     	ldr	x23, [sp, #48]
1000c7e78:     	orr	x23, x21, x23
1000c7e7c:     	ldrsb	w23, [x11, x23]
1000c7e80:     	add	w22, w22, w23
1000c7e84:     	scvtf	s1, w22
1000c7e88:     	ldp	x23, x22, [sp, #32]
1000c7e8c:     	orr	x22, x2, x22
1000c7e90:     	ldrsb	w22, [x11, x22]
1000c7e94:     	orr	x23, x4, x23
1000c7e98:     	ldrsb	w23, [x11, x23]
1000c7e9c:     	ldr	x24, [sp, #24]
1000c7ea0:     	orr	x24, x5, x24
1000c7ea4:     	ldrsb	w24, [x11, x24]
1000c7ea8:     	add	w22, w22, w23
1000c7eac:     	add	w22, w22, w24
1000c7eb0:     	orr	x23, x6, x28
1000c7eb4:     	ldrsb	w23, [x11, x23]
1000c7eb8:     	orr	x24, x7, x30
1000c7ebc:     	ldrsb	w24, [x11, x24]
1000c7ec0:     	orr	x25, x19, x8
1000c7ec4:     	ldrsb	w25, [x11, x25]
1000c7ec8:     	add	w22, w22, w23
1000c7ecc:     	orr	x23, x20, x3
1000c7ed0:     	ldrsb	w23, [x11, x23]
1000c7ed4:     	add	w22, w22, w24
1000c7ed8:     	add	w22, w22, w25
1000c7edc:     	add	w22, w22, w23
1000c7ee0:     	orr	x23, x21, x9
1000c7ee4:     	ldrsb	w23, [x11, x23]
1000c7ee8:     	add	w22, w22, w23
1000c7eec:     	scvtf	s2, w22
1000c7ef0:     	orr	x2, x2, x1
1000c7ef4:     	ldrsb	w2, [x11, x2]
1000c7ef8:     	orr	x4, x4, x10
1000c7efc:     	ldrsb	w4, [x11, x4]
1000c7f00:     	orr	x5, x5, x13
1000c7f04:     	ldrsb	w5, [x11, x5]
1000c7f08:     	add	w2, w2, w4
1000c7f0c:     	add	w2, w2, w5
1000c7f10:     	orr	x4, x6, x26
1000c7f14:     	ldrsb	w4, [x11, x4]
1000c7f18:     	orr	x5, x7, x14
1000c7f1c:     	ldrsb	w5, [x11, x5]
1000c7f20:     	add	w2, w2, w4
1000c7f24:     	orr	x4, x19, x15
1000c7f28:     	ldrsb	w4, [x11, x4]
1000c7f2c:     	add	w2, w2, w5
1000c7f30:     	orr	x5, x20, x16
1000c7f34:     	ldrsb	w5, [x11, x5]
1000c7f38:     	add	w2, w2, w4
1000c7f3c:     	add	w2, w2, w5
1000c7f40:     	orr	x4, x21, x17
1000c7f44:     	ldrsb	w4, [x11, x4]
1000c7f48:     	add	w2, w2, w4
1000c7f4c:     	add	x4, sp, #176
1000c7f50:     	scvtf	s3, w2
1000c7f54:     	add	x2, x27, x12
1000c7f58:     	ldur	s4, [x2, #-64]
1000c7f5c:     	fadd	s1, s4, s1
1000c7f60:     	stur	s1, [x2, #-64]
1000c7f64:     	ldr	s1, [x2]
1000c7f68:     	fadd	s1, s1, s2
1000c7f6c:     	str	s1, [x2]
1000c7f70:     	ldr	s1, [x2, #64]
1000c7f74:     	fadd	s1, s1, s3
1000c7f78:     	ldr	s2, [x4, x12]
1000c7f7c:     	str	s1, [x2, #64]
1000c7f80:     	fadd	s0, s2, s0
1000c7f84:     	str	s0, [x4, x12]
1000c7f88:     	add	x12, x12, #4
1000c7f8c:     	cmp	x12, #64
1000c7f90:     	b.ne	0x1000c7d5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c7f94:     	add	x0, x0, #64
1000c7f98:     	ldp	x8, x1, [sp, #8]
1000c7f9c:     	add	x1, x1, #16
1000c7fa0:     	cmp	x1, x8
1000c7fa4:     	b.ne	0x1000c7c9c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c7fa8:     	ldp	q0, q1, [sp, #368]
1000c7fac:     	ldr	x8, [sp]
1000c7fb0:     	stp	q0, q1, [x8, #192]
1000c7fb4:     	ldp	q0, q1, [sp, #400]
1000c7fb8:     	stp	q0, q1, [x8, #224]
1000c7fbc:     	ldp	q0, q1, [sp, #304]
1000c7fc0:     	stp	q0, q1, [x8, #128]
1000c7fc4:     	ldp	q0, q1, [sp, #336]
1000c7fc8:     	stp	q0, q1, [x8, #160]
1000c7fcc:     	ldp	q0, q1, [sp, #240]
1000c7fd0:     	stp	q0, q1, [x8, #64]
1000c7fd4:     	ldp	q0, q1, [sp, #272]
1000c7fd8:     	stp	q0, q1, [x8, #96]
1000c7fdc:     	ldp	q0, q1, [sp, #176]
1000c7fe0:     	stp	q0, q1, [x8]
1000c7fe4:     	ldp	q0, q1, [sp, #208]
1000c7fe8:     	stp	q0, q1, [x8, #32]
1000c7fec:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 8ul, false>(char const*)+0x248>
1000c7ff0:     	ldr	x8, [x8, #392]
1000c7ff4:     	ldr	x8, [x8]
1000c7ff8:     	ldur	x9, [x29, #-96]
1000c7ffc:     	cmp	x8, x9
1000c8000:     	b.ne	0x1000c8024 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x404>
1000c8004:     	add	sp, sp, #448
1000c8008:     	ldp	x29, x30, [sp, #80]
1000c800c:     	ldp	x20, x19, [sp, #64]
1000c8010:     	ldp	x22, x21, [sp, #48]
1000c8014:     	ldp	x24, x23, [sp, #32]
1000c8018:     	ldp	x26, x25, [sp, #16]
1000c801c:     	ldp	x28, x27, [sp], #96
1000c8020:     	ret
1000c8024:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

