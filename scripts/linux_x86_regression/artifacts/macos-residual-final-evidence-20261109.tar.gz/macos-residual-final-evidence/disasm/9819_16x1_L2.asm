00000001000c4124 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c4124:     	stp	x22, x21, [sp, #-32]!
1000c4128:     	stp	x20, x19, [sp, #16]
1000c412c:     	movi.2d	v0, #0000000000000000
1000c4130:     	stp	q0, q0, [x3, #32]
1000c4134:     	stp	q0, q0, [x3]
1000c4138:     	cmp	x2, #8
1000c413c:     	b.hs	0x1000c4148 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c4140:     	mov	x8, #0
1000c4144:     	b	0x1000c4258 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c4148:     	mov	x8, #0
1000c414c:     	mov	w14, #8
1000c4150:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b4>
1000c4154:     	add	x9, x9, #1244
1000c4158:     	mov	x10, x0
1000c415c:     	mov	x11, #0
1000c4160:     	lsr	x8, x8, #1
1000c4164:     	mul	x8, x8, x4
1000c4168:     	ldr	w6, [x1, x8]
1000c416c:     	ubfx	x12, x6, #4, #4
1000c4170:     	ubfx	x13, x6, #8, #4
1000c4174:     	mov	x8, x14
1000c4178:     	ubfx	x14, x6, #12, #4
1000c417c:     	and	x15, x6, #0xf
1000c4180:     	ubfx	x16, x6, #16, #4
1000c4184:     	ubfx	x17, x6, #20, #4
1000c4188:     	ubfx	x5, x6, #24, #4
1000c418c:     	lsr	x6, x6, #28
1000c4190:     	ldr	w7, [x10, x11]
1000c4194:     	lsl	w19, w7, #4
1000c4198:     	and	x19, x19, #0xf0
1000c419c:     	orr	x19, x19, x15
1000c41a0:     	ldrb	w19, [x9, x19]
1000c41a4:     	and	x20, x7, #0xf0
1000c41a8:     	orr	x20, x20, x12
1000c41ac:     	ldrb	w20, [x9, x20]
1000c41b0:     	lsr	x21, x7, #4
1000c41b4:     	and	x21, x21, #0xf0
1000c41b8:     	orr	x21, x21, x13
1000c41bc:     	ldrb	w21, [x9, x21]
1000c41c0:     	lsr	x22, x7, #8
1000c41c4:     	and	x22, x22, #0xf0
1000c41c8:     	orr	x22, x22, x14
1000c41cc:     	ldrb	w22, [x9, x22]
1000c41d0:     	add	w19, w19, w20
1000c41d4:     	add	w19, w19, w21
1000c41d8:     	lsr	x20, x7, #12
1000c41dc:     	and	x20, x20, #0xf0
1000c41e0:     	orr	x20, x20, x16
1000c41e4:     	ldrb	w20, [x9, x20]
1000c41e8:     	lsr	x21, x7, #16
1000c41ec:     	and	x21, x21, #0xf0
1000c41f0:     	orr	x21, x21, x17
1000c41f4:     	ldrb	w21, [x9, x21]
1000c41f8:     	add	w19, w19, w22
1000c41fc:     	add	w19, w19, w20
1000c4200:     	lsr	x20, x7, #20
1000c4204:     	and	x20, x20, #0xf0
1000c4208:     	orr	x20, x20, x5
1000c420c:     	ldrb	w20, [x9, x20]
1000c4210:     	lsr	x7, x7, #24
1000c4214:     	and	x7, x7, #0xf0
1000c4218:     	orr	x7, x7, x6
1000c421c:     	ldrb	w7, [x9, x7]
1000c4220:     	add	w19, w19, w21
1000c4224:     	add	w19, w19, w20
1000c4228:     	add	w7, w19, w7
1000c422c:     	scvtf	s0, w7
1000c4230:     	ldr	s1, [x3, x11]
1000c4234:     	fadd	s0, s1, s0
1000c4238:     	str	s0, [x3, x11]
1000c423c:     	add	x11, x11, #4
1000c4240:     	cmp	x11, #64
1000c4244:     	b.ne	0x1000c4190 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x6c>
1000c4248:     	add	x14, x8, #8
1000c424c:     	add	x10, x10, #64
1000c4250:     	cmp	x14, x2
1000c4254:     	b.ls	0x1000c415c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c4258:     	cmp	x8, x2
1000c425c:     	b.hs	0x1000c4554 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x430>
1000c4260:     	lsl	x9, x4, #2
1000c4264:     	lsl	w10, w8, #2
1000c4268:     	mov	w11, #-16
1000c426c:     	lsr	x13, x8, #3
1000c4270:     	mul	x12, x9, x13
1000c4274:     	ubfx	x14, x8, #1, #2
1000c4278:     	orr	x15, x12, x14
1000c427c:     	and	w12, w10, #0x4
1000c4280:     	ldrb	w15, [x1, x15]
1000c4284:     	lsr	w15, w15, w12
1000c4288:     	and	w16, w15, #0xf
1000c428c:     	cmp	w16, #8
1000c4290:     	csel	w16, wzr, w11, lo
1000c4294:     	bfi	x14, x13, #6, #58
1000c4298:     	bfxil	w16, w15, #0, #4
1000c429c:     	add	x13, x0, x14
1000c42a0:     	ldrb	w14, [x13]
1000c42a4:     	lsr	w14, w14, w12
1000c42a8:     	and	w15, w14, #0xf
1000c42ac:     	scvtf	s0, w16
1000c42b0:     	cmp	w15, #8
1000c42b4:     	csel	w15, wzr, w11, lo
1000c42b8:     	bfxil	w15, w14, #0, #4
1000c42bc:     	scvtf	s1, w15
1000c42c0:     	fsub	s1, s1, s0
1000c42c4:     	ldp	s2, s3, [x3]
1000c42c8:     	fmadd	s1, s1, s1, s2
1000c42cc:     	str	s1, [x3]
1000c42d0:     	ldrb	w14, [x13, #4]
1000c42d4:     	lsr	w14, w14, w12
1000c42d8:     	and	w15, w14, #0xf
1000c42dc:     	cmp	w15, #8
1000c42e0:     	csel	w15, wzr, w11, lo
1000c42e4:     	bfxil	w15, w14, #0, #4
1000c42e8:     	scvtf	s1, w15
1000c42ec:     	fsub	s1, s1, s0
1000c42f0:     	fmadd	s1, s1, s1, s3
1000c42f4:     	str	s1, [x3, #4]
1000c42f8:     	ldrb	w14, [x13, #8]
1000c42fc:     	lsr	w14, w14, w12
1000c4300:     	and	w15, w14, #0xf
1000c4304:     	cmp	w15, #8
1000c4308:     	csel	w15, wzr, w11, lo
1000c430c:     	bfxil	w15, w14, #0, #4
1000c4310:     	scvtf	s1, w15
1000c4314:     	fsub	s1, s1, s0
1000c4318:     	ldp	s2, s3, [x3, #8]
1000c431c:     	fmadd	s1, s1, s1, s2
1000c4320:     	str	s1, [x3, #8]
1000c4324:     	ldrb	w14, [x13, #12]
1000c4328:     	lsr	w14, w14, w12
1000c432c:     	and	w15, w14, #0xf
1000c4330:     	cmp	w15, #8
1000c4334:     	csel	w15, wzr, w11, lo
1000c4338:     	bfxil	w15, w14, #0, #4
1000c433c:     	scvtf	s1, w15
1000c4340:     	fsub	s1, s1, s0
1000c4344:     	fmadd	s1, s1, s1, s3
1000c4348:     	str	s1, [x3, #12]
1000c434c:     	ldrb	w14, [x13, #16]
1000c4350:     	lsr	w14, w14, w12
1000c4354:     	and	w15, w14, #0xf
1000c4358:     	cmp	w15, #8
1000c435c:     	csel	w15, wzr, w11, lo
1000c4360:     	bfxil	w15, w14, #0, #4
1000c4364:     	scvtf	s1, w15
1000c4368:     	fsub	s1, s1, s0
1000c436c:     	ldp	s2, s3, [x3, #16]
1000c4370:     	fmadd	s1, s1, s1, s2
1000c4374:     	str	s1, [x3, #16]
1000c4378:     	ldrb	w14, [x13, #20]
1000c437c:     	lsr	w14, w14, w12
1000c4380:     	and	w15, w14, #0xf
1000c4384:     	cmp	w15, #8
1000c4388:     	csel	w15, wzr, w11, lo
1000c438c:     	bfxil	w15, w14, #0, #4
1000c4390:     	scvtf	s1, w15
1000c4394:     	fsub	s1, s1, s0
1000c4398:     	fmadd	s1, s1, s1, s3
1000c439c:     	str	s1, [x3, #20]
1000c43a0:     	ldrb	w14, [x13, #24]
1000c43a4:     	lsr	w14, w14, w12
1000c43a8:     	and	w15, w14, #0xf
1000c43ac:     	cmp	w15, #8
1000c43b0:     	csel	w15, wzr, w11, lo
1000c43b4:     	bfxil	w15, w14, #0, #4
1000c43b8:     	scvtf	s1, w15
1000c43bc:     	fsub	s1, s1, s0
1000c43c0:     	ldp	s2, s3, [x3, #24]
1000c43c4:     	fmadd	s1, s1, s1, s2
1000c43c8:     	str	s1, [x3, #24]
1000c43cc:     	ldrb	w14, [x13, #28]
1000c43d0:     	lsr	w14, w14, w12
1000c43d4:     	and	w15, w14, #0xf
1000c43d8:     	cmp	w15, #8
1000c43dc:     	csel	w15, wzr, w11, lo
1000c43e0:     	bfxil	w15, w14, #0, #4
1000c43e4:     	scvtf	s1, w15
1000c43e8:     	fsub	s1, s1, s0
1000c43ec:     	fmadd	s1, s1, s1, s3
1000c43f0:     	str	s1, [x3, #28]
1000c43f4:     	ldrb	w14, [x13, #32]
1000c43f8:     	lsr	w14, w14, w12
1000c43fc:     	and	w15, w14, #0xf
1000c4400:     	cmp	w15, #8
1000c4404:     	csel	w15, wzr, w11, lo
1000c4408:     	bfxil	w15, w14, #0, #4
1000c440c:     	scvtf	s1, w15
1000c4410:     	fsub	s1, s1, s0
1000c4414:     	ldp	s2, s3, [x3, #32]
1000c4418:     	fmadd	s1, s1, s1, s2
1000c441c:     	str	s1, [x3, #32]
1000c4420:     	ldrb	w14, [x13, #36]
1000c4424:     	lsr	w14, w14, w12
1000c4428:     	and	w15, w14, #0xf
1000c442c:     	cmp	w15, #8
1000c4430:     	csel	w15, wzr, w11, lo
1000c4434:     	bfxil	w15, w14, #0, #4
1000c4438:     	scvtf	s1, w15
1000c443c:     	fsub	s1, s1, s0
1000c4440:     	fmadd	s1, s1, s1, s3
1000c4444:     	str	s1, [x3, #36]
1000c4448:     	ldrb	w14, [x13, #40]
1000c444c:     	lsr	w14, w14, w12
1000c4450:     	and	w15, w14, #0xf
1000c4454:     	cmp	w15, #8
1000c4458:     	csel	w15, wzr, w11, lo
1000c445c:     	bfxil	w15, w14, #0, #4
1000c4460:     	scvtf	s1, w15
1000c4464:     	fsub	s1, s1, s0
1000c4468:     	ldp	s2, s3, [x3, #40]
1000c446c:     	fmadd	s1, s1, s1, s2
1000c4470:     	str	s1, [x3, #40]
1000c4474:     	ldrb	w14, [x13, #44]
1000c4478:     	lsr	w14, w14, w12
1000c447c:     	and	w15, w14, #0xf
1000c4480:     	cmp	w15, #8
1000c4484:     	csel	w15, wzr, w11, lo
1000c4488:     	bfxil	w15, w14, #0, #4
1000c448c:     	scvtf	s1, w15
1000c4490:     	fsub	s1, s1, s0
1000c4494:     	fmadd	s1, s1, s1, s3
1000c4498:     	str	s1, [x3, #44]
1000c449c:     	ldrb	w14, [x13, #48]
1000c44a0:     	lsr	w14, w14, w12
1000c44a4:     	and	w15, w14, #0xf
1000c44a8:     	cmp	w15, #8
1000c44ac:     	csel	w15, wzr, w11, lo
1000c44b0:     	bfxil	w15, w14, #0, #4
1000c44b4:     	scvtf	s1, w15
1000c44b8:     	fsub	s1, s1, s0
1000c44bc:     	ldp	s2, s3, [x3, #48]
1000c44c0:     	fmadd	s1, s1, s1, s2
1000c44c4:     	str	s1, [x3, #48]
1000c44c8:     	ldrb	w14, [x13, #52]
1000c44cc:     	lsr	w14, w14, w12
1000c44d0:     	and	w15, w14, #0xf
1000c44d4:     	cmp	w15, #8
1000c44d8:     	csel	w15, wzr, w11, lo
1000c44dc:     	bfxil	w15, w14, #0, #4
1000c44e0:     	scvtf	s1, w15
1000c44e4:     	fsub	s1, s1, s0
1000c44e8:     	fmadd	s1, s1, s1, s3
1000c44ec:     	str	s1, [x3, #52]
1000c44f0:     	ldrb	w14, [x13, #56]
1000c44f4:     	lsr	w14, w14, w12
1000c44f8:     	and	w15, w14, #0xf
1000c44fc:     	cmp	w15, #8
1000c4500:     	csel	w15, wzr, w11, lo
1000c4504:     	bfxil	w15, w14, #0, #4
1000c4508:     	scvtf	s1, w15
1000c450c:     	fsub	s1, s1, s0
1000c4510:     	ldp	s2, s3, [x3, #56]
1000c4514:     	fmadd	s1, s1, s1, s2
1000c4518:     	str	s1, [x3, #56]
1000c451c:     	ldrb	w13, [x13, #60]
1000c4520:     	lsr	w12, w13, w12
1000c4524:     	and	w13, w12, #0xf
1000c4528:     	cmp	w13, #8
1000c452c:     	csel	w13, wzr, w11, lo
1000c4530:     	bfxil	w13, w12, #0, #4
1000c4534:     	scvtf	s1, w13
1000c4538:     	fsub	s0, s1, s0
1000c453c:     	fmadd	s0, s0, s0, s3
1000c4540:     	str	s0, [x3, #60]
1000c4544:     	add	x8, x8, #1
1000c4548:     	add	w10, w10, #4
1000c454c:     	cmp	x2, x8
1000c4550:     	b.ne	0x1000c426c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c4554:     	ldp	x20, x19, [sp, #16]
1000c4558:     	ldp	x22, x21, [sp], #32
1000c455c:     	ret

