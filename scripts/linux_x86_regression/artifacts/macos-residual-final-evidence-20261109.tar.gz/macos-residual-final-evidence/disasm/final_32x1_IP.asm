00000001000cfe1c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000cfe1c:     	stp	x22, x21, [sp, #-32]!
1000cfe20:     	stp	x20, x19, [sp, #16]
1000cfe24:     	movi.2d	v0, #0000000000000000
1000cfe28:     	stp	q0, q0, [x3, #96]
1000cfe2c:     	stp	q0, q0, [x3, #64]
1000cfe30:     	stp	q0, q0, [x3, #32]
1000cfe34:     	stp	q0, q0, [x3]
1000cfe38:     	cmp	x2, #8
1000cfe3c:     	b.hs	0x1000cfe48 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000cfe40:     	mov	x8, #0
1000cfe44:     	b	0x1000cff58 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000cfe48:     	mov	x8, #0
1000cfe4c:     	mov	w12, #8
1000cfe50:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 2ul, false>(char const*)+0xc8>
1000cfe54:     	add	x9, x9, #1980
1000cfe58:     	mov	x10, x0
1000cfe5c:     	mov	x11, #0
1000cfe60:     	lsr	x8, x8, #1
1000cfe64:     	mul	x8, x8, x4
1000cfe68:     	ldr	w6, [x1, x8]
1000cfe6c:     	mov	x8, x12
1000cfe70:     	lsl	w12, w6, #4
1000cfe74:     	and	x12, x12, #0xf0
1000cfe78:     	add	x12, x9, x12
1000cfe7c:     	and	x13, x6, #0xf0
1000cfe80:     	add	x13, x9, x13
1000cfe84:     	lsr	x14, x6, #4
1000cfe88:     	and	x14, x14, #0xf0
1000cfe8c:     	add	x14, x9, x14
1000cfe90:     	lsr	x15, x6, #8
1000cfe94:     	and	x15, x15, #0xf0
1000cfe98:     	add	x15, x9, x15
1000cfe9c:     	lsr	x16, x6, #12
1000cfea0:     	and	x16, x16, #0xf0
1000cfea4:     	add	x16, x9, x16
1000cfea8:     	lsr	x17, x6, #16
1000cfeac:     	and	x17, x17, #0xf0
1000cfeb0:     	add	x17, x9, x17
1000cfeb4:     	lsr	x5, x6, #20
1000cfeb8:     	and	x5, x5, #0xf0
1000cfebc:     	add	x5, x9, x5
1000cfec0:     	lsr	x6, x6, #24
1000cfec4:     	and	x6, x6, #0xf0
1000cfec8:     	add	x6, x9, x6
1000cfecc:     	ldr	w7, [x10, x11]
1000cfed0:     	and	x19, x7, #0xf
1000cfed4:     	ldrsb	w19, [x12, x19]
1000cfed8:     	ubfx	x20, x7, #4, #4
1000cfedc:     	ldrsb	w20, [x13, x20]
1000cfee0:     	ubfx	x21, x7, #8, #4
1000cfee4:     	ldrsb	w21, [x14, x21]
1000cfee8:     	add	w19, w19, w20
1000cfeec:     	add	w19, w19, w21
1000cfef0:     	ubfx	x20, x7, #12, #4
1000cfef4:     	ldrsb	w20, [x15, x20]
1000cfef8:     	ubfx	x21, x7, #16, #4
1000cfefc:     	ldrsb	w21, [x16, x21]
1000cff00:     	add	w19, w19, w20
1000cff04:     	add	w19, w19, w21
1000cff08:     	ubfx	x20, x7, #20, #4
1000cff0c:     	ldrsb	w20, [x17, x20]
1000cff10:     	ubfx	x21, x7, #24, #4
1000cff14:     	ldrsb	w21, [x5, x21]
1000cff18:     	lsr	x7, x7, #28
1000cff1c:     	ldrsb	w7, [x6, x7]
1000cff20:     	add	w19, w19, w20
1000cff24:     	add	w19, w19, w21
1000cff28:     	add	w7, w19, w7
1000cff2c:     	scvtf	s0, w7
1000cff30:     	ldr	s1, [x3, x11]
1000cff34:     	fadd	s0, s1, s0
1000cff38:     	str	s0, [x3, x11]
1000cff3c:     	add	x11, x11, #4
1000cff40:     	cmp	x11, #128
1000cff44:     	b.ne	0x1000cfecc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000cff48:     	add	x12, x8, #8
1000cff4c:     	add	x10, x10, #128
1000cff50:     	cmp	x12, x2
1000cff54:     	b.ls	0x1000cfe5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000cff58:     	cmp	x8, x2
1000cff5c:     	b.hs	0x1000cffe8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1cc>
1000cff60:     	lsl	x9, x4, #2
1000cff64:     	mov	w10, #-16
1000cff68:     	mov	x11, #0
1000cff6c:     	lsr	x13, x8, #3
1000cff70:     	lsl	x12, x13, #7
1000cff74:     	mul	x14, x9, x13
1000cff78:     	ubfx	x13, x8, #1, #2
1000cff7c:     	orr	x14, x14, x13
1000cff80:     	ldrb	w15, [x1, x14]
1000cff84:     	ubfiz	w14, w8, #2, #1
1000cff88:     	lsr	w15, w15, w14
1000cff8c:     	and	w16, w15, #0xf
1000cff90:     	cmp	w16, #8
1000cff94:     	csel	w16, wzr, w10, lo
1000cff98:     	bfxil	w16, w15, #0, #4
1000cff9c:     	scvtf	s0, w16
1000cffa0:     	add	x15, x12, x11
1000cffa4:     	orr	x15, x15, x13
1000cffa8:     	ldrb	w15, [x0, x15]
1000cffac:     	lsr	w15, w15, w14
1000cffb0:     	and	w16, w15, #0xf
1000cffb4:     	cmp	w16, #8
1000cffb8:     	csel	w16, wzr, w10, lo
1000cffbc:     	bfxil	w16, w15, #0, #4
1000cffc0:     	scvtf	s1, w16
1000cffc4:     	ldr	s2, [x3, x11]
1000cffc8:     	fmsub	s1, s1, s0, s2
1000cffcc:     	str	s1, [x3, x11]
1000cffd0:     	add	x11, x11, #4
1000cffd4:     	cmp	x11, #128
1000cffd8:     	b.ne	0x1000cffa0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000cffdc:     	add	x8, x8, #1
1000cffe0:     	cmp	x8, x2
1000cffe4:     	b.ne	0x1000cff68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000cffe8:     	ldp	x20, x19, [sp, #16]
1000cffec:     	ldp	x22, x21, [sp], #32
1000cfff0:     	ret

