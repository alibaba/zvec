00000001000d5874 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5874:     	stp	x28, x27, [sp, #-96]!
1000d5878:     	stp	x26, x25, [sp, #16]
1000d587c:     	stp	x24, x23, [sp, #32]
1000d5880:     	stp	x22, x21, [sp, #48]
1000d5884:     	stp	x20, x19, [sp, #64]
1000d5888:     	stp	x29, x30, [sp, #80]
1000d588c:     	add	x29, sp, #80
1000d5890:     	sub	sp, sp, #1488
1000d5894:     	str	x3, [sp]
1000d5898:     	mov	x20, x1
1000d589c:     	mov	x22, x0
1000d58a0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d58a4:     	ldr	x8, [x8, #392]
1000d58a8:     	ldr	x8, [x8]
1000d58ac:     	stur	x8, [x29, #-96]
1000d58b0:     	lsl	x8, x2, #2
1000d58b4:     	and	x19, x8, #0xfffffffffffffff8
1000d58b8:     	add	x0, sp, #448
1000d58bc:     	mov	w1, #1024
1000d58c0:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d58c4:     	cbz	x19, 0x1000d5df0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d58c8:     	add	x8, x20, x19
1000d58cc:     	str	x8, [sp, #8]
1000d58d0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d58d4:     	add	x9, x9, #1724
1000d58d8:     	mov	x10, #0
1000d58dc:     	ldp	w8, w11, [x20]
1000d58e0:     	ubfx	x13, x8, #8, #4
1000d58e4:     	ubfx	x12, x8, #16, #4
1000d58e8:     	stp	x12, x13, [sp, #432]
1000d58ec:     	ubfx	x15, x8, #24, #4
1000d58f0:     	ldp	w12, w13, [x20, #8]
1000d58f4:     	and	x14, x8, #0xf
1000d58f8:     	stp	x14, x15, [sp, #416]
1000d58fc:     	ubfx	x15, x8, #4, #4
1000d5900:     	ubfx	x14, x8, #12, #4
1000d5904:     	stp	x14, x15, [sp, #400]
1000d5908:     	ubfx	x14, x8, #20, #4
1000d590c:     	lsr	x8, x8, #28
1000d5910:     	stp	x8, x14, [sp, #384]
1000d5914:     	and	x8, x11, #0xf
1000d5918:     	str	x8, [sp, #376]
1000d591c:     	ubfx	x8, x11, #8, #4
1000d5920:     	str	x8, [sp, #368]
1000d5924:     	ubfx	x8, x11, #16, #4
1000d5928:     	str	x8, [sp, #360]
1000d592c:     	ubfx	x8, x11, #24, #4
1000d5930:     	str	x8, [sp, #352]
1000d5934:     	ubfx	x8, x11, #4, #4
1000d5938:     	str	x8, [sp, #344]
1000d593c:     	ubfx	x8, x11, #12, #4
1000d5940:     	str	x8, [sp, #336]
1000d5944:     	ubfx	x8, x11, #20, #4
1000d5948:     	str	x8, [sp, #328]
1000d594c:     	lsr	x8, x11, #28
1000d5950:     	str	x8, [sp, #320]
1000d5954:     	and	x11, x12, #0xf
1000d5958:     	ubfx	x8, x12, #8, #4
1000d595c:     	stp	x8, x11, [sp, #304]
1000d5960:     	ubfx	x11, x12, #16, #4
1000d5964:     	ubfx	x8, x12, #24, #4
1000d5968:     	stp	x8, x11, [sp, #288]
1000d596c:     	ubfx	x11, x12, #4, #4
1000d5970:     	ubfx	x8, x12, #12, #4
1000d5974:     	stp	x8, x11, [sp, #272]
1000d5978:     	ubfx	x11, x12, #20, #4
1000d597c:     	lsr	x8, x12, #28
1000d5980:     	stp	x8, x11, [sp, #256]
1000d5984:     	and	x11, x13, #0xf
1000d5988:     	ubfx	x8, x13, #8, #4
1000d598c:     	stp	x8, x11, [sp, #240]
1000d5990:     	ubfx	x11, x13, #16, #4
1000d5994:     	ubfx	x8, x13, #24, #4
1000d5998:     	stp	x8, x11, [sp, #224]
1000d599c:     	ubfx	x11, x13, #4, #4
1000d59a0:     	ubfx	x8, x13, #12, #4
1000d59a4:     	stp	x8, x11, [sp, #208]
1000d59a8:     	ubfx	x11, x13, #20, #4
1000d59ac:     	lsr	x8, x13, #28
1000d59b0:     	stp	x8, x11, [sp, #192]
1000d59b4:     	ldp	w8, w11, [x20, #16]
1000d59b8:     	and	x13, x8, #0xf
1000d59bc:     	ubfx	x12, x8, #8, #4
1000d59c0:     	stp	x12, x13, [sp, #176]
1000d59c4:     	ubfx	x13, x8, #16, #4
1000d59c8:     	ubfx	x12, x8, #24, #4
1000d59cc:     	stp	x12, x13, [sp, #160]
1000d59d0:     	ubfx	x13, x8, #4, #4
1000d59d4:     	ubfx	x12, x8, #12, #4
1000d59d8:     	stp	x12, x13, [sp, #144]
1000d59dc:     	ubfx	x12, x8, #20, #4
1000d59e0:     	lsr	x8, x8, #28
1000d59e4:     	stp	x8, x12, [sp, #128]
1000d59e8:     	and	x8, x11, #0xf
1000d59ec:     	str	x8, [sp, #120]
1000d59f0:     	ubfx	x8, x11, #8, #4
1000d59f4:     	str	x8, [sp, #112]
1000d59f8:     	ubfx	x8, x11, #16, #4
1000d59fc:     	str	x8, [sp, #104]
1000d5a00:     	ubfx	x8, x11, #24, #4
1000d5a04:     	str	x8, [sp, #96]
1000d5a08:     	ubfx	x8, x11, #4, #4
1000d5a0c:     	str	x8, [sp, #88]
1000d5a10:     	ubfx	x8, x11, #12, #4
1000d5a14:     	str	x8, [sp, #80]
1000d5a18:     	ubfx	x8, x11, #20, #4
1000d5a1c:     	str	x8, [sp, #72]
1000d5a20:     	lsr	x8, x11, #28
1000d5a24:     	str	x8, [sp, #64]
1000d5a28:     	ldp	w13, w2, [x20, #24]
1000d5a2c:     	and	x11, x13, #0xf
1000d5a30:     	ubfx	x8, x13, #8, #4
1000d5a34:     	stp	x8, x11, [sp, #48]
1000d5a38:     	ubfx	x11, x13, #16, #4
1000d5a3c:     	ubfx	x8, x13, #24, #4
1000d5a40:     	stp	x8, x11, [sp, #32]
1000d5a44:     	ubfx	x8, x13, #4, #4
1000d5a48:     	stp	x20, x8, [sp, #16]
1000d5a4c:     	ubfx	x11, x13, #12, #4
1000d5a50:     	ubfx	x12, x13, #20, #4
1000d5a54:     	lsr	x13, x13, #28
1000d5a58:     	and	x14, x2, #0xf
1000d5a5c:     	ubfx	x21, x2, #8, #4
1000d5a60:     	ubfx	x15, x2, #16, #4
1000d5a64:     	ubfx	x16, x2, #24, #4
1000d5a68:     	ubfx	x17, x2, #4, #4
1000d5a6c:     	ubfx	x0, x2, #12, #4
1000d5a70:     	ubfx	x1, x2, #20, #4
1000d5a74:     	lsr	x2, x2, #28
1000d5a78:     	ldr	w25, [x22, x10]
1000d5a7c:     	lsl	w3, w25, #4
1000d5a80:     	and	x3, x3, #0xf0
1000d5a84:     	add	x3, x9, x3
1000d5a88:     	ldr	x8, [sp, #416]
1000d5a8c:     	ldrb	w26, [x3, x8]
1000d5a90:     	lsr	x4, x25, #4
1000d5a94:     	and	x4, x4, #0xf0
1000d5a98:     	add	x4, x9, x4
1000d5a9c:     	ldr	x8, [sp, #440]
1000d5aa0:     	ldrb	w27, [x4, x8]
1000d5aa4:     	lsr	x5, x25, #12
1000d5aa8:     	and	x5, x5, #0xf0
1000d5aac:     	add	x5, x9, x5
1000d5ab0:     	ldr	x8, [sp, #432]
1000d5ab4:     	ldrb	w28, [x5, x8]
1000d5ab8:     	lsr	x6, x25, #20
1000d5abc:     	and	x6, x6, #0xf0
1000d5ac0:     	add	x7, x9, x6
1000d5ac4:     	ldr	x8, [sp, #424]
1000d5ac8:     	ldrb	w30, [x7, x8]
1000d5acc:     	and	x6, x25, #0xf0
1000d5ad0:     	add	x6, x9, x6
1000d5ad4:     	ldr	x8, [sp, #408]
1000d5ad8:     	ldrb	w19, [x6, x8]
1000d5adc:     	lsr	x23, x25, #8
1000d5ae0:     	and	x23, x23, #0xf0
1000d5ae4:     	add	x23, x9, x23
1000d5ae8:     	ldp	x20, x8, [sp, #392]
1000d5aec:     	ldrb	w8, [x23, x8]
1000d5af0:     	lsr	x24, x25, #16
1000d5af4:     	and	x24, x24, #0xf0
1000d5af8:     	add	x24, x9, x24
1000d5afc:     	ldrb	w20, [x24, x20]
1000d5b00:     	lsr	x25, x25, #24
1000d5b04:     	and	x25, x25, #0xf0
1000d5b08:     	add	x25, x9, x25
1000d5b0c:     	add	w26, w26, w27
1000d5b10:     	ldr	x27, [sp, #384]
1000d5b14:     	ldrb	w27, [x25, x27]
1000d5b18:     	add	w26, w26, w28
1000d5b1c:     	add	w26, w26, w30
1000d5b20:     	add	w19, w26, w19
1000d5b24:     	add	w8, w19, w8
1000d5b28:     	add	w8, w8, w20
1000d5b2c:     	add	w8, w8, w27
1000d5b30:     	scvtf	s0, w8
1000d5b34:     	ldp	x19, x8, [sp, #368]
1000d5b38:     	ldrb	w8, [x3, x8]
1000d5b3c:     	ldrb	w19, [x4, x19]
1000d5b40:     	ldp	x26, x20, [sp, #352]
1000d5b44:     	ldrb	w20, [x5, x20]
1000d5b48:     	ldrb	w26, [x7, x26]
1000d5b4c:     	ldp	x28, x27, [sp, #336]
1000d5b50:     	ldrb	w27, [x6, x27]
1000d5b54:     	ldrb	w28, [x23, x28]
1000d5b58:     	add	w8, w8, w19
1000d5b5c:     	ldr	x19, [sp, #328]
1000d5b60:     	ldrb	w19, [x24, x19]
1000d5b64:     	add	w8, w8, w20
1000d5b68:     	add	w8, w8, w26
1000d5b6c:     	ldr	x20, [sp, #320]
1000d5b70:     	ldrb	w20, [x25, x20]
1000d5b74:     	add	w8, w8, w27
1000d5b78:     	add	w8, w8, w28
1000d5b7c:     	add	w8, w8, w19
1000d5b80:     	add	w8, w8, w20
1000d5b84:     	scvtf	s1, w8
1000d5b88:     	ldp	x19, x8, [sp, #304]
1000d5b8c:     	ldrb	w8, [x3, x8]
1000d5b90:     	ldrb	w19, [x4, x19]
1000d5b94:     	ldp	x26, x20, [sp, #288]
1000d5b98:     	ldrb	w20, [x5, x20]
1000d5b9c:     	ldrb	w26, [x7, x26]
1000d5ba0:     	ldr	x27, [sp, #280]
1000d5ba4:     	ldrb	w27, [x6, x27]
1000d5ba8:     	add	w8, w8, w19
1000d5bac:     	ldr	x19, [sp, #272]
1000d5bb0:     	ldrb	w19, [x23, x19]
1000d5bb4:     	add	w8, w8, w20
1000d5bb8:     	ldr	x20, [sp, #264]
1000d5bbc:     	ldrb	w20, [x24, x20]
1000d5bc0:     	add	w8, w8, w26
1000d5bc4:     	ldr	x26, [sp, #256]
1000d5bc8:     	ldrb	w26, [x25, x26]
1000d5bcc:     	add	w8, w8, w27
1000d5bd0:     	add	w8, w8, w19
1000d5bd4:     	add	w8, w8, w20
1000d5bd8:     	add	w8, w8, w26
1000d5bdc:     	scvtf	s2, w8
1000d5be0:     	ldp	x19, x8, [sp, #240]
1000d5be4:     	ldrb	w8, [x3, x8]
1000d5be8:     	ldrb	w19, [x4, x19]
1000d5bec:     	ldp	x26, x20, [sp, #224]
1000d5bf0:     	ldrb	w20, [x5, x20]
1000d5bf4:     	ldrb	w26, [x7, x26]
1000d5bf8:     	add	w8, w8, w19
1000d5bfc:     	ldr	x19, [sp, #216]
1000d5c00:     	ldrb	w19, [x6, x19]
1000d5c04:     	add	w8, w8, w20
1000d5c08:     	ldr	x20, [sp, #208]
1000d5c0c:     	ldrb	w20, [x23, x20]
1000d5c10:     	add	w8, w8, w26
1000d5c14:     	ldr	x26, [sp, #200]
1000d5c18:     	ldrb	w26, [x24, x26]
1000d5c1c:     	add	w8, w8, w19
1000d5c20:     	ldr	x19, [sp, #192]
1000d5c24:     	ldrb	w19, [x25, x19]
1000d5c28:     	add	w8, w8, w20
1000d5c2c:     	add	w8, w8, w26
1000d5c30:     	add	w8, w8, w19
1000d5c34:     	scvtf	s3, w8
1000d5c38:     	ldp	x19, x8, [sp, #176]
1000d5c3c:     	ldrb	w8, [x3, x8]
1000d5c40:     	ldrb	w19, [x4, x19]
1000d5c44:     	ldp	x26, x20, [sp, #160]
1000d5c48:     	ldrb	w20, [x5, x20]
1000d5c4c:     	ldrb	w26, [x7, x26]
1000d5c50:     	add	w8, w8, w19
1000d5c54:     	add	w8, w8, w20
1000d5c58:     	ldp	x20, x19, [sp, #144]
1000d5c5c:     	ldrb	w19, [x6, x19]
1000d5c60:     	ldrb	w20, [x23, x20]
1000d5c64:     	add	w8, w8, w26
1000d5c68:     	add	w8, w8, w19
1000d5c6c:     	ldp	x26, x19, [sp, #128]
1000d5c70:     	ldrb	w19, [x24, x19]
1000d5c74:     	ldrb	w26, [x25, x26]
1000d5c78:     	add	w8, w8, w20
1000d5c7c:     	add	w8, w8, w19
1000d5c80:     	add	w8, w8, w26
1000d5c84:     	scvtf	s4, w8
1000d5c88:     	ldp	x19, x8, [sp, #112]
1000d5c8c:     	ldrb	w8, [x3, x8]
1000d5c90:     	ldrb	w19, [x4, x19]
1000d5c94:     	ldr	x20, [sp, #104]
1000d5c98:     	ldrb	w20, [x5, x20]
1000d5c9c:     	add	w8, w8, w19
1000d5ca0:     	add	w8, w8, w20
1000d5ca4:     	ldp	x20, x19, [sp, #88]
1000d5ca8:     	ldrb	w19, [x7, x19]
1000d5cac:     	ldrb	w20, [x6, x20]
1000d5cb0:     	add	w8, w8, w19
1000d5cb4:     	add	w8, w8, w20
1000d5cb8:     	ldp	x20, x19, [sp, #72]
1000d5cbc:     	ldrb	w19, [x23, x19]
1000d5cc0:     	ldrb	w20, [x24, x20]
1000d5cc4:     	add	w8, w8, w19
1000d5cc8:     	add	w8, w8, w20
1000d5ccc:     	ldr	x19, [sp, #64]
1000d5cd0:     	ldrb	w19, [x25, x19]
1000d5cd4:     	add	w8, w8, w19
1000d5cd8:     	scvtf	s5, w8
1000d5cdc:     	ldp	x19, x8, [sp, #48]
1000d5ce0:     	ldrb	w8, [x3, x8]
1000d5ce4:     	ldrb	w19, [x4, x19]
1000d5ce8:     	ldp	x26, x20, [sp, #32]
1000d5cec:     	ldrb	w20, [x5, x20]
1000d5cf0:     	ldrb	w26, [x7, x26]
1000d5cf4:     	add	w8, w8, w19
1000d5cf8:     	ldr	x19, [sp, #24]
1000d5cfc:     	ldrb	w19, [x6, x19]
1000d5d00:     	add	w8, w8, w20
1000d5d04:     	ldrb	w20, [x23, x11]
1000d5d08:     	add	w8, w8, w26
1000d5d0c:     	ldrb	w26, [x24, x12]
1000d5d10:     	add	w8, w8, w19
1000d5d14:     	add	w8, w8, w20
1000d5d18:     	add	w8, w8, w26
1000d5d1c:     	ldrb	w19, [x25, x13]
1000d5d20:     	add	w8, w8, w19
1000d5d24:     	scvtf	s6, w8
1000d5d28:     	ldrb	w8, [x3, x14]
1000d5d2c:     	ldrb	w3, [x4, x21]
1000d5d30:     	ldrb	w4, [x5, x15]
1000d5d34:     	add	w8, w8, w3
1000d5d38:     	add	w8, w8, w4
1000d5d3c:     	ldrb	w3, [x7, x16]
1000d5d40:     	ldrb	w4, [x6, x17]
1000d5d44:     	add	w8, w8, w3
1000d5d48:     	add	w8, w8, w4
1000d5d4c:     	ldrb	w3, [x23, x0]
1000d5d50:     	add	x5, sp, #448
1000d5d54:     	ldrb	w4, [x24, x1]
1000d5d58:     	add	w8, w8, w3
1000d5d5c:     	add	w8, w8, w4
1000d5d60:     	ldrb	w3, [x25, x2]
1000d5d64:     	add	w8, w8, w3
1000d5d68:     	scvtf	s7, w8
1000d5d6c:     	add	x8, x5, x10
1000d5d70:     	ldr	s16, [x8]
1000d5d74:     	fadd	s0, s16, s0
1000d5d78:     	str	s0, [x8]
1000d5d7c:     	ldr	s0, [x8, #128]
1000d5d80:     	fadd	s0, s0, s1
1000d5d84:     	str	s0, [x8, #128]
1000d5d88:     	ldr	s0, [x8, #256]
1000d5d8c:     	fadd	s0, s0, s2
1000d5d90:     	str	s0, [x8, #256]
1000d5d94:     	ldr	s0, [x8, #384]
1000d5d98:     	fadd	s0, s0, s3
1000d5d9c:     	str	s0, [x8, #384]
1000d5da0:     	ldr	s0, [x8, #512]
1000d5da4:     	fadd	s0, s0, s4
1000d5da8:     	str	s0, [x8, #512]
1000d5dac:     	ldr	s0, [x8, #640]
1000d5db0:     	fadd	s0, s0, s5
1000d5db4:     	str	s0, [x8, #640]
1000d5db8:     	ldr	s0, [x8, #768]
1000d5dbc:     	fadd	s0, s0, s6
1000d5dc0:     	ldr	s1, [x8, #896]
1000d5dc4:     	fadd	s1, s1, s7
1000d5dc8:     	str	s0, [x8, #768]
1000d5dcc:     	str	s1, [x8, #896]
1000d5dd0:     	add	x10, x10, #4
1000d5dd4:     	cmp	x10, #128
1000d5dd8:     	b.ne	0x1000d5a78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d5ddc:     	add	x22, x22, #128
1000d5de0:     	ldp	x8, x20, [sp, #8]
1000d5de4:     	add	x20, x20, #32
1000d5de8:     	cmp	x20, x8
1000d5dec:     	b.ne	0x1000d58d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d5df0:     	add	x1, sp, #448
1000d5df4:     	ldr	x0, [sp]
1000d5df8:     	mov	w2, #1024
1000d5dfc:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d5e00:     	ldur	x8, [x29, #-96]
1000d5e04:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000d5e08:     	ldr	x9, [x9, #392]
1000d5e0c:     	ldr	x9, [x9]
1000d5e10:     	cmp	x9, x8
1000d5e14:     	b.ne	0x1000d5e38 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d5e18:     	add	sp, sp, #1488
1000d5e1c:     	ldp	x29, x30, [sp, #80]
1000d5e20:     	ldp	x20, x19, [sp, #64]
1000d5e24:     	ldp	x22, x21, [sp, #48]
1000d5e28:     	ldp	x24, x23, [sp, #32]
1000d5e2c:     	ldp	x26, x25, [sp, #16]
1000d5e30:     	ldp	x28, x27, [sp], #96
1000d5e34:     	ret
1000d5e38:     	bl	0x100163694 <_strcmp+0x100163694>

