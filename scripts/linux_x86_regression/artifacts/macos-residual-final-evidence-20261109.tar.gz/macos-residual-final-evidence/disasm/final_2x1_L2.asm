00000001000b62a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b62a0:     	stp	x24, x23, [sp, #-48]!
1000b62a4:     	stp	x22, x21, [sp, #16]
1000b62a8:     	stp	x20, x19, [sp, #32]
1000b62ac:     	str	xzr, [x3]
1000b62b0:     	lsl	x8, x4, #2
1000b62b4:     	cmp	x2, #8
1000b62b8:     	b.hs	0x1000b62cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b62bc:     	mov	x12, #0
1000b62c0:     	movi	d1, #0000000000000000
1000b62c4:     	movi	d0, #0000000000000000
1000b62c8:     	b	0x1000b6434 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b62cc:     	mov	x10, #0
1000b62d0:     	adrp	x9, 0x100169000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x90>
1000b62d4:     	add	x9, x9, #3772
1000b62d8:     	mov	x11, x1
1000b62dc:     	ldr	w4, [x11]
1000b62e0:     	lsl	w12, w4, #4
1000b62e4:     	and	x13, x12, #0xf0
1000b62e8:     	and	x12, x4, #0xf0
1000b62ec:     	add	x12, x9, x12
1000b62f0:     	lsr	x14, x4, #4
1000b62f4:     	and	x15, x14, #0xf0
1000b62f8:     	add	x14, x9, x13
1000b62fc:     	add	x13, x9, x15
1000b6300:     	lsr	x15, x4, #8
1000b6304:     	and	x15, x15, #0xf0
1000b6308:     	lsr	x16, x4, #12
1000b630c:     	and	x17, x16, #0xf0
1000b6310:     	add	x16, x9, x15
1000b6314:     	add	x15, x9, x17
1000b6318:     	lsr	x17, x4, #16
1000b631c:     	and	x17, x17, #0xf0
1000b6320:     	lsr	x5, x4, #20
1000b6324:     	and	x5, x5, #0xf0
1000b6328:     	add	x17, x9, x17
1000b632c:     	lsr	x4, x4, #24
1000b6330:     	and	x6, x4, #0xf0
1000b6334:     	add	x7, x0, x10
1000b6338:     	ldr	w19, [x7]
1000b633c:     	and	x20, x19, #0xf
1000b6340:     	add	x4, x9, x5
1000b6344:     	ldrb	w5, [x14, x20]
1000b6348:     	ubfx	x20, x19, #4, #4
1000b634c:     	ubfx	x21, x19, #8, #4
1000b6350:     	ldrb	w20, [x12, x20]
1000b6354:     	ldrb	w21, [x13, x21]
1000b6358:     	ubfx	x22, x19, #12, #4
1000b635c:     	ubfx	x23, x19, #16, #4
1000b6360:     	ldrb	w22, [x16, x22]
1000b6364:     	ldrb	w23, [x15, x23]
1000b6368:     	ubfx	x24, x19, #20, #4
1000b636c:     	ldrb	w24, [x17, x24]
1000b6370:     	add	w5, w5, w20
1000b6374:     	add	w5, w5, w21
1000b6378:     	ubfx	x20, x19, #24, #4
1000b637c:     	ldrb	w20, [x4, x20]
1000b6380:     	add	w5, w5, w22
1000b6384:     	add	w5, w5, w23
1000b6388:     	add	x6, x9, x6
1000b638c:     	lsr	x19, x19, #28
1000b6390:     	ldrb	w19, [x6, x19]
1000b6394:     	add	w5, w5, w24
1000b6398:     	add	w5, w5, w20
1000b639c:     	add	w5, w5, w19
1000b63a0:     	scvtf	s0, w5
1000b63a4:     	ldp	s1, s2, [x3]
1000b63a8:     	fadd	s0, s1, s0
1000b63ac:     	str	s0, [x3]
1000b63b0:     	ldr	w5, [x7, #4]
1000b63b4:     	and	x7, x5, #0xf
1000b63b8:     	ubfx	x19, x5, #4, #4
1000b63bc:     	ldrb	w14, [x14, x7]
1000b63c0:     	ldrb	w12, [x12, x19]
1000b63c4:     	ubfx	x7, x5, #8, #4
1000b63c8:     	ubfx	x19, x5, #12, #4
1000b63cc:     	ldrb	w13, [x13, x7]
1000b63d0:     	ldrb	w16, [x16, x19]
1000b63d4:     	ubfx	x7, x5, #16, #4
1000b63d8:     	ldrb	w15, [x15, x7]
1000b63dc:     	add	w12, w14, w12
1000b63e0:     	add	w12, w12, w13
1000b63e4:     	ubfx	x13, x5, #20, #4
1000b63e8:     	ldrb	w13, [x17, x13]
1000b63ec:     	add	w12, w12, w16
1000b63f0:     	add	w12, w12, w15
1000b63f4:     	ubfx	x14, x5, #24, #4
1000b63f8:     	ldrb	w14, [x4, x14]
1000b63fc:     	lsr	x15, x5, #28
1000b6400:     	add	w12, w12, w13
1000b6404:     	add	w12, w12, w14
1000b6408:     	ldrb	w13, [x6, x15]
1000b640c:     	add	w12, w12, w13
1000b6410:     	scvtf	s1, w12
1000b6414:     	fadd	s1, s2, s1
1000b6418:     	str	s1, [x3, #4]
1000b641c:     	add	x12, x10, #8
1000b6420:     	add	x11, x11, x8
1000b6424:     	add	x13, x10, #16
1000b6428:     	mov	x10, x12
1000b642c:     	cmp	x13, x2
1000b6430:     	b.ls	0x1000b62dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b6434:     	cmp	x12, x2
1000b6438:     	b.hs	0x1000b64e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x240>
1000b643c:     	lsl	w9, w12, #2
1000b6440:     	mov	w10, #-16
1000b6444:     	lsr	x11, x12, #3
1000b6448:     	mul	x11, x8, x11
1000b644c:     	ubfx	x13, x12, #1, #2
1000b6450:     	orr	x11, x11, x13
1000b6454:     	and	w13, w9, #0x4
1000b6458:     	ldrb	w11, [x1, x11]
1000b645c:     	lsr	w11, w11, w13
1000b6460:     	and	w14, w11, #0xf
1000b6464:     	cmp	w14, #8
1000b6468:     	csel	w14, wzr, w10, lo
1000b646c:     	and	x15, x12, #0xfffffffffffffff8
1000b6470:     	bfxil	w14, w11, #0, #4
1000b6474:     	bfxil	x15, x12, #1, #2
1000b6478:     	add	x11, x0, x15
1000b647c:     	ldrb	w15, [x11]
1000b6480:     	lsr	w15, w15, w13
1000b6484:     	scvtf	s2, w14
1000b6488:     	and	w14, w15, #0xf
1000b648c:     	cmp	w14, #8
1000b6490:     	csel	w14, wzr, w10, lo
1000b6494:     	bfxil	w14, w15, #0, #4
1000b6498:     	scvtf	s3, w14
1000b649c:     	fsub	s3, s3, s2
1000b64a0:     	fmadd	s0, s3, s3, s0
1000b64a4:     	str	s0, [x3]
1000b64a8:     	ldrb	w11, [x11, #4]
1000b64ac:     	lsr	w11, w11, w13
1000b64b0:     	and	w13, w11, #0xf
1000b64b4:     	cmp	w13, #8
1000b64b8:     	csel	w13, wzr, w10, lo
1000b64bc:     	bfxil	w13, w11, #0, #4
1000b64c0:     	scvtf	s3, w13
1000b64c4:     	fsub	s2, s3, s2
1000b64c8:     	fmadd	s1, s2, s2, s1
1000b64cc:     	str	s1, [x3, #4]
1000b64d0:     	add	x12, x12, #1
1000b64d4:     	add	w9, w9, #4
1000b64d8:     	cmp	x2, x12
1000b64dc:     	b.ne	0x1000b6444 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b64e0:     	ldp	x20, x19, [sp, #32]
1000b64e4:     	ldp	x22, x21, [sp, #16]
1000b64e8:     	ldp	x24, x23, [sp], #48
1000b64ec:     	ret

