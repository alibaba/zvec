00000001000d3394 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d3394:     	stp	x28, x27, [sp, #-96]!
1000d3398:     	stp	x26, x25, [sp, #16]
1000d339c:     	stp	x24, x23, [sp, #32]
1000d33a0:     	stp	x22, x21, [sp, #48]
1000d33a4:     	stp	x20, x19, [sp, #64]
1000d33a8:     	stp	x29, x30, [sp, #80]
1000d33ac:     	add	x29, sp, #80
1000d33b0:     	sub	sp, sp, #704
1000d33b4:     	str	x3, [sp]
1000d33b8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d33bc:     	ldr	x8, [x8, #392]
1000d33c0:     	ldr	x8, [x8]
1000d33c4:     	stur	x8, [x29, #-96]
1000d33c8:     	movi.2d	v0, #0000000000000000
1000d33cc:     	stp	q0, q0, [sp, #656]
1000d33d0:     	lsl	x8, x2, #1
1000d33d4:     	stp	q0, q0, [sp, #624]
1000d33d8:     	stp	q0, q0, [sp, #592]
1000d33dc:     	stp	q0, q0, [sp, #560]
1000d33e0:     	stp	q0, q0, [sp, #528]
1000d33e4:     	stp	q0, q0, [sp, #496]
1000d33e8:     	stp	q0, q0, [sp, #464]
1000d33ec:     	stp	q0, q0, [sp, #432]
1000d33f0:     	stp	q0, q0, [sp, #400]
1000d33f4:     	stp	q0, q0, [sp, #368]
1000d33f8:     	stp	q0, q0, [sp, #336]
1000d33fc:     	stp	q0, q0, [sp, #304]
1000d3400:     	stp	q0, q0, [sp, #272]
1000d3404:     	stp	q0, q0, [sp, #240]
1000d3408:     	stp	q0, q0, [sp, #208]
1000d340c:     	stp	q0, q0, [sp, #176]
1000d3410:     	ands	x8, x8, #0xfffffffffffffffc
1000d3414:     	b.eq	0x1000d36f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d3418:     	add	x8, x1, x8
1000d341c:     	str	x8, [sp, #8]
1000d3420:     	add	x8, sp, #176
1000d3424:     	add	x27, x8, #256
1000d3428:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d342c:     	add	x11, x11, #1724
1000d3430:     	mov	x12, #0
1000d3434:     	ldp	w8, w9, [x1]
1000d3438:     	ubfx	x10, x8, #8, #4
1000d343c:     	str	x10, [sp, #168]
1000d3440:     	ubfx	x10, x8, #16, #4
1000d3444:     	str	x10, [sp, #160]
1000d3448:     	ubfx	x10, x8, #24, #4
1000d344c:     	str	x10, [sp, #152]
1000d3450:     	ldp	w10, w17, [x1, #8]
1000d3454:     	str	x1, [sp, #16]
1000d3458:     	and	x14, x8, #0xf
1000d345c:     	ubfx	x13, x8, #4, #4
1000d3460:     	stp	x13, x14, [sp, #136]
1000d3464:     	ubfx	x14, x8, #12, #4
1000d3468:     	ubfx	x13, x8, #20, #4
1000d346c:     	stp	x13, x14, [sp, #120]
1000d3470:     	lsr	x8, x8, #28
1000d3474:     	str	x8, [sp, #112]
1000d3478:     	and	x8, x9, #0xf
1000d347c:     	str	x8, [sp, #104]
1000d3480:     	ubfx	x8, x9, #8, #4
1000d3484:     	str	x8, [sp, #96]
1000d3488:     	ubfx	x8, x9, #16, #4
1000d348c:     	str	x8, [sp, #88]
1000d3490:     	ubfx	x8, x9, #24, #4
1000d3494:     	str	x8, [sp, #80]
1000d3498:     	ubfx	x8, x9, #4, #4
1000d349c:     	str	x8, [sp, #72]
1000d34a0:     	ubfx	x8, x9, #12, #4
1000d34a4:     	str	x8, [sp, #64]
1000d34a8:     	ubfx	x8, x9, #20, #4
1000d34ac:     	str	x8, [sp, #56]
1000d34b0:     	lsr	x8, x9, #28
1000d34b4:     	str	x8, [sp, #48]
1000d34b8:     	and	x9, x10, #0xf
1000d34bc:     	ubfx	x8, x10, #8, #4
1000d34c0:     	stp	x8, x9, [sp, #32]
1000d34c4:     	ubfx	x8, x10, #16, #4
1000d34c8:     	str	x8, [sp, #24]
1000d34cc:     	ubfx	x28, x10, #24, #4
1000d34d0:     	ubfx	x30, x10, #4, #4
1000d34d4:     	ubfx	x3, x10, #12, #4
1000d34d8:     	ubfx	x8, x10, #20, #4
1000d34dc:     	lsr	x9, x10, #28
1000d34e0:     	and	x1, x17, #0xf
1000d34e4:     	ubfx	x10, x17, #8, #4
1000d34e8:     	ubfx	x13, x17, #16, #4
1000d34ec:     	ubfx	x26, x17, #24, #4
1000d34f0:     	ubfx	x14, x17, #4, #4
1000d34f4:     	ubfx	x15, x17, #12, #4
1000d34f8:     	ubfx	x16, x17, #20, #4
1000d34fc:     	lsr	x17, x17, #28
1000d3500:     	ldr	w20, [x0, x12]
1000d3504:     	lsl	w2, w20, #4
1000d3508:     	and	x2, x2, #0xf0
1000d350c:     	add	x5, x11, x2
1000d3510:     	and	x2, x20, #0xf0
1000d3514:     	add	x2, x11, x2
1000d3518:     	lsr	x4, x20, #4
1000d351c:     	and	x4, x4, #0xf0
1000d3520:     	add	x7, x11, x4
1000d3524:     	lsr	x4, x20, #8
1000d3528:     	and	x4, x4, #0xf0
1000d352c:     	add	x4, x11, x4
1000d3530:     	lsr	x6, x20, #12
1000d3534:     	and	x6, x6, #0xf0
1000d3538:     	add	x19, x11, x6
1000d353c:     	lsr	x6, x20, #16
1000d3540:     	and	x6, x6, #0xf0
1000d3544:     	add	x6, x11, x6
1000d3548:     	lsr	x21, x20, #20
1000d354c:     	and	x21, x21, #0xf0
1000d3550:     	add	x21, x11, x21
1000d3554:     	lsr	x20, x20, #24
1000d3558:     	and	x20, x20, #0xf0
1000d355c:     	ldr	x22, [sp, #144]
1000d3560:     	ldrb	w22, [x5, x22]
1000d3564:     	add	x20, x11, x20
1000d3568:     	ldp	x24, x23, [sp, #160]
1000d356c:     	ldrb	w23, [x7, x23]
1000d3570:     	ldrb	w24, [x19, x24]
1000d3574:     	add	w22, w22, w23
1000d3578:     	add	w22, w22, w24
1000d357c:     	ldr	x23, [sp, #152]
1000d3580:     	ldrb	w23, [x21, x23]
1000d3584:     	ldr	x24, [sp, #136]
1000d3588:     	ldrb	w24, [x2, x24]
1000d358c:     	add	w22, w22, w23
1000d3590:     	add	w22, w22, w24
1000d3594:     	ldp	x24, x23, [sp, #120]
1000d3598:     	ldrb	w23, [x4, x23]
1000d359c:     	ldrb	w24, [x6, x24]
1000d35a0:     	add	w22, w22, w23
1000d35a4:     	add	w22, w22, w24
1000d35a8:     	ldr	x23, [sp, #112]
1000d35ac:     	ldrb	w23, [x20, x23]
1000d35b0:     	add	w22, w22, w23
1000d35b4:     	scvtf	s0, w22
1000d35b8:     	ldp	x23, x22, [sp, #96]
1000d35bc:     	ldrb	w22, [x5, x22]
1000d35c0:     	ldrb	w23, [x7, x23]
1000d35c4:     	ldp	x25, x24, [sp, #80]
1000d35c8:     	ldrb	w24, [x19, x24]
1000d35cc:     	ldrb	w25, [x21, x25]
1000d35d0:     	add	w22, w22, w23
1000d35d4:     	ldr	x23, [sp, #72]
1000d35d8:     	ldrb	w23, [x2, x23]
1000d35dc:     	add	w22, w22, w24
1000d35e0:     	ldr	x24, [sp, #64]
1000d35e4:     	ldrb	w24, [x4, x24]
1000d35e8:     	add	w22, w22, w25
1000d35ec:     	ldr	x25, [sp, #56]
1000d35f0:     	ldrb	w25, [x6, x25]
1000d35f4:     	add	w22, w22, w23
1000d35f8:     	add	w22, w22, w24
1000d35fc:     	add	w22, w22, w25
1000d3600:     	ldr	x23, [sp, #48]
1000d3604:     	ldrb	w23, [x20, x23]
1000d3608:     	add	w22, w22, w23
1000d360c:     	scvtf	s1, w22
1000d3610:     	ldp	x23, x22, [sp, #32]
1000d3614:     	ldrb	w22, [x5, x22]
1000d3618:     	ldrb	w23, [x7, x23]
1000d361c:     	ldr	x24, [sp, #24]
1000d3620:     	ldrb	w24, [x19, x24]
1000d3624:     	add	w22, w22, w23
1000d3628:     	ldrb	w23, [x21, x28]
1000d362c:     	add	w22, w22, w24
1000d3630:     	ldrb	w24, [x2, x30]
1000d3634:     	add	w22, w22, w23
1000d3638:     	ldrb	w23, [x4, x3]
1000d363c:     	add	w22, w22, w24
1000d3640:     	ldrb	w24, [x6, x8]
1000d3644:     	add	w22, w22, w23
1000d3648:     	ldrb	w23, [x20, x9]
1000d364c:     	add	w22, w22, w24
1000d3650:     	add	w22, w22, w23
1000d3654:     	scvtf	s2, w22
1000d3658:     	ldrb	w5, [x5, x1]
1000d365c:     	ldrb	w7, [x7, x10]
1000d3660:     	ldrb	w19, [x19, x13]
1000d3664:     	add	w5, w5, w7
1000d3668:     	add	w5, w5, w19
1000d366c:     	ldrb	w7, [x21, x26]
1000d3670:     	ldrb	w2, [x2, x14]
1000d3674:     	add	w5, w5, w7
1000d3678:     	add	w2, w5, w2
1000d367c:     	ldrb	w4, [x4, x15]
1000d3680:     	ldrb	w5, [x6, x16]
1000d3684:     	add	w2, w2, w4
1000d3688:     	add	w2, w2, w5
1000d368c:     	ldrb	w4, [x20, x17]
1000d3690:     	add	w2, w2, w4
1000d3694:     	add	x4, sp, #176
1000d3698:     	scvtf	s3, w2
1000d369c:     	add	x2, x27, x12
1000d36a0:     	ldur	s4, [x2, #-128]
1000d36a4:     	fadd	s1, s4, s1
1000d36a8:     	stur	s1, [x2, #-128]
1000d36ac:     	ldr	s1, [x2]
1000d36b0:     	fadd	s1, s1, s2
1000d36b4:     	str	s1, [x2]
1000d36b8:     	ldr	s1, [x2, #128]
1000d36bc:     	fadd	s1, s1, s3
1000d36c0:     	ldr	s2, [x4, x12]
1000d36c4:     	str	s1, [x2, #128]
1000d36c8:     	fadd	s0, s2, s0
1000d36cc:     	str	s0, [x4, x12]
1000d36d0:     	add	x12, x12, #4
1000d36d4:     	cmp	x12, #128
1000d36d8:     	b.ne	0x1000d3500 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d36dc:     	add	x0, x0, #128
1000d36e0:     	ldp	x8, x1, [sp, #8]
1000d36e4:     	add	x1, x1, #16
1000d36e8:     	cmp	x1, x8
1000d36ec:     	b.ne	0x1000d3430 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d36f0:     	add	x1, sp, #176
1000d36f4:     	ldr	x0, [sp]
1000d36f8:     	mov	w2, #512
1000d36fc:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d3700:     	ldur	x8, [x29, #-96]
1000d3704:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xfc>
1000d3708:     	ldr	x9, [x9, #392]
1000d370c:     	ldr	x9, [x9]
1000d3710:     	cmp	x9, x8
1000d3714:     	b.ne	0x1000d3738 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d3718:     	add	sp, sp, #704
1000d371c:     	ldp	x29, x30, [sp, #80]
1000d3720:     	ldp	x20, x19, [sp, #64]
1000d3724:     	ldp	x22, x21, [sp, #48]
1000d3728:     	ldp	x24, x23, [sp, #32]
1000d372c:     	ldp	x26, x25, [sp, #16]
1000d3730:     	ldp	x28, x27, [sp], #96
1000d3734:     	ret
1000d3738:     	bl	0x100163694 <_strcmp+0x100163694>

