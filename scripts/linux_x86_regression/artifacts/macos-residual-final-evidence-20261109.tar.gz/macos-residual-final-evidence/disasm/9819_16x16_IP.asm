00000001000cb550 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cb550:     	stp	x28, x27, [sp, #-64]!
1000cb554:     	stp	x22, x21, [sp, #16]
1000cb558:     	stp	x20, x19, [sp, #32]
1000cb55c:     	stp	x29, x30, [sp, #48]
1000cb560:     	add	x29, sp, #48
1000cb564:     	sub	sp, sp, #1040
1000cb568:     	mov	x19, x3
1000cb56c:     	mov	x20, x1
1000cb570:     	mov	x21, x0
1000cb574:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0xf4>
1000cb578:     	ldr	x8, [x8, #392]
1000cb57c:     	ldr	x8, [x8]
1000cb580:     	stur	x8, [x29, #-56]
1000cb584:     	lsl	x8, x2, #3
1000cb588:     	and	x22, x8, #0xfffffffffffffff0
1000cb58c:     	add	x0, sp, #8
1000cb590:     	mov	w1, #1024
1000cb594:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000cb598:     	cbz	x22, 0x1000cb6b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000cb59c:     	add	x8, x20, x22
1000cb5a0:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x118>
1000cb5a4:     	add	x9, x9, #1500
1000cb5a8:     	mov	x10, #0
1000cb5ac:     	add	x11, sp, #8
1000cb5b0:     	mov	x12, #0
1000cb5b4:     	ldr	w2, [x21, x10, lsl #2]
1000cb5b8:     	lsl	w13, w2, #4
1000cb5bc:     	and	x13, x13, #0xf0
1000cb5c0:     	and	x14, x2, #0xf0
1000cb5c4:     	lsr	x15, x2, #4
1000cb5c8:     	and	x15, x15, #0xf0
1000cb5cc:     	lsr	x16, x2, #8
1000cb5d0:     	and	x16, x16, #0xf0
1000cb5d4:     	lsr	x17, x2, #12
1000cb5d8:     	and	x17, x17, #0xf0
1000cb5dc:     	lsr	x0, x2, #16
1000cb5e0:     	and	x0, x0, #0xf0
1000cb5e4:     	lsr	x1, x2, #20
1000cb5e8:     	and	x1, x1, #0xf0
1000cb5ec:     	lsr	x2, x2, #24
1000cb5f0:     	and	x2, x2, #0xf0
1000cb5f4:     	mov	x3, x11
1000cb5f8:     	ldr	w4, [x20, x12]
1000cb5fc:     	and	x5, x4, #0xf
1000cb600:     	orr	x5, x13, x5
1000cb604:     	ldrsb	w5, [x9, x5]
1000cb608:     	ubfx	x6, x4, #4, #4
1000cb60c:     	orr	x6, x14, x6
1000cb610:     	ldrsb	w6, [x9, x6]
1000cb614:     	ubfx	x7, x4, #8, #4
1000cb618:     	orr	x7, x15, x7
1000cb61c:     	ldrsb	w7, [x9, x7]
1000cb620:     	add	w5, w5, w6
1000cb624:     	add	w5, w5, w7
1000cb628:     	ubfx	x6, x4, #12, #4
1000cb62c:     	orr	x6, x16, x6
1000cb630:     	ldrsb	w6, [x9, x6]
1000cb634:     	ubfx	x7, x4, #16, #4
1000cb638:     	orr	x7, x17, x7
1000cb63c:     	ldrsb	w7, [x9, x7]
1000cb640:     	add	w5, w5, w6
1000cb644:     	add	w5, w5, w7
1000cb648:     	ubfx	x6, x4, #20, #4
1000cb64c:     	orr	x6, x0, x6
1000cb650:     	ldrsb	w6, [x9, x6]
1000cb654:     	ubfx	x7, x4, #24, #4
1000cb658:     	orr	x7, x1, x7
1000cb65c:     	ldrsb	w7, [x9, x7]
1000cb660:     	add	w5, w5, w6
1000cb664:     	add	w5, w5, w7
1000cb668:     	orr	x4, x2, x4, lsr #28
1000cb66c:     	ldrsb	w4, [x9, x4]
1000cb670:     	add	w4, w5, w4
1000cb674:     	scvtf	s0, w4
1000cb678:     	ldr	s1, [x3]
1000cb67c:     	fadd	s0, s1, s0
1000cb680:     	str	s0, [x3], #64
1000cb684:     	add	x12, x12, #4
1000cb688:     	cmp	x12, #64
1000cb68c:     	b.ne	0x1000cb5f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000cb690:     	add	x10, x10, #1
1000cb694:     	add	x11, x11, #4
1000cb698:     	cmp	x10, #16
1000cb69c:     	b.ne	0x1000cb5b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000cb6a0:     	add	x21, x21, #64
1000cb6a4:     	add	x20, x20, #64
1000cb6a8:     	cmp	x20, x8
1000cb6ac:     	b.ne	0x1000cb5a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000cb6b0:     	add	x1, sp, #8
1000cb6b4:     	mov	x0, x19
1000cb6b8:     	mov	w2, #1024
1000cb6bc:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000cb6c0:     	ldur	x8, [x29, #-56]
1000cb6c4:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x244>
1000cb6c8:     	ldr	x9, [x9, #392]
1000cb6cc:     	ldr	x9, [x9]
1000cb6d0:     	cmp	x9, x8
1000cb6d4:     	b.ne	0x1000cb6f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000cb6d8:     	add	sp, sp, #1040
1000cb6dc:     	ldp	x29, x30, [sp, #48]
1000cb6e0:     	ldp	x20, x19, [sp, #32]
1000cb6e4:     	ldp	x22, x21, [sp, #16]
1000cb6e8:     	ldp	x28, x27, [sp], #64
1000cb6ec:     	ret
1000cb6f0:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

