00000001000cc93c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000cc93c:     	stp	x22, x21, [sp, #-32]!
1000cc940:     	stp	x20, x19, [sp, #16]
1000cc944:     	movi.2d	v0, #0000000000000000
1000cc948:     	stp	q0, q0, [x3, #96]
1000cc94c:     	stp	q0, q0, [x3, #64]
1000cc950:     	stp	q0, q0, [x3, #32]
1000cc954:     	stp	q0, q0, [x3]
1000cc958:     	cmp	x2, #8
1000cc95c:     	b.hs	0x1000cc968 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000cc960:     	mov	x8, #0
1000cc964:     	b	0x1000cca78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000cc968:     	mov	x8, #0
1000cc96c:     	mov	w14, #8
1000cc970:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x94>
1000cc974:     	add	x9, x9, #1756
1000cc978:     	mov	x10, x0
1000cc97c:     	mov	x11, #0
1000cc980:     	lsr	x8, x8, #1
1000cc984:     	mul	x8, x8, x4
1000cc988:     	ldr	w6, [x1, x8]
1000cc98c:     	ubfx	x12, x6, #4, #4
1000cc990:     	ubfx	x13, x6, #8, #4
1000cc994:     	mov	x8, x14
1000cc998:     	ubfx	x14, x6, #12, #4
1000cc99c:     	and	x15, x6, #0xf
1000cc9a0:     	ubfx	x16, x6, #16, #4
1000cc9a4:     	ubfx	x17, x6, #20, #4
1000cc9a8:     	ubfx	x5, x6, #24, #4
1000cc9ac:     	lsr	x6, x6, #28
1000cc9b0:     	ldr	w7, [x10, x11]
1000cc9b4:     	lsl	w19, w7, #4
1000cc9b8:     	and	x19, x19, #0xf0
1000cc9bc:     	orr	x19, x19, x15
1000cc9c0:     	ldrb	w19, [x9, x19]
1000cc9c4:     	and	x20, x7, #0xf0
1000cc9c8:     	orr	x20, x20, x12
1000cc9cc:     	ldrb	w20, [x9, x20]
1000cc9d0:     	lsr	x21, x7, #4
1000cc9d4:     	and	x21, x21, #0xf0
1000cc9d8:     	orr	x21, x21, x13
1000cc9dc:     	ldrb	w21, [x9, x21]
1000cc9e0:     	lsr	x22, x7, #8
1000cc9e4:     	and	x22, x22, #0xf0
1000cc9e8:     	orr	x22, x22, x14
1000cc9ec:     	ldrb	w22, [x9, x22]
1000cc9f0:     	add	w19, w19, w20
1000cc9f4:     	add	w19, w19, w21
1000cc9f8:     	lsr	x20, x7, #12
1000cc9fc:     	and	x20, x20, #0xf0
1000cca00:     	orr	x20, x20, x16
1000cca04:     	ldrb	w20, [x9, x20]
1000cca08:     	lsr	x21, x7, #16
1000cca0c:     	and	x21, x21, #0xf0
1000cca10:     	orr	x21, x21, x17
1000cca14:     	ldrb	w21, [x9, x21]
1000cca18:     	add	w19, w19, w22
1000cca1c:     	add	w19, w19, w20
1000cca20:     	lsr	x20, x7, #20
1000cca24:     	and	x20, x20, #0xf0
1000cca28:     	orr	x20, x20, x5
1000cca2c:     	ldrb	w20, [x9, x20]
1000cca30:     	lsr	x7, x7, #24
1000cca34:     	and	x7, x7, #0xf0
1000cca38:     	orr	x7, x7, x6
1000cca3c:     	ldrb	w7, [x9, x7]
1000cca40:     	add	w19, w19, w21
1000cca44:     	add	w19, w19, w20
1000cca48:     	add	w7, w19, w7
1000cca4c:     	scvtf	s0, w7
1000cca50:     	ldr	s1, [x3, x11]
1000cca54:     	fadd	s0, s1, s0
1000cca58:     	str	s0, [x3, x11]
1000cca5c:     	add	x11, x11, #4
1000cca60:     	cmp	x11, #128
1000cca64:     	b.ne	0x1000cc9b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x74>
1000cca68:     	add	x14, x8, #8
1000cca6c:     	add	x10, x10, #128
1000cca70:     	cmp	x14, x2
1000cca74:     	b.ls	0x1000cc97c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000cca78:     	cmp	x8, x2
1000cca7c:     	b.hs	0x1000ccb0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1d0>
1000cca80:     	lsl	x9, x4, #2
1000cca84:     	mov	w10, #-16
1000cca88:     	mov	x11, #0
1000cca8c:     	lsr	x13, x8, #3
1000cca90:     	lsl	x12, x13, #7
1000cca94:     	mul	x14, x9, x13
1000cca98:     	ubfx	x13, x8, #1, #2
1000cca9c:     	orr	x14, x14, x13
1000ccaa0:     	ldrb	w15, [x1, x14]
1000ccaa4:     	ubfiz	w14, w8, #2, #1
1000ccaa8:     	lsr	w15, w15, w14
1000ccaac:     	and	w16, w15, #0xf
1000ccab0:     	cmp	w16, #8
1000ccab4:     	csel	w16, wzr, w10, lo
1000ccab8:     	bfxil	w16, w15, #0, #4
1000ccabc:     	scvtf	s0, w16
1000ccac0:     	add	x15, x12, x11
1000ccac4:     	orr	x15, x15, x13
1000ccac8:     	ldrb	w15, [x0, x15]
1000ccacc:     	lsr	w15, w15, w14
1000ccad0:     	and	w16, w15, #0xf
1000ccad4:     	cmp	w16, #8
1000ccad8:     	csel	w16, wzr, w10, lo
1000ccadc:     	bfxil	w16, w15, #0, #4
1000ccae0:     	scvtf	s1, w16
1000ccae4:     	ldr	s2, [x3, x11]
1000ccae8:     	fsub	s1, s1, s0
1000ccaec:     	fmadd	s1, s1, s1, s2
1000ccaf0:     	str	s1, [x3, x11]
1000ccaf4:     	add	x11, x11, #4
1000ccaf8:     	cmp	x11, #128
1000ccafc:     	b.ne	0x1000ccac0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000ccb00:     	add	x8, x8, #1
1000ccb04:     	cmp	x8, x2
1000ccb08:     	b.ne	0x1000cca88 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000ccb0c:     	ldp	x20, x19, [sp, #16]
1000ccb10:     	ldp	x22, x21, [sp], #32
1000ccb14:     	ret

