00000001000b8174 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b8174:     	stp	x22, x21, [sp, #-32]!
1000b8178:     	stp	x20, x19, [sp, #16]
1000b817c:     	ands	x8, x2, #0xfffffffffffffffe
1000b8180:     	b.eq	0x1000b8404 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b8184:     	add	x8, x1, x8
1000b8188:     	movi	d0, #0000000000000000
1000b818c:     	adrp	x9, 0x100169000 <void run<unsigned char, 4ul, 1ul, false>(char const*)+0x20>
1000b8190:     	add	x9, x9, #4028
1000b8194:     	movi	d1, #0000000000000000
1000b8198:     	movi	d2, #0000000000000000
1000b819c:     	movi	d3, #0000000000000000
1000b81a0:     	ldp	w10, w11, [x0]
1000b81a4:     	lsl	w12, w10, #4
1000b81a8:     	and	x14, x12, #0xf0
1000b81ac:     	mov	x15, x14
1000b81b0:     	ldp	w12, w13, [x1]
1000b81b4:     	bfxil	x15, x12, #0, #4
1000b81b8:     	ldrsb	w15, [x9, x15]
1000b81bc:     	and	x16, x10, #0xf0
1000b81c0:     	mov	x17, x16
1000b81c4:     	bfxil	x17, x12, #4, #4
1000b81c8:     	ldrsb	w17, [x9, x17]
1000b81cc:     	lsr	x2, x10, #4
1000b81d0:     	and	x2, x2, #0xf0
1000b81d4:     	mov	x4, x2
1000b81d8:     	bfxil	x4, x12, #8, #4
1000b81dc:     	ldrsb	w4, [x9, x4]
1000b81e0:     	lsr	x5, x10, #8
1000b81e4:     	and	x5, x5, #0xf0
1000b81e8:     	mov	x6, x5
1000b81ec:     	bfxil	x6, x12, #12, #4
1000b81f0:     	ldrsb	w6, [x9, x6]
1000b81f4:     	lsr	x7, x10, #12
1000b81f8:     	and	x7, x7, #0xf0
1000b81fc:     	mov	x19, x7
1000b8200:     	bfxil	x19, x12, #16, #4
1000b8204:     	ldrsb	w19, [x9, x19]
1000b8208:     	add	w15, w15, w17
1000b820c:     	add	w15, w15, w4
1000b8210:     	lsr	x17, x10, #16
1000b8214:     	and	x17, x17, #0xf0
1000b8218:     	mov	x4, x17
1000b821c:     	bfxil	x4, x12, #20, #4
1000b8220:     	add	w15, w15, w6
1000b8224:     	add	w15, w15, w19
1000b8228:     	ldrsb	w4, [x9, x4]
1000b822c:     	lsr	x6, x10, #20
1000b8230:     	and	x6, x6, #0xf0
1000b8234:     	mov	x19, x6
1000b8238:     	bfxil	x19, x12, #24, #4
1000b823c:     	ldrsb	w19, [x9, x19]
1000b8240:     	add	w15, w15, w4
1000b8244:     	add	w15, w15, w19
1000b8248:     	lsr	x10, x10, #24
1000b824c:     	and	x4, x10, #0xf0
1000b8250:     	lsr	x10, x12, #28
1000b8254:     	orr	x19, x4, x10
1000b8258:     	ldrsb	w19, [x9, x19]
1000b825c:     	add	w15, w15, w19
1000b8260:     	scvtf	s4, w15
1000b8264:     	fadd	s0, s0, s4
1000b8268:     	bfxil	x14, x13, #0, #4
1000b826c:     	ldrsb	w14, [x9, x14]
1000b8270:     	and	x15, x13, #0xf
1000b8274:     	ubfx	x19, x13, #4, #4
1000b8278:     	bfxil	x16, x13, #4, #4
1000b827c:     	ldrsb	w16, [x9, x16]
1000b8280:     	ubfx	x20, x13, #8, #4
1000b8284:     	bfxil	x2, x13, #8, #4
1000b8288:     	ldrsb	w2, [x9, x2]
1000b828c:     	add	w14, w14, w16
1000b8290:     	add	w14, w14, w2
1000b8294:     	ubfx	x16, x13, #12, #4
1000b8298:     	bfxil	x5, x13, #12, #4
1000b829c:     	ldrsb	w2, [x9, x5]
1000b82a0:     	bfxil	x7, x13, #16, #4
1000b82a4:     	ldrsb	w5, [x9, x7]
1000b82a8:     	ubfx	x7, x13, #16, #4
1000b82ac:     	add	w14, w14, w2
1000b82b0:     	add	w14, w14, w5
1000b82b4:     	bfxil	x17, x13, #20, #4
1000b82b8:     	ldrsb	w17, [x9, x17]
1000b82bc:     	bfxil	x6, x13, #24, #4
1000b82c0:     	ldrsb	w2, [x9, x6]
1000b82c4:     	add	w14, w14, w17
1000b82c8:     	add	w17, w14, w2
1000b82cc:     	lsr	x14, x13, #28
1000b82d0:     	orr	x2, x4, x14
1000b82d4:     	ldrsb	w2, [x9, x2]
1000b82d8:     	add	w17, w17, w2
1000b82dc:     	scvtf	s4, w17
1000b82e0:     	ubfx	x17, x13, #20, #4
1000b82e4:     	fadd	s2, s2, s4
1000b82e8:     	lsl	w2, w11, #4
1000b82ec:     	and	x2, x2, #0xf0
1000b82f0:     	orr	w15, w2, w15
1000b82f4:     	bfxil	x2, x12, #0, #4
1000b82f8:     	ldrsb	w2, [x9, x2]
1000b82fc:     	and	x4, x11, #0xf0
1000b8300:     	orr	w5, w4, w19
1000b8304:     	bfxil	x4, x12, #4, #4
1000b8308:     	ldrsb	w4, [x9, x4]
1000b830c:     	lsr	x6, x11, #4
1000b8310:     	and	x6, x6, #0xf0
1000b8314:     	orr	w19, w6, w20
1000b8318:     	bfxil	x6, x12, #8, #4
1000b831c:     	ldrsb	w6, [x9, x6]
1000b8320:     	add	w2, w2, w4
1000b8324:     	add	w2, w2, w6
1000b8328:     	lsr	x4, x11, #8
1000b832c:     	and	x4, x4, #0xf0
1000b8330:     	orr	w16, w4, w16
1000b8334:     	lsr	x6, x11, #12
1000b8338:     	and	x6, x6, #0xf0
1000b833c:     	orr	w7, w6, w7
1000b8340:     	lsr	x20, x11, #16
1000b8344:     	and	x20, x20, #0xf0
1000b8348:     	orr	w17, w20, w17
1000b834c:     	lsr	x21, x11, #20
1000b8350:     	and	x21, x21, #0xf0
1000b8354:     	ubfx	x13, x13, #24, #4
1000b8358:     	orr	w13, w21, w13
1000b835c:     	bfxil	x4, x12, #12, #4
1000b8360:     	ldrsb	w4, [x9, x4]
1000b8364:     	bfxil	x6, x12, #16, #4
1000b8368:     	ldrsb	w6, [x9, x6]
1000b836c:     	bfxil	x20, x12, #20, #4
1000b8370:     	ldrsb	w20, [x9, x20]
1000b8374:     	bfxil	x21, x12, #24, #4
1000b8378:     	ldrsb	w12, [x9, x21]
1000b837c:     	add	w2, w2, w4
1000b8380:     	add	w2, w2, w6
1000b8384:     	add	w2, w2, w20
1000b8388:     	add	w12, w2, w12
1000b838c:     	lsr	x11, x11, #24
1000b8390:     	and	x11, x11, #0xf0
1000b8394:     	orr	x10, x11, x10
1000b8398:     	ldrsb	w10, [x9, x10]
1000b839c:     	add	w10, w12, w10
1000b83a0:     	scvtf	s4, w10
1000b83a4:     	fadd	s1, s1, s4
1000b83a8:     	ldrsb	w10, [x9, w15, uxtw]
1000b83ac:     	ldrsb	w12, [x9, w5, uxtw]
1000b83b0:     	ldrsb	w15, [x9, w19, uxtw]
1000b83b4:     	add	w10, w10, w12
1000b83b8:     	add	w10, w10, w15
1000b83bc:     	ldrsb	w12, [x9, w16, uxtw]
1000b83c0:     	ldrsb	w15, [x9, w7, uxtw]
1000b83c4:     	add	w10, w10, w12
1000b83c8:     	add	w10, w10, w15
1000b83cc:     	ldrsb	w12, [x9, w17, uxtw]
1000b83d0:     	ldrsb	w13, [x9, w13, uxtw]
1000b83d4:     	add	w10, w10, w12
1000b83d8:     	add	w10, w10, w13
1000b83dc:     	orr	w11, w11, w14
1000b83e0:     	ldrsb	w11, [x9, w11, uxtw]
1000b83e4:     	add	w10, w10, w11
1000b83e8:     	scvtf	s4, w10
1000b83ec:     	fadd	s3, s3, s4
1000b83f0:     	add	x0, x0, #8
1000b83f4:     	add	x1, x1, #8
1000b83f8:     	cmp	x1, x8
1000b83fc:     	b.ne	0x1000b81a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8400:     	b	0x1000b8414 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b8404:     	movi	d0, #0000000000000000
1000b8408:     	movi	d1, #0000000000000000
1000b840c:     	movi	d2, #0000000000000000
1000b8410:     	movi	d3, #0000000000000000
1000b8414:     	str	s0, [x3]
1000b8418:     	str	s1, [x3, #4]
1000b841c:     	str	s2, [x3, #8]
1000b8420:     	str	s3, [x3, #12]
1000b8424:     	ldp	x20, x19, [sp, #16]
1000b8428:     	ldp	x22, x21, [sp], #32
1000b842c:     	ret

