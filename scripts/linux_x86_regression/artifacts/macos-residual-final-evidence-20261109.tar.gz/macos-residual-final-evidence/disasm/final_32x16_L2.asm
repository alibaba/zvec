00000001000d7c04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d7c04:     	stp	x28, x27, [sp, #-80]!
1000d7c08:     	stp	x24, x23, [sp, #16]
1000d7c0c:     	stp	x22, x21, [sp, #32]
1000d7c10:     	stp	x20, x19, [sp, #48]
1000d7c14:     	stp	x29, x30, [sp, #64]
1000d7c18:     	add	x29, sp, #64
1000d7c1c:     	sub	sp, sp, #2192
1000d7c20:     	mov	x19, x3
1000d7c24:     	mov	x20, x1
1000d7c28:     	mov	x21, x0
1000d7c2c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x27c>
1000d7c30:     	ldr	x8, [x8, #392]
1000d7c34:     	ldr	x8, [x8]
1000d7c38:     	stur	x8, [x29, #-72]
1000d7c3c:     	lsl	x8, x2, #3
1000d7c40:     	and	x22, x8, #0xfffffffffffffff0
1000d7c44:     	add	x0, sp, #136
1000d7c48:     	mov	w1, #2048
1000d7c4c:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d7c50:     	cbz	x22, 0x1000d7e54 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000d7c54:     	add	x8, x20, x22
1000d7c58:     	mov	w9, #252645135
1000d7c5c:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x8>
1000d7c60:     	add	x10, x10, #1724
1000d7c64:     	add	x11, sp, #8
1000d7c68:     	mov	x12, #0
1000d7c6c:     	ldp	w13, w14, [x20]
1000d7c70:     	and	w15, w13, w9
1000d7c74:     	and	w13, w9, w13, lsr #4
1000d7c78:     	stp	w15, w13, [sp, #8]
1000d7c7c:     	and	w13, w14, w9
1000d7c80:     	and	w14, w9, w14, lsr #4
1000d7c84:     	stp	w13, w14, [sp, #16]
1000d7c88:     	ldp	w13, w14, [x20, #8]
1000d7c8c:     	and	w15, w13, w9
1000d7c90:     	and	w13, w9, w13, lsr #4
1000d7c94:     	stp	w15, w13, [sp, #24]
1000d7c98:     	and	w13, w14, w9
1000d7c9c:     	and	w14, w9, w14, lsr #4
1000d7ca0:     	stp	w13, w14, [sp, #32]
1000d7ca4:     	ldp	w13, w14, [x20, #16]
1000d7ca8:     	and	w15, w13, w9
1000d7cac:     	and	w13, w9, w13, lsr #4
1000d7cb0:     	stp	w15, w13, [sp, #40]
1000d7cb4:     	and	w13, w14, w9
1000d7cb8:     	and	w14, w9, w14, lsr #4
1000d7cbc:     	stp	w13, w14, [sp, #48]
1000d7cc0:     	ldp	w13, w14, [x20, #24]
1000d7cc4:     	and	w15, w13, w9
1000d7cc8:     	and	w13, w9, w13, lsr #4
1000d7ccc:     	stp	w15, w13, [sp, #56]
1000d7cd0:     	and	w13, w14, w9
1000d7cd4:     	and	w14, w9, w14, lsr #4
1000d7cd8:     	stp	w13, w14, [sp, #64]
1000d7cdc:     	ldp	w13, w14, [x20, #32]
1000d7ce0:     	and	w15, w13, w9
1000d7ce4:     	and	w13, w9, w13, lsr #4
1000d7ce8:     	stp	w15, w13, [sp, #72]
1000d7cec:     	and	w13, w14, w9
1000d7cf0:     	and	w14, w9, w14, lsr #4
1000d7cf4:     	stp	w13, w14, [sp, #80]
1000d7cf8:     	ldp	w13, w14, [x20, #40]
1000d7cfc:     	and	w15, w13, w9
1000d7d00:     	and	w13, w9, w13, lsr #4
1000d7d04:     	stp	w15, w13, [sp, #88]
1000d7d08:     	and	w13, w14, w9
1000d7d0c:     	and	w14, w9, w14, lsr #4
1000d7d10:     	stp	w13, w14, [sp, #96]
1000d7d14:     	ldp	w13, w14, [x20, #48]
1000d7d18:     	and	w15, w13, w9
1000d7d1c:     	and	w13, w9, w13, lsr #4
1000d7d20:     	stp	w15, w13, [sp, #104]
1000d7d24:     	and	w13, w14, w9
1000d7d28:     	and	w14, w9, w14, lsr #4
1000d7d2c:     	stp	w13, w14, [sp, #112]
1000d7d30:     	ldp	w13, w14, [x20, #56]
1000d7d34:     	and	w15, w13, w9
1000d7d38:     	and	w13, w9, w13, lsr #4
1000d7d3c:     	stp	w15, w13, [sp, #120]
1000d7d40:     	and	w13, w14, w9
1000d7d44:     	and	w14, w9, w14, lsr #4
1000d7d48:     	stp	w13, w14, [sp, #128]
1000d7d4c:     	add	x13, sp, #136
1000d7d50:     	mov	x14, #0
1000d7d54:     	ldr	w4, [x21, x12, lsl #2]
1000d7d58:     	lsl	w15, w4, #4
1000d7d5c:     	and	x15, x15, #0xf0
1000d7d60:     	add	x15, x10, x15
1000d7d64:     	and	x16, x4, #0xf0
1000d7d68:     	add	x16, x10, x16
1000d7d6c:     	lsr	x17, x4, #4
1000d7d70:     	and	x17, x17, #0xf0
1000d7d74:     	add	x17, x10, x17
1000d7d78:     	lsr	x0, x4, #8
1000d7d7c:     	and	x0, x0, #0xf0
1000d7d80:     	add	x0, x10, x0
1000d7d84:     	lsr	x1, x4, #12
1000d7d88:     	and	x1, x1, #0xf0
1000d7d8c:     	add	x1, x10, x1
1000d7d90:     	lsr	x2, x4, #16
1000d7d94:     	and	x2, x2, #0xf0
1000d7d98:     	add	x2, x10, x2
1000d7d9c:     	lsr	x3, x4, #20
1000d7da0:     	and	x3, x3, #0xf0
1000d7da4:     	add	x3, x10, x3
1000d7da8:     	lsr	x4, x4, #24
1000d7dac:     	and	x4, x4, #0xf0
1000d7db0:     	add	x4, x10, x4
1000d7db4:     	mov	x5, x13
1000d7db8:     	add	x6, x11, x14
1000d7dbc:     	ldrb	w7, [x6]
1000d7dc0:     	ldrb	w7, [x15, x7]
1000d7dc4:     	ldrb	w22, [x6, #1]
1000d7dc8:     	ldrb	w22, [x17, x22]
1000d7dcc:     	ldrb	w23, [x6, #2]
1000d7dd0:     	ldrb	w23, [x1, x23]
1000d7dd4:     	add	w7, w7, w22
1000d7dd8:     	add	w7, w7, w23
1000d7ddc:     	ldrb	w22, [x6, #3]
1000d7de0:     	ldrb	w22, [x3, x22]
1000d7de4:     	ldrb	w23, [x6, #4]
1000d7de8:     	ldrb	w23, [x16, x23]
1000d7dec:     	ldrb	w24, [x6, #5]
1000d7df0:     	ldrb	w24, [x0, x24]
1000d7df4:     	add	w7, w7, w22
1000d7df8:     	add	w7, w7, w23
1000d7dfc:     	ldrb	w22, [x6, #6]
1000d7e00:     	ldrb	w22, [x2, x22]
1000d7e04:     	add	w7, w7, w24
1000d7e08:     	add	w7, w7, w22
1000d7e0c:     	ldrb	w6, [x6, #7]
1000d7e10:     	ldrb	w6, [x4, x6]
1000d7e14:     	add	w6, w7, w6
1000d7e18:     	scvtf	s0, w6
1000d7e1c:     	ldr	s1, [x5]
1000d7e20:     	fadd	s0, s1, s0
1000d7e24:     	str	s0, [x5], #128
1000d7e28:     	add	x14, x14, #8
1000d7e2c:     	cmp	x14, #128
1000d7e30:     	b.ne	0x1000d7db8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000d7e34:     	add	x12, x12, #1
1000d7e38:     	add	x13, x13, #4
1000d7e3c:     	cmp	x12, #32
1000d7e40:     	b.ne	0x1000d7d50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000d7e44:     	add	x21, x21, #128
1000d7e48:     	add	x20, x20, #64
1000d7e4c:     	cmp	x20, x8
1000d7e50:     	b.ne	0x1000d7c68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d7e54:     	add	x1, sp, #136
1000d7e58:     	mov	x0, x19
1000d7e5c:     	mov	w2, #2048
1000d7e60:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d7e64:     	ldur	x8, [x29, #-72]
1000d7e68:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x21c>
1000d7e6c:     	ldr	x9, [x9, #392]
1000d7e70:     	ldr	x9, [x9]
1000d7e74:     	cmp	x9, x8
1000d7e78:     	b.ne	0x1000d7e98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000d7e7c:     	add	sp, sp, #2192
1000d7e80:     	ldp	x29, x30, [sp, #64]
1000d7e84:     	ldp	x20, x19, [sp, #48]
1000d7e88:     	ldp	x22, x21, [sp, #32]
1000d7e8c:     	ldp	x24, x23, [sp, #16]
1000d7e90:     	ldp	x28, x27, [sp], #80
1000d7e94:     	ret
1000d7e98:     	bl	0x100163694 <_strcmp+0x100163694>

