00000001000bf630 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bf630:     	stp	x24, x23, [sp, #-48]!
1000bf634:     	stp	x22, x21, [sp, #16]
1000bf638:     	stp	x20, x19, [sp, #32]
1000bf63c:     	movi.2d	v0, #0000000000000000
1000bf640:     	stp	q0, q0, [x3]
1000bf644:     	lsl	x8, x4, #2
1000bf648:     	cmp	x2, #8
1000bf64c:     	b.hs	0x1000bf658 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bf650:     	mov	x13, #0
1000bf654:     	b	0x1000bfa58 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bf658:     	mov	x10, #0
1000bf65c:     	add	x9, x0, #16
1000bf660:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bf664:     	add	x11, x11, #956
1000bf668:     	mov	x12, x1
1000bf66c:     	ldr	w5, [x12]
1000bf670:     	lsr	x13, x5, #24
1000bf674:     	and	x13, x13, #0xf0
1000bf678:     	lsr	x14, x5, #20
1000bf67c:     	and	x14, x14, #0xf0
1000bf680:     	add	x13, x11, x13
1000bf684:     	add	x14, x11, x14
1000bf688:     	lsr	x15, x5, #16
1000bf68c:     	and	x15, x15, #0xf0
1000bf690:     	lsr	x16, x5, #12
1000bf694:     	and	x6, x16, #0xf0
1000bf698:     	add	x15, x11, x15
1000bf69c:     	lsr	x16, x5, #8
1000bf6a0:     	and	x16, x16, #0xf0
1000bf6a4:     	add	x16, x11, x16
1000bf6a8:     	lsr	x17, x5, #4
1000bf6ac:     	and	x17, x17, #0xf0
1000bf6b0:     	add	x17, x11, x17
1000bf6b4:     	and	x4, x5, #0xf0
1000bf6b8:     	add	x4, x11, x4
1000bf6bc:     	lsl	w5, w5, #4
1000bf6c0:     	and	x5, x5, #0xf0
1000bf6c4:     	ldur	w7, [x9, #-16]
1000bf6c8:     	add	x5, x11, x5
1000bf6cc:     	and	x19, x7, #0xf
1000bf6d0:     	ubfx	x20, x7, #4, #4
1000bf6d4:     	ldrsb	w20, [x4, x20]
1000bf6d8:     	ldrsb	w19, [x5, x19]
1000bf6dc:     	ubfx	x21, x7, #8, #4
1000bf6e0:     	ldrsb	w21, [x17, x21]
1000bf6e4:     	ubfx	x22, x7, #12, #4
1000bf6e8:     	ldrsb	w22, [x16, x22]
1000bf6ec:     	add	x6, x11, x6
1000bf6f0:     	ubfx	x23, x7, #16, #4
1000bf6f4:     	ldrsb	w23, [x6, x23]
1000bf6f8:     	add	w19, w19, w20
1000bf6fc:     	add	w19, w19, w21
1000bf700:     	ubfx	x20, x7, #20, #4
1000bf704:     	ldrsb	w20, [x15, x20]
1000bf708:     	ubfx	x21, x7, #24, #4
1000bf70c:     	add	w19, w19, w22
1000bf710:     	add	w19, w19, w23
1000bf714:     	ldrsb	w21, [x14, x21]
1000bf718:     	lsr	x7, x7, #28
1000bf71c:     	ldrsb	w7, [x13, x7]
1000bf720:     	add	w19, w19, w20
1000bf724:     	add	w19, w19, w21
1000bf728:     	add	w7, w19, w7
1000bf72c:     	scvtf	s0, w7
1000bf730:     	ldp	s1, s2, [x3]
1000bf734:     	fadd	s0, s1, s0
1000bf738:     	str	s0, [x3]
1000bf73c:     	ldur	w7, [x9, #-12]
1000bf740:     	and	x19, x7, #0xf
1000bf744:     	ldrsb	w19, [x5, x19]
1000bf748:     	ubfx	x20, x7, #4, #4
1000bf74c:     	ldrsb	w20, [x4, x20]
1000bf750:     	ubfx	x21, x7, #8, #4
1000bf754:     	ldrsb	w21, [x17, x21]
1000bf758:     	ubfx	x22, x7, #12, #4
1000bf75c:     	ldrsb	w22, [x16, x22]
1000bf760:     	ubfx	x23, x7, #16, #4
1000bf764:     	add	w19, w19, w20
1000bf768:     	add	w19, w19, w21
1000bf76c:     	ldrsb	w20, [x6, x23]
1000bf770:     	ubfx	x21, x7, #20, #4
1000bf774:     	ldrsb	w21, [x15, x21]
1000bf778:     	add	w19, w19, w22
1000bf77c:     	add	w19, w19, w20
1000bf780:     	ubfx	x20, x7, #24, #4
1000bf784:     	ldrsb	w20, [x14, x20]
1000bf788:     	add	w19, w19, w21
1000bf78c:     	add	w19, w19, w20
1000bf790:     	lsr	x7, x7, #28
1000bf794:     	ldrsb	w7, [x13, x7]
1000bf798:     	add	w7, w19, w7
1000bf79c:     	scvtf	s0, w7
1000bf7a0:     	fadd	s0, s2, s0
1000bf7a4:     	str	s0, [x3, #4]
1000bf7a8:     	ldur	w7, [x9, #-8]
1000bf7ac:     	and	x19, x7, #0xf
1000bf7b0:     	ldrsb	w19, [x5, x19]
1000bf7b4:     	ubfx	x20, x7, #4, #4
1000bf7b8:     	ldrsb	w20, [x4, x20]
1000bf7bc:     	ubfx	x21, x7, #8, #4
1000bf7c0:     	ldrsb	w21, [x17, x21]
1000bf7c4:     	ubfx	x22, x7, #12, #4
1000bf7c8:     	ldrsb	w22, [x16, x22]
1000bf7cc:     	ubfx	x23, x7, #16, #4
1000bf7d0:     	add	w19, w19, w20
1000bf7d4:     	add	w19, w19, w21
1000bf7d8:     	ldrsb	w20, [x6, x23]
1000bf7dc:     	ubfx	x21, x7, #20, #4
1000bf7e0:     	ldrsb	w21, [x15, x21]
1000bf7e4:     	add	w19, w19, w22
1000bf7e8:     	add	w19, w19, w20
1000bf7ec:     	ubfx	x20, x7, #24, #4
1000bf7f0:     	ldrsb	w20, [x14, x20]
1000bf7f4:     	add	w19, w19, w21
1000bf7f8:     	add	w19, w19, w20
1000bf7fc:     	lsr	x7, x7, #28
1000bf800:     	ldrsb	w7, [x13, x7]
1000bf804:     	add	w7, w19, w7
1000bf808:     	scvtf	s0, w7
1000bf80c:     	ldp	s1, s2, [x3, #8]
1000bf810:     	fadd	s0, s1, s0
1000bf814:     	str	s0, [x3, #8]
1000bf818:     	ldur	w7, [x9, #-4]
1000bf81c:     	and	x19, x7, #0xf
1000bf820:     	ldrsb	w19, [x5, x19]
1000bf824:     	ubfx	x20, x7, #4, #4
1000bf828:     	ldrsb	w20, [x4, x20]
1000bf82c:     	ubfx	x21, x7, #8, #4
1000bf830:     	ldrsb	w21, [x17, x21]
1000bf834:     	ubfx	x22, x7, #12, #4
1000bf838:     	ldrsb	w22, [x16, x22]
1000bf83c:     	ubfx	x23, x7, #16, #4
1000bf840:     	ldrsb	w23, [x6, x23]
1000bf844:     	ubfx	x24, x7, #20, #4
1000bf848:     	add	w19, w19, w20
1000bf84c:     	add	w19, w19, w21
1000bf850:     	ldrsb	w20, [x15, x24]
1000bf854:     	ubfx	x21, x7, #24, #4
1000bf858:     	ldrsb	w21, [x14, x21]
1000bf85c:     	add	w19, w19, w22
1000bf860:     	add	w19, w19, w23
1000bf864:     	lsr	x7, x7, #28
1000bf868:     	ldrsb	w7, [x13, x7]
1000bf86c:     	add	w19, w19, w20
1000bf870:     	add	w19, w19, w21
1000bf874:     	add	w7, w19, w7
1000bf878:     	scvtf	s0, w7
1000bf87c:     	fadd	s0, s2, s0
1000bf880:     	str	s0, [x3, #12]
1000bf884:     	ldr	w7, [x9]
1000bf888:     	and	x19, x7, #0xf
1000bf88c:     	ldrsb	w19, [x5, x19]
1000bf890:     	ubfx	x20, x7, #4, #4
1000bf894:     	ldrsb	w20, [x4, x20]
1000bf898:     	ubfx	x21, x7, #8, #4
1000bf89c:     	ldrsb	w21, [x17, x21]
1000bf8a0:     	ubfx	x22, x7, #12, #4
1000bf8a4:     	ldrsb	w22, [x16, x22]
1000bf8a8:     	ubfx	x23, x7, #16, #4
1000bf8ac:     	ldrsb	w23, [x6, x23]
1000bf8b0:     	add	w19, w19, w20
1000bf8b4:     	add	w19, w19, w21
1000bf8b8:     	ubfx	x20, x7, #20, #4
1000bf8bc:     	ldrsb	w20, [x15, x20]
1000bf8c0:     	ubfx	x21, x7, #24, #4
1000bf8c4:     	add	w19, w19, w22
1000bf8c8:     	add	w19, w19, w23
1000bf8cc:     	ldrsb	w21, [x14, x21]
1000bf8d0:     	lsr	x7, x7, #28
1000bf8d4:     	ldrsb	w7, [x13, x7]
1000bf8d8:     	add	w19, w19, w20
1000bf8dc:     	add	w19, w19, w21
1000bf8e0:     	add	w7, w19, w7
1000bf8e4:     	scvtf	s0, w7
1000bf8e8:     	ldp	s1, s2, [x3, #16]
1000bf8ec:     	fadd	s0, s1, s0
1000bf8f0:     	str	s0, [x3, #16]
1000bf8f4:     	ldr	w7, [x9, #4]
1000bf8f8:     	and	x19, x7, #0xf
1000bf8fc:     	ldrsb	w19, [x5, x19]
1000bf900:     	ubfx	x20, x7, #4, #4
1000bf904:     	ldrsb	w20, [x4, x20]
1000bf908:     	ubfx	x21, x7, #8, #4
1000bf90c:     	ldrsb	w21, [x17, x21]
1000bf910:     	ubfx	x22, x7, #12, #4
1000bf914:     	ldrsb	w22, [x16, x22]
1000bf918:     	ubfx	x23, x7, #16, #4
1000bf91c:     	add	w19, w19, w20
1000bf920:     	add	w19, w19, w21
1000bf924:     	ldrsb	w20, [x6, x23]
1000bf928:     	ubfx	x21, x7, #20, #4
1000bf92c:     	ldrsb	w21, [x15, x21]
1000bf930:     	add	w19, w19, w22
1000bf934:     	add	w19, w19, w20
1000bf938:     	ubfx	x20, x7, #24, #4
1000bf93c:     	ldrsb	w20, [x14, x20]
1000bf940:     	add	w19, w19, w21
1000bf944:     	add	w19, w19, w20
1000bf948:     	lsr	x7, x7, #28
1000bf94c:     	ldrsb	w7, [x13, x7]
1000bf950:     	add	w7, w19, w7
1000bf954:     	scvtf	s0, w7
1000bf958:     	fadd	s0, s2, s0
1000bf95c:     	str	s0, [x3, #20]
1000bf960:     	ldr	w7, [x9, #8]
1000bf964:     	and	x19, x7, #0xf
1000bf968:     	ldrsb	w19, [x5, x19]
1000bf96c:     	ubfx	x20, x7, #4, #4
1000bf970:     	ldrsb	w20, [x4, x20]
1000bf974:     	ubfx	x21, x7, #8, #4
1000bf978:     	ldrsb	w21, [x17, x21]
1000bf97c:     	ubfx	x22, x7, #12, #4
1000bf980:     	ldrsb	w22, [x16, x22]
1000bf984:     	ubfx	x23, x7, #16, #4
1000bf988:     	add	w19, w19, w20
1000bf98c:     	add	w19, w19, w21
1000bf990:     	ldrsb	w20, [x6, x23]
1000bf994:     	ubfx	x21, x7, #20, #4
1000bf998:     	ldrsb	w21, [x15, x21]
1000bf99c:     	add	w19, w19, w22
1000bf9a0:     	add	w19, w19, w20
1000bf9a4:     	ubfx	x20, x7, #24, #4
1000bf9a8:     	ldrsb	w20, [x14, x20]
1000bf9ac:     	add	w19, w19, w21
1000bf9b0:     	add	w19, w19, w20
1000bf9b4:     	lsr	x7, x7, #28
1000bf9b8:     	ldrsb	w7, [x13, x7]
1000bf9bc:     	add	w7, w19, w7
1000bf9c0:     	scvtf	s0, w7
1000bf9c4:     	ldp	s1, s2, [x3, #24]
1000bf9c8:     	fadd	s0, s1, s0
1000bf9cc:     	str	s0, [x3, #24]
1000bf9d0:     	ldr	w7, [x9, #12]
1000bf9d4:     	and	x19, x7, #0xf
1000bf9d8:     	ldrsb	w5, [x5, x19]
1000bf9dc:     	ubfx	x19, x7, #4, #4
1000bf9e0:     	ldrsb	w4, [x4, x19]
1000bf9e4:     	ubfx	x19, x7, #8, #4
1000bf9e8:     	ldrsb	w17, [x17, x19]
1000bf9ec:     	ubfx	x19, x7, #12, #4
1000bf9f0:     	ldrsb	w16, [x16, x19]
1000bf9f4:     	ubfx	x19, x7, #16, #4
1000bf9f8:     	ldrsb	w6, [x6, x19]
1000bf9fc:     	add	w4, w5, w4
1000bfa00:     	add	w17, w4, w17
1000bfa04:     	ubfx	x4, x7, #20, #4
1000bfa08:     	ldrsb	w15, [x15, x4]
1000bfa0c:     	ubfx	x4, x7, #24, #4
1000bfa10:     	add	w16, w17, w16
1000bfa14:     	add	w16, w16, w6
1000bfa18:     	ldrsb	w14, [x14, x4]
1000bfa1c:     	lsr	x17, x7, #28
1000bfa20:     	ldrsb	w13, [x13, x17]
1000bfa24:     	add	w15, w16, w15
1000bfa28:     	add	w14, w15, w14
1000bfa2c:     	add	w13, w14, w13
1000bfa30:     	scvtf	s0, w13
1000bfa34:     	fadd	s0, s2, s0
1000bfa38:     	str	s0, [x3, #28]
1000bfa3c:     	add	x13, x10, #8
1000bfa40:     	add	x12, x12, x8
1000bfa44:     	add	x14, x10, #16
1000bfa48:     	add	x9, x9, #32
1000bfa4c:     	mov	x10, x13
1000bfa50:     	cmp	x14, x2
1000bfa54:     	b.ls	0x1000bf66c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000bfa58:     	cmp	x13, x2
1000bfa5c:     	b.hs	0x1000bfbf0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5c0>
1000bfa60:     	ldp	s0, s1, [x3, #8]
1000bfa64:     	lsl	x9, x13, #2
1000bfa68:     	mov	w10, #-16
1000bfa6c:     	ldr	s2, [x3, #16]
1000bfa70:     	lsr	x11, x13, #3
1000bfa74:     	mul	x12, x8, x11
1000bfa78:     	ubfx	x11, x13, #1, #2
1000bfa7c:     	orr	x14, x12, x11
1000bfa80:     	and	w12, w9, #0x4
1000bfa84:     	ldrb	w14, [x1, x14]
1000bfa88:     	lsr	w14, w14, w12
1000bfa8c:     	and	w15, w14, #0xf
1000bfa90:     	cmp	w15, #8
1000bfa94:     	csel	w15, wzr, w10, lo
1000bfa98:     	and	x16, x9, #0xffffffffffffffe0
1000bfa9c:     	bfxil	w15, w14, #0, #4
1000bfaa0:     	bfxil	x16, x13, #1, #2
1000bfaa4:     	add	x14, x0, x16
1000bfaa8:     	ldrb	w16, [x14]
1000bfaac:     	lsr	w16, w16, w12
1000bfab0:     	scvtf	s3, w15
1000bfab4:     	and	w15, w16, #0xf
1000bfab8:     	cmp	w15, #8
1000bfabc:     	csel	w15, wzr, w10, lo
1000bfac0:     	bfxil	w15, w16, #0, #4
1000bfac4:     	scvtf	s4, w15
1000bfac8:     	ldp	s5, s6, [x3]
1000bfacc:     	fmsub	s4, s4, s3, s5
1000bfad0:     	str	s4, [x3]
1000bfad4:     	ldrb	w15, [x14, #4]
1000bfad8:     	lsr	w15, w15, w12
1000bfadc:     	and	w16, w15, #0xf
1000bfae0:     	cmp	w16, #8
1000bfae4:     	csel	w16, wzr, w10, lo
1000bfae8:     	bfxil	w16, w15, #0, #4
1000bfaec:     	scvtf	s4, w16
1000bfaf0:     	fmsub	s4, s4, s3, s6
1000bfaf4:     	str	s4, [x3, #4]
1000bfaf8:     	ldrb	w15, [x14, #8]
1000bfafc:     	lsr	w15, w15, w12
1000bfb00:     	and	w16, w15, #0xf
1000bfb04:     	cmp	w16, #8
1000bfb08:     	csel	w16, wzr, w10, lo
1000bfb0c:     	bfxil	w16, w15, #0, #4
1000bfb10:     	scvtf	s4, w16
1000bfb14:     	fmsub	s0, s4, s3, s0
1000bfb18:     	str	s0, [x3, #8]
1000bfb1c:     	ldrb	w15, [x14, #12]
1000bfb20:     	lsr	w15, w15, w12
1000bfb24:     	and	w16, w15, #0xf
1000bfb28:     	cmp	w16, #8
1000bfb2c:     	csel	w16, wzr, w10, lo
1000bfb30:     	bfxil	w16, w15, #0, #4
1000bfb34:     	scvtf	s4, w16
1000bfb38:     	fmsub	s1, s4, s3, s1
1000bfb3c:     	str	s1, [x3, #12]
1000bfb40:     	ldrb	w15, [x14, #16]
1000bfb44:     	lsr	w15, w15, w12
1000bfb48:     	and	w16, w15, #0xf
1000bfb4c:     	cmp	w16, #8
1000bfb50:     	csel	w16, wzr, w10, lo
1000bfb54:     	bfxil	w16, w15, #0, #4
1000bfb58:     	scvtf	s4, w16
1000bfb5c:     	fmsub	s2, s4, s3, s2
1000bfb60:     	str	s2, [x3, #16]
1000bfb64:     	ldrb	w15, [x14, #20]
1000bfb68:     	lsr	w15, w15, w12
1000bfb6c:     	and	w16, w15, #0xf
1000bfb70:     	cmp	w16, #8
1000bfb74:     	csel	w16, wzr, w10, lo
1000bfb78:     	bfxil	w16, w15, #0, #4
1000bfb7c:     	scvtf	s4, w16
1000bfb80:     	ldp	s5, s6, [x3, #20]
1000bfb84:     	fmsub	s4, s4, s3, s5
1000bfb88:     	str	s4, [x3, #20]
1000bfb8c:     	ldrb	w14, [x14, #24]
1000bfb90:     	lsr	w14, w14, w12
1000bfb94:     	and	w15, w14, #0xf
1000bfb98:     	cmp	w15, #8
1000bfb9c:     	csel	w15, wzr, w10, lo
1000bfba0:     	bfxil	w15, w14, #0, #4
1000bfba4:     	scvtf	s4, w15
1000bfba8:     	fmsub	s4, s4, s3, s6
1000bfbac:     	str	s4, [x3, #24]
1000bfbb0:     	orr	x11, x9, x11
1000bfbb4:     	orr	x11, x11, #0x1c
1000bfbb8:     	ldrb	w11, [x0, x11]
1000bfbbc:     	lsr	w11, w11, w12
1000bfbc0:     	and	w12, w11, #0xf
1000bfbc4:     	cmp	w12, #8
1000bfbc8:     	csel	w12, wzr, w10, lo
1000bfbcc:     	bfxil	w12, w11, #0, #4
1000bfbd0:     	scvtf	s4, w12
1000bfbd4:     	ldr	s5, [x3, #28]
1000bfbd8:     	fmsub	s3, s4, s3, s5
1000bfbdc:     	str	s3, [x3, #28]
1000bfbe0:     	add	x13, x13, #1
1000bfbe4:     	add	x9, x9, #4
1000bfbe8:     	cmp	x2, x13
1000bfbec:     	b.ne	0x1000bfa70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000bfbf0:     	ldp	x20, x19, [sp, #32]
1000bfbf4:     	ldp	x22, x21, [sp, #16]
1000bfbf8:     	ldp	x24, x23, [sp], #48
1000bfbfc:     	ret

