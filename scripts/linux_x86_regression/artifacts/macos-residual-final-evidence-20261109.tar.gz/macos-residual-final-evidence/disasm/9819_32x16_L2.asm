00000001000d41bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d41bc:     	stp	x28, x27, [sp, #-64]!
1000d41c0:     	stp	x22, x21, [sp, #16]
1000d41c4:     	stp	x20, x19, [sp, #32]
1000d41c8:     	stp	x29, x30, [sp, #48]
1000d41cc:     	add	x29, sp, #48
1000d41d0:     	sub	sp, sp, #2064
1000d41d4:     	mov	x19, x3
1000d41d8:     	mov	x20, x1
1000d41dc:     	mov	x21, x0
1000d41e0:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xcc>
1000d41e4:     	ldr	x8, [x8, #392]
1000d41e8:     	ldr	x8, [x8]
1000d41ec:     	stur	x8, [x29, #-56]
1000d41f0:     	lsl	x8, x2, #3
1000d41f4:     	and	x22, x8, #0xfffffffffffffff0
1000d41f8:     	add	x0, sp, #8
1000d41fc:     	mov	w1, #2048
1000d4200:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d4204:     	cbz	x22, 0x1000d431c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d4208:     	add	x8, x20, x22
1000d420c:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf0>
1000d4210:     	add	x9, x9, #1756
1000d4214:     	mov	x10, #0
1000d4218:     	add	x11, sp, #8
1000d421c:     	mov	x12, #0
1000d4220:     	ldr	w2, [x21, x10, lsl #2]
1000d4224:     	lsl	w13, w2, #4
1000d4228:     	and	x13, x13, #0xf0
1000d422c:     	and	x14, x2, #0xf0
1000d4230:     	lsr	x15, x2, #4
1000d4234:     	and	x15, x15, #0xf0
1000d4238:     	lsr	x16, x2, #8
1000d423c:     	and	x16, x16, #0xf0
1000d4240:     	lsr	x17, x2, #12
1000d4244:     	and	x17, x17, #0xf0
1000d4248:     	lsr	x0, x2, #16
1000d424c:     	and	x0, x0, #0xf0
1000d4250:     	lsr	x1, x2, #20
1000d4254:     	and	x1, x1, #0xf0
1000d4258:     	lsr	x2, x2, #24
1000d425c:     	and	x2, x2, #0xf0
1000d4260:     	mov	x3, x11
1000d4264:     	ldr	w4, [x20, x12]
1000d4268:     	and	x5, x4, #0xf
1000d426c:     	orr	x5, x13, x5
1000d4270:     	ldrb	w5, [x9, x5]
1000d4274:     	ubfx	x6, x4, #4, #4
1000d4278:     	orr	x6, x14, x6
1000d427c:     	ldrb	w6, [x9, x6]
1000d4280:     	ubfx	x7, x4, #8, #4
1000d4284:     	orr	x7, x15, x7
1000d4288:     	ldrb	w7, [x9, x7]
1000d428c:     	add	w5, w5, w6
1000d4290:     	add	w5, w5, w7
1000d4294:     	ubfx	x6, x4, #12, #4
1000d4298:     	orr	x6, x16, x6
1000d429c:     	ldrb	w6, [x9, x6]
1000d42a0:     	ubfx	x7, x4, #16, #4
1000d42a4:     	orr	x7, x17, x7
1000d42a8:     	ldrb	w7, [x9, x7]
1000d42ac:     	add	w5, w5, w6
1000d42b0:     	add	w5, w5, w7
1000d42b4:     	ubfx	x6, x4, #20, #4
1000d42b8:     	orr	x6, x0, x6
1000d42bc:     	ldrb	w6, [x9, x6]
1000d42c0:     	ubfx	x7, x4, #24, #4
1000d42c4:     	orr	x7, x1, x7
1000d42c8:     	ldrb	w7, [x9, x7]
1000d42cc:     	add	w5, w5, w6
1000d42d0:     	add	w5, w5, w7
1000d42d4:     	orr	x4, x2, x4, lsr #28
1000d42d8:     	ldrb	w4, [x9, x4]
1000d42dc:     	add	w4, w5, w4
1000d42e0:     	scvtf	s0, w4
1000d42e4:     	ldr	s1, [x3]
1000d42e8:     	fadd	s0, s1, s0
1000d42ec:     	str	s0, [x3], #128
1000d42f0:     	add	x12, x12, #4
1000d42f4:     	cmp	x12, #64
1000d42f8:     	b.ne	0x1000d4264 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d42fc:     	add	x10, x10, #1
1000d4300:     	add	x11, x11, #4
1000d4304:     	cmp	x10, #32
1000d4308:     	b.ne	0x1000d421c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d430c:     	add	x21, x21, #128
1000d4310:     	add	x20, x20, #64
1000d4314:     	cmp	x20, x8
1000d4318:     	b.ne	0x1000d4214 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d431c:     	add	x1, sp, #8
1000d4320:     	mov	x0, x19
1000d4324:     	mov	w2, #2048
1000d4328:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d432c:     	ldur	x8, [x29, #-56]
1000d4330:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x21c>
1000d4334:     	ldr	x9, [x9, #392]
1000d4338:     	ldr	x9, [x9]
1000d433c:     	cmp	x9, x8
1000d4340:     	b.ne	0x1000d435c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d4344:     	add	sp, sp, #2064
1000d4348:     	ldp	x29, x30, [sp, #48]
1000d434c:     	ldp	x20, x19, [sp, #32]
1000d4350:     	ldp	x22, x21, [sp, #16]
1000d4354:     	ldp	x28, x27, [sp], #64
1000d4358:     	ret
1000d435c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

