00000001000ce610 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce610:     	sub	sp, sp, #400
1000ce614:     	stp	x28, x27, [sp, #304]
1000ce618:     	stp	x26, x25, [sp, #320]
1000ce61c:     	stp	x24, x23, [sp, #336]
1000ce620:     	stp	x22, x21, [sp, #352]
1000ce624:     	stp	x20, x19, [sp, #368]
1000ce628:     	stp	x29, x30, [sp, #384]
1000ce62c:     	add	x29, sp, #384
1000ce630:     	str	x3, [sp]
1000ce634:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0xc>
1000ce638:     	ldr	x8, [x8, #392]
1000ce63c:     	ldr	x8, [x8]
1000ce640:     	stur	x8, [x29, #-96]
1000ce644:     	movi.2d	v0, #0000000000000000
1000ce648:     	stp	q0, q0, [sp, #256]
1000ce64c:     	stp	q0, q0, [sp, #224]
1000ce650:     	stp	q0, q0, [sp, #192]
1000ce654:     	stp	q0, q0, [sp, #160]
1000ce658:     	stp	q0, q0, [sp, #128]
1000ce65c:     	stp	q0, q0, [sp, #96]
1000ce660:     	stp	q0, q0, [sp, #64]
1000ce664:     	stp	q0, q0, [sp, #32]
1000ce668:     	ands	x8, x2, #0xfffffffffffffffe
1000ce66c:     	b.eq	0x1000ce810 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x200>
1000ce670:     	add	x8, x1, x8
1000ce674:     	str	x8, [sp, #8]
1000ce678:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x48>
1000ce67c:     	add	x9, x9, #2012
1000ce680:     	mov	x11, #0
1000ce684:     	ldp	w4, w23, [x1]
1000ce688:     	ubfx	x8, x4, #4, #4
1000ce68c:     	stp	x1, x8, [sp, #16]
1000ce690:     	ubfx	x13, x4, #8, #4
1000ce694:     	and	x14, x4, #0xf
1000ce698:     	ubfx	x15, x4, #12, #4
1000ce69c:     	ubfx	x16, x4, #16, #4
1000ce6a0:     	ubfx	x17, x4, #20, #4
1000ce6a4:     	ubfx	x2, x4, #24, #4
1000ce6a8:     	lsr	x4, x4, #28
1000ce6ac:     	and	x5, x23, #0xf
1000ce6b0:     	ubfx	x6, x23, #4, #4
1000ce6b4:     	ubfx	x7, x23, #8, #4
1000ce6b8:     	ubfx	x19, x23, #12, #4
1000ce6bc:     	ubfx	x20, x23, #16, #4
1000ce6c0:     	ubfx	x21, x23, #20, #4
1000ce6c4:     	ubfx	x22, x23, #24, #4
1000ce6c8:     	lsr	x23, x23, #28
1000ce6cc:     	ldr	w24, [x0, x11]
1000ce6d0:     	lsl	w25, w24, #4
1000ce6d4:     	and	x25, x25, #0xf0
1000ce6d8:     	orr	x26, x25, x14
1000ce6dc:     	ldrsb	w26, [x9, x26]
1000ce6e0:     	and	x27, x24, #0xf0
1000ce6e4:     	ldr	x8, [sp, #24]
1000ce6e8:     	orr	x28, x27, x8
1000ce6ec:     	ldrsb	w28, [x9, x28]
1000ce6f0:     	lsr	x30, x24, #4
1000ce6f4:     	and	x30, x30, #0xf0
1000ce6f8:     	orr	x8, x30, x13
1000ce6fc:     	ldrsb	w8, [x9, x8]
1000ce700:     	add	w26, w26, w28
1000ce704:     	add	w8, w26, w8
1000ce708:     	lsr	x26, x24, #8
1000ce70c:     	and	x26, x26, #0xf0
1000ce710:     	orr	x28, x26, x15
1000ce714:     	ldrsb	w28, [x9, x28]
1000ce718:     	lsr	x3, x24, #12
1000ce71c:     	and	x3, x3, #0xf0
1000ce720:     	orr	x10, x3, x16
1000ce724:     	ldrsb	w10, [x9, x10]
1000ce728:     	add	w8, w8, w28
1000ce72c:     	add	w8, w8, w10
1000ce730:     	lsr	x10, x24, #16
1000ce734:     	and	x10, x10, #0xf0
1000ce738:     	orr	x28, x10, x17
1000ce73c:     	ldrsb	w28, [x9, x28]
1000ce740:     	lsr	x1, x24, #20
1000ce744:     	and	x1, x1, #0xf0
1000ce748:     	orr	x12, x1, x2
1000ce74c:     	ldrsb	w12, [x9, x12]
1000ce750:     	add	w8, w8, w28
1000ce754:     	add	x28, sp, #32
1000ce758:     	add	w8, w8, w12
1000ce75c:     	lsr	x12, x24, #24
1000ce760:     	and	x12, x12, #0xf0
1000ce764:     	orr	x24, x12, x4
1000ce768:     	ldrsb	w24, [x9, x24]
1000ce76c:     	add	w8, w8, w24
1000ce770:     	scvtf	s0, w8
1000ce774:     	add	x8, x28, x11
1000ce778:     	ldr	s1, [x8]
1000ce77c:     	fadd	s0, s1, s0
1000ce780:     	orr	x24, x25, x5
1000ce784:     	ldrsb	w24, [x9, x24]
1000ce788:     	orr	x25, x27, x6
1000ce78c:     	ldrsb	w25, [x9, x25]
1000ce790:     	orr	x27, x30, x7
1000ce794:     	ldrsb	w27, [x9, x27]
1000ce798:     	add	w24, w24, w25
1000ce79c:     	add	w24, w24, w27
1000ce7a0:     	orr	x25, x26, x19
1000ce7a4:     	ldrsb	w25, [x9, x25]
1000ce7a8:     	orr	x3, x3, x20
1000ce7ac:     	ldrsb	w3, [x9, x3]
1000ce7b0:     	orr	x10, x10, x21
1000ce7b4:     	ldrsb	w10, [x9, x10]
1000ce7b8:     	add	w24, w24, w25
1000ce7bc:     	add	w3, w24, w3
1000ce7c0:     	orr	x1, x1, x22
1000ce7c4:     	ldrsb	w1, [x9, x1]
1000ce7c8:     	add	w10, w3, w10
1000ce7cc:     	add	w10, w10, w1
1000ce7d0:     	orr	x12, x12, x23
1000ce7d4:     	ldrsb	w12, [x9, x12]
1000ce7d8:     	add	w10, w10, w12
1000ce7dc:     	scvtf	s1, w10
1000ce7e0:     	str	s0, [x8]
1000ce7e4:     	ldr	s0, [x8, #128]
1000ce7e8:     	fadd	s0, s0, s1
1000ce7ec:     	str	s0, [x8, #128]
1000ce7f0:     	add	x11, x11, #4
1000ce7f4:     	cmp	x11, #128
1000ce7f8:     	b.ne	0x1000ce6cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000ce7fc:     	add	x0, x0, #128
1000ce800:     	ldp	x8, x1, [sp, #8]
1000ce804:     	add	x1, x1, #8
1000ce808:     	cmp	x1, x8
1000ce80c:     	b.ne	0x1000ce680 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000ce810:     	ldp	q0, q1, [sp, #224]
1000ce814:     	ldr	x8, [sp]
1000ce818:     	stp	q0, q1, [x8, #192]
1000ce81c:     	ldp	q0, q1, [sp, #256]
1000ce820:     	stp	q0, q1, [x8, #224]
1000ce824:     	ldp	q0, q1, [sp, #160]
1000ce828:     	stp	q0, q1, [x8, #128]
1000ce82c:     	ldp	q0, q1, [sp, #192]
1000ce830:     	stp	q0, q1, [x8, #160]
1000ce834:     	ldp	q0, q1, [sp, #96]
1000ce838:     	stp	q0, q1, [x8, #64]
1000ce83c:     	ldp	q0, q1, [sp, #128]
1000ce840:     	stp	q0, q1, [x8, #96]
1000ce844:     	ldp	q0, q1, [sp, #32]
1000ce848:     	stp	q0, q1, [x8]
1000ce84c:     	ldp	q0, q1, [sp, #64]
1000ce850:     	stp	q0, q1, [x8, #32]
1000ce854:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x22c>
1000ce858:     	ldr	x8, [x8, #392]
1000ce85c:     	ldr	x8, [x8]
1000ce860:     	ldur	x9, [x29, #-96]
1000ce864:     	cmp	x8, x9
1000ce868:     	b.ne	0x1000ce88c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x27c>
1000ce86c:     	ldp	x29, x30, [sp, #384]
1000ce870:     	ldp	x20, x19, [sp, #368]
1000ce874:     	ldp	x22, x21, [sp, #352]
1000ce878:     	ldp	x24, x23, [sp, #336]
1000ce87c:     	ldp	x26, x25, [sp, #320]
1000ce880:     	ldp	x28, x27, [sp, #304]
1000ce884:     	add	sp, sp, #400
1000ce888:     	ret
1000ce88c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

