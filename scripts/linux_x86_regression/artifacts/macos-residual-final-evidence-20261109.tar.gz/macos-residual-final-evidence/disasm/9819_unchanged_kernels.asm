
bin/9819_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000421d8 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000421d8:     	sub	sp, sp, #80
1000421dc:     	stp	x22, x21, [sp, #32]
1000421e0:     	stp	x20, x19, [sp, #48]
1000421e4:     	stp	x29, x30, [sp, #64]
1000421e8:     	add	x29, sp, #64
1000421ec:     	mov	x19, x3
1000421f0:     	mov	x20, x2
1000421f4:     	mov	x21, x1
1000421f8:     	mov	x22, x0
1000421fc:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2d8>
100042200:     	ldr	x8, [x8, #16]
100042204:     	ldaprb	w8, [x8]
100042208:     	tbz	w8, #0, 0x100042254 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
10004220c:     	stp	x21, x22, [sp, #16]
100042210:     	stp	x19, x20, [sp]
100042214:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2f0>
100042218:     	ldr	x8, [x8, #192]
10004221c:     	ldr	x0, [x8, #24]
100042220:     	cbz	x0, 0x1000422ac <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100042224:     	ldr	x8, [x0]
100042228:     	ldr	x8, [x8, #48]
10004222c:     	add	x1, sp, #24
100042230:     	add	x2, sp, #16
100042234:     	add	x3, sp, #8
100042238:     	mov	x4, sp
10004223c:     	blr	x8
100042240:     	ldp	x29, x30, [sp, #64]
100042244:     	ldp	x20, x19, [sp, #48]
100042248:     	ldp	x22, x21, [sp, #32]
10004224c:     	add	sp, sp, #80
100042250:     	ret
100042254:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x330>
100042258:     	ldr	x0, [x0, #16]
10004225c:     	bl	0x10015f690 <_strcmp+0x10015f690>
100042260:     	cbz	w0, 0x10004220c <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100042264:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x340>
100042268:     	ldr	x8, [x8, #192]
10004226c:     	mov	w0, #0
100042270:     	mov	w1, #2
100042274:     	mov	w2, #8
100042278:     	mov	w3, #0
10004227c:     	bl	0x10015c718 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100042280:     	adrp	x0, 0x100003000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa0c>
100042284:     	add	x0, x0, #1968
100042288:     	adrp	x1, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x364>
10004228c:     	ldr	x1, [x1, #192]
100042290:     	adrp	x2, 0x100000000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa10>
100042294:     	add	x2, x2, #0
100042298:     	bl	0x10015f660 <_strcmp+0x10015f660>
10004229c:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x378>
1000422a0:     	ldr	x0, [x0, #16]
1000422a4:     	bl	0x10015f69c <_strcmp+0x10015f69c>
1000422a8:     	b	0x10004220c <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000422ac:     	bl	0x1000037fc <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000422b0:     	mov	x19, x0
1000422b4:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x390>
1000422b8:     	ldr	x0, [x0, #16]
1000422bc:     	bl	0x10015f684 <_strcmp+0x10015f684>
1000422c0:     	mov	x0, x19
1000422c4:     	bl	0x10015f5f4 <_strcmp+0x10015f5f4>

00000001000422cc <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000422cc:     	sub	sp, sp, #80
1000422d0:     	stp	x22, x21, [sp, #32]
1000422d4:     	stp	x20, x19, [sp, #48]
1000422d8:     	stp	x29, x30, [sp, #64]
1000422dc:     	add	x29, sp, #64
1000422e0:     	mov	x19, x3
1000422e4:     	mov	x20, x2
1000422e8:     	mov	x21, x1
1000422ec:     	mov	x22, x0
1000422f0:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3cc>
1000422f4:     	ldr	x8, [x8, #24]
1000422f8:     	ldaprb	w8, [x8]
1000422fc:     	tbz	w8, #0, 0x100042348 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100042300:     	stp	x21, x22, [sp, #16]
100042304:     	stp	x19, x20, [sp]
100042308:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3e4>
10004230c:     	ldr	x8, [x8, #200]
100042310:     	ldr	x0, [x8, #24]
100042314:     	cbz	x0, 0x1000423a0 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100042318:     	ldr	x8, [x0]
10004231c:     	ldr	x8, [x8, #48]
100042320:     	add	x1, sp, #24
100042324:     	add	x2, sp, #16
100042328:     	add	x3, sp, #8
10004232c:     	mov	x4, sp
100042330:     	blr	x8
100042334:     	ldp	x29, x30, [sp, #64]
100042338:     	ldp	x20, x19, [sp, #48]
10004233c:     	ldp	x22, x21, [sp, #32]
100042340:     	add	sp, sp, #80
100042344:     	ret
100042348:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x424>
10004234c:     	ldr	x0, [x0, #24]
100042350:     	bl	0x10015f690 <_strcmp+0x10015f690>
100042354:     	cbz	w0, 0x100042300 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100042358:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x434>
10004235c:     	ldr	x8, [x8, #200]
100042360:     	mov	w0, #2
100042364:     	mov	w1, #2
100042368:     	mov	w2, #8
10004236c:     	mov	w3, #0
100042370:     	bl	0x10015c718 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100042374:     	adrp	x0, 0x100003000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa0>
100042378:     	add	x0, x0, #1968
10004237c:     	adrp	x1, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x458>
100042380:     	ldr	x1, [x1, #200]
100042384:     	adrp	x2, 0x100000000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa4>
100042388:     	add	x2, x2, #0
10004238c:     	bl	0x10015f660 <_strcmp+0x10015f660>
100042390:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x46c>
100042394:     	ldr	x0, [x0, #24]
100042398:     	bl	0x10015f69c <_strcmp+0x10015f69c>
10004239c:     	b	0x100042300 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000423a0:     	bl	0x1000037fc <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000423a4:     	mov	x19, x0
1000423a8:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x484>
1000423ac:     	ldr	x0, [x0, #24]
1000423b0:     	bl	0x10015f684 <_strcmp+0x10015f684>
1000423b4:     	mov	x0, x19
1000423b8:     	bl	0x10015f5f4 <_strcmp+0x10015f5f4>

000000010007dd08 <void kernel<signed char, 1ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10007dd08:     	b	0x10007dd0c <zvec::turbo::DistanceMatrix<signed char, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(signed char const*, signed char const*, unsigned long, float*)>

000000010007ddfc <void kernel<signed char, 1ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10007ddfc:     	b	0x10007de00 <zvec::turbo::DistanceMatrix<signed char, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(signed char const*, signed char const*, unsigned long, float*)>

000000010007f3f0 <void kernel<signed char, 2ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10007f3f0:     	cbz	x2, 0x10007f404 <void kernel<signed char, 2ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
10007f3f4:     	mov	w4, #1
10007f3f8:     	mov	x5, #0
10007f3fc:     	mov	x6, #0
10007f400:     	b	0x10007f40c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10007f404:     	str	xzr, [x3]
10007f408:     	ret

000000010007f55c <void kernel<signed char, 2ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10007f55c:     	cbz	x2, 0x10007f570 <void kernel<signed char, 2ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
10007f560:     	mov	w4, #1
10007f564:     	mov	x5, #0
10007f568:     	mov	x6, #0
10007f56c:     	b	0x10007f578 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10007f570:     	str	xzr, [x3]
10007f574:     	ret

000000010008123c <void kernel<signed char, 2ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10008123c:     	stp	x22, x21, [sp, #-48]!
100081240:     	stp	x20, x19, [sp, #16]
100081244:     	stp	x29, x30, [sp, #32]
100081248:     	add	x29, sp, #32
10008124c:     	mov	x19, x3
100081250:     	cbz	x2, 0x1000812a0 <void kernel<signed char, 2ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100081254:     	mov	x20, x2
100081258:     	mov	x22, x1
10008125c:     	mov	x21, x0
100081260:     	mov	x3, x19
100081264:     	mov	w4, #2
100081268:     	mov	x5, #0
10008126c:     	mov	x6, #0
100081270:     	bl	0x10007f40c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100081274:     	add	x1, x22, #4
100081278:     	add	x3, x19, #8
10008127c:     	mov	x0, x21
100081280:     	mov	x2, x20
100081284:     	mov	w4, #2
100081288:     	mov	x5, #0
10008128c:     	mov	x6, #0
100081290:     	ldp	x29, x30, [sp, #32]
100081294:     	ldp	x20, x19, [sp, #16]
100081298:     	ldp	x22, x21, [sp], #48
10008129c:     	b	0x10007f40c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000812a0:     	stp	xzr, xzr, [x19]
1000812a4:     	ldp	x29, x30, [sp, #32]
1000812a8:     	ldp	x20, x19, [sp, #16]
1000812ac:     	ldp	x22, x21, [sp], #48
1000812b0:     	ret

00000001000812b4 <void kernel<signed char, 2ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000812b4:     	stp	x22, x21, [sp, #-48]!
1000812b8:     	stp	x20, x19, [sp, #16]
1000812bc:     	stp	x29, x30, [sp, #32]
1000812c0:     	add	x29, sp, #32
1000812c4:     	mov	x19, x3
1000812c8:     	cbz	x2, 0x100081318 <void kernel<signed char, 2ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
1000812cc:     	mov	x20, x2
1000812d0:     	mov	x22, x1
1000812d4:     	mov	x21, x0
1000812d8:     	mov	x3, x19
1000812dc:     	mov	w4, #2
1000812e0:     	mov	x5, #0
1000812e4:     	mov	x6, #0
1000812e8:     	bl	0x10007f578 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000812ec:     	add	x1, x22, #4
1000812f0:     	add	x3, x19, #8
1000812f4:     	mov	x0, x21
1000812f8:     	mov	x2, x20
1000812fc:     	mov	w4, #2
100081300:     	mov	x5, #0
100081304:     	mov	x6, #0
100081308:     	ldp	x29, x30, [sp, #32]
10008130c:     	ldp	x20, x19, [sp, #16]
100081310:     	ldp	x22, x21, [sp], #48
100081314:     	b	0x10007f578 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100081318:     	stp	xzr, xzr, [x19]
10008131c:     	ldp	x29, x30, [sp, #32]
100081320:     	ldp	x20, x19, [sp, #16]
100081324:     	ldp	x22, x21, [sp], #48
100081328:     	ret

0000000100082cd0 <void kernel<signed char, 4ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100082cd0:     	cbz	x2, 0x100082ce4 <void kernel<signed char, 4ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100082cd4:     	mov	w4, #1
100082cd8:     	mov	x5, #0
100082cdc:     	mov	x6, #0
100082ce0:     	b	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100082ce4:     	stp	xzr, xzr, [x3]
100082ce8:     	ret

0000000100082f10 <void kernel<signed char, 4ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100082f10:     	cbz	x2, 0x100082f24 <void kernel<signed char, 4ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100082f14:     	mov	w4, #1
100082f18:     	mov	x5, #0
100082f1c:     	mov	x6, #0
100082f20:     	b	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100082f24:     	stp	xzr, xzr, [x3]
100082f28:     	ret

0000000100085378 <void kernel<signed char, 4ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100085378:     	stp	x22, x21, [sp, #-48]!
10008537c:     	stp	x20, x19, [sp, #16]
100085380:     	stp	x29, x30, [sp, #32]
100085384:     	add	x29, sp, #32
100085388:     	mov	x19, x3
10008538c:     	cbz	x2, 0x1000853dc <void kernel<signed char, 4ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100085390:     	mov	x20, x2
100085394:     	mov	x22, x1
100085398:     	mov	x21, x0
10008539c:     	mov	x3, x19
1000853a0:     	mov	w4, #2
1000853a4:     	mov	x5, #0
1000853a8:     	mov	x6, #0
1000853ac:     	bl	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000853b0:     	add	x1, x22, #4
1000853b4:     	add	x3, x19, #16
1000853b8:     	mov	x0, x21
1000853bc:     	mov	x2, x20
1000853c0:     	mov	w4, #2
1000853c4:     	mov	x5, #0
1000853c8:     	mov	x6, #0
1000853cc:     	ldp	x29, x30, [sp, #32]
1000853d0:     	ldp	x20, x19, [sp, #16]
1000853d4:     	ldp	x22, x21, [sp], #48
1000853d8:     	b	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000853dc:     	movi.2d	v0, #0000000000000000
1000853e0:     	stp	q0, q0, [x19]
1000853e4:     	ldp	x29, x30, [sp, #32]
1000853e8:     	ldp	x20, x19, [sp, #16]
1000853ec:     	ldp	x22, x21, [sp], #48
1000853f0:     	ret

00000001000853f4 <void kernel<signed char, 4ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000853f4:     	stp	x22, x21, [sp, #-48]!
1000853f8:     	stp	x20, x19, [sp, #16]
1000853fc:     	stp	x29, x30, [sp, #32]
100085400:     	add	x29, sp, #32
100085404:     	mov	x19, x3
100085408:     	cbz	x2, 0x100085458 <void kernel<signed char, 4ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
10008540c:     	mov	x20, x2
100085410:     	mov	x22, x1
100085414:     	mov	x21, x0
100085418:     	mov	x3, x19
10008541c:     	mov	w4, #2
100085420:     	mov	x5, #0
100085424:     	mov	x6, #0
100085428:     	bl	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008542c:     	add	x1, x22, #4
100085430:     	add	x3, x19, #16
100085434:     	mov	x0, x21
100085438:     	mov	x2, x20
10008543c:     	mov	w4, #2
100085440:     	mov	x5, #0
100085444:     	mov	x6, #0
100085448:     	ldp	x29, x30, [sp, #32]
10008544c:     	ldp	x20, x19, [sp, #16]
100085450:     	ldp	x22, x21, [sp], #48
100085454:     	b	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100085458:     	movi.2d	v0, #0000000000000000
10008545c:     	stp	q0, q0, [x19]
100085460:     	ldp	x29, x30, [sp, #32]
100085464:     	ldp	x20, x19, [sp, #16]
100085468:     	ldp	x22, x21, [sp], #48
10008546c:     	ret

000000010008710c <void kernel<signed char, 4ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10008710c:     	stp	x22, x21, [sp, #-48]!
100087110:     	stp	x20, x19, [sp, #16]
100087114:     	stp	x29, x30, [sp, #32]
100087118:     	add	x29, sp, #32
10008711c:     	mov	x19, x3
100087120:     	cbz	x2, 0x1000871b0 <void kernel<signed char, 4ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
100087124:     	mov	x20, x2
100087128:     	mov	x22, x1
10008712c:     	mov	x21, x0
100087130:     	mov	x3, x19
100087134:     	mov	w4, #4
100087138:     	mov	x5, #0
10008713c:     	mov	x6, #0
100087140:     	bl	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087144:     	add	x1, x22, #4
100087148:     	add	x3, x19, #16
10008714c:     	mov	x0, x21
100087150:     	mov	x2, x20
100087154:     	mov	w4, #4
100087158:     	mov	x5, #0
10008715c:     	mov	x6, #0
100087160:     	bl	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087164:     	add	x1, x22, #8
100087168:     	add	x3, x19, #32
10008716c:     	mov	x0, x21
100087170:     	mov	x2, x20
100087174:     	mov	w4, #4
100087178:     	mov	x5, #0
10008717c:     	mov	x6, #0
100087180:     	bl	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087184:     	add	x1, x22, #12
100087188:     	add	x3, x19, #48
10008718c:     	mov	x0, x21
100087190:     	mov	x2, x20
100087194:     	mov	w4, #4
100087198:     	mov	x5, #0
10008719c:     	mov	x6, #0
1000871a0:     	ldp	x29, x30, [sp, #32]
1000871a4:     	ldp	x20, x19, [sp, #16]
1000871a8:     	ldp	x22, x21, [sp], #48
1000871ac:     	b	0x100082cec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000871b0:     	movi.2d	v0, #0000000000000000
1000871b4:     	stp	q0, q0, [x19, #32]
1000871b8:     	stp	q0, q0, [x19]
1000871bc:     	ldp	x29, x30, [sp, #32]
1000871c0:     	ldp	x20, x19, [sp, #16]
1000871c4:     	ldp	x22, x21, [sp], #48
1000871c8:     	ret

00000001000871cc <void kernel<signed char, 4ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000871cc:     	stp	x22, x21, [sp, #-48]!
1000871d0:     	stp	x20, x19, [sp, #16]
1000871d4:     	stp	x29, x30, [sp, #32]
1000871d8:     	add	x29, sp, #32
1000871dc:     	mov	x19, x3
1000871e0:     	cbz	x2, 0x100087270 <void kernel<signed char, 4ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
1000871e4:     	mov	x20, x2
1000871e8:     	mov	x22, x1
1000871ec:     	mov	x21, x0
1000871f0:     	mov	x3, x19
1000871f4:     	mov	w4, #4
1000871f8:     	mov	x5, #0
1000871fc:     	mov	x6, #0
100087200:     	bl	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087204:     	add	x1, x22, #4
100087208:     	add	x3, x19, #16
10008720c:     	mov	x0, x21
100087210:     	mov	x2, x20
100087214:     	mov	w4, #4
100087218:     	mov	x5, #0
10008721c:     	mov	x6, #0
100087220:     	bl	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087224:     	add	x1, x22, #8
100087228:     	add	x3, x19, #32
10008722c:     	mov	x0, x21
100087230:     	mov	x2, x20
100087234:     	mov	w4, #4
100087238:     	mov	x5, #0
10008723c:     	mov	x6, #0
100087240:     	bl	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087244:     	add	x1, x22, #12
100087248:     	add	x3, x19, #48
10008724c:     	mov	x0, x21
100087250:     	mov	x2, x20
100087254:     	mov	w4, #4
100087258:     	mov	x5, #0
10008725c:     	mov	x6, #0
100087260:     	ldp	x29, x30, [sp, #32]
100087264:     	ldp	x20, x19, [sp, #16]
100087268:     	ldp	x22, x21, [sp], #48
10008726c:     	b	0x100082f2c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100087270:     	movi.2d	v0, #0000000000000000
100087274:     	stp	q0, q0, [x19, #32]
100087278:     	stp	q0, q0, [x19]
10008727c:     	ldp	x29, x30, [sp, #32]
100087280:     	ldp	x20, x19, [sp, #16]
100087284:     	ldp	x22, x21, [sp], #48
100087288:     	ret

0000000100089574 <void kernel<signed char, 8ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100089574:     	cbz	x2, 0x100089588 <void kernel<signed char, 8ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100089578:     	mov	w4, #1
10008957c:     	mov	x5, #0
100089580:     	mov	x6, #0
100089584:     	b	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100089588:     	movi.2d	v0, #0000000000000000
10008958c:     	stp	q0, q0, [x3]
100089590:     	ret

0000000100089910 <void kernel<signed char, 8ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100089910:     	cbz	x2, 0x100089924 <void kernel<signed char, 8ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100089914:     	mov	w4, #1
100089918:     	mov	x5, #0
10008991c:     	mov	x6, #0
100089920:     	b	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100089924:     	movi.2d	v0, #0000000000000000
100089928:     	stp	q0, q0, [x3]
10008992c:     	ret

000000010008be58 <void kernel<signed char, 8ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10008be58:     	stp	x22, x21, [sp, #-48]!
10008be5c:     	stp	x20, x19, [sp, #16]
10008be60:     	stp	x29, x30, [sp, #32]
10008be64:     	add	x29, sp, #32
10008be68:     	mov	x19, x3
10008be6c:     	cbz	x2, 0x10008bebc <void kernel<signed char, 8ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
10008be70:     	mov	x20, x2
10008be74:     	mov	x22, x1
10008be78:     	mov	x21, x0
10008be7c:     	mov	x3, x19
10008be80:     	mov	w4, #2
10008be84:     	mov	x5, #0
10008be88:     	mov	x6, #0
10008be8c:     	bl	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008be90:     	add	x1, x22, #4
10008be94:     	add	x3, x19, #32
10008be98:     	mov	x0, x21
10008be9c:     	mov	x2, x20
10008bea0:     	mov	w4, #2
10008bea4:     	mov	x5, #0
10008bea8:     	mov	x6, #0
10008beac:     	ldp	x29, x30, [sp, #32]
10008beb0:     	ldp	x20, x19, [sp, #16]
10008beb4:     	ldp	x22, x21, [sp], #48
10008beb8:     	b	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008bebc:     	movi.2d	v0, #0000000000000000
10008bec0:     	stp	q0, q0, [x19, #32]
10008bec4:     	stp	q0, q0, [x19]
10008bec8:     	ldp	x29, x30, [sp, #32]
10008becc:     	ldp	x20, x19, [sp, #16]
10008bed0:     	ldp	x22, x21, [sp], #48
10008bed4:     	ret

000000010008bed8 <void kernel<signed char, 8ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10008bed8:     	stp	x22, x21, [sp, #-48]!
10008bedc:     	stp	x20, x19, [sp, #16]
10008bee0:     	stp	x29, x30, [sp, #32]
10008bee4:     	add	x29, sp, #32
10008bee8:     	mov	x19, x3
10008beec:     	cbz	x2, 0x10008bf3c <void kernel<signed char, 8ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
10008bef0:     	mov	x20, x2
10008bef4:     	mov	x22, x1
10008bef8:     	mov	x21, x0
10008befc:     	mov	x3, x19
10008bf00:     	mov	w4, #2
10008bf04:     	mov	x5, #0
10008bf08:     	mov	x6, #0
10008bf0c:     	bl	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008bf10:     	add	x1, x22, #4
10008bf14:     	add	x3, x19, #32
10008bf18:     	mov	x0, x21
10008bf1c:     	mov	x2, x20
10008bf20:     	mov	w4, #2
10008bf24:     	mov	x5, #0
10008bf28:     	mov	x6, #0
10008bf2c:     	ldp	x29, x30, [sp, #32]
10008bf30:     	ldp	x20, x19, [sp, #16]
10008bf34:     	ldp	x22, x21, [sp], #48
10008bf38:     	b	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008bf3c:     	movi.2d	v0, #0000000000000000
10008bf40:     	stp	q0, q0, [x19, #32]
10008bf44:     	stp	q0, q0, [x19]
10008bf48:     	ldp	x29, x30, [sp, #32]
10008bf4c:     	ldp	x20, x19, [sp, #16]
10008bf50:     	ldp	x22, x21, [sp], #48
10008bf54:     	ret

000000010008e76c <void kernel<signed char, 8ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10008e76c:     	stp	x22, x21, [sp, #-48]!
10008e770:     	stp	x20, x19, [sp, #16]
10008e774:     	stp	x29, x30, [sp, #32]
10008e778:     	add	x29, sp, #32
10008e77c:     	mov	x19, x3
10008e780:     	cbz	x2, 0x10008e810 <void kernel<signed char, 8ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
10008e784:     	mov	x20, x2
10008e788:     	mov	x22, x1
10008e78c:     	mov	x21, x0
10008e790:     	mov	x3, x19
10008e794:     	mov	w4, #4
10008e798:     	mov	x5, #0
10008e79c:     	mov	x6, #0
10008e7a0:     	bl	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e7a4:     	add	x1, x22, #4
10008e7a8:     	add	x3, x19, #32
10008e7ac:     	mov	x0, x21
10008e7b0:     	mov	x2, x20
10008e7b4:     	mov	w4, #4
10008e7b8:     	mov	x5, #0
10008e7bc:     	mov	x6, #0
10008e7c0:     	bl	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e7c4:     	add	x1, x22, #8
10008e7c8:     	add	x3, x19, #64
10008e7cc:     	mov	x0, x21
10008e7d0:     	mov	x2, x20
10008e7d4:     	mov	w4, #4
10008e7d8:     	mov	x5, #0
10008e7dc:     	mov	x6, #0
10008e7e0:     	bl	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e7e4:     	add	x1, x22, #12
10008e7e8:     	add	x3, x19, #96
10008e7ec:     	mov	x0, x21
10008e7f0:     	mov	x2, x20
10008e7f4:     	mov	w4, #4
10008e7f8:     	mov	x5, #0
10008e7fc:     	mov	x6, #0
10008e800:     	ldp	x29, x30, [sp, #32]
10008e804:     	ldp	x20, x19, [sp, #16]
10008e808:     	ldp	x22, x21, [sp], #48
10008e80c:     	b	0x100089594 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e810:     	movi.2d	v0, #0000000000000000
10008e814:     	stp	q0, q0, [x19, #96]
10008e818:     	stp	q0, q0, [x19, #64]
10008e81c:     	stp	q0, q0, [x19, #32]
10008e820:     	stp	q0, q0, [x19]
10008e824:     	ldp	x29, x30, [sp, #32]
10008e828:     	ldp	x20, x19, [sp, #16]
10008e82c:     	ldp	x22, x21, [sp], #48
10008e830:     	ret

000000010008e834 <void kernel<signed char, 8ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10008e834:     	stp	x22, x21, [sp, #-48]!
10008e838:     	stp	x20, x19, [sp, #16]
10008e83c:     	stp	x29, x30, [sp, #32]
10008e840:     	add	x29, sp, #32
10008e844:     	mov	x19, x3
10008e848:     	cbz	x2, 0x10008e8d8 <void kernel<signed char, 8ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
10008e84c:     	mov	x20, x2
10008e850:     	mov	x22, x1
10008e854:     	mov	x21, x0
10008e858:     	mov	x3, x19
10008e85c:     	mov	w4, #4
10008e860:     	mov	x5, #0
10008e864:     	mov	x6, #0
10008e868:     	bl	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e86c:     	add	x1, x22, #4
10008e870:     	add	x3, x19, #32
10008e874:     	mov	x0, x21
10008e878:     	mov	x2, x20
10008e87c:     	mov	w4, #4
10008e880:     	mov	x5, #0
10008e884:     	mov	x6, #0
10008e888:     	bl	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e88c:     	add	x1, x22, #8
10008e890:     	add	x3, x19, #64
10008e894:     	mov	x0, x21
10008e898:     	mov	x2, x20
10008e89c:     	mov	w4, #4
10008e8a0:     	mov	x5, #0
10008e8a4:     	mov	x6, #0
10008e8a8:     	bl	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e8ac:     	add	x1, x22, #12
10008e8b0:     	add	x3, x19, #96
10008e8b4:     	mov	x0, x21
10008e8b8:     	mov	x2, x20
10008e8bc:     	mov	w4, #4
10008e8c0:     	mov	x5, #0
10008e8c4:     	mov	x6, #0
10008e8c8:     	ldp	x29, x30, [sp, #32]
10008e8cc:     	ldp	x20, x19, [sp, #16]
10008e8d0:     	ldp	x22, x21, [sp], #48
10008e8d4:     	b	0x100089930 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10008e8d8:     	movi.2d	v0, #0000000000000000
10008e8dc:     	stp	q0, q0, [x19, #96]
10008e8e0:     	stp	q0, q0, [x19, #64]
10008e8e4:     	stp	q0, q0, [x19, #32]
10008e8e8:     	stp	q0, q0, [x19]
10008e8ec:     	ldp	x29, x30, [sp, #32]
10008e8f0:     	ldp	x20, x19, [sp, #16]
10008e8f4:     	ldp	x22, x21, [sp], #48
10008e8f8:     	ret

00000001000912a0 <void kernel<signed char, 8ul, 8ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000912a0:     	b	0x1000912a4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)0>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000913fc <void kernel<signed char, 8ul, 8ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000913fc:     	b	0x100091400 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

000000010009392c <void kernel<signed char, 16ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10009392c:     	cbz	x2, 0x100093940 <void kernel<signed char, 16ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100093930:     	mov	w4, #1
100093934:     	mov	x5, #0
100093938:     	mov	x6, #0
10009393c:     	b	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100093940:     	movi.2d	v0, #0000000000000000
100093944:     	stp	q0, q0, [x3, #32]
100093948:     	stp	q0, q0, [x3]
10009394c:     	ret

0000000100093fa4 <void kernel<signed char, 16ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
100093fa4:     	cbz	x2, 0x100093fb8 <void kernel<signed char, 16ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x14>
100093fa8:     	mov	w4, #1
100093fac:     	mov	x5, #0
100093fb0:     	mov	x6, #0
100093fb4:     	b	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100093fb8:     	movi.2d	v0, #0000000000000000
100093fbc:     	stp	q0, q0, [x3, #32]
100093fc0:     	stp	q0, q0, [x3]
100093fc4:     	ret

0000000100097028 <void kernel<signed char, 16ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100097028:     	stp	x22, x21, [sp, #-48]!
10009702c:     	stp	x20, x19, [sp, #16]
100097030:     	stp	x29, x30, [sp, #32]
100097034:     	add	x29, sp, #32
100097038:     	mov	x19, x3
10009703c:     	cbz	x2, 0x10009708c <void kernel<signed char, 16ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x64>
100097040:     	mov	x20, x2
100097044:     	mov	x22, x1
100097048:     	mov	x21, x0
10009704c:     	mov	x3, x19
100097050:     	mov	w4, #2
100097054:     	mov	x5, #0
100097058:     	mov	x6, #0
10009705c:     	bl	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100097060:     	add	x1, x22, #4
100097064:     	add	x3, x19, #64
100097068:     	mov	x0, x21
10009706c:     	mov	x2, x20
100097070:     	mov	w4, #2
100097074:     	mov	x5, #0
100097078:     	mov	x6, #0
10009707c:     	ldp	x29, x30, [sp, #32]
100097080:     	ldp	x20, x19, [sp, #16]
100097084:     	ldp	x22, x21, [sp], #48
100097088:     	b	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009708c:     	movi.2d	v0, #0000000000000000
100097090:     	stp	q0, q0, [x19, #96]
100097094:     	stp	q0, q0, [x19, #64]
100097098:     	stp	q0, q0, [x19, #32]
10009709c:     	stp	q0, q0, [x19]
1000970a0:     	ldp	x29, x30, [sp, #32]
1000970a4:     	ldp	x20, x19, [sp, #16]
1000970a8:     	ldp	x22, x21, [sp], #48
1000970ac:     	ret

00000001000970b0 <void kernel<signed char, 16ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000970b0:     	stp	x22, x21, [sp, #-48]!
1000970b4:     	stp	x20, x19, [sp, #16]
1000970b8:     	stp	x29, x30, [sp, #32]
1000970bc:     	add	x29, sp, #32
1000970c0:     	mov	x19, x3
1000970c4:     	cbz	x2, 0x100097114 <void kernel<signed char, 16ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x64>
1000970c8:     	mov	x20, x2
1000970cc:     	mov	x22, x1
1000970d0:     	mov	x21, x0
1000970d4:     	mov	x3, x19
1000970d8:     	mov	w4, #2
1000970dc:     	mov	x5, #0
1000970e0:     	mov	x6, #0
1000970e4:     	bl	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
1000970e8:     	add	x1, x22, #4
1000970ec:     	add	x3, x19, #64
1000970f0:     	mov	x0, x21
1000970f4:     	mov	x2, x20
1000970f8:     	mov	w4, #2
1000970fc:     	mov	x5, #0
100097100:     	mov	x6, #0
100097104:     	ldp	x29, x30, [sp, #32]
100097108:     	ldp	x20, x19, [sp, #16]
10009710c:     	ldp	x22, x21, [sp], #48
100097110:     	b	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100097114:     	movi.2d	v0, #0000000000000000
100097118:     	stp	q0, q0, [x19, #96]
10009711c:     	stp	q0, q0, [x19, #64]
100097120:     	stp	q0, q0, [x19, #32]
100097124:     	stp	q0, q0, [x19]
100097128:     	ldp	x29, x30, [sp, #32]
10009712c:     	ldp	x20, x19, [sp, #16]
100097130:     	ldp	x22, x21, [sp], #48
100097134:     	ret

0000000100099f4c <void kernel<signed char, 16ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
100099f4c:     	stp	x22, x21, [sp, #-48]!
100099f50:     	stp	x20, x19, [sp, #16]
100099f54:     	stp	x29, x30, [sp, #32]
100099f58:     	add	x29, sp, #32
100099f5c:     	mov	x19, x3
100099f60:     	cbz	x2, 0x100099ff0 <void kernel<signed char, 16ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
100099f64:     	mov	x20, x2
100099f68:     	mov	x22, x1
100099f6c:     	mov	x21, x0
100099f70:     	mov	x3, x19
100099f74:     	mov	w4, #4
100099f78:     	mov	x5, #0
100099f7c:     	mov	x6, #0
100099f80:     	bl	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100099f84:     	add	x1, x22, #4
100099f88:     	add	x3, x19, #64
100099f8c:     	mov	x0, x21
100099f90:     	mov	x2, x20
100099f94:     	mov	w4, #4
100099f98:     	mov	x5, #0
100099f9c:     	mov	x6, #0
100099fa0:     	bl	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100099fa4:     	add	x1, x22, #8
100099fa8:     	add	x3, x19, #128
100099fac:     	mov	x0, x21
100099fb0:     	mov	x2, x20
100099fb4:     	mov	w4, #4
100099fb8:     	mov	x5, #0
100099fbc:     	mov	x6, #0
100099fc0:     	bl	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100099fc4:     	add	x1, x22, #12
100099fc8:     	add	x3, x19, #192
100099fcc:     	mov	x0, x21
100099fd0:     	mov	x2, x20
100099fd4:     	mov	w4, #4
100099fd8:     	mov	x5, #0
100099fdc:     	mov	x6, #0
100099fe0:     	ldp	x29, x30, [sp, #32]
100099fe4:     	ldp	x20, x19, [sp, #16]
100099fe8:     	ldp	x22, x21, [sp], #48
100099fec:     	b	0x100093950 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
100099ff0:     	movi.2d	v0, #0000000000000000
100099ff4:     	stp	q0, q0, [x19, #224]
100099ff8:     	stp	q0, q0, [x19, #192]
100099ffc:     	stp	q0, q0, [x19, #160]
10009a000:     	stp	q0, q0, [x19, #128]
10009a004:     	stp	q0, q0, [x19, #96]
10009a008:     	stp	q0, q0, [x19, #64]
10009a00c:     	stp	q0, q0, [x19, #32]
10009a010:     	stp	q0, q0, [x19]
10009a014:     	ldp	x29, x30, [sp, #32]
10009a018:     	ldp	x20, x19, [sp, #16]
10009a01c:     	ldp	x22, x21, [sp], #48
10009a020:     	ret

000000010009a024 <void kernel<signed char, 16ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10009a024:     	stp	x22, x21, [sp, #-48]!
10009a028:     	stp	x20, x19, [sp, #16]
10009a02c:     	stp	x29, x30, [sp, #32]
10009a030:     	add	x29, sp, #32
10009a034:     	mov	x19, x3
10009a038:     	cbz	x2, 0x10009a0c8 <void kernel<signed char, 16ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xa4>
10009a03c:     	mov	x20, x2
10009a040:     	mov	x22, x1
10009a044:     	mov	x21, x0
10009a048:     	mov	x3, x19
10009a04c:     	mov	w4, #4
10009a050:     	mov	x5, #0
10009a054:     	mov	x6, #0
10009a058:     	bl	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009a05c:     	add	x1, x22, #4
10009a060:     	add	x3, x19, #64
10009a064:     	mov	x0, x21
10009a068:     	mov	x2, x20
10009a06c:     	mov	w4, #4
10009a070:     	mov	x5, #0
10009a074:     	mov	x6, #0
10009a078:     	bl	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009a07c:     	add	x1, x22, #8
10009a080:     	add	x3, x19, #128
10009a084:     	mov	x0, x21
10009a088:     	mov	x2, x20
10009a08c:     	mov	w4, #4
10009a090:     	mov	x5, #0
10009a094:     	mov	x6, #0
10009a098:     	bl	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009a09c:     	add	x1, x22, #12
10009a0a0:     	add	x3, x19, #192
10009a0a4:     	mov	x0, x21
10009a0a8:     	mov	x2, x20
10009a0ac:     	mov	w4, #4
10009a0b0:     	mov	x5, #0
10009a0b4:     	mov	x6, #0
10009a0b8:     	ldp	x29, x30, [sp, #32]
10009a0bc:     	ldp	x20, x19, [sp, #16]
10009a0c0:     	ldp	x22, x21, [sp], #48
10009a0c4:     	b	0x100093fc8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(signed char const*, signed char const*, unsigned long, float*, unsigned long, float*, float*)>
10009a0c8:     	movi.2d	v0, #0000000000000000
10009a0cc:     	stp	q0, q0, [x19, #224]
10009a0d0:     	stp	q0, q0, [x19, #192]
10009a0d4:     	stp	q0, q0, [x19, #160]
10009a0d8:     	stp	q0, q0, [x19, #128]
10009a0dc:     	stp	q0, q0, [x19, #96]
10009a0e0:     	stp	q0, q0, [x19, #64]
10009a0e4:     	stp	q0, q0, [x19, #32]
10009a0e8:     	stp	q0, q0, [x19]
10009a0ec:     	ldp	x29, x30, [sp, #32]
10009a0f0:     	ldp	x20, x19, [sp, #16]
10009a0f4:     	ldp	x22, x21, [sp], #48
10009a0f8:     	ret

000000010009d940 <void kernel<signed char, 16ul, 8ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
10009d940:     	b	0x10009d944 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

000000010009dabc <void kernel<signed char, 16ul, 8ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
10009dabc:     	b	0x10009dac0 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a16e8 <void kernel<signed char, 16ul, 16ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a16e8:     	b	0x1000a16ec <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a1928 <void kernel<signed char, 16ul, 16ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a1928:     	b	0x1000a192c <void zvec::turbo::InterleavedDistanceMatrix<signed char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a2b1c <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a2b1c:     	movi.2d	v0, #0000000000000000
1000a2b20:     	stp	q0, q0, [x3, #96]
1000a2b24:     	stp	q0, q0, [x3, #64]
1000a2b28:     	stp	q0, q0, [x3, #32]
1000a2b2c:     	stp	q0, q0, [x3]
1000a2b30:     	cbz	x2, 0x1000a2bb0 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x94>
1000a2b34:     	cmp	x2, #4
1000a2b38:     	b.hs	0x1000a2bb4 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x98>
1000a2b3c:     	mov	x8, #0
1000a2b40:     	cmp	x8, x2
1000a2b44:     	b.hs	0x1000a2bb0 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x94>
1000a2b48:     	lsl	x9, x8, #3
1000a2b4c:     	mov	x10, #0
1000a2b50:     	lsl	x11, x9, #2
1000a2b54:     	and	x11, x11, #0xffffffffffffff80
1000a2b58:     	and	x12, x8, #0x3
1000a2b5c:     	ldr	b0, [x1, x8]
1000a2b60:     	sshll.8h	v0, v0, #0
1000a2b64:     	sshll.4s	v0, v0, #0
1000a2b68:     	scvtf	s0, s0
1000a2b6c:     	add	x13, x11, x10
1000a2b70:     	orr	x13, x13, x12
1000a2b74:     	ldr	b1, [x0, x13]
1000a2b78:     	sshll.8h	v1, v1, #0
1000a2b7c:     	sshll.4s	v1, v1, #0
1000a2b80:     	scvtf	s1, s1
1000a2b84:     	ldr	s2, [x3, x10]
1000a2b88:     	fsub	s1, s1, s0
1000a2b8c:     	fmadd	s1, s1, s1, s2
1000a2b90:     	str	s1, [x3, x10]
1000a2b94:     	add	x10, x10, #4
1000a2b98:     	cmp	x10, #128
1000a2b9c:     	b.ne	0x1000a2b6c <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x50>
1000a2ba0:     	add	x8, x8, #1
1000a2ba4:     	add	x9, x9, #8
1000a2ba8:     	cmp	x8, x2
1000a2bac:     	b.ne	0x1000a2b4c <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x30>
1000a2bb0:     	ret
1000a2bb4:     	mov	x9, #0
1000a2bb8:     	mov	x8, #0
1000a2bbc:     	add	x10, x3, #128
1000a2bc0:     	mov	w12, #4
1000a2bc4:     	mov	x11, x0
1000a2bc8:     	b	0x1000a2e1c <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x300>
1000a2bcc:     	dup.4s	v0, v3[3]
1000a2bd0:     	dup.4s	v1, v3[2]
1000a2bd4:     	add	x12, x0, x13, lsl #5
1000a2bd8:     	dup.4s	v2, v3[1]
1000a2bdc:     	dup.4s	v3, v3[0]
1000a2be0:     	ld4.16b	{ v4, v5, v6, v7 }, [x12], #64
1000a2be4:     	sshll2.8h	v16, v4, #0
1000a2be8:     	sshll2.4s	v17, v16, #0
1000a2bec:     	sshll.4s	v16, v16, #0
1000a2bf0:     	sshll.8h	v18, v4, #0
1000a2bf4:     	sshll2.4s	v19, v18, #0
1000a2bf8:     	sshll.4s	v18, v18, #0
1000a2bfc:     	sub.4s	v18, v18, v3
1000a2c00:     	sub.4s	v19, v19, v3
1000a2c04:     	sub.4s	v16, v16, v3
1000a2c08:     	sub.4s	v17, v17, v3
1000a2c0c:     	sshll2.8h	v20, v5, #0
1000a2c10:     	sshll2.4s	v21, v20, #0
1000a2c14:     	sshll.4s	v20, v20, #0
1000a2c18:     	sshll.8h	v22, v5, #0
1000a2c1c:     	sshll2.4s	v23, v22, #0
1000a2c20:     	sshll.4s	v22, v22, #0
1000a2c24:     	sub.4s	v22, v22, v2
1000a2c28:     	sub.4s	v23, v23, v2
1000a2c2c:     	sub.4s	v20, v20, v2
1000a2c30:     	sub.4s	v21, v21, v2
1000a2c34:     	sshll.8h	v24, v6, #0
1000a2c38:     	sshll.4s	v25, v24, #0
1000a2c3c:     	sshll2.4s	v24, v24, #0
1000a2c40:     	sshll2.8h	v26, v6, #0
1000a2c44:     	sshll.4s	v27, v26, #0
1000a2c48:     	sshll2.4s	v26, v26, #0
1000a2c4c:     	sub.4s	v26, v26, v1
1000a2c50:     	sub.4s	v27, v27, v1
1000a2c54:     	sub.4s	v24, v24, v1
1000a2c58:     	sub.4s	v25, v25, v1
1000a2c5c:     	sshll2.8h	v28, v7, #0
1000a2c60:     	sshll2.4s	v29, v28, #0
1000a2c64:     	sshll.4s	v28, v28, #0
1000a2c68:     	sshll.8h	v4, v7, #0
1000a2c6c:     	sshll2.4s	v5, v4, #0
1000a2c70:     	sshll.4s	v4, v4, #0
1000a2c74:     	sub.4s	v4, v4, v0
1000a2c78:     	sub.4s	v5, v5, v0
1000a2c7c:     	sub.4s	v6, v28, v0
1000a2c80:     	sub.4s	v7, v29, v0
1000a2c84:     	mul.4s	v17, v17, v17
1000a2c88:     	mul.4s	v16, v16, v16
1000a2c8c:     	mul.4s	v19, v19, v19
1000a2c90:     	mul.4s	v18, v18, v18
1000a2c94:     	mla.4s	v18, v22, v22
1000a2c98:     	mla.4s	v19, v23, v23
1000a2c9c:     	mla.4s	v16, v20, v20
1000a2ca0:     	mla.4s	v17, v21, v21
1000a2ca4:     	mla.4s	v17, v26, v26
1000a2ca8:     	mla.4s	v16, v27, v27
1000a2cac:     	mla.4s	v19, v24, v24
1000a2cb0:     	mla.4s	v18, v25, v25
1000a2cb4:     	mla.4s	v18, v4, v4
1000a2cb8:     	mla.4s	v19, v5, v5
1000a2cbc:     	mla.4s	v16, v6, v6
1000a2cc0:     	mla.4s	v17, v7, v7
1000a2cc4:     	scvtf.4s	v4, v17
1000a2cc8:     	scvtf.4s	v5, v16
1000a2ccc:     	scvtf.4s	v6, v19
1000a2cd0:     	scvtf.4s	v7, v18
1000a2cd4:     	ldp	q17, q16, [x3, #32]
1000a2cd8:     	ldp	q19, q18, [x3]
1000a2cdc:     	fadd.4s	v7, v19, v7
1000a2ce0:     	fadd.4s	v6, v18, v6
1000a2ce4:     	fadd.4s	v5, v17, v5
1000a2ce8:     	fadd.4s	v4, v16, v4
1000a2cec:     	stp	q5, q4, [x3, #32]
1000a2cf0:     	stp	q7, q6, [x3]
1000a2cf4:     	ld4.16b	{ v4, v5, v6, v7 }, [x12]
1000a2cf8:     	sshll2.8h	v16, v4, #0
1000a2cfc:     	sshll2.4s	v17, v16, #0
1000a2d00:     	sshll.4s	v16, v16, #0
1000a2d04:     	sshll.8h	v18, v4, #0
1000a2d08:     	sshll2.4s	v19, v18, #0
1000a2d0c:     	sshll.4s	v18, v18, #0
1000a2d10:     	sub.4s	v18, v18, v3
1000a2d14:     	sub.4s	v19, v19, v3
1000a2d18:     	sub.4s	v16, v16, v3
1000a2d1c:     	sub.4s	v3, v17, v3
1000a2d20:     	sshll2.8h	v17, v5, #0
1000a2d24:     	sshll2.4s	v20, v17, #0
1000a2d28:     	sshll.4s	v17, v17, #0
1000a2d2c:     	sshll.8h	v21, v5, #0
1000a2d30:     	sshll2.4s	v22, v21, #0
1000a2d34:     	sshll.4s	v21, v21, #0
1000a2d38:     	sub.4s	v21, v21, v2
1000a2d3c:     	sub.4s	v22, v22, v2
1000a2d40:     	sub.4s	v17, v17, v2
1000a2d44:     	sub.4s	v2, v20, v2
1000a2d48:     	sshll.8h	v20, v6, #0
1000a2d4c:     	sshll.4s	v23, v20, #0
1000a2d50:     	sshll2.4s	v20, v20, #0
1000a2d54:     	sshll2.8h	v24, v6, #0
1000a2d58:     	sshll.4s	v25, v24, #0
1000a2d5c:     	sshll2.4s	v24, v24, #0
1000a2d60:     	sub.4s	v24, v24, v1
1000a2d64:     	sub.4s	v25, v25, v1
1000a2d68:     	sub.4s	v20, v20, v1
1000a2d6c:     	sub.4s	v1, v23, v1
1000a2d70:     	sshll2.8h	v23, v7, #0
1000a2d74:     	sshll2.4s	v26, v23, #0
1000a2d78:     	sshll.4s	v23, v23, #0
1000a2d7c:     	sshll.8h	v4, v7, #0
1000a2d80:     	sshll2.4s	v5, v4, #0
1000a2d84:     	sshll.4s	v4, v4, #0
1000a2d88:     	sub.4s	v4, v4, v0
1000a2d8c:     	sub.4s	v5, v5, v0
1000a2d90:     	sub.4s	v6, v23, v0
1000a2d94:     	sub.4s	v0, v26, v0
1000a2d98:     	mul.4s	v3, v3, v3
1000a2d9c:     	mul.4s	v7, v16, v16
1000a2da0:     	mul.4s	v16, v19, v19
1000a2da4:     	mul.4s	v18, v18, v18
1000a2da8:     	mla.4s	v18, v21, v21
1000a2dac:     	mla.4s	v16, v22, v22
1000a2db0:     	mla.4s	v7, v17, v17
1000a2db4:     	mla.4s	v3, v2, v2
1000a2db8:     	mla.4s	v3, v24, v24
1000a2dbc:     	mla.4s	v7, v25, v25
1000a2dc0:     	mla.4s	v16, v20, v20
1000a2dc4:     	mla.4s	v18, v1, v1
1000a2dc8:     	mla.4s	v18, v4, v4
1000a2dcc:     	mla.4s	v16, v5, v5
1000a2dd0:     	mla.4s	v7, v6, v6
1000a2dd4:     	mla.4s	v3, v0, v0
1000a2dd8:     	scvtf.4s	v0, v3
1000a2ddc:     	scvtf.4s	v1, v7
1000a2de0:     	scvtf.4s	v2, v16
1000a2de4:     	scvtf.4s	v3, v18
1000a2de8:     	ldp	q5, q4, [x3, #96]
1000a2dec:     	ldp	q7, q6, [x3, #64]
1000a2df0:     	fadd.4s	v3, v7, v3
1000a2df4:     	fadd.4s	v1, v5, v1
1000a2df8:     	fadd.4s	v0, v4, v0
1000a2dfc:     	stp	q1, q0, [x3, #96]
1000a2e00:     	fadd.4s	v0, v6, v2
1000a2e04:     	stp	q3, q0, [x3, #64]
1000a2e08:     	add	x12, x8, #4
1000a2e0c:     	add	x9, x9, #1
1000a2e10:     	add	x11, x11, #128
1000a2e14:     	cmp	x12, x2
1000a2e18:     	b.hi	0x1000a2b40 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x24>
1000a2e1c:     	mov	x13, x8
1000a2e20:     	mov	x8, x12
1000a2e24:     	ldr	s0, [x1, x13]
1000a2e28:     	sshll.8h	v0, v0, #0
1000a2e2c:     	sshll.4s	v3, v0, #0
1000a2e30:     	add	x12, x0, x9, lsl #7
1000a2e34:     	add	x14, x12, #128
1000a2e38:     	cmp	x14, x3
1000a2e3c:     	ccmp	x12, x10, #2, hi
1000a2e40:     	b.hs	0x1000a2bcc <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0xb0>
1000a2e44:     	mov	x12, #0
1000a2e48:     	ldr	s0, [x11, x12]
1000a2e4c:     	sshll.8h	v0, v0, #0
1000a2e50:     	sshll.4s	v0, v0, #0
1000a2e54:     	sub.4s	v0, v0, v3
1000a2e58:     	mul.4s	v0, v0, v0
1000a2e5c:     	addv.4s	s0, v0
1000a2e60:     	fmov	w13, s0
1000a2e64:     	scvtf	s0, w13
1000a2e68:     	ldr	s1, [x3, x12]
1000a2e6c:     	fadd	s0, s1, s0
1000a2e70:     	str	s0, [x3, x12]
1000a2e74:     	add	x12, x12, #4
1000a2e78:     	cmp	x12, #128
1000a2e7c:     	b.ne	0x1000a2e48 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x32c>
1000a2e80:     	b	0x1000a2e08 <void kernel<signed char, 32ul, 1ul, false>(signed char const*, signed char const*, unsigned long, float*)+0x2ec>

00000001000a2e84 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a2e84:     	movi.2d	v0, #0000000000000000
1000a2e88:     	stp	q0, q0, [x3, #96]
1000a2e8c:     	stp	q0, q0, [x3, #64]
1000a2e90:     	stp	q0, q0, [x3, #32]
1000a2e94:     	stp	q0, q0, [x3]
1000a2e98:     	cbz	x2, 0x1000a2f14 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x90>
1000a2e9c:     	cmp	x2, #4
1000a2ea0:     	b.hs	0x1000a2f18 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x94>
1000a2ea4:     	mov	x8, #0
1000a2ea8:     	cmp	x8, x2
1000a2eac:     	b.hs	0x1000a2f14 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x90>
1000a2eb0:     	lsl	x9, x8, #3
1000a2eb4:     	mov	x10, #0
1000a2eb8:     	lsl	x11, x9, #2
1000a2ebc:     	and	x11, x11, #0xffffffffffffff80
1000a2ec0:     	and	x12, x8, #0x3
1000a2ec4:     	ldr	b0, [x1, x8]
1000a2ec8:     	sshll.8h	v0, v0, #0
1000a2ecc:     	sshll.4s	v0, v0, #0
1000a2ed0:     	scvtf	s0, s0
1000a2ed4:     	add	x13, x11, x10
1000a2ed8:     	orr	x13, x13, x12
1000a2edc:     	ldr	b1, [x0, x13]
1000a2ee0:     	sshll.8h	v1, v1, #0
1000a2ee4:     	sshll.4s	v1, v1, #0
1000a2ee8:     	ldr	s2, [x3, x10]
1000a2eec:     	scvtf	s1, s1
1000a2ef0:     	fmsub	s1, s1, s0, s2
1000a2ef4:     	str	s1, [x3, x10]
1000a2ef8:     	add	x10, x10, #4
1000a2efc:     	cmp	x10, #128
1000a2f00:     	b.ne	0x1000a2ed4 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x50>
1000a2f04:     	add	x8, x8, #1
1000a2f08:     	add	x9, x9, #8
1000a2f0c:     	cmp	x8, x2
1000a2f10:     	b.ne	0x1000a2eb4 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x30>
1000a2f14:     	ret
1000a2f18:     	mov	x9, #0
1000a2f1c:     	mov	x8, #0
1000a2f20:     	add	x10, x3, #128
1000a2f24:     	mov	w12, #4
1000a2f28:     	mov	x11, x0
1000a2f2c:     	b	0x1000a30f0 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x26c>
1000a2f30:     	add	x12, x0, x13, lsl #5
1000a2f34:     	ld4.16b	{ v1, v2, v3, v4 }, [x12], #64
1000a2f38:     	sshll.8h	v5, v1, #0
1000a2f3c:     	sshll.4s	v6, v5, #0
1000a2f40:     	sshll2.4s	v5, v5, #0
1000a2f44:     	sshll2.8h	v7, v1, #0
1000a2f48:     	sshll.4s	v16, v7, #0
1000a2f4c:     	sshll2.4s	v7, v7, #0
1000a2f50:     	mul.4s	v7, v7, v0[0]
1000a2f54:     	mul.4s	v16, v16, v0[0]
1000a2f58:     	mul.4s	v5, v5, v0[0]
1000a2f5c:     	mul.4s	v6, v6, v0[0]
1000a2f60:     	sshll.8h	v17, v2, #0
1000a2f64:     	sshll.4s	v18, v17, #0
1000a2f68:     	sshll2.4s	v17, v17, #0
1000a2f6c:     	sshll2.8h	v19, v2, #0
1000a2f70:     	sshll.4s	v20, v19, #0
1000a2f74:     	sshll2.4s	v19, v19, #0
1000a2f78:     	mla.4s	v6, v18, v0[1]
1000a2f7c:     	mla.4s	v5, v17, v0[1]
1000a2f80:     	mla.4s	v16, v20, v0[1]
1000a2f84:     	mla.4s	v7, v19, v0[1]
1000a2f88:     	sshll2.8h	v17, v3, #0
1000a2f8c:     	sshll2.4s	v18, v17, #0
1000a2f90:     	sshll.4s	v17, v17, #0
1000a2f94:     	sshll.8h	v19, v3, #0
1000a2f98:     	sshll2.4s	v20, v19, #0
1000a2f9c:     	sshll.4s	v19, v19, #0
1000a2fa0:     	mla.4s	v7, v18, v0[2]
1000a2fa4:     	mla.4s	v16, v17, v0[2]
1000a2fa8:     	mla.4s	v5, v20, v0[2]
1000a2fac:     	mla.4s	v6, v19, v0[2]
1000a2fb0:     	sshll.8h	v17, v4, #0
1000a2fb4:     	sshll.4s	v18, v17, #0
1000a2fb8:     	sshll2.4s	v17, v17, #0
1000a2fbc:     	sshll2.8h	v1, v4, #0
1000a2fc0:     	sshll.4s	v2, v1, #0
1000a2fc4:     	sshll2.4s	v1, v1, #0
1000a2fc8:     	mla.4s	v6, v18, v0[3]
1000a2fcc:     	mla.4s	v5, v17, v0[3]
1000a2fd0:     	mla.4s	v16, v2, v0[3]
1000a2fd4:     	mla.4s	v7, v1, v0[3]
1000a2fd8:     	scvtf.4s	v1, v7
1000a2fdc:     	scvtf.4s	v2, v16
1000a2fe0:     	scvtf.4s	v3, v5
1000a2fe4:     	scvtf.4s	v4, v6
1000a2fe8:     	ldp	q6, q5, [x3, #32]
1000a2fec:     	ldp	q16, q7, [x3]
1000a2ff0:     	fsub.4s	v4, v16, v4
1000a2ff4:     	fsub.4s	v3, v7, v3
1000a2ff8:     	fsub.4s	v2, v6, v2
1000a2ffc:     	fsub.4s	v1, v5, v1
1000a3000:     	stp	q2, q1, [x3, #32]
1000a3004:     	stp	q4, q3, [x3]
1000a3008:     	ld4.16b	{ v1, v2, v3, v4 }, [x12]
1000a300c:     	sshll.8h	v5, v1, #0
1000a3010:     	sshll.4s	v6, v5, #0
1000a3014:     	sshll2.4s	v5, v5, #0
1000a3018:     	sshll2.8h	v7, v1, #0
1000a301c:     	sshll.4s	v16, v7, #0
1000a3020:     	sshll2.4s	v7, v7, #0
1000a3024:     	mul.4s	v7, v7, v0[0]
1000a3028:     	mul.4s	v16, v16, v0[0]
1000a302c:     	mul.4s	v5, v5, v0[0]
1000a3030:     	mul.4s	v6, v6, v0[0]
1000a3034:     	sshll.8h	v17, v2, #0
1000a3038:     	sshll.4s	v18, v17, #0
1000a303c:     	sshll2.4s	v17, v17, #0
1000a3040:     	sshll2.8h	v19, v2, #0
1000a3044:     	sshll.4s	v20, v19, #0
1000a3048:     	sshll2.4s	v19, v19, #0
1000a304c:     	mla.4s	v6, v18, v0[1]
1000a3050:     	mla.4s	v5, v17, v0[1]
1000a3054:     	mla.4s	v16, v20, v0[1]
1000a3058:     	mla.4s	v7, v19, v0[1]
1000a305c:     	sshll2.8h	v17, v3, #0
1000a3060:     	sshll2.4s	v18, v17, #0
1000a3064:     	sshll.4s	v17, v17, #0
1000a3068:     	sshll.8h	v19, v3, #0
1000a306c:     	sshll2.4s	v20, v19, #0
1000a3070:     	sshll.4s	v19, v19, #0
1000a3074:     	mla.4s	v7, v18, v0[2]
1000a3078:     	mla.4s	v16, v17, v0[2]
1000a307c:     	mla.4s	v5, v20, v0[2]
1000a3080:     	mla.4s	v6, v19, v0[2]
1000a3084:     	sshll.8h	v17, v4, #0
1000a3088:     	sshll.4s	v18, v17, #0
1000a308c:     	sshll2.4s	v17, v17, #0
1000a3090:     	sshll2.8h	v1, v4, #0
1000a3094:     	sshll.4s	v2, v1, #0
1000a3098:     	sshll2.4s	v1, v1, #0
1000a309c:     	mla.4s	v6, v18, v0[3]
1000a30a0:     	mla.4s	v5, v17, v0[3]
1000a30a4:     	mla.4s	v16, v2, v0[3]
1000a30a8:     	mla.4s	v7, v1, v0[3]
1000a30ac:     	scvtf.4s	v0, v7
1000a30b0:     	scvtf.4s	v1, v16
1000a30b4:     	scvtf.4s	v2, v5
1000a30b8:     	scvtf.4s	v3, v6
1000a30bc:     	ldp	q5, q4, [x3, #96]
1000a30c0:     	ldp	q7, q6, [x3, #64]
1000a30c4:     	fsub.4s	v3, v7, v3
1000a30c8:     	fsub.4s	v1, v5, v1
1000a30cc:     	fsub.4s	v0, v4, v0
1000a30d0:     	stp	q1, q0, [x3, #96]
1000a30d4:     	fsub.4s	v0, v6, v2
1000a30d8:     	stp	q3, q0, [x3, #64]
1000a30dc:     	add	x12, x8, #4
1000a30e0:     	add	x9, x9, #1
1000a30e4:     	add	x11, x11, #128
1000a30e8:     	cmp	x12, x2
1000a30ec:     	b.hi	0x1000a2ea8 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x24>
1000a30f0:     	mov	x13, x8
1000a30f4:     	mov	x8, x12
1000a30f8:     	ldr	s0, [x1, x13]
1000a30fc:     	ushll.8h	v0, v0, #0
1000a3100:     	ushll.4s	v0, v0, #0
1000a3104:     	shl.4s	v0, v0, #24
1000a3108:     	sshr.4s	v0, v0, #24
1000a310c:     	add	x12, x0, x9, lsl #7
1000a3110:     	add	x14, x12, #128
1000a3114:     	cmp	x14, x3
1000a3118:     	ccmp	x12, x10, #2, hi
1000a311c:     	b.hs	0x1000a2f30 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0xac>
1000a3120:     	mov	x12, #0
1000a3124:     	ldr	s1, [x11, x12]
1000a3128:     	sshll.8h	v1, v1, #0
1000a312c:     	sshll.4s	v1, v1, #0
1000a3130:     	mul.4s	v1, v1, v0
1000a3134:     	addv.4s	s1, v1
1000a3138:     	fmov	w13, s1
1000a313c:     	scvtf	s1, w13
1000a3140:     	ldr	s2, [x3, x12]
1000a3144:     	fsub	s1, s2, s1
1000a3148:     	str	s1, [x3, x12]
1000a314c:     	add	x12, x12, #4
1000a3150:     	cmp	x12, #128
1000a3154:     	b.ne	0x1000a3124 <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x2a0>
1000a3158:     	b	0x1000a30dc <void kernel<signed char, 32ul, 1ul, true>(signed char const*, signed char const*, unsigned long, float*)+0x258>

00000001000a4aa0 <void kernel<signed char, 32ul, 2ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a4aa0:     	b	0x1000a4aa4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a52f0 <void kernel<signed char, 32ul, 2ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a52f0:     	b	0x1000a52f4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a78a4 <void kernel<signed char, 32ul, 4ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000a78a4:     	b	0x1000a78a8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000a88c8 <void kernel<signed char, 32ul, 4ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000a88c8:     	b	0x1000a88cc <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000abe50 <void kernel<signed char, 32ul, 8ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000abe50:     	b	0x1000abe54 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000ac6e4 <void kernel<signed char, 32ul, 8ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000ac6e4:     	b	0x1000ac6e8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000af9f0 <void kernel<signed char, 32ul, 16ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000af9f0:     	b	0x1000af9f4 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000afea4 <void kernel<signed char, 32ul, 16ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000afea4:     	b	0x1000afea8 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000b1a14 <void kernel<signed char, 32ul, 32ul, false>(signed char const*, signed char const*, unsigned long, float*)>:
1000b1a14:     	b	0x1000b1a18 <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001000b1ec8 <void kernel<signed char, 32ul, 32ul, true>(signed char const*, signed char const*, unsigned long, float*)>:
1000b1ec8:     	b	0x1000b1ecc <void zvec::turbo::InterleavedDistanceMatrix<signed char, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(signed char const*, signed char const*, unsigned long, float*)>

00000001001115cc <void kernel<short, 1ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
1001115cc:     	b	0x1001115d0 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(short const*, short const*, unsigned long, float*)>

00000001001116c0 <void kernel<short, 1ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001116c0:     	b	0x1001116c4 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(short const*, short const*, unsigned long, float*)>

0000000100112bd8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100112bd8:     	stp	d9, d8, [sp, #-16]!
100112bdc:     	cbz	x2, 0x100112bf8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x20>
100112be0:     	cmp	x2, #32
100112be4:     	b.hs	0x100112c04 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x2c>
100112be8:     	mov	x8, #0
100112bec:     	movi	d1, #0000000000000000
100112bf0:     	movi	d0, #0000000000000000
100112bf4:     	b	0x100112f58 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x380>
100112bf8:     	str	xzr, [x3]
100112bfc:     	ldp	d9, d8, [sp], #16
100112c00:     	ret
100112c04:     	and	x8, x2, #0xffffffffffffffe0
100112c08:     	add	x9, x1, #32
100112c0c:     	add	x10, x0, #64
100112c10:     	movi	d1, #0000000000000000
100112c14:     	mov	x11, x8
100112c18:     	movi	d0, #0000000000000000
100112c1c:     	ldp	q3, q2, [x9, #-32]
100112c20:     	sub	x12, x10, #64
100112c24:     	ld2.8h	{ v27, v28 }, [x12]
100112c28:     	ldp	q5, q4, [x9]
100112c2c:     	sub	x12, x10, #32
100112c30:     	ld2.8h	{ v23, v24 }, [x12]
100112c34:     	mov	x12, x10
100112c38:     	ld2.8h	{ v20, v21 }, [x12], #32
100112c3c:     	ld2.8h	{ v18, v19 }, [x12]
100112c40:     	sshll2.4s	v17, v27, #0
100112c44:     	sshll.4s	v26, v27, #0
100112c48:     	sshll2.4s	v16, v23, #0
100112c4c:     	sshll.4s	v25, v23, #0
100112c50:     	sshll2.4s	v7, v20, #0
100112c54:     	sshll.4s	v22, v20, #0
100112c58:     	sshll2.4s	v6, v18, #0
100112c5c:     	sshll2.4s	v29, v28, #0
100112c60:     	sshll.4s	v30, v18, #0
100112c64:     	sshll.4s	v27, v28, #0
100112c68:     	sshll2.4s	v28, v24, #0
100112c6c:     	sshll.4s	v23, v24, #0
100112c70:     	sshll2.4s	v24, v21, #0
100112c74:     	sshll.4s	v21, v21, #0
100112c78:     	sshll2.4s	v31, v19, #0
100112c7c:     	sshll.4s	v8, v19, #0
100112c80:     	sshll.4s	v18, v3, #0
100112c84:     	scvtf.4s	v18, v18
100112c88:     	scvtf.4s	v19, v26
100112c8c:     	scvtf.4s	v26, v27
100112c90:     	fsub.4s	v20, v19, v18
100112c94:     	fsub.4s	v26, v26, v18
100112c98:     	sshll2.4s	v3, v3, #0
100112c9c:     	scvtf.4s	v3, v3
100112ca0:     	scvtf.4s	v17, v17
100112ca4:     	scvtf.4s	v18, v29
100112ca8:     	fsub.4s	v19, v17, v3
100112cac:     	fsub.4s	v27, v18, v3
100112cb0:     	sshll.4s	v3, v2, #0
100112cb4:     	scvtf.4s	v3, v3
100112cb8:     	scvtf.4s	v17, v25
100112cbc:     	scvtf.4s	v23, v23
100112cc0:     	fsub.4s	v18, v17, v3
100112cc4:     	fsub.4s	v23, v23, v3
100112cc8:     	sshll2.4s	v2, v2, #0
100112ccc:     	scvtf.4s	v2, v2
100112cd0:     	scvtf.4s	v3, v16
100112cd4:     	scvtf.4s	v16, v28
100112cd8:     	fsub.4s	v17, v3, v2
100112cdc:     	fsub.4s	v25, v16, v2
100112ce0:     	sshll.4s	v2, v5, #0
100112ce4:     	scvtf.4s	v2, v2
100112ce8:     	scvtf.4s	v3, v22
100112cec:     	scvtf.4s	v21, v21
100112cf0:     	fsub.4s	v16, v3, v2
100112cf4:     	fsub.4s	v21, v21, v2
100112cf8:     	sshll2.4s	v2, v5, #0
100112cfc:     	scvtf.4s	v2, v2
100112d00:     	scvtf.4s	v3, v7
100112d04:     	scvtf.4s	v7, v24
100112d08:     	fsub.4s	v5, v3, v2
100112d0c:     	fsub.4s	v7, v7, v2
100112d10:     	sshll.4s	v2, v4, #0
100112d14:     	scvtf.4s	v2, v2
100112d18:     	scvtf.4s	v3, v30
100112d1c:     	scvtf.4s	v22, v8
100112d20:     	fsub.4s	v3, v3, v2
100112d24:     	fsub.4s	v22, v22, v2
100112d28:     	sshll2.4s	v2, v4, #0
100112d2c:     	scvtf.4s	v4, v2
100112d30:     	scvtf.4s	v2, v6
100112d34:     	scvtf.4s	v6, v31
100112d38:     	fsub.4s	v2, v2, v4
100112d3c:     	fsub.4s	v4, v6, v4
100112d40:     	fmul.4s	v6, v26, v26
100112d44:     	mov	s24, v6[1]
100112d48:     	fadd	s1, s1, s6
100112d4c:     	fadd	s1, s1, s24
100112d50:     	mov	s24, v6[2]
100112d54:     	fadd	s1, s1, s24
100112d58:     	fmul.4s	v24, v27, v27
100112d5c:     	mov	s6, v6[3]
100112d60:     	fadd	s1, s1, s6
100112d64:     	mov	s6, v24[1]
100112d68:     	fadd	s1, s1, s24
100112d6c:     	fadd	s1, s1, s6
100112d70:     	mov	s6, v24[2]
100112d74:     	fadd	s1, s1, s6
100112d78:     	mov	s6, v24[3]
100112d7c:     	fmul.4s	v23, v23, v23
100112d80:     	fadd	s1, s1, s6
100112d84:     	mov	s6, v23[1]
100112d88:     	fadd	s1, s1, s23
100112d8c:     	fadd	s1, s1, s6
100112d90:     	mov	s6, v23[2]
100112d94:     	fadd	s1, s1, s6
100112d98:     	fmul.4s	v6, v25, v25
100112d9c:     	mov	s23, v23[3]
100112da0:     	fadd	s1, s1, s23
100112da4:     	mov	s23, v6[1]
100112da8:     	fadd	s1, s1, s6
100112dac:     	fadd	s1, s1, s23
100112db0:     	mov	s23, v6[2]
100112db4:     	fadd	s1, s1, s23
100112db8:     	mov	s6, v6[3]
100112dbc:     	fmul.4s	v21, v21, v21
100112dc0:     	fadd	s1, s1, s6
100112dc4:     	mov	s6, v21[1]
100112dc8:     	fadd	s1, s1, s21
100112dcc:     	fadd	s1, s1, s6
100112dd0:     	mov	s6, v21[2]
100112dd4:     	fadd	s1, s1, s6
100112dd8:     	fmul.4s	v6, v7, v7
100112ddc:     	mov	s7, v21[3]
100112de0:     	fadd	s1, s1, s7
100112de4:     	mov	s7, v6[1]
100112de8:     	fadd	s1, s1, s6
100112dec:     	fadd	s1, s1, s7
100112df0:     	mov	s7, v6[2]
100112df4:     	fadd	s1, s1, s7
100112df8:     	fmul.4s	v7, v20, v20
100112dfc:     	mov	s6, v6[3]
100112e00:     	fmul.4s	v20, v22, v22
100112e04:     	fadd	s1, s1, s6
100112e08:     	mov	s6, v20[1]
100112e0c:     	fadd	s1, s1, s20
100112e10:     	fadd	s1, s1, s6
100112e14:     	mov	s6, v20[2]
100112e18:     	fadd	s1, s1, s6
100112e1c:     	mov	s6, v7[1]
100112e20:     	fadd	s0, s0, s7
100112e24:     	fadd	s0, s0, s6
100112e28:     	mov	s6, v7[2]
100112e2c:     	fadd	s0, s0, s6
100112e30:     	mov	s6, v7[3]
100112e34:     	fadd	s0, s0, s6
100112e38:     	fmul.4s	v6, v19, v19
100112e3c:     	mov	s7, v20[3]
100112e40:     	fadd	s1, s1, s7
100112e44:     	mov	s7, v6[1]
100112e48:     	fadd	s0, s0, s6
100112e4c:     	fadd	s0, s0, s7
100112e50:     	mov	s7, v6[2]
100112e54:     	fadd	s0, s0, s7
100112e58:     	mov	s6, v6[3]
100112e5c:     	fmul.4s	v7, v18, v18
100112e60:     	fmul.4s	v4, v4, v4
100112e64:     	fadd	s0, s0, s6
100112e68:     	mov	s6, v4[1]
100112e6c:     	fadd	s1, s1, s4
100112e70:     	fadd	s1, s1, s6
100112e74:     	mov	s6, v7[1]
100112e78:     	fadd	s0, s0, s7
100112e7c:     	fadd	s0, s0, s6
100112e80:     	mov	s6, v7[2]
100112e84:     	fadd	s0, s0, s6
100112e88:     	fmul.4s	v6, v17, v17
100112e8c:     	mov	s7, v7[3]
100112e90:     	fadd	s0, s0, s7
100112e94:     	mov	s7, v6[1]
100112e98:     	fadd	s0, s0, s6
100112e9c:     	fadd	s0, s0, s7
100112ea0:     	mov	s7, v6[2]
100112ea4:     	fadd	s0, s0, s7
100112ea8:     	mov	s6, v6[3]
100112eac:     	fmul.4s	v7, v16, v16
100112eb0:     	fadd	s0, s0, s6
100112eb4:     	mov	s6, v4[2]
100112eb8:     	fadd	s1, s1, s6
100112ebc:     	mov	s6, v7[1]
100112ec0:     	fadd	s0, s0, s7
100112ec4:     	fadd	s0, s0, s6
100112ec8:     	mov	s6, v7[2]
100112ecc:     	fadd	s0, s0, s6
100112ed0:     	fmul.4s	v5, v5, v5
100112ed4:     	mov	s6, v7[3]
100112ed8:     	fadd	s0, s0, s6
100112edc:     	mov	s6, v5[1]
100112ee0:     	fadd	s0, s0, s5
100112ee4:     	fadd	s0, s0, s6
100112ee8:     	mov	s6, v5[2]
100112eec:     	fadd	s0, s0, s6
100112ef0:     	mov	s5, v5[3]
100112ef4:     	fadd	s0, s0, s5
100112ef8:     	fmul.4s	v3, v3, v3
100112efc:     	mov	s4, v4[3]
100112f00:     	fadd	s1, s1, s4
100112f04:     	mov	s4, v3[1]
100112f08:     	fadd	s0, s0, s3
100112f0c:     	fadd	s0, s0, s4
100112f10:     	mov	s4, v3[2]
100112f14:     	fadd	s0, s0, s4
100112f18:     	fmul.4s	v2, v2, v2
100112f1c:     	mov	s3, v3[3]
100112f20:     	fadd	s0, s0, s3
100112f24:     	mov	s3, v2[1]
100112f28:     	fadd	s0, s0, s2
100112f2c:     	fadd	s0, s0, s3
100112f30:     	mov	s3, v2[2]
100112f34:     	fadd	s0, s0, s3
100112f38:     	mov	s2, v2[3]
100112f3c:     	fadd	s0, s0, s2
100112f40:     	add	x9, x9, #64
100112f44:     	add	x10, x10, #128
100112f48:     	subs	x11, x11, #32
100112f4c:     	b.ne	0x100112c1c <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x44>
100112f50:     	cmp	x8, x2
100112f54:     	b.eq	0x100112fa4 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
100112f58:     	sub	x9, x2, x8
100112f5c:     	add	x10, x0, x8, lsl #2
100112f60:     	add	x10, x10, #2
100112f64:     	add	x8, x1, x8, lsl #1
100112f68:     	ldrsh	w11, [x8], #2
100112f6c:     	scvtf	s2, w11
100112f70:     	ldur	h3, [x10, #-2]
100112f74:     	sshll.4s	v3, v3, #0
100112f78:     	scvtf	s3, s3
100112f7c:     	fsub	s3, s3, s2
100112f80:     	fmadd	s0, s3, s3, s0
100112f84:     	ldr	h3, [x10]
100112f88:     	sshll.4s	v3, v3, #0
100112f8c:     	scvtf	s3, s3
100112f90:     	fsub	s2, s3, s2
100112f94:     	fmadd	s1, s2, s2, s1
100112f98:     	add	x10, x10, #4
100112f9c:     	subs	x9, x9, #1
100112fa0:     	b.ne	0x100112f68 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
100112fa4:     	stp	s0, s1, [x3]
100112fa8:     	ldp	d9, d8, [sp], #16
100112fac:     	ret

0000000100112fb0 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100112fb0:     	cbz	x2, 0x100112fcc <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x1c>
100112fb4:     	cmp	x2, #32
100112fb8:     	b.hs	0x100112fd4 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x24>
100112fbc:     	mov	x8, #0
100112fc0:     	movi	d1, #0000000000000000
100112fc4:     	movi	d0, #0000000000000000
100112fc8:     	b	0x100113328 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x378>
100112fcc:     	str	xzr, [x3]
100112fd0:     	ret
100112fd4:     	and	x8, x2, #0xffffffffffffffe0
100112fd8:     	add	x9, x1, #32
100112fdc:     	add	x10, x0, #64
100112fe0:     	movi	d1, #0000000000000000
100112fe4:     	mov	x11, x8
100112fe8:     	movi	d0, #0000000000000000
100112fec:     	ldp	q4, q2, [x9, #-32]
100112ff0:     	sub	x12, x10, #64
100112ff4:     	ld2.8h	{ v27, v28 }, [x12]
100112ff8:     	ldp	q5, q3, [x9]
100112ffc:     	sub	x12, x10, #32
100113000:     	ld2.8h	{ v25, v26 }, [x12]
100113004:     	mov	x12, x10
100113008:     	ld2.8h	{ v22, v23 }, [x12], #32
10011300c:     	ld2.8h	{ v20, v21 }, [x12]
100113010:     	sshll2.4s	v24, v27, #0
100113014:     	sshll.4s	v19, v27, #0
100113018:     	sshll2.4s	v18, v25, #0
10011301c:     	sshll.4s	v17, v25, #0
100113020:     	sshll2.4s	v16, v22, #0
100113024:     	sshll.4s	v7, v22, #0
100113028:     	sshll2.4s	v6, v20, #0
10011302c:     	sshll2.4s	v30, v28, #0
100113030:     	sshll.4s	v29, v20, #0
100113034:     	sshll.4s	v27, v28, #0
100113038:     	sshll2.4s	v28, v26, #0
10011303c:     	sshll.4s	v25, v26, #0
100113040:     	sshll2.4s	v26, v23, #0
100113044:     	sshll.4s	v22, v23, #0
100113048:     	sshll2.4s	v23, v21, #0
10011304c:     	sshll.4s	v21, v21, #0
100113050:     	sshll2.4s	v20, v4, #0
100113054:     	scvtf.4s	v31, v20
100113058:     	scvtf.4s	v20, v24
10011305c:     	fneg.4s	v20, v20
100113060:     	fmul.4s	v20, v20, v31
100113064:     	scvtf.4s	v24, v30
100113068:     	fneg.4s	v24, v24
10011306c:     	fmul.4s	v24, v24, v31
100113070:     	sshll.4s	v4, v4, #0
100113074:     	scvtf.4s	v4, v4
100113078:     	scvtf.4s	v19, v19
10011307c:     	fneg.4s	v19, v19
100113080:     	fmul.4s	v19, v19, v4
100113084:     	scvtf.4s	v27, v27
100113088:     	fneg.4s	v27, v27
10011308c:     	fmul.4s	v27, v27, v4
100113090:     	sshll2.4s	v4, v2, #0
100113094:     	scvtf.4s	v30, v4
100113098:     	scvtf.4s	v4, v18
10011309c:     	fneg.4s	v4, v4
1001130a0:     	scvtf.4s	v18, v28
1001130a4:     	fneg.4s	v18, v18
1001130a8:     	fmul.4s	v4, v4, v30
1001130ac:     	fmul.4s	v18, v18, v30
1001130b0:     	sshll.4s	v2, v2, #0
1001130b4:     	scvtf.4s	v2, v2
1001130b8:     	scvtf.4s	v17, v17
1001130bc:     	fneg.4s	v17, v17
1001130c0:     	fmul.4s	v17, v17, v2
1001130c4:     	scvtf.4s	v25, v25
1001130c8:     	fneg.4s	v25, v25
1001130cc:     	fmul.4s	v25, v25, v2
1001130d0:     	sshll2.4s	v2, v5, #0
1001130d4:     	scvtf.4s	v16, v16
1001130d8:     	scvtf.4s	v28, v2
1001130dc:     	fneg.4s	v2, v16
1001130e0:     	fmul.4s	v2, v2, v28
1001130e4:     	scvtf.4s	v16, v26
1001130e8:     	fneg.4s	v16, v16
1001130ec:     	fmul.4s	v16, v16, v28
1001130f0:     	sshll.4s	v5, v5, #0
1001130f4:     	scvtf.4s	v5, v5
1001130f8:     	scvtf.4s	v7, v7
1001130fc:     	fneg.4s	v7, v7
100113100:     	scvtf.4s	v22, v22
100113104:     	fneg.4s	v22, v22
100113108:     	fmul.4s	v7, v7, v5
10011310c:     	fmul.4s	v22, v22, v5
100113110:     	sshll2.4s	v5, v3, #0
100113114:     	scvtf.4s	v26, v5
100113118:     	scvtf.4s	v5, v6
10011311c:     	fneg.4s	v5, v5
100113120:     	fmul.4s	v5, v5, v26
100113124:     	scvtf.4s	v6, v23
100113128:     	fneg.4s	v6, v6
10011312c:     	fmul.4s	v6, v6, v26
100113130:     	sshll.4s	v3, v3, #0
100113134:     	scvtf.4s	v3, v3
100113138:     	scvtf.4s	v23, v29
10011313c:     	fneg.4s	v23, v23
100113140:     	fmul.4s	v23, v23, v3
100113144:     	scvtf.4s	v21, v21
100113148:     	fneg.4s	v21, v21
10011314c:     	fmul.4s	v3, v21, v3
100113150:     	mov	s21, v27[1]
100113154:     	fadd	s1, s1, s27
100113158:     	fadd	s1, s1, s21
10011315c:     	mov	s21, v27[2]
100113160:     	fadd	s1, s1, s21
100113164:     	mov	s21, v27[3]
100113168:     	fadd	s1, s1, s21
10011316c:     	mov	s21, v24[1]
100113170:     	fadd	s1, s1, s24
100113174:     	fadd	s1, s1, s21
100113178:     	mov	s21, v24[2]
10011317c:     	fadd	s1, s1, s21
100113180:     	mov	s21, v24[3]
100113184:     	fadd	s1, s1, s21
100113188:     	mov	s21, v25[1]
10011318c:     	fadd	s1, s1, s25
100113190:     	fadd	s1, s1, s21
100113194:     	mov	s21, v25[2]
100113198:     	fadd	s1, s1, s21
10011319c:     	mov	s21, v25[3]
1001131a0:     	fadd	s1, s1, s21
1001131a4:     	mov	s21, v18[1]
1001131a8:     	fadd	s1, s1, s18
1001131ac:     	fadd	s1, s1, s21
1001131b0:     	mov	s21, v18[2]
1001131b4:     	fadd	s1, s1, s21
1001131b8:     	mov	s18, v18[3]
1001131bc:     	fadd	s1, s1, s18
1001131c0:     	mov	s18, v22[1]
1001131c4:     	fadd	s1, s1, s22
1001131c8:     	fadd	s1, s1, s18
1001131cc:     	mov	s18, v22[2]
1001131d0:     	fadd	s1, s1, s18
1001131d4:     	mov	s18, v22[3]
1001131d8:     	fadd	s1, s1, s18
1001131dc:     	mov	s18, v16[1]
1001131e0:     	fadd	s1, s1, s16
1001131e4:     	fadd	s1, s1, s18
1001131e8:     	mov	s18, v16[2]
1001131ec:     	fadd	s1, s1, s18
1001131f0:     	mov	s16, v16[3]
1001131f4:     	fadd	s1, s1, s16
1001131f8:     	mov	s16, v3[1]
1001131fc:     	fadd	s1, s1, s3
100113200:     	fadd	s1, s1, s16
100113204:     	mov	s16, v3[2]
100113208:     	fadd	s1, s1, s16
10011320c:     	fadd	s0, s0, s19
100113210:     	mov	s16, v19[1]
100113214:     	fadd	s0, s0, s16
100113218:     	mov	s16, v19[2]
10011321c:     	fadd	s0, s0, s16
100113220:     	mov	s16, v19[3]
100113224:     	fadd	s0, s0, s16
100113228:     	mov	s16, v20[1]
10011322c:     	fadd	s0, s0, s20
100113230:     	fadd	s0, s0, s16
100113234:     	mov	s16, v20[2]
100113238:     	fadd	s0, s0, s16
10011323c:     	mov	s3, v3[3]
100113240:     	fadd	s1, s1, s3
100113244:     	mov	s3, v20[3]
100113248:     	fadd	s0, s0, s3
10011324c:     	mov	s3, v17[1]
100113250:     	fadd	s0, s0, s17
100113254:     	fadd	s0, s0, s3
100113258:     	mov	s3, v17[2]
10011325c:     	fadd	s0, s0, s3
100113260:     	mov	s3, v17[3]
100113264:     	fadd	s0, s0, s3
100113268:     	mov	s3, v6[1]
10011326c:     	fadd	s1, s1, s6
100113270:     	fadd	s1, s1, s3
100113274:     	mov	s3, v4[1]
100113278:     	fadd	s0, s0, s4
10011327c:     	fadd	s0, s0, s3
100113280:     	mov	s3, v4[2]
100113284:     	fadd	s0, s0, s3
100113288:     	mov	s3, v4[3]
10011328c:     	fadd	s0, s0, s3
100113290:     	mov	s3, v7[1]
100113294:     	fadd	s0, s0, s7
100113298:     	fadd	s0, s0, s3
10011329c:     	mov	s3, v6[2]
1001132a0:     	fadd	s1, s1, s3
1001132a4:     	mov	s3, v7[2]
1001132a8:     	fadd	s0, s0, s3
1001132ac:     	mov	s3, v7[3]
1001132b0:     	fadd	s0, s0, s3
1001132b4:     	fadd	s0, s0, s2
1001132b8:     	mov	s3, v2[1]
1001132bc:     	fadd	s0, s0, s3
1001132c0:     	mov	s3, v2[2]
1001132c4:     	fadd	s0, s0, s3
1001132c8:     	mov	s2, v2[3]
1001132cc:     	fadd	s0, s0, s2
1001132d0:     	mov	s2, v23[1]
1001132d4:     	fadd	s0, s0, s23
1001132d8:     	fadd	s0, s0, s2
1001132dc:     	mov	s2, v23[2]
1001132e0:     	fadd	s0, s0, s2
1001132e4:     	mov	s2, v6[3]
1001132e8:     	fadd	s1, s1, s2
1001132ec:     	mov	s2, v23[3]
1001132f0:     	fadd	s0, s0, s2
1001132f4:     	mov	s2, v5[1]
1001132f8:     	fadd	s0, s0, s5
1001132fc:     	fadd	s0, s0, s2
100113300:     	mov	s2, v5[2]
100113304:     	fadd	s0, s0, s2
100113308:     	mov	s2, v5[3]
10011330c:     	fadd	s0, s0, s2
100113310:     	add	x9, x9, #64
100113314:     	add	x10, x10, #128
100113318:     	subs	x11, x11, #32
10011331c:     	b.ne	0x100112fec <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3c>
100113320:     	cmp	x8, x2
100113324:     	b.eq	0x10011336c <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3bc>
100113328:     	sub	x9, x2, x8
10011332c:     	add	x10, x0, x8, lsl #2
100113330:     	add	x10, x10, #2
100113334:     	add	x8, x1, x8, lsl #1
100113338:     	ldrsh	w11, [x8], #2
10011333c:     	scvtf	s2, w11
100113340:     	ldur	h3, [x10, #-2]
100113344:     	sshll.4s	v3, v3, #0
100113348:     	scvtf	s3, s3
10011334c:     	fmsub	s0, s3, s2, s0
100113350:     	ldr	h3, [x10]
100113354:     	sshll.4s	v3, v3, #0
100113358:     	scvtf	s3, s3
10011335c:     	fmsub	s1, s3, s2, s1
100113360:     	add	x10, x10, #4
100113364:     	subs	x9, x9, #1
100113368:     	b.ne	0x100113338 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x388>
10011336c:     	stp	s0, s1, [x3]
100113370:     	ret

0000000100114ed8 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
100114ed8:     	cbz	x2, 0x100114f38 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x60>
100114edc:     	ldrsh	w8, [x1]
100114ee0:     	fmov	s0, w8
100114ee4:     	ldrsh	w8, [x1, #2]
100114ee8:     	mov.s	v0[1], w8
100114eec:     	scvtf.2s	v0, v0
100114ef0:     	zip1.4s	v0, v0, v0
100114ef4:     	ldrsh	w8, [x0]
100114ef8:     	fmov	s1, w8
100114efc:     	ldrsh	w8, [x0, #2]
100114f00:     	mov.s	v1[1], w8
100114f04:     	scvtf.2s	v1, v1
100114f08:     	mov.d	v1[1], v1[0]
100114f0c:     	fsub.4s	v0, v1, v0
100114f10:     	fmul.4s	v0, v0, v0
100114f14:     	str	q0, [x3]
100114f18:     	subs	x11, x2, #1
100114f1c:     	b.eq	0x10011514c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x274>
100114f20:     	cmp	x2, #9
100114f24:     	b.hs	0x100114f40 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x68>
100114f28:     	mov	w8, #1
100114f2c:     	mov	x9, x1
100114f30:     	mov	x10, x0
100114f34:     	b	0x1001150f0 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x218>
100114f38:     	stp	xzr, xzr, [x3]
100114f3c:     	ret
100114f40:     	and	x12, x11, #0xfffffffffffffff8
100114f44:     	lsl	x8, x12, #2
100114f48:     	add	x9, x1, x8
100114f4c:     	add	x10, x0, x8
100114f50:     	orr	x8, x12, #0x1
100114f54:     	mov	s3, v0[1]
100114f58:     	mov	s2, v0[2]
100114f5c:     	mov	s1, v0[3]
100114f60:     	add	x13, x0, #4
100114f64:     	add	x14, x1, #4
100114f68:     	mov	x15, x12
100114f6c:     	ld2.8h	{ v4, v5 }, [x13], #32
100114f70:     	sshll2.4s	v6, v4, #0
100114f74:     	scvtf.4s	v6, v6
100114f78:     	sshll.4s	v7, v4, #0
100114f7c:     	scvtf.4s	v7, v7
100114f80:     	ld2.8h	{ v16, v17 }, [x14], #32
100114f84:     	sshll2.4s	v18, v16, #0
100114f88:     	scvtf.4s	v18, v18
100114f8c:     	sshll.4s	v19, v16, #0
100114f90:     	scvtf.4s	v19, v19
100114f94:     	sshll2.4s	v20, v17, #0
100114f98:     	sshll.4s	v16, v17, #0
100114f9c:     	sshll2.4s	v17, v5, #0
100114fa0:     	sshll.4s	v4, v5, #0
100114fa4:     	fsub.4s	v5, v7, v19
100114fa8:     	scvtf.4s	v16, v16
100114fac:     	fsub.4s	v7, v7, v16
100114fb0:     	scvtf.4s	v4, v4
100114fb4:     	fsub.4s	v19, v4, v19
100114fb8:     	fsub.4s	v4, v4, v16
100114fbc:     	fsub.4s	v16, v6, v18
100114fc0:     	scvtf.4s	v20, v20
100114fc4:     	fsub.4s	v6, v6, v20
100114fc8:     	scvtf.4s	v17, v17
100114fcc:     	fsub.4s	v18, v17, v18
100114fd0:     	fsub.4s	v17, v17, v20
100114fd4:     	fmul.4s	v4, v4, v4
100114fd8:     	mov	s20, v4[1]
100114fdc:     	fadd	s1, s1, s4
100114fe0:     	fadd	s1, s1, s20
100114fe4:     	mov	s20, v4[2]
100114fe8:     	fadd	s1, s1, s20
100114fec:     	fmul.4s	v17, v17, v17
100114ff0:     	mov	s4, v4[3]
100114ff4:     	fadd	s1, s1, s4
100114ff8:     	mov	s4, v17[1]
100114ffc:     	fadd	s1, s1, s17
100115000:     	fadd	s1, s1, s4
100115004:     	mov	s4, v17[2]
100115008:     	fadd	s1, s1, s4
10011500c:     	fmul.4s	v4, v19, v19
100115010:     	mov	s17, v17[3]
100115014:     	fadd	s1, s1, s17
100115018:     	mov	s17, v4[1]
10011501c:     	fadd	s3, s3, s4
100115020:     	fadd	s3, s3, s17
100115024:     	mov	s17, v4[2]
100115028:     	fadd	s3, s3, s17
10011502c:     	fmul.4s	v17, v18, v18
100115030:     	mov	s4, v4[3]
100115034:     	fadd	s3, s3, s4
100115038:     	mov	s4, v17[1]
10011503c:     	fadd	s3, s3, s17
100115040:     	fadd	s3, s3, s4
100115044:     	mov	s4, v17[2]
100115048:     	fadd	s3, s3, s4
10011504c:     	fmul.4s	v4, v7, v7
100115050:     	mov	s7, v17[3]
100115054:     	fadd	s3, s3, s7
100115058:     	mov	s7, v4[1]
10011505c:     	fadd	s2, s2, s4
100115060:     	fadd	s2, s2, s7
100115064:     	mov	s7, v4[2]
100115068:     	fadd	s2, s2, s7
10011506c:     	fmul.4s	v6, v6, v6
100115070:     	mov	s4, v4[3]
100115074:     	fadd	s2, s2, s4
100115078:     	mov	s4, v6[1]
10011507c:     	fadd	s2, s2, s6
100115080:     	fadd	s2, s2, s4
100115084:     	mov	s4, v6[2]
100115088:     	fadd	s2, s2, s4
10011508c:     	fmul.4s	v4, v5, v5
100115090:     	mov	s5, v6[3]
100115094:     	fadd	s2, s2, s5
100115098:     	mov	s5, v4[1]
10011509c:     	fadd	s0, s0, s4
1001150a0:     	fadd	s0, s0, s5
1001150a4:     	mov	s5, v4[2]
1001150a8:     	fadd	s0, s0, s5
1001150ac:     	fmul.4s	v5, v16, v16
1001150b0:     	mov	s4, v4[3]
1001150b4:     	fadd	s0, s0, s4
1001150b8:     	mov	s4, v5[1]
1001150bc:     	fadd	s0, s0, s5
1001150c0:     	fadd	s0, s0, s4
1001150c4:     	mov	s4, v5[3]
1001150c8:     	mov	s5, v5[2]
1001150cc:     	fadd	s0, s0, s5
1001150d0:     	fadd	s0, s0, s4
1001150d4:     	subs	x15, x15, #8
1001150d8:     	b.ne	0x100114f6c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x94>
1001150dc:     	mov.s	v0[1], v3[0]
1001150e0:     	mov.s	v0[2], v2[0]
1001150e4:     	mov.s	v0[3], v1[0]
1001150e8:     	cmp	x11, x12
1001150ec:     	b.eq	0x100115148 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x270>
1001150f0:     	add	x9, x9, #4
1001150f4:     	add	x10, x10, #4
1001150f8:     	sub	x8, x2, x8
1001150fc:     	ldrsh	w11, [x9]
100115100:     	fmov	s1, w11
100115104:     	ldrsh	w11, [x9, #2]
100115108:     	mov.s	v1[1], w11
10011510c:     	scvtf.2s	v1, v1
100115110:     	zip1.4s	v1, v1, v1
100115114:     	ldrsh	w11, [x10]
100115118:     	fmov	s2, w11
10011511c:     	ldrsh	w11, [x10, #2]
100115120:     	mov.s	v2[1], w11
100115124:     	scvtf.2s	v2, v2
100115128:     	mov.d	v2[1], v2[0]
10011512c:     	fsub.4s	v1, v2, v1
100115130:     	fmul.4s	v1, v1, v1
100115134:     	fadd.4s	v0, v0, v1
100115138:     	add	x9, x9, #4
10011513c:     	add	x10, x10, #4
100115140:     	subs	x8, x8, #1
100115144:     	b.ne	0x1001150fc <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x224>
100115148:     	str	q0, [x3]
10011514c:     	ret

0000000100115150 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100115150:     	cbz	x2, 0x1001151f0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0xa0>
100115154:     	ldrsh	w8, [x1, #2]
100115158:     	ldrsh	w9, [x1]
10011515c:     	fmov	s0, w9
100115160:     	mov.s	v0[1], w8
100115164:     	ldrsh	w8, [x0, #2]
100115168:     	ldrsh	w9, [x0]
10011516c:     	fmov	s1, w9
100115170:     	mov.s	v1[1], w8
100115174:     	mov.s	v1[2], w9
100115178:     	mov.s	v1[3], w8
10011517c:     	zip1.4s	v0, v0, v0
100115180:     	mul.4s	v0, v1, v0
100115184:     	scvtf.4s	v0, v0
100115188:     	fneg.4s	v0, v0
10011518c:     	str	q0, [x3]
100115190:     	subs	x8, x2, #1
100115194:     	b.eq	0x1001151ec <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x9c>
100115198:     	add	x9, x0, #4
10011519c:     	add	x10, x1, #4
1001151a0:     	ldrsh	w11, [x10, #2]
1001151a4:     	ldrsh	w12, [x10]
1001151a8:     	fmov	s1, w12
1001151ac:     	mov.s	v1[1], w11
1001151b0:     	zip1.4s	v1, v1, v1
1001151b4:     	ldrsh	w11, [x9, #2]
1001151b8:     	ldrsh	w12, [x9]
1001151bc:     	fmov	s2, w12
1001151c0:     	mov.s	v2[1], w11
1001151c4:     	mov.s	v2[2], w12
1001151c8:     	mov.s	v2[3], w11
1001151cc:     	mul.4s	v1, v2, v1
1001151d0:     	scvtf.4s	v1, v1
1001151d4:     	fsub.4s	v0, v0, v1
1001151d8:     	add	x9, x9, #4
1001151dc:     	add	x10, x10, #4
1001151e0:     	subs	x8, x8, #1
1001151e4:     	b.ne	0x1001151a0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x50>
1001151e8:     	str	q0, [x3]
1001151ec:     	ret
1001151f0:     	stp	xzr, xzr, [x3]
1001151f4:     	ret

0000000100116a94 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100116a94:     	cbz	x2, 0x100116adc <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x48>
100116a98:     	ldr	h0, [x1]
100116a9c:     	sshll.4s	v0, v0, #0
100116aa0:     	scvtf	s0, s0
100116aa4:     	ldr	d1, [x0]
100116aa8:     	sshll.4s	v1, v1, #0
100116aac:     	scvtf.4s	v1, v1
100116ab0:     	dup.4s	v0, v0[0]
100116ab4:     	fsub.4s	v0, v1, v0
100116ab8:     	fmul.4s	v0, v0, v0
100116abc:     	str	q0, [x3]
100116ac0:     	subs	x10, x2, #1
100116ac4:     	b.eq	0x100116e60 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
100116ac8:     	cmp	x2, #17
100116acc:     	b.hs	0x100116ae4 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x50>
100116ad0:     	mov	w8, #1
100116ad4:     	mov	x9, x1
100116ad8:     	b	0x100116e24 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
100116adc:     	stp	xzr, xzr, [x3]
100116ae0:     	ret
100116ae4:     	and	x11, x10, #0xfffffffffffffff0
100116ae8:     	add	x9, x1, x11, lsl #1
100116aec:     	orr	x8, x11, #0x1
100116af0:     	mov	s1, v0[1]
100116af4:     	mov	s2, v0[2]
100116af8:     	mov	s3, v0[3]
100116afc:     	add	x12, x0, #72
100116b00:     	add	x13, x1, #18
100116b04:     	mov	x14, x11
100116b08:     	add	x0, x0, x11, lsl #3
100116b0c:     	sub	x15, x12, #64
100116b10:     	ld4.8h	{ v16, v17, v18, v19 }, [x15]
100116b14:     	ld4.8h	{ v20, v21, v22, v23 }, [x12]
100116b18:     	sshll2.4s	v5, v16, #0
100116b1c:     	sshll2.4s	v4, v20, #0
100116b20:     	sshll.4s	v7, v16, #0
100116b24:     	sshll.4s	v6, v20, #0
100116b28:     	sshll2.4s	v25, v17, #0
100116b2c:     	sshll.4s	v27, v17, #0
100116b30:     	sshll2.4s	v24, v21, #0
100116b34:     	sshll.4s	v26, v21, #0
100116b38:     	sshll2.4s	v28, v18, #0
100116b3c:     	sshll.4s	v29, v18, #0
100116b40:     	sshll2.4s	v30, v19, #0
100116b44:     	sshll.4s	v16, v19, #0
100116b48:     	sshll2.4s	v17, v22, #0
100116b4c:     	sshll.4s	v18, v22, #0
100116b50:     	sshll2.4s	v19, v23, #0
100116b54:     	sshll.4s	v20, v23, #0
100116b58:     	ldur	q21, [x13, #-16]
100116b5c:     	sshll.4s	v22, v21, #0
100116b60:     	scvtf.4s	v22, v22
100116b64:     	scvtf.4s	v7, v7
100116b68:     	fsub.4s	v7, v7, v22
100116b6c:     	scvtf.4s	v23, v27
100116b70:     	fsub.4s	v23, v23, v22
100116b74:     	scvtf.4s	v27, v29
100116b78:     	fsub.4s	v27, v27, v22
100116b7c:     	scvtf.4s	v16, v16
100116b80:     	fsub.4s	v22, v16, v22
100116b84:     	ldr	q29, [x13]
100116b88:     	sshll2.4s	v16, v21, #0
100116b8c:     	scvtf.4s	v21, v16
100116b90:     	scvtf.4s	v5, v5
100116b94:     	scvtf.4s	v25, v25
100116b98:     	fsub.4s	v16, v5, v21
100116b9c:     	fsub.4s	v25, v25, v21
100116ba0:     	scvtf.4s	v5, v28
100116ba4:     	fsub.4s	v28, v5, v21
100116ba8:     	scvtf.4s	v5, v30
100116bac:     	fsub.4s	v21, v5, v21
100116bb0:     	sshll.4s	v5, v29, #0
100116bb4:     	scvtf.4s	v30, v5
100116bb8:     	scvtf.4s	v5, v6
100116bbc:     	fsub.4s	v5, v5, v30
100116bc0:     	scvtf.4s	v6, v26
100116bc4:     	scvtf.4s	v18, v18
100116bc8:     	fsub.4s	v6, v6, v30
100116bcc:     	fsub.4s	v18, v18, v30
100116bd0:     	scvtf.4s	v20, v20
100116bd4:     	fsub.4s	v20, v20, v30
100116bd8:     	sshll2.4s	v26, v29, #0
100116bdc:     	scvtf.4s	v26, v26
100116be0:     	scvtf.4s	v4, v4
100116be4:     	fsub.4s	v4, v4, v26
100116be8:     	scvtf.4s	v24, v24
100116bec:     	fsub.4s	v24, v24, v26
100116bf0:     	scvtf.4s	v17, v17
100116bf4:     	scvtf.4s	v19, v19
100116bf8:     	fsub.4s	v17, v17, v26
100116bfc:     	fsub.4s	v19, v19, v26
100116c00:     	fmul.4s	v22, v22, v22
100116c04:     	mov	s26, v22[1]
100116c08:     	fadd	s3, s3, s22
100116c0c:     	fadd	s3, s3, s26
100116c10:     	mov	s26, v22[2]
100116c14:     	fadd	s3, s3, s26
100116c18:     	fmul.4s	v21, v21, v21
100116c1c:     	mov	s22, v22[3]
100116c20:     	fadd	s3, s3, s22
100116c24:     	mov	s22, v21[1]
100116c28:     	fadd	s3, s3, s21
100116c2c:     	fadd	s3, s3, s22
100116c30:     	mov	s22, v21[2]
100116c34:     	fadd	s3, s3, s22
100116c38:     	mov	s21, v21[3]
100116c3c:     	fmul.4s	v20, v20, v20
100116c40:     	fadd	s3, s3, s21
100116c44:     	mov	s21, v20[1]
100116c48:     	fadd	s3, s3, s20
100116c4c:     	fadd	s3, s3, s21
100116c50:     	mov	s21, v20[2]
100116c54:     	fadd	s3, s3, s21
100116c58:     	fmul.4s	v21, v27, v27
100116c5c:     	fmul.4s	v19, v19, v19
100116c60:     	mov	s20, v20[3]
100116c64:     	fadd	s3, s3, s20
100116c68:     	mov	s20, v19[1]
100116c6c:     	fadd	s3, s3, s19
100116c70:     	fadd	s3, s3, s20
100116c74:     	mov	s20, v21[1]
100116c78:     	fadd	s2, s2, s21
100116c7c:     	fadd	s2, s2, s20
100116c80:     	mov	s20, v21[2]
100116c84:     	fadd	s2, s2, s20
100116c88:     	fmul.4s	v20, v28, v28
100116c8c:     	mov	s21, v21[3]
100116c90:     	fadd	s2, s2, s21
100116c94:     	mov	s21, v20[1]
100116c98:     	fadd	s2, s2, s20
100116c9c:     	fadd	s2, s2, s21
100116ca0:     	mov	s21, v20[2]
100116ca4:     	fadd	s2, s2, s21
100116ca8:     	mov	s20, v20[3]
100116cac:     	fmul.4s	v18, v18, v18
100116cb0:     	fadd	s2, s2, s20
100116cb4:     	mov	s20, v18[1]
100116cb8:     	fadd	s2, s2, s18
100116cbc:     	fadd	s2, s2, s20
100116cc0:     	mov	s20, v18[2]
100116cc4:     	fadd	s2, s2, s20
100116cc8:     	fmul.4s	v20, v23, v23
100116ccc:     	fmul.4s	v17, v17, v17
100116cd0:     	mov	s18, v18[3]
100116cd4:     	fadd	s2, s2, s18
100116cd8:     	mov	s18, v17[1]
100116cdc:     	fadd	s2, s2, s17
100116ce0:     	fadd	s2, s2, s18
100116ce4:     	mov	s18, v19[2]
100116ce8:     	fadd	s3, s3, s18
100116cec:     	mov	s18, v17[2]
100116cf0:     	fadd	s2, s2, s18
100116cf4:     	mov	s18, v20[1]
100116cf8:     	fadd	s1, s1, s20
100116cfc:     	fadd	s1, s1, s18
100116d00:     	mov	s18, v20[2]
100116d04:     	fadd	s1, s1, s18
100116d08:     	mov	s18, v20[3]
100116d0c:     	fadd	s1, s1, s18
100116d10:     	fmul.4s	v18, v25, v25
100116d14:     	mov	s19, v19[3]
100116d18:     	fadd	s3, s3, s19
100116d1c:     	mov	s19, v18[1]
100116d20:     	fadd	s1, s1, s18
100116d24:     	fadd	s1, s1, s19
100116d28:     	mov	s19, v18[2]
100116d2c:     	fadd	s1, s1, s19
100116d30:     	mov	s18, v18[3]
100116d34:     	fmul.4s	v6, v6, v6
100116d38:     	fadd	s1, s1, s18
100116d3c:     	mov	s18, v6[1]
100116d40:     	fadd	s1, s1, s6
100116d44:     	fadd	s1, s1, s18
100116d48:     	mov	s18, v6[2]
100116d4c:     	fadd	s1, s1, s18
100116d50:     	fmul.4s	v18, v24, v24
100116d54:     	mov	s6, v6[3]
100116d58:     	fadd	s1, s1, s6
100116d5c:     	mov	s6, v18[1]
100116d60:     	fadd	s1, s1, s18
100116d64:     	fadd	s1, s1, s6
100116d68:     	mov	s6, v18[2]
100116d6c:     	fadd	s1, s1, s6
100116d70:     	fmul.4s	v6, v7, v7
100116d74:     	mov	s7, v17[3]
100116d78:     	fadd	s2, s2, s7
100116d7c:     	mov	s7, v6[1]
100116d80:     	fadd	s0, s0, s6
100116d84:     	fadd	s0, s0, s7
100116d88:     	mov	s7, v6[2]
100116d8c:     	fadd	s0, s0, s7
100116d90:     	fmul.4s	v7, v16, v16
100116d94:     	mov	s6, v6[3]
100116d98:     	fadd	s0, s0, s6
100116d9c:     	mov	s6, v7[1]
100116da0:     	fadd	s0, s0, s7
100116da4:     	fadd	s0, s0, s6
100116da8:     	mov	s6, v7[2]
100116dac:     	fadd	s0, s0, s6
100116db0:     	mov	s6, v7[3]
100116db4:     	fadd	s0, s0, s6
100116db8:     	fmul.4s	v5, v5, v5
100116dbc:     	mov	s6, v18[3]
100116dc0:     	fadd	s1, s1, s6
100116dc4:     	mov	s6, v5[1]
100116dc8:     	fadd	s0, s0, s5
100116dcc:     	fadd	s0, s0, s6
100116dd0:     	mov	s6, v5[2]
100116dd4:     	fadd	s0, s0, s6
100116dd8:     	fmul.4s	v4, v4, v4
100116ddc:     	mov	s5, v5[3]
100116de0:     	fadd	s0, s0, s5
100116de4:     	mov	s5, v4[1]
100116de8:     	fadd	s0, s0, s4
100116dec:     	fadd	s0, s0, s5
100116df0:     	mov	s5, v4[2]
100116df4:     	fadd	s0, s0, s5
100116df8:     	mov	s4, v4[3]
100116dfc:     	fadd	s0, s0, s4
100116e00:     	add	x12, x12, #128
100116e04:     	add	x13, x13, #32
100116e08:     	subs	x14, x14, #16
100116e0c:     	b.ne	0x100116b0c <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x78>
100116e10:     	mov.s	v0[1], v1[0]
100116e14:     	mov.s	v0[2], v2[0]
100116e18:     	mov.s	v0[3], v3[0]
100116e1c:     	cmp	x10, x11
100116e20:     	b.eq	0x100116e5c <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3c8>
100116e24:     	add	x9, x9, #2
100116e28:     	add	x10, x0, #8
100116e2c:     	sub	x8, x2, x8
100116e30:     	ldrsh	w11, [x9], #2
100116e34:     	scvtf	s1, w11
100116e38:     	ldr	d2, [x10], #8
100116e3c:     	sshll.4s	v2, v2, #0
100116e40:     	scvtf.4s	v2, v2
100116e44:     	dup.4s	v1, v1[0]
100116e48:     	fsub.4s	v1, v2, v1
100116e4c:     	fmul.4s	v1, v1, v1
100116e50:     	fadd.4s	v0, v0, v1
100116e54:     	subs	x8, x8, #1
100116e58:     	b.ne	0x100116e30 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x39c>
100116e5c:     	str	q0, [x3]
100116e60:     	ret

0000000100116e64 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100116e64:     	cbz	x2, 0x100116ebc <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x58>
100116e68:     	ld1r.4h	{ v0 }, [x1]
100116e6c:     	ldr	d1, [x0]
100116e70:     	smull.4s	v0, v0, v1
100116e74:     	scvtf.4s	v0, v0
100116e78:     	fneg.4s	v0, v0
100116e7c:     	str	q0, [x3]
100116e80:     	cmp	x2, #1
100116e84:     	b.eq	0x100116eb8 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x54>
100116e88:     	add	x8, x1, #2
100116e8c:     	add	x9, x0, #8
100116e90:     	lsl	x10, x2, #1
100116e94:     	sub	x10, x10, #2
100116e98:     	ldr	d1, [x9], #8
100116e9c:     	ld1r.4h	{ v2 }, [x8], #2
100116ea0:     	smull.4s	v1, v2, v1
100116ea4:     	scvtf.4s	v1, v1
100116ea8:     	fsub.4s	v0, v0, v1
100116eac:     	subs	x10, x10, #2
100116eb0:     	b.ne	0x100116e98 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x34>
100116eb4:     	str	q0, [x3]
100116eb8:     	ret
100116ebc:     	stp	xzr, xzr, [x3]
100116ec0:     	ret

00000001001190e4 <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
1001190e4:     	cbz	x2, 0x1001190ec <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001190e8:     	b	0x1001190f8 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
1001190ec:     	movi.2d	v0, #0000000000000000
1001190f0:     	stp	q0, q0, [x3]
1001190f4:     	ret

00000001001194cc <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
1001194cc:     	cbz	x2, 0x1001194d4 <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001194d0:     	b	0x1001194e0 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
1001194d4:     	movi.2d	v0, #0000000000000000
1001194d8:     	stp	q0, q0, [x3]
1001194dc:     	ret

000000010011b18c <void kernel<short, 4ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10011b18c:     	b	0x10011b190 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010011b28c <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10011b28c:     	cbz	x2, 0x10011b294 <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011b290:     	b	0x10011b2a4 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
10011b294:     	movi.2d	v0, #0000000000000000
10011b298:     	stp	q0, q0, [x3, #32]
10011b29c:     	stp	q0, q0, [x3]
10011b2a0:     	ret

000000010011d528 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
10011d528:     	cbz	x2, 0x10011d530 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10011d52c:     	b	0x10011d53c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
10011d530:     	movi.2d	v0, #0000000000000000
10011d534:     	stp	q0, q0, [x3]
10011d538:     	ret

000000010011d5d4 <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
10011d5d4:     	cbz	x2, 0x10011d5dc <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011d5d8:     	b	0x10011d5e8 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
10011d5dc:     	movi.2d	v0, #0000000000000000
10011d5e0:     	stp	q0, q0, [x3]
10011d5e4:     	ret

000000010011f814 <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10011f814:     	cbz	x2, 0x10011f81c <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10011f818:     	b	0x10011f82c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011f81c:     	movi.2d	v0, #0000000000000000
10011f820:     	stp	q0, q0, [x3, #32]
10011f824:     	stp	q0, q0, [x3]
10011f828:     	ret

000000010011f96c <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10011f96c:     	cbz	x2, 0x10011f974 <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011f970:     	b	0x10011f984 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011f974:     	movi.2d	v0, #0000000000000000
10011f978:     	stp	q0, q0, [x3, #32]
10011f97c:     	stp	q0, q0, [x3]
10011f980:     	ret

00000001001221d0 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
1001221d0:     	cbz	x2, 0x1001221d8 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001221d4:     	b	0x1001221f0 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001221d8:     	movi.2d	v0, #0000000000000000
1001221dc:     	stp	q0, q0, [x3, #96]
1001221e0:     	stp	q0, q0, [x3, #64]
1001221e4:     	stp	q0, q0, [x3, #32]
1001221e8:     	stp	q0, q0, [x3]
1001221ec:     	ret

00000001001223e0 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
1001223e0:     	cbz	x2, 0x1001223e8 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001223e4:     	b	0x100122400 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001223e8:     	movi.2d	v0, #0000000000000000
1001223ec:     	stp	q0, q0, [x3, #96]
1001223f0:     	stp	q0, q0, [x3, #64]
1001223f4:     	stp	q0, q0, [x3, #32]
1001223f8:     	stp	q0, q0, [x3]
1001223fc:     	ret

0000000100124e1c <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100124e1c:     	cbz	x2, 0x100124e24 <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)+0x8>
100124e20:     	b	0x100124e4c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(short const*, short const*, unsigned long, float*)>
100124e24:     	movi.2d	v0, #0000000000000000
100124e28:     	stp	q0, q0, [x3, #224]
100124e2c:     	stp	q0, q0, [x3, #192]
100124e30:     	stp	q0, q0, [x3, #160]
100124e34:     	stp	q0, q0, [x3, #128]
100124e38:     	stp	q0, q0, [x3, #96]
100124e3c:     	stp	q0, q0, [x3, #64]
100124e40:     	stp	q0, q0, [x3, #32]
100124e44:     	stp	q0, q0, [x3]
100124e48:     	ret

0000000100125268 <void kernel<short, 8ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100125268:     	b	0x10012526c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100127694 <void kernel<short, 16ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100127694:     	b	0x100127698 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

0000000100127728 <void kernel<short, 16ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100127728:     	b	0x10012772c <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010012a1c4 <void kernel<short, 16ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10012a1c4:     	b	0x10012a1c8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010012a2e4 <void kernel<short, 16ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10012a2e4:     	b	0x10012a2e8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010012d0f0 <void kernel<short, 16ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10012d0f0:     	b	0x10012d0f4 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010012d320 <void kernel<short, 16ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10012d320:     	b	0x10012d324 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

0000000100130b74 <void kernel<short, 16ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100130b74:     	b	0x100130b78 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100130c64 <void kernel<short, 16ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100130c64:     	b	0x100130c68 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

00000001001345d8 <void kernel<short, 16ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
1001345d8:     	b	0x1001345dc <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010013468c <void kernel<short, 16ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10013468c:     	b	0x100134690 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

0000000100135628 <void kernel<short, 32ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100135628:     	b	0x10013562c <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

00000001001357dc <void kernel<short, 32ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001357dc:     	b	0x1001357e0 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

00000001001371e0 <void kernel<short, 32ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
1001371e0:     	b	0x1001371e4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

0000000100137540 <void kernel<short, 32ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100137540:     	b	0x100137544 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

0000000100139544 <void kernel<short, 32ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
100139544:     	b	0x100139548 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010013974c <void kernel<short, 32ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10013974c:     	b	0x100139750 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010013c1e8 <void kernel<short, 32ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
10013c1e8:     	b	0x10013c1ec <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

000000010013c3b4 <void kernel<short, 32ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
10013c3b4:     	b	0x10013c3b8 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

000000010013eed0 <void kernel<short, 32ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
10013eed0:     	b	0x10013eed4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010013f09c <void kernel<short, 32ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10013f09c:     	b	0x10013f0a0 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

00000001001408e8 <void kernel<short, 32ul, 32ul, false>(short const*, short const*, unsigned long, float*)>:
1001408e8:     	b	0x1001408ec <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100140ab4 <void kernel<short, 32ul, 32ul, true>(short const*, short const*, unsigned long, float*)>:
100140ab4:     	b	0x100140ab8 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100142fec <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>:
100142fec:     	add	x8, x0, x2, lsl #1
100142ff0:     	ands	x9, x2, #0xfffffffffffffff8
100142ff4:     	b.eq	0x10014308c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xa0>
100142ff8:     	add	x11, x0, x9, lsl #1
100142ffc:     	lsl	x9, x2, #1
100143000:     	and	x9, x9, #0xfffffffffffffff0
100143004:     	movi.2d	v0, #0000000000000000
100143008:     	mov	x10, x0
10014300c:     	movi.2d	v1, #0000000000000000
100143010:     	ldr	q2, [x10], #16
100143014:     	ldr	q3, [x1], #16
100143018:     	fcvtl	v4.4s, v2.4h
10014301c:     	fcvtl	v5.4s, v3.4h
100143020:     	fmla.4s	v0, v5, v4
100143024:     	fcvtl2	v2.4s, v2.8h
100143028:     	fcvtl2	v3.4s, v3.8h
10014302c:     	fmla.4s	v1, v3, v2
100143030:     	subs	x9, x9, #16
100143034:     	b.ne	0x100143010 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x24>
100143038:     	sub	x9, x8, x11
10014303c:     	cmp	x9, #7
100143040:     	b.lt	0x100143058 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100143044:     	ldr	d2, [x11], #8
100143048:     	fcvtl	v2.4s, v2.4h
10014304c:     	ldr	d3, [x1], #8
100143050:     	fcvtl	v3.4s, v3.4h
100143054:     	fmla.4s	v0, v3, v2
100143058:     	fadd.4s	v0, v1, v0
10014305c:     	faddp.4s	v0, v0, v0
100143060:     	faddp.2s	s0, v0
100143064:     	cmp	x11, x8
100143068:     	b.eq	0x1001431a8 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014306c:     	add	x9, x0, x2, lsl #1
100143070:     	sub	x9, x9, x11
100143074:     	sub	x9, x9, #2
100143078:     	cmp	x9, #30
10014307c:     	b.hs	0x1001430a8 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xbc>
100143080:     	mov	x9, x11
100143084:     	mov	x10, x1
100143088:     	b	0x10014318c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
10014308c:     	movi.2d	v1, #0000000000000000
100143090:     	movi.2d	v0, #0000000000000000
100143094:     	mov	x11, x0
100143098:     	sub	x9, x8, x0
10014309c:     	cmp	x9, #7
1001430a0:     	b.ge	0x100143044 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x58>
1001430a4:     	b	0x100143058 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
1001430a8:     	lsr	x9, x9, #1
1001430ac:     	add	x12, x9, #1
1001430b0:     	and	x13, x12, #0xfffffffffffffff0
1001430b4:     	lsl	x10, x13, #1
1001430b8:     	add	x9, x11, x10
1001430bc:     	add	x10, x1, x10
1001430c0:     	add	x14, x1, #16
1001430c4:     	add	x11, x11, #16
1001430c8:     	mov	x15, x13
1001430cc:     	ldp	q1, q2, [x11, #-16]
1001430d0:     	fcvtl	v3.4s, v1.4h
1001430d4:     	fcvtl2	v1.4s, v1.8h
1001430d8:     	fcvtl	v4.4s, v2.4h
1001430dc:     	fcvtl2	v2.4s, v2.8h
1001430e0:     	ldp	q5, q6, [x14, #-16]
1001430e4:     	fcvtl	v7.4s, v5.4h
1001430e8:     	fcvtl2	v5.4s, v5.8h
1001430ec:     	fcvtl	v16.4s, v6.4h
1001430f0:     	fcvtl2	v6.4s, v6.8h
1001430f4:     	fmul.4s	v1, v1, v5
1001430f8:     	mov	s5, v1[3]
1001430fc:     	mov	s17, v1[2]
100143100:     	mov	s18, v1[1]
100143104:     	fmul.4s	v3, v3, v7
100143108:     	mov	s7, v3[3]
10014310c:     	mov	s19, v3[2]
100143110:     	mov	s20, v3[1]
100143114:     	fmul.4s	v2, v2, v6
100143118:     	mov	s6, v2[3]
10014311c:     	mov	s21, v2[2]
100143120:     	mov	s22, v2[1]
100143124:     	fmul.4s	v4, v4, v16
100143128:     	mov	s16, v4[3]
10014312c:     	mov	s23, v4[2]
100143130:     	mov	s24, v4[1]
100143134:     	fadd	s0, s0, s3
100143138:     	fadd	s0, s0, s20
10014313c:     	fadd	s0, s0, s19
100143140:     	fadd	s0, s0, s7
100143144:     	fadd	s0, s0, s1
100143148:     	fadd	s0, s0, s18
10014314c:     	fadd	s0, s0, s17
100143150:     	fadd	s0, s0, s5
100143154:     	fadd	s0, s0, s4
100143158:     	fadd	s0, s0, s24
10014315c:     	fadd	s0, s0, s23
100143160:     	fadd	s0, s0, s16
100143164:     	fadd	s0, s0, s2
100143168:     	fadd	s0, s0, s22
10014316c:     	fadd	s0, s0, s21
100143170:     	fadd	s0, s0, s6
100143174:     	add	x14, x14, #32
100143178:     	add	x11, x11, #32
10014317c:     	subs	x15, x15, #16
100143180:     	b.ne	0x1001430cc <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xe0>
100143184:     	cmp	x12, x13
100143188:     	b.eq	0x1001431a8 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014318c:     	ldr	h1, [x9], #2
100143190:     	fcvt	s1, h1
100143194:     	ldr	h2, [x10], #2
100143198:     	fcvt	s2, h2
10014319c:     	fmadd	s0, s1, s2, s0
1001431a0:     	cmp	x9, x8
1001431a4:     	b.ne	0x10014318c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
1001431a8:     	fneg	s0, s0
1001431ac:     	str	s0, [x3]
1001431b0:     	ret
