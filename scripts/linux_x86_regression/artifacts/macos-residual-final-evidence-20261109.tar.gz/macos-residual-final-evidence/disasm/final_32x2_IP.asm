00000001000d18c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d18c8:     	sub	sp, sp, #400
1000d18cc:     	stp	x28, x27, [sp, #304]
1000d18d0:     	stp	x26, x25, [sp, #320]
1000d18d4:     	stp	x24, x23, [sp, #336]
1000d18d8:     	stp	x22, x21, [sp, #352]
1000d18dc:     	stp	x20, x19, [sp, #368]
1000d18e0:     	stp	x29, x30, [sp, #384]
1000d18e4:     	add	x29, sp, #384
1000d18e8:     	str	x3, [sp]
1000d18ec:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x30>
1000d18f0:     	ldr	x8, [x8, #392]
1000d18f4:     	ldr	x8, [x8]
1000d18f8:     	stur	x8, [x29, #-96]
1000d18fc:     	movi.2d	v0, #0000000000000000
1000d1900:     	stp	q0, q0, [sp, #256]
1000d1904:     	stp	q0, q0, [sp, #224]
1000d1908:     	stp	q0, q0, [sp, #192]
1000d190c:     	stp	q0, q0, [sp, #160]
1000d1910:     	stp	q0, q0, [sp, #128]
1000d1914:     	stp	q0, q0, [sp, #96]
1000d1918:     	stp	q0, q0, [sp, #64]
1000d191c:     	stp	q0, q0, [sp, #32]
1000d1920:     	ands	x8, x2, #0xfffffffffffffffe
1000d1924:     	b.eq	0x1000d1aa8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d1928:     	add	x8, x1, x8
1000d192c:     	str	x8, [sp, #8]
1000d1930:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x6c>
1000d1934:     	add	x9, x9, #1980
1000d1938:     	mov	x11, #0
1000d193c:     	ldp	w4, w23, [x1]
1000d1940:     	ubfx	x8, x4, #8, #4
1000d1944:     	stp	x1, x8, [sp, #16]
1000d1948:     	ubfx	x13, x4, #16, #4
1000d194c:     	and	x14, x4, #0xf
1000d1950:     	ubfx	x15, x4, #24, #4
1000d1954:     	ubfx	x16, x4, #4, #4
1000d1958:     	ubfx	x17, x4, #12, #4
1000d195c:     	ubfx	x2, x4, #20, #4
1000d1960:     	lsr	x4, x4, #28
1000d1964:     	and	x5, x23, #0xf
1000d1968:     	ubfx	x6, x23, #8, #4
1000d196c:     	ubfx	x7, x23, #16, #4
1000d1970:     	ubfx	x19, x23, #24, #4
1000d1974:     	ubfx	x20, x23, #4, #4
1000d1978:     	ubfx	x21, x23, #12, #4
1000d197c:     	ubfx	x22, x23, #20, #4
1000d1980:     	lsr	x23, x23, #28
1000d1984:     	ldr	w24, [x0, x11]
1000d1988:     	lsl	w25, w24, #4
1000d198c:     	and	x25, x25, #0xf0
1000d1990:     	add	x25, x9, x25
1000d1994:     	and	x26, x24, #0xf0
1000d1998:     	add	x26, x9, x26
1000d199c:     	lsr	x27, x24, #4
1000d19a0:     	and	x27, x27, #0xf0
1000d19a4:     	add	x27, x9, x27
1000d19a8:     	lsr	x28, x24, #8
1000d19ac:     	and	x28, x28, #0xf0
1000d19b0:     	add	x28, x9, x28
1000d19b4:     	lsr	x30, x24, #12
1000d19b8:     	and	x30, x30, #0xf0
1000d19bc:     	add	x30, x9, x30
1000d19c0:     	lsr	x8, x24, #16
1000d19c4:     	and	x8, x8, #0xf0
1000d19c8:     	add	x8, x9, x8
1000d19cc:     	lsr	x3, x24, #20
1000d19d0:     	and	x3, x3, #0xf0
1000d19d4:     	add	x3, x9, x3
1000d19d8:     	lsr	x24, x24, #24
1000d19dc:     	and	x24, x24, #0xf0
1000d19e0:     	ldrsb	w10, [x25, x14]
1000d19e4:     	ldr	x12, [sp, #24]
1000d19e8:     	ldrsb	w1, [x27, x12]
1000d19ec:     	ldrsb	w12, [x30, x13]
1000d19f0:     	add	w10, w10, w1
1000d19f4:     	add	w10, w10, w12
1000d19f8:     	ldrsb	w12, [x3, x15]
1000d19fc:     	ldrsb	w1, [x26, x16]
1000d1a00:     	add	w10, w10, w12
1000d1a04:     	add	w10, w10, w1
1000d1a08:     	ldrsb	w12, [x28, x17]
1000d1a0c:     	ldrsb	w1, [x8, x2]
1000d1a10:     	add	x24, x9, x24
1000d1a14:     	add	w10, w10, w12
1000d1a18:     	add	w10, w10, w1
1000d1a1c:     	ldrsb	w12, [x24, x4]
1000d1a20:     	add	w10, w10, w12
1000d1a24:     	scvtf	s0, w10
1000d1a28:     	add	x10, sp, #32
1000d1a2c:     	add	x10, x10, x11
1000d1a30:     	ldr	s1, [x10]
1000d1a34:     	ldrsb	w12, [x25, x5]
1000d1a38:     	fadd	s0, s1, s0
1000d1a3c:     	ldrsb	w1, [x27, x6]
1000d1a40:     	ldrsb	w25, [x30, x7]
1000d1a44:     	add	w12, w12, w1
1000d1a48:     	add	w12, w12, w25
1000d1a4c:     	ldrsb	w1, [x3, x19]
1000d1a50:     	ldrsb	w3, [x26, x20]
1000d1a54:     	add	w12, w12, w1
1000d1a58:     	add	w12, w12, w3
1000d1a5c:     	ldrsb	w1, [x28, x21]
1000d1a60:     	ldrsb	w8, [x8, x22]
1000d1a64:     	add	w12, w12, w1
1000d1a68:     	add	w8, w12, w8
1000d1a6c:     	ldrsb	w12, [x24, x23]
1000d1a70:     	add	w8, w8, w12
1000d1a74:     	scvtf	s1, w8
1000d1a78:     	str	s0, [x10]
1000d1a7c:     	ldr	s0, [x10, #128]
1000d1a80:     	fadd	s0, s0, s1
1000d1a84:     	str	s0, [x10, #128]
1000d1a88:     	add	x11, x11, #4
1000d1a8c:     	cmp	x11, #128
1000d1a90:     	b.ne	0x1000d1984 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d1a94:     	add	x0, x0, #128
1000d1a98:     	ldp	x8, x1, [sp, #8]
1000d1a9c:     	add	x1, x1, #8
1000d1aa0:     	cmp	x1, x8
1000d1aa4:     	b.ne	0x1000d1938 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d1aa8:     	ldp	q0, q1, [sp, #224]
1000d1aac:     	ldr	x8, [sp]
1000d1ab0:     	stp	q0, q1, [x8, #192]
1000d1ab4:     	ldp	q0, q1, [sp, #256]
1000d1ab8:     	stp	q0, q1, [x8, #224]
1000d1abc:     	ldp	q0, q1, [sp, #160]
1000d1ac0:     	stp	q0, q1, [x8, #128]
1000d1ac4:     	ldp	q0, q1, [sp, #192]
1000d1ac8:     	stp	q0, q1, [x8, #160]
1000d1acc:     	ldp	q0, q1, [sp, #96]
1000d1ad0:     	stp	q0, q1, [x8, #64]
1000d1ad4:     	ldp	q0, q1, [sp, #128]
1000d1ad8:     	stp	q0, q1, [x8, #96]
1000d1adc:     	ldp	q0, q1, [sp, #32]
1000d1ae0:     	stp	q0, q1, [x8]
1000d1ae4:     	ldp	q0, q1, [sp, #64]
1000d1ae8:     	stp	q0, q1, [x8, #32]
1000d1aec:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x230>
1000d1af0:     	ldr	x8, [x8, #392]
1000d1af4:     	ldr	x8, [x8]
1000d1af8:     	ldur	x9, [x29, #-96]
1000d1afc:     	cmp	x8, x9
1000d1b00:     	b.ne	0x1000d1b24 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d1b04:     	ldp	x29, x30, [sp, #384]
1000d1b08:     	ldp	x20, x19, [sp, #368]
1000d1b0c:     	ldp	x22, x21, [sp, #352]
1000d1b10:     	ldp	x24, x23, [sp, #336]
1000d1b14:     	ldp	x26, x25, [sp, #320]
1000d1b18:     	ldp	x28, x27, [sp, #304]
1000d1b1c:     	add	sp, sp, #400
1000d1b20:     	ret
1000d1b24:     	bl	0x100163694 <_strcmp+0x100163694>

