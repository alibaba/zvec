00000001000c54e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c54e0:     	stp	x28, x27, [sp, #-96]!
1000c54e4:     	stp	x26, x25, [sp, #16]
1000c54e8:     	stp	x24, x23, [sp, #32]
1000c54ec:     	stp	x22, x21, [sp, #48]
1000c54f0:     	stp	x20, x19, [sp, #64]
1000c54f4:     	stp	x29, x30, [sp, #80]
1000c54f8:     	add	x29, sp, #80
1000c54fc:     	sub	sp, sp, #720
1000c5500:     	str	x3, [sp, #8]
1000c5504:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c5508:     	ldr	x8, [x8, #392]
1000c550c:     	ldr	x8, [x8]
1000c5510:     	stur	x8, [x29, #-96]
1000c5514:     	movi.2d	v0, #0000000000000000
1000c5518:     	stp	q0, q0, [sp, #672]
1000c551c:     	lsl	x8, x2, #2
1000c5520:     	stp	q0, q0, [sp, #640]
1000c5524:     	stp	q0, q0, [sp, #608]
1000c5528:     	stp	q0, q0, [sp, #576]
1000c552c:     	stp	q0, q0, [sp, #544]
1000c5530:     	stp	q0, q0, [sp, #512]
1000c5534:     	stp	q0, q0, [sp, #480]
1000c5538:     	stp	q0, q0, [sp, #448]
1000c553c:     	ands	x8, x8, #0xfffffffffffffff8
1000c5540:     	b.eq	0x1000c5a8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c5544:     	add	x8, x1, x8
1000c5548:     	str	x8, [sp, #16]
1000c554c:     	add	x8, sp, #448
1000c5550:     	add	x19, x8, #128
1000c5554:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000c5558:     	add	x11, x11, #956
1000c555c:     	mov	x12, #0
1000c5560:     	ldp	w8, w9, [x1]
1000c5564:     	ubfx	x10, x8, #8, #4
1000c5568:     	str	x10, [sp, #440]
1000c556c:     	ubfx	x10, x8, #16, #4
1000c5570:     	str	x10, [sp, #432]
1000c5574:     	ubfx	x10, x8, #24, #4
1000c5578:     	str	x10, [sp, #424]
1000c557c:     	ldp	w10, w13, [x1, #8]
1000c5580:     	and	x15, x8, #0xf
1000c5584:     	ubfx	x14, x8, #4, #4
1000c5588:     	stp	x14, x15, [sp, #408]
1000c558c:     	ubfx	x15, x8, #12, #4
1000c5590:     	ubfx	x14, x8, #20, #4
1000c5594:     	stp	x14, x15, [sp, #392]
1000c5598:     	lsr	x8, x8, #28
1000c559c:     	str	x8, [sp, #384]
1000c55a0:     	and	x8, x9, #0xf
1000c55a4:     	str	x8, [sp, #376]
1000c55a8:     	ubfx	x8, x9, #8, #4
1000c55ac:     	str	x8, [sp, #368]
1000c55b0:     	ubfx	x8, x9, #16, #4
1000c55b4:     	str	x8, [sp, #360]
1000c55b8:     	ubfx	x8, x9, #24, #4
1000c55bc:     	str	x8, [sp, #352]
1000c55c0:     	ubfx	x8, x9, #4, #4
1000c55c4:     	str	x8, [sp, #344]
1000c55c8:     	ubfx	x8, x9, #12, #4
1000c55cc:     	str	x8, [sp, #336]
1000c55d0:     	ubfx	x8, x9, #20, #4
1000c55d4:     	str	x8, [sp, #328]
1000c55d8:     	lsr	x8, x9, #28
1000c55dc:     	str	x8, [sp, #320]
1000c55e0:     	and	x9, x10, #0xf
1000c55e4:     	ubfx	x8, x10, #8, #4
1000c55e8:     	stp	x8, x9, [sp, #304]
1000c55ec:     	ubfx	x9, x10, #16, #4
1000c55f0:     	ubfx	x8, x10, #24, #4
1000c55f4:     	stp	x8, x9, [sp, #288]
1000c55f8:     	ubfx	x9, x10, #4, #4
1000c55fc:     	ubfx	x8, x10, #12, #4
1000c5600:     	stp	x8, x9, [sp, #272]
1000c5604:     	ubfx	x9, x10, #20, #4
1000c5608:     	lsr	x8, x10, #28
1000c560c:     	stp	x8, x9, [sp, #256]
1000c5610:     	and	x9, x13, #0xf
1000c5614:     	ubfx	x8, x13, #8, #4
1000c5618:     	stp	x8, x9, [sp, #240]
1000c561c:     	ubfx	x9, x13, #16, #4
1000c5620:     	ubfx	x8, x13, #24, #4
1000c5624:     	stp	x8, x9, [sp, #224]
1000c5628:     	ubfx	x9, x13, #4, #4
1000c562c:     	ubfx	x8, x13, #12, #4
1000c5630:     	stp	x8, x9, [sp, #208]
1000c5634:     	ubfx	x9, x13, #20, #4
1000c5638:     	lsr	x8, x13, #28
1000c563c:     	stp	x8, x9, [sp, #192]
1000c5640:     	ldp	w8, w9, [x1, #16]
1000c5644:     	and	x10, x8, #0xf
1000c5648:     	str	x10, [sp, #184]
1000c564c:     	ubfx	x10, x8, #8, #4
1000c5650:     	str	x10, [sp, #176]
1000c5654:     	ubfx	x10, x8, #16, #4
1000c5658:     	str	x10, [sp, #168]
1000c565c:     	ubfx	x10, x8, #24, #4
1000c5660:     	str	x10, [sp, #160]
1000c5664:     	ubfx	x10, x8, #4, #4
1000c5668:     	str	x10, [sp, #152]
1000c566c:     	ubfx	x10, x8, #12, #4
1000c5670:     	str	x10, [sp, #144]
1000c5674:     	ubfx	x10, x8, #20, #4
1000c5678:     	lsr	x8, x8, #28
1000c567c:     	stp	x8, x10, [sp, #128]
1000c5680:     	and	x10, x9, #0xf
1000c5684:     	ubfx	x8, x9, #8, #4
1000c5688:     	stp	x8, x10, [sp, #112]
1000c568c:     	ubfx	x10, x9, #16, #4
1000c5690:     	ubfx	x8, x9, #24, #4
1000c5694:     	stp	x8, x10, [sp, #96]
1000c5698:     	ubfx	x10, x9, #4, #4
1000c569c:     	ubfx	x8, x9, #12, #4
1000c56a0:     	stp	x8, x10, [sp, #80]
1000c56a4:     	ubfx	x10, x9, #20, #4
1000c56a8:     	lsr	x8, x9, #28
1000c56ac:     	stp	x8, x10, [sp, #64]
1000c56b0:     	ldp	w14, w7, [x1, #24]
1000c56b4:     	and	x9, x14, #0xf
1000c56b8:     	ubfx	x8, x14, #8, #4
1000c56bc:     	stp	x8, x9, [sp, #48]
1000c56c0:     	ubfx	x8, x14, #16, #4
1000c56c4:     	str	x8, [sp, #40]
1000c56c8:     	ubfx	x8, x14, #24, #4
1000c56cc:     	stp	x1, x8, [sp, #24]
1000c56d0:     	ubfx	x10, x14, #4, #4
1000c56d4:     	ubfx	x13, x14, #12, #4
1000c56d8:     	ubfx	x9, x14, #20, #4
1000c56dc:     	lsr	x14, x14, #28
1000c56e0:     	and	x15, x7, #0xf
1000c56e4:     	ubfx	x16, x7, #8, #4
1000c56e8:     	ubfx	x17, x7, #16, #4
1000c56ec:     	ubfx	x2, x7, #24, #4
1000c56f0:     	ubfx	x4, x7, #4, #4
1000c56f4:     	ubfx	x5, x7, #12, #4
1000c56f8:     	ubfx	x6, x7, #20, #4
1000c56fc:     	lsr	x7, x7, #28
1000c5700:     	ldr	w26, [x0, x12]
1000c5704:     	mov	x1, x19
1000c5708:     	lsl	w19, w26, #4
1000c570c:     	and	x19, x19, #0xf0
1000c5710:     	add	x19, x11, x19
1000c5714:     	ldr	x8, [sp, #416]
1000c5718:     	ldrsb	w25, [x19, x8]
1000c571c:     	lsr	x20, x26, #4
1000c5720:     	and	x20, x20, #0xf0
1000c5724:     	add	x20, x11, x20
1000c5728:     	ldr	x8, [sp, #440]
1000c572c:     	ldrsb	w27, [x20, x8]
1000c5730:     	lsr	x21, x26, #12
1000c5734:     	and	x21, x21, #0xf0
1000c5738:     	add	x21, x11, x21
1000c573c:     	ldr	x8, [sp, #432]
1000c5740:     	ldrsb	w28, [x21, x8]
1000c5744:     	lsr	x22, x26, #20
1000c5748:     	and	x22, x22, #0xf0
1000c574c:     	add	x23, x11, x22
1000c5750:     	ldr	x8, [sp, #424]
1000c5754:     	ldrsb	w30, [x23, x8]
1000c5758:     	and	x22, x26, #0xf0
1000c575c:     	add	x22, x11, x22
1000c5760:     	ldp	x3, x8, [sp, #400]
1000c5764:     	ldrsb	w8, [x22, x8]
1000c5768:     	lsr	x24, x26, #8
1000c576c:     	and	x24, x24, #0xf0
1000c5770:     	add	x24, x11, x24
1000c5774:     	ldrsb	w3, [x24, x3]
1000c5778:     	add	w27, w25, w27
1000c577c:     	lsr	x25, x26, #16
1000c5780:     	and	x25, x25, #0xf0
1000c5784:     	add	x25, x11, x25
1000c5788:     	add	w27, w27, w28
1000c578c:     	ldr	x28, [sp, #392]
1000c5790:     	ldrsb	w28, [x25, x28]
1000c5794:     	lsr	x26, x26, #24
1000c5798:     	and	x26, x26, #0xf0
1000c579c:     	add	x26, x11, x26
1000c57a0:     	add	w27, w27, w30
1000c57a4:     	ldr	x30, [sp, #384]
1000c57a8:     	ldrsb	w30, [x26, x30]
1000c57ac:     	add	w8, w27, w8
1000c57b0:     	add	w8, w8, w3
1000c57b4:     	add	w8, w8, w28
1000c57b8:     	add	w8, w8, w30
1000c57bc:     	scvtf	s0, w8
1000c57c0:     	ldp	x3, x8, [sp, #368]
1000c57c4:     	ldrsb	w8, [x19, x8]
1000c57c8:     	ldrsb	w3, [x20, x3]
1000c57cc:     	ldp	x28, x27, [sp, #352]
1000c57d0:     	ldrsb	w27, [x21, x27]
1000c57d4:     	ldrsb	w28, [x23, x28]
1000c57d8:     	ldr	x30, [sp, #344]
1000c57dc:     	ldrsb	w30, [x22, x30]
1000c57e0:     	add	w8, w8, w3
1000c57e4:     	ldr	x3, [sp, #336]
1000c57e8:     	ldrsb	w3, [x24, x3]
1000c57ec:     	add	w8, w8, w27
1000c57f0:     	ldr	x27, [sp, #328]
1000c57f4:     	ldrsb	w27, [x25, x27]
1000c57f8:     	add	w8, w8, w28
1000c57fc:     	ldr	x28, [sp, #320]
1000c5800:     	ldrsb	w28, [x26, x28]
1000c5804:     	add	w8, w8, w30
1000c5808:     	add	w8, w8, w3
1000c580c:     	add	w8, w8, w27
1000c5810:     	add	w8, w8, w28
1000c5814:     	scvtf	s1, w8
1000c5818:     	ldp	x3, x8, [sp, #304]
1000c581c:     	ldrsb	w8, [x19, x8]
1000c5820:     	ldrsb	w3, [x20, x3]
1000c5824:     	ldp	x28, x27, [sp, #288]
1000c5828:     	ldrsb	w27, [x21, x27]
1000c582c:     	ldrsb	w28, [x23, x28]
1000c5830:     	add	w8, w8, w3
1000c5834:     	ldr	x3, [sp, #280]
1000c5838:     	ldrsb	w3, [x22, x3]
1000c583c:     	add	w8, w8, w27
1000c5840:     	ldr	x27, [sp, #272]
1000c5844:     	ldrsb	w27, [x24, x27]
1000c5848:     	add	w8, w8, w28
1000c584c:     	ldr	x28, [sp, #264]
1000c5850:     	ldrsb	w28, [x25, x28]
1000c5854:     	add	w8, w8, w3
1000c5858:     	ldr	x3, [sp, #256]
1000c585c:     	ldrsb	w3, [x26, x3]
1000c5860:     	add	w8, w8, w27
1000c5864:     	add	w8, w8, w28
1000c5868:     	add	w8, w8, w3
1000c586c:     	scvtf	s2, w8
1000c5870:     	ldp	x3, x8, [sp, #240]
1000c5874:     	ldrsb	w8, [x19, x8]
1000c5878:     	ldrsb	w3, [x20, x3]
1000c587c:     	ldp	x28, x27, [sp, #224]
1000c5880:     	ldrsb	w27, [x21, x27]
1000c5884:     	ldrsb	w28, [x23, x28]
1000c5888:     	add	w8, w8, w3
1000c588c:     	ldr	x3, [sp, #216]
1000c5890:     	ldrsb	w3, [x22, x3]
1000c5894:     	add	w8, w8, w27
1000c5898:     	ldr	x27, [sp, #208]
1000c589c:     	ldrsb	w27, [x24, x27]
1000c58a0:     	add	w8, w8, w28
1000c58a4:     	ldr	x28, [sp, #200]
1000c58a8:     	ldrsb	w28, [x25, x28]
1000c58ac:     	add	w8, w8, w3
1000c58b0:     	ldr	x3, [sp, #192]
1000c58b4:     	ldrsb	w3, [x26, x3]
1000c58b8:     	add	w8, w8, w27
1000c58bc:     	add	w8, w8, w28
1000c58c0:     	add	w8, w8, w3
1000c58c4:     	scvtf	s3, w8
1000c58c8:     	ldp	x3, x8, [sp, #176]
1000c58cc:     	ldrsb	w8, [x19, x8]
1000c58d0:     	ldrsb	w3, [x20, x3]
1000c58d4:     	ldp	x28, x27, [sp, #160]
1000c58d8:     	ldrsb	w27, [x21, x27]
1000c58dc:     	ldrsb	w28, [x23, x28]
1000c58e0:     	add	w8, w8, w3
1000c58e4:     	add	w8, w8, w27
1000c58e8:     	ldr	x3, [sp, #152]
1000c58ec:     	ldrsb	w3, [x22, x3]
1000c58f0:     	add	w8, w8, w28
1000c58f4:     	add	w8, w8, w3
1000c58f8:     	ldp	x27, x3, [sp, #136]
1000c58fc:     	ldrsb	w3, [x24, x3]
1000c5900:     	ldrsb	w27, [x25, x27]
1000c5904:     	add	w8, w8, w3
1000c5908:     	add	w8, w8, w27
1000c590c:     	ldr	x3, [sp, #128]
1000c5910:     	ldrsb	w3, [x26, x3]
1000c5914:     	add	w8, w8, w3
1000c5918:     	scvtf	s4, w8
1000c591c:     	ldp	x3, x8, [sp, #112]
1000c5920:     	ldrsb	w8, [x19, x8]
1000c5924:     	ldrsb	w3, [x20, x3]
1000c5928:     	ldp	x28, x27, [sp, #96]
1000c592c:     	ldrsb	w27, [x21, x27]
1000c5930:     	ldrsb	w28, [x23, x28]
1000c5934:     	add	w8, w8, w3
1000c5938:     	ldr	x3, [sp, #88]
1000c593c:     	ldrsb	w3, [x22, x3]
1000c5940:     	add	w8, w8, w27
1000c5944:     	ldr	x27, [sp, #80]
1000c5948:     	ldrsb	w27, [x24, x27]
1000c594c:     	add	w8, w8, w28
1000c5950:     	ldr	x28, [sp, #72]
1000c5954:     	ldrsb	w28, [x25, x28]
1000c5958:     	add	w8, w8, w3
1000c595c:     	add	w8, w8, w27
1000c5960:     	add	w8, w8, w28
1000c5964:     	ldr	x3, [sp, #64]
1000c5968:     	ldrsb	w3, [x26, x3]
1000c596c:     	add	w8, w8, w3
1000c5970:     	scvtf	s5, w8
1000c5974:     	ldp	x3, x8, [sp, #48]
1000c5978:     	ldrsb	w8, [x19, x8]
1000c597c:     	ldrsb	w3, [x20, x3]
1000c5980:     	ldr	x27, [sp, #40]
1000c5984:     	ldrsb	w27, [x21, x27]
1000c5988:     	add	w8, w8, w3
1000c598c:     	ldr	x3, [sp, #32]
1000c5990:     	ldrsb	w3, [x23, x3]
1000c5994:     	add	w8, w8, w27
1000c5998:     	ldrsb	w27, [x22, x10]
1000c599c:     	add	w8, w8, w3
1000c59a0:     	ldrsb	w3, [x24, x13]
1000c59a4:     	add	w8, w8, w27
1000c59a8:     	ldrsb	w27, [x25, x9]
1000c59ac:     	add	w8, w8, w3
1000c59b0:     	ldrsb	w3, [x26, x14]
1000c59b4:     	add	w8, w8, w27
1000c59b8:     	add	w8, w8, w3
1000c59bc:     	scvtf	s6, w8
1000c59c0:     	ldrsb	w8, [x19, x15]
1000c59c4:     	ldrsb	w3, [x20, x16]
1000c59c8:     	ldrsb	w19, [x21, x17]
1000c59cc:     	add	w8, w8, w3
1000c59d0:     	add	w8, w8, w19
1000c59d4:     	ldrsb	w3, [x23, x2]
1000c59d8:     	ldrsb	w19, [x22, x4]
1000c59dc:     	add	w8, w8, w3
1000c59e0:     	add	w8, w8, w19
1000c59e4:     	ldrsb	w3, [x24, x5]
1000c59e8:     	ldrsb	w19, [x25, x6]
1000c59ec:     	add	w8, w8, w3
1000c59f0:     	add	w8, w8, w19
1000c59f4:     	mov	x19, x1
1000c59f8:     	ldrsb	w3, [x26, x7]
1000c59fc:     	add	w8, w8, w3
1000c5a00:     	add	x3, sp, #448
1000c5a04:     	scvtf	s7, w8
1000c5a08:     	add	x8, x1, x12
1000c5a0c:     	ldur	s16, [x8, #-96]
1000c5a10:     	fadd	s1, s16, s1
1000c5a14:     	stur	s1, [x8, #-96]
1000c5a18:     	ldur	s1, [x8, #-64]
1000c5a1c:     	fadd	s1, s1, s2
1000c5a20:     	stur	s1, [x8, #-64]
1000c5a24:     	ldur	s1, [x8, #-32]
1000c5a28:     	fadd	s1, s1, s3
1000c5a2c:     	stur	s1, [x8, #-32]
1000c5a30:     	ldr	s1, [x8]
1000c5a34:     	fadd	s1, s1, s4
1000c5a38:     	str	s1, [x8]
1000c5a3c:     	ldr	s1, [x8, #32]
1000c5a40:     	fadd	s1, s1, s5
1000c5a44:     	str	s1, [x8, #32]
1000c5a48:     	ldr	s1, [x8, #64]
1000c5a4c:     	fadd	s1, s1, s6
1000c5a50:     	str	s1, [x8, #64]
1000c5a54:     	ldr	s1, [x8, #96]
1000c5a58:     	fadd	s1, s1, s7
1000c5a5c:     	ldr	s2, [x3, x12]
1000c5a60:     	str	s1, [x8, #96]
1000c5a64:     	fadd	s0, s2, s0
1000c5a68:     	str	s0, [x3, x12]
1000c5a6c:     	add	x12, x12, #4
1000c5a70:     	cmp	x12, #32
1000c5a74:     	b.ne	0x1000c5700 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c5a78:     	add	x0, x0, #32
1000c5a7c:     	ldp	x8, x1, [sp, #16]
1000c5a80:     	add	x1, x1, #32
1000c5a84:     	cmp	x1, x8
1000c5a88:     	b.ne	0x1000c555c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c5a8c:     	ldp	q0, q1, [sp, #640]
1000c5a90:     	ldr	x8, [sp, #8]
1000c5a94:     	stp	q0, q1, [x8, #192]
1000c5a98:     	ldp	q0, q1, [sp, #672]
1000c5a9c:     	stp	q0, q1, [x8, #224]
1000c5aa0:     	ldp	q0, q1, [sp, #576]
1000c5aa4:     	stp	q0, q1, [x8, #128]
1000c5aa8:     	ldp	q0, q1, [sp, #608]
1000c5aac:     	stp	q0, q1, [x8, #160]
1000c5ab0:     	ldp	q0, q1, [sp, #512]
1000c5ab4:     	stp	q0, q1, [x8, #64]
1000c5ab8:     	ldp	q0, q1, [sp, #544]
1000c5abc:     	stp	q0, q1, [x8, #96]
1000c5ac0:     	ldp	q0, q1, [sp, #448]
1000c5ac4:     	stp	q0, q1, [x8]
1000c5ac8:     	ldp	q0, q1, [sp, #480]
1000c5acc:     	stp	q0, q1, [x8, #32]
1000c5ad0:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x260>
1000c5ad4:     	ldr	x8, [x8, #392]
1000c5ad8:     	ldr	x8, [x8]
1000c5adc:     	ldur	x9, [x29, #-96]
1000c5ae0:     	cmp	x8, x9
1000c5ae4:     	b.ne	0x1000c5b08 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c5ae8:     	add	sp, sp, #720
1000c5aec:     	ldp	x29, x30, [sp, #80]
1000c5af0:     	ldp	x20, x19, [sp, #64]
1000c5af4:     	ldp	x22, x21, [sp, #48]
1000c5af8:     	ldp	x24, x23, [sp, #32]
1000c5afc:     	ldp	x26, x25, [sp, #16]
1000c5b00:     	ldp	x28, x27, [sp], #96
1000c5b04:     	ret
1000c5b08:     	bl	0x100163694 <_strcmp+0x100163694>

