00000001000d159c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d159c:     	sub	sp, sp, #400
1000d15a0:     	stp	x28, x27, [sp, #304]
1000d15a4:     	stp	x26, x25, [sp, #320]
1000d15a8:     	stp	x24, x23, [sp, #336]
1000d15ac:     	stp	x22, x21, [sp, #352]
1000d15b0:     	stp	x20, x19, [sp, #368]
1000d15b4:     	stp	x29, x30, [sp, #384]
1000d15b8:     	add	x29, sp, #384
1000d15bc:     	str	x3, [sp]
1000d15c0:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30>
1000d15c4:     	ldr	x8, [x8, #392]
1000d15c8:     	ldr	x8, [x8]
1000d15cc:     	stur	x8, [x29, #-96]
1000d15d0:     	movi.2d	v0, #0000000000000000
1000d15d4:     	stp	q0, q0, [sp, #256]
1000d15d8:     	stp	q0, q0, [sp, #224]
1000d15dc:     	stp	q0, q0, [sp, #192]
1000d15e0:     	stp	q0, q0, [sp, #160]
1000d15e4:     	stp	q0, q0, [sp, #128]
1000d15e8:     	stp	q0, q0, [sp, #96]
1000d15ec:     	stp	q0, q0, [sp, #64]
1000d15f0:     	stp	q0, q0, [sp, #32]
1000d15f4:     	ands	x8, x2, #0xfffffffffffffffe
1000d15f8:     	b.eq	0x1000d177c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d15fc:     	add	x8, x1, x8
1000d1600:     	str	x8, [sp, #8]
1000d1604:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d1608:     	add	x9, x9, #1724
1000d160c:     	mov	x11, #0
1000d1610:     	ldp	w4, w23, [x1]
1000d1614:     	ubfx	x8, x4, #8, #4
1000d1618:     	stp	x1, x8, [sp, #16]
1000d161c:     	ubfx	x13, x4, #16, #4
1000d1620:     	and	x14, x4, #0xf
1000d1624:     	ubfx	x15, x4, #24, #4
1000d1628:     	ubfx	x16, x4, #4, #4
1000d162c:     	ubfx	x17, x4, #12, #4
1000d1630:     	ubfx	x2, x4, #20, #4
1000d1634:     	lsr	x4, x4, #28
1000d1638:     	and	x5, x23, #0xf
1000d163c:     	ubfx	x6, x23, #8, #4
1000d1640:     	ubfx	x7, x23, #16, #4
1000d1644:     	ubfx	x19, x23, #24, #4
1000d1648:     	ubfx	x20, x23, #4, #4
1000d164c:     	ubfx	x21, x23, #12, #4
1000d1650:     	ubfx	x22, x23, #20, #4
1000d1654:     	lsr	x23, x23, #28
1000d1658:     	ldr	w24, [x0, x11]
1000d165c:     	lsl	w25, w24, #4
1000d1660:     	and	x25, x25, #0xf0
1000d1664:     	add	x25, x9, x25
1000d1668:     	and	x26, x24, #0xf0
1000d166c:     	add	x26, x9, x26
1000d1670:     	lsr	x27, x24, #4
1000d1674:     	and	x27, x27, #0xf0
1000d1678:     	add	x27, x9, x27
1000d167c:     	lsr	x28, x24, #8
1000d1680:     	and	x28, x28, #0xf0
1000d1684:     	add	x28, x9, x28
1000d1688:     	lsr	x30, x24, #12
1000d168c:     	and	x30, x30, #0xf0
1000d1690:     	add	x30, x9, x30
1000d1694:     	lsr	x8, x24, #16
1000d1698:     	and	x8, x8, #0xf0
1000d169c:     	add	x8, x9, x8
1000d16a0:     	lsr	x3, x24, #20
1000d16a4:     	and	x3, x3, #0xf0
1000d16a8:     	add	x3, x9, x3
1000d16ac:     	lsr	x24, x24, #24
1000d16b0:     	and	x24, x24, #0xf0
1000d16b4:     	ldrb	w10, [x25, x14]
1000d16b8:     	ldr	x12, [sp, #24]
1000d16bc:     	ldrb	w1, [x27, x12]
1000d16c0:     	ldrb	w12, [x30, x13]
1000d16c4:     	add	w10, w10, w1
1000d16c8:     	add	w10, w10, w12
1000d16cc:     	ldrb	w12, [x3, x15]
1000d16d0:     	ldrb	w1, [x26, x16]
1000d16d4:     	add	w10, w10, w12
1000d16d8:     	add	w10, w10, w1
1000d16dc:     	ldrb	w12, [x28, x17]
1000d16e0:     	ldrb	w1, [x8, x2]
1000d16e4:     	add	x24, x9, x24
1000d16e8:     	add	w10, w10, w12
1000d16ec:     	add	w10, w10, w1
1000d16f0:     	ldrb	w12, [x24, x4]
1000d16f4:     	add	w10, w10, w12
1000d16f8:     	scvtf	s0, w10
1000d16fc:     	add	x10, sp, #32
1000d1700:     	add	x10, x10, x11
1000d1704:     	ldr	s1, [x10]
1000d1708:     	ldrb	w12, [x25, x5]
1000d170c:     	fadd	s0, s1, s0
1000d1710:     	ldrb	w1, [x27, x6]
1000d1714:     	ldrb	w25, [x30, x7]
1000d1718:     	add	w12, w12, w1
1000d171c:     	add	w12, w12, w25
1000d1720:     	ldrb	w1, [x3, x19]
1000d1724:     	ldrb	w3, [x26, x20]
1000d1728:     	add	w12, w12, w1
1000d172c:     	add	w12, w12, w3
1000d1730:     	ldrb	w1, [x28, x21]
1000d1734:     	ldrb	w8, [x8, x22]
1000d1738:     	add	w12, w12, w1
1000d173c:     	add	w8, w12, w8
1000d1740:     	ldrb	w12, [x24, x23]
1000d1744:     	add	w8, w8, w12
1000d1748:     	scvtf	s1, w8
1000d174c:     	str	s0, [x10]
1000d1750:     	ldr	s0, [x10, #128]
1000d1754:     	fadd	s0, s0, s1
1000d1758:     	str	s0, [x10, #128]
1000d175c:     	add	x11, x11, #4
1000d1760:     	cmp	x11, #128
1000d1764:     	b.ne	0x1000d1658 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d1768:     	add	x0, x0, #128
1000d176c:     	ldp	x8, x1, [sp, #8]
1000d1770:     	add	x1, x1, #8
1000d1774:     	cmp	x1, x8
1000d1778:     	b.ne	0x1000d160c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d177c:     	ldp	q0, q1, [sp, #224]
1000d1780:     	ldr	x8, [sp]
1000d1784:     	stp	q0, q1, [x8, #192]
1000d1788:     	ldp	q0, q1, [sp, #256]
1000d178c:     	stp	q0, q1, [x8, #224]
1000d1790:     	ldp	q0, q1, [sp, #160]
1000d1794:     	stp	q0, q1, [x8, #128]
1000d1798:     	ldp	q0, q1, [sp, #192]
1000d179c:     	stp	q0, q1, [x8, #160]
1000d17a0:     	ldp	q0, q1, [sp, #96]
1000d17a4:     	stp	q0, q1, [x8, #64]
1000d17a8:     	ldp	q0, q1, [sp, #128]
1000d17ac:     	stp	q0, q1, [x8, #96]
1000d17b0:     	ldp	q0, q1, [sp, #32]
1000d17b4:     	stp	q0, q1, [x8]
1000d17b8:     	ldp	q0, q1, [sp, #64]
1000d17bc:     	stp	q0, q1, [x8, #32]
1000d17c0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x164>
1000d17c4:     	ldr	x8, [x8, #392]
1000d17c8:     	ldr	x8, [x8]
1000d17cc:     	ldur	x9, [x29, #-96]
1000d17d0:     	cmp	x8, x9
1000d17d4:     	b.ne	0x1000d17f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d17d8:     	ldp	x29, x30, [sp, #384]
1000d17dc:     	ldp	x20, x19, [sp, #368]
1000d17e0:     	ldp	x22, x21, [sp, #352]
1000d17e4:     	ldp	x24, x23, [sp, #336]
1000d17e8:     	ldp	x26, x25, [sp, #320]
1000d17ec:     	ldp	x28, x27, [sp, #304]
1000d17f0:     	add	sp, sp, #400
1000d17f4:     	ret
1000d17f8:     	bl	0x100163694 <_strcmp+0x100163694>

