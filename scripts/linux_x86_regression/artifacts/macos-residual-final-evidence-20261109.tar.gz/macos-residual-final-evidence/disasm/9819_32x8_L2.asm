00000001000d2674 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d2674:     	stp	x28, x27, [sp, #-64]!
1000d2678:     	stp	x22, x21, [sp, #16]
1000d267c:     	stp	x20, x19, [sp, #32]
1000d2680:     	stp	x29, x30, [sp, #48]
1000d2684:     	add	x29, sp, #48
1000d2688:     	sub	sp, sp, #1040
1000d268c:     	mov	x19, x3
1000d2690:     	mov	x20, x1
1000d2694:     	mov	x21, x0
1000d2698:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd4>
1000d269c:     	ldr	x8, [x8, #392]
1000d26a0:     	ldr	x8, [x8]
1000d26a4:     	stur	x8, [x29, #-56]
1000d26a8:     	lsl	x8, x2, #2
1000d26ac:     	and	x22, x8, #0xfffffffffffffff8
1000d26b0:     	add	x0, sp, #8
1000d26b4:     	mov	w1, #1024
1000d26b8:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d26bc:     	cbz	x22, 0x1000d27d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d26c0:     	add	x8, x20, x22
1000d26c4:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf8>
1000d26c8:     	add	x9, x9, #1756
1000d26cc:     	mov	x10, #0
1000d26d0:     	add	x11, sp, #8
1000d26d4:     	mov	x12, #0
1000d26d8:     	ldr	w2, [x21, x10, lsl #2]
1000d26dc:     	lsl	w13, w2, #4
1000d26e0:     	and	x13, x13, #0xf0
1000d26e4:     	and	x14, x2, #0xf0
1000d26e8:     	lsr	x15, x2, #4
1000d26ec:     	and	x15, x15, #0xf0
1000d26f0:     	lsr	x16, x2, #8
1000d26f4:     	and	x16, x16, #0xf0
1000d26f8:     	lsr	x17, x2, #12
1000d26fc:     	and	x17, x17, #0xf0
1000d2700:     	lsr	x0, x2, #16
1000d2704:     	and	x0, x0, #0xf0
1000d2708:     	lsr	x1, x2, #20
1000d270c:     	and	x1, x1, #0xf0
1000d2710:     	lsr	x2, x2, #24
1000d2714:     	and	x2, x2, #0xf0
1000d2718:     	mov	x3, x11
1000d271c:     	ldr	w4, [x20, x12]
1000d2720:     	and	x5, x4, #0xf
1000d2724:     	orr	x5, x13, x5
1000d2728:     	ldrb	w5, [x9, x5]
1000d272c:     	ubfx	x6, x4, #4, #4
1000d2730:     	orr	x6, x14, x6
1000d2734:     	ldrb	w6, [x9, x6]
1000d2738:     	ubfx	x7, x4, #8, #4
1000d273c:     	orr	x7, x15, x7
1000d2740:     	ldrb	w7, [x9, x7]
1000d2744:     	add	w5, w5, w6
1000d2748:     	add	w5, w5, w7
1000d274c:     	ubfx	x6, x4, #12, #4
1000d2750:     	orr	x6, x16, x6
1000d2754:     	ldrb	w6, [x9, x6]
1000d2758:     	ubfx	x7, x4, #16, #4
1000d275c:     	orr	x7, x17, x7
1000d2760:     	ldrb	w7, [x9, x7]
1000d2764:     	add	w5, w5, w6
1000d2768:     	add	w5, w5, w7
1000d276c:     	ubfx	x6, x4, #20, #4
1000d2770:     	orr	x6, x0, x6
1000d2774:     	ldrb	w6, [x9, x6]
1000d2778:     	ubfx	x7, x4, #24, #4
1000d277c:     	orr	x7, x1, x7
1000d2780:     	ldrb	w7, [x9, x7]
1000d2784:     	add	w5, w5, w6
1000d2788:     	add	w5, w5, w7
1000d278c:     	orr	x4, x2, x4, lsr #28
1000d2790:     	ldrb	w4, [x9, x4]
1000d2794:     	add	w4, w5, w4
1000d2798:     	scvtf	s0, w4
1000d279c:     	ldr	s1, [x3]
1000d27a0:     	fadd	s0, s1, s0
1000d27a4:     	str	s0, [x3], #128
1000d27a8:     	add	x12, x12, #4
1000d27ac:     	cmp	x12, #32
1000d27b0:     	b.ne	0x1000d271c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d27b4:     	add	x10, x10, #1
1000d27b8:     	add	x11, x11, #4
1000d27bc:     	cmp	x10, #32
1000d27c0:     	b.ne	0x1000d26d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d27c4:     	add	x21, x21, #128
1000d27c8:     	add	x20, x20, #32
1000d27cc:     	cmp	x20, x8
1000d27d0:     	b.ne	0x1000d26cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d27d4:     	add	x1, sp, #8
1000d27d8:     	mov	x0, x19
1000d27dc:     	mov	w2, #1024
1000d27e0:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d27e4:     	ldur	x8, [x29, #-56]
1000d27e8:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb4>
1000d27ec:     	ldr	x9, [x9, #392]
1000d27f0:     	ldr	x9, [x9]
1000d27f4:     	cmp	x9, x8
1000d27f8:     	b.ne	0x1000d2814 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d27fc:     	add	sp, sp, #1040
1000d2800:     	ldp	x29, x30, [sp, #48]
1000d2804:     	ldp	x20, x19, [sp, #32]
1000d2808:     	ldp	x22, x21, [sp, #16]
1000d280c:     	ldp	x28, x27, [sp], #64
1000d2810:     	ret
1000d2814:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

