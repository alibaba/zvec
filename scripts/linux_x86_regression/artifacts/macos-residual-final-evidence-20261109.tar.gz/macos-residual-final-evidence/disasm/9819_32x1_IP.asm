00000001000ccb44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000ccb44:     	stp	x22, x21, [sp, #-32]!
1000ccb48:     	stp	x20, x19, [sp, #16]
1000ccb4c:     	movi.2d	v0, #0000000000000000
1000ccb50:     	stp	q0, q0, [x3, #96]
1000ccb54:     	stp	q0, q0, [x3, #64]
1000ccb58:     	stp	q0, q0, [x3, #32]
1000ccb5c:     	stp	q0, q0, [x3]
1000ccb60:     	cmp	x2, #8
1000ccb64:     	b.hs	0x1000ccb70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000ccb68:     	mov	x8, #0
1000ccb6c:     	b	0x1000ccc80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000ccb70:     	mov	x8, #0
1000ccb74:     	mov	w14, #8
1000ccb78:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 2ul, false>(char const*)+0xc4>
1000ccb7c:     	add	x9, x9, #2012
1000ccb80:     	mov	x10, x0
1000ccb84:     	mov	x11, #0
1000ccb88:     	lsr	x8, x8, #1
1000ccb8c:     	mul	x8, x8, x4
1000ccb90:     	ldr	w6, [x1, x8]
1000ccb94:     	ubfx	x12, x6, #4, #4
1000ccb98:     	ubfx	x13, x6, #8, #4
1000ccb9c:     	mov	x8, x14
1000ccba0:     	ubfx	x14, x6, #12, #4
1000ccba4:     	and	x15, x6, #0xf
1000ccba8:     	ubfx	x16, x6, #16, #4
1000ccbac:     	ubfx	x17, x6, #20, #4
1000ccbb0:     	ubfx	x5, x6, #24, #4
1000ccbb4:     	lsr	x6, x6, #28
1000ccbb8:     	ldr	w7, [x10, x11]
1000ccbbc:     	lsl	w19, w7, #4
1000ccbc0:     	and	x19, x19, #0xf0
1000ccbc4:     	orr	x19, x19, x15
1000ccbc8:     	ldrsb	w19, [x9, x19]
1000ccbcc:     	and	x20, x7, #0xf0
1000ccbd0:     	orr	x20, x20, x12
1000ccbd4:     	ldrsb	w20, [x9, x20]
1000ccbd8:     	lsr	x21, x7, #4
1000ccbdc:     	and	x21, x21, #0xf0
1000ccbe0:     	orr	x21, x21, x13
1000ccbe4:     	ldrsb	w21, [x9, x21]
1000ccbe8:     	lsr	x22, x7, #8
1000ccbec:     	and	x22, x22, #0xf0
1000ccbf0:     	orr	x22, x22, x14
1000ccbf4:     	ldrsb	w22, [x9, x22]
1000ccbf8:     	add	w19, w19, w20
1000ccbfc:     	add	w19, w19, w21
1000ccc00:     	lsr	x20, x7, #12
1000ccc04:     	and	x20, x20, #0xf0
1000ccc08:     	orr	x20, x20, x16
1000ccc0c:     	ldrsb	w20, [x9, x20]
1000ccc10:     	lsr	x21, x7, #16
1000ccc14:     	and	x21, x21, #0xf0
1000ccc18:     	orr	x21, x21, x17
1000ccc1c:     	ldrsb	w21, [x9, x21]
1000ccc20:     	add	w19, w19, w22
1000ccc24:     	add	w19, w19, w20
1000ccc28:     	lsr	x20, x7, #20
1000ccc2c:     	and	x20, x20, #0xf0
1000ccc30:     	orr	x20, x20, x5
1000ccc34:     	ldrsb	w20, [x9, x20]
1000ccc38:     	lsr	x7, x7, #24
1000ccc3c:     	and	x7, x7, #0xf0
1000ccc40:     	orr	x7, x7, x6
1000ccc44:     	ldrsb	w7, [x9, x7]
1000ccc48:     	add	w19, w19, w21
1000ccc4c:     	add	w19, w19, w20
1000ccc50:     	add	w7, w19, w7
1000ccc54:     	scvtf	s0, w7
1000ccc58:     	ldr	s1, [x3, x11]
1000ccc5c:     	fadd	s0, s1, s0
1000ccc60:     	str	s0, [x3, x11]
1000ccc64:     	add	x11, x11, #4
1000ccc68:     	cmp	x11, #128
1000ccc6c:     	b.ne	0x1000ccbb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x74>
1000ccc70:     	add	x14, x8, #8
1000ccc74:     	add	x10, x10, #128
1000ccc78:     	cmp	x14, x2
1000ccc7c:     	b.ls	0x1000ccb84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000ccc80:     	cmp	x8, x2
1000ccc84:     	b.hs	0x1000ccd10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1cc>
1000ccc88:     	lsl	x9, x4, #2
1000ccc8c:     	mov	w10, #-16
1000ccc90:     	mov	x11, #0
1000ccc94:     	lsr	x13, x8, #3
1000ccc98:     	lsl	x12, x13, #7
1000ccc9c:     	mul	x14, x9, x13
1000ccca0:     	ubfx	x13, x8, #1, #2
1000ccca4:     	orr	x14, x14, x13
1000ccca8:     	ldrb	w15, [x1, x14]
1000cccac:     	ubfiz	w14, w8, #2, #1
1000cccb0:     	lsr	w15, w15, w14
1000cccb4:     	and	w16, w15, #0xf
1000cccb8:     	cmp	w16, #8
1000cccbc:     	csel	w16, wzr, w10, lo
1000cccc0:     	bfxil	w16, w15, #0, #4
1000cccc4:     	scvtf	s0, w16
1000cccc8:     	add	x15, x12, x11
1000ccccc:     	orr	x15, x15, x13
1000cccd0:     	ldrb	w15, [x0, x15]
1000cccd4:     	lsr	w15, w15, w14
1000cccd8:     	and	w16, w15, #0xf
1000cccdc:     	cmp	w16, #8
1000ccce0:     	csel	w16, wzr, w10, lo
1000ccce4:     	bfxil	w16, w15, #0, #4
1000ccce8:     	scvtf	s1, w16
1000cccec:     	ldr	s2, [x3, x11]
1000cccf0:     	fmsub	s1, s1, s0, s2
1000cccf4:     	str	s1, [x3, x11]
1000cccf8:     	add	x11, x11, #4
1000cccfc:     	cmp	x11, #128
1000ccd00:     	b.ne	0x1000cccc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000ccd04:     	add	x8, x8, #1
1000ccd08:     	cmp	x8, x2
1000ccd0c:     	b.ne	0x1000ccc90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000ccd10:     	ldp	x20, x19, [sp, #16]
1000ccd14:     	ldp	x22, x21, [sp], #32
1000ccd18:     	ret

