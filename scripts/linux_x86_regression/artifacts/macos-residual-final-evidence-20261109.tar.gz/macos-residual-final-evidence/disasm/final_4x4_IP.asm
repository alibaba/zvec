00000001000bd560 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bd560:     	sub	sp, sp, #352
1000bd564:     	stp	x28, x27, [sp, #256]
1000bd568:     	stp	x26, x25, [sp, #272]
1000bd56c:     	stp	x24, x23, [sp, #288]
1000bd570:     	stp	x22, x21, [sp, #304]
1000bd574:     	stp	x20, x19, [sp, #320]
1000bd578:     	stp	x29, x30, [sp, #336]
1000bd57c:     	add	x29, sp, #336
1000bd580:     	str	x3, [sp]
1000bd584:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bd588:     	ldr	x8, [x8, #392]
1000bd58c:     	ldr	x8, [x8]
1000bd590:     	stur	x8, [x29, #-96]
1000bd594:     	movi.2d	v0, #0000000000000000
1000bd598:     	stp	q0, q0, [x29, #-128]
1000bd59c:     	lsl	x8, x2, #1
1000bd5a0:     	stp	q0, q0, [x29, #-160]
1000bd5a4:     	ands	x8, x8, #0xfffffffffffffffc
1000bd5a8:     	b.eq	0x1000bd8d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bd5ac:     	add	x8, x1, x8
1000bd5b0:     	str	x8, [sp, #8]
1000bd5b4:     	sub	x8, x29, #160
1000bd5b8:     	add	x27, x8, #32
1000bd5bc:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bd5c0:     	add	x11, x11, #444
1000bd5c4:     	mov	x12, #0
1000bd5c8:     	ldp	w8, w9, [x1]
1000bd5cc:     	ubfx	x10, x8, #4, #4
1000bd5d0:     	str	x10, [sp, #168]
1000bd5d4:     	ubfx	x10, x8, #8, #4
1000bd5d8:     	str	x10, [sp, #160]
1000bd5dc:     	and	x10, x8, #0xf
1000bd5e0:     	str	x10, [sp, #152]
1000bd5e4:     	ubfx	x10, x8, #12, #4
1000bd5e8:     	str	x10, [sp, #144]
1000bd5ec:     	ubfx	x10, x8, #16, #4
1000bd5f0:     	str	x10, [sp, #136]
1000bd5f4:     	ubfx	x10, x8, #20, #4
1000bd5f8:     	str	x10, [sp, #128]
1000bd5fc:     	ubfx	x10, x8, #24, #4
1000bd600:     	lsr	x8, x8, #28
1000bd604:     	stp	x8, x10, [sp, #112]
1000bd608:     	and	x10, x9, #0xf
1000bd60c:     	ubfx	x8, x9, #4, #4
1000bd610:     	stp	x8, x10, [sp, #96]
1000bd614:     	ubfx	x10, x9, #8, #4
1000bd618:     	ubfx	x8, x9, #12, #4
1000bd61c:     	stp	x8, x10, [sp, #80]
1000bd620:     	ubfx	x10, x9, #16, #4
1000bd624:     	ubfx	x8, x9, #20, #4
1000bd628:     	stp	x8, x10, [sp, #64]
1000bd62c:     	ubfx	x10, x9, #24, #4
1000bd630:     	lsr	x8, x9, #28
1000bd634:     	stp	x8, x10, [sp, #48]
1000bd638:     	ldp	w9, w17, [x1, #8]
1000bd63c:     	and	x10, x9, #0xf
1000bd640:     	ubfx	x8, x9, #4, #4
1000bd644:     	stp	x8, x10, [sp, #32]
1000bd648:     	ubfx	x8, x9, #8, #4
1000bd64c:     	stp	x1, x8, [sp, #16]
1000bd650:     	ubfx	x28, x9, #12, #4
1000bd654:     	ubfx	x30, x9, #16, #4
1000bd658:     	ubfx	x8, x9, #20, #4
1000bd65c:     	ubfx	x3, x9, #24, #4
1000bd660:     	lsr	x9, x9, #28
1000bd664:     	and	x1, x17, #0xf
1000bd668:     	ubfx	x10, x17, #4, #4
1000bd66c:     	ubfx	x13, x17, #8, #4
1000bd670:     	ubfx	x26, x17, #12, #4
1000bd674:     	ubfx	x14, x17, #16, #4
1000bd678:     	ubfx	x15, x17, #20, #4
1000bd67c:     	ubfx	x16, x17, #24, #4
1000bd680:     	lsr	x17, x17, #28
1000bd684:     	ldr	w21, [x0, x12]
1000bd688:     	lsl	w2, w21, #4
1000bd68c:     	and	x2, x2, #0xf0
1000bd690:     	ldp	x4, x19, [sp, #152]
1000bd694:     	orr	x4, x2, x4
1000bd698:     	ldrsb	w6, [x11, x4]
1000bd69c:     	and	x4, x21, #0xf0
1000bd6a0:     	ldr	x5, [sp, #168]
1000bd6a4:     	orr	x5, x4, x5
1000bd6a8:     	ldrsb	w7, [x11, x5]
1000bd6ac:     	lsr	x5, x21, #4
1000bd6b0:     	and	x5, x5, #0xf0
1000bd6b4:     	orr	x19, x5, x19
1000bd6b8:     	ldrsb	w19, [x11, x19]
1000bd6bc:     	add	w6, w6, w7
1000bd6c0:     	add	w19, w6, w19
1000bd6c4:     	lsr	x6, x21, #8
1000bd6c8:     	and	x6, x6, #0xf0
1000bd6cc:     	ldp	x22, x7, [sp, #136]
1000bd6d0:     	orr	x7, x6, x7
1000bd6d4:     	ldrsb	w20, [x11, x7]
1000bd6d8:     	lsr	x7, x21, #12
1000bd6dc:     	and	x7, x7, #0xf0
1000bd6e0:     	orr	x22, x7, x22
1000bd6e4:     	ldrsb	w22, [x11, x22]
1000bd6e8:     	add	w19, w19, w20
1000bd6ec:     	add	w22, w19, w22
1000bd6f0:     	lsr	x19, x21, #16
1000bd6f4:     	and	x19, x19, #0xf0
1000bd6f8:     	ldp	x24, x20, [sp, #120]
1000bd6fc:     	orr	x20, x19, x20
1000bd700:     	ldrsb	w23, [x11, x20]
1000bd704:     	lsr	x20, x21, #20
1000bd708:     	and	x20, x20, #0xf0
1000bd70c:     	orr	x24, x20, x24
1000bd710:     	ldrsb	w24, [x11, x24]
1000bd714:     	add	w22, w22, w23
1000bd718:     	add	w22, w22, w24
1000bd71c:     	lsr	x21, x21, #24
1000bd720:     	and	x21, x21, #0xf0
1000bd724:     	ldr	x23, [sp, #112]
1000bd728:     	orr	x23, x21, x23
1000bd72c:     	ldrsb	w23, [x11, x23]
1000bd730:     	add	w22, w22, w23
1000bd734:     	scvtf	s0, w22
1000bd738:     	ldp	x23, x22, [sp, #96]
1000bd73c:     	orr	x22, x2, x22
1000bd740:     	ldrsb	w22, [x11, x22]
1000bd744:     	orr	x23, x4, x23
1000bd748:     	ldrsb	w23, [x11, x23]
1000bd74c:     	ldr	x24, [sp, #88]
1000bd750:     	orr	x24, x5, x24
1000bd754:     	ldrsb	w24, [x11, x24]
1000bd758:     	add	w22, w22, w23
1000bd75c:     	add	w22, w22, w24
1000bd760:     	ldp	x24, x23, [sp, #72]
1000bd764:     	orr	x23, x6, x23
1000bd768:     	ldrsb	w23, [x11, x23]
1000bd76c:     	orr	x24, x7, x24
1000bd770:     	ldrsb	w24, [x11, x24]
1000bd774:     	ldr	x25, [sp, #64]
1000bd778:     	orr	x25, x19, x25
1000bd77c:     	ldrsb	w25, [x11, x25]
1000bd780:     	add	w22, w22, w23
1000bd784:     	add	w22, w22, w24
1000bd788:     	ldr	x23, [sp, #56]
1000bd78c:     	orr	x23, x20, x23
1000bd790:     	ldrsb	w23, [x11, x23]
1000bd794:     	add	w22, w22, w25
1000bd798:     	add	w22, w22, w23
1000bd79c:     	ldr	x23, [sp, #48]
1000bd7a0:     	orr	x23, x21, x23
1000bd7a4:     	ldrsb	w23, [x11, x23]
1000bd7a8:     	add	w22, w22, w23
1000bd7ac:     	scvtf	s1, w22
1000bd7b0:     	ldp	x23, x22, [sp, #32]
1000bd7b4:     	orr	x22, x2, x22
1000bd7b8:     	ldrsb	w22, [x11, x22]
1000bd7bc:     	orr	x23, x4, x23
1000bd7c0:     	ldrsb	w23, [x11, x23]
1000bd7c4:     	ldr	x24, [sp, #24]
1000bd7c8:     	orr	x24, x5, x24
1000bd7cc:     	ldrsb	w24, [x11, x24]
1000bd7d0:     	add	w22, w22, w23
1000bd7d4:     	add	w22, w22, w24
1000bd7d8:     	orr	x23, x6, x28
1000bd7dc:     	ldrsb	w23, [x11, x23]
1000bd7e0:     	orr	x24, x7, x30
1000bd7e4:     	ldrsb	w24, [x11, x24]
1000bd7e8:     	orr	x25, x19, x8
1000bd7ec:     	ldrsb	w25, [x11, x25]
1000bd7f0:     	add	w22, w22, w23
1000bd7f4:     	orr	x23, x20, x3
1000bd7f8:     	ldrsb	w23, [x11, x23]
1000bd7fc:     	add	w22, w22, w24
1000bd800:     	add	w22, w22, w25
1000bd804:     	add	w22, w22, w23
1000bd808:     	orr	x23, x21, x9
1000bd80c:     	ldrsb	w23, [x11, x23]
1000bd810:     	add	w22, w22, w23
1000bd814:     	scvtf	s2, w22
1000bd818:     	orr	x2, x2, x1
1000bd81c:     	ldrsb	w2, [x11, x2]
1000bd820:     	orr	x4, x4, x10
1000bd824:     	ldrsb	w4, [x11, x4]
1000bd828:     	orr	x5, x5, x13
1000bd82c:     	ldrsb	w5, [x11, x5]
1000bd830:     	add	w2, w2, w4
1000bd834:     	add	w2, w2, w5
1000bd838:     	orr	x4, x6, x26
1000bd83c:     	ldrsb	w4, [x11, x4]
1000bd840:     	orr	x5, x7, x14
1000bd844:     	ldrsb	w5, [x11, x5]
1000bd848:     	add	w2, w2, w4
1000bd84c:     	orr	x4, x19, x15
1000bd850:     	ldrsb	w4, [x11, x4]
1000bd854:     	add	w2, w2, w5
1000bd858:     	orr	x5, x20, x16
1000bd85c:     	ldrsb	w5, [x11, x5]
1000bd860:     	add	w2, w2, w4
1000bd864:     	add	w2, w2, w5
1000bd868:     	orr	x4, x21, x17
1000bd86c:     	ldrsb	w4, [x11, x4]
1000bd870:     	add	w2, w2, w4
1000bd874:     	sub	x4, x29, #160
1000bd878:     	scvtf	s3, w2
1000bd87c:     	add	x2, x27, x12
1000bd880:     	ldur	s4, [x2, #-16]
1000bd884:     	fadd	s1, s4, s1
1000bd888:     	stur	s1, [x2, #-16]
1000bd88c:     	ldr	s1, [x2]
1000bd890:     	fadd	s1, s1, s2
1000bd894:     	str	s1, [x2]
1000bd898:     	ldr	s1, [x2, #16]
1000bd89c:     	fadd	s1, s1, s3
1000bd8a0:     	ldr	s2, [x4, x12]
1000bd8a4:     	str	s1, [x2, #16]
1000bd8a8:     	fadd	s0, s2, s0
1000bd8ac:     	str	s0, [x4, x12]
1000bd8b0:     	add	x12, x12, #4
1000bd8b4:     	cmp	x12, #16
1000bd8b8:     	b.ne	0x1000bd684 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bd8bc:     	add	x0, x0, #16
1000bd8c0:     	ldp	x8, x1, [sp, #8]
1000bd8c4:     	add	x1, x1, #16
1000bd8c8:     	cmp	x1, x8
1000bd8cc:     	b.ne	0x1000bd5c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bd8d0:     	ldp	q0, q1, [x29, #-160]
1000bd8d4:     	ldr	x8, [sp]
1000bd8d8:     	stp	q0, q1, [x8]
1000bd8dc:     	ldp	q0, q1, [x29, #-128]
1000bd8e0:     	stp	q0, q1, [x8, #32]
1000bd8e4:     	ldur	x8, [x29, #-96]
1000bd8e8:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 1ul, false>(char const*)+0x284>
1000bd8ec:     	ldr	x9, [x9, #392]
1000bd8f0:     	ldr	x9, [x9]
1000bd8f4:     	cmp	x9, x8
1000bd8f8:     	b.ne	0x1000bd91c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bd8fc:     	ldp	x29, x30, [sp, #336]
1000bd900:     	ldp	x20, x19, [sp, #320]
1000bd904:     	ldp	x22, x21, [sp, #304]
1000bd908:     	ldp	x24, x23, [sp, #288]
1000bd90c:     	ldp	x26, x25, [sp, #272]
1000bd910:     	ldp	x28, x27, [sp, #256]
1000bd914:     	add	sp, sp, #352
1000bd918:     	ret
1000bd91c:     	bl	0x100163694 <_strcmp+0x100163694>

