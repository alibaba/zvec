00000001000bb91c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bb91c:     	sub	sp, sp, #176
1000bb920:     	stp	x28, x27, [sp, #80]
1000bb924:     	stp	x26, x25, [sp, #96]
1000bb928:     	stp	x24, x23, [sp, #112]
1000bb92c:     	stp	x22, x21, [sp, #128]
1000bb930:     	stp	x20, x19, [sp, #144]
1000bb934:     	stp	x29, x30, [sp, #160]
1000bb938:     	add	x29, sp, #160
1000bb93c:     	str	x3, [sp]
1000bb940:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xc>
1000bb944:     	ldr	x8, [x8, #392]
1000bb948:     	ldr	x8, [x8]
1000bb94c:     	str	x8, [sp, #72]
1000bb950:     	movi.2d	v0, #0000000000000000
1000bb954:     	stp	q0, q0, [sp, #32]
1000bb958:     	ands	x8, x2, #0xfffffffffffffffe
1000bb95c:     	b.eq	0x1000bbb00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bb960:     	add	x8, x1, x8
1000bb964:     	str	x8, [sp, #8]
1000bb968:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000bb96c:     	add	x9, x9, #188
1000bb970:     	mov	x11, #0
1000bb974:     	ldp	w4, w23, [x1]
1000bb978:     	ubfx	x8, x4, #4, #4
1000bb97c:     	stp	x1, x8, [sp, #16]
1000bb980:     	ubfx	x13, x4, #8, #4
1000bb984:     	and	x14, x4, #0xf
1000bb988:     	ubfx	x15, x4, #12, #4
1000bb98c:     	ubfx	x16, x4, #16, #4
1000bb990:     	ubfx	x17, x4, #20, #4
1000bb994:     	ubfx	x2, x4, #24, #4
1000bb998:     	lsr	x4, x4, #28
1000bb99c:     	and	x5, x23, #0xf
1000bb9a0:     	ubfx	x6, x23, #4, #4
1000bb9a4:     	ubfx	x7, x23, #8, #4
1000bb9a8:     	ubfx	x19, x23, #12, #4
1000bb9ac:     	ubfx	x20, x23, #16, #4
1000bb9b0:     	ubfx	x21, x23, #20, #4
1000bb9b4:     	ubfx	x22, x23, #24, #4
1000bb9b8:     	lsr	x23, x23, #28
1000bb9bc:     	ldr	w24, [x0, x11]
1000bb9c0:     	lsl	w25, w24, #4
1000bb9c4:     	and	x25, x25, #0xf0
1000bb9c8:     	orr	x26, x25, x14
1000bb9cc:     	ldrb	w26, [x9, x26]
1000bb9d0:     	and	x27, x24, #0xf0
1000bb9d4:     	ldr	x8, [sp, #24]
1000bb9d8:     	orr	x28, x27, x8
1000bb9dc:     	ldrb	w28, [x9, x28]
1000bb9e0:     	lsr	x30, x24, #4
1000bb9e4:     	and	x30, x30, #0xf0
1000bb9e8:     	orr	x8, x30, x13
1000bb9ec:     	ldrb	w8, [x9, x8]
1000bb9f0:     	add	w26, w26, w28
1000bb9f4:     	add	w8, w26, w8
1000bb9f8:     	lsr	x26, x24, #8
1000bb9fc:     	and	x26, x26, #0xf0
1000bba00:     	orr	x28, x26, x15
1000bba04:     	ldrb	w28, [x9, x28]
1000bba08:     	lsr	x3, x24, #12
1000bba0c:     	and	x3, x3, #0xf0
1000bba10:     	orr	x10, x3, x16
1000bba14:     	ldrb	w10, [x9, x10]
1000bba18:     	add	w8, w8, w28
1000bba1c:     	add	w8, w8, w10
1000bba20:     	lsr	x10, x24, #16
1000bba24:     	and	x10, x10, #0xf0
1000bba28:     	orr	x28, x10, x17
1000bba2c:     	ldrb	w28, [x9, x28]
1000bba30:     	lsr	x1, x24, #20
1000bba34:     	and	x1, x1, #0xf0
1000bba38:     	orr	x12, x1, x2
1000bba3c:     	ldrb	w12, [x9, x12]
1000bba40:     	add	w8, w8, w28
1000bba44:     	add	x28, sp, #32
1000bba48:     	add	w8, w8, w12
1000bba4c:     	lsr	x12, x24, #24
1000bba50:     	and	x12, x12, #0xf0
1000bba54:     	orr	x24, x12, x4
1000bba58:     	ldrb	w24, [x9, x24]
1000bba5c:     	add	w8, w8, w24
1000bba60:     	scvtf	s0, w8
1000bba64:     	add	x8, x28, x11
1000bba68:     	ldr	s1, [x8]
1000bba6c:     	fadd	s0, s1, s0
1000bba70:     	orr	x24, x25, x5
1000bba74:     	ldrb	w24, [x9, x24]
1000bba78:     	orr	x25, x27, x6
1000bba7c:     	ldrb	w25, [x9, x25]
1000bba80:     	orr	x27, x30, x7
1000bba84:     	ldrb	w27, [x9, x27]
1000bba88:     	add	w24, w24, w25
1000bba8c:     	add	w24, w24, w27
1000bba90:     	orr	x25, x26, x19
1000bba94:     	ldrb	w25, [x9, x25]
1000bba98:     	orr	x3, x3, x20
1000bba9c:     	ldrb	w3, [x9, x3]
1000bbaa0:     	orr	x10, x10, x21
1000bbaa4:     	ldrb	w10, [x9, x10]
1000bbaa8:     	add	w24, w24, w25
1000bbaac:     	add	w3, w24, w3
1000bbab0:     	orr	x1, x1, x22
1000bbab4:     	ldrb	w1, [x9, x1]
1000bbab8:     	add	w10, w3, w10
1000bbabc:     	add	w10, w10, w1
1000bbac0:     	orr	x12, x12, x23
1000bbac4:     	ldrb	w12, [x9, x12]
1000bbac8:     	add	w10, w10, w12
1000bbacc:     	scvtf	s1, w10
1000bbad0:     	str	s0, [x8]
1000bbad4:     	ldr	s0, [x8, #16]
1000bbad8:     	fadd	s0, s0, s1
1000bbadc:     	str	s0, [x8, #16]
1000bbae0:     	add	x11, x11, #4
1000bbae4:     	cmp	x11, #16
1000bbae8:     	b.ne	0x1000bb9bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bbaec:     	add	x0, x0, #16
1000bbaf0:     	ldp	x8, x1, [sp, #8]
1000bbaf4:     	add	x1, x1, #8
1000bbaf8:     	cmp	x1, x8
1000bbafc:     	b.ne	0x1000bb970 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bbb00:     	ldp	q0, q1, [sp, #32]
1000bbb04:     	ldr	x8, [sp]
1000bbb08:     	stp	q0, q1, [x8]
1000bbb0c:     	ldr	x8, [sp, #72]
1000bbb10:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1dc>
1000bbb14:     	ldr	x9, [x9, #392]
1000bbb18:     	ldr	x9, [x9]
1000bbb1c:     	cmp	x9, x8
1000bbb20:     	b.ne	0x1000bbb44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bbb24:     	ldp	x29, x30, [sp, #160]
1000bbb28:     	ldp	x20, x19, [sp, #144]
1000bbb2c:     	ldp	x22, x21, [sp, #128]
1000bbb30:     	ldp	x24, x23, [sp, #112]
1000bbb34:     	ldp	x26, x25, [sp, #96]
1000bbb38:     	ldp	x28, x27, [sp, #80]
1000bbb3c:     	add	sp, sp, #176
1000bbb40:     	ret
1000bbb44:     	bl	0x100163694 <_strcmp+0x100163694>

