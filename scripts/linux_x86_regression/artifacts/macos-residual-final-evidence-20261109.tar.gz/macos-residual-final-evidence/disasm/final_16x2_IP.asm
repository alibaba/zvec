00000001000c896c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c896c:     	sub	sp, sp, #272
1000c8970:     	stp	x28, x27, [sp, #176]
1000c8974:     	stp	x26, x25, [sp, #192]
1000c8978:     	stp	x24, x23, [sp, #208]
1000c897c:     	stp	x22, x21, [sp, #224]
1000c8980:     	stp	x20, x19, [sp, #240]
1000c8984:     	stp	x29, x30, [sp, #256]
1000c8988:     	add	x29, sp, #256
1000c898c:     	str	x3, [sp]
1000c8990:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x84>
1000c8994:     	ldr	x8, [x8, #392]
1000c8998:     	ldr	x8, [x8]
1000c899c:     	stur	x8, [x29, #-96]
1000c89a0:     	movi.2d	v0, #0000000000000000
1000c89a4:     	stp	q0, q0, [sp, #128]
1000c89a8:     	stp	q0, q0, [sp, #96]
1000c89ac:     	stp	q0, q0, [sp, #64]
1000c89b0:     	stp	q0, q0, [sp, #32]
1000c89b4:     	ands	x8, x2, #0xfffffffffffffffe
1000c89b8:     	b.eq	0x1000c8b3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c89bc:     	add	x8, x1, x8
1000c89c0:     	str	x8, [sp, #8]
1000c89c4:     	adrp	x9, 0x10016a000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0xb0>
1000c89c8:     	add	x9, x9, #1468
1000c89cc:     	mov	x11, #0
1000c89d0:     	ldp	w4, w23, [x1]
1000c89d4:     	ubfx	x8, x4, #8, #4
1000c89d8:     	stp	x1, x8, [sp, #16]
1000c89dc:     	ubfx	x13, x4, #16, #4
1000c89e0:     	and	x14, x4, #0xf
1000c89e4:     	ubfx	x15, x4, #24, #4
1000c89e8:     	ubfx	x16, x4, #4, #4
1000c89ec:     	ubfx	x17, x4, #12, #4
1000c89f0:     	ubfx	x2, x4, #20, #4
1000c89f4:     	lsr	x4, x4, #28
1000c89f8:     	and	x5, x23, #0xf
1000c89fc:     	ubfx	x6, x23, #8, #4
1000c8a00:     	ubfx	x7, x23, #16, #4
1000c8a04:     	ubfx	x19, x23, #24, #4
1000c8a08:     	ubfx	x20, x23, #4, #4
1000c8a0c:     	ubfx	x21, x23, #12, #4
1000c8a10:     	ubfx	x22, x23, #20, #4
1000c8a14:     	lsr	x23, x23, #28
1000c8a18:     	ldr	w24, [x0, x11]
1000c8a1c:     	lsl	w25, w24, #4
1000c8a20:     	and	x25, x25, #0xf0
1000c8a24:     	add	x25, x9, x25
1000c8a28:     	and	x26, x24, #0xf0
1000c8a2c:     	add	x26, x9, x26
1000c8a30:     	lsr	x27, x24, #4
1000c8a34:     	and	x27, x27, #0xf0
1000c8a38:     	add	x27, x9, x27
1000c8a3c:     	lsr	x28, x24, #8
1000c8a40:     	and	x28, x28, #0xf0
1000c8a44:     	add	x28, x9, x28
1000c8a48:     	lsr	x30, x24, #12
1000c8a4c:     	and	x30, x30, #0xf0
1000c8a50:     	add	x30, x9, x30
1000c8a54:     	lsr	x8, x24, #16
1000c8a58:     	and	x8, x8, #0xf0
1000c8a5c:     	add	x8, x9, x8
1000c8a60:     	lsr	x3, x24, #20
1000c8a64:     	and	x3, x3, #0xf0
1000c8a68:     	add	x3, x9, x3
1000c8a6c:     	lsr	x24, x24, #24
1000c8a70:     	and	x24, x24, #0xf0
1000c8a74:     	ldrsb	w10, [x25, x14]
1000c8a78:     	ldr	x12, [sp, #24]
1000c8a7c:     	ldrsb	w1, [x27, x12]
1000c8a80:     	ldrsb	w12, [x30, x13]
1000c8a84:     	add	w10, w10, w1
1000c8a88:     	add	w10, w10, w12
1000c8a8c:     	ldrsb	w12, [x3, x15]
1000c8a90:     	ldrsb	w1, [x26, x16]
1000c8a94:     	add	w10, w10, w12
1000c8a98:     	add	w10, w10, w1
1000c8a9c:     	ldrsb	w12, [x28, x17]
1000c8aa0:     	ldrsb	w1, [x8, x2]
1000c8aa4:     	add	x24, x9, x24
1000c8aa8:     	add	w10, w10, w12
1000c8aac:     	add	w10, w10, w1
1000c8ab0:     	ldrsb	w12, [x24, x4]
1000c8ab4:     	add	w10, w10, w12
1000c8ab8:     	scvtf	s0, w10
1000c8abc:     	add	x10, sp, #32
1000c8ac0:     	add	x10, x10, x11
1000c8ac4:     	ldr	s1, [x10]
1000c8ac8:     	ldrsb	w12, [x25, x5]
1000c8acc:     	fadd	s0, s1, s0
1000c8ad0:     	ldrsb	w1, [x27, x6]
1000c8ad4:     	ldrsb	w25, [x30, x7]
1000c8ad8:     	add	w12, w12, w1
1000c8adc:     	add	w12, w12, w25
1000c8ae0:     	ldrsb	w1, [x3, x19]
1000c8ae4:     	ldrsb	w3, [x26, x20]
1000c8ae8:     	add	w12, w12, w1
1000c8aec:     	add	w12, w12, w3
1000c8af0:     	ldrsb	w1, [x28, x21]
1000c8af4:     	ldrsb	w8, [x8, x22]
1000c8af8:     	add	w12, w12, w1
1000c8afc:     	add	w8, w12, w8
1000c8b00:     	ldrsb	w12, [x24, x23]
1000c8b04:     	add	w8, w8, w12
1000c8b08:     	scvtf	s1, w8
1000c8b0c:     	str	s0, [x10]
1000c8b10:     	ldr	s0, [x10, #64]
1000c8b14:     	fadd	s0, s0, s1
1000c8b18:     	str	s0, [x10, #64]
1000c8b1c:     	add	x11, x11, #4
1000c8b20:     	cmp	x11, #64
1000c8b24:     	b.ne	0x1000c8a18 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c8b28:     	add	x0, x0, #64
1000c8b2c:     	ldp	x8, x1, [sp, #8]
1000c8b30:     	add	x1, x1, #8
1000c8b34:     	cmp	x1, x8
1000c8b38:     	b.ne	0x1000c89cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c8b3c:     	ldp	q0, q1, [sp, #96]
1000c8b40:     	ldr	x8, [sp]
1000c8b44:     	stp	q0, q1, [x8, #64]
1000c8b48:     	ldp	q0, q1, [sp, #128]
1000c8b4c:     	stp	q0, q1, [x8, #96]
1000c8b50:     	ldp	q0, q1, [sp, #32]
1000c8b54:     	stp	q0, q1, [x8]
1000c8b58:     	ldp	q0, q1, [sp, #64]
1000c8b5c:     	stp	q0, q1, [x8, #32]
1000c8b60:     	ldur	x8, [x29, #-96]
1000c8b64:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x258>
1000c8b68:     	ldr	x9, [x9, #392]
1000c8b6c:     	ldr	x9, [x9]
1000c8b70:     	cmp	x9, x8
1000c8b74:     	b.ne	0x1000c8b98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c8b78:     	ldp	x29, x30, [sp, #256]
1000c8b7c:     	ldp	x20, x19, [sp, #240]
1000c8b80:     	ldp	x22, x21, [sp, #224]
1000c8b84:     	ldp	x24, x23, [sp, #208]
1000c8b88:     	ldp	x26, x25, [sp, #192]
1000c8b8c:     	ldp	x28, x27, [sp, #176]
1000c8b90:     	add	sp, sp, #272
1000c8b94:     	ret
1000c8b98:     	bl	0x100163694 <_strcmp+0x100163694>

