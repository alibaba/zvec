00000001000bd0a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bd0a8:     	sub	sp, sp, #352
1000bd0ac:     	stp	x28, x27, [sp, #256]
1000bd0b0:     	stp	x26, x25, [sp, #272]
1000bd0b4:     	stp	x24, x23, [sp, #288]
1000bd0b8:     	stp	x22, x21, [sp, #304]
1000bd0bc:     	stp	x20, x19, [sp, #320]
1000bd0c0:     	stp	x29, x30, [sp, #336]
1000bd0c4:     	add	x29, sp, #336
1000bd0c8:     	str	x3, [sp]
1000bd0cc:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bd0d0:     	ldr	x8, [x8, #392]
1000bd0d4:     	ldr	x8, [x8]
1000bd0d8:     	stur	x8, [x29, #-96]
1000bd0dc:     	movi.2d	v0, #0000000000000000
1000bd0e0:     	stp	q0, q0, [x29, #-128]
1000bd0e4:     	lsl	x8, x2, #1
1000bd0e8:     	stp	q0, q0, [x29, #-160]
1000bd0ec:     	ands	x8, x8, #0xfffffffffffffffc
1000bd0f0:     	b.eq	0x1000bd418 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bd0f4:     	add	x8, x1, x8
1000bd0f8:     	str	x8, [sp, #8]
1000bd0fc:     	sub	x8, x29, #160
1000bd100:     	add	x27, x8, #32
1000bd104:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bd108:     	add	x11, x11, #188
1000bd10c:     	mov	x12, #0
1000bd110:     	ldp	w8, w9, [x1]
1000bd114:     	ubfx	x10, x8, #4, #4
1000bd118:     	str	x10, [sp, #168]
1000bd11c:     	ubfx	x10, x8, #8, #4
1000bd120:     	str	x10, [sp, #160]
1000bd124:     	and	x10, x8, #0xf
1000bd128:     	str	x10, [sp, #152]
1000bd12c:     	ubfx	x10, x8, #12, #4
1000bd130:     	str	x10, [sp, #144]
1000bd134:     	ubfx	x10, x8, #16, #4
1000bd138:     	str	x10, [sp, #136]
1000bd13c:     	ubfx	x10, x8, #20, #4
1000bd140:     	str	x10, [sp, #128]
1000bd144:     	ubfx	x10, x8, #24, #4
1000bd148:     	lsr	x8, x8, #28
1000bd14c:     	stp	x8, x10, [sp, #112]
1000bd150:     	and	x10, x9, #0xf
1000bd154:     	ubfx	x8, x9, #4, #4
1000bd158:     	stp	x8, x10, [sp, #96]
1000bd15c:     	ubfx	x10, x9, #8, #4
1000bd160:     	ubfx	x8, x9, #12, #4
1000bd164:     	stp	x8, x10, [sp, #80]
1000bd168:     	ubfx	x10, x9, #16, #4
1000bd16c:     	ubfx	x8, x9, #20, #4
1000bd170:     	stp	x8, x10, [sp, #64]
1000bd174:     	ubfx	x10, x9, #24, #4
1000bd178:     	lsr	x8, x9, #28
1000bd17c:     	stp	x8, x10, [sp, #48]
1000bd180:     	ldp	w9, w17, [x1, #8]
1000bd184:     	and	x10, x9, #0xf
1000bd188:     	ubfx	x8, x9, #4, #4
1000bd18c:     	stp	x8, x10, [sp, #32]
1000bd190:     	ubfx	x8, x9, #8, #4
1000bd194:     	stp	x1, x8, [sp, #16]
1000bd198:     	ubfx	x28, x9, #12, #4
1000bd19c:     	ubfx	x30, x9, #16, #4
1000bd1a0:     	ubfx	x8, x9, #20, #4
1000bd1a4:     	ubfx	x3, x9, #24, #4
1000bd1a8:     	lsr	x9, x9, #28
1000bd1ac:     	and	x1, x17, #0xf
1000bd1b0:     	ubfx	x10, x17, #4, #4
1000bd1b4:     	ubfx	x13, x17, #8, #4
1000bd1b8:     	ubfx	x26, x17, #12, #4
1000bd1bc:     	ubfx	x14, x17, #16, #4
1000bd1c0:     	ubfx	x15, x17, #20, #4
1000bd1c4:     	ubfx	x16, x17, #24, #4
1000bd1c8:     	lsr	x17, x17, #28
1000bd1cc:     	ldr	w21, [x0, x12]
1000bd1d0:     	lsl	w2, w21, #4
1000bd1d4:     	and	x2, x2, #0xf0
1000bd1d8:     	ldp	x4, x19, [sp, #152]
1000bd1dc:     	orr	x4, x2, x4
1000bd1e0:     	ldrb	w6, [x11, x4]
1000bd1e4:     	and	x4, x21, #0xf0
1000bd1e8:     	ldr	x5, [sp, #168]
1000bd1ec:     	orr	x5, x4, x5
1000bd1f0:     	ldrb	w7, [x11, x5]
1000bd1f4:     	lsr	x5, x21, #4
1000bd1f8:     	and	x5, x5, #0xf0
1000bd1fc:     	orr	x19, x5, x19
1000bd200:     	ldrb	w19, [x11, x19]
1000bd204:     	add	w6, w6, w7
1000bd208:     	add	w19, w6, w19
1000bd20c:     	lsr	x6, x21, #8
1000bd210:     	and	x6, x6, #0xf0
1000bd214:     	ldp	x22, x7, [sp, #136]
1000bd218:     	orr	x7, x6, x7
1000bd21c:     	ldrb	w20, [x11, x7]
1000bd220:     	lsr	x7, x21, #12
1000bd224:     	and	x7, x7, #0xf0
1000bd228:     	orr	x22, x7, x22
1000bd22c:     	ldrb	w22, [x11, x22]
1000bd230:     	add	w19, w19, w20
1000bd234:     	add	w22, w19, w22
1000bd238:     	lsr	x19, x21, #16
1000bd23c:     	and	x19, x19, #0xf0
1000bd240:     	ldp	x24, x20, [sp, #120]
1000bd244:     	orr	x20, x19, x20
1000bd248:     	ldrb	w23, [x11, x20]
1000bd24c:     	lsr	x20, x21, #20
1000bd250:     	and	x20, x20, #0xf0
1000bd254:     	orr	x24, x20, x24
1000bd258:     	ldrb	w24, [x11, x24]
1000bd25c:     	add	w22, w22, w23
1000bd260:     	add	w22, w22, w24
1000bd264:     	lsr	x21, x21, #24
1000bd268:     	and	x21, x21, #0xf0
1000bd26c:     	ldr	x23, [sp, #112]
1000bd270:     	orr	x23, x21, x23
1000bd274:     	ldrb	w23, [x11, x23]
1000bd278:     	add	w22, w22, w23
1000bd27c:     	scvtf	s0, w22
1000bd280:     	ldp	x23, x22, [sp, #96]
1000bd284:     	orr	x22, x2, x22
1000bd288:     	ldrb	w22, [x11, x22]
1000bd28c:     	orr	x23, x4, x23
1000bd290:     	ldrb	w23, [x11, x23]
1000bd294:     	ldr	x24, [sp, #88]
1000bd298:     	orr	x24, x5, x24
1000bd29c:     	ldrb	w24, [x11, x24]
1000bd2a0:     	add	w22, w22, w23
1000bd2a4:     	add	w22, w22, w24
1000bd2a8:     	ldp	x24, x23, [sp, #72]
1000bd2ac:     	orr	x23, x6, x23
1000bd2b0:     	ldrb	w23, [x11, x23]
1000bd2b4:     	orr	x24, x7, x24
1000bd2b8:     	ldrb	w24, [x11, x24]
1000bd2bc:     	ldr	x25, [sp, #64]
1000bd2c0:     	orr	x25, x19, x25
1000bd2c4:     	ldrb	w25, [x11, x25]
1000bd2c8:     	add	w22, w22, w23
1000bd2cc:     	add	w22, w22, w24
1000bd2d0:     	ldr	x23, [sp, #56]
1000bd2d4:     	orr	x23, x20, x23
1000bd2d8:     	ldrb	w23, [x11, x23]
1000bd2dc:     	add	w22, w22, w25
1000bd2e0:     	add	w22, w22, w23
1000bd2e4:     	ldr	x23, [sp, #48]
1000bd2e8:     	orr	x23, x21, x23
1000bd2ec:     	ldrb	w23, [x11, x23]
1000bd2f0:     	add	w22, w22, w23
1000bd2f4:     	scvtf	s1, w22
1000bd2f8:     	ldp	x23, x22, [sp, #32]
1000bd2fc:     	orr	x22, x2, x22
1000bd300:     	ldrb	w22, [x11, x22]
1000bd304:     	orr	x23, x4, x23
1000bd308:     	ldrb	w23, [x11, x23]
1000bd30c:     	ldr	x24, [sp, #24]
1000bd310:     	orr	x24, x5, x24
1000bd314:     	ldrb	w24, [x11, x24]
1000bd318:     	add	w22, w22, w23
1000bd31c:     	add	w22, w22, w24
1000bd320:     	orr	x23, x6, x28
1000bd324:     	ldrb	w23, [x11, x23]
1000bd328:     	orr	x24, x7, x30
1000bd32c:     	ldrb	w24, [x11, x24]
1000bd330:     	orr	x25, x19, x8
1000bd334:     	ldrb	w25, [x11, x25]
1000bd338:     	add	w22, w22, w23
1000bd33c:     	orr	x23, x20, x3
1000bd340:     	ldrb	w23, [x11, x23]
1000bd344:     	add	w22, w22, w24
1000bd348:     	add	w22, w22, w25
1000bd34c:     	add	w22, w22, w23
1000bd350:     	orr	x23, x21, x9
1000bd354:     	ldrb	w23, [x11, x23]
1000bd358:     	add	w22, w22, w23
1000bd35c:     	scvtf	s2, w22
1000bd360:     	orr	x2, x2, x1
1000bd364:     	ldrb	w2, [x11, x2]
1000bd368:     	orr	x4, x4, x10
1000bd36c:     	ldrb	w4, [x11, x4]
1000bd370:     	orr	x5, x5, x13
1000bd374:     	ldrb	w5, [x11, x5]
1000bd378:     	add	w2, w2, w4
1000bd37c:     	add	w2, w2, w5
1000bd380:     	orr	x4, x6, x26
1000bd384:     	ldrb	w4, [x11, x4]
1000bd388:     	orr	x5, x7, x14
1000bd38c:     	ldrb	w5, [x11, x5]
1000bd390:     	add	w2, w2, w4
1000bd394:     	orr	x4, x19, x15
1000bd398:     	ldrb	w4, [x11, x4]
1000bd39c:     	add	w2, w2, w5
1000bd3a0:     	orr	x5, x20, x16
1000bd3a4:     	ldrb	w5, [x11, x5]
1000bd3a8:     	add	w2, w2, w4
1000bd3ac:     	add	w2, w2, w5
1000bd3b0:     	orr	x4, x21, x17
1000bd3b4:     	ldrb	w4, [x11, x4]
1000bd3b8:     	add	w2, w2, w4
1000bd3bc:     	sub	x4, x29, #160
1000bd3c0:     	scvtf	s3, w2
1000bd3c4:     	add	x2, x27, x12
1000bd3c8:     	ldur	s4, [x2, #-16]
1000bd3cc:     	fadd	s1, s4, s1
1000bd3d0:     	stur	s1, [x2, #-16]
1000bd3d4:     	ldr	s1, [x2]
1000bd3d8:     	fadd	s1, s1, s2
1000bd3dc:     	str	s1, [x2]
1000bd3e0:     	ldr	s1, [x2, #16]
1000bd3e4:     	fadd	s1, s1, s3
1000bd3e8:     	ldr	s2, [x4, x12]
1000bd3ec:     	str	s1, [x2, #16]
1000bd3f0:     	fadd	s0, s2, s0
1000bd3f4:     	str	s0, [x4, x12]
1000bd3f8:     	add	x12, x12, #4
1000bd3fc:     	cmp	x12, #16
1000bd400:     	b.ne	0x1000bd1cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bd404:     	add	x0, x0, #16
1000bd408:     	ldp	x8, x1, [sp, #8]
1000bd40c:     	add	x1, x1, #16
1000bd410:     	cmp	x1, x8
1000bd414:     	b.ne	0x1000bd10c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bd418:     	ldp	q0, q1, [x29, #-160]
1000bd41c:     	ldr	x8, [sp]
1000bd420:     	stp	q0, q1, [x8]
1000bd424:     	ldp	q0, q1, [x29, #-128]
1000bd428:     	stp	q0, q1, [x8, #32]
1000bd42c:     	ldur	x8, [x29, #-96]
1000bd430:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18c>
1000bd434:     	ldr	x9, [x9, #392]
1000bd438:     	ldr	x9, [x9]
1000bd43c:     	cmp	x9, x8
1000bd440:     	b.ne	0x1000bd464 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bd444:     	ldp	x29, x30, [sp, #336]
1000bd448:     	ldp	x20, x19, [sp, #320]
1000bd44c:     	ldp	x22, x21, [sp, #304]
1000bd450:     	ldp	x24, x23, [sp, #288]
1000bd454:     	ldp	x26, x25, [sp, #272]
1000bd458:     	ldp	x28, x27, [sp, #256]
1000bd45c:     	add	sp, sp, #352
1000bd460:     	ret
1000bd464:     	bl	0x100163694 <_strcmp+0x100163694>

