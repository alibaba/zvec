
bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000b62a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b62a0:     	stp	x24, x23, [sp, #-48]!
1000b62a4:     	stp	x22, x21, [sp, #16]
1000b62a8:     	stp	x20, x19, [sp, #32]
1000b62ac:     	str	xzr, [x3]
1000b62b0:     	lsl	x8, x4, #2
1000b62b4:     	cmp	x2, #8
1000b62b8:     	b.hs	0x1000b62cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b62bc:     	mov	x12, #0
1000b62c0:     	movi	d1, #0000000000000000
1000b62c4:     	movi	d0, #0000000000000000
1000b62c8:     	b	0x1000b6434 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b62cc:     	mov	x10, #0
1000b62d0:     	adrp	x9, 0x100169000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x90>
1000b62d4:     	add	x9, x9, #3772
1000b62d8:     	mov	x11, x1
1000b62dc:     	ldr	w4, [x11]
1000b62e0:     	lsl	w12, w4, #4
1000b62e4:     	and	x13, x12, #0xf0
1000b62e8:     	and	x12, x4, #0xf0
1000b62ec:     	add	x12, x9, x12
1000b62f0:     	lsr	x14, x4, #4
1000b62f4:     	and	x15, x14, #0xf0
1000b62f8:     	add	x14, x9, x13
1000b62fc:     	add	x13, x9, x15
1000b6300:     	lsr	x15, x4, #8
1000b6304:     	and	x15, x15, #0xf0
1000b6308:     	lsr	x16, x4, #12
1000b630c:     	and	x17, x16, #0xf0
1000b6310:     	add	x16, x9, x15
1000b6314:     	add	x15, x9, x17
1000b6318:     	lsr	x17, x4, #16
1000b631c:     	and	x17, x17, #0xf0
1000b6320:     	lsr	x5, x4, #20
1000b6324:     	and	x5, x5, #0xf0
1000b6328:     	add	x17, x9, x17
1000b632c:     	lsr	x4, x4, #24
1000b6330:     	and	x6, x4, #0xf0
1000b6334:     	add	x7, x0, x10
1000b6338:     	ldr	w19, [x7]
1000b633c:     	and	x20, x19, #0xf
1000b6340:     	add	x4, x9, x5
1000b6344:     	ldrb	w5, [x14, x20]
1000b6348:     	ubfx	x20, x19, #4, #4
1000b634c:     	ubfx	x21, x19, #8, #4
1000b6350:     	ldrb	w20, [x12, x20]
1000b6354:     	ldrb	w21, [x13, x21]
1000b6358:     	ubfx	x22, x19, #12, #4
1000b635c:     	ubfx	x23, x19, #16, #4
1000b6360:     	ldrb	w22, [x16, x22]
1000b6364:     	ldrb	w23, [x15, x23]
1000b6368:     	ubfx	x24, x19, #20, #4
1000b636c:     	ldrb	w24, [x17, x24]
1000b6370:     	add	w5, w5, w20
1000b6374:     	add	w5, w5, w21
1000b6378:     	ubfx	x20, x19, #24, #4
1000b637c:     	ldrb	w20, [x4, x20]
1000b6380:     	add	w5, w5, w22
1000b6384:     	add	w5, w5, w23
1000b6388:     	add	x6, x9, x6
1000b638c:     	lsr	x19, x19, #28
1000b6390:     	ldrb	w19, [x6, x19]
1000b6394:     	add	w5, w5, w24
1000b6398:     	add	w5, w5, w20
1000b639c:     	add	w5, w5, w19
1000b63a0:     	scvtf	s0, w5
1000b63a4:     	ldp	s1, s2, [x3]
1000b63a8:     	fadd	s0, s1, s0
1000b63ac:     	str	s0, [x3]
1000b63b0:     	ldr	w5, [x7, #4]
1000b63b4:     	and	x7, x5, #0xf
1000b63b8:     	ubfx	x19, x5, #4, #4
1000b63bc:     	ldrb	w14, [x14, x7]
1000b63c0:     	ldrb	w12, [x12, x19]
1000b63c4:     	ubfx	x7, x5, #8, #4
1000b63c8:     	ubfx	x19, x5, #12, #4
1000b63cc:     	ldrb	w13, [x13, x7]
1000b63d0:     	ldrb	w16, [x16, x19]
1000b63d4:     	ubfx	x7, x5, #16, #4
1000b63d8:     	ldrb	w15, [x15, x7]
1000b63dc:     	add	w12, w14, w12
1000b63e0:     	add	w12, w12, w13
1000b63e4:     	ubfx	x13, x5, #20, #4
1000b63e8:     	ldrb	w13, [x17, x13]
1000b63ec:     	add	w12, w12, w16
1000b63f0:     	add	w12, w12, w15
1000b63f4:     	ubfx	x14, x5, #24, #4
1000b63f8:     	ldrb	w14, [x4, x14]
1000b63fc:     	lsr	x15, x5, #28
1000b6400:     	add	w12, w12, w13
1000b6404:     	add	w12, w12, w14
1000b6408:     	ldrb	w13, [x6, x15]
1000b640c:     	add	w12, w12, w13
1000b6410:     	scvtf	s1, w12
1000b6414:     	fadd	s1, s2, s1
1000b6418:     	str	s1, [x3, #4]
1000b641c:     	add	x12, x10, #8
1000b6420:     	add	x11, x11, x8
1000b6424:     	add	x13, x10, #16
1000b6428:     	mov	x10, x12
1000b642c:     	cmp	x13, x2
1000b6430:     	b.ls	0x1000b62dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b6434:     	cmp	x12, x2
1000b6438:     	b.hs	0x1000b64e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x240>
1000b643c:     	lsl	w9, w12, #2
1000b6440:     	mov	w10, #-16
1000b6444:     	lsr	x11, x12, #3
1000b6448:     	mul	x11, x8, x11
1000b644c:     	ubfx	x13, x12, #1, #2
1000b6450:     	orr	x11, x11, x13
1000b6454:     	and	w13, w9, #0x4
1000b6458:     	ldrb	w11, [x1, x11]
1000b645c:     	lsr	w11, w11, w13
1000b6460:     	and	w14, w11, #0xf
1000b6464:     	cmp	w14, #8
1000b6468:     	csel	w14, wzr, w10, lo
1000b646c:     	and	x15, x12, #0xfffffffffffffff8
1000b6470:     	bfxil	w14, w11, #0, #4
1000b6474:     	bfxil	x15, x12, #1, #2
1000b6478:     	add	x11, x0, x15
1000b647c:     	ldrb	w15, [x11]
1000b6480:     	lsr	w15, w15, w13
1000b6484:     	scvtf	s2, w14
1000b6488:     	and	w14, w15, #0xf
1000b648c:     	cmp	w14, #8
1000b6490:     	csel	w14, wzr, w10, lo
1000b6494:     	bfxil	w14, w15, #0, #4
1000b6498:     	scvtf	s3, w14
1000b649c:     	fsub	s3, s3, s2
1000b64a0:     	fmadd	s0, s3, s3, s0
1000b64a4:     	str	s0, [x3]
1000b64a8:     	ldrb	w11, [x11, #4]
1000b64ac:     	lsr	w11, w11, w13
1000b64b0:     	and	w13, w11, #0xf
1000b64b4:     	cmp	w13, #8
1000b64b8:     	csel	w13, wzr, w10, lo
1000b64bc:     	bfxil	w13, w11, #0, #4
1000b64c0:     	scvtf	s3, w13
1000b64c4:     	fsub	s2, s3, s2
1000b64c8:     	fmadd	s1, s2, s2, s1
1000b64cc:     	str	s1, [x3, #4]
1000b64d0:     	add	x12, x12, #1
1000b64d4:     	add	w9, w9, #4
1000b64d8:     	cmp	x2, x12
1000b64dc:     	b.ne	0x1000b6444 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b64e0:     	ldp	x20, x19, [sp, #32]
1000b64e4:     	ldp	x22, x21, [sp, #16]
1000b64e8:     	ldp	x24, x23, [sp], #48
1000b64ec:     	ret

00000001000b650c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b650c:     	stp	x24, x23, [sp, #-48]!
1000b6510:     	stp	x22, x21, [sp, #16]
1000b6514:     	stp	x20, x19, [sp, #32]
1000b6518:     	str	xzr, [x3]
1000b651c:     	lsl	x8, x4, #2
1000b6520:     	cmp	x2, #8
1000b6524:     	b.hs	0x1000b6538 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b6528:     	mov	x12, #0
1000b652c:     	movi	d1, #0000000000000000
1000b6530:     	movi	d0, #0000000000000000
1000b6534:     	b	0x1000b66a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b6538:     	mov	x10, #0
1000b653c:     	adrp	x9, 0x100169000 <void run<unsigned char, 2ul, 2ul, false>(char const*)+0xb4>
1000b6540:     	add	x9, x9, #4028
1000b6544:     	mov	x11, x1
1000b6548:     	ldr	w4, [x11]
1000b654c:     	lsl	w12, w4, #4
1000b6550:     	and	x13, x12, #0xf0
1000b6554:     	and	x12, x4, #0xf0
1000b6558:     	add	x12, x9, x12
1000b655c:     	lsr	x14, x4, #4
1000b6560:     	and	x15, x14, #0xf0
1000b6564:     	add	x14, x9, x13
1000b6568:     	add	x13, x9, x15
1000b656c:     	lsr	x15, x4, #8
1000b6570:     	and	x15, x15, #0xf0
1000b6574:     	lsr	x16, x4, #12
1000b6578:     	and	x17, x16, #0xf0
1000b657c:     	add	x16, x9, x15
1000b6580:     	add	x15, x9, x17
1000b6584:     	lsr	x17, x4, #16
1000b6588:     	and	x17, x17, #0xf0
1000b658c:     	lsr	x5, x4, #20
1000b6590:     	and	x5, x5, #0xf0
1000b6594:     	add	x17, x9, x17
1000b6598:     	lsr	x4, x4, #24
1000b659c:     	and	x6, x4, #0xf0
1000b65a0:     	add	x7, x0, x10
1000b65a4:     	ldr	w19, [x7]
1000b65a8:     	and	x20, x19, #0xf
1000b65ac:     	add	x4, x9, x5
1000b65b0:     	ldrsb	w5, [x14, x20]
1000b65b4:     	ubfx	x20, x19, #4, #4
1000b65b8:     	ubfx	x21, x19, #8, #4
1000b65bc:     	ldrsb	w20, [x12, x20]
1000b65c0:     	ldrsb	w21, [x13, x21]
1000b65c4:     	ubfx	x22, x19, #12, #4
1000b65c8:     	ubfx	x23, x19, #16, #4
1000b65cc:     	ldrsb	w22, [x16, x22]
1000b65d0:     	ldrsb	w23, [x15, x23]
1000b65d4:     	ubfx	x24, x19, #20, #4
1000b65d8:     	ldrsb	w24, [x17, x24]
1000b65dc:     	add	w5, w5, w20
1000b65e0:     	add	w5, w5, w21
1000b65e4:     	ubfx	x20, x19, #24, #4
1000b65e8:     	ldrsb	w20, [x4, x20]
1000b65ec:     	add	w5, w5, w22
1000b65f0:     	add	w5, w5, w23
1000b65f4:     	add	x6, x9, x6
1000b65f8:     	lsr	x19, x19, #28
1000b65fc:     	ldrsb	w19, [x6, x19]
1000b6600:     	add	w5, w5, w24
1000b6604:     	add	w5, w5, w20
1000b6608:     	add	w5, w5, w19
1000b660c:     	scvtf	s0, w5
1000b6610:     	ldp	s1, s2, [x3]
1000b6614:     	fadd	s0, s1, s0
1000b6618:     	str	s0, [x3]
1000b661c:     	ldr	w5, [x7, #4]
1000b6620:     	and	x7, x5, #0xf
1000b6624:     	ubfx	x19, x5, #4, #4
1000b6628:     	ldrsb	w14, [x14, x7]
1000b662c:     	ldrsb	w12, [x12, x19]
1000b6630:     	ubfx	x7, x5, #8, #4
1000b6634:     	ubfx	x19, x5, #12, #4
1000b6638:     	ldrsb	w13, [x13, x7]
1000b663c:     	ldrsb	w16, [x16, x19]
1000b6640:     	ubfx	x7, x5, #16, #4
1000b6644:     	ldrsb	w15, [x15, x7]
1000b6648:     	add	w12, w14, w12
1000b664c:     	add	w12, w12, w13
1000b6650:     	ubfx	x13, x5, #20, #4
1000b6654:     	ldrsb	w13, [x17, x13]
1000b6658:     	add	w12, w12, w16
1000b665c:     	add	w12, w12, w15
1000b6660:     	ubfx	x14, x5, #24, #4
1000b6664:     	ldrsb	w14, [x4, x14]
1000b6668:     	lsr	x15, x5, #28
1000b666c:     	add	w12, w12, w13
1000b6670:     	add	w12, w12, w14
1000b6674:     	ldrsb	w13, [x6, x15]
1000b6678:     	add	w12, w12, w13
1000b667c:     	scvtf	s1, w12
1000b6680:     	fadd	s1, s2, s1
1000b6684:     	str	s1, [x3, #4]
1000b6688:     	add	x12, x10, #8
1000b668c:     	add	x11, x11, x8
1000b6690:     	add	x13, x10, #16
1000b6694:     	mov	x10, x12
1000b6698:     	cmp	x13, x2
1000b669c:     	b.ls	0x1000b6548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b66a0:     	cmp	x12, x2
1000b66a4:     	b.hs	0x1000b6744 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x238>
1000b66a8:     	lsl	w9, w12, #2
1000b66ac:     	mov	w10, #-16
1000b66b0:     	lsr	x11, x12, #3
1000b66b4:     	mul	x11, x8, x11
1000b66b8:     	ubfx	x13, x12, #1, #2
1000b66bc:     	orr	x11, x11, x13
1000b66c0:     	ldrb	w11, [x1, x11]
1000b66c4:     	and	w13, w9, #0x4
1000b66c8:     	lsr	w11, w11, w13
1000b66cc:     	and	w14, w11, #0xf
1000b66d0:     	cmp	w14, #8
1000b66d4:     	csel	w14, wzr, w10, lo
1000b66d8:     	and	x15, x12, #0xfffffffffffffff8
1000b66dc:     	bfxil	x15, x12, #1, #2
1000b66e0:     	add	x15, x0, x15
1000b66e4:     	ldrb	w16, [x15]
1000b66e8:     	lsr	w16, w16, w13
1000b66ec:     	bfxil	w14, w11, #0, #4
1000b66f0:     	and	w11, w16, #0xf
1000b66f4:     	cmp	w11, #8
1000b66f8:     	csel	w11, wzr, w10, lo
1000b66fc:     	bfxil	w11, w16, #0, #4
1000b6700:     	scvtf	s2, w14
1000b6704:     	scvtf	s3, w11
1000b6708:     	fmsub	s0, s3, s2, s0
1000b670c:     	str	s0, [x3]
1000b6710:     	ldrb	w11, [x15, #4]
1000b6714:     	lsr	w11, w11, w13
1000b6718:     	and	w13, w11, #0xf
1000b671c:     	cmp	w13, #8
1000b6720:     	csel	w13, wzr, w10, lo
1000b6724:     	bfxil	w13, w11, #0, #4
1000b6728:     	scvtf	s3, w13
1000b672c:     	fmsub	s1, s3, s2, s1
1000b6730:     	str	s1, [x3, #4]
1000b6734:     	add	x12, x12, #1
1000b6738:     	add	w9, w9, #4
1000b673c:     	cmp	x2, x12
1000b6740:     	b.ne	0x1000b66b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b6744:     	ldp	x20, x19, [sp, #32]
1000b6748:     	ldp	x22, x21, [sp, #16]
1000b674c:     	ldp	x24, x23, [sp], #48
1000b6750:     	ret

00000001000b7e0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b7e0c:     	stp	x22, x21, [sp, #-32]!
1000b7e10:     	stp	x20, x19, [sp, #16]
1000b7e14:     	ands	x8, x2, #0xfffffffffffffffe
1000b7e18:     	b.eq	0x1000b809c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b7e1c:     	add	x8, x1, x8
1000b7e20:     	movi	d0, #0000000000000000
1000b7e24:     	adrp	x9, 0x100169000 <void kernel<unsigned char, 2ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24>
1000b7e28:     	add	x9, x9, #3772
1000b7e2c:     	movi	d1, #0000000000000000
1000b7e30:     	movi	d2, #0000000000000000
1000b7e34:     	movi	d3, #0000000000000000
1000b7e38:     	ldp	w10, w11, [x0]
1000b7e3c:     	lsl	w12, w10, #4
1000b7e40:     	and	x14, x12, #0xf0
1000b7e44:     	mov	x15, x14
1000b7e48:     	ldp	w12, w13, [x1]
1000b7e4c:     	bfxil	x15, x12, #0, #4
1000b7e50:     	ldrb	w15, [x9, x15]
1000b7e54:     	and	x16, x10, #0xf0
1000b7e58:     	mov	x17, x16
1000b7e5c:     	bfxil	x17, x12, #4, #4
1000b7e60:     	ldrb	w17, [x9, x17]
1000b7e64:     	lsr	x2, x10, #4
1000b7e68:     	and	x2, x2, #0xf0
1000b7e6c:     	mov	x4, x2
1000b7e70:     	bfxil	x4, x12, #8, #4
1000b7e74:     	ldrb	w4, [x9, x4]
1000b7e78:     	lsr	x5, x10, #8
1000b7e7c:     	and	x5, x5, #0xf0
1000b7e80:     	mov	x6, x5
1000b7e84:     	bfxil	x6, x12, #12, #4
1000b7e88:     	ldrb	w6, [x9, x6]
1000b7e8c:     	lsr	x7, x10, #12
1000b7e90:     	and	x7, x7, #0xf0
1000b7e94:     	mov	x19, x7
1000b7e98:     	bfxil	x19, x12, #16, #4
1000b7e9c:     	ldrb	w19, [x9, x19]
1000b7ea0:     	add	w15, w15, w17
1000b7ea4:     	add	w15, w15, w4
1000b7ea8:     	lsr	x17, x10, #16
1000b7eac:     	and	x17, x17, #0xf0
1000b7eb0:     	mov	x4, x17
1000b7eb4:     	bfxil	x4, x12, #20, #4
1000b7eb8:     	add	w15, w15, w6
1000b7ebc:     	add	w15, w15, w19
1000b7ec0:     	ldrb	w4, [x9, x4]
1000b7ec4:     	lsr	x6, x10, #20
1000b7ec8:     	and	x6, x6, #0xf0
1000b7ecc:     	mov	x19, x6
1000b7ed0:     	bfxil	x19, x12, #24, #4
1000b7ed4:     	ldrb	w19, [x9, x19]
1000b7ed8:     	add	w15, w15, w4
1000b7edc:     	add	w15, w15, w19
1000b7ee0:     	lsr	x10, x10, #24
1000b7ee4:     	and	x4, x10, #0xf0
1000b7ee8:     	lsr	x10, x12, #28
1000b7eec:     	orr	x19, x4, x10
1000b7ef0:     	ldrb	w19, [x9, x19]
1000b7ef4:     	add	w15, w15, w19
1000b7ef8:     	scvtf	s4, w15
1000b7efc:     	fadd	s0, s0, s4
1000b7f00:     	bfxil	x14, x13, #0, #4
1000b7f04:     	ldrb	w14, [x9, x14]
1000b7f08:     	and	x15, x13, #0xf
1000b7f0c:     	ubfx	x19, x13, #4, #4
1000b7f10:     	bfxil	x16, x13, #4, #4
1000b7f14:     	ldrb	w16, [x9, x16]
1000b7f18:     	ubfx	x20, x13, #8, #4
1000b7f1c:     	bfxil	x2, x13, #8, #4
1000b7f20:     	ldrb	w2, [x9, x2]
1000b7f24:     	add	w14, w14, w16
1000b7f28:     	add	w14, w14, w2
1000b7f2c:     	ubfx	x16, x13, #12, #4
1000b7f30:     	bfxil	x5, x13, #12, #4
1000b7f34:     	ldrb	w2, [x9, x5]
1000b7f38:     	bfxil	x7, x13, #16, #4
1000b7f3c:     	ldrb	w5, [x9, x7]
1000b7f40:     	ubfx	x7, x13, #16, #4
1000b7f44:     	add	w14, w14, w2
1000b7f48:     	add	w14, w14, w5
1000b7f4c:     	bfxil	x17, x13, #20, #4
1000b7f50:     	ldrb	w17, [x9, x17]
1000b7f54:     	bfxil	x6, x13, #24, #4
1000b7f58:     	ldrb	w2, [x9, x6]
1000b7f5c:     	add	w14, w14, w17
1000b7f60:     	add	w17, w14, w2
1000b7f64:     	lsr	x14, x13, #28
1000b7f68:     	orr	x2, x4, x14
1000b7f6c:     	ldrb	w2, [x9, x2]
1000b7f70:     	add	w17, w17, w2
1000b7f74:     	scvtf	s4, w17
1000b7f78:     	ubfx	x17, x13, #20, #4
1000b7f7c:     	fadd	s2, s2, s4
1000b7f80:     	lsl	w2, w11, #4
1000b7f84:     	and	x2, x2, #0xf0
1000b7f88:     	orr	w15, w2, w15
1000b7f8c:     	bfxil	x2, x12, #0, #4
1000b7f90:     	ldrb	w2, [x9, x2]
1000b7f94:     	and	x4, x11, #0xf0
1000b7f98:     	orr	w5, w4, w19
1000b7f9c:     	bfxil	x4, x12, #4, #4
1000b7fa0:     	ldrb	w4, [x9, x4]
1000b7fa4:     	lsr	x6, x11, #4
1000b7fa8:     	and	x6, x6, #0xf0
1000b7fac:     	orr	w19, w6, w20
1000b7fb0:     	bfxil	x6, x12, #8, #4
1000b7fb4:     	ldrb	w6, [x9, x6]
1000b7fb8:     	add	w2, w2, w4
1000b7fbc:     	add	w2, w2, w6
1000b7fc0:     	lsr	x4, x11, #8
1000b7fc4:     	and	x4, x4, #0xf0
1000b7fc8:     	orr	w16, w4, w16
1000b7fcc:     	lsr	x6, x11, #12
1000b7fd0:     	and	x6, x6, #0xf0
1000b7fd4:     	orr	w7, w6, w7
1000b7fd8:     	lsr	x20, x11, #16
1000b7fdc:     	and	x20, x20, #0xf0
1000b7fe0:     	orr	w17, w20, w17
1000b7fe4:     	lsr	x21, x11, #20
1000b7fe8:     	and	x21, x21, #0xf0
1000b7fec:     	ubfx	x13, x13, #24, #4
1000b7ff0:     	orr	w13, w21, w13
1000b7ff4:     	bfxil	x4, x12, #12, #4
1000b7ff8:     	ldrb	w4, [x9, x4]
1000b7ffc:     	bfxil	x6, x12, #16, #4
1000b8000:     	ldrb	w6, [x9, x6]
1000b8004:     	bfxil	x20, x12, #20, #4
1000b8008:     	ldrb	w20, [x9, x20]
1000b800c:     	bfxil	x21, x12, #24, #4
1000b8010:     	ldrb	w12, [x9, x21]
1000b8014:     	add	w2, w2, w4
1000b8018:     	add	w2, w2, w6
1000b801c:     	add	w2, w2, w20
1000b8020:     	add	w12, w2, w12
1000b8024:     	lsr	x11, x11, #24
1000b8028:     	and	x11, x11, #0xf0
1000b802c:     	orr	x10, x11, x10
1000b8030:     	ldrb	w10, [x9, x10]
1000b8034:     	add	w10, w12, w10
1000b8038:     	scvtf	s4, w10
1000b803c:     	fadd	s1, s1, s4
1000b8040:     	ldrb	w10, [x9, w15, uxtw]
1000b8044:     	ldrb	w12, [x9, w5, uxtw]
1000b8048:     	ldrb	w15, [x9, w19, uxtw]
1000b804c:     	add	w10, w10, w12
1000b8050:     	add	w10, w10, w15
1000b8054:     	ldrb	w12, [x9, w16, uxtw]
1000b8058:     	ldrb	w15, [x9, w7, uxtw]
1000b805c:     	add	w10, w10, w12
1000b8060:     	add	w10, w10, w15
1000b8064:     	ldrb	w12, [x9, w17, uxtw]
1000b8068:     	ldrb	w13, [x9, w13, uxtw]
1000b806c:     	add	w10, w10, w12
1000b8070:     	add	w10, w10, w13
1000b8074:     	orr	w11, w11, w14
1000b8078:     	ldrb	w11, [x9, w11, uxtw]
1000b807c:     	add	w10, w10, w11
1000b8080:     	scvtf	s4, w10
1000b8084:     	fadd	s3, s3, s4
1000b8088:     	add	x0, x0, #8
1000b808c:     	add	x1, x1, #8
1000b8090:     	cmp	x1, x8
1000b8094:     	b.ne	0x1000b7e38 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8098:     	b	0x1000b80ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b809c:     	movi	d0, #0000000000000000
1000b80a0:     	movi	d1, #0000000000000000
1000b80a4:     	movi	d2, #0000000000000000
1000b80a8:     	movi	d3, #0000000000000000
1000b80ac:     	str	s0, [x3]
1000b80b0:     	str	s1, [x3, #4]
1000b80b4:     	str	s2, [x3, #8]
1000b80b8:     	str	s3, [x3, #12]
1000b80bc:     	ldp	x20, x19, [sp, #16]
1000b80c0:     	ldp	x22, x21, [sp], #32
1000b80c4:     	ret

00000001000b8174 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b8174:     	stp	x22, x21, [sp, #-32]!
1000b8178:     	stp	x20, x19, [sp, #16]
1000b817c:     	ands	x8, x2, #0xfffffffffffffffe
1000b8180:     	b.eq	0x1000b8404 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b8184:     	add	x8, x1, x8
1000b8188:     	movi	d0, #0000000000000000
1000b818c:     	adrp	x9, 0x100169000 <void run<unsigned char, 4ul, 1ul, false>(char const*)+0x20>
1000b8190:     	add	x9, x9, #4028
1000b8194:     	movi	d1, #0000000000000000
1000b8198:     	movi	d2, #0000000000000000
1000b819c:     	movi	d3, #0000000000000000
1000b81a0:     	ldp	w10, w11, [x0]
1000b81a4:     	lsl	w12, w10, #4
1000b81a8:     	and	x14, x12, #0xf0
1000b81ac:     	mov	x15, x14
1000b81b0:     	ldp	w12, w13, [x1]
1000b81b4:     	bfxil	x15, x12, #0, #4
1000b81b8:     	ldrsb	w15, [x9, x15]
1000b81bc:     	and	x16, x10, #0xf0
1000b81c0:     	mov	x17, x16
1000b81c4:     	bfxil	x17, x12, #4, #4
1000b81c8:     	ldrsb	w17, [x9, x17]
1000b81cc:     	lsr	x2, x10, #4
1000b81d0:     	and	x2, x2, #0xf0
1000b81d4:     	mov	x4, x2
1000b81d8:     	bfxil	x4, x12, #8, #4
1000b81dc:     	ldrsb	w4, [x9, x4]
1000b81e0:     	lsr	x5, x10, #8
1000b81e4:     	and	x5, x5, #0xf0
1000b81e8:     	mov	x6, x5
1000b81ec:     	bfxil	x6, x12, #12, #4
1000b81f0:     	ldrsb	w6, [x9, x6]
1000b81f4:     	lsr	x7, x10, #12
1000b81f8:     	and	x7, x7, #0xf0
1000b81fc:     	mov	x19, x7
1000b8200:     	bfxil	x19, x12, #16, #4
1000b8204:     	ldrsb	w19, [x9, x19]
1000b8208:     	add	w15, w15, w17
1000b820c:     	add	w15, w15, w4
1000b8210:     	lsr	x17, x10, #16
1000b8214:     	and	x17, x17, #0xf0
1000b8218:     	mov	x4, x17
1000b821c:     	bfxil	x4, x12, #20, #4
1000b8220:     	add	w15, w15, w6
1000b8224:     	add	w15, w15, w19
1000b8228:     	ldrsb	w4, [x9, x4]
1000b822c:     	lsr	x6, x10, #20
1000b8230:     	and	x6, x6, #0xf0
1000b8234:     	mov	x19, x6
1000b8238:     	bfxil	x19, x12, #24, #4
1000b823c:     	ldrsb	w19, [x9, x19]
1000b8240:     	add	w15, w15, w4
1000b8244:     	add	w15, w15, w19
1000b8248:     	lsr	x10, x10, #24
1000b824c:     	and	x4, x10, #0xf0
1000b8250:     	lsr	x10, x12, #28
1000b8254:     	orr	x19, x4, x10
1000b8258:     	ldrsb	w19, [x9, x19]
1000b825c:     	add	w15, w15, w19
1000b8260:     	scvtf	s4, w15
1000b8264:     	fadd	s0, s0, s4
1000b8268:     	bfxil	x14, x13, #0, #4
1000b826c:     	ldrsb	w14, [x9, x14]
1000b8270:     	and	x15, x13, #0xf
1000b8274:     	ubfx	x19, x13, #4, #4
1000b8278:     	bfxil	x16, x13, #4, #4
1000b827c:     	ldrsb	w16, [x9, x16]
1000b8280:     	ubfx	x20, x13, #8, #4
1000b8284:     	bfxil	x2, x13, #8, #4
1000b8288:     	ldrsb	w2, [x9, x2]
1000b828c:     	add	w14, w14, w16
1000b8290:     	add	w14, w14, w2
1000b8294:     	ubfx	x16, x13, #12, #4
1000b8298:     	bfxil	x5, x13, #12, #4
1000b829c:     	ldrsb	w2, [x9, x5]
1000b82a0:     	bfxil	x7, x13, #16, #4
1000b82a4:     	ldrsb	w5, [x9, x7]
1000b82a8:     	ubfx	x7, x13, #16, #4
1000b82ac:     	add	w14, w14, w2
1000b82b0:     	add	w14, w14, w5
1000b82b4:     	bfxil	x17, x13, #20, #4
1000b82b8:     	ldrsb	w17, [x9, x17]
1000b82bc:     	bfxil	x6, x13, #24, #4
1000b82c0:     	ldrsb	w2, [x9, x6]
1000b82c4:     	add	w14, w14, w17
1000b82c8:     	add	w17, w14, w2
1000b82cc:     	lsr	x14, x13, #28
1000b82d0:     	orr	x2, x4, x14
1000b82d4:     	ldrsb	w2, [x9, x2]
1000b82d8:     	add	w17, w17, w2
1000b82dc:     	scvtf	s4, w17
1000b82e0:     	ubfx	x17, x13, #20, #4
1000b82e4:     	fadd	s2, s2, s4
1000b82e8:     	lsl	w2, w11, #4
1000b82ec:     	and	x2, x2, #0xf0
1000b82f0:     	orr	w15, w2, w15
1000b82f4:     	bfxil	x2, x12, #0, #4
1000b82f8:     	ldrsb	w2, [x9, x2]
1000b82fc:     	and	x4, x11, #0xf0
1000b8300:     	orr	w5, w4, w19
1000b8304:     	bfxil	x4, x12, #4, #4
1000b8308:     	ldrsb	w4, [x9, x4]
1000b830c:     	lsr	x6, x11, #4
1000b8310:     	and	x6, x6, #0xf0
1000b8314:     	orr	w19, w6, w20
1000b8318:     	bfxil	x6, x12, #8, #4
1000b831c:     	ldrsb	w6, [x9, x6]
1000b8320:     	add	w2, w2, w4
1000b8324:     	add	w2, w2, w6
1000b8328:     	lsr	x4, x11, #8
1000b832c:     	and	x4, x4, #0xf0
1000b8330:     	orr	w16, w4, w16
1000b8334:     	lsr	x6, x11, #12
1000b8338:     	and	x6, x6, #0xf0
1000b833c:     	orr	w7, w6, w7
1000b8340:     	lsr	x20, x11, #16
1000b8344:     	and	x20, x20, #0xf0
1000b8348:     	orr	w17, w20, w17
1000b834c:     	lsr	x21, x11, #20
1000b8350:     	and	x21, x21, #0xf0
1000b8354:     	ubfx	x13, x13, #24, #4
1000b8358:     	orr	w13, w21, w13
1000b835c:     	bfxil	x4, x12, #12, #4
1000b8360:     	ldrsb	w4, [x9, x4]
1000b8364:     	bfxil	x6, x12, #16, #4
1000b8368:     	ldrsb	w6, [x9, x6]
1000b836c:     	bfxil	x20, x12, #20, #4
1000b8370:     	ldrsb	w20, [x9, x20]
1000b8374:     	bfxil	x21, x12, #24, #4
1000b8378:     	ldrsb	w12, [x9, x21]
1000b837c:     	add	w2, w2, w4
1000b8380:     	add	w2, w2, w6
1000b8384:     	add	w2, w2, w20
1000b8388:     	add	w12, w2, w12
1000b838c:     	lsr	x11, x11, #24
1000b8390:     	and	x11, x11, #0xf0
1000b8394:     	orr	x10, x11, x10
1000b8398:     	ldrsb	w10, [x9, x10]
1000b839c:     	add	w10, w12, w10
1000b83a0:     	scvtf	s4, w10
1000b83a4:     	fadd	s1, s1, s4
1000b83a8:     	ldrsb	w10, [x9, w15, uxtw]
1000b83ac:     	ldrsb	w12, [x9, w5, uxtw]
1000b83b0:     	ldrsb	w15, [x9, w19, uxtw]
1000b83b4:     	add	w10, w10, w12
1000b83b8:     	add	w10, w10, w15
1000b83bc:     	ldrsb	w12, [x9, w16, uxtw]
1000b83c0:     	ldrsb	w15, [x9, w7, uxtw]
1000b83c4:     	add	w10, w10, w12
1000b83c8:     	add	w10, w10, w15
1000b83cc:     	ldrsb	w12, [x9, w17, uxtw]
1000b83d0:     	ldrsb	w13, [x9, w13, uxtw]
1000b83d4:     	add	w10, w10, w12
1000b83d8:     	add	w10, w10, w13
1000b83dc:     	orr	w11, w11, w14
1000b83e0:     	ldrsb	w11, [x9, w11, uxtw]
1000b83e4:     	add	w10, w10, w11
1000b83e8:     	scvtf	s4, w10
1000b83ec:     	fadd	s3, s3, s4
1000b83f0:     	add	x0, x0, #8
1000b83f4:     	add	x1, x1, #8
1000b83f8:     	cmp	x1, x8
1000b83fc:     	b.ne	0x1000b81a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8400:     	b	0x1000b8414 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b8404:     	movi	d0, #0000000000000000
1000b8408:     	movi	d1, #0000000000000000
1000b840c:     	movi	d2, #0000000000000000
1000b8410:     	movi	d3, #0000000000000000
1000b8414:     	str	s0, [x3]
1000b8418:     	str	s1, [x3, #4]
1000b841c:     	str	s2, [x3, #8]
1000b8420:     	str	s3, [x3, #12]
1000b8424:     	ldp	x20, x19, [sp, #16]
1000b8428:     	ldp	x22, x21, [sp], #32
1000b842c:     	ret

00000001000b9704 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b9704:     	stp	x24, x23, [sp, #-48]!
1000b9708:     	stp	x22, x21, [sp, #16]
1000b970c:     	stp	x20, x19, [sp, #32]
1000b9710:     	stp	xzr, xzr, [x3]
1000b9714:     	lsl	x8, x4, #2
1000b9718:     	cmp	x2, #8
1000b971c:     	b.hs	0x1000b9730 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b9720:     	mov	x13, #0
1000b9724:     	movi	d1, #0000000000000000
1000b9728:     	movi	d0, #0000000000000000
1000b972c:     	b	0x1000b9978 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000b9730:     	mov	x10, #0
1000b9734:     	add	x9, x0, #8
1000b9738:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f8>
1000b973c:     	add	x11, x11, #188
1000b9740:     	mov	x12, x1
1000b9744:     	ldr	w5, [x12]
1000b9748:     	lsl	w13, w5, #4
1000b974c:     	and	x14, x13, #0xf0
1000b9750:     	and	x13, x5, #0xf0
1000b9754:     	add	x13, x11, x13
1000b9758:     	add	x14, x11, x14
1000b975c:     	lsr	x15, x5, #4
1000b9760:     	and	x15, x15, #0xf0
1000b9764:     	add	x15, x11, x15
1000b9768:     	lsr	x16, x5, #8
1000b976c:     	and	x16, x16, #0xf0
1000b9770:     	add	x16, x11, x16
1000b9774:     	lsr	x17, x5, #12
1000b9778:     	and	x17, x17, #0xf0
1000b977c:     	add	x17, x11, x17
1000b9780:     	lsr	x4, x5, #16
1000b9784:     	and	x4, x4, #0xf0
1000b9788:     	add	x4, x11, x4
1000b978c:     	lsr	x6, x5, #20
1000b9790:     	and	x6, x6, #0xf0
1000b9794:     	lsr	x5, x5, #24
1000b9798:     	and	x7, x5, #0xf0
1000b979c:     	ldur	w19, [x9, #-8]
1000b97a0:     	add	x5, x11, x6
1000b97a4:     	and	x6, x19, #0xf
1000b97a8:     	ubfx	x20, x19, #4, #4
1000b97ac:     	ldrb	w20, [x13, x20]
1000b97b0:     	ldrb	w21, [x14, x6]
1000b97b4:     	ubfx	x6, x19, #8, #4
1000b97b8:     	ldrb	w22, [x15, x6]
1000b97bc:     	ubfx	x6, x19, #12, #4
1000b97c0:     	ldrb	w23, [x16, x6]
1000b97c4:     	add	x6, x11, x7
1000b97c8:     	ubfx	x7, x19, #16, #4
1000b97cc:     	ldrb	w7, [x17, x7]
1000b97d0:     	add	w20, w21, w20
1000b97d4:     	add	w20, w20, w22
1000b97d8:     	ubfx	x21, x19, #20, #4
1000b97dc:     	ldrb	w21, [x4, x21]
1000b97e0:     	ubfx	x22, x19, #24, #4
1000b97e4:     	add	w20, w20, w23
1000b97e8:     	add	w7, w20, w7
1000b97ec:     	ldrb	w20, [x5, x22]
1000b97f0:     	lsr	x19, x19, #28
1000b97f4:     	ldrb	w19, [x6, x19]
1000b97f8:     	add	w7, w7, w21
1000b97fc:     	add	w7, w7, w20
1000b9800:     	add	w7, w7, w19
1000b9804:     	scvtf	s0, w7
1000b9808:     	ldp	s1, s2, [x3]
1000b980c:     	fadd	s0, s1, s0
1000b9810:     	str	s0, [x3]
1000b9814:     	ldur	w7, [x9, #-4]
1000b9818:     	and	x19, x7, #0xf
1000b981c:     	ldrb	w19, [x14, x19]
1000b9820:     	ubfx	x20, x7, #4, #4
1000b9824:     	ldrb	w20, [x13, x20]
1000b9828:     	ubfx	x21, x7, #8, #4
1000b982c:     	ldrb	w21, [x15, x21]
1000b9830:     	ubfx	x22, x7, #12, #4
1000b9834:     	ldrb	w22, [x16, x22]
1000b9838:     	ubfx	x23, x7, #16, #4
1000b983c:     	add	w19, w19, w20
1000b9840:     	add	w19, w19, w21
1000b9844:     	ldrb	w20, [x17, x23]
1000b9848:     	ubfx	x21, x7, #20, #4
1000b984c:     	ldrb	w21, [x4, x21]
1000b9850:     	add	w19, w19, w22
1000b9854:     	add	w19, w19, w20
1000b9858:     	ubfx	x20, x7, #24, #4
1000b985c:     	ldrb	w20, [x5, x20]
1000b9860:     	add	w19, w19, w21
1000b9864:     	add	w19, w19, w20
1000b9868:     	lsr	x7, x7, #28
1000b986c:     	ldrb	w7, [x6, x7]
1000b9870:     	add	w7, w19, w7
1000b9874:     	scvtf	s0, w7
1000b9878:     	fadd	s0, s2, s0
1000b987c:     	str	s0, [x3, #4]
1000b9880:     	ldr	w7, [x9]
1000b9884:     	and	x19, x7, #0xf
1000b9888:     	ldrb	w19, [x14, x19]
1000b988c:     	ubfx	x20, x7, #4, #4
1000b9890:     	ldrb	w20, [x13, x20]
1000b9894:     	ubfx	x21, x7, #8, #4
1000b9898:     	ldrb	w21, [x15, x21]
1000b989c:     	ubfx	x22, x7, #12, #4
1000b98a0:     	ldrb	w22, [x16, x22]
1000b98a4:     	ubfx	x23, x7, #16, #4
1000b98a8:     	add	w19, w19, w20
1000b98ac:     	add	w19, w19, w21
1000b98b0:     	ldrb	w20, [x17, x23]
1000b98b4:     	ubfx	x21, x7, #20, #4
1000b98b8:     	ldrb	w21, [x4, x21]
1000b98bc:     	add	w19, w19, w22
1000b98c0:     	add	w19, w19, w20
1000b98c4:     	ubfx	x20, x7, #24, #4
1000b98c8:     	ldrb	w20, [x5, x20]
1000b98cc:     	add	w19, w19, w21
1000b98d0:     	add	w19, w19, w20
1000b98d4:     	lsr	x7, x7, #28
1000b98d8:     	ldrb	w7, [x6, x7]
1000b98dc:     	add	w7, w19, w7
1000b98e0:     	scvtf	s0, w7
1000b98e4:     	ldp	s1, s2, [x3, #8]
1000b98e8:     	fadd	s0, s1, s0
1000b98ec:     	str	s0, [x3, #8]
1000b98f0:     	ldr	w7, [x9, #4]
1000b98f4:     	and	x19, x7, #0xf
1000b98f8:     	ldrb	w14, [x14, x19]
1000b98fc:     	ubfx	x19, x7, #4, #4
1000b9900:     	ldrb	w13, [x13, x19]
1000b9904:     	ubfx	x19, x7, #8, #4
1000b9908:     	ldrb	w15, [x15, x19]
1000b990c:     	ubfx	x19, x7, #12, #4
1000b9910:     	ldrb	w16, [x16, x19]
1000b9914:     	ubfx	x19, x7, #16, #4
1000b9918:     	ldrb	w17, [x17, x19]
1000b991c:     	add	w13, w14, w13
1000b9920:     	add	w13, w13, w15
1000b9924:     	ubfx	x14, x7, #20, #4
1000b9928:     	ldrb	w14, [x4, x14]
1000b992c:     	ubfx	x15, x7, #24, #4
1000b9930:     	add	w13, w13, w16
1000b9934:     	add	w13, w13, w17
1000b9938:     	ldrb	w15, [x5, x15]
1000b993c:     	lsr	x16, x7, #28
1000b9940:     	ldrb	w16, [x6, x16]
1000b9944:     	add	w13, w13, w14
1000b9948:     	add	w13, w13, w15
1000b994c:     	add	w13, w13, w16
1000b9950:     	scvtf	s1, w13
1000b9954:     	fadd	s1, s2, s1
1000b9958:     	str	s1, [x3, #12]
1000b995c:     	add	x13, x10, #8
1000b9960:     	add	x12, x12, x8
1000b9964:     	add	x9, x9, #16
1000b9968:     	add	x14, x10, #16
1000b996c:     	mov	x10, x13
1000b9970:     	cmp	x14, x2
1000b9974:     	b.ls	0x1000b9744 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000b9978:     	cmp	x13, x2
1000b997c:     	b.hs	0x1000b9a74 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x370>
1000b9980:     	ldp	s2, s3, [x3]
1000b9984:     	lsl	w9, w13, #2
1000b9988:     	mov	w10, #-16
1000b998c:     	lsr	x11, x13, #3
1000b9990:     	mul	x12, x8, x11
1000b9994:     	ubfx	x14, x13, #1, #2
1000b9998:     	orr	x12, x12, x14
1000b999c:     	ldrb	w12, [x1, x12]
1000b99a0:     	and	w15, w9, #0x4
1000b99a4:     	lsr	w12, w12, w15
1000b99a8:     	and	w16, w12, #0xf
1000b99ac:     	cmp	w16, #8
1000b99b0:     	csel	w16, wzr, w10, lo
1000b99b4:     	bfxil	w16, w12, #0, #4
1000b99b8:     	bfi	x14, x11, #4, #60
1000b99bc:     	add	x11, x0, x14
1000b99c0:     	ldrb	w12, [x11]
1000b99c4:     	lsr	w12, w12, w15
1000b99c8:     	scvtf	s4, w16
1000b99cc:     	and	w14, w12, #0xf
1000b99d0:     	cmp	w14, #8
1000b99d4:     	csel	w14, wzr, w10, lo
1000b99d8:     	bfxil	w14, w12, #0, #4
1000b99dc:     	scvtf	s5, w14
1000b99e0:     	fsub	s5, s5, s4
1000b99e4:     	fmadd	s2, s5, s5, s2
1000b99e8:     	str	s2, [x3]
1000b99ec:     	ldrb	w12, [x11, #4]
1000b99f0:     	lsr	w12, w12, w15
1000b99f4:     	and	w14, w12, #0xf
1000b99f8:     	cmp	w14, #8
1000b99fc:     	csel	w14, wzr, w10, lo
1000b9a00:     	bfxil	w14, w12, #0, #4
1000b9a04:     	scvtf	s5, w14
1000b9a08:     	fsub	s5, s5, s4
1000b9a0c:     	fmadd	s3, s5, s5, s3
1000b9a10:     	str	s3, [x3, #4]
1000b9a14:     	ldrb	w12, [x11, #8]
1000b9a18:     	lsr	w12, w12, w15
1000b9a1c:     	and	w14, w12, #0xf
1000b9a20:     	cmp	w14, #8
1000b9a24:     	csel	w14, wzr, w10, lo
1000b9a28:     	bfxil	w14, w12, #0, #4
1000b9a2c:     	scvtf	s5, w14
1000b9a30:     	fsub	s5, s5, s4
1000b9a34:     	fmadd	s0, s5, s5, s0
1000b9a38:     	str	s0, [x3, #8]
1000b9a3c:     	ldrb	w11, [x11, #12]
1000b9a40:     	lsr	w11, w11, w15
1000b9a44:     	and	w12, w11, #0xf
1000b9a48:     	cmp	w12, #8
1000b9a4c:     	csel	w12, wzr, w10, lo
1000b9a50:     	bfxil	w12, w11, #0, #4
1000b9a54:     	scvtf	s5, w12
1000b9a58:     	fsub	s4, s5, s4
1000b9a5c:     	fmadd	s1, s4, s4, s1
1000b9a60:     	str	s1, [x3, #12]
1000b9a64:     	add	x13, x13, #1
1000b9a68:     	add	w9, w9, #4
1000b9a6c:     	cmp	x2, x13
1000b9a70:     	b.ne	0x1000b998c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000b9a74:     	ldp	x20, x19, [sp, #32]
1000b9a78:     	ldp	x22, x21, [sp, #16]
1000b9a7c:     	ldp	x24, x23, [sp], #48
1000b9a80:     	ret

00000001000b9aa0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b9aa0:     	stp	x24, x23, [sp, #-48]!
1000b9aa4:     	stp	x22, x21, [sp, #16]
1000b9aa8:     	stp	x20, x19, [sp, #32]
1000b9aac:     	stp	xzr, xzr, [x3]
1000b9ab0:     	lsl	x8, x4, #2
1000b9ab4:     	cmp	x2, #8
1000b9ab8:     	b.hs	0x1000b9acc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b9abc:     	mov	x13, #0
1000b9ac0:     	movi	d1, #0000000000000000
1000b9ac4:     	movi	d0, #0000000000000000
1000b9ac8:     	b	0x1000b9d14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000b9acc:     	mov	x10, #0
1000b9ad0:     	add	x9, x0, #8
1000b9ad4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f8>
1000b9ad8:     	add	x11, x11, #444
1000b9adc:     	mov	x12, x1
1000b9ae0:     	ldr	w5, [x12]
1000b9ae4:     	lsl	w13, w5, #4
1000b9ae8:     	and	x14, x13, #0xf0
1000b9aec:     	and	x13, x5, #0xf0
1000b9af0:     	add	x13, x11, x13
1000b9af4:     	add	x14, x11, x14
1000b9af8:     	lsr	x15, x5, #4
1000b9afc:     	and	x15, x15, #0xf0
1000b9b00:     	add	x15, x11, x15
1000b9b04:     	lsr	x16, x5, #8
1000b9b08:     	and	x16, x16, #0xf0
1000b9b0c:     	add	x16, x11, x16
1000b9b10:     	lsr	x17, x5, #12
1000b9b14:     	and	x17, x17, #0xf0
1000b9b18:     	add	x17, x11, x17
1000b9b1c:     	lsr	x4, x5, #16
1000b9b20:     	and	x4, x4, #0xf0
1000b9b24:     	add	x4, x11, x4
1000b9b28:     	lsr	x6, x5, #20
1000b9b2c:     	and	x6, x6, #0xf0
1000b9b30:     	lsr	x5, x5, #24
1000b9b34:     	and	x7, x5, #0xf0
1000b9b38:     	ldur	w19, [x9, #-8]
1000b9b3c:     	add	x5, x11, x6
1000b9b40:     	and	x6, x19, #0xf
1000b9b44:     	ubfx	x20, x19, #4, #4
1000b9b48:     	ldrsb	w20, [x13, x20]
1000b9b4c:     	ldrsb	w21, [x14, x6]
1000b9b50:     	ubfx	x6, x19, #8, #4
1000b9b54:     	ldrsb	w22, [x15, x6]
1000b9b58:     	ubfx	x6, x19, #12, #4
1000b9b5c:     	ldrsb	w23, [x16, x6]
1000b9b60:     	add	x6, x11, x7
1000b9b64:     	ubfx	x7, x19, #16, #4
1000b9b68:     	ldrsb	w7, [x17, x7]
1000b9b6c:     	add	w20, w21, w20
1000b9b70:     	add	w20, w20, w22
1000b9b74:     	ubfx	x21, x19, #20, #4
1000b9b78:     	ldrsb	w21, [x4, x21]
1000b9b7c:     	ubfx	x22, x19, #24, #4
1000b9b80:     	add	w20, w20, w23
1000b9b84:     	add	w7, w20, w7
1000b9b88:     	ldrsb	w20, [x5, x22]
1000b9b8c:     	lsr	x19, x19, #28
1000b9b90:     	ldrsb	w19, [x6, x19]
1000b9b94:     	add	w7, w7, w21
1000b9b98:     	add	w7, w7, w20
1000b9b9c:     	add	w7, w7, w19
1000b9ba0:     	scvtf	s0, w7
1000b9ba4:     	ldp	s1, s2, [x3]
1000b9ba8:     	fadd	s0, s1, s0
1000b9bac:     	str	s0, [x3]
1000b9bb0:     	ldur	w7, [x9, #-4]
1000b9bb4:     	and	x19, x7, #0xf
1000b9bb8:     	ldrsb	w19, [x14, x19]
1000b9bbc:     	ubfx	x20, x7, #4, #4
1000b9bc0:     	ldrsb	w20, [x13, x20]
1000b9bc4:     	ubfx	x21, x7, #8, #4
1000b9bc8:     	ldrsb	w21, [x15, x21]
1000b9bcc:     	ubfx	x22, x7, #12, #4
1000b9bd0:     	ldrsb	w22, [x16, x22]
1000b9bd4:     	ubfx	x23, x7, #16, #4
1000b9bd8:     	add	w19, w19, w20
1000b9bdc:     	add	w19, w19, w21
1000b9be0:     	ldrsb	w20, [x17, x23]
1000b9be4:     	ubfx	x21, x7, #20, #4
1000b9be8:     	ldrsb	w21, [x4, x21]
1000b9bec:     	add	w19, w19, w22
1000b9bf0:     	add	w19, w19, w20
1000b9bf4:     	ubfx	x20, x7, #24, #4
1000b9bf8:     	ldrsb	w20, [x5, x20]
1000b9bfc:     	add	w19, w19, w21
1000b9c00:     	add	w19, w19, w20
1000b9c04:     	lsr	x7, x7, #28
1000b9c08:     	ldrsb	w7, [x6, x7]
1000b9c0c:     	add	w7, w19, w7
1000b9c10:     	scvtf	s0, w7
1000b9c14:     	fadd	s0, s2, s0
1000b9c18:     	str	s0, [x3, #4]
1000b9c1c:     	ldr	w7, [x9]
1000b9c20:     	and	x19, x7, #0xf
1000b9c24:     	ldrsb	w19, [x14, x19]
1000b9c28:     	ubfx	x20, x7, #4, #4
1000b9c2c:     	ldrsb	w20, [x13, x20]
1000b9c30:     	ubfx	x21, x7, #8, #4
1000b9c34:     	ldrsb	w21, [x15, x21]
1000b9c38:     	ubfx	x22, x7, #12, #4
1000b9c3c:     	ldrsb	w22, [x16, x22]
1000b9c40:     	ubfx	x23, x7, #16, #4
1000b9c44:     	add	w19, w19, w20
1000b9c48:     	add	w19, w19, w21
1000b9c4c:     	ldrsb	w20, [x17, x23]
1000b9c50:     	ubfx	x21, x7, #20, #4
1000b9c54:     	ldrsb	w21, [x4, x21]
1000b9c58:     	add	w19, w19, w22
1000b9c5c:     	add	w19, w19, w20
1000b9c60:     	ubfx	x20, x7, #24, #4
1000b9c64:     	ldrsb	w20, [x5, x20]
1000b9c68:     	add	w19, w19, w21
1000b9c6c:     	add	w19, w19, w20
1000b9c70:     	lsr	x7, x7, #28
1000b9c74:     	ldrsb	w7, [x6, x7]
1000b9c78:     	add	w7, w19, w7
1000b9c7c:     	scvtf	s0, w7
1000b9c80:     	ldp	s1, s2, [x3, #8]
1000b9c84:     	fadd	s0, s1, s0
1000b9c88:     	str	s0, [x3, #8]
1000b9c8c:     	ldr	w7, [x9, #4]
1000b9c90:     	and	x19, x7, #0xf
1000b9c94:     	ldrsb	w14, [x14, x19]
1000b9c98:     	ubfx	x19, x7, #4, #4
1000b9c9c:     	ldrsb	w13, [x13, x19]
1000b9ca0:     	ubfx	x19, x7, #8, #4
1000b9ca4:     	ldrsb	w15, [x15, x19]
1000b9ca8:     	ubfx	x19, x7, #12, #4
1000b9cac:     	ldrsb	w16, [x16, x19]
1000b9cb0:     	ubfx	x19, x7, #16, #4
1000b9cb4:     	ldrsb	w17, [x17, x19]
1000b9cb8:     	add	w13, w14, w13
1000b9cbc:     	add	w13, w13, w15
1000b9cc0:     	ubfx	x14, x7, #20, #4
1000b9cc4:     	ldrsb	w14, [x4, x14]
1000b9cc8:     	ubfx	x15, x7, #24, #4
1000b9ccc:     	add	w13, w13, w16
1000b9cd0:     	add	w13, w13, w17
1000b9cd4:     	ldrsb	w15, [x5, x15]
1000b9cd8:     	lsr	x16, x7, #28
1000b9cdc:     	ldrsb	w16, [x6, x16]
1000b9ce0:     	add	w13, w13, w14
1000b9ce4:     	add	w13, w13, w15
1000b9ce8:     	add	w13, w13, w16
1000b9cec:     	scvtf	s1, w13
1000b9cf0:     	fadd	s1, s2, s1
1000b9cf4:     	str	s1, [x3, #12]
1000b9cf8:     	add	x13, x10, #8
1000b9cfc:     	add	x12, x12, x8
1000b9d00:     	add	x9, x9, #16
1000b9d04:     	add	x14, x10, #16
1000b9d08:     	mov	x10, x13
1000b9d0c:     	cmp	x14, x2
1000b9d10:     	b.ls	0x1000b9ae0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000b9d14:     	cmp	x13, x2
1000b9d18:     	b.hs	0x1000b9e00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x360>
1000b9d1c:     	ldp	s2, s3, [x3]
1000b9d20:     	lsl	w9, w13, #2
1000b9d24:     	mov	w10, #-16
1000b9d28:     	lsr	x11, x13, #3
1000b9d2c:     	mul	x12, x8, x11
1000b9d30:     	ubfx	x14, x13, #1, #2
1000b9d34:     	orr	x12, x12, x14
1000b9d38:     	ldrb	w12, [x1, x12]
1000b9d3c:     	and	w15, w9, #0x4
1000b9d40:     	lsr	w12, w12, w15
1000b9d44:     	and	w16, w12, #0xf
1000b9d48:     	cmp	w16, #8
1000b9d4c:     	csel	w16, wzr, w10, lo
1000b9d50:     	bfxil	w16, w12, #0, #4
1000b9d54:     	bfi	x14, x11, #4, #60
1000b9d58:     	add	x11, x0, x14
1000b9d5c:     	ldrb	w12, [x11]
1000b9d60:     	lsr	w12, w12, w15
1000b9d64:     	scvtf	s4, w16
1000b9d68:     	and	w14, w12, #0xf
1000b9d6c:     	cmp	w14, #8
1000b9d70:     	csel	w14, wzr, w10, lo
1000b9d74:     	bfxil	w14, w12, #0, #4
1000b9d78:     	scvtf	s5, w14
1000b9d7c:     	fmsub	s2, s5, s4, s2
1000b9d80:     	str	s2, [x3]
1000b9d84:     	ldrb	w12, [x11, #4]
1000b9d88:     	lsr	w12, w12, w15
1000b9d8c:     	and	w14, w12, #0xf
1000b9d90:     	cmp	w14, #8
1000b9d94:     	csel	w14, wzr, w10, lo
1000b9d98:     	bfxil	w14, w12, #0, #4
1000b9d9c:     	scvtf	s5, w14
1000b9da0:     	fmsub	s3, s5, s4, s3
1000b9da4:     	str	s3, [x3, #4]
1000b9da8:     	ldrb	w12, [x11, #8]
1000b9dac:     	lsr	w12, w12, w15
1000b9db0:     	and	w14, w12, #0xf
1000b9db4:     	cmp	w14, #8
1000b9db8:     	csel	w14, wzr, w10, lo
1000b9dbc:     	bfxil	w14, w12, #0, #4
1000b9dc0:     	scvtf	s5, w14
1000b9dc4:     	fmsub	s0, s5, s4, s0
1000b9dc8:     	str	s0, [x3, #8]
1000b9dcc:     	ldrb	w11, [x11, #12]
1000b9dd0:     	lsr	w11, w11, w15
1000b9dd4:     	and	w12, w11, #0xf
1000b9dd8:     	cmp	w12, #8
1000b9ddc:     	csel	w12, wzr, w10, lo
1000b9de0:     	bfxil	w12, w11, #0, #4
1000b9de4:     	scvtf	s5, w12
1000b9de8:     	fmsub	s1, s5, s4, s1
1000b9dec:     	str	s1, [x3, #12]
1000b9df0:     	add	x13, x13, #1
1000b9df4:     	add	w9, w9, #4
1000b9df8:     	cmp	x2, x13
1000b9dfc:     	b.ne	0x1000b9d28 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000b9e00:     	ldp	x20, x19, [sp, #32]
1000b9e04:     	ldp	x22, x21, [sp, #16]
1000b9e08:     	ldp	x24, x23, [sp], #48
1000b9e0c:     	ret

00000001000bb91c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bb91c:     	sub	sp, sp, #176
1000bb920:     	stp	x28, x27, [sp, #80]
1000bb924:     	stp	x26, x25, [sp, #96]
1000bb928:     	stp	x24, x23, [sp, #112]
1000bb92c:     	stp	x22, x21, [sp, #128]
1000bb930:     	stp	x20, x19, [sp, #144]
1000bb934:     	stp	x29, x30, [sp, #160]
1000bb938:     	add	x29, sp, #160
1000bb93c:     	str	x3, [sp]
1000bb940:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xc>
1000bb944:     	ldr	x8, [x8, #392]
1000bb948:     	ldr	x8, [x8]
1000bb94c:     	str	x8, [sp, #72]
1000bb950:     	movi.2d	v0, #0000000000000000
1000bb954:     	stp	q0, q0, [sp, #32]
1000bb958:     	ands	x8, x2, #0xfffffffffffffffe
1000bb95c:     	b.eq	0x1000bbb00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bb960:     	add	x8, x1, x8
1000bb964:     	str	x8, [sp, #8]
1000bb968:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000bb96c:     	add	x9, x9, #188
1000bb970:     	mov	x11, #0
1000bb974:     	ldp	w4, w23, [x1]
1000bb978:     	ubfx	x8, x4, #4, #4
1000bb97c:     	stp	x1, x8, [sp, #16]
1000bb980:     	ubfx	x13, x4, #8, #4
1000bb984:     	and	x14, x4, #0xf
1000bb988:     	ubfx	x15, x4, #12, #4
1000bb98c:     	ubfx	x16, x4, #16, #4
1000bb990:     	ubfx	x17, x4, #20, #4
1000bb994:     	ubfx	x2, x4, #24, #4
1000bb998:     	lsr	x4, x4, #28
1000bb99c:     	and	x5, x23, #0xf
1000bb9a0:     	ubfx	x6, x23, #4, #4
1000bb9a4:     	ubfx	x7, x23, #8, #4
1000bb9a8:     	ubfx	x19, x23, #12, #4
1000bb9ac:     	ubfx	x20, x23, #16, #4
1000bb9b0:     	ubfx	x21, x23, #20, #4
1000bb9b4:     	ubfx	x22, x23, #24, #4
1000bb9b8:     	lsr	x23, x23, #28
1000bb9bc:     	ldr	w24, [x0, x11]
1000bb9c0:     	lsl	w25, w24, #4
1000bb9c4:     	and	x25, x25, #0xf0
1000bb9c8:     	orr	x26, x25, x14
1000bb9cc:     	ldrb	w26, [x9, x26]
1000bb9d0:     	and	x27, x24, #0xf0
1000bb9d4:     	ldr	x8, [sp, #24]
1000bb9d8:     	orr	x28, x27, x8
1000bb9dc:     	ldrb	w28, [x9, x28]
1000bb9e0:     	lsr	x30, x24, #4
1000bb9e4:     	and	x30, x30, #0xf0
1000bb9e8:     	orr	x8, x30, x13
1000bb9ec:     	ldrb	w8, [x9, x8]
1000bb9f0:     	add	w26, w26, w28
1000bb9f4:     	add	w8, w26, w8
1000bb9f8:     	lsr	x26, x24, #8
1000bb9fc:     	and	x26, x26, #0xf0
1000bba00:     	orr	x28, x26, x15
1000bba04:     	ldrb	w28, [x9, x28]
1000bba08:     	lsr	x3, x24, #12
1000bba0c:     	and	x3, x3, #0xf0
1000bba10:     	orr	x10, x3, x16
1000bba14:     	ldrb	w10, [x9, x10]
1000bba18:     	add	w8, w8, w28
1000bba1c:     	add	w8, w8, w10
1000bba20:     	lsr	x10, x24, #16
1000bba24:     	and	x10, x10, #0xf0
1000bba28:     	orr	x28, x10, x17
1000bba2c:     	ldrb	w28, [x9, x28]
1000bba30:     	lsr	x1, x24, #20
1000bba34:     	and	x1, x1, #0xf0
1000bba38:     	orr	x12, x1, x2
1000bba3c:     	ldrb	w12, [x9, x12]
1000bba40:     	add	w8, w8, w28
1000bba44:     	add	x28, sp, #32
1000bba48:     	add	w8, w8, w12
1000bba4c:     	lsr	x12, x24, #24
1000bba50:     	and	x12, x12, #0xf0
1000bba54:     	orr	x24, x12, x4
1000bba58:     	ldrb	w24, [x9, x24]
1000bba5c:     	add	w8, w8, w24
1000bba60:     	scvtf	s0, w8
1000bba64:     	add	x8, x28, x11
1000bba68:     	ldr	s1, [x8]
1000bba6c:     	fadd	s0, s1, s0
1000bba70:     	orr	x24, x25, x5
1000bba74:     	ldrb	w24, [x9, x24]
1000bba78:     	orr	x25, x27, x6
1000bba7c:     	ldrb	w25, [x9, x25]
1000bba80:     	orr	x27, x30, x7
1000bba84:     	ldrb	w27, [x9, x27]
1000bba88:     	add	w24, w24, w25
1000bba8c:     	add	w24, w24, w27
1000bba90:     	orr	x25, x26, x19
1000bba94:     	ldrb	w25, [x9, x25]
1000bba98:     	orr	x3, x3, x20
1000bba9c:     	ldrb	w3, [x9, x3]
1000bbaa0:     	orr	x10, x10, x21
1000bbaa4:     	ldrb	w10, [x9, x10]
1000bbaa8:     	add	w24, w24, w25
1000bbaac:     	add	w3, w24, w3
1000bbab0:     	orr	x1, x1, x22
1000bbab4:     	ldrb	w1, [x9, x1]
1000bbab8:     	add	w10, w3, w10
1000bbabc:     	add	w10, w10, w1
1000bbac0:     	orr	x12, x12, x23
1000bbac4:     	ldrb	w12, [x9, x12]
1000bbac8:     	add	w10, w10, w12
1000bbacc:     	scvtf	s1, w10
1000bbad0:     	str	s0, [x8]
1000bbad4:     	ldr	s0, [x8, #16]
1000bbad8:     	fadd	s0, s0, s1
1000bbadc:     	str	s0, [x8, #16]
1000bbae0:     	add	x11, x11, #4
1000bbae4:     	cmp	x11, #16
1000bbae8:     	b.ne	0x1000bb9bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bbaec:     	add	x0, x0, #16
1000bbaf0:     	ldp	x8, x1, [sp, #8]
1000bbaf4:     	add	x1, x1, #8
1000bbaf8:     	cmp	x1, x8
1000bbafc:     	b.ne	0x1000bb970 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bbb00:     	ldp	q0, q1, [sp, #32]
1000bbb04:     	ldr	x8, [sp]
1000bbb08:     	stp	q0, q1, [x8]
1000bbb0c:     	ldr	x8, [sp, #72]
1000bbb10:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1dc>
1000bbb14:     	ldr	x9, [x9, #392]
1000bbb18:     	ldr	x9, [x9]
1000bbb1c:     	cmp	x9, x8
1000bbb20:     	b.ne	0x1000bbb44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bbb24:     	ldp	x29, x30, [sp, #160]
1000bbb28:     	ldp	x20, x19, [sp, #144]
1000bbb2c:     	ldp	x22, x21, [sp, #128]
1000bbb30:     	ldp	x24, x23, [sp, #112]
1000bbb34:     	ldp	x26, x25, [sp, #96]
1000bbb38:     	ldp	x28, x27, [sp, #80]
1000bbb3c:     	add	sp, sp, #176
1000bbb40:     	ret
1000bbb44:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bbbf8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bbbf8:     	sub	sp, sp, #176
1000bbbfc:     	stp	x28, x27, [sp, #80]
1000bbc00:     	stp	x26, x25, [sp, #96]
1000bbc04:     	stp	x24, x23, [sp, #112]
1000bbc08:     	stp	x22, x21, [sp, #128]
1000bbc0c:     	stp	x20, x19, [sp, #144]
1000bbc10:     	stp	x29, x30, [sp, #160]
1000bbc14:     	add	x29, sp, #160
1000bbc18:     	str	x3, [sp]
1000bbc1c:     	adrp	x8, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xbc>
1000bbc20:     	ldr	x8, [x8, #392]
1000bbc24:     	ldr	x8, [x8]
1000bbc28:     	str	x8, [sp, #72]
1000bbc2c:     	movi.2d	v0, #0000000000000000
1000bbc30:     	stp	q0, q0, [sp, #32]
1000bbc34:     	ands	x8, x2, #0xfffffffffffffffe
1000bbc38:     	b.eq	0x1000bbddc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bbc3c:     	add	x8, x1, x8
1000bbc40:     	str	x8, [sp, #8]
1000bbc44:     	adrp	x9, 0x10016a000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xdc>
1000bbc48:     	add	x9, x9, #444
1000bbc4c:     	mov	x11, #0
1000bbc50:     	ldp	w4, w23, [x1]
1000bbc54:     	ubfx	x8, x4, #4, #4
1000bbc58:     	stp	x1, x8, [sp, #16]
1000bbc5c:     	ubfx	x13, x4, #8, #4
1000bbc60:     	and	x14, x4, #0xf
1000bbc64:     	ubfx	x15, x4, #12, #4
1000bbc68:     	ubfx	x16, x4, #16, #4
1000bbc6c:     	ubfx	x17, x4, #20, #4
1000bbc70:     	ubfx	x2, x4, #24, #4
1000bbc74:     	lsr	x4, x4, #28
1000bbc78:     	and	x5, x23, #0xf
1000bbc7c:     	ubfx	x6, x23, #4, #4
1000bbc80:     	ubfx	x7, x23, #8, #4
1000bbc84:     	ubfx	x19, x23, #12, #4
1000bbc88:     	ubfx	x20, x23, #16, #4
1000bbc8c:     	ubfx	x21, x23, #20, #4
1000bbc90:     	ubfx	x22, x23, #24, #4
1000bbc94:     	lsr	x23, x23, #28
1000bbc98:     	ldr	w24, [x0, x11]
1000bbc9c:     	lsl	w25, w24, #4
1000bbca0:     	and	x25, x25, #0xf0
1000bbca4:     	orr	x26, x25, x14
1000bbca8:     	ldrsb	w26, [x9, x26]
1000bbcac:     	and	x27, x24, #0xf0
1000bbcb0:     	ldr	x8, [sp, #24]
1000bbcb4:     	orr	x28, x27, x8
1000bbcb8:     	ldrsb	w28, [x9, x28]
1000bbcbc:     	lsr	x30, x24, #4
1000bbcc0:     	and	x30, x30, #0xf0
1000bbcc4:     	orr	x8, x30, x13
1000bbcc8:     	ldrsb	w8, [x9, x8]
1000bbccc:     	add	w26, w26, w28
1000bbcd0:     	add	w8, w26, w8
1000bbcd4:     	lsr	x26, x24, #8
1000bbcd8:     	and	x26, x26, #0xf0
1000bbcdc:     	orr	x28, x26, x15
1000bbce0:     	ldrsb	w28, [x9, x28]
1000bbce4:     	lsr	x3, x24, #12
1000bbce8:     	and	x3, x3, #0xf0
1000bbcec:     	orr	x10, x3, x16
1000bbcf0:     	ldrsb	w10, [x9, x10]
1000bbcf4:     	add	w8, w8, w28
1000bbcf8:     	add	w8, w8, w10
1000bbcfc:     	lsr	x10, x24, #16
1000bbd00:     	and	x10, x10, #0xf0
1000bbd04:     	orr	x28, x10, x17
1000bbd08:     	ldrsb	w28, [x9, x28]
1000bbd0c:     	lsr	x1, x24, #20
1000bbd10:     	and	x1, x1, #0xf0
1000bbd14:     	orr	x12, x1, x2
1000bbd18:     	ldrsb	w12, [x9, x12]
1000bbd1c:     	add	w8, w8, w28
1000bbd20:     	add	x28, sp, #32
1000bbd24:     	add	w8, w8, w12
1000bbd28:     	lsr	x12, x24, #24
1000bbd2c:     	and	x12, x12, #0xf0
1000bbd30:     	orr	x24, x12, x4
1000bbd34:     	ldrsb	w24, [x9, x24]
1000bbd38:     	add	w8, w8, w24
1000bbd3c:     	scvtf	s0, w8
1000bbd40:     	add	x8, x28, x11
1000bbd44:     	ldr	s1, [x8]
1000bbd48:     	fadd	s0, s1, s0
1000bbd4c:     	orr	x24, x25, x5
1000bbd50:     	ldrsb	w24, [x9, x24]
1000bbd54:     	orr	x25, x27, x6
1000bbd58:     	ldrsb	w25, [x9, x25]
1000bbd5c:     	orr	x27, x30, x7
1000bbd60:     	ldrsb	w27, [x9, x27]
1000bbd64:     	add	w24, w24, w25
1000bbd68:     	add	w24, w24, w27
1000bbd6c:     	orr	x25, x26, x19
1000bbd70:     	ldrsb	w25, [x9, x25]
1000bbd74:     	orr	x3, x3, x20
1000bbd78:     	ldrsb	w3, [x9, x3]
1000bbd7c:     	orr	x10, x10, x21
1000bbd80:     	ldrsb	w10, [x9, x10]
1000bbd84:     	add	w24, w24, w25
1000bbd88:     	add	w3, w24, w3
1000bbd8c:     	orr	x1, x1, x22
1000bbd90:     	ldrsb	w1, [x9, x1]
1000bbd94:     	add	w10, w3, w10
1000bbd98:     	add	w10, w10, w1
1000bbd9c:     	orr	x12, x12, x23
1000bbda0:     	ldrsb	w12, [x9, x12]
1000bbda4:     	add	w10, w10, w12
1000bbda8:     	scvtf	s1, w10
1000bbdac:     	str	s0, [x8]
1000bbdb0:     	ldr	s0, [x8, #16]
1000bbdb4:     	fadd	s0, s0, s1
1000bbdb8:     	str	s0, [x8, #16]
1000bbdbc:     	add	x11, x11, #4
1000bbdc0:     	cmp	x11, #16
1000bbdc4:     	b.ne	0x1000bbc98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bbdc8:     	add	x0, x0, #16
1000bbdcc:     	ldp	x8, x1, [sp, #8]
1000bbdd0:     	add	x1, x1, #8
1000bbdd4:     	cmp	x1, x8
1000bbdd8:     	b.ne	0x1000bbc4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bbddc:     	ldp	q0, q1, [sp, #32]
1000bbde0:     	ldr	x8, [sp]
1000bbde4:     	stp	q0, q1, [x8]
1000bbde8:     	ldr	x8, [sp, #72]
1000bbdec:     	adrp	x9, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0x28c>
1000bbdf0:     	ldr	x9, [x9, #392]
1000bbdf4:     	ldr	x9, [x9]
1000bbdf8:     	cmp	x9, x8
1000bbdfc:     	b.ne	0x1000bbe20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bbe00:     	ldp	x29, x30, [sp, #160]
1000bbe04:     	ldp	x20, x19, [sp, #144]
1000bbe08:     	ldp	x22, x21, [sp, #128]
1000bbe0c:     	ldp	x24, x23, [sp, #112]
1000bbe10:     	ldp	x26, x25, [sp, #96]
1000bbe14:     	ldp	x28, x27, [sp, #80]
1000bbe18:     	add	sp, sp, #176
1000bbe1c:     	ret
1000bbe20:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bd0a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bd0a8:     	sub	sp, sp, #352
1000bd0ac:     	stp	x28, x27, [sp, #256]
1000bd0b0:     	stp	x26, x25, [sp, #272]
1000bd0b4:     	stp	x24, x23, [sp, #288]
1000bd0b8:     	stp	x22, x21, [sp, #304]
1000bd0bc:     	stp	x20, x19, [sp, #320]
1000bd0c0:     	stp	x29, x30, [sp, #336]
1000bd0c4:     	add	x29, sp, #336
1000bd0c8:     	str	x3, [sp]
1000bd0cc:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bd0d0:     	ldr	x8, [x8, #392]
1000bd0d4:     	ldr	x8, [x8]
1000bd0d8:     	stur	x8, [x29, #-96]
1000bd0dc:     	movi.2d	v0, #0000000000000000
1000bd0e0:     	stp	q0, q0, [x29, #-128]
1000bd0e4:     	lsl	x8, x2, #1
1000bd0e8:     	stp	q0, q0, [x29, #-160]
1000bd0ec:     	ands	x8, x8, #0xfffffffffffffffc
1000bd0f0:     	b.eq	0x1000bd418 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bd0f4:     	add	x8, x1, x8
1000bd0f8:     	str	x8, [sp, #8]
1000bd0fc:     	sub	x8, x29, #160
1000bd100:     	add	x27, x8, #32
1000bd104:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bd108:     	add	x11, x11, #188
1000bd10c:     	mov	x12, #0
1000bd110:     	ldp	w8, w9, [x1]
1000bd114:     	ubfx	x10, x8, #4, #4
1000bd118:     	str	x10, [sp, #168]
1000bd11c:     	ubfx	x10, x8, #8, #4
1000bd120:     	str	x10, [sp, #160]
1000bd124:     	and	x10, x8, #0xf
1000bd128:     	str	x10, [sp, #152]
1000bd12c:     	ubfx	x10, x8, #12, #4
1000bd130:     	str	x10, [sp, #144]
1000bd134:     	ubfx	x10, x8, #16, #4
1000bd138:     	str	x10, [sp, #136]
1000bd13c:     	ubfx	x10, x8, #20, #4
1000bd140:     	str	x10, [sp, #128]
1000bd144:     	ubfx	x10, x8, #24, #4
1000bd148:     	lsr	x8, x8, #28
1000bd14c:     	stp	x8, x10, [sp, #112]
1000bd150:     	and	x10, x9, #0xf
1000bd154:     	ubfx	x8, x9, #4, #4
1000bd158:     	stp	x8, x10, [sp, #96]
1000bd15c:     	ubfx	x10, x9, #8, #4
1000bd160:     	ubfx	x8, x9, #12, #4
1000bd164:     	stp	x8, x10, [sp, #80]
1000bd168:     	ubfx	x10, x9, #16, #4
1000bd16c:     	ubfx	x8, x9, #20, #4
1000bd170:     	stp	x8, x10, [sp, #64]
1000bd174:     	ubfx	x10, x9, #24, #4
1000bd178:     	lsr	x8, x9, #28
1000bd17c:     	stp	x8, x10, [sp, #48]
1000bd180:     	ldp	w9, w17, [x1, #8]
1000bd184:     	and	x10, x9, #0xf
1000bd188:     	ubfx	x8, x9, #4, #4
1000bd18c:     	stp	x8, x10, [sp, #32]
1000bd190:     	ubfx	x8, x9, #8, #4
1000bd194:     	stp	x1, x8, [sp, #16]
1000bd198:     	ubfx	x28, x9, #12, #4
1000bd19c:     	ubfx	x30, x9, #16, #4
1000bd1a0:     	ubfx	x8, x9, #20, #4
1000bd1a4:     	ubfx	x3, x9, #24, #4
1000bd1a8:     	lsr	x9, x9, #28
1000bd1ac:     	and	x1, x17, #0xf
1000bd1b0:     	ubfx	x10, x17, #4, #4
1000bd1b4:     	ubfx	x13, x17, #8, #4
1000bd1b8:     	ubfx	x26, x17, #12, #4
1000bd1bc:     	ubfx	x14, x17, #16, #4
1000bd1c0:     	ubfx	x15, x17, #20, #4
1000bd1c4:     	ubfx	x16, x17, #24, #4
1000bd1c8:     	lsr	x17, x17, #28
1000bd1cc:     	ldr	w21, [x0, x12]
1000bd1d0:     	lsl	w2, w21, #4
1000bd1d4:     	and	x2, x2, #0xf0
1000bd1d8:     	ldp	x4, x19, [sp, #152]
1000bd1dc:     	orr	x4, x2, x4
1000bd1e0:     	ldrb	w6, [x11, x4]
1000bd1e4:     	and	x4, x21, #0xf0
1000bd1e8:     	ldr	x5, [sp, #168]
1000bd1ec:     	orr	x5, x4, x5
1000bd1f0:     	ldrb	w7, [x11, x5]
1000bd1f4:     	lsr	x5, x21, #4
1000bd1f8:     	and	x5, x5, #0xf0
1000bd1fc:     	orr	x19, x5, x19
1000bd200:     	ldrb	w19, [x11, x19]
1000bd204:     	add	w6, w6, w7
1000bd208:     	add	w19, w6, w19
1000bd20c:     	lsr	x6, x21, #8
1000bd210:     	and	x6, x6, #0xf0
1000bd214:     	ldp	x22, x7, [sp, #136]
1000bd218:     	orr	x7, x6, x7
1000bd21c:     	ldrb	w20, [x11, x7]
1000bd220:     	lsr	x7, x21, #12
1000bd224:     	and	x7, x7, #0xf0
1000bd228:     	orr	x22, x7, x22
1000bd22c:     	ldrb	w22, [x11, x22]
1000bd230:     	add	w19, w19, w20
1000bd234:     	add	w22, w19, w22
1000bd238:     	lsr	x19, x21, #16
1000bd23c:     	and	x19, x19, #0xf0
1000bd240:     	ldp	x24, x20, [sp, #120]
1000bd244:     	orr	x20, x19, x20
1000bd248:     	ldrb	w23, [x11, x20]
1000bd24c:     	lsr	x20, x21, #20
1000bd250:     	and	x20, x20, #0xf0
1000bd254:     	orr	x24, x20, x24
1000bd258:     	ldrb	w24, [x11, x24]
1000bd25c:     	add	w22, w22, w23
1000bd260:     	add	w22, w22, w24
1000bd264:     	lsr	x21, x21, #24
1000bd268:     	and	x21, x21, #0xf0
1000bd26c:     	ldr	x23, [sp, #112]
1000bd270:     	orr	x23, x21, x23
1000bd274:     	ldrb	w23, [x11, x23]
1000bd278:     	add	w22, w22, w23
1000bd27c:     	scvtf	s0, w22
1000bd280:     	ldp	x23, x22, [sp, #96]
1000bd284:     	orr	x22, x2, x22
1000bd288:     	ldrb	w22, [x11, x22]
1000bd28c:     	orr	x23, x4, x23
1000bd290:     	ldrb	w23, [x11, x23]
1000bd294:     	ldr	x24, [sp, #88]
1000bd298:     	orr	x24, x5, x24
1000bd29c:     	ldrb	w24, [x11, x24]
1000bd2a0:     	add	w22, w22, w23
1000bd2a4:     	add	w22, w22, w24
1000bd2a8:     	ldp	x24, x23, [sp, #72]
1000bd2ac:     	orr	x23, x6, x23
1000bd2b0:     	ldrb	w23, [x11, x23]
1000bd2b4:     	orr	x24, x7, x24
1000bd2b8:     	ldrb	w24, [x11, x24]
1000bd2bc:     	ldr	x25, [sp, #64]
1000bd2c0:     	orr	x25, x19, x25
1000bd2c4:     	ldrb	w25, [x11, x25]
1000bd2c8:     	add	w22, w22, w23
1000bd2cc:     	add	w22, w22, w24
1000bd2d0:     	ldr	x23, [sp, #56]
1000bd2d4:     	orr	x23, x20, x23
1000bd2d8:     	ldrb	w23, [x11, x23]
1000bd2dc:     	add	w22, w22, w25
1000bd2e0:     	add	w22, w22, w23
1000bd2e4:     	ldr	x23, [sp, #48]
1000bd2e8:     	orr	x23, x21, x23
1000bd2ec:     	ldrb	w23, [x11, x23]
1000bd2f0:     	add	w22, w22, w23
1000bd2f4:     	scvtf	s1, w22
1000bd2f8:     	ldp	x23, x22, [sp, #32]
1000bd2fc:     	orr	x22, x2, x22
1000bd300:     	ldrb	w22, [x11, x22]
1000bd304:     	orr	x23, x4, x23
1000bd308:     	ldrb	w23, [x11, x23]
1000bd30c:     	ldr	x24, [sp, #24]
1000bd310:     	orr	x24, x5, x24
1000bd314:     	ldrb	w24, [x11, x24]
1000bd318:     	add	w22, w22, w23
1000bd31c:     	add	w22, w22, w24
1000bd320:     	orr	x23, x6, x28
1000bd324:     	ldrb	w23, [x11, x23]
1000bd328:     	orr	x24, x7, x30
1000bd32c:     	ldrb	w24, [x11, x24]
1000bd330:     	orr	x25, x19, x8
1000bd334:     	ldrb	w25, [x11, x25]
1000bd338:     	add	w22, w22, w23
1000bd33c:     	orr	x23, x20, x3
1000bd340:     	ldrb	w23, [x11, x23]
1000bd344:     	add	w22, w22, w24
1000bd348:     	add	w22, w22, w25
1000bd34c:     	add	w22, w22, w23
1000bd350:     	orr	x23, x21, x9
1000bd354:     	ldrb	w23, [x11, x23]
1000bd358:     	add	w22, w22, w23
1000bd35c:     	scvtf	s2, w22
1000bd360:     	orr	x2, x2, x1
1000bd364:     	ldrb	w2, [x11, x2]
1000bd368:     	orr	x4, x4, x10
1000bd36c:     	ldrb	w4, [x11, x4]
1000bd370:     	orr	x5, x5, x13
1000bd374:     	ldrb	w5, [x11, x5]
1000bd378:     	add	w2, w2, w4
1000bd37c:     	add	w2, w2, w5
1000bd380:     	orr	x4, x6, x26
1000bd384:     	ldrb	w4, [x11, x4]
1000bd388:     	orr	x5, x7, x14
1000bd38c:     	ldrb	w5, [x11, x5]
1000bd390:     	add	w2, w2, w4
1000bd394:     	orr	x4, x19, x15
1000bd398:     	ldrb	w4, [x11, x4]
1000bd39c:     	add	w2, w2, w5
1000bd3a0:     	orr	x5, x20, x16
1000bd3a4:     	ldrb	w5, [x11, x5]
1000bd3a8:     	add	w2, w2, w4
1000bd3ac:     	add	w2, w2, w5
1000bd3b0:     	orr	x4, x21, x17
1000bd3b4:     	ldrb	w4, [x11, x4]
1000bd3b8:     	add	w2, w2, w4
1000bd3bc:     	sub	x4, x29, #160
1000bd3c0:     	scvtf	s3, w2
1000bd3c4:     	add	x2, x27, x12
1000bd3c8:     	ldur	s4, [x2, #-16]
1000bd3cc:     	fadd	s1, s4, s1
1000bd3d0:     	stur	s1, [x2, #-16]
1000bd3d4:     	ldr	s1, [x2]
1000bd3d8:     	fadd	s1, s1, s2
1000bd3dc:     	str	s1, [x2]
1000bd3e0:     	ldr	s1, [x2, #16]
1000bd3e4:     	fadd	s1, s1, s3
1000bd3e8:     	ldr	s2, [x4, x12]
1000bd3ec:     	str	s1, [x2, #16]
1000bd3f0:     	fadd	s0, s2, s0
1000bd3f4:     	str	s0, [x4, x12]
1000bd3f8:     	add	x12, x12, #4
1000bd3fc:     	cmp	x12, #16
1000bd400:     	b.ne	0x1000bd1cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bd404:     	add	x0, x0, #16
1000bd408:     	ldp	x8, x1, [sp, #8]
1000bd40c:     	add	x1, x1, #16
1000bd410:     	cmp	x1, x8
1000bd414:     	b.ne	0x1000bd10c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bd418:     	ldp	q0, q1, [x29, #-160]
1000bd41c:     	ldr	x8, [sp]
1000bd420:     	stp	q0, q1, [x8]
1000bd424:     	ldp	q0, q1, [x29, #-128]
1000bd428:     	stp	q0, q1, [x8, #32]
1000bd42c:     	ldur	x8, [x29, #-96]
1000bd430:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18c>
1000bd434:     	ldr	x9, [x9, #392]
1000bd438:     	ldr	x9, [x9]
1000bd43c:     	cmp	x9, x8
1000bd440:     	b.ne	0x1000bd464 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bd444:     	ldp	x29, x30, [sp, #336]
1000bd448:     	ldp	x20, x19, [sp, #320]
1000bd44c:     	ldp	x22, x21, [sp, #304]
1000bd450:     	ldp	x24, x23, [sp, #288]
1000bd454:     	ldp	x26, x25, [sp, #272]
1000bd458:     	ldp	x28, x27, [sp, #256]
1000bd45c:     	add	sp, sp, #352
1000bd460:     	ret
1000bd464:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bd560 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bd560:     	sub	sp, sp, #352
1000bd564:     	stp	x28, x27, [sp, #256]
1000bd568:     	stp	x26, x25, [sp, #272]
1000bd56c:     	stp	x24, x23, [sp, #288]
1000bd570:     	stp	x22, x21, [sp, #304]
1000bd574:     	stp	x20, x19, [sp, #320]
1000bd578:     	stp	x29, x30, [sp, #336]
1000bd57c:     	add	x29, sp, #336
1000bd580:     	str	x3, [sp]
1000bd584:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bd588:     	ldr	x8, [x8, #392]
1000bd58c:     	ldr	x8, [x8]
1000bd590:     	stur	x8, [x29, #-96]
1000bd594:     	movi.2d	v0, #0000000000000000
1000bd598:     	stp	q0, q0, [x29, #-128]
1000bd59c:     	lsl	x8, x2, #1
1000bd5a0:     	stp	q0, q0, [x29, #-160]
1000bd5a4:     	ands	x8, x8, #0xfffffffffffffffc
1000bd5a8:     	b.eq	0x1000bd8d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bd5ac:     	add	x8, x1, x8
1000bd5b0:     	str	x8, [sp, #8]
1000bd5b4:     	sub	x8, x29, #160
1000bd5b8:     	add	x27, x8, #32
1000bd5bc:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bd5c0:     	add	x11, x11, #444
1000bd5c4:     	mov	x12, #0
1000bd5c8:     	ldp	w8, w9, [x1]
1000bd5cc:     	ubfx	x10, x8, #4, #4
1000bd5d0:     	str	x10, [sp, #168]
1000bd5d4:     	ubfx	x10, x8, #8, #4
1000bd5d8:     	str	x10, [sp, #160]
1000bd5dc:     	and	x10, x8, #0xf
1000bd5e0:     	str	x10, [sp, #152]
1000bd5e4:     	ubfx	x10, x8, #12, #4
1000bd5e8:     	str	x10, [sp, #144]
1000bd5ec:     	ubfx	x10, x8, #16, #4
1000bd5f0:     	str	x10, [sp, #136]
1000bd5f4:     	ubfx	x10, x8, #20, #4
1000bd5f8:     	str	x10, [sp, #128]
1000bd5fc:     	ubfx	x10, x8, #24, #4
1000bd600:     	lsr	x8, x8, #28
1000bd604:     	stp	x8, x10, [sp, #112]
1000bd608:     	and	x10, x9, #0xf
1000bd60c:     	ubfx	x8, x9, #4, #4
1000bd610:     	stp	x8, x10, [sp, #96]
1000bd614:     	ubfx	x10, x9, #8, #4
1000bd618:     	ubfx	x8, x9, #12, #4
1000bd61c:     	stp	x8, x10, [sp, #80]
1000bd620:     	ubfx	x10, x9, #16, #4
1000bd624:     	ubfx	x8, x9, #20, #4
1000bd628:     	stp	x8, x10, [sp, #64]
1000bd62c:     	ubfx	x10, x9, #24, #4
1000bd630:     	lsr	x8, x9, #28
1000bd634:     	stp	x8, x10, [sp, #48]
1000bd638:     	ldp	w9, w17, [x1, #8]
1000bd63c:     	and	x10, x9, #0xf
1000bd640:     	ubfx	x8, x9, #4, #4
1000bd644:     	stp	x8, x10, [sp, #32]
1000bd648:     	ubfx	x8, x9, #8, #4
1000bd64c:     	stp	x1, x8, [sp, #16]
1000bd650:     	ubfx	x28, x9, #12, #4
1000bd654:     	ubfx	x30, x9, #16, #4
1000bd658:     	ubfx	x8, x9, #20, #4
1000bd65c:     	ubfx	x3, x9, #24, #4
1000bd660:     	lsr	x9, x9, #28
1000bd664:     	and	x1, x17, #0xf
1000bd668:     	ubfx	x10, x17, #4, #4
1000bd66c:     	ubfx	x13, x17, #8, #4
1000bd670:     	ubfx	x26, x17, #12, #4
1000bd674:     	ubfx	x14, x17, #16, #4
1000bd678:     	ubfx	x15, x17, #20, #4
1000bd67c:     	ubfx	x16, x17, #24, #4
1000bd680:     	lsr	x17, x17, #28
1000bd684:     	ldr	w21, [x0, x12]
1000bd688:     	lsl	w2, w21, #4
1000bd68c:     	and	x2, x2, #0xf0
1000bd690:     	ldp	x4, x19, [sp, #152]
1000bd694:     	orr	x4, x2, x4
1000bd698:     	ldrsb	w6, [x11, x4]
1000bd69c:     	and	x4, x21, #0xf0
1000bd6a0:     	ldr	x5, [sp, #168]
1000bd6a4:     	orr	x5, x4, x5
1000bd6a8:     	ldrsb	w7, [x11, x5]
1000bd6ac:     	lsr	x5, x21, #4
1000bd6b0:     	and	x5, x5, #0xf0
1000bd6b4:     	orr	x19, x5, x19
1000bd6b8:     	ldrsb	w19, [x11, x19]
1000bd6bc:     	add	w6, w6, w7
1000bd6c0:     	add	w19, w6, w19
1000bd6c4:     	lsr	x6, x21, #8
1000bd6c8:     	and	x6, x6, #0xf0
1000bd6cc:     	ldp	x22, x7, [sp, #136]
1000bd6d0:     	orr	x7, x6, x7
1000bd6d4:     	ldrsb	w20, [x11, x7]
1000bd6d8:     	lsr	x7, x21, #12
1000bd6dc:     	and	x7, x7, #0xf0
1000bd6e0:     	orr	x22, x7, x22
1000bd6e4:     	ldrsb	w22, [x11, x22]
1000bd6e8:     	add	w19, w19, w20
1000bd6ec:     	add	w22, w19, w22
1000bd6f0:     	lsr	x19, x21, #16
1000bd6f4:     	and	x19, x19, #0xf0
1000bd6f8:     	ldp	x24, x20, [sp, #120]
1000bd6fc:     	orr	x20, x19, x20
1000bd700:     	ldrsb	w23, [x11, x20]
1000bd704:     	lsr	x20, x21, #20
1000bd708:     	and	x20, x20, #0xf0
1000bd70c:     	orr	x24, x20, x24
1000bd710:     	ldrsb	w24, [x11, x24]
1000bd714:     	add	w22, w22, w23
1000bd718:     	add	w22, w22, w24
1000bd71c:     	lsr	x21, x21, #24
1000bd720:     	and	x21, x21, #0xf0
1000bd724:     	ldr	x23, [sp, #112]
1000bd728:     	orr	x23, x21, x23
1000bd72c:     	ldrsb	w23, [x11, x23]
1000bd730:     	add	w22, w22, w23
1000bd734:     	scvtf	s0, w22
1000bd738:     	ldp	x23, x22, [sp, #96]
1000bd73c:     	orr	x22, x2, x22
1000bd740:     	ldrsb	w22, [x11, x22]
1000bd744:     	orr	x23, x4, x23
1000bd748:     	ldrsb	w23, [x11, x23]
1000bd74c:     	ldr	x24, [sp, #88]
1000bd750:     	orr	x24, x5, x24
1000bd754:     	ldrsb	w24, [x11, x24]
1000bd758:     	add	w22, w22, w23
1000bd75c:     	add	w22, w22, w24
1000bd760:     	ldp	x24, x23, [sp, #72]
1000bd764:     	orr	x23, x6, x23
1000bd768:     	ldrsb	w23, [x11, x23]
1000bd76c:     	orr	x24, x7, x24
1000bd770:     	ldrsb	w24, [x11, x24]
1000bd774:     	ldr	x25, [sp, #64]
1000bd778:     	orr	x25, x19, x25
1000bd77c:     	ldrsb	w25, [x11, x25]
1000bd780:     	add	w22, w22, w23
1000bd784:     	add	w22, w22, w24
1000bd788:     	ldr	x23, [sp, #56]
1000bd78c:     	orr	x23, x20, x23
1000bd790:     	ldrsb	w23, [x11, x23]
1000bd794:     	add	w22, w22, w25
1000bd798:     	add	w22, w22, w23
1000bd79c:     	ldr	x23, [sp, #48]
1000bd7a0:     	orr	x23, x21, x23
1000bd7a4:     	ldrsb	w23, [x11, x23]
1000bd7a8:     	add	w22, w22, w23
1000bd7ac:     	scvtf	s1, w22
1000bd7b0:     	ldp	x23, x22, [sp, #32]
1000bd7b4:     	orr	x22, x2, x22
1000bd7b8:     	ldrsb	w22, [x11, x22]
1000bd7bc:     	orr	x23, x4, x23
1000bd7c0:     	ldrsb	w23, [x11, x23]
1000bd7c4:     	ldr	x24, [sp, #24]
1000bd7c8:     	orr	x24, x5, x24
1000bd7cc:     	ldrsb	w24, [x11, x24]
1000bd7d0:     	add	w22, w22, w23
1000bd7d4:     	add	w22, w22, w24
1000bd7d8:     	orr	x23, x6, x28
1000bd7dc:     	ldrsb	w23, [x11, x23]
1000bd7e0:     	orr	x24, x7, x30
1000bd7e4:     	ldrsb	w24, [x11, x24]
1000bd7e8:     	orr	x25, x19, x8
1000bd7ec:     	ldrsb	w25, [x11, x25]
1000bd7f0:     	add	w22, w22, w23
1000bd7f4:     	orr	x23, x20, x3
1000bd7f8:     	ldrsb	w23, [x11, x23]
1000bd7fc:     	add	w22, w22, w24
1000bd800:     	add	w22, w22, w25
1000bd804:     	add	w22, w22, w23
1000bd808:     	orr	x23, x21, x9
1000bd80c:     	ldrsb	w23, [x11, x23]
1000bd810:     	add	w22, w22, w23
1000bd814:     	scvtf	s2, w22
1000bd818:     	orr	x2, x2, x1
1000bd81c:     	ldrsb	w2, [x11, x2]
1000bd820:     	orr	x4, x4, x10
1000bd824:     	ldrsb	w4, [x11, x4]
1000bd828:     	orr	x5, x5, x13
1000bd82c:     	ldrsb	w5, [x11, x5]
1000bd830:     	add	w2, w2, w4
1000bd834:     	add	w2, w2, w5
1000bd838:     	orr	x4, x6, x26
1000bd83c:     	ldrsb	w4, [x11, x4]
1000bd840:     	orr	x5, x7, x14
1000bd844:     	ldrsb	w5, [x11, x5]
1000bd848:     	add	w2, w2, w4
1000bd84c:     	orr	x4, x19, x15
1000bd850:     	ldrsb	w4, [x11, x4]
1000bd854:     	add	w2, w2, w5
1000bd858:     	orr	x5, x20, x16
1000bd85c:     	ldrsb	w5, [x11, x5]
1000bd860:     	add	w2, w2, w4
1000bd864:     	add	w2, w2, w5
1000bd868:     	orr	x4, x21, x17
1000bd86c:     	ldrsb	w4, [x11, x4]
1000bd870:     	add	w2, w2, w4
1000bd874:     	sub	x4, x29, #160
1000bd878:     	scvtf	s3, w2
1000bd87c:     	add	x2, x27, x12
1000bd880:     	ldur	s4, [x2, #-16]
1000bd884:     	fadd	s1, s4, s1
1000bd888:     	stur	s1, [x2, #-16]
1000bd88c:     	ldr	s1, [x2]
1000bd890:     	fadd	s1, s1, s2
1000bd894:     	str	s1, [x2]
1000bd898:     	ldr	s1, [x2, #16]
1000bd89c:     	fadd	s1, s1, s3
1000bd8a0:     	ldr	s2, [x4, x12]
1000bd8a4:     	str	s1, [x2, #16]
1000bd8a8:     	fadd	s0, s2, s0
1000bd8ac:     	str	s0, [x4, x12]
1000bd8b0:     	add	x12, x12, #4
1000bd8b4:     	cmp	x12, #16
1000bd8b8:     	b.ne	0x1000bd684 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bd8bc:     	add	x0, x0, #16
1000bd8c0:     	ldp	x8, x1, [sp, #8]
1000bd8c4:     	add	x1, x1, #16
1000bd8c8:     	cmp	x1, x8
1000bd8cc:     	b.ne	0x1000bd5c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bd8d0:     	ldp	q0, q1, [x29, #-160]
1000bd8d4:     	ldr	x8, [sp]
1000bd8d8:     	stp	q0, q1, [x8]
1000bd8dc:     	ldp	q0, q1, [x29, #-128]
1000bd8e0:     	stp	q0, q1, [x8, #32]
1000bd8e4:     	ldur	x8, [x29, #-96]
1000bd8e8:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 1ul, false>(char const*)+0x284>
1000bd8ec:     	ldr	x9, [x9, #392]
1000bd8f0:     	ldr	x9, [x9]
1000bd8f4:     	cmp	x9, x8
1000bd8f8:     	b.ne	0x1000bd91c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bd8fc:     	ldp	x29, x30, [sp, #336]
1000bd900:     	ldp	x20, x19, [sp, #320]
1000bd904:     	ldp	x22, x21, [sp, #304]
1000bd908:     	ldp	x24, x23, [sp, #288]
1000bd90c:     	ldp	x26, x25, [sp, #272]
1000bd910:     	ldp	x28, x27, [sp, #256]
1000bd914:     	add	sp, sp, #352
1000bd918:     	ret
1000bd91c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bf020 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bf020:     	stp	x24, x23, [sp, #-48]!
1000bf024:     	stp	x22, x21, [sp, #16]
1000bf028:     	stp	x20, x19, [sp, #32]
1000bf02c:     	movi.2d	v0, #0000000000000000
1000bf030:     	stp	q0, q0, [x3]
1000bf034:     	lsl	x8, x4, #2
1000bf038:     	cmp	x2, #8
1000bf03c:     	b.hs	0x1000bf048 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bf040:     	mov	x13, #0
1000bf044:     	b	0x1000bf448 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bf048:     	mov	x10, #0
1000bf04c:     	add	x9, x0, #16
1000bf050:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bf054:     	add	x11, x11, #700
1000bf058:     	mov	x12, x1
1000bf05c:     	ldr	w5, [x12]
1000bf060:     	lsr	x13, x5, #24
1000bf064:     	and	x13, x13, #0xf0
1000bf068:     	lsr	x14, x5, #20
1000bf06c:     	and	x14, x14, #0xf0
1000bf070:     	add	x13, x11, x13
1000bf074:     	add	x14, x11, x14
1000bf078:     	lsr	x15, x5, #16
1000bf07c:     	and	x15, x15, #0xf0
1000bf080:     	lsr	x16, x5, #12
1000bf084:     	and	x6, x16, #0xf0
1000bf088:     	add	x15, x11, x15
1000bf08c:     	lsr	x16, x5, #8
1000bf090:     	and	x16, x16, #0xf0
1000bf094:     	add	x16, x11, x16
1000bf098:     	lsr	x17, x5, #4
1000bf09c:     	and	x17, x17, #0xf0
1000bf0a0:     	add	x17, x11, x17
1000bf0a4:     	and	x4, x5, #0xf0
1000bf0a8:     	add	x4, x11, x4
1000bf0ac:     	lsl	w5, w5, #4
1000bf0b0:     	and	x5, x5, #0xf0
1000bf0b4:     	ldur	w7, [x9, #-16]
1000bf0b8:     	add	x5, x11, x5
1000bf0bc:     	and	x19, x7, #0xf
1000bf0c0:     	ubfx	x20, x7, #4, #4
1000bf0c4:     	ldrb	w20, [x4, x20]
1000bf0c8:     	ldrb	w19, [x5, x19]
1000bf0cc:     	ubfx	x21, x7, #8, #4
1000bf0d0:     	ldrb	w21, [x17, x21]
1000bf0d4:     	ubfx	x22, x7, #12, #4
1000bf0d8:     	ldrb	w22, [x16, x22]
1000bf0dc:     	add	x6, x11, x6
1000bf0e0:     	ubfx	x23, x7, #16, #4
1000bf0e4:     	ldrb	w23, [x6, x23]
1000bf0e8:     	add	w19, w19, w20
1000bf0ec:     	add	w19, w19, w21
1000bf0f0:     	ubfx	x20, x7, #20, #4
1000bf0f4:     	ldrb	w20, [x15, x20]
1000bf0f8:     	ubfx	x21, x7, #24, #4
1000bf0fc:     	add	w19, w19, w22
1000bf100:     	add	w19, w19, w23
1000bf104:     	ldrb	w21, [x14, x21]
1000bf108:     	lsr	x7, x7, #28
1000bf10c:     	ldrb	w7, [x13, x7]
1000bf110:     	add	w19, w19, w20
1000bf114:     	add	w19, w19, w21
1000bf118:     	add	w7, w19, w7
1000bf11c:     	scvtf	s0, w7
1000bf120:     	ldp	s1, s2, [x3]
1000bf124:     	fadd	s0, s1, s0
1000bf128:     	str	s0, [x3]
1000bf12c:     	ldur	w7, [x9, #-12]
1000bf130:     	and	x19, x7, #0xf
1000bf134:     	ldrb	w19, [x5, x19]
1000bf138:     	ubfx	x20, x7, #4, #4
1000bf13c:     	ldrb	w20, [x4, x20]
1000bf140:     	ubfx	x21, x7, #8, #4
1000bf144:     	ldrb	w21, [x17, x21]
1000bf148:     	ubfx	x22, x7, #12, #4
1000bf14c:     	ldrb	w22, [x16, x22]
1000bf150:     	ubfx	x23, x7, #16, #4
1000bf154:     	add	w19, w19, w20
1000bf158:     	add	w19, w19, w21
1000bf15c:     	ldrb	w20, [x6, x23]
1000bf160:     	ubfx	x21, x7, #20, #4
1000bf164:     	ldrb	w21, [x15, x21]
1000bf168:     	add	w19, w19, w22
1000bf16c:     	add	w19, w19, w20
1000bf170:     	ubfx	x20, x7, #24, #4
1000bf174:     	ldrb	w20, [x14, x20]
1000bf178:     	add	w19, w19, w21
1000bf17c:     	add	w19, w19, w20
1000bf180:     	lsr	x7, x7, #28
1000bf184:     	ldrb	w7, [x13, x7]
1000bf188:     	add	w7, w19, w7
1000bf18c:     	scvtf	s0, w7
1000bf190:     	fadd	s0, s2, s0
1000bf194:     	str	s0, [x3, #4]
1000bf198:     	ldur	w7, [x9, #-8]
1000bf19c:     	and	x19, x7, #0xf
1000bf1a0:     	ldrb	w19, [x5, x19]
1000bf1a4:     	ubfx	x20, x7, #4, #4
1000bf1a8:     	ldrb	w20, [x4, x20]
1000bf1ac:     	ubfx	x21, x7, #8, #4
1000bf1b0:     	ldrb	w21, [x17, x21]
1000bf1b4:     	ubfx	x22, x7, #12, #4
1000bf1b8:     	ldrb	w22, [x16, x22]
1000bf1bc:     	ubfx	x23, x7, #16, #4
1000bf1c0:     	add	w19, w19, w20
1000bf1c4:     	add	w19, w19, w21
1000bf1c8:     	ldrb	w20, [x6, x23]
1000bf1cc:     	ubfx	x21, x7, #20, #4
1000bf1d0:     	ldrb	w21, [x15, x21]
1000bf1d4:     	add	w19, w19, w22
1000bf1d8:     	add	w19, w19, w20
1000bf1dc:     	ubfx	x20, x7, #24, #4
1000bf1e0:     	ldrb	w20, [x14, x20]
1000bf1e4:     	add	w19, w19, w21
1000bf1e8:     	add	w19, w19, w20
1000bf1ec:     	lsr	x7, x7, #28
1000bf1f0:     	ldrb	w7, [x13, x7]
1000bf1f4:     	add	w7, w19, w7
1000bf1f8:     	scvtf	s0, w7
1000bf1fc:     	ldp	s1, s2, [x3, #8]
1000bf200:     	fadd	s0, s1, s0
1000bf204:     	str	s0, [x3, #8]
1000bf208:     	ldur	w7, [x9, #-4]
1000bf20c:     	and	x19, x7, #0xf
1000bf210:     	ldrb	w19, [x5, x19]
1000bf214:     	ubfx	x20, x7, #4, #4
1000bf218:     	ldrb	w20, [x4, x20]
1000bf21c:     	ubfx	x21, x7, #8, #4
1000bf220:     	ldrb	w21, [x17, x21]
1000bf224:     	ubfx	x22, x7, #12, #4
1000bf228:     	ldrb	w22, [x16, x22]
1000bf22c:     	ubfx	x23, x7, #16, #4
1000bf230:     	ldrb	w23, [x6, x23]
1000bf234:     	ubfx	x24, x7, #20, #4
1000bf238:     	add	w19, w19, w20
1000bf23c:     	add	w19, w19, w21
1000bf240:     	ldrb	w20, [x15, x24]
1000bf244:     	ubfx	x21, x7, #24, #4
1000bf248:     	ldrb	w21, [x14, x21]
1000bf24c:     	add	w19, w19, w22
1000bf250:     	add	w19, w19, w23
1000bf254:     	lsr	x7, x7, #28
1000bf258:     	ldrb	w7, [x13, x7]
1000bf25c:     	add	w19, w19, w20
1000bf260:     	add	w19, w19, w21
1000bf264:     	add	w7, w19, w7
1000bf268:     	scvtf	s0, w7
1000bf26c:     	fadd	s0, s2, s0
1000bf270:     	str	s0, [x3, #12]
1000bf274:     	ldr	w7, [x9]
1000bf278:     	and	x19, x7, #0xf
1000bf27c:     	ldrb	w19, [x5, x19]
1000bf280:     	ubfx	x20, x7, #4, #4
1000bf284:     	ldrb	w20, [x4, x20]
1000bf288:     	ubfx	x21, x7, #8, #4
1000bf28c:     	ldrb	w21, [x17, x21]
1000bf290:     	ubfx	x22, x7, #12, #4
1000bf294:     	ldrb	w22, [x16, x22]
1000bf298:     	ubfx	x23, x7, #16, #4
1000bf29c:     	ldrb	w23, [x6, x23]
1000bf2a0:     	add	w19, w19, w20
1000bf2a4:     	add	w19, w19, w21
1000bf2a8:     	ubfx	x20, x7, #20, #4
1000bf2ac:     	ldrb	w20, [x15, x20]
1000bf2b0:     	ubfx	x21, x7, #24, #4
1000bf2b4:     	add	w19, w19, w22
1000bf2b8:     	add	w19, w19, w23
1000bf2bc:     	ldrb	w21, [x14, x21]
1000bf2c0:     	lsr	x7, x7, #28
1000bf2c4:     	ldrb	w7, [x13, x7]
1000bf2c8:     	add	w19, w19, w20
1000bf2cc:     	add	w19, w19, w21
1000bf2d0:     	add	w7, w19, w7
1000bf2d4:     	scvtf	s0, w7
1000bf2d8:     	ldp	s1, s2, [x3, #16]
1000bf2dc:     	fadd	s0, s1, s0
1000bf2e0:     	str	s0, [x3, #16]
1000bf2e4:     	ldr	w7, [x9, #4]
1000bf2e8:     	and	x19, x7, #0xf
1000bf2ec:     	ldrb	w19, [x5, x19]
1000bf2f0:     	ubfx	x20, x7, #4, #4
1000bf2f4:     	ldrb	w20, [x4, x20]
1000bf2f8:     	ubfx	x21, x7, #8, #4
1000bf2fc:     	ldrb	w21, [x17, x21]
1000bf300:     	ubfx	x22, x7, #12, #4
1000bf304:     	ldrb	w22, [x16, x22]
1000bf308:     	ubfx	x23, x7, #16, #4
1000bf30c:     	add	w19, w19, w20
1000bf310:     	add	w19, w19, w21
1000bf314:     	ldrb	w20, [x6, x23]
1000bf318:     	ubfx	x21, x7, #20, #4
1000bf31c:     	ldrb	w21, [x15, x21]
1000bf320:     	add	w19, w19, w22
1000bf324:     	add	w19, w19, w20
1000bf328:     	ubfx	x20, x7, #24, #4
1000bf32c:     	ldrb	w20, [x14, x20]
1000bf330:     	add	w19, w19, w21
1000bf334:     	add	w19, w19, w20
1000bf338:     	lsr	x7, x7, #28
1000bf33c:     	ldrb	w7, [x13, x7]
1000bf340:     	add	w7, w19, w7
1000bf344:     	scvtf	s0, w7
1000bf348:     	fadd	s0, s2, s0
1000bf34c:     	str	s0, [x3, #20]
1000bf350:     	ldr	w7, [x9, #8]
1000bf354:     	and	x19, x7, #0xf
1000bf358:     	ldrb	w19, [x5, x19]
1000bf35c:     	ubfx	x20, x7, #4, #4
1000bf360:     	ldrb	w20, [x4, x20]
1000bf364:     	ubfx	x21, x7, #8, #4
1000bf368:     	ldrb	w21, [x17, x21]
1000bf36c:     	ubfx	x22, x7, #12, #4
1000bf370:     	ldrb	w22, [x16, x22]
1000bf374:     	ubfx	x23, x7, #16, #4
1000bf378:     	add	w19, w19, w20
1000bf37c:     	add	w19, w19, w21
1000bf380:     	ldrb	w20, [x6, x23]
1000bf384:     	ubfx	x21, x7, #20, #4
1000bf388:     	ldrb	w21, [x15, x21]
1000bf38c:     	add	w19, w19, w22
1000bf390:     	add	w19, w19, w20
1000bf394:     	ubfx	x20, x7, #24, #4
1000bf398:     	ldrb	w20, [x14, x20]
1000bf39c:     	add	w19, w19, w21
1000bf3a0:     	add	w19, w19, w20
1000bf3a4:     	lsr	x7, x7, #28
1000bf3a8:     	ldrb	w7, [x13, x7]
1000bf3ac:     	add	w7, w19, w7
1000bf3b0:     	scvtf	s0, w7
1000bf3b4:     	ldp	s1, s2, [x3, #24]
1000bf3b8:     	fadd	s0, s1, s0
1000bf3bc:     	str	s0, [x3, #24]
1000bf3c0:     	ldr	w7, [x9, #12]
1000bf3c4:     	and	x19, x7, #0xf
1000bf3c8:     	ldrb	w5, [x5, x19]
1000bf3cc:     	ubfx	x19, x7, #4, #4
1000bf3d0:     	ldrb	w4, [x4, x19]
1000bf3d4:     	ubfx	x19, x7, #8, #4
1000bf3d8:     	ldrb	w17, [x17, x19]
1000bf3dc:     	ubfx	x19, x7, #12, #4
1000bf3e0:     	ldrb	w16, [x16, x19]
1000bf3e4:     	ubfx	x19, x7, #16, #4
1000bf3e8:     	ldrb	w6, [x6, x19]
1000bf3ec:     	add	w4, w5, w4
1000bf3f0:     	add	w17, w4, w17
1000bf3f4:     	ubfx	x4, x7, #20, #4
1000bf3f8:     	ldrb	w15, [x15, x4]
1000bf3fc:     	ubfx	x4, x7, #24, #4
1000bf400:     	add	w16, w17, w16
1000bf404:     	add	w16, w16, w6
1000bf408:     	ldrb	w14, [x14, x4]
1000bf40c:     	lsr	x17, x7, #28
1000bf410:     	ldrb	w13, [x13, x17]
1000bf414:     	add	w15, w16, w15
1000bf418:     	add	w14, w15, w14
1000bf41c:     	add	w13, w14, w13
1000bf420:     	scvtf	s0, w13
1000bf424:     	fadd	s0, s2, s0
1000bf428:     	str	s0, [x3, #28]
1000bf42c:     	add	x13, x10, #8
1000bf430:     	add	x12, x12, x8
1000bf434:     	add	x14, x10, #16
1000bf438:     	add	x9, x9, #32
1000bf43c:     	mov	x10, x13
1000bf440:     	cmp	x14, x2
1000bf444:     	b.ls	0x1000bf05c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000bf448:     	cmp	x13, x2
1000bf44c:     	b.hs	0x1000bf600 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5e0>
1000bf450:     	ldp	s0, s1, [x3, #8]
1000bf454:     	lsl	x9, x13, #2
1000bf458:     	mov	w10, #-16
1000bf45c:     	ldr	s2, [x3, #16]
1000bf460:     	lsr	x11, x13, #3
1000bf464:     	mul	x12, x8, x11
1000bf468:     	ubfx	x11, x13, #1, #2
1000bf46c:     	orr	x12, x12, x11
1000bf470:     	ldrb	w14, [x1, x12]
1000bf474:     	and	w12, w9, #0x4
1000bf478:     	lsr	w14, w14, w12
1000bf47c:     	and	w15, w14, #0xf
1000bf480:     	cmp	w15, #8
1000bf484:     	csel	w15, wzr, w10, lo
1000bf488:     	and	x16, x9, #0xffffffffffffffe0
1000bf48c:     	bfxil	x16, x13, #1, #2
1000bf490:     	bfxil	w15, w14, #0, #4
1000bf494:     	add	x14, x0, x16
1000bf498:     	ldrb	w16, [x14]
1000bf49c:     	lsr	w16, w16, w12
1000bf4a0:     	and	w17, w16, #0xf
1000bf4a4:     	scvtf	s3, w15
1000bf4a8:     	cmp	w17, #8
1000bf4ac:     	csel	w15, wzr, w10, lo
1000bf4b0:     	bfxil	w15, w16, #0, #4
1000bf4b4:     	scvtf	s4, w15
1000bf4b8:     	fsub	s4, s4, s3
1000bf4bc:     	ldp	s5, s6, [x3]
1000bf4c0:     	fmadd	s4, s4, s4, s5
1000bf4c4:     	str	s4, [x3]
1000bf4c8:     	ldrb	w15, [x14, #4]
1000bf4cc:     	lsr	w15, w15, w12
1000bf4d0:     	and	w16, w15, #0xf
1000bf4d4:     	cmp	w16, #8
1000bf4d8:     	csel	w16, wzr, w10, lo
1000bf4dc:     	bfxil	w16, w15, #0, #4
1000bf4e0:     	scvtf	s4, w16
1000bf4e4:     	fsub	s4, s4, s3
1000bf4e8:     	fmadd	s4, s4, s4, s6
1000bf4ec:     	str	s4, [x3, #4]
1000bf4f0:     	ldrb	w15, [x14, #8]
1000bf4f4:     	lsr	w15, w15, w12
1000bf4f8:     	and	w16, w15, #0xf
1000bf4fc:     	cmp	w16, #8
1000bf500:     	csel	w16, wzr, w10, lo
1000bf504:     	bfxil	w16, w15, #0, #4
1000bf508:     	scvtf	s4, w16
1000bf50c:     	fsub	s4, s4, s3
1000bf510:     	fmadd	s0, s4, s4, s0
1000bf514:     	str	s0, [x3, #8]
1000bf518:     	ldrb	w15, [x14, #12]
1000bf51c:     	lsr	w15, w15, w12
1000bf520:     	and	w16, w15, #0xf
1000bf524:     	cmp	w16, #8
1000bf528:     	csel	w16, wzr, w10, lo
1000bf52c:     	bfxil	w16, w15, #0, #4
1000bf530:     	scvtf	s4, w16
1000bf534:     	fsub	s4, s4, s3
1000bf538:     	fmadd	s1, s4, s4, s1
1000bf53c:     	str	s1, [x3, #12]
1000bf540:     	ldrb	w15, [x14, #16]
1000bf544:     	lsr	w15, w15, w12
1000bf548:     	and	w16, w15, #0xf
1000bf54c:     	cmp	w16, #8
1000bf550:     	csel	w16, wzr, w10, lo
1000bf554:     	bfxil	w16, w15, #0, #4
1000bf558:     	scvtf	s4, w16
1000bf55c:     	fsub	s4, s4, s3
1000bf560:     	fmadd	s2, s4, s4, s2
1000bf564:     	str	s2, [x3, #16]
1000bf568:     	ldrb	w15, [x14, #20]
1000bf56c:     	lsr	w15, w15, w12
1000bf570:     	and	w16, w15, #0xf
1000bf574:     	cmp	w16, #8
1000bf578:     	csel	w16, wzr, w10, lo
1000bf57c:     	bfxil	w16, w15, #0, #4
1000bf580:     	scvtf	s4, w16
1000bf584:     	fsub	s4, s4, s3
1000bf588:     	ldp	s5, s6, [x3, #20]
1000bf58c:     	fmadd	s4, s4, s4, s5
1000bf590:     	str	s4, [x3, #20]
1000bf594:     	ldrb	w14, [x14, #24]
1000bf598:     	lsr	w14, w14, w12
1000bf59c:     	and	w15, w14, #0xf
1000bf5a0:     	cmp	w15, #8
1000bf5a4:     	csel	w15, wzr, w10, lo
1000bf5a8:     	bfxil	w15, w14, #0, #4
1000bf5ac:     	scvtf	s4, w15
1000bf5b0:     	fsub	s4, s4, s3
1000bf5b4:     	fmadd	s4, s4, s4, s6
1000bf5b8:     	str	s4, [x3, #24]
1000bf5bc:     	orr	x11, x9, x11
1000bf5c0:     	orr	x11, x11, #0x1c
1000bf5c4:     	ldrb	w11, [x0, x11]
1000bf5c8:     	lsr	w11, w11, w12
1000bf5cc:     	and	w12, w11, #0xf
1000bf5d0:     	cmp	w12, #8
1000bf5d4:     	csel	w12, wzr, w10, lo
1000bf5d8:     	bfxil	w12, w11, #0, #4
1000bf5dc:     	scvtf	s4, w12
1000bf5e0:     	fsub	s3, s4, s3
1000bf5e4:     	ldr	s4, [x3, #28]
1000bf5e8:     	fmadd	s3, s3, s3, s4
1000bf5ec:     	str	s3, [x3, #28]
1000bf5f0:     	add	x13, x13, #1
1000bf5f4:     	add	x9, x9, #4
1000bf5f8:     	cmp	x2, x13
1000bf5fc:     	b.ne	0x1000bf460 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000bf600:     	ldp	x20, x19, [sp, #32]
1000bf604:     	ldp	x22, x21, [sp, #16]
1000bf608:     	ldp	x24, x23, [sp], #48
1000bf60c:     	ret

00000001000bf630 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bf630:     	stp	x24, x23, [sp, #-48]!
1000bf634:     	stp	x22, x21, [sp, #16]
1000bf638:     	stp	x20, x19, [sp, #32]
1000bf63c:     	movi.2d	v0, #0000000000000000
1000bf640:     	stp	q0, q0, [x3]
1000bf644:     	lsl	x8, x4, #2
1000bf648:     	cmp	x2, #8
1000bf64c:     	b.hs	0x1000bf658 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bf650:     	mov	x13, #0
1000bf654:     	b	0x1000bfa58 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bf658:     	mov	x10, #0
1000bf65c:     	add	x9, x0, #16
1000bf660:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bf664:     	add	x11, x11, #956
1000bf668:     	mov	x12, x1
1000bf66c:     	ldr	w5, [x12]
1000bf670:     	lsr	x13, x5, #24
1000bf674:     	and	x13, x13, #0xf0
1000bf678:     	lsr	x14, x5, #20
1000bf67c:     	and	x14, x14, #0xf0
1000bf680:     	add	x13, x11, x13
1000bf684:     	add	x14, x11, x14
1000bf688:     	lsr	x15, x5, #16
1000bf68c:     	and	x15, x15, #0xf0
1000bf690:     	lsr	x16, x5, #12
1000bf694:     	and	x6, x16, #0xf0
1000bf698:     	add	x15, x11, x15
1000bf69c:     	lsr	x16, x5, #8
1000bf6a0:     	and	x16, x16, #0xf0
1000bf6a4:     	add	x16, x11, x16
1000bf6a8:     	lsr	x17, x5, #4
1000bf6ac:     	and	x17, x17, #0xf0
1000bf6b0:     	add	x17, x11, x17
1000bf6b4:     	and	x4, x5, #0xf0
1000bf6b8:     	add	x4, x11, x4
1000bf6bc:     	lsl	w5, w5, #4
1000bf6c0:     	and	x5, x5, #0xf0
1000bf6c4:     	ldur	w7, [x9, #-16]
1000bf6c8:     	add	x5, x11, x5
1000bf6cc:     	and	x19, x7, #0xf
1000bf6d0:     	ubfx	x20, x7, #4, #4
1000bf6d4:     	ldrsb	w20, [x4, x20]
1000bf6d8:     	ldrsb	w19, [x5, x19]
1000bf6dc:     	ubfx	x21, x7, #8, #4
1000bf6e0:     	ldrsb	w21, [x17, x21]
1000bf6e4:     	ubfx	x22, x7, #12, #4
1000bf6e8:     	ldrsb	w22, [x16, x22]
1000bf6ec:     	add	x6, x11, x6
1000bf6f0:     	ubfx	x23, x7, #16, #4
1000bf6f4:     	ldrsb	w23, [x6, x23]
1000bf6f8:     	add	w19, w19, w20
1000bf6fc:     	add	w19, w19, w21
1000bf700:     	ubfx	x20, x7, #20, #4
1000bf704:     	ldrsb	w20, [x15, x20]
1000bf708:     	ubfx	x21, x7, #24, #4
1000bf70c:     	add	w19, w19, w22
1000bf710:     	add	w19, w19, w23
1000bf714:     	ldrsb	w21, [x14, x21]
1000bf718:     	lsr	x7, x7, #28
1000bf71c:     	ldrsb	w7, [x13, x7]
1000bf720:     	add	w19, w19, w20
1000bf724:     	add	w19, w19, w21
1000bf728:     	add	w7, w19, w7
1000bf72c:     	scvtf	s0, w7
1000bf730:     	ldp	s1, s2, [x3]
1000bf734:     	fadd	s0, s1, s0
1000bf738:     	str	s0, [x3]
1000bf73c:     	ldur	w7, [x9, #-12]
1000bf740:     	and	x19, x7, #0xf
1000bf744:     	ldrsb	w19, [x5, x19]
1000bf748:     	ubfx	x20, x7, #4, #4
1000bf74c:     	ldrsb	w20, [x4, x20]
1000bf750:     	ubfx	x21, x7, #8, #4
1000bf754:     	ldrsb	w21, [x17, x21]
1000bf758:     	ubfx	x22, x7, #12, #4
1000bf75c:     	ldrsb	w22, [x16, x22]
1000bf760:     	ubfx	x23, x7, #16, #4
1000bf764:     	add	w19, w19, w20
1000bf768:     	add	w19, w19, w21
1000bf76c:     	ldrsb	w20, [x6, x23]
1000bf770:     	ubfx	x21, x7, #20, #4
1000bf774:     	ldrsb	w21, [x15, x21]
1000bf778:     	add	w19, w19, w22
1000bf77c:     	add	w19, w19, w20
1000bf780:     	ubfx	x20, x7, #24, #4
1000bf784:     	ldrsb	w20, [x14, x20]
1000bf788:     	add	w19, w19, w21
1000bf78c:     	add	w19, w19, w20
1000bf790:     	lsr	x7, x7, #28
1000bf794:     	ldrsb	w7, [x13, x7]
1000bf798:     	add	w7, w19, w7
1000bf79c:     	scvtf	s0, w7
1000bf7a0:     	fadd	s0, s2, s0
1000bf7a4:     	str	s0, [x3, #4]
1000bf7a8:     	ldur	w7, [x9, #-8]
1000bf7ac:     	and	x19, x7, #0xf
1000bf7b0:     	ldrsb	w19, [x5, x19]
1000bf7b4:     	ubfx	x20, x7, #4, #4
1000bf7b8:     	ldrsb	w20, [x4, x20]
1000bf7bc:     	ubfx	x21, x7, #8, #4
1000bf7c0:     	ldrsb	w21, [x17, x21]
1000bf7c4:     	ubfx	x22, x7, #12, #4
1000bf7c8:     	ldrsb	w22, [x16, x22]
1000bf7cc:     	ubfx	x23, x7, #16, #4
1000bf7d0:     	add	w19, w19, w20
1000bf7d4:     	add	w19, w19, w21
1000bf7d8:     	ldrsb	w20, [x6, x23]
1000bf7dc:     	ubfx	x21, x7, #20, #4
1000bf7e0:     	ldrsb	w21, [x15, x21]
1000bf7e4:     	add	w19, w19, w22
1000bf7e8:     	add	w19, w19, w20
1000bf7ec:     	ubfx	x20, x7, #24, #4
1000bf7f0:     	ldrsb	w20, [x14, x20]
1000bf7f4:     	add	w19, w19, w21
1000bf7f8:     	add	w19, w19, w20
1000bf7fc:     	lsr	x7, x7, #28
1000bf800:     	ldrsb	w7, [x13, x7]
1000bf804:     	add	w7, w19, w7
1000bf808:     	scvtf	s0, w7
1000bf80c:     	ldp	s1, s2, [x3, #8]
1000bf810:     	fadd	s0, s1, s0
1000bf814:     	str	s0, [x3, #8]
1000bf818:     	ldur	w7, [x9, #-4]
1000bf81c:     	and	x19, x7, #0xf
1000bf820:     	ldrsb	w19, [x5, x19]
1000bf824:     	ubfx	x20, x7, #4, #4
1000bf828:     	ldrsb	w20, [x4, x20]
1000bf82c:     	ubfx	x21, x7, #8, #4
1000bf830:     	ldrsb	w21, [x17, x21]
1000bf834:     	ubfx	x22, x7, #12, #4
1000bf838:     	ldrsb	w22, [x16, x22]
1000bf83c:     	ubfx	x23, x7, #16, #4
1000bf840:     	ldrsb	w23, [x6, x23]
1000bf844:     	ubfx	x24, x7, #20, #4
1000bf848:     	add	w19, w19, w20
1000bf84c:     	add	w19, w19, w21
1000bf850:     	ldrsb	w20, [x15, x24]
1000bf854:     	ubfx	x21, x7, #24, #4
1000bf858:     	ldrsb	w21, [x14, x21]
1000bf85c:     	add	w19, w19, w22
1000bf860:     	add	w19, w19, w23
1000bf864:     	lsr	x7, x7, #28
1000bf868:     	ldrsb	w7, [x13, x7]
1000bf86c:     	add	w19, w19, w20
1000bf870:     	add	w19, w19, w21
1000bf874:     	add	w7, w19, w7
1000bf878:     	scvtf	s0, w7
1000bf87c:     	fadd	s0, s2, s0
1000bf880:     	str	s0, [x3, #12]
1000bf884:     	ldr	w7, [x9]
1000bf888:     	and	x19, x7, #0xf
1000bf88c:     	ldrsb	w19, [x5, x19]
1000bf890:     	ubfx	x20, x7, #4, #4
1000bf894:     	ldrsb	w20, [x4, x20]
1000bf898:     	ubfx	x21, x7, #8, #4
1000bf89c:     	ldrsb	w21, [x17, x21]
1000bf8a0:     	ubfx	x22, x7, #12, #4
1000bf8a4:     	ldrsb	w22, [x16, x22]
1000bf8a8:     	ubfx	x23, x7, #16, #4
1000bf8ac:     	ldrsb	w23, [x6, x23]
1000bf8b0:     	add	w19, w19, w20
1000bf8b4:     	add	w19, w19, w21
1000bf8b8:     	ubfx	x20, x7, #20, #4
1000bf8bc:     	ldrsb	w20, [x15, x20]
1000bf8c0:     	ubfx	x21, x7, #24, #4
1000bf8c4:     	add	w19, w19, w22
1000bf8c8:     	add	w19, w19, w23
1000bf8cc:     	ldrsb	w21, [x14, x21]
1000bf8d0:     	lsr	x7, x7, #28
1000bf8d4:     	ldrsb	w7, [x13, x7]
1000bf8d8:     	add	w19, w19, w20
1000bf8dc:     	add	w19, w19, w21
1000bf8e0:     	add	w7, w19, w7
1000bf8e4:     	scvtf	s0, w7
1000bf8e8:     	ldp	s1, s2, [x3, #16]
1000bf8ec:     	fadd	s0, s1, s0
1000bf8f0:     	str	s0, [x3, #16]
1000bf8f4:     	ldr	w7, [x9, #4]
1000bf8f8:     	and	x19, x7, #0xf
1000bf8fc:     	ldrsb	w19, [x5, x19]
1000bf900:     	ubfx	x20, x7, #4, #4
1000bf904:     	ldrsb	w20, [x4, x20]
1000bf908:     	ubfx	x21, x7, #8, #4
1000bf90c:     	ldrsb	w21, [x17, x21]
1000bf910:     	ubfx	x22, x7, #12, #4
1000bf914:     	ldrsb	w22, [x16, x22]
1000bf918:     	ubfx	x23, x7, #16, #4
1000bf91c:     	add	w19, w19, w20
1000bf920:     	add	w19, w19, w21
1000bf924:     	ldrsb	w20, [x6, x23]
1000bf928:     	ubfx	x21, x7, #20, #4
1000bf92c:     	ldrsb	w21, [x15, x21]
1000bf930:     	add	w19, w19, w22
1000bf934:     	add	w19, w19, w20
1000bf938:     	ubfx	x20, x7, #24, #4
1000bf93c:     	ldrsb	w20, [x14, x20]
1000bf940:     	add	w19, w19, w21
1000bf944:     	add	w19, w19, w20
1000bf948:     	lsr	x7, x7, #28
1000bf94c:     	ldrsb	w7, [x13, x7]
1000bf950:     	add	w7, w19, w7
1000bf954:     	scvtf	s0, w7
1000bf958:     	fadd	s0, s2, s0
1000bf95c:     	str	s0, [x3, #20]
1000bf960:     	ldr	w7, [x9, #8]
1000bf964:     	and	x19, x7, #0xf
1000bf968:     	ldrsb	w19, [x5, x19]
1000bf96c:     	ubfx	x20, x7, #4, #4
1000bf970:     	ldrsb	w20, [x4, x20]
1000bf974:     	ubfx	x21, x7, #8, #4
1000bf978:     	ldrsb	w21, [x17, x21]
1000bf97c:     	ubfx	x22, x7, #12, #4
1000bf980:     	ldrsb	w22, [x16, x22]
1000bf984:     	ubfx	x23, x7, #16, #4
1000bf988:     	add	w19, w19, w20
1000bf98c:     	add	w19, w19, w21
1000bf990:     	ldrsb	w20, [x6, x23]
1000bf994:     	ubfx	x21, x7, #20, #4
1000bf998:     	ldrsb	w21, [x15, x21]
1000bf99c:     	add	w19, w19, w22
1000bf9a0:     	add	w19, w19, w20
1000bf9a4:     	ubfx	x20, x7, #24, #4
1000bf9a8:     	ldrsb	w20, [x14, x20]
1000bf9ac:     	add	w19, w19, w21
1000bf9b0:     	add	w19, w19, w20
1000bf9b4:     	lsr	x7, x7, #28
1000bf9b8:     	ldrsb	w7, [x13, x7]
1000bf9bc:     	add	w7, w19, w7
1000bf9c0:     	scvtf	s0, w7
1000bf9c4:     	ldp	s1, s2, [x3, #24]
1000bf9c8:     	fadd	s0, s1, s0
1000bf9cc:     	str	s0, [x3, #24]
1000bf9d0:     	ldr	w7, [x9, #12]
1000bf9d4:     	and	x19, x7, #0xf
1000bf9d8:     	ldrsb	w5, [x5, x19]
1000bf9dc:     	ubfx	x19, x7, #4, #4
1000bf9e0:     	ldrsb	w4, [x4, x19]
1000bf9e4:     	ubfx	x19, x7, #8, #4
1000bf9e8:     	ldrsb	w17, [x17, x19]
1000bf9ec:     	ubfx	x19, x7, #12, #4
1000bf9f0:     	ldrsb	w16, [x16, x19]
1000bf9f4:     	ubfx	x19, x7, #16, #4
1000bf9f8:     	ldrsb	w6, [x6, x19]
1000bf9fc:     	add	w4, w5, w4
1000bfa00:     	add	w17, w4, w17
1000bfa04:     	ubfx	x4, x7, #20, #4
1000bfa08:     	ldrsb	w15, [x15, x4]
1000bfa0c:     	ubfx	x4, x7, #24, #4
1000bfa10:     	add	w16, w17, w16
1000bfa14:     	add	w16, w16, w6
1000bfa18:     	ldrsb	w14, [x14, x4]
1000bfa1c:     	lsr	x17, x7, #28
1000bfa20:     	ldrsb	w13, [x13, x17]
1000bfa24:     	add	w15, w16, w15
1000bfa28:     	add	w14, w15, w14
1000bfa2c:     	add	w13, w14, w13
1000bfa30:     	scvtf	s0, w13
1000bfa34:     	fadd	s0, s2, s0
1000bfa38:     	str	s0, [x3, #28]
1000bfa3c:     	add	x13, x10, #8
1000bfa40:     	add	x12, x12, x8
1000bfa44:     	add	x14, x10, #16
1000bfa48:     	add	x9, x9, #32
1000bfa4c:     	mov	x10, x13
1000bfa50:     	cmp	x14, x2
1000bfa54:     	b.ls	0x1000bf66c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000bfa58:     	cmp	x13, x2
1000bfa5c:     	b.hs	0x1000bfbf0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5c0>
1000bfa60:     	ldp	s0, s1, [x3, #8]
1000bfa64:     	lsl	x9, x13, #2
1000bfa68:     	mov	w10, #-16
1000bfa6c:     	ldr	s2, [x3, #16]
1000bfa70:     	lsr	x11, x13, #3
1000bfa74:     	mul	x12, x8, x11
1000bfa78:     	ubfx	x11, x13, #1, #2
1000bfa7c:     	orr	x14, x12, x11
1000bfa80:     	and	w12, w9, #0x4
1000bfa84:     	ldrb	w14, [x1, x14]
1000bfa88:     	lsr	w14, w14, w12
1000bfa8c:     	and	w15, w14, #0xf
1000bfa90:     	cmp	w15, #8
1000bfa94:     	csel	w15, wzr, w10, lo
1000bfa98:     	and	x16, x9, #0xffffffffffffffe0
1000bfa9c:     	bfxil	w15, w14, #0, #4
1000bfaa0:     	bfxil	x16, x13, #1, #2
1000bfaa4:     	add	x14, x0, x16
1000bfaa8:     	ldrb	w16, [x14]
1000bfaac:     	lsr	w16, w16, w12
1000bfab0:     	scvtf	s3, w15
1000bfab4:     	and	w15, w16, #0xf
1000bfab8:     	cmp	w15, #8
1000bfabc:     	csel	w15, wzr, w10, lo
1000bfac0:     	bfxil	w15, w16, #0, #4
1000bfac4:     	scvtf	s4, w15
1000bfac8:     	ldp	s5, s6, [x3]
1000bfacc:     	fmsub	s4, s4, s3, s5
1000bfad0:     	str	s4, [x3]
1000bfad4:     	ldrb	w15, [x14, #4]
1000bfad8:     	lsr	w15, w15, w12
1000bfadc:     	and	w16, w15, #0xf
1000bfae0:     	cmp	w16, #8
1000bfae4:     	csel	w16, wzr, w10, lo
1000bfae8:     	bfxil	w16, w15, #0, #4
1000bfaec:     	scvtf	s4, w16
1000bfaf0:     	fmsub	s4, s4, s3, s6
1000bfaf4:     	str	s4, [x3, #4]
1000bfaf8:     	ldrb	w15, [x14, #8]
1000bfafc:     	lsr	w15, w15, w12
1000bfb00:     	and	w16, w15, #0xf
1000bfb04:     	cmp	w16, #8
1000bfb08:     	csel	w16, wzr, w10, lo
1000bfb0c:     	bfxil	w16, w15, #0, #4
1000bfb10:     	scvtf	s4, w16
1000bfb14:     	fmsub	s0, s4, s3, s0
1000bfb18:     	str	s0, [x3, #8]
1000bfb1c:     	ldrb	w15, [x14, #12]
1000bfb20:     	lsr	w15, w15, w12
1000bfb24:     	and	w16, w15, #0xf
1000bfb28:     	cmp	w16, #8
1000bfb2c:     	csel	w16, wzr, w10, lo
1000bfb30:     	bfxil	w16, w15, #0, #4
1000bfb34:     	scvtf	s4, w16
1000bfb38:     	fmsub	s1, s4, s3, s1
1000bfb3c:     	str	s1, [x3, #12]
1000bfb40:     	ldrb	w15, [x14, #16]
1000bfb44:     	lsr	w15, w15, w12
1000bfb48:     	and	w16, w15, #0xf
1000bfb4c:     	cmp	w16, #8
1000bfb50:     	csel	w16, wzr, w10, lo
1000bfb54:     	bfxil	w16, w15, #0, #4
1000bfb58:     	scvtf	s4, w16
1000bfb5c:     	fmsub	s2, s4, s3, s2
1000bfb60:     	str	s2, [x3, #16]
1000bfb64:     	ldrb	w15, [x14, #20]
1000bfb68:     	lsr	w15, w15, w12
1000bfb6c:     	and	w16, w15, #0xf
1000bfb70:     	cmp	w16, #8
1000bfb74:     	csel	w16, wzr, w10, lo
1000bfb78:     	bfxil	w16, w15, #0, #4
1000bfb7c:     	scvtf	s4, w16
1000bfb80:     	ldp	s5, s6, [x3, #20]
1000bfb84:     	fmsub	s4, s4, s3, s5
1000bfb88:     	str	s4, [x3, #20]
1000bfb8c:     	ldrb	w14, [x14, #24]
1000bfb90:     	lsr	w14, w14, w12
1000bfb94:     	and	w15, w14, #0xf
1000bfb98:     	cmp	w15, #8
1000bfb9c:     	csel	w15, wzr, w10, lo
1000bfba0:     	bfxil	w15, w14, #0, #4
1000bfba4:     	scvtf	s4, w15
1000bfba8:     	fmsub	s4, s4, s3, s6
1000bfbac:     	str	s4, [x3, #24]
1000bfbb0:     	orr	x11, x9, x11
1000bfbb4:     	orr	x11, x11, #0x1c
1000bfbb8:     	ldrb	w11, [x0, x11]
1000bfbbc:     	lsr	w11, w11, w12
1000bfbc0:     	and	w12, w11, #0xf
1000bfbc4:     	cmp	w12, #8
1000bfbc8:     	csel	w12, wzr, w10, lo
1000bfbcc:     	bfxil	w12, w11, #0, #4
1000bfbd0:     	scvtf	s4, w12
1000bfbd4:     	ldr	s5, [x3, #28]
1000bfbd8:     	fmsub	s3, s4, s3, s5
1000bfbdc:     	str	s3, [x3, #28]
1000bfbe0:     	add	x13, x13, #1
1000bfbe4:     	add	x9, x9, #4
1000bfbe8:     	cmp	x2, x13
1000bfbec:     	b.ne	0x1000bfa70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000bfbf0:     	ldp	x20, x19, [sp, #32]
1000bfbf4:     	ldp	x22, x21, [sp, #16]
1000bfbf8:     	ldp	x24, x23, [sp], #48
1000bfbfc:     	ret

00000001000c11a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c11a0:     	sub	sp, sp, #208
1000c11a4:     	stp	x28, x27, [sp, #112]
1000c11a8:     	stp	x26, x25, [sp, #128]
1000c11ac:     	stp	x24, x23, [sp, #144]
1000c11b0:     	stp	x22, x21, [sp, #160]
1000c11b4:     	stp	x20, x19, [sp, #176]
1000c11b8:     	stp	x29, x30, [sp, #192]
1000c11bc:     	add	x29, sp, #192
1000c11c0:     	str	x3, [sp]
1000c11c4:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000c11c8:     	ldr	x8, [x8, #392]
1000c11cc:     	ldr	x8, [x8]
1000c11d0:     	stur	x8, [x29, #-88]
1000c11d4:     	movi.2d	v0, #0000000000000000
1000c11d8:     	stp	q0, q0, [sp, #64]
1000c11dc:     	stp	q0, q0, [sp, #32]
1000c11e0:     	ands	x8, x2, #0xfffffffffffffffe
1000c11e4:     	b.eq	0x1000c1368 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c11e8:     	add	x8, x1, x8
1000c11ec:     	str	x8, [sp, #8]
1000c11f0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x28>
1000c11f4:     	add	x9, x9, #700
1000c11f8:     	mov	x11, #0
1000c11fc:     	ldp	w4, w23, [x1]
1000c1200:     	ubfx	x8, x4, #8, #4
1000c1204:     	stp	x1, x8, [sp, #16]
1000c1208:     	ubfx	x13, x4, #16, #4
1000c120c:     	and	x14, x4, #0xf
1000c1210:     	ubfx	x15, x4, #24, #4
1000c1214:     	ubfx	x16, x4, #4, #4
1000c1218:     	ubfx	x17, x4, #12, #4
1000c121c:     	ubfx	x2, x4, #20, #4
1000c1220:     	lsr	x4, x4, #28
1000c1224:     	and	x5, x23, #0xf
1000c1228:     	ubfx	x6, x23, #8, #4
1000c122c:     	ubfx	x7, x23, #16, #4
1000c1230:     	ubfx	x19, x23, #24, #4
1000c1234:     	ubfx	x20, x23, #4, #4
1000c1238:     	ubfx	x21, x23, #12, #4
1000c123c:     	ubfx	x22, x23, #20, #4
1000c1240:     	lsr	x23, x23, #28
1000c1244:     	ldr	w24, [x0, x11]
1000c1248:     	lsl	w25, w24, #4
1000c124c:     	and	x25, x25, #0xf0
1000c1250:     	add	x25, x9, x25
1000c1254:     	and	x26, x24, #0xf0
1000c1258:     	add	x26, x9, x26
1000c125c:     	lsr	x27, x24, #4
1000c1260:     	and	x27, x27, #0xf0
1000c1264:     	add	x27, x9, x27
1000c1268:     	lsr	x28, x24, #8
1000c126c:     	and	x28, x28, #0xf0
1000c1270:     	add	x28, x9, x28
1000c1274:     	lsr	x30, x24, #12
1000c1278:     	and	x30, x30, #0xf0
1000c127c:     	add	x30, x9, x30
1000c1280:     	lsr	x8, x24, #16
1000c1284:     	and	x8, x8, #0xf0
1000c1288:     	add	x8, x9, x8
1000c128c:     	lsr	x3, x24, #20
1000c1290:     	and	x3, x3, #0xf0
1000c1294:     	add	x3, x9, x3
1000c1298:     	lsr	x24, x24, #24
1000c129c:     	and	x24, x24, #0xf0
1000c12a0:     	ldrb	w10, [x25, x14]
1000c12a4:     	ldr	x12, [sp, #24]
1000c12a8:     	ldrb	w1, [x27, x12]
1000c12ac:     	ldrb	w12, [x30, x13]
1000c12b0:     	add	w10, w10, w1
1000c12b4:     	add	w10, w10, w12
1000c12b8:     	ldrb	w12, [x3, x15]
1000c12bc:     	ldrb	w1, [x26, x16]
1000c12c0:     	add	w10, w10, w12
1000c12c4:     	add	w10, w10, w1
1000c12c8:     	ldrb	w12, [x28, x17]
1000c12cc:     	ldrb	w1, [x8, x2]
1000c12d0:     	add	x24, x9, x24
1000c12d4:     	add	w10, w10, w12
1000c12d8:     	add	w10, w10, w1
1000c12dc:     	ldrb	w12, [x24, x4]
1000c12e0:     	add	w10, w10, w12
1000c12e4:     	scvtf	s0, w10
1000c12e8:     	add	x10, sp, #32
1000c12ec:     	add	x10, x10, x11
1000c12f0:     	ldr	s1, [x10]
1000c12f4:     	ldrb	w12, [x25, x5]
1000c12f8:     	fadd	s0, s1, s0
1000c12fc:     	ldrb	w1, [x27, x6]
1000c1300:     	ldrb	w25, [x30, x7]
1000c1304:     	add	w12, w12, w1
1000c1308:     	add	w12, w12, w25
1000c130c:     	ldrb	w1, [x3, x19]
1000c1310:     	ldrb	w3, [x26, x20]
1000c1314:     	add	w12, w12, w1
1000c1318:     	add	w12, w12, w3
1000c131c:     	ldrb	w1, [x28, x21]
1000c1320:     	ldrb	w8, [x8, x22]
1000c1324:     	add	w12, w12, w1
1000c1328:     	add	w8, w12, w8
1000c132c:     	ldrb	w12, [x24, x23]
1000c1330:     	add	w8, w8, w12
1000c1334:     	scvtf	s1, w8
1000c1338:     	str	s0, [x10]
1000c133c:     	ldr	s0, [x10, #32]
1000c1340:     	fadd	s0, s0, s1
1000c1344:     	str	s0, [x10, #32]
1000c1348:     	add	x11, x11, #4
1000c134c:     	cmp	x11, #32
1000c1350:     	b.ne	0x1000c1244 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1354:     	add	x0, x0, #32
1000c1358:     	ldp	x8, x1, [sp, #8]
1000c135c:     	add	x1, x1, #8
1000c1360:     	cmp	x1, x8
1000c1364:     	b.ne	0x1000c11f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1368:     	ldp	q0, q1, [sp, #32]
1000c136c:     	ldr	x8, [sp]
1000c1370:     	stp	q0, q1, [x8]
1000c1374:     	ldp	q0, q1, [sp, #64]
1000c1378:     	stp	q0, q1, [x8, #32]
1000c137c:     	ldur	x8, [x29, #-88]
1000c1380:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c0>
1000c1384:     	ldr	x9, [x9, #392]
1000c1388:     	ldr	x9, [x9]
1000c138c:     	cmp	x9, x8
1000c1390:     	b.ne	0x1000c13b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1394:     	ldp	x29, x30, [sp, #192]
1000c1398:     	ldp	x20, x19, [sp, #176]
1000c139c:     	ldp	x22, x21, [sp, #160]
1000c13a0:     	ldp	x24, x23, [sp, #144]
1000c13a4:     	ldp	x26, x25, [sp, #128]
1000c13a8:     	ldp	x28, x27, [sp, #112]
1000c13ac:     	add	sp, sp, #208
1000c13b0:     	ret
1000c13b4:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c146c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c146c:     	sub	sp, sp, #208
1000c1470:     	stp	x28, x27, [sp, #112]
1000c1474:     	stp	x26, x25, [sp, #128]
1000c1478:     	stp	x24, x23, [sp, #144]
1000c147c:     	stp	x22, x21, [sp, #160]
1000c1480:     	stp	x20, x19, [sp, #176]
1000c1484:     	stp	x29, x30, [sp, #192]
1000c1488:     	add	x29, sp, #192
1000c148c:     	str	x3, [sp]
1000c1490:     	adrp	x8, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xb8>
1000c1494:     	ldr	x8, [x8, #392]
1000c1498:     	ldr	x8, [x8]
1000c149c:     	stur	x8, [x29, #-88]
1000c14a0:     	movi.2d	v0, #0000000000000000
1000c14a4:     	stp	q0, q0, [sp, #64]
1000c14a8:     	stp	q0, q0, [sp, #32]
1000c14ac:     	ands	x8, x2, #0xfffffffffffffffe
1000c14b0:     	b.eq	0x1000c1634 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c14b4:     	add	x8, x1, x8
1000c14b8:     	str	x8, [sp, #8]
1000c14bc:     	adrp	x9, 0x10016a000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xdc>
1000c14c0:     	add	x9, x9, #956
1000c14c4:     	mov	x11, #0
1000c14c8:     	ldp	w4, w23, [x1]
1000c14cc:     	ubfx	x8, x4, #8, #4
1000c14d0:     	stp	x1, x8, [sp, #16]
1000c14d4:     	ubfx	x13, x4, #16, #4
1000c14d8:     	and	x14, x4, #0xf
1000c14dc:     	ubfx	x15, x4, #24, #4
1000c14e0:     	ubfx	x16, x4, #4, #4
1000c14e4:     	ubfx	x17, x4, #12, #4
1000c14e8:     	ubfx	x2, x4, #20, #4
1000c14ec:     	lsr	x4, x4, #28
1000c14f0:     	and	x5, x23, #0xf
1000c14f4:     	ubfx	x6, x23, #8, #4
1000c14f8:     	ubfx	x7, x23, #16, #4
1000c14fc:     	ubfx	x19, x23, #24, #4
1000c1500:     	ubfx	x20, x23, #4, #4
1000c1504:     	ubfx	x21, x23, #12, #4
1000c1508:     	ubfx	x22, x23, #20, #4
1000c150c:     	lsr	x23, x23, #28
1000c1510:     	ldr	w24, [x0, x11]
1000c1514:     	lsl	w25, w24, #4
1000c1518:     	and	x25, x25, #0xf0
1000c151c:     	add	x25, x9, x25
1000c1520:     	and	x26, x24, #0xf0
1000c1524:     	add	x26, x9, x26
1000c1528:     	lsr	x27, x24, #4
1000c152c:     	and	x27, x27, #0xf0
1000c1530:     	add	x27, x9, x27
1000c1534:     	lsr	x28, x24, #8
1000c1538:     	and	x28, x28, #0xf0
1000c153c:     	add	x28, x9, x28
1000c1540:     	lsr	x30, x24, #12
1000c1544:     	and	x30, x30, #0xf0
1000c1548:     	add	x30, x9, x30
1000c154c:     	lsr	x8, x24, #16
1000c1550:     	and	x8, x8, #0xf0
1000c1554:     	add	x8, x9, x8
1000c1558:     	lsr	x3, x24, #20
1000c155c:     	and	x3, x3, #0xf0
1000c1560:     	add	x3, x9, x3
1000c1564:     	lsr	x24, x24, #24
1000c1568:     	and	x24, x24, #0xf0
1000c156c:     	ldrsb	w10, [x25, x14]
1000c1570:     	ldr	x12, [sp, #24]
1000c1574:     	ldrsb	w1, [x27, x12]
1000c1578:     	ldrsb	w12, [x30, x13]
1000c157c:     	add	w10, w10, w1
1000c1580:     	add	w10, w10, w12
1000c1584:     	ldrsb	w12, [x3, x15]
1000c1588:     	ldrsb	w1, [x26, x16]
1000c158c:     	add	w10, w10, w12
1000c1590:     	add	w10, w10, w1
1000c1594:     	ldrsb	w12, [x28, x17]
1000c1598:     	ldrsb	w1, [x8, x2]
1000c159c:     	add	x24, x9, x24
1000c15a0:     	add	w10, w10, w12
1000c15a4:     	add	w10, w10, w1
1000c15a8:     	ldrsb	w12, [x24, x4]
1000c15ac:     	add	w10, w10, w12
1000c15b0:     	scvtf	s0, w10
1000c15b4:     	add	x10, sp, #32
1000c15b8:     	add	x10, x10, x11
1000c15bc:     	ldr	s1, [x10]
1000c15c0:     	ldrsb	w12, [x25, x5]
1000c15c4:     	fadd	s0, s1, s0
1000c15c8:     	ldrsb	w1, [x27, x6]
1000c15cc:     	ldrsb	w25, [x30, x7]
1000c15d0:     	add	w12, w12, w1
1000c15d4:     	add	w12, w12, w25
1000c15d8:     	ldrsb	w1, [x3, x19]
1000c15dc:     	ldrsb	w3, [x26, x20]
1000c15e0:     	add	w12, w12, w1
1000c15e4:     	add	w12, w12, w3
1000c15e8:     	ldrsb	w1, [x28, x21]
1000c15ec:     	ldrsb	w8, [x8, x22]
1000c15f0:     	add	w12, w12, w1
1000c15f4:     	add	w8, w12, w8
1000c15f8:     	ldrsb	w12, [x24, x23]
1000c15fc:     	add	w8, w8, w12
1000c1600:     	scvtf	s1, w8
1000c1604:     	str	s0, [x10]
1000c1608:     	ldr	s0, [x10, #32]
1000c160c:     	fadd	s0, s0, s1
1000c1610:     	str	s0, [x10, #32]
1000c1614:     	add	x11, x11, #4
1000c1618:     	cmp	x11, #32
1000c161c:     	b.ne	0x1000c1510 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1620:     	add	x0, x0, #32
1000c1624:     	ldp	x8, x1, [sp, #8]
1000c1628:     	add	x1, x1, #8
1000c162c:     	cmp	x1, x8
1000c1630:     	b.ne	0x1000c14c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1634:     	ldp	q0, q1, [sp, #32]
1000c1638:     	ldr	x8, [sp]
1000c163c:     	stp	q0, q1, [x8]
1000c1640:     	ldp	q0, q1, [sp, #64]
1000c1644:     	stp	q0, q1, [x8, #32]
1000c1648:     	ldur	x8, [x29, #-88]
1000c164c:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x274>
1000c1650:     	ldr	x9, [x9, #392]
1000c1654:     	ldr	x9, [x9]
1000c1658:     	cmp	x9, x8
1000c165c:     	b.ne	0x1000c1680 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1660:     	ldp	x29, x30, [sp, #192]
1000c1664:     	ldp	x20, x19, [sp, #176]
1000c1668:     	ldp	x22, x21, [sp, #160]
1000c166c:     	ldp	x24, x23, [sp, #144]
1000c1670:     	ldp	x26, x25, [sp, #128]
1000c1674:     	ldp	x28, x27, [sp, #112]
1000c1678:     	add	sp, sp, #208
1000c167c:     	ret
1000c1680:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c2f80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c2f80:     	sub	sp, sp, #416
1000c2f84:     	stp	x28, x27, [sp, #320]
1000c2f88:     	stp	x26, x25, [sp, #336]
1000c2f8c:     	stp	x24, x23, [sp, #352]
1000c2f90:     	stp	x22, x21, [sp, #368]
1000c2f94:     	stp	x20, x19, [sp, #384]
1000c2f98:     	stp	x29, x30, [sp, #400]
1000c2f9c:     	add	x29, sp, #400
1000c2fa0:     	str	x3, [sp]
1000c2fa4:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2cc>
1000c2fa8:     	ldr	x8, [x8, #392]
1000c2fac:     	ldr	x8, [x8]
1000c2fb0:     	stur	x8, [x29, #-96]
1000c2fb4:     	movi.2d	v0, #0000000000000000
1000c2fb8:     	stp	q0, q0, [sp, #272]
1000c2fbc:     	lsl	x8, x2, #1
1000c2fc0:     	stp	q0, q0, [sp, #240]
1000c2fc4:     	stp	q0, q0, [sp, #208]
1000c2fc8:     	stp	q0, q0, [sp, #176]
1000c2fcc:     	ands	x8, x8, #0xfffffffffffffffc
1000c2fd0:     	b.eq	0x1000c32ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c2fd4:     	add	x8, x1, x8
1000c2fd8:     	str	x8, [sp, #8]
1000c2fdc:     	add	x8, sp, #176
1000c2fe0:     	add	x27, x8, #64
1000c2fe4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x304>
1000c2fe8:     	add	x11, x11, #700
1000c2fec:     	mov	x12, #0
1000c2ff0:     	ldp	w8, w9, [x1]
1000c2ff4:     	ubfx	x10, x8, #8, #4
1000c2ff8:     	str	x10, [sp, #168]
1000c2ffc:     	ubfx	x10, x8, #16, #4
1000c3000:     	str	x10, [sp, #160]
1000c3004:     	ubfx	x10, x8, #24, #4
1000c3008:     	str	x10, [sp, #152]
1000c300c:     	ldp	w10, w17, [x1, #8]
1000c3010:     	str	x1, [sp, #16]
1000c3014:     	and	x14, x8, #0xf
1000c3018:     	ubfx	x13, x8, #4, #4
1000c301c:     	stp	x13, x14, [sp, #136]
1000c3020:     	ubfx	x14, x8, #12, #4
1000c3024:     	ubfx	x13, x8, #20, #4
1000c3028:     	stp	x13, x14, [sp, #120]
1000c302c:     	lsr	x8, x8, #28
1000c3030:     	str	x8, [sp, #112]
1000c3034:     	and	x8, x9, #0xf
1000c3038:     	str	x8, [sp, #104]
1000c303c:     	ubfx	x8, x9, #8, #4
1000c3040:     	str	x8, [sp, #96]
1000c3044:     	ubfx	x8, x9, #16, #4
1000c3048:     	str	x8, [sp, #88]
1000c304c:     	ubfx	x8, x9, #24, #4
1000c3050:     	str	x8, [sp, #80]
1000c3054:     	ubfx	x8, x9, #4, #4
1000c3058:     	str	x8, [sp, #72]
1000c305c:     	ubfx	x8, x9, #12, #4
1000c3060:     	str	x8, [sp, #64]
1000c3064:     	ubfx	x8, x9, #20, #4
1000c3068:     	str	x8, [sp, #56]
1000c306c:     	lsr	x8, x9, #28
1000c3070:     	str	x8, [sp, #48]
1000c3074:     	and	x9, x10, #0xf
1000c3078:     	ubfx	x8, x10, #8, #4
1000c307c:     	stp	x8, x9, [sp, #32]
1000c3080:     	ubfx	x8, x10, #16, #4
1000c3084:     	str	x8, [sp, #24]
1000c3088:     	ubfx	x28, x10, #24, #4
1000c308c:     	ubfx	x30, x10, #4, #4
1000c3090:     	ubfx	x8, x10, #12, #4
1000c3094:     	ubfx	x3, x10, #20, #4
1000c3098:     	lsr	x9, x10, #28
1000c309c:     	and	x1, x17, #0xf
1000c30a0:     	ubfx	x10, x17, #8, #4
1000c30a4:     	ubfx	x13, x17, #16, #4
1000c30a8:     	ubfx	x26, x17, #24, #4
1000c30ac:     	ubfx	x14, x17, #4, #4
1000c30b0:     	ubfx	x15, x17, #12, #4
1000c30b4:     	ubfx	x16, x17, #20, #4
1000c30b8:     	lsr	x17, x17, #28
1000c30bc:     	ldr	w20, [x0, x12]
1000c30c0:     	lsl	w2, w20, #4
1000c30c4:     	and	x2, x2, #0xf0
1000c30c8:     	add	x5, x11, x2
1000c30cc:     	and	x2, x20, #0xf0
1000c30d0:     	add	x2, x11, x2
1000c30d4:     	lsr	x4, x20, #4
1000c30d8:     	and	x4, x4, #0xf0
1000c30dc:     	add	x7, x11, x4
1000c30e0:     	lsr	x4, x20, #8
1000c30e4:     	and	x4, x4, #0xf0
1000c30e8:     	add	x4, x11, x4
1000c30ec:     	lsr	x6, x20, #12
1000c30f0:     	and	x6, x6, #0xf0
1000c30f4:     	add	x19, x11, x6
1000c30f8:     	lsr	x6, x20, #16
1000c30fc:     	and	x6, x6, #0xf0
1000c3100:     	add	x6, x11, x6
1000c3104:     	lsr	x21, x20, #20
1000c3108:     	and	x21, x21, #0xf0
1000c310c:     	add	x21, x11, x21
1000c3110:     	lsr	x20, x20, #24
1000c3114:     	and	x20, x20, #0xf0
1000c3118:     	ldr	x22, [sp, #144]
1000c311c:     	ldrb	w22, [x5, x22]
1000c3120:     	add	x20, x11, x20
1000c3124:     	ldp	x24, x23, [sp, #160]
1000c3128:     	ldrb	w23, [x7, x23]
1000c312c:     	ldrb	w24, [x19, x24]
1000c3130:     	add	w22, w22, w23
1000c3134:     	add	w22, w22, w24
1000c3138:     	ldr	x23, [sp, #152]
1000c313c:     	ldrb	w23, [x21, x23]
1000c3140:     	ldr	x24, [sp, #136]
1000c3144:     	ldrb	w24, [x2, x24]
1000c3148:     	add	w22, w22, w23
1000c314c:     	add	w22, w22, w24
1000c3150:     	ldp	x24, x23, [sp, #120]
1000c3154:     	ldrb	w23, [x4, x23]
1000c3158:     	ldrb	w24, [x6, x24]
1000c315c:     	add	w22, w22, w23
1000c3160:     	add	w22, w22, w24
1000c3164:     	ldr	x23, [sp, #112]
1000c3168:     	ldrb	w23, [x20, x23]
1000c316c:     	add	w22, w22, w23
1000c3170:     	scvtf	s0, w22
1000c3174:     	ldp	x23, x22, [sp, #96]
1000c3178:     	ldrb	w22, [x5, x22]
1000c317c:     	ldrb	w23, [x7, x23]
1000c3180:     	ldp	x25, x24, [sp, #80]
1000c3184:     	ldrb	w24, [x19, x24]
1000c3188:     	ldrb	w25, [x21, x25]
1000c318c:     	add	w22, w22, w23
1000c3190:     	ldr	x23, [sp, #72]
1000c3194:     	ldrb	w23, [x2, x23]
1000c3198:     	add	w22, w22, w24
1000c319c:     	ldr	x24, [sp, #64]
1000c31a0:     	ldrb	w24, [x4, x24]
1000c31a4:     	add	w22, w22, w25
1000c31a8:     	ldr	x25, [sp, #56]
1000c31ac:     	ldrb	w25, [x6, x25]
1000c31b0:     	add	w22, w22, w23
1000c31b4:     	add	w22, w22, w24
1000c31b8:     	add	w22, w22, w25
1000c31bc:     	ldr	x23, [sp, #48]
1000c31c0:     	ldrb	w23, [x20, x23]
1000c31c4:     	add	w22, w22, w23
1000c31c8:     	scvtf	s1, w22
1000c31cc:     	ldp	x23, x22, [sp, #32]
1000c31d0:     	ldrb	w22, [x5, x22]
1000c31d4:     	ldrb	w23, [x7, x23]
1000c31d8:     	ldr	x24, [sp, #24]
1000c31dc:     	ldrb	w24, [x19, x24]
1000c31e0:     	add	w22, w22, w23
1000c31e4:     	ldrb	w23, [x21, x28]
1000c31e8:     	add	w22, w22, w24
1000c31ec:     	ldrb	w24, [x2, x30]
1000c31f0:     	add	w22, w22, w23
1000c31f4:     	ldrb	w23, [x4, x8]
1000c31f8:     	add	w22, w22, w24
1000c31fc:     	ldrb	w24, [x6, x3]
1000c3200:     	add	w22, w22, w23
1000c3204:     	ldrb	w23, [x20, x9]
1000c3208:     	add	w22, w22, w24
1000c320c:     	add	w22, w22, w23
1000c3210:     	scvtf	s2, w22
1000c3214:     	ldrb	w5, [x5, x1]
1000c3218:     	ldrb	w7, [x7, x10]
1000c321c:     	ldrb	w19, [x19, x13]
1000c3220:     	add	w5, w5, w7
1000c3224:     	add	w5, w5, w19
1000c3228:     	ldrb	w7, [x21, x26]
1000c322c:     	ldrb	w2, [x2, x14]
1000c3230:     	add	w5, w5, w7
1000c3234:     	add	w2, w5, w2
1000c3238:     	ldrb	w4, [x4, x15]
1000c323c:     	ldrb	w5, [x6, x16]
1000c3240:     	add	w2, w2, w4
1000c3244:     	add	w2, w2, w5
1000c3248:     	ldrb	w4, [x20, x17]
1000c324c:     	add	w2, w2, w4
1000c3250:     	add	x4, sp, #176
1000c3254:     	scvtf	s3, w2
1000c3258:     	add	x2, x27, x12
1000c325c:     	ldur	s4, [x2, #-32]
1000c3260:     	fadd	s1, s4, s1
1000c3264:     	stur	s1, [x2, #-32]
1000c3268:     	ldr	s1, [x2]
1000c326c:     	fadd	s1, s1, s2
1000c3270:     	str	s1, [x2]
1000c3274:     	ldr	s1, [x2, #32]
1000c3278:     	fadd	s1, s1, s3
1000c327c:     	ldr	s2, [x4, x12]
1000c3280:     	str	s1, [x2, #32]
1000c3284:     	fadd	s0, s2, s0
1000c3288:     	str	s0, [x4, x12]
1000c328c:     	add	x12, x12, #4
1000c3290:     	cmp	x12, #32
1000c3294:     	b.ne	0x1000c30bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3298:     	add	x0, x0, #32
1000c329c:     	ldp	x8, x1, [sp, #8]
1000c32a0:     	add	x1, x1, #16
1000c32a4:     	cmp	x1, x8
1000c32a8:     	b.ne	0x1000c2fec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c32ac:     	ldp	q0, q1, [sp, #240]
1000c32b0:     	ldr	x8, [sp]
1000c32b4:     	stp	q0, q1, [x8, #64]
1000c32b8:     	ldp	q0, q1, [sp, #272]
1000c32bc:     	stp	q0, q1, [x8, #96]
1000c32c0:     	ldp	q0, q1, [sp, #176]
1000c32c4:     	stp	q0, q1, [x8]
1000c32c8:     	ldp	q0, q1, [sp, #208]
1000c32cc:     	stp	q0, q1, [x8, #32]
1000c32d0:     	ldur	x8, [x29, #-96]
1000c32d4:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000c32d8:     	ldr	x9, [x9, #392]
1000c32dc:     	ldr	x9, [x9]
1000c32e0:     	cmp	x9, x8
1000c32e4:     	b.ne	0x1000c3308 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c32e8:     	ldp	x29, x30, [sp, #400]
1000c32ec:     	ldp	x20, x19, [sp, #384]
1000c32f0:     	ldp	x22, x21, [sp, #368]
1000c32f4:     	ldp	x24, x23, [sp, #352]
1000c32f8:     	ldp	x26, x25, [sp, #336]
1000c32fc:     	ldp	x28, x27, [sp, #320]
1000c3300:     	add	sp, sp, #416
1000c3304:     	ret
1000c3308:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c340c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c340c:     	sub	sp, sp, #416
1000c3410:     	stp	x28, x27, [sp, #320]
1000c3414:     	stp	x26, x25, [sp, #336]
1000c3418:     	stp	x24, x23, [sp, #352]
1000c341c:     	stp	x22, x21, [sp, #368]
1000c3420:     	stp	x20, x19, [sp, #384]
1000c3424:     	stp	x29, x30, [sp, #400]
1000c3428:     	add	x29, sp, #400
1000c342c:     	str	x3, [sp]
1000c3430:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
1000c3434:     	ldr	x8, [x8, #392]
1000c3438:     	ldr	x8, [x8]
1000c343c:     	stur	x8, [x29, #-96]
1000c3440:     	movi.2d	v0, #0000000000000000
1000c3444:     	stp	q0, q0, [sp, #272]
1000c3448:     	lsl	x8, x2, #1
1000c344c:     	stp	q0, q0, [sp, #240]
1000c3450:     	stp	q0, q0, [sp, #208]
1000c3454:     	stp	q0, q0, [sp, #176]
1000c3458:     	ands	x8, x8, #0xfffffffffffffffc
1000c345c:     	b.eq	0x1000c3738 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c3460:     	add	x8, x1, x8
1000c3464:     	str	x8, [sp, #8]
1000c3468:     	add	x8, sp, #176
1000c346c:     	add	x27, x8, #64
1000c3470:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x300>
1000c3474:     	add	x11, x11, #956
1000c3478:     	mov	x12, #0
1000c347c:     	ldp	w8, w9, [x1]
1000c3480:     	ubfx	x10, x8, #8, #4
1000c3484:     	str	x10, [sp, #168]
1000c3488:     	ubfx	x10, x8, #16, #4
1000c348c:     	str	x10, [sp, #160]
1000c3490:     	ubfx	x10, x8, #24, #4
1000c3494:     	str	x10, [sp, #152]
1000c3498:     	ldp	w10, w17, [x1, #8]
1000c349c:     	str	x1, [sp, #16]
1000c34a0:     	and	x14, x8, #0xf
1000c34a4:     	ubfx	x13, x8, #4, #4
1000c34a8:     	stp	x13, x14, [sp, #136]
1000c34ac:     	ubfx	x14, x8, #12, #4
1000c34b0:     	ubfx	x13, x8, #20, #4
1000c34b4:     	stp	x13, x14, [sp, #120]
1000c34b8:     	lsr	x8, x8, #28
1000c34bc:     	str	x8, [sp, #112]
1000c34c0:     	and	x8, x9, #0xf
1000c34c4:     	str	x8, [sp, #104]
1000c34c8:     	ubfx	x8, x9, #8, #4
1000c34cc:     	str	x8, [sp, #96]
1000c34d0:     	ubfx	x8, x9, #16, #4
1000c34d4:     	str	x8, [sp, #88]
1000c34d8:     	ubfx	x8, x9, #24, #4
1000c34dc:     	str	x8, [sp, #80]
1000c34e0:     	ubfx	x8, x9, #4, #4
1000c34e4:     	str	x8, [sp, #72]
1000c34e8:     	ubfx	x8, x9, #12, #4
1000c34ec:     	str	x8, [sp, #64]
1000c34f0:     	ubfx	x8, x9, #20, #4
1000c34f4:     	str	x8, [sp, #56]
1000c34f8:     	lsr	x8, x9, #28
1000c34fc:     	str	x8, [sp, #48]
1000c3500:     	and	x9, x10, #0xf
1000c3504:     	ubfx	x8, x10, #8, #4
1000c3508:     	stp	x8, x9, [sp, #32]
1000c350c:     	ubfx	x8, x10, #16, #4
1000c3510:     	str	x8, [sp, #24]
1000c3514:     	ubfx	x28, x10, #24, #4
1000c3518:     	ubfx	x30, x10, #4, #4
1000c351c:     	ubfx	x8, x10, #12, #4
1000c3520:     	ubfx	x3, x10, #20, #4
1000c3524:     	lsr	x9, x10, #28
1000c3528:     	and	x1, x17, #0xf
1000c352c:     	ubfx	x10, x17, #8, #4
1000c3530:     	ubfx	x13, x17, #16, #4
1000c3534:     	ubfx	x26, x17, #24, #4
1000c3538:     	ubfx	x14, x17, #4, #4
1000c353c:     	ubfx	x15, x17, #12, #4
1000c3540:     	ubfx	x16, x17, #20, #4
1000c3544:     	lsr	x17, x17, #28
1000c3548:     	ldr	w20, [x0, x12]
1000c354c:     	lsl	w2, w20, #4
1000c3550:     	and	x2, x2, #0xf0
1000c3554:     	add	x5, x11, x2
1000c3558:     	and	x2, x20, #0xf0
1000c355c:     	add	x2, x11, x2
1000c3560:     	lsr	x4, x20, #4
1000c3564:     	and	x4, x4, #0xf0
1000c3568:     	add	x7, x11, x4
1000c356c:     	lsr	x4, x20, #8
1000c3570:     	and	x4, x4, #0xf0
1000c3574:     	add	x4, x11, x4
1000c3578:     	lsr	x6, x20, #12
1000c357c:     	and	x6, x6, #0xf0
1000c3580:     	add	x19, x11, x6
1000c3584:     	lsr	x6, x20, #16
1000c3588:     	and	x6, x6, #0xf0
1000c358c:     	add	x6, x11, x6
1000c3590:     	lsr	x21, x20, #20
1000c3594:     	and	x21, x21, #0xf0
1000c3598:     	add	x21, x11, x21
1000c359c:     	lsr	x20, x20, #24
1000c35a0:     	and	x20, x20, #0xf0
1000c35a4:     	ldr	x22, [sp, #144]
1000c35a8:     	ldrsb	w22, [x5, x22]
1000c35ac:     	add	x20, x11, x20
1000c35b0:     	ldp	x24, x23, [sp, #160]
1000c35b4:     	ldrsb	w23, [x7, x23]
1000c35b8:     	ldrsb	w24, [x19, x24]
1000c35bc:     	add	w22, w22, w23
1000c35c0:     	add	w22, w22, w24
1000c35c4:     	ldr	x23, [sp, #152]
1000c35c8:     	ldrsb	w23, [x21, x23]
1000c35cc:     	ldr	x24, [sp, #136]
1000c35d0:     	ldrsb	w24, [x2, x24]
1000c35d4:     	add	w22, w22, w23
1000c35d8:     	add	w22, w22, w24
1000c35dc:     	ldp	x24, x23, [sp, #120]
1000c35e0:     	ldrsb	w23, [x4, x23]
1000c35e4:     	ldrsb	w24, [x6, x24]
1000c35e8:     	add	w22, w22, w23
1000c35ec:     	add	w22, w22, w24
1000c35f0:     	ldr	x23, [sp, #112]
1000c35f4:     	ldrsb	w23, [x20, x23]
1000c35f8:     	add	w22, w22, w23
1000c35fc:     	scvtf	s0, w22
1000c3600:     	ldp	x23, x22, [sp, #96]
1000c3604:     	ldrsb	w22, [x5, x22]
1000c3608:     	ldrsb	w23, [x7, x23]
1000c360c:     	ldp	x25, x24, [sp, #80]
1000c3610:     	ldrsb	w24, [x19, x24]
1000c3614:     	ldrsb	w25, [x21, x25]
1000c3618:     	add	w22, w22, w23
1000c361c:     	ldr	x23, [sp, #72]
1000c3620:     	ldrsb	w23, [x2, x23]
1000c3624:     	add	w22, w22, w24
1000c3628:     	ldr	x24, [sp, #64]
1000c362c:     	ldrsb	w24, [x4, x24]
1000c3630:     	add	w22, w22, w25
1000c3634:     	ldr	x25, [sp, #56]
1000c3638:     	ldrsb	w25, [x6, x25]
1000c363c:     	add	w22, w22, w23
1000c3640:     	add	w22, w22, w24
1000c3644:     	add	w22, w22, w25
1000c3648:     	ldr	x23, [sp, #48]
1000c364c:     	ldrsb	w23, [x20, x23]
1000c3650:     	add	w22, w22, w23
1000c3654:     	scvtf	s1, w22
1000c3658:     	ldp	x23, x22, [sp, #32]
1000c365c:     	ldrsb	w22, [x5, x22]
1000c3660:     	ldrsb	w23, [x7, x23]
1000c3664:     	ldr	x24, [sp, #24]
1000c3668:     	ldrsb	w24, [x19, x24]
1000c366c:     	add	w22, w22, w23
1000c3670:     	ldrsb	w23, [x21, x28]
1000c3674:     	add	w22, w22, w24
1000c3678:     	ldrsb	w24, [x2, x30]
1000c367c:     	add	w22, w22, w23
1000c3680:     	ldrsb	w23, [x4, x8]
1000c3684:     	add	w22, w22, w24
1000c3688:     	ldrsb	w24, [x6, x3]
1000c368c:     	add	w22, w22, w23
1000c3690:     	ldrsb	w23, [x20, x9]
1000c3694:     	add	w22, w22, w24
1000c3698:     	add	w22, w22, w23
1000c369c:     	scvtf	s2, w22
1000c36a0:     	ldrsb	w5, [x5, x1]
1000c36a4:     	ldrsb	w7, [x7, x10]
1000c36a8:     	ldrsb	w19, [x19, x13]
1000c36ac:     	add	w5, w5, w7
1000c36b0:     	add	w5, w5, w19
1000c36b4:     	ldrsb	w7, [x21, x26]
1000c36b8:     	ldrsb	w2, [x2, x14]
1000c36bc:     	add	w5, w5, w7
1000c36c0:     	add	w2, w5, w2
1000c36c4:     	ldrsb	w4, [x4, x15]
1000c36c8:     	ldrsb	w5, [x6, x16]
1000c36cc:     	add	w2, w2, w4
1000c36d0:     	add	w2, w2, w5
1000c36d4:     	ldrsb	w4, [x20, x17]
1000c36d8:     	add	w2, w2, w4
1000c36dc:     	add	x4, sp, #176
1000c36e0:     	scvtf	s3, w2
1000c36e4:     	add	x2, x27, x12
1000c36e8:     	ldur	s4, [x2, #-32]
1000c36ec:     	fadd	s1, s4, s1
1000c36f0:     	stur	s1, [x2, #-32]
1000c36f4:     	ldr	s1, [x2]
1000c36f8:     	fadd	s1, s1, s2
1000c36fc:     	str	s1, [x2]
1000c3700:     	ldr	s1, [x2, #32]
1000c3704:     	fadd	s1, s1, s3
1000c3708:     	ldr	s2, [x4, x12]
1000c370c:     	str	s1, [x2, #32]
1000c3710:     	fadd	s0, s2, s0
1000c3714:     	str	s0, [x4, x12]
1000c3718:     	add	x12, x12, #4
1000c371c:     	cmp	x12, #32
1000c3720:     	b.ne	0x1000c3548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3724:     	add	x0, x0, #32
1000c3728:     	ldp	x8, x1, [sp, #8]
1000c372c:     	add	x1, x1, #16
1000c3730:     	cmp	x1, x8
1000c3734:     	b.ne	0x1000c3478 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c3738:     	ldp	q0, q1, [sp, #240]
1000c373c:     	ldr	x8, [sp]
1000c3740:     	stp	q0, q1, [x8, #64]
1000c3744:     	ldp	q0, q1, [sp, #272]
1000c3748:     	stp	q0, q1, [x8, #96]
1000c374c:     	ldp	q0, q1, [sp, #176]
1000c3750:     	stp	q0, q1, [x8]
1000c3754:     	ldp	q0, q1, [sp, #208]
1000c3758:     	stp	q0, q1, [x8, #32]
1000c375c:     	ldur	x8, [x29, #-96]
1000c3760:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 8ul, false>(char const*)+0x26c>
1000c3764:     	ldr	x9, [x9, #392]
1000c3768:     	ldr	x9, [x9]
1000c376c:     	cmp	x9, x8
1000c3770:     	b.ne	0x1000c3794 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c3774:     	ldp	x29, x30, [sp, #400]
1000c3778:     	ldp	x20, x19, [sp, #384]
1000c377c:     	ldp	x22, x21, [sp, #368]
1000c3780:     	ldp	x24, x23, [sp, #352]
1000c3784:     	ldp	x26, x25, [sp, #336]
1000c3788:     	ldp	x28, x27, [sp, #320]
1000c378c:     	add	sp, sp, #416
1000c3790:     	ret
1000c3794:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c4d24 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c4d24:     	stp	x28, x27, [sp, #-96]!
1000c4d28:     	stp	x26, x25, [sp, #16]
1000c4d2c:     	stp	x24, x23, [sp, #32]
1000c4d30:     	stp	x22, x21, [sp, #48]
1000c4d34:     	stp	x20, x19, [sp, #64]
1000c4d38:     	stp	x29, x30, [sp, #80]
1000c4d3c:     	add	x29, sp, #80
1000c4d40:     	sub	sp, sp, #720
1000c4d44:     	str	x3, [sp, #8]
1000c4d48:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c4>
1000c4d4c:     	ldr	x8, [x8, #392]
1000c4d50:     	ldr	x8, [x8]
1000c4d54:     	stur	x8, [x29, #-96]
1000c4d58:     	movi.2d	v0, #0000000000000000
1000c4d5c:     	stp	q0, q0, [sp, #672]
1000c4d60:     	lsl	x8, x2, #2
1000c4d64:     	stp	q0, q0, [sp, #640]
1000c4d68:     	stp	q0, q0, [sp, #608]
1000c4d6c:     	stp	q0, q0, [sp, #576]
1000c4d70:     	stp	q0, q0, [sp, #544]
1000c4d74:     	stp	q0, q0, [sp, #512]
1000c4d78:     	stp	q0, q0, [sp, #480]
1000c4d7c:     	stp	q0, q0, [sp, #448]
1000c4d80:     	ands	x8, x8, #0xfffffffffffffff8
1000c4d84:     	b.eq	0x1000c52d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c4d88:     	add	x8, x1, x8
1000c4d8c:     	str	x8, [sp, #16]
1000c4d90:     	add	x8, sp, #448
1000c4d94:     	add	x19, x8, #128
1000c4d98:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000c4d9c:     	add	x11, x11, #700
1000c4da0:     	mov	x12, #0
1000c4da4:     	ldp	w8, w9, [x1]
1000c4da8:     	ubfx	x10, x8, #8, #4
1000c4dac:     	str	x10, [sp, #440]
1000c4db0:     	ubfx	x10, x8, #16, #4
1000c4db4:     	str	x10, [sp, #432]
1000c4db8:     	ubfx	x10, x8, #24, #4
1000c4dbc:     	str	x10, [sp, #424]
1000c4dc0:     	ldp	w10, w13, [x1, #8]
1000c4dc4:     	and	x15, x8, #0xf
1000c4dc8:     	ubfx	x14, x8, #4, #4
1000c4dcc:     	stp	x14, x15, [sp, #408]
1000c4dd0:     	ubfx	x15, x8, #12, #4
1000c4dd4:     	ubfx	x14, x8, #20, #4
1000c4dd8:     	stp	x14, x15, [sp, #392]
1000c4ddc:     	lsr	x8, x8, #28
1000c4de0:     	str	x8, [sp, #384]
1000c4de4:     	and	x8, x9, #0xf
1000c4de8:     	str	x8, [sp, #376]
1000c4dec:     	ubfx	x8, x9, #8, #4
1000c4df0:     	str	x8, [sp, #368]
1000c4df4:     	ubfx	x8, x9, #16, #4
1000c4df8:     	str	x8, [sp, #360]
1000c4dfc:     	ubfx	x8, x9, #24, #4
1000c4e00:     	str	x8, [sp, #352]
1000c4e04:     	ubfx	x8, x9, #4, #4
1000c4e08:     	str	x8, [sp, #344]
1000c4e0c:     	ubfx	x8, x9, #12, #4
1000c4e10:     	str	x8, [sp, #336]
1000c4e14:     	ubfx	x8, x9, #20, #4
1000c4e18:     	str	x8, [sp, #328]
1000c4e1c:     	lsr	x8, x9, #28
1000c4e20:     	str	x8, [sp, #320]
1000c4e24:     	and	x9, x10, #0xf
1000c4e28:     	ubfx	x8, x10, #8, #4
1000c4e2c:     	stp	x8, x9, [sp, #304]
1000c4e30:     	ubfx	x9, x10, #16, #4
1000c4e34:     	ubfx	x8, x10, #24, #4
1000c4e38:     	stp	x8, x9, [sp, #288]
1000c4e3c:     	ubfx	x9, x10, #4, #4
1000c4e40:     	ubfx	x8, x10, #12, #4
1000c4e44:     	stp	x8, x9, [sp, #272]
1000c4e48:     	ubfx	x9, x10, #20, #4
1000c4e4c:     	lsr	x8, x10, #28
1000c4e50:     	stp	x8, x9, [sp, #256]
1000c4e54:     	and	x9, x13, #0xf
1000c4e58:     	ubfx	x8, x13, #8, #4
1000c4e5c:     	stp	x8, x9, [sp, #240]
1000c4e60:     	ubfx	x9, x13, #16, #4
1000c4e64:     	ubfx	x8, x13, #24, #4
1000c4e68:     	stp	x8, x9, [sp, #224]
1000c4e6c:     	ubfx	x9, x13, #4, #4
1000c4e70:     	ubfx	x8, x13, #12, #4
1000c4e74:     	stp	x8, x9, [sp, #208]
1000c4e78:     	ubfx	x9, x13, #20, #4
1000c4e7c:     	lsr	x8, x13, #28
1000c4e80:     	stp	x8, x9, [sp, #192]
1000c4e84:     	ldp	w8, w9, [x1, #16]
1000c4e88:     	and	x10, x8, #0xf
1000c4e8c:     	str	x10, [sp, #184]
1000c4e90:     	ubfx	x10, x8, #8, #4
1000c4e94:     	str	x10, [sp, #176]
1000c4e98:     	ubfx	x10, x8, #16, #4
1000c4e9c:     	str	x10, [sp, #168]
1000c4ea0:     	ubfx	x10, x8, #24, #4
1000c4ea4:     	str	x10, [sp, #160]
1000c4ea8:     	ubfx	x10, x8, #4, #4
1000c4eac:     	str	x10, [sp, #152]
1000c4eb0:     	ubfx	x10, x8, #12, #4
1000c4eb4:     	str	x10, [sp, #144]
1000c4eb8:     	ubfx	x10, x8, #20, #4
1000c4ebc:     	lsr	x8, x8, #28
1000c4ec0:     	stp	x8, x10, [sp, #128]
1000c4ec4:     	and	x10, x9, #0xf
1000c4ec8:     	ubfx	x8, x9, #8, #4
1000c4ecc:     	stp	x8, x10, [sp, #112]
1000c4ed0:     	ubfx	x10, x9, #16, #4
1000c4ed4:     	ubfx	x8, x9, #24, #4
1000c4ed8:     	stp	x8, x10, [sp, #96]
1000c4edc:     	ubfx	x10, x9, #4, #4
1000c4ee0:     	ubfx	x8, x9, #12, #4
1000c4ee4:     	stp	x8, x10, [sp, #80]
1000c4ee8:     	ubfx	x10, x9, #20, #4
1000c4eec:     	lsr	x8, x9, #28
1000c4ef0:     	stp	x8, x10, [sp, #64]
1000c4ef4:     	ldp	w14, w7, [x1, #24]
1000c4ef8:     	and	x9, x14, #0xf
1000c4efc:     	ubfx	x8, x14, #8, #4
1000c4f00:     	stp	x8, x9, [sp, #48]
1000c4f04:     	ubfx	x8, x14, #16, #4
1000c4f08:     	str	x8, [sp, #40]
1000c4f0c:     	ubfx	x8, x14, #24, #4
1000c4f10:     	stp	x1, x8, [sp, #24]
1000c4f14:     	ubfx	x10, x14, #4, #4
1000c4f18:     	ubfx	x13, x14, #12, #4
1000c4f1c:     	ubfx	x9, x14, #20, #4
1000c4f20:     	lsr	x14, x14, #28
1000c4f24:     	and	x15, x7, #0xf
1000c4f28:     	ubfx	x16, x7, #8, #4
1000c4f2c:     	ubfx	x17, x7, #16, #4
1000c4f30:     	ubfx	x2, x7, #24, #4
1000c4f34:     	ubfx	x4, x7, #4, #4
1000c4f38:     	ubfx	x5, x7, #12, #4
1000c4f3c:     	ubfx	x6, x7, #20, #4
1000c4f40:     	lsr	x7, x7, #28
1000c4f44:     	ldr	w26, [x0, x12]
1000c4f48:     	mov	x1, x19
1000c4f4c:     	lsl	w19, w26, #4
1000c4f50:     	and	x19, x19, #0xf0
1000c4f54:     	add	x19, x11, x19
1000c4f58:     	ldr	x8, [sp, #416]
1000c4f5c:     	ldrb	w25, [x19, x8]
1000c4f60:     	lsr	x20, x26, #4
1000c4f64:     	and	x20, x20, #0xf0
1000c4f68:     	add	x20, x11, x20
1000c4f6c:     	ldr	x8, [sp, #440]
1000c4f70:     	ldrb	w27, [x20, x8]
1000c4f74:     	lsr	x21, x26, #12
1000c4f78:     	and	x21, x21, #0xf0
1000c4f7c:     	add	x21, x11, x21
1000c4f80:     	ldr	x8, [sp, #432]
1000c4f84:     	ldrb	w28, [x21, x8]
1000c4f88:     	lsr	x22, x26, #20
1000c4f8c:     	and	x22, x22, #0xf0
1000c4f90:     	add	x23, x11, x22
1000c4f94:     	ldr	x8, [sp, #424]
1000c4f98:     	ldrb	w30, [x23, x8]
1000c4f9c:     	and	x22, x26, #0xf0
1000c4fa0:     	add	x22, x11, x22
1000c4fa4:     	ldp	x3, x8, [sp, #400]
1000c4fa8:     	ldrb	w8, [x22, x8]
1000c4fac:     	lsr	x24, x26, #8
1000c4fb0:     	and	x24, x24, #0xf0
1000c4fb4:     	add	x24, x11, x24
1000c4fb8:     	ldrb	w3, [x24, x3]
1000c4fbc:     	add	w27, w25, w27
1000c4fc0:     	lsr	x25, x26, #16
1000c4fc4:     	and	x25, x25, #0xf0
1000c4fc8:     	add	x25, x11, x25
1000c4fcc:     	add	w27, w27, w28
1000c4fd0:     	ldr	x28, [sp, #392]
1000c4fd4:     	ldrb	w28, [x25, x28]
1000c4fd8:     	lsr	x26, x26, #24
1000c4fdc:     	and	x26, x26, #0xf0
1000c4fe0:     	add	x26, x11, x26
1000c4fe4:     	add	w27, w27, w30
1000c4fe8:     	ldr	x30, [sp, #384]
1000c4fec:     	ldrb	w30, [x26, x30]
1000c4ff0:     	add	w8, w27, w8
1000c4ff4:     	add	w8, w8, w3
1000c4ff8:     	add	w8, w8, w28
1000c4ffc:     	add	w8, w8, w30
1000c5000:     	scvtf	s0, w8
1000c5004:     	ldp	x3, x8, [sp, #368]
1000c5008:     	ldrb	w8, [x19, x8]
1000c500c:     	ldrb	w3, [x20, x3]
1000c5010:     	ldp	x28, x27, [sp, #352]
1000c5014:     	ldrb	w27, [x21, x27]
1000c5018:     	ldrb	w28, [x23, x28]
1000c501c:     	ldr	x30, [sp, #344]
1000c5020:     	ldrb	w30, [x22, x30]
1000c5024:     	add	w8, w8, w3
1000c5028:     	ldr	x3, [sp, #336]
1000c502c:     	ldrb	w3, [x24, x3]
1000c5030:     	add	w8, w8, w27
1000c5034:     	ldr	x27, [sp, #328]
1000c5038:     	ldrb	w27, [x25, x27]
1000c503c:     	add	w8, w8, w28
1000c5040:     	ldr	x28, [sp, #320]
1000c5044:     	ldrb	w28, [x26, x28]
1000c5048:     	add	w8, w8, w30
1000c504c:     	add	w8, w8, w3
1000c5050:     	add	w8, w8, w27
1000c5054:     	add	w8, w8, w28
1000c5058:     	scvtf	s1, w8
1000c505c:     	ldp	x3, x8, [sp, #304]
1000c5060:     	ldrb	w8, [x19, x8]
1000c5064:     	ldrb	w3, [x20, x3]
1000c5068:     	ldp	x28, x27, [sp, #288]
1000c506c:     	ldrb	w27, [x21, x27]
1000c5070:     	ldrb	w28, [x23, x28]
1000c5074:     	add	w8, w8, w3
1000c5078:     	ldr	x3, [sp, #280]
1000c507c:     	ldrb	w3, [x22, x3]
1000c5080:     	add	w8, w8, w27
1000c5084:     	ldr	x27, [sp, #272]
1000c5088:     	ldrb	w27, [x24, x27]
1000c508c:     	add	w8, w8, w28
1000c5090:     	ldr	x28, [sp, #264]
1000c5094:     	ldrb	w28, [x25, x28]
1000c5098:     	add	w8, w8, w3
1000c509c:     	ldr	x3, [sp, #256]
1000c50a0:     	ldrb	w3, [x26, x3]
1000c50a4:     	add	w8, w8, w27
1000c50a8:     	add	w8, w8, w28
1000c50ac:     	add	w8, w8, w3
1000c50b0:     	scvtf	s2, w8
1000c50b4:     	ldp	x3, x8, [sp, #240]
1000c50b8:     	ldrb	w8, [x19, x8]
1000c50bc:     	ldrb	w3, [x20, x3]
1000c50c0:     	ldp	x28, x27, [sp, #224]
1000c50c4:     	ldrb	w27, [x21, x27]
1000c50c8:     	ldrb	w28, [x23, x28]
1000c50cc:     	add	w8, w8, w3
1000c50d0:     	ldr	x3, [sp, #216]
1000c50d4:     	ldrb	w3, [x22, x3]
1000c50d8:     	add	w8, w8, w27
1000c50dc:     	ldr	x27, [sp, #208]
1000c50e0:     	ldrb	w27, [x24, x27]
1000c50e4:     	add	w8, w8, w28
1000c50e8:     	ldr	x28, [sp, #200]
1000c50ec:     	ldrb	w28, [x25, x28]
1000c50f0:     	add	w8, w8, w3
1000c50f4:     	ldr	x3, [sp, #192]
1000c50f8:     	ldrb	w3, [x26, x3]
1000c50fc:     	add	w8, w8, w27
1000c5100:     	add	w8, w8, w28
1000c5104:     	add	w8, w8, w3
1000c5108:     	scvtf	s3, w8
1000c510c:     	ldp	x3, x8, [sp, #176]
1000c5110:     	ldrb	w8, [x19, x8]
1000c5114:     	ldrb	w3, [x20, x3]
1000c5118:     	ldp	x28, x27, [sp, #160]
1000c511c:     	ldrb	w27, [x21, x27]
1000c5120:     	ldrb	w28, [x23, x28]
1000c5124:     	add	w8, w8, w3
1000c5128:     	add	w8, w8, w27
1000c512c:     	ldr	x3, [sp, #152]
1000c5130:     	ldrb	w3, [x22, x3]
1000c5134:     	add	w8, w8, w28
1000c5138:     	add	w8, w8, w3
1000c513c:     	ldp	x27, x3, [sp, #136]
1000c5140:     	ldrb	w3, [x24, x3]
1000c5144:     	ldrb	w27, [x25, x27]
1000c5148:     	add	w8, w8, w3
1000c514c:     	add	w8, w8, w27
1000c5150:     	ldr	x3, [sp, #128]
1000c5154:     	ldrb	w3, [x26, x3]
1000c5158:     	add	w8, w8, w3
1000c515c:     	scvtf	s4, w8
1000c5160:     	ldp	x3, x8, [sp, #112]
1000c5164:     	ldrb	w8, [x19, x8]
1000c5168:     	ldrb	w3, [x20, x3]
1000c516c:     	ldp	x28, x27, [sp, #96]
1000c5170:     	ldrb	w27, [x21, x27]
1000c5174:     	ldrb	w28, [x23, x28]
1000c5178:     	add	w8, w8, w3
1000c517c:     	ldr	x3, [sp, #88]
1000c5180:     	ldrb	w3, [x22, x3]
1000c5184:     	add	w8, w8, w27
1000c5188:     	ldr	x27, [sp, #80]
1000c518c:     	ldrb	w27, [x24, x27]
1000c5190:     	add	w8, w8, w28
1000c5194:     	ldr	x28, [sp, #72]
1000c5198:     	ldrb	w28, [x25, x28]
1000c519c:     	add	w8, w8, w3
1000c51a0:     	add	w8, w8, w27
1000c51a4:     	add	w8, w8, w28
1000c51a8:     	ldr	x3, [sp, #64]
1000c51ac:     	ldrb	w3, [x26, x3]
1000c51b0:     	add	w8, w8, w3
1000c51b4:     	scvtf	s5, w8
1000c51b8:     	ldp	x3, x8, [sp, #48]
1000c51bc:     	ldrb	w8, [x19, x8]
1000c51c0:     	ldrb	w3, [x20, x3]
1000c51c4:     	ldr	x27, [sp, #40]
1000c51c8:     	ldrb	w27, [x21, x27]
1000c51cc:     	add	w8, w8, w3
1000c51d0:     	ldr	x3, [sp, #32]
1000c51d4:     	ldrb	w3, [x23, x3]
1000c51d8:     	add	w8, w8, w27
1000c51dc:     	ldrb	w27, [x22, x10]
1000c51e0:     	add	w8, w8, w3
1000c51e4:     	ldrb	w3, [x24, x13]
1000c51e8:     	add	w8, w8, w27
1000c51ec:     	ldrb	w27, [x25, x9]
1000c51f0:     	add	w8, w8, w3
1000c51f4:     	ldrb	w3, [x26, x14]
1000c51f8:     	add	w8, w8, w27
1000c51fc:     	add	w8, w8, w3
1000c5200:     	scvtf	s6, w8
1000c5204:     	ldrb	w8, [x19, x15]
1000c5208:     	ldrb	w3, [x20, x16]
1000c520c:     	ldrb	w19, [x21, x17]
1000c5210:     	add	w8, w8, w3
1000c5214:     	add	w8, w8, w19
1000c5218:     	ldrb	w3, [x23, x2]
1000c521c:     	ldrb	w19, [x22, x4]
1000c5220:     	add	w8, w8, w3
1000c5224:     	add	w8, w8, w19
1000c5228:     	ldrb	w3, [x24, x5]
1000c522c:     	ldrb	w19, [x25, x6]
1000c5230:     	add	w8, w8, w3
1000c5234:     	add	w8, w8, w19
1000c5238:     	mov	x19, x1
1000c523c:     	ldrb	w3, [x26, x7]
1000c5240:     	add	w8, w8, w3
1000c5244:     	add	x3, sp, #448
1000c5248:     	scvtf	s7, w8
1000c524c:     	add	x8, x1, x12
1000c5250:     	ldur	s16, [x8, #-96]
1000c5254:     	fadd	s1, s16, s1
1000c5258:     	stur	s1, [x8, #-96]
1000c525c:     	ldur	s1, [x8, #-64]
1000c5260:     	fadd	s1, s1, s2
1000c5264:     	stur	s1, [x8, #-64]
1000c5268:     	ldur	s1, [x8, #-32]
1000c526c:     	fadd	s1, s1, s3
1000c5270:     	stur	s1, [x8, #-32]
1000c5274:     	ldr	s1, [x8]
1000c5278:     	fadd	s1, s1, s4
1000c527c:     	str	s1, [x8]
1000c5280:     	ldr	s1, [x8, #32]
1000c5284:     	fadd	s1, s1, s5
1000c5288:     	str	s1, [x8, #32]
1000c528c:     	ldr	s1, [x8, #64]
1000c5290:     	fadd	s1, s1, s6
1000c5294:     	str	s1, [x8, #64]
1000c5298:     	ldr	s1, [x8, #96]
1000c529c:     	fadd	s1, s1, s7
1000c52a0:     	ldr	s2, [x3, x12]
1000c52a4:     	str	s1, [x8, #96]
1000c52a8:     	fadd	s0, s2, s0
1000c52ac:     	str	s0, [x3, x12]
1000c52b0:     	add	x12, x12, #4
1000c52b4:     	cmp	x12, #32
1000c52b8:     	b.ne	0x1000c4f44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c52bc:     	add	x0, x0, #32
1000c52c0:     	ldp	x8, x1, [sp, #16]
1000c52c4:     	add	x1, x1, #32
1000c52c8:     	cmp	x1, x8
1000c52cc:     	b.ne	0x1000c4da0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c52d0:     	ldp	q0, q1, [sp, #640]
1000c52d4:     	ldr	x8, [sp, #8]
1000c52d8:     	stp	q0, q1, [x8, #192]
1000c52dc:     	ldp	q0, q1, [sp, #672]
1000c52e0:     	stp	q0, q1, [x8, #224]
1000c52e4:     	ldp	q0, q1, [sp, #576]
1000c52e8:     	stp	q0, q1, [x8, #128]
1000c52ec:     	ldp	q0, q1, [sp, #608]
1000c52f0:     	stp	q0, q1, [x8, #160]
1000c52f4:     	ldp	q0, q1, [sp, #512]
1000c52f8:     	stp	q0, q1, [x8, #64]
1000c52fc:     	ldp	q0, q1, [sp, #544]
1000c5300:     	stp	q0, q1, [x8, #96]
1000c5304:     	ldp	q0, q1, [sp, #448]
1000c5308:     	stp	q0, q1, [x8]
1000c530c:     	ldp	q0, q1, [sp, #480]
1000c5310:     	stp	q0, q1, [x8, #32]
1000c5314:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c5318:     	ldr	x8, [x8, #392]
1000c531c:     	ldr	x8, [x8]
1000c5320:     	ldur	x9, [x29, #-96]
1000c5324:     	cmp	x8, x9
1000c5328:     	b.ne	0x1000c534c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c532c:     	add	sp, sp, #720
1000c5330:     	ldp	x29, x30, [sp, #80]
1000c5334:     	ldp	x20, x19, [sp, #64]
1000c5338:     	ldp	x22, x21, [sp, #48]
1000c533c:     	ldp	x24, x23, [sp, #32]
1000c5340:     	ldp	x26, x25, [sp, #16]
1000c5344:     	ldp	x28, x27, [sp], #96
1000c5348:     	ret
1000c534c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c54e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c54e0:     	stp	x28, x27, [sp, #-96]!
1000c54e4:     	stp	x26, x25, [sp, #16]
1000c54e8:     	stp	x24, x23, [sp, #32]
1000c54ec:     	stp	x22, x21, [sp, #48]
1000c54f0:     	stp	x20, x19, [sp, #64]
1000c54f4:     	stp	x29, x30, [sp, #80]
1000c54f8:     	add	x29, sp, #80
1000c54fc:     	sub	sp, sp, #720
1000c5500:     	str	x3, [sp, #8]
1000c5504:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c5508:     	ldr	x8, [x8, #392]
1000c550c:     	ldr	x8, [x8]
1000c5510:     	stur	x8, [x29, #-96]
1000c5514:     	movi.2d	v0, #0000000000000000
1000c5518:     	stp	q0, q0, [sp, #672]
1000c551c:     	lsl	x8, x2, #2
1000c5520:     	stp	q0, q0, [sp, #640]
1000c5524:     	stp	q0, q0, [sp, #608]
1000c5528:     	stp	q0, q0, [sp, #576]
1000c552c:     	stp	q0, q0, [sp, #544]
1000c5530:     	stp	q0, q0, [sp, #512]
1000c5534:     	stp	q0, q0, [sp, #480]
1000c5538:     	stp	q0, q0, [sp, #448]
1000c553c:     	ands	x8, x8, #0xfffffffffffffff8
1000c5540:     	b.eq	0x1000c5a8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c5544:     	add	x8, x1, x8
1000c5548:     	str	x8, [sp, #16]
1000c554c:     	add	x8, sp, #448
1000c5550:     	add	x19, x8, #128
1000c5554:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000c5558:     	add	x11, x11, #956
1000c555c:     	mov	x12, #0
1000c5560:     	ldp	w8, w9, [x1]
1000c5564:     	ubfx	x10, x8, #8, #4
1000c5568:     	str	x10, [sp, #440]
1000c556c:     	ubfx	x10, x8, #16, #4
1000c5570:     	str	x10, [sp, #432]
1000c5574:     	ubfx	x10, x8, #24, #4
1000c5578:     	str	x10, [sp, #424]
1000c557c:     	ldp	w10, w13, [x1, #8]
1000c5580:     	and	x15, x8, #0xf
1000c5584:     	ubfx	x14, x8, #4, #4
1000c5588:     	stp	x14, x15, [sp, #408]
1000c558c:     	ubfx	x15, x8, #12, #4
1000c5590:     	ubfx	x14, x8, #20, #4
1000c5594:     	stp	x14, x15, [sp, #392]
1000c5598:     	lsr	x8, x8, #28
1000c559c:     	str	x8, [sp, #384]
1000c55a0:     	and	x8, x9, #0xf
1000c55a4:     	str	x8, [sp, #376]
1000c55a8:     	ubfx	x8, x9, #8, #4
1000c55ac:     	str	x8, [sp, #368]
1000c55b0:     	ubfx	x8, x9, #16, #4
1000c55b4:     	str	x8, [sp, #360]
1000c55b8:     	ubfx	x8, x9, #24, #4
1000c55bc:     	str	x8, [sp, #352]
1000c55c0:     	ubfx	x8, x9, #4, #4
1000c55c4:     	str	x8, [sp, #344]
1000c55c8:     	ubfx	x8, x9, #12, #4
1000c55cc:     	str	x8, [sp, #336]
1000c55d0:     	ubfx	x8, x9, #20, #4
1000c55d4:     	str	x8, [sp, #328]
1000c55d8:     	lsr	x8, x9, #28
1000c55dc:     	str	x8, [sp, #320]
1000c55e0:     	and	x9, x10, #0xf
1000c55e4:     	ubfx	x8, x10, #8, #4
1000c55e8:     	stp	x8, x9, [sp, #304]
1000c55ec:     	ubfx	x9, x10, #16, #4
1000c55f0:     	ubfx	x8, x10, #24, #4
1000c55f4:     	stp	x8, x9, [sp, #288]
1000c55f8:     	ubfx	x9, x10, #4, #4
1000c55fc:     	ubfx	x8, x10, #12, #4
1000c5600:     	stp	x8, x9, [sp, #272]
1000c5604:     	ubfx	x9, x10, #20, #4
1000c5608:     	lsr	x8, x10, #28
1000c560c:     	stp	x8, x9, [sp, #256]
1000c5610:     	and	x9, x13, #0xf
1000c5614:     	ubfx	x8, x13, #8, #4
1000c5618:     	stp	x8, x9, [sp, #240]
1000c561c:     	ubfx	x9, x13, #16, #4
1000c5620:     	ubfx	x8, x13, #24, #4
1000c5624:     	stp	x8, x9, [sp, #224]
1000c5628:     	ubfx	x9, x13, #4, #4
1000c562c:     	ubfx	x8, x13, #12, #4
1000c5630:     	stp	x8, x9, [sp, #208]
1000c5634:     	ubfx	x9, x13, #20, #4
1000c5638:     	lsr	x8, x13, #28
1000c563c:     	stp	x8, x9, [sp, #192]
1000c5640:     	ldp	w8, w9, [x1, #16]
1000c5644:     	and	x10, x8, #0xf
1000c5648:     	str	x10, [sp, #184]
1000c564c:     	ubfx	x10, x8, #8, #4
1000c5650:     	str	x10, [sp, #176]
1000c5654:     	ubfx	x10, x8, #16, #4
1000c5658:     	str	x10, [sp, #168]
1000c565c:     	ubfx	x10, x8, #24, #4
1000c5660:     	str	x10, [sp, #160]
1000c5664:     	ubfx	x10, x8, #4, #4
1000c5668:     	str	x10, [sp, #152]
1000c566c:     	ubfx	x10, x8, #12, #4
1000c5670:     	str	x10, [sp, #144]
1000c5674:     	ubfx	x10, x8, #20, #4
1000c5678:     	lsr	x8, x8, #28
1000c567c:     	stp	x8, x10, [sp, #128]
1000c5680:     	and	x10, x9, #0xf
1000c5684:     	ubfx	x8, x9, #8, #4
1000c5688:     	stp	x8, x10, [sp, #112]
1000c568c:     	ubfx	x10, x9, #16, #4
1000c5690:     	ubfx	x8, x9, #24, #4
1000c5694:     	stp	x8, x10, [sp, #96]
1000c5698:     	ubfx	x10, x9, #4, #4
1000c569c:     	ubfx	x8, x9, #12, #4
1000c56a0:     	stp	x8, x10, [sp, #80]
1000c56a4:     	ubfx	x10, x9, #20, #4
1000c56a8:     	lsr	x8, x9, #28
1000c56ac:     	stp	x8, x10, [sp, #64]
1000c56b0:     	ldp	w14, w7, [x1, #24]
1000c56b4:     	and	x9, x14, #0xf
1000c56b8:     	ubfx	x8, x14, #8, #4
1000c56bc:     	stp	x8, x9, [sp, #48]
1000c56c0:     	ubfx	x8, x14, #16, #4
1000c56c4:     	str	x8, [sp, #40]
1000c56c8:     	ubfx	x8, x14, #24, #4
1000c56cc:     	stp	x1, x8, [sp, #24]
1000c56d0:     	ubfx	x10, x14, #4, #4
1000c56d4:     	ubfx	x13, x14, #12, #4
1000c56d8:     	ubfx	x9, x14, #20, #4
1000c56dc:     	lsr	x14, x14, #28
1000c56e0:     	and	x15, x7, #0xf
1000c56e4:     	ubfx	x16, x7, #8, #4
1000c56e8:     	ubfx	x17, x7, #16, #4
1000c56ec:     	ubfx	x2, x7, #24, #4
1000c56f0:     	ubfx	x4, x7, #4, #4
1000c56f4:     	ubfx	x5, x7, #12, #4
1000c56f8:     	ubfx	x6, x7, #20, #4
1000c56fc:     	lsr	x7, x7, #28
1000c5700:     	ldr	w26, [x0, x12]
1000c5704:     	mov	x1, x19
1000c5708:     	lsl	w19, w26, #4
1000c570c:     	and	x19, x19, #0xf0
1000c5710:     	add	x19, x11, x19
1000c5714:     	ldr	x8, [sp, #416]
1000c5718:     	ldrsb	w25, [x19, x8]
1000c571c:     	lsr	x20, x26, #4
1000c5720:     	and	x20, x20, #0xf0
1000c5724:     	add	x20, x11, x20
1000c5728:     	ldr	x8, [sp, #440]
1000c572c:     	ldrsb	w27, [x20, x8]
1000c5730:     	lsr	x21, x26, #12
1000c5734:     	and	x21, x21, #0xf0
1000c5738:     	add	x21, x11, x21
1000c573c:     	ldr	x8, [sp, #432]
1000c5740:     	ldrsb	w28, [x21, x8]
1000c5744:     	lsr	x22, x26, #20
1000c5748:     	and	x22, x22, #0xf0
1000c574c:     	add	x23, x11, x22
1000c5750:     	ldr	x8, [sp, #424]
1000c5754:     	ldrsb	w30, [x23, x8]
1000c5758:     	and	x22, x26, #0xf0
1000c575c:     	add	x22, x11, x22
1000c5760:     	ldp	x3, x8, [sp, #400]
1000c5764:     	ldrsb	w8, [x22, x8]
1000c5768:     	lsr	x24, x26, #8
1000c576c:     	and	x24, x24, #0xf0
1000c5770:     	add	x24, x11, x24
1000c5774:     	ldrsb	w3, [x24, x3]
1000c5778:     	add	w27, w25, w27
1000c577c:     	lsr	x25, x26, #16
1000c5780:     	and	x25, x25, #0xf0
1000c5784:     	add	x25, x11, x25
1000c5788:     	add	w27, w27, w28
1000c578c:     	ldr	x28, [sp, #392]
1000c5790:     	ldrsb	w28, [x25, x28]
1000c5794:     	lsr	x26, x26, #24
1000c5798:     	and	x26, x26, #0xf0
1000c579c:     	add	x26, x11, x26
1000c57a0:     	add	w27, w27, w30
1000c57a4:     	ldr	x30, [sp, #384]
1000c57a8:     	ldrsb	w30, [x26, x30]
1000c57ac:     	add	w8, w27, w8
1000c57b0:     	add	w8, w8, w3
1000c57b4:     	add	w8, w8, w28
1000c57b8:     	add	w8, w8, w30
1000c57bc:     	scvtf	s0, w8
1000c57c0:     	ldp	x3, x8, [sp, #368]
1000c57c4:     	ldrsb	w8, [x19, x8]
1000c57c8:     	ldrsb	w3, [x20, x3]
1000c57cc:     	ldp	x28, x27, [sp, #352]
1000c57d0:     	ldrsb	w27, [x21, x27]
1000c57d4:     	ldrsb	w28, [x23, x28]
1000c57d8:     	ldr	x30, [sp, #344]
1000c57dc:     	ldrsb	w30, [x22, x30]
1000c57e0:     	add	w8, w8, w3
1000c57e4:     	ldr	x3, [sp, #336]
1000c57e8:     	ldrsb	w3, [x24, x3]
1000c57ec:     	add	w8, w8, w27
1000c57f0:     	ldr	x27, [sp, #328]
1000c57f4:     	ldrsb	w27, [x25, x27]
1000c57f8:     	add	w8, w8, w28
1000c57fc:     	ldr	x28, [sp, #320]
1000c5800:     	ldrsb	w28, [x26, x28]
1000c5804:     	add	w8, w8, w30
1000c5808:     	add	w8, w8, w3
1000c580c:     	add	w8, w8, w27
1000c5810:     	add	w8, w8, w28
1000c5814:     	scvtf	s1, w8
1000c5818:     	ldp	x3, x8, [sp, #304]
1000c581c:     	ldrsb	w8, [x19, x8]
1000c5820:     	ldrsb	w3, [x20, x3]
1000c5824:     	ldp	x28, x27, [sp, #288]
1000c5828:     	ldrsb	w27, [x21, x27]
1000c582c:     	ldrsb	w28, [x23, x28]
1000c5830:     	add	w8, w8, w3
1000c5834:     	ldr	x3, [sp, #280]
1000c5838:     	ldrsb	w3, [x22, x3]
1000c583c:     	add	w8, w8, w27
1000c5840:     	ldr	x27, [sp, #272]
1000c5844:     	ldrsb	w27, [x24, x27]
1000c5848:     	add	w8, w8, w28
1000c584c:     	ldr	x28, [sp, #264]
1000c5850:     	ldrsb	w28, [x25, x28]
1000c5854:     	add	w8, w8, w3
1000c5858:     	ldr	x3, [sp, #256]
1000c585c:     	ldrsb	w3, [x26, x3]
1000c5860:     	add	w8, w8, w27
1000c5864:     	add	w8, w8, w28
1000c5868:     	add	w8, w8, w3
1000c586c:     	scvtf	s2, w8
1000c5870:     	ldp	x3, x8, [sp, #240]
1000c5874:     	ldrsb	w8, [x19, x8]
1000c5878:     	ldrsb	w3, [x20, x3]
1000c587c:     	ldp	x28, x27, [sp, #224]
1000c5880:     	ldrsb	w27, [x21, x27]
1000c5884:     	ldrsb	w28, [x23, x28]
1000c5888:     	add	w8, w8, w3
1000c588c:     	ldr	x3, [sp, #216]
1000c5890:     	ldrsb	w3, [x22, x3]
1000c5894:     	add	w8, w8, w27
1000c5898:     	ldr	x27, [sp, #208]
1000c589c:     	ldrsb	w27, [x24, x27]
1000c58a0:     	add	w8, w8, w28
1000c58a4:     	ldr	x28, [sp, #200]
1000c58a8:     	ldrsb	w28, [x25, x28]
1000c58ac:     	add	w8, w8, w3
1000c58b0:     	ldr	x3, [sp, #192]
1000c58b4:     	ldrsb	w3, [x26, x3]
1000c58b8:     	add	w8, w8, w27
1000c58bc:     	add	w8, w8, w28
1000c58c0:     	add	w8, w8, w3
1000c58c4:     	scvtf	s3, w8
1000c58c8:     	ldp	x3, x8, [sp, #176]
1000c58cc:     	ldrsb	w8, [x19, x8]
1000c58d0:     	ldrsb	w3, [x20, x3]
1000c58d4:     	ldp	x28, x27, [sp, #160]
1000c58d8:     	ldrsb	w27, [x21, x27]
1000c58dc:     	ldrsb	w28, [x23, x28]
1000c58e0:     	add	w8, w8, w3
1000c58e4:     	add	w8, w8, w27
1000c58e8:     	ldr	x3, [sp, #152]
1000c58ec:     	ldrsb	w3, [x22, x3]
1000c58f0:     	add	w8, w8, w28
1000c58f4:     	add	w8, w8, w3
1000c58f8:     	ldp	x27, x3, [sp, #136]
1000c58fc:     	ldrsb	w3, [x24, x3]
1000c5900:     	ldrsb	w27, [x25, x27]
1000c5904:     	add	w8, w8, w3
1000c5908:     	add	w8, w8, w27
1000c590c:     	ldr	x3, [sp, #128]
1000c5910:     	ldrsb	w3, [x26, x3]
1000c5914:     	add	w8, w8, w3
1000c5918:     	scvtf	s4, w8
1000c591c:     	ldp	x3, x8, [sp, #112]
1000c5920:     	ldrsb	w8, [x19, x8]
1000c5924:     	ldrsb	w3, [x20, x3]
1000c5928:     	ldp	x28, x27, [sp, #96]
1000c592c:     	ldrsb	w27, [x21, x27]
1000c5930:     	ldrsb	w28, [x23, x28]
1000c5934:     	add	w8, w8, w3
1000c5938:     	ldr	x3, [sp, #88]
1000c593c:     	ldrsb	w3, [x22, x3]
1000c5940:     	add	w8, w8, w27
1000c5944:     	ldr	x27, [sp, #80]
1000c5948:     	ldrsb	w27, [x24, x27]
1000c594c:     	add	w8, w8, w28
1000c5950:     	ldr	x28, [sp, #72]
1000c5954:     	ldrsb	w28, [x25, x28]
1000c5958:     	add	w8, w8, w3
1000c595c:     	add	w8, w8, w27
1000c5960:     	add	w8, w8, w28
1000c5964:     	ldr	x3, [sp, #64]
1000c5968:     	ldrsb	w3, [x26, x3]
1000c596c:     	add	w8, w8, w3
1000c5970:     	scvtf	s5, w8
1000c5974:     	ldp	x3, x8, [sp, #48]
1000c5978:     	ldrsb	w8, [x19, x8]
1000c597c:     	ldrsb	w3, [x20, x3]
1000c5980:     	ldr	x27, [sp, #40]
1000c5984:     	ldrsb	w27, [x21, x27]
1000c5988:     	add	w8, w8, w3
1000c598c:     	ldr	x3, [sp, #32]
1000c5990:     	ldrsb	w3, [x23, x3]
1000c5994:     	add	w8, w8, w27
1000c5998:     	ldrsb	w27, [x22, x10]
1000c599c:     	add	w8, w8, w3
1000c59a0:     	ldrsb	w3, [x24, x13]
1000c59a4:     	add	w8, w8, w27
1000c59a8:     	ldrsb	w27, [x25, x9]
1000c59ac:     	add	w8, w8, w3
1000c59b0:     	ldrsb	w3, [x26, x14]
1000c59b4:     	add	w8, w8, w27
1000c59b8:     	add	w8, w8, w3
1000c59bc:     	scvtf	s6, w8
1000c59c0:     	ldrsb	w8, [x19, x15]
1000c59c4:     	ldrsb	w3, [x20, x16]
1000c59c8:     	ldrsb	w19, [x21, x17]
1000c59cc:     	add	w8, w8, w3
1000c59d0:     	add	w8, w8, w19
1000c59d4:     	ldrsb	w3, [x23, x2]
1000c59d8:     	ldrsb	w19, [x22, x4]
1000c59dc:     	add	w8, w8, w3
1000c59e0:     	add	w8, w8, w19
1000c59e4:     	ldrsb	w3, [x24, x5]
1000c59e8:     	ldrsb	w19, [x25, x6]
1000c59ec:     	add	w8, w8, w3
1000c59f0:     	add	w8, w8, w19
1000c59f4:     	mov	x19, x1
1000c59f8:     	ldrsb	w3, [x26, x7]
1000c59fc:     	add	w8, w8, w3
1000c5a00:     	add	x3, sp, #448
1000c5a04:     	scvtf	s7, w8
1000c5a08:     	add	x8, x1, x12
1000c5a0c:     	ldur	s16, [x8, #-96]
1000c5a10:     	fadd	s1, s16, s1
1000c5a14:     	stur	s1, [x8, #-96]
1000c5a18:     	ldur	s1, [x8, #-64]
1000c5a1c:     	fadd	s1, s1, s2
1000c5a20:     	stur	s1, [x8, #-64]
1000c5a24:     	ldur	s1, [x8, #-32]
1000c5a28:     	fadd	s1, s1, s3
1000c5a2c:     	stur	s1, [x8, #-32]
1000c5a30:     	ldr	s1, [x8]
1000c5a34:     	fadd	s1, s1, s4
1000c5a38:     	str	s1, [x8]
1000c5a3c:     	ldr	s1, [x8, #32]
1000c5a40:     	fadd	s1, s1, s5
1000c5a44:     	str	s1, [x8, #32]
1000c5a48:     	ldr	s1, [x8, #64]
1000c5a4c:     	fadd	s1, s1, s6
1000c5a50:     	str	s1, [x8, #64]
1000c5a54:     	ldr	s1, [x8, #96]
1000c5a58:     	fadd	s1, s1, s7
1000c5a5c:     	ldr	s2, [x3, x12]
1000c5a60:     	str	s1, [x8, #96]
1000c5a64:     	fadd	s0, s2, s0
1000c5a68:     	str	s0, [x3, x12]
1000c5a6c:     	add	x12, x12, #4
1000c5a70:     	cmp	x12, #32
1000c5a74:     	b.ne	0x1000c5700 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c5a78:     	add	x0, x0, #32
1000c5a7c:     	ldp	x8, x1, [sp, #16]
1000c5a80:     	add	x1, x1, #32
1000c5a84:     	cmp	x1, x8
1000c5a88:     	b.ne	0x1000c555c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c5a8c:     	ldp	q0, q1, [sp, #640]
1000c5a90:     	ldr	x8, [sp, #8]
1000c5a94:     	stp	q0, q1, [x8, #192]
1000c5a98:     	ldp	q0, q1, [sp, #672]
1000c5a9c:     	stp	q0, q1, [x8, #224]
1000c5aa0:     	ldp	q0, q1, [sp, #576]
1000c5aa4:     	stp	q0, q1, [x8, #128]
1000c5aa8:     	ldp	q0, q1, [sp, #608]
1000c5aac:     	stp	q0, q1, [x8, #160]
1000c5ab0:     	ldp	q0, q1, [sp, #512]
1000c5ab4:     	stp	q0, q1, [x8, #64]
1000c5ab8:     	ldp	q0, q1, [sp, #544]
1000c5abc:     	stp	q0, q1, [x8, #96]
1000c5ac0:     	ldp	q0, q1, [sp, #448]
1000c5ac4:     	stp	q0, q1, [x8]
1000c5ac8:     	ldp	q0, q1, [sp, #480]
1000c5acc:     	stp	q0, q1, [x8, #32]
1000c5ad0:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x260>
1000c5ad4:     	ldr	x8, [x8, #392]
1000c5ad8:     	ldr	x8, [x8]
1000c5adc:     	ldur	x9, [x29, #-96]
1000c5ae0:     	cmp	x8, x9
1000c5ae4:     	b.ne	0x1000c5b08 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c5ae8:     	add	sp, sp, #720
1000c5aec:     	ldp	x29, x30, [sp, #80]
1000c5af0:     	ldp	x20, x19, [sp, #64]
1000c5af4:     	ldp	x22, x21, [sp, #48]
1000c5af8:     	ldp	x24, x23, [sp, #32]
1000c5afc:     	ldp	x26, x25, [sp, #16]
1000c5b00:     	ldp	x28, x27, [sp], #96
1000c5b04:     	ret
1000c5b08:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c6a44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c6a44:     	stp	x22, x21, [sp, #-32]!
1000c6a48:     	stp	x20, x19, [sp, #16]
1000c6a4c:     	movi.2d	v0, #0000000000000000
1000c6a50:     	stp	q0, q0, [x3, #32]
1000c6a54:     	stp	q0, q0, [x3]
1000c6a58:     	cmp	x2, #8
1000c6a5c:     	b.hs	0x1000c6a68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c6a60:     	mov	x8, #0
1000c6a64:     	b	0x1000c6b78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c6a68:     	mov	x8, #0
1000c6a6c:     	mov	w12, #8
1000c6a70:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2bc>
1000c6a74:     	add	x9, x9, #1212
1000c6a78:     	mov	x10, x0
1000c6a7c:     	mov	x11, #0
1000c6a80:     	lsr	x8, x8, #1
1000c6a84:     	mul	x8, x8, x4
1000c6a88:     	ldr	w6, [x1, x8]
1000c6a8c:     	mov	x8, x12
1000c6a90:     	lsl	w12, w6, #4
1000c6a94:     	and	x12, x12, #0xf0
1000c6a98:     	add	x12, x9, x12
1000c6a9c:     	and	x13, x6, #0xf0
1000c6aa0:     	add	x13, x9, x13
1000c6aa4:     	lsr	x14, x6, #4
1000c6aa8:     	and	x14, x14, #0xf0
1000c6aac:     	add	x14, x9, x14
1000c6ab0:     	lsr	x15, x6, #8
1000c6ab4:     	and	x15, x15, #0xf0
1000c6ab8:     	add	x15, x9, x15
1000c6abc:     	lsr	x16, x6, #12
1000c6ac0:     	and	x16, x16, #0xf0
1000c6ac4:     	add	x16, x9, x16
1000c6ac8:     	lsr	x17, x6, #16
1000c6acc:     	and	x17, x17, #0xf0
1000c6ad0:     	add	x17, x9, x17
1000c6ad4:     	lsr	x5, x6, #20
1000c6ad8:     	and	x5, x5, #0xf0
1000c6adc:     	add	x5, x9, x5
1000c6ae0:     	lsr	x6, x6, #24
1000c6ae4:     	and	x6, x6, #0xf0
1000c6ae8:     	add	x6, x9, x6
1000c6aec:     	ldr	w7, [x10, x11]
1000c6af0:     	and	x19, x7, #0xf
1000c6af4:     	ldrb	w19, [x12, x19]
1000c6af8:     	ubfx	x20, x7, #4, #4
1000c6afc:     	ldrb	w20, [x13, x20]
1000c6b00:     	ubfx	x21, x7, #8, #4
1000c6b04:     	ldrb	w21, [x14, x21]
1000c6b08:     	add	w19, w19, w20
1000c6b0c:     	add	w19, w19, w21
1000c6b10:     	ubfx	x20, x7, #12, #4
1000c6b14:     	ldrb	w20, [x15, x20]
1000c6b18:     	ubfx	x21, x7, #16, #4
1000c6b1c:     	ldrb	w21, [x16, x21]
1000c6b20:     	add	w19, w19, w20
1000c6b24:     	add	w19, w19, w21
1000c6b28:     	ubfx	x20, x7, #20, #4
1000c6b2c:     	ldrb	w20, [x17, x20]
1000c6b30:     	ubfx	x21, x7, #24, #4
1000c6b34:     	ldrb	w21, [x5, x21]
1000c6b38:     	lsr	x7, x7, #28
1000c6b3c:     	ldrb	w7, [x6, x7]
1000c6b40:     	add	w19, w19, w20
1000c6b44:     	add	w19, w19, w21
1000c6b48:     	add	w7, w19, w7
1000c6b4c:     	scvtf	s0, w7
1000c6b50:     	ldr	s1, [x3, x11]
1000c6b54:     	fadd	s0, s1, s0
1000c6b58:     	str	s0, [x3, x11]
1000c6b5c:     	add	x11, x11, #4
1000c6b60:     	cmp	x11, #64
1000c6b64:     	b.ne	0x1000c6aec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c6b68:     	add	x12, x8, #8
1000c6b6c:     	add	x10, x10, #64
1000c6b70:     	cmp	x12, x2
1000c6b74:     	b.ls	0x1000c6a7c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c6b78:     	cmp	x8, x2
1000c6b7c:     	b.hs	0x1000c6e74 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x430>
1000c6b80:     	lsl	x9, x4, #2
1000c6b84:     	lsl	w10, w8, #2
1000c6b88:     	mov	w11, #-16
1000c6b8c:     	lsr	x13, x8, #3
1000c6b90:     	mul	x12, x9, x13
1000c6b94:     	ubfx	x14, x8, #1, #2
1000c6b98:     	orr	x15, x12, x14
1000c6b9c:     	and	w12, w10, #0x4
1000c6ba0:     	ldrb	w15, [x1, x15]
1000c6ba4:     	lsr	w15, w15, w12
1000c6ba8:     	and	w16, w15, #0xf
1000c6bac:     	cmp	w16, #8
1000c6bb0:     	csel	w16, wzr, w11, lo
1000c6bb4:     	bfi	x14, x13, #6, #58
1000c6bb8:     	bfxil	w16, w15, #0, #4
1000c6bbc:     	add	x13, x0, x14
1000c6bc0:     	ldrb	w14, [x13]
1000c6bc4:     	lsr	w14, w14, w12
1000c6bc8:     	and	w15, w14, #0xf
1000c6bcc:     	scvtf	s0, w16
1000c6bd0:     	cmp	w15, #8
1000c6bd4:     	csel	w15, wzr, w11, lo
1000c6bd8:     	bfxil	w15, w14, #0, #4
1000c6bdc:     	scvtf	s1, w15
1000c6be0:     	fsub	s1, s1, s0
1000c6be4:     	ldp	s2, s3, [x3]
1000c6be8:     	fmadd	s1, s1, s1, s2
1000c6bec:     	str	s1, [x3]
1000c6bf0:     	ldrb	w14, [x13, #4]
1000c6bf4:     	lsr	w14, w14, w12
1000c6bf8:     	and	w15, w14, #0xf
1000c6bfc:     	cmp	w15, #8
1000c6c00:     	csel	w15, wzr, w11, lo
1000c6c04:     	bfxil	w15, w14, #0, #4
1000c6c08:     	scvtf	s1, w15
1000c6c0c:     	fsub	s1, s1, s0
1000c6c10:     	fmadd	s1, s1, s1, s3
1000c6c14:     	str	s1, [x3, #4]
1000c6c18:     	ldrb	w14, [x13, #8]
1000c6c1c:     	lsr	w14, w14, w12
1000c6c20:     	and	w15, w14, #0xf
1000c6c24:     	cmp	w15, #8
1000c6c28:     	csel	w15, wzr, w11, lo
1000c6c2c:     	bfxil	w15, w14, #0, #4
1000c6c30:     	scvtf	s1, w15
1000c6c34:     	fsub	s1, s1, s0
1000c6c38:     	ldp	s2, s3, [x3, #8]
1000c6c3c:     	fmadd	s1, s1, s1, s2
1000c6c40:     	str	s1, [x3, #8]
1000c6c44:     	ldrb	w14, [x13, #12]
1000c6c48:     	lsr	w14, w14, w12
1000c6c4c:     	and	w15, w14, #0xf
1000c6c50:     	cmp	w15, #8
1000c6c54:     	csel	w15, wzr, w11, lo
1000c6c58:     	bfxil	w15, w14, #0, #4
1000c6c5c:     	scvtf	s1, w15
1000c6c60:     	fsub	s1, s1, s0
1000c6c64:     	fmadd	s1, s1, s1, s3
1000c6c68:     	str	s1, [x3, #12]
1000c6c6c:     	ldrb	w14, [x13, #16]
1000c6c70:     	lsr	w14, w14, w12
1000c6c74:     	and	w15, w14, #0xf
1000c6c78:     	cmp	w15, #8
1000c6c7c:     	csel	w15, wzr, w11, lo
1000c6c80:     	bfxil	w15, w14, #0, #4
1000c6c84:     	scvtf	s1, w15
1000c6c88:     	fsub	s1, s1, s0
1000c6c8c:     	ldp	s2, s3, [x3, #16]
1000c6c90:     	fmadd	s1, s1, s1, s2
1000c6c94:     	str	s1, [x3, #16]
1000c6c98:     	ldrb	w14, [x13, #20]
1000c6c9c:     	lsr	w14, w14, w12
1000c6ca0:     	and	w15, w14, #0xf
1000c6ca4:     	cmp	w15, #8
1000c6ca8:     	csel	w15, wzr, w11, lo
1000c6cac:     	bfxil	w15, w14, #0, #4
1000c6cb0:     	scvtf	s1, w15
1000c6cb4:     	fsub	s1, s1, s0
1000c6cb8:     	fmadd	s1, s1, s1, s3
1000c6cbc:     	str	s1, [x3, #20]
1000c6cc0:     	ldrb	w14, [x13, #24]
1000c6cc4:     	lsr	w14, w14, w12
1000c6cc8:     	and	w15, w14, #0xf
1000c6ccc:     	cmp	w15, #8
1000c6cd0:     	csel	w15, wzr, w11, lo
1000c6cd4:     	bfxil	w15, w14, #0, #4
1000c6cd8:     	scvtf	s1, w15
1000c6cdc:     	fsub	s1, s1, s0
1000c6ce0:     	ldp	s2, s3, [x3, #24]
1000c6ce4:     	fmadd	s1, s1, s1, s2
1000c6ce8:     	str	s1, [x3, #24]
1000c6cec:     	ldrb	w14, [x13, #28]
1000c6cf0:     	lsr	w14, w14, w12
1000c6cf4:     	and	w15, w14, #0xf
1000c6cf8:     	cmp	w15, #8
1000c6cfc:     	csel	w15, wzr, w11, lo
1000c6d00:     	bfxil	w15, w14, #0, #4
1000c6d04:     	scvtf	s1, w15
1000c6d08:     	fsub	s1, s1, s0
1000c6d0c:     	fmadd	s1, s1, s1, s3
1000c6d10:     	str	s1, [x3, #28]
1000c6d14:     	ldrb	w14, [x13, #32]
1000c6d18:     	lsr	w14, w14, w12
1000c6d1c:     	and	w15, w14, #0xf
1000c6d20:     	cmp	w15, #8
1000c6d24:     	csel	w15, wzr, w11, lo
1000c6d28:     	bfxil	w15, w14, #0, #4
1000c6d2c:     	scvtf	s1, w15
1000c6d30:     	fsub	s1, s1, s0
1000c6d34:     	ldp	s2, s3, [x3, #32]
1000c6d38:     	fmadd	s1, s1, s1, s2
1000c6d3c:     	str	s1, [x3, #32]
1000c6d40:     	ldrb	w14, [x13, #36]
1000c6d44:     	lsr	w14, w14, w12
1000c6d48:     	and	w15, w14, #0xf
1000c6d4c:     	cmp	w15, #8
1000c6d50:     	csel	w15, wzr, w11, lo
1000c6d54:     	bfxil	w15, w14, #0, #4
1000c6d58:     	scvtf	s1, w15
1000c6d5c:     	fsub	s1, s1, s0
1000c6d60:     	fmadd	s1, s1, s1, s3
1000c6d64:     	str	s1, [x3, #36]
1000c6d68:     	ldrb	w14, [x13, #40]
1000c6d6c:     	lsr	w14, w14, w12
1000c6d70:     	and	w15, w14, #0xf
1000c6d74:     	cmp	w15, #8
1000c6d78:     	csel	w15, wzr, w11, lo
1000c6d7c:     	bfxil	w15, w14, #0, #4
1000c6d80:     	scvtf	s1, w15
1000c6d84:     	fsub	s1, s1, s0
1000c6d88:     	ldp	s2, s3, [x3, #40]
1000c6d8c:     	fmadd	s1, s1, s1, s2
1000c6d90:     	str	s1, [x3, #40]
1000c6d94:     	ldrb	w14, [x13, #44]
1000c6d98:     	lsr	w14, w14, w12
1000c6d9c:     	and	w15, w14, #0xf
1000c6da0:     	cmp	w15, #8
1000c6da4:     	csel	w15, wzr, w11, lo
1000c6da8:     	bfxil	w15, w14, #0, #4
1000c6dac:     	scvtf	s1, w15
1000c6db0:     	fsub	s1, s1, s0
1000c6db4:     	fmadd	s1, s1, s1, s3
1000c6db8:     	str	s1, [x3, #44]
1000c6dbc:     	ldrb	w14, [x13, #48]
1000c6dc0:     	lsr	w14, w14, w12
1000c6dc4:     	and	w15, w14, #0xf
1000c6dc8:     	cmp	w15, #8
1000c6dcc:     	csel	w15, wzr, w11, lo
1000c6dd0:     	bfxil	w15, w14, #0, #4
1000c6dd4:     	scvtf	s1, w15
1000c6dd8:     	fsub	s1, s1, s0
1000c6ddc:     	ldp	s2, s3, [x3, #48]
1000c6de0:     	fmadd	s1, s1, s1, s2
1000c6de4:     	str	s1, [x3, #48]
1000c6de8:     	ldrb	w14, [x13, #52]
1000c6dec:     	lsr	w14, w14, w12
1000c6df0:     	and	w15, w14, #0xf
1000c6df4:     	cmp	w15, #8
1000c6df8:     	csel	w15, wzr, w11, lo
1000c6dfc:     	bfxil	w15, w14, #0, #4
1000c6e00:     	scvtf	s1, w15
1000c6e04:     	fsub	s1, s1, s0
1000c6e08:     	fmadd	s1, s1, s1, s3
1000c6e0c:     	str	s1, [x3, #52]
1000c6e10:     	ldrb	w14, [x13, #56]
1000c6e14:     	lsr	w14, w14, w12
1000c6e18:     	and	w15, w14, #0xf
1000c6e1c:     	cmp	w15, #8
1000c6e20:     	csel	w15, wzr, w11, lo
1000c6e24:     	bfxil	w15, w14, #0, #4
1000c6e28:     	scvtf	s1, w15
1000c6e2c:     	fsub	s1, s1, s0
1000c6e30:     	ldp	s2, s3, [x3, #56]
1000c6e34:     	fmadd	s1, s1, s1, s2
1000c6e38:     	str	s1, [x3, #56]
1000c6e3c:     	ldrb	w13, [x13, #60]
1000c6e40:     	lsr	w12, w13, w12
1000c6e44:     	and	w13, w12, #0xf
1000c6e48:     	cmp	w13, #8
1000c6e4c:     	csel	w13, wzr, w11, lo
1000c6e50:     	bfxil	w13, w12, #0, #4
1000c6e54:     	scvtf	s1, w13
1000c6e58:     	fsub	s0, s1, s0
1000c6e5c:     	fmadd	s0, s0, s0, s3
1000c6e60:     	str	s0, [x3, #60]
1000c6e64:     	add	x8, x8, #1
1000c6e68:     	add	w10, w10, #4
1000c6e6c:     	cmp	x2, x8
1000c6e70:     	b.ne	0x1000c6b8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c6e74:     	ldp	x20, x19, [sp, #16]
1000c6e78:     	ldp	x22, x21, [sp], #32
1000c6e7c:     	ret

00000001000c6ea4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c6ea4:     	stp	x22, x21, [sp, #-32]!
1000c6ea8:     	stp	x20, x19, [sp, #16]
1000c6eac:     	movi.2d	v0, #0000000000000000
1000c6eb0:     	stp	q0, q0, [x3, #32]
1000c6eb4:     	stp	q0, q0, [x3]
1000c6eb8:     	cmp	x2, #8
1000c6ebc:     	b.hs	0x1000c6ec8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c6ec0:     	mov	x8, #0
1000c6ec4:     	b	0x1000c6fd8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c6ec8:     	mov	x8, #0
1000c6ecc:     	mov	w12, #8
1000c6ed0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2bc>
1000c6ed4:     	add	x9, x9, #1468
1000c6ed8:     	mov	x10, x0
1000c6edc:     	mov	x11, #0
1000c6ee0:     	lsr	x8, x8, #1
1000c6ee4:     	mul	x8, x8, x4
1000c6ee8:     	ldr	w6, [x1, x8]
1000c6eec:     	mov	x8, x12
1000c6ef0:     	lsl	w12, w6, #4
1000c6ef4:     	and	x12, x12, #0xf0
1000c6ef8:     	add	x12, x9, x12
1000c6efc:     	and	x13, x6, #0xf0
1000c6f00:     	add	x13, x9, x13
1000c6f04:     	lsr	x14, x6, #4
1000c6f08:     	and	x14, x14, #0xf0
1000c6f0c:     	add	x14, x9, x14
1000c6f10:     	lsr	x15, x6, #8
1000c6f14:     	and	x15, x15, #0xf0
1000c6f18:     	add	x15, x9, x15
1000c6f1c:     	lsr	x16, x6, #12
1000c6f20:     	and	x16, x16, #0xf0
1000c6f24:     	add	x16, x9, x16
1000c6f28:     	lsr	x17, x6, #16
1000c6f2c:     	and	x17, x17, #0xf0
1000c6f30:     	add	x17, x9, x17
1000c6f34:     	lsr	x5, x6, #20
1000c6f38:     	and	x5, x5, #0xf0
1000c6f3c:     	add	x5, x9, x5
1000c6f40:     	lsr	x6, x6, #24
1000c6f44:     	and	x6, x6, #0xf0
1000c6f48:     	add	x6, x9, x6
1000c6f4c:     	ldr	w7, [x10, x11]
1000c6f50:     	and	x19, x7, #0xf
1000c6f54:     	ldrsb	w19, [x12, x19]
1000c6f58:     	ubfx	x20, x7, #4, #4
1000c6f5c:     	ldrsb	w20, [x13, x20]
1000c6f60:     	ubfx	x21, x7, #8, #4
1000c6f64:     	ldrsb	w21, [x14, x21]
1000c6f68:     	add	w19, w19, w20
1000c6f6c:     	add	w19, w19, w21
1000c6f70:     	ubfx	x20, x7, #12, #4
1000c6f74:     	ldrsb	w20, [x15, x20]
1000c6f78:     	ubfx	x21, x7, #16, #4
1000c6f7c:     	ldrsb	w21, [x16, x21]
1000c6f80:     	add	w19, w19, w20
1000c6f84:     	add	w19, w19, w21
1000c6f88:     	ubfx	x20, x7, #20, #4
1000c6f8c:     	ldrsb	w20, [x17, x20]
1000c6f90:     	ubfx	x21, x7, #24, #4
1000c6f94:     	ldrsb	w21, [x5, x21]
1000c6f98:     	lsr	x7, x7, #28
1000c6f9c:     	ldrsb	w7, [x6, x7]
1000c6fa0:     	add	w19, w19, w20
1000c6fa4:     	add	w19, w19, w21
1000c6fa8:     	add	w7, w19, w7
1000c6fac:     	scvtf	s0, w7
1000c6fb0:     	ldr	s1, [x3, x11]
1000c6fb4:     	fadd	s0, s1, s0
1000c6fb8:     	str	s0, [x3, x11]
1000c6fbc:     	add	x11, x11, #4
1000c6fc0:     	cmp	x11, #64
1000c6fc4:     	b.ne	0x1000c6f4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c6fc8:     	add	x12, x8, #8
1000c6fcc:     	add	x10, x10, #64
1000c6fd0:     	cmp	x12, x2
1000c6fd4:     	b.ls	0x1000c6edc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c6fd8:     	cmp	x8, x2
1000c6fdc:     	b.hs	0x1000c7294 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000c6fe0:     	lsl	x9, x4, #2
1000c6fe4:     	lsl	w10, w8, #2
1000c6fe8:     	mov	w11, #-16
1000c6fec:     	lsr	x13, x8, #3
1000c6ff0:     	mul	x12, x9, x13
1000c6ff4:     	ubfx	x14, x8, #1, #2
1000c6ff8:     	orr	x12, x12, x14
1000c6ffc:     	ldrb	w15, [x1, x12]
1000c7000:     	and	w12, w10, #0x4
1000c7004:     	lsr	w15, w15, w12
1000c7008:     	and	w16, w15, #0xf
1000c700c:     	cmp	w16, #8
1000c7010:     	csel	w16, wzr, w11, lo
1000c7014:     	bfi	x14, x13, #6, #58
1000c7018:     	add	x13, x0, x14
1000c701c:     	ldrb	w14, [x13]
1000c7020:     	lsr	w14, w14, w12
1000c7024:     	bfxil	w16, w15, #0, #4
1000c7028:     	and	w15, w14, #0xf
1000c702c:     	cmp	w15, #8
1000c7030:     	csel	w15, wzr, w11, lo
1000c7034:     	bfxil	w15, w14, #0, #4
1000c7038:     	scvtf	s0, w16
1000c703c:     	scvtf	s1, w15
1000c7040:     	ldp	s2, s3, [x3]
1000c7044:     	fmsub	s1, s1, s0, s2
1000c7048:     	str	s1, [x3]
1000c704c:     	ldrb	w14, [x13, #4]
1000c7050:     	lsr	w14, w14, w12
1000c7054:     	and	w15, w14, #0xf
1000c7058:     	cmp	w15, #8
1000c705c:     	csel	w15, wzr, w11, lo
1000c7060:     	bfxil	w15, w14, #0, #4
1000c7064:     	scvtf	s1, w15
1000c7068:     	fmsub	s1, s1, s0, s3
1000c706c:     	str	s1, [x3, #4]
1000c7070:     	ldrb	w14, [x13, #8]
1000c7074:     	lsr	w14, w14, w12
1000c7078:     	and	w15, w14, #0xf
1000c707c:     	cmp	w15, #8
1000c7080:     	csel	w15, wzr, w11, lo
1000c7084:     	bfxil	w15, w14, #0, #4
1000c7088:     	scvtf	s1, w15
1000c708c:     	ldp	s2, s3, [x3, #8]
1000c7090:     	fmsub	s1, s1, s0, s2
1000c7094:     	str	s1, [x3, #8]
1000c7098:     	ldrb	w14, [x13, #12]
1000c709c:     	lsr	w14, w14, w12
1000c70a0:     	and	w15, w14, #0xf
1000c70a4:     	cmp	w15, #8
1000c70a8:     	csel	w15, wzr, w11, lo
1000c70ac:     	bfxil	w15, w14, #0, #4
1000c70b0:     	scvtf	s1, w15
1000c70b4:     	fmsub	s1, s1, s0, s3
1000c70b8:     	str	s1, [x3, #12]
1000c70bc:     	ldrb	w14, [x13, #16]
1000c70c0:     	lsr	w14, w14, w12
1000c70c4:     	and	w15, w14, #0xf
1000c70c8:     	cmp	w15, #8
1000c70cc:     	csel	w15, wzr, w11, lo
1000c70d0:     	bfxil	w15, w14, #0, #4
1000c70d4:     	scvtf	s1, w15
1000c70d8:     	ldp	s2, s3, [x3, #16]
1000c70dc:     	fmsub	s1, s1, s0, s2
1000c70e0:     	str	s1, [x3, #16]
1000c70e4:     	ldrb	w14, [x13, #20]
1000c70e8:     	lsr	w14, w14, w12
1000c70ec:     	and	w15, w14, #0xf
1000c70f0:     	cmp	w15, #8
1000c70f4:     	csel	w15, wzr, w11, lo
1000c70f8:     	bfxil	w15, w14, #0, #4
1000c70fc:     	scvtf	s1, w15
1000c7100:     	fmsub	s1, s1, s0, s3
1000c7104:     	str	s1, [x3, #20]
1000c7108:     	ldrb	w14, [x13, #24]
1000c710c:     	lsr	w14, w14, w12
1000c7110:     	and	w15, w14, #0xf
1000c7114:     	cmp	w15, #8
1000c7118:     	csel	w15, wzr, w11, lo
1000c711c:     	bfxil	w15, w14, #0, #4
1000c7120:     	scvtf	s1, w15
1000c7124:     	ldp	s2, s3, [x3, #24]
1000c7128:     	fmsub	s1, s1, s0, s2
1000c712c:     	str	s1, [x3, #24]
1000c7130:     	ldrb	w14, [x13, #28]
1000c7134:     	lsr	w14, w14, w12
1000c7138:     	and	w15, w14, #0xf
1000c713c:     	cmp	w15, #8
1000c7140:     	csel	w15, wzr, w11, lo
1000c7144:     	bfxil	w15, w14, #0, #4
1000c7148:     	scvtf	s1, w15
1000c714c:     	fmsub	s1, s1, s0, s3
1000c7150:     	str	s1, [x3, #28]
1000c7154:     	ldrb	w14, [x13, #32]
1000c7158:     	lsr	w14, w14, w12
1000c715c:     	and	w15, w14, #0xf
1000c7160:     	cmp	w15, #8
1000c7164:     	csel	w15, wzr, w11, lo
1000c7168:     	bfxil	w15, w14, #0, #4
1000c716c:     	scvtf	s1, w15
1000c7170:     	ldp	s2, s3, [x3, #32]
1000c7174:     	fmsub	s1, s1, s0, s2
1000c7178:     	str	s1, [x3, #32]
1000c717c:     	ldrb	w14, [x13, #36]
1000c7180:     	lsr	w14, w14, w12
1000c7184:     	and	w15, w14, #0xf
1000c7188:     	cmp	w15, #8
1000c718c:     	csel	w15, wzr, w11, lo
1000c7190:     	bfxil	w15, w14, #0, #4
1000c7194:     	scvtf	s1, w15
1000c7198:     	fmsub	s1, s1, s0, s3
1000c719c:     	str	s1, [x3, #36]
1000c71a0:     	ldrb	w14, [x13, #40]
1000c71a4:     	lsr	w14, w14, w12
1000c71a8:     	and	w15, w14, #0xf
1000c71ac:     	cmp	w15, #8
1000c71b0:     	csel	w15, wzr, w11, lo
1000c71b4:     	bfxil	w15, w14, #0, #4
1000c71b8:     	scvtf	s1, w15
1000c71bc:     	ldp	s2, s3, [x3, #40]
1000c71c0:     	fmsub	s1, s1, s0, s2
1000c71c4:     	str	s1, [x3, #40]
1000c71c8:     	ldrb	w14, [x13, #44]
1000c71cc:     	lsr	w14, w14, w12
1000c71d0:     	and	w15, w14, #0xf
1000c71d4:     	cmp	w15, #8
1000c71d8:     	csel	w15, wzr, w11, lo
1000c71dc:     	bfxil	w15, w14, #0, #4
1000c71e0:     	scvtf	s1, w15
1000c71e4:     	fmsub	s1, s1, s0, s3
1000c71e8:     	str	s1, [x3, #44]
1000c71ec:     	ldrb	w14, [x13, #48]
1000c71f0:     	lsr	w14, w14, w12
1000c71f4:     	and	w15, w14, #0xf
1000c71f8:     	cmp	w15, #8
1000c71fc:     	csel	w15, wzr, w11, lo
1000c7200:     	bfxil	w15, w14, #0, #4
1000c7204:     	scvtf	s1, w15
1000c7208:     	ldp	s2, s3, [x3, #48]
1000c720c:     	fmsub	s1, s1, s0, s2
1000c7210:     	str	s1, [x3, #48]
1000c7214:     	ldrb	w14, [x13, #52]
1000c7218:     	lsr	w14, w14, w12
1000c721c:     	and	w15, w14, #0xf
1000c7220:     	cmp	w15, #8
1000c7224:     	csel	w15, wzr, w11, lo
1000c7228:     	bfxil	w15, w14, #0, #4
1000c722c:     	scvtf	s1, w15
1000c7230:     	fmsub	s1, s1, s0, s3
1000c7234:     	str	s1, [x3, #52]
1000c7238:     	ldrb	w14, [x13, #56]
1000c723c:     	lsr	w14, w14, w12
1000c7240:     	and	w15, w14, #0xf
1000c7244:     	cmp	w15, #8
1000c7248:     	csel	w15, wzr, w11, lo
1000c724c:     	bfxil	w15, w14, #0, #4
1000c7250:     	scvtf	s1, w15
1000c7254:     	ldp	s2, s3, [x3, #56]
1000c7258:     	fmsub	s1, s1, s0, s2
1000c725c:     	str	s1, [x3, #56]
1000c7260:     	ldrb	w13, [x13, #60]
1000c7264:     	lsr	w12, w13, w12
1000c7268:     	and	w13, w12, #0xf
1000c726c:     	cmp	w13, #8
1000c7270:     	csel	w13, wzr, w11, lo
1000c7274:     	bfxil	w13, w12, #0, #4
1000c7278:     	scvtf	s1, w13
1000c727c:     	fmsub	s0, s1, s0, s3
1000c7280:     	str	s0, [x3, #60]
1000c7284:     	add	x8, x8, #1
1000c7288:     	add	w10, w10, #4
1000c728c:     	cmp	x2, x8
1000c7290:     	b.ne	0x1000c6fec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c7294:     	ldp	x20, x19, [sp, #16]
1000c7298:     	ldp	x22, x21, [sp], #32
1000c729c:     	ret

00000001000c8680 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c8680:     	sub	sp, sp, #272
1000c8684:     	stp	x28, x27, [sp, #176]
1000c8688:     	stp	x26, x25, [sp, #192]
1000c868c:     	stp	x24, x23, [sp, #208]
1000c8690:     	stp	x22, x21, [sp, #224]
1000c8694:     	stp	x20, x19, [sp, #240]
1000c8698:     	stp	x29, x30, [sp, #256]
1000c869c:     	add	x29, sp, #256
1000c86a0:     	str	x3, [sp]
1000c86a4:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x84>
1000c86a8:     	ldr	x8, [x8, #392]
1000c86ac:     	ldr	x8, [x8]
1000c86b0:     	stur	x8, [x29, #-96]
1000c86b4:     	movi.2d	v0, #0000000000000000
1000c86b8:     	stp	q0, q0, [sp, #128]
1000c86bc:     	stp	q0, q0, [sp, #96]
1000c86c0:     	stp	q0, q0, [sp, #64]
1000c86c4:     	stp	q0, q0, [sp, #32]
1000c86c8:     	ands	x8, x2, #0xfffffffffffffffe
1000c86cc:     	b.eq	0x1000c8850 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c86d0:     	add	x8, x1, x8
1000c86d4:     	str	x8, [sp, #8]
1000c86d8:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c86dc:     	add	x9, x9, #1212
1000c86e0:     	mov	x11, #0
1000c86e4:     	ldp	w4, w23, [x1]
1000c86e8:     	ubfx	x8, x4, #8, #4
1000c86ec:     	stp	x1, x8, [sp, #16]
1000c86f0:     	ubfx	x13, x4, #16, #4
1000c86f4:     	and	x14, x4, #0xf
1000c86f8:     	ubfx	x15, x4, #24, #4
1000c86fc:     	ubfx	x16, x4, #4, #4
1000c8700:     	ubfx	x17, x4, #12, #4
1000c8704:     	ubfx	x2, x4, #20, #4
1000c8708:     	lsr	x4, x4, #28
1000c870c:     	and	x5, x23, #0xf
1000c8710:     	ubfx	x6, x23, #8, #4
1000c8714:     	ubfx	x7, x23, #16, #4
1000c8718:     	ubfx	x19, x23, #24, #4
1000c871c:     	ubfx	x20, x23, #4, #4
1000c8720:     	ubfx	x21, x23, #12, #4
1000c8724:     	ubfx	x22, x23, #20, #4
1000c8728:     	lsr	x23, x23, #28
1000c872c:     	ldr	w24, [x0, x11]
1000c8730:     	lsl	w25, w24, #4
1000c8734:     	and	x25, x25, #0xf0
1000c8738:     	add	x25, x9, x25
1000c873c:     	and	x26, x24, #0xf0
1000c8740:     	add	x26, x9, x26
1000c8744:     	lsr	x27, x24, #4
1000c8748:     	and	x27, x27, #0xf0
1000c874c:     	add	x27, x9, x27
1000c8750:     	lsr	x28, x24, #8
1000c8754:     	and	x28, x28, #0xf0
1000c8758:     	add	x28, x9, x28
1000c875c:     	lsr	x30, x24, #12
1000c8760:     	and	x30, x30, #0xf0
1000c8764:     	add	x30, x9, x30
1000c8768:     	lsr	x8, x24, #16
1000c876c:     	and	x8, x8, #0xf0
1000c8770:     	add	x8, x9, x8
1000c8774:     	lsr	x3, x24, #20
1000c8778:     	and	x3, x3, #0xf0
1000c877c:     	add	x3, x9, x3
1000c8780:     	lsr	x24, x24, #24
1000c8784:     	and	x24, x24, #0xf0
1000c8788:     	ldrb	w10, [x25, x14]
1000c878c:     	ldr	x12, [sp, #24]
1000c8790:     	ldrb	w1, [x27, x12]
1000c8794:     	ldrb	w12, [x30, x13]
1000c8798:     	add	w10, w10, w1
1000c879c:     	add	w10, w10, w12
1000c87a0:     	ldrb	w12, [x3, x15]
1000c87a4:     	ldrb	w1, [x26, x16]
1000c87a8:     	add	w10, w10, w12
1000c87ac:     	add	w10, w10, w1
1000c87b0:     	ldrb	w12, [x28, x17]
1000c87b4:     	ldrb	w1, [x8, x2]
1000c87b8:     	add	x24, x9, x24
1000c87bc:     	add	w10, w10, w12
1000c87c0:     	add	w10, w10, w1
1000c87c4:     	ldrb	w12, [x24, x4]
1000c87c8:     	add	w10, w10, w12
1000c87cc:     	scvtf	s0, w10
1000c87d0:     	add	x10, sp, #32
1000c87d4:     	add	x10, x10, x11
1000c87d8:     	ldr	s1, [x10]
1000c87dc:     	ldrb	w12, [x25, x5]
1000c87e0:     	fadd	s0, s1, s0
1000c87e4:     	ldrb	w1, [x27, x6]
1000c87e8:     	ldrb	w25, [x30, x7]
1000c87ec:     	add	w12, w12, w1
1000c87f0:     	add	w12, w12, w25
1000c87f4:     	ldrb	w1, [x3, x19]
1000c87f8:     	ldrb	w3, [x26, x20]
1000c87fc:     	add	w12, w12, w1
1000c8800:     	add	w12, w12, w3
1000c8804:     	ldrb	w1, [x28, x21]
1000c8808:     	ldrb	w8, [x8, x22]
1000c880c:     	add	w12, w12, w1
1000c8810:     	add	w8, w12, w8
1000c8814:     	ldrb	w12, [x24, x23]
1000c8818:     	add	w8, w8, w12
1000c881c:     	scvtf	s1, w8
1000c8820:     	str	s0, [x10]
1000c8824:     	ldr	s0, [x10, #64]
1000c8828:     	fadd	s0, s0, s1
1000c882c:     	str	s0, [x10, #64]
1000c8830:     	add	x11, x11, #4
1000c8834:     	cmp	x11, #64
1000c8838:     	b.ne	0x1000c872c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c883c:     	add	x0, x0, #64
1000c8840:     	ldp	x8, x1, [sp, #8]
1000c8844:     	add	x1, x1, #8
1000c8848:     	cmp	x1, x8
1000c884c:     	b.ne	0x1000c86e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c8850:     	ldp	q0, q1, [sp, #96]
1000c8854:     	ldr	x8, [sp]
1000c8858:     	stp	q0, q1, [x8, #64]
1000c885c:     	ldp	q0, q1, [sp, #128]
1000c8860:     	stp	q0, q1, [x8, #96]
1000c8864:     	ldp	q0, q1, [sp, #32]
1000c8868:     	stp	q0, q1, [x8]
1000c886c:     	ldp	q0, q1, [sp, #64]
1000c8870:     	stp	q0, q1, [x8, #32]
1000c8874:     	ldur	x8, [x29, #-96]
1000c8878:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x19c>
1000c887c:     	ldr	x9, [x9, #392]
1000c8880:     	ldr	x9, [x9]
1000c8884:     	cmp	x9, x8
1000c8888:     	b.ne	0x1000c88ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c888c:     	ldp	x29, x30, [sp, #256]
1000c8890:     	ldp	x20, x19, [sp, #240]
1000c8894:     	ldp	x22, x21, [sp, #224]
1000c8898:     	ldp	x24, x23, [sp, #208]
1000c889c:     	ldp	x26, x25, [sp, #192]
1000c88a0:     	ldp	x28, x27, [sp, #176]
1000c88a4:     	add	sp, sp, #272
1000c88a8:     	ret
1000c88ac:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c896c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c896c:     	sub	sp, sp, #272
1000c8970:     	stp	x28, x27, [sp, #176]
1000c8974:     	stp	x26, x25, [sp, #192]
1000c8978:     	stp	x24, x23, [sp, #208]
1000c897c:     	stp	x22, x21, [sp, #224]
1000c8980:     	stp	x20, x19, [sp, #240]
1000c8984:     	stp	x29, x30, [sp, #256]
1000c8988:     	add	x29, sp, #256
1000c898c:     	str	x3, [sp]
1000c8990:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x84>
1000c8994:     	ldr	x8, [x8, #392]
1000c8998:     	ldr	x8, [x8]
1000c899c:     	stur	x8, [x29, #-96]
1000c89a0:     	movi.2d	v0, #0000000000000000
1000c89a4:     	stp	q0, q0, [sp, #128]
1000c89a8:     	stp	q0, q0, [sp, #96]
1000c89ac:     	stp	q0, q0, [sp, #64]
1000c89b0:     	stp	q0, q0, [sp, #32]
1000c89b4:     	ands	x8, x2, #0xfffffffffffffffe
1000c89b8:     	b.eq	0x1000c8b3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c89bc:     	add	x8, x1, x8
1000c89c0:     	str	x8, [sp, #8]
1000c89c4:     	adrp	x9, 0x10016a000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0xb0>
1000c89c8:     	add	x9, x9, #1468
1000c89cc:     	mov	x11, #0
1000c89d0:     	ldp	w4, w23, [x1]
1000c89d4:     	ubfx	x8, x4, #8, #4
1000c89d8:     	stp	x1, x8, [sp, #16]
1000c89dc:     	ubfx	x13, x4, #16, #4
1000c89e0:     	and	x14, x4, #0xf
1000c89e4:     	ubfx	x15, x4, #24, #4
1000c89e8:     	ubfx	x16, x4, #4, #4
1000c89ec:     	ubfx	x17, x4, #12, #4
1000c89f0:     	ubfx	x2, x4, #20, #4
1000c89f4:     	lsr	x4, x4, #28
1000c89f8:     	and	x5, x23, #0xf
1000c89fc:     	ubfx	x6, x23, #8, #4
1000c8a00:     	ubfx	x7, x23, #16, #4
1000c8a04:     	ubfx	x19, x23, #24, #4
1000c8a08:     	ubfx	x20, x23, #4, #4
1000c8a0c:     	ubfx	x21, x23, #12, #4
1000c8a10:     	ubfx	x22, x23, #20, #4
1000c8a14:     	lsr	x23, x23, #28
1000c8a18:     	ldr	w24, [x0, x11]
1000c8a1c:     	lsl	w25, w24, #4
1000c8a20:     	and	x25, x25, #0xf0
1000c8a24:     	add	x25, x9, x25
1000c8a28:     	and	x26, x24, #0xf0
1000c8a2c:     	add	x26, x9, x26
1000c8a30:     	lsr	x27, x24, #4
1000c8a34:     	and	x27, x27, #0xf0
1000c8a38:     	add	x27, x9, x27
1000c8a3c:     	lsr	x28, x24, #8
1000c8a40:     	and	x28, x28, #0xf0
1000c8a44:     	add	x28, x9, x28
1000c8a48:     	lsr	x30, x24, #12
1000c8a4c:     	and	x30, x30, #0xf0
1000c8a50:     	add	x30, x9, x30
1000c8a54:     	lsr	x8, x24, #16
1000c8a58:     	and	x8, x8, #0xf0
1000c8a5c:     	add	x8, x9, x8
1000c8a60:     	lsr	x3, x24, #20
1000c8a64:     	and	x3, x3, #0xf0
1000c8a68:     	add	x3, x9, x3
1000c8a6c:     	lsr	x24, x24, #24
1000c8a70:     	and	x24, x24, #0xf0
1000c8a74:     	ldrsb	w10, [x25, x14]
1000c8a78:     	ldr	x12, [sp, #24]
1000c8a7c:     	ldrsb	w1, [x27, x12]
1000c8a80:     	ldrsb	w12, [x30, x13]
1000c8a84:     	add	w10, w10, w1
1000c8a88:     	add	w10, w10, w12
1000c8a8c:     	ldrsb	w12, [x3, x15]
1000c8a90:     	ldrsb	w1, [x26, x16]
1000c8a94:     	add	w10, w10, w12
1000c8a98:     	add	w10, w10, w1
1000c8a9c:     	ldrsb	w12, [x28, x17]
1000c8aa0:     	ldrsb	w1, [x8, x2]
1000c8aa4:     	add	x24, x9, x24
1000c8aa8:     	add	w10, w10, w12
1000c8aac:     	add	w10, w10, w1
1000c8ab0:     	ldrsb	w12, [x24, x4]
1000c8ab4:     	add	w10, w10, w12
1000c8ab8:     	scvtf	s0, w10
1000c8abc:     	add	x10, sp, #32
1000c8ac0:     	add	x10, x10, x11
1000c8ac4:     	ldr	s1, [x10]
1000c8ac8:     	ldrsb	w12, [x25, x5]
1000c8acc:     	fadd	s0, s1, s0
1000c8ad0:     	ldrsb	w1, [x27, x6]
1000c8ad4:     	ldrsb	w25, [x30, x7]
1000c8ad8:     	add	w12, w12, w1
1000c8adc:     	add	w12, w12, w25
1000c8ae0:     	ldrsb	w1, [x3, x19]
1000c8ae4:     	ldrsb	w3, [x26, x20]
1000c8ae8:     	add	w12, w12, w1
1000c8aec:     	add	w12, w12, w3
1000c8af0:     	ldrsb	w1, [x28, x21]
1000c8af4:     	ldrsb	w8, [x8, x22]
1000c8af8:     	add	w12, w12, w1
1000c8afc:     	add	w8, w12, w8
1000c8b00:     	ldrsb	w12, [x24, x23]
1000c8b04:     	add	w8, w8, w12
1000c8b08:     	scvtf	s1, w8
1000c8b0c:     	str	s0, [x10]
1000c8b10:     	ldr	s0, [x10, #64]
1000c8b14:     	fadd	s0, s0, s1
1000c8b18:     	str	s0, [x10, #64]
1000c8b1c:     	add	x11, x11, #4
1000c8b20:     	cmp	x11, #64
1000c8b24:     	b.ne	0x1000c8a18 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c8b28:     	add	x0, x0, #64
1000c8b2c:     	ldp	x8, x1, [sp, #8]
1000c8b30:     	add	x1, x1, #8
1000c8b34:     	cmp	x1, x8
1000c8b38:     	b.ne	0x1000c89cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c8b3c:     	ldp	q0, q1, [sp, #96]
1000c8b40:     	ldr	x8, [sp]
1000c8b44:     	stp	q0, q1, [x8, #64]
1000c8b48:     	ldp	q0, q1, [sp, #128]
1000c8b4c:     	stp	q0, q1, [x8, #96]
1000c8b50:     	ldp	q0, q1, [sp, #32]
1000c8b54:     	stp	q0, q1, [x8]
1000c8b58:     	ldp	q0, q1, [sp, #64]
1000c8b5c:     	stp	q0, q1, [x8, #32]
1000c8b60:     	ldur	x8, [x29, #-96]
1000c8b64:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x258>
1000c8b68:     	ldr	x9, [x9, #392]
1000c8b6c:     	ldr	x9, [x9]
1000c8b70:     	cmp	x9, x8
1000c8b74:     	b.ne	0x1000c8b98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c8b78:     	ldp	x29, x30, [sp, #256]
1000c8b7c:     	ldp	x20, x19, [sp, #240]
1000c8b80:     	ldp	x22, x21, [sp, #224]
1000c8b84:     	ldp	x24, x23, [sp, #208]
1000c8b88:     	ldp	x26, x25, [sp, #192]
1000c8b8c:     	ldp	x28, x27, [sp, #176]
1000c8b90:     	add	sp, sp, #272
1000c8b94:     	ret
1000c8b98:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c9fe8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c9fe8:     	stp	x28, x27, [sp, #-96]!
1000c9fec:     	stp	x26, x25, [sp, #16]
1000c9ff0:     	stp	x24, x23, [sp, #32]
1000c9ff4:     	stp	x22, x21, [sp, #48]
1000c9ff8:     	stp	x20, x19, [sp, #64]
1000c9ffc:     	stp	x29, x30, [sp, #80]
1000ca000:     	add	x29, sp, #80
1000ca004:     	sub	sp, sp, #448
1000ca008:     	str	x3, [sp]
1000ca00c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000ca010:     	ldr	x8, [x8, #392]
1000ca014:     	ldr	x8, [x8]
1000ca018:     	stur	x8, [x29, #-96]
1000ca01c:     	movi.2d	v0, #0000000000000000
1000ca020:     	stp	q0, q0, [sp, #400]
1000ca024:     	lsl	x8, x2, #1
1000ca028:     	stp	q0, q0, [sp, #368]
1000ca02c:     	stp	q0, q0, [sp, #336]
1000ca030:     	stp	q0, q0, [sp, #304]
1000ca034:     	stp	q0, q0, [sp, #272]
1000ca038:     	stp	q0, q0, [sp, #240]
1000ca03c:     	stp	q0, q0, [sp, #208]
1000ca040:     	stp	q0, q0, [sp, #176]
1000ca044:     	ands	x8, x8, #0xfffffffffffffffc
1000ca048:     	b.eq	0x1000ca324 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000ca04c:     	add	x8, x1, x8
1000ca050:     	str	x8, [sp, #8]
1000ca054:     	add	x8, sp, #176
1000ca058:     	add	x27, x8, #128
1000ca05c:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000ca060:     	add	x11, x11, #1212
1000ca064:     	mov	x12, #0
1000ca068:     	ldp	w8, w9, [x1]
1000ca06c:     	ubfx	x10, x8, #8, #4
1000ca070:     	str	x10, [sp, #168]
1000ca074:     	ubfx	x10, x8, #16, #4
1000ca078:     	str	x10, [sp, #160]
1000ca07c:     	ubfx	x10, x8, #24, #4
1000ca080:     	str	x10, [sp, #152]
1000ca084:     	ldp	w10, w17, [x1, #8]
1000ca088:     	str	x1, [sp, #16]
1000ca08c:     	and	x14, x8, #0xf
1000ca090:     	ubfx	x13, x8, #4, #4
1000ca094:     	stp	x13, x14, [sp, #136]
1000ca098:     	ubfx	x14, x8, #12, #4
1000ca09c:     	ubfx	x13, x8, #20, #4
1000ca0a0:     	stp	x13, x14, [sp, #120]
1000ca0a4:     	lsr	x8, x8, #28
1000ca0a8:     	str	x8, [sp, #112]
1000ca0ac:     	and	x8, x9, #0xf
1000ca0b0:     	str	x8, [sp, #104]
1000ca0b4:     	ubfx	x8, x9, #8, #4
1000ca0b8:     	str	x8, [sp, #96]
1000ca0bc:     	ubfx	x8, x9, #16, #4
1000ca0c0:     	str	x8, [sp, #88]
1000ca0c4:     	ubfx	x8, x9, #24, #4
1000ca0c8:     	str	x8, [sp, #80]
1000ca0cc:     	ubfx	x8, x9, #4, #4
1000ca0d0:     	str	x8, [sp, #72]
1000ca0d4:     	ubfx	x8, x9, #12, #4
1000ca0d8:     	str	x8, [sp, #64]
1000ca0dc:     	ubfx	x8, x9, #20, #4
1000ca0e0:     	str	x8, [sp, #56]
1000ca0e4:     	lsr	x8, x9, #28
1000ca0e8:     	str	x8, [sp, #48]
1000ca0ec:     	and	x9, x10, #0xf
1000ca0f0:     	ubfx	x8, x10, #8, #4
1000ca0f4:     	stp	x8, x9, [sp, #32]
1000ca0f8:     	ubfx	x8, x10, #16, #4
1000ca0fc:     	str	x8, [sp, #24]
1000ca100:     	ubfx	x28, x10, #24, #4
1000ca104:     	ubfx	x30, x10, #4, #4
1000ca108:     	ubfx	x8, x10, #12, #4
1000ca10c:     	ubfx	x3, x10, #20, #4
1000ca110:     	lsr	x9, x10, #28
1000ca114:     	and	x1, x17, #0xf
1000ca118:     	ubfx	x10, x17, #8, #4
1000ca11c:     	ubfx	x13, x17, #16, #4
1000ca120:     	ubfx	x26, x17, #24, #4
1000ca124:     	ubfx	x14, x17, #4, #4
1000ca128:     	ubfx	x15, x17, #12, #4
1000ca12c:     	ubfx	x16, x17, #20, #4
1000ca130:     	lsr	x17, x17, #28
1000ca134:     	ldr	w20, [x0, x12]
1000ca138:     	lsl	w2, w20, #4
1000ca13c:     	and	x2, x2, #0xf0
1000ca140:     	add	x5, x11, x2
1000ca144:     	and	x2, x20, #0xf0
1000ca148:     	add	x2, x11, x2
1000ca14c:     	lsr	x4, x20, #4
1000ca150:     	and	x4, x4, #0xf0
1000ca154:     	add	x7, x11, x4
1000ca158:     	lsr	x4, x20, #8
1000ca15c:     	and	x4, x4, #0xf0
1000ca160:     	add	x4, x11, x4
1000ca164:     	lsr	x6, x20, #12
1000ca168:     	and	x6, x6, #0xf0
1000ca16c:     	add	x19, x11, x6
1000ca170:     	lsr	x6, x20, #16
1000ca174:     	and	x6, x6, #0xf0
1000ca178:     	add	x6, x11, x6
1000ca17c:     	lsr	x21, x20, #20
1000ca180:     	and	x21, x21, #0xf0
1000ca184:     	add	x21, x11, x21
1000ca188:     	lsr	x20, x20, #24
1000ca18c:     	and	x20, x20, #0xf0
1000ca190:     	ldr	x22, [sp, #144]
1000ca194:     	ldrb	w22, [x5, x22]
1000ca198:     	add	x20, x11, x20
1000ca19c:     	ldp	x24, x23, [sp, #160]
1000ca1a0:     	ldrb	w23, [x7, x23]
1000ca1a4:     	ldrb	w24, [x19, x24]
1000ca1a8:     	add	w22, w22, w23
1000ca1ac:     	add	w22, w22, w24
1000ca1b0:     	ldr	x23, [sp, #152]
1000ca1b4:     	ldrb	w23, [x21, x23]
1000ca1b8:     	ldr	x24, [sp, #136]
1000ca1bc:     	ldrb	w24, [x2, x24]
1000ca1c0:     	add	w22, w22, w23
1000ca1c4:     	add	w22, w22, w24
1000ca1c8:     	ldp	x24, x23, [sp, #120]
1000ca1cc:     	ldrb	w23, [x4, x23]
1000ca1d0:     	ldrb	w24, [x6, x24]
1000ca1d4:     	add	w22, w22, w23
1000ca1d8:     	add	w22, w22, w24
1000ca1dc:     	ldr	x23, [sp, #112]
1000ca1e0:     	ldrb	w23, [x20, x23]
1000ca1e4:     	add	w22, w22, w23
1000ca1e8:     	scvtf	s0, w22
1000ca1ec:     	ldp	x23, x22, [sp, #96]
1000ca1f0:     	ldrb	w22, [x5, x22]
1000ca1f4:     	ldrb	w23, [x7, x23]
1000ca1f8:     	ldp	x25, x24, [sp, #80]
1000ca1fc:     	ldrb	w24, [x19, x24]
1000ca200:     	ldrb	w25, [x21, x25]
1000ca204:     	add	w22, w22, w23
1000ca208:     	ldr	x23, [sp, #72]
1000ca20c:     	ldrb	w23, [x2, x23]
1000ca210:     	add	w22, w22, w24
1000ca214:     	ldr	x24, [sp, #64]
1000ca218:     	ldrb	w24, [x4, x24]
1000ca21c:     	add	w22, w22, w25
1000ca220:     	ldr	x25, [sp, #56]
1000ca224:     	ldrb	w25, [x6, x25]
1000ca228:     	add	w22, w22, w23
1000ca22c:     	add	w22, w22, w24
1000ca230:     	add	w22, w22, w25
1000ca234:     	ldr	x23, [sp, #48]
1000ca238:     	ldrb	w23, [x20, x23]
1000ca23c:     	add	w22, w22, w23
1000ca240:     	scvtf	s1, w22
1000ca244:     	ldp	x23, x22, [sp, #32]
1000ca248:     	ldrb	w22, [x5, x22]
1000ca24c:     	ldrb	w23, [x7, x23]
1000ca250:     	ldr	x24, [sp, #24]
1000ca254:     	ldrb	w24, [x19, x24]
1000ca258:     	add	w22, w22, w23
1000ca25c:     	ldrb	w23, [x21, x28]
1000ca260:     	add	w22, w22, w24
1000ca264:     	ldrb	w24, [x2, x30]
1000ca268:     	add	w22, w22, w23
1000ca26c:     	ldrb	w23, [x4, x8]
1000ca270:     	add	w22, w22, w24
1000ca274:     	ldrb	w24, [x6, x3]
1000ca278:     	add	w22, w22, w23
1000ca27c:     	ldrb	w23, [x20, x9]
1000ca280:     	add	w22, w22, w24
1000ca284:     	add	w22, w22, w23
1000ca288:     	scvtf	s2, w22
1000ca28c:     	ldrb	w5, [x5, x1]
1000ca290:     	ldrb	w7, [x7, x10]
1000ca294:     	ldrb	w19, [x19, x13]
1000ca298:     	add	w5, w5, w7
1000ca29c:     	add	w5, w5, w19
1000ca2a0:     	ldrb	w7, [x21, x26]
1000ca2a4:     	ldrb	w2, [x2, x14]
1000ca2a8:     	add	w5, w5, w7
1000ca2ac:     	add	w2, w5, w2
1000ca2b0:     	ldrb	w4, [x4, x15]
1000ca2b4:     	ldrb	w5, [x6, x16]
1000ca2b8:     	add	w2, w2, w4
1000ca2bc:     	add	w2, w2, w5
1000ca2c0:     	ldrb	w4, [x20, x17]
1000ca2c4:     	add	w2, w2, w4
1000ca2c8:     	add	x4, sp, #176
1000ca2cc:     	scvtf	s3, w2
1000ca2d0:     	add	x2, x27, x12
1000ca2d4:     	ldur	s4, [x2, #-64]
1000ca2d8:     	fadd	s1, s4, s1
1000ca2dc:     	stur	s1, [x2, #-64]
1000ca2e0:     	ldr	s1, [x2]
1000ca2e4:     	fadd	s1, s1, s2
1000ca2e8:     	str	s1, [x2]
1000ca2ec:     	ldr	s1, [x2, #64]
1000ca2f0:     	fadd	s1, s1, s3
1000ca2f4:     	ldr	s2, [x4, x12]
1000ca2f8:     	str	s1, [x2, #64]
1000ca2fc:     	fadd	s0, s2, s0
1000ca300:     	str	s0, [x4, x12]
1000ca304:     	add	x12, x12, #4
1000ca308:     	cmp	x12, #64
1000ca30c:     	b.ne	0x1000ca134 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ca310:     	add	x0, x0, #64
1000ca314:     	ldp	x8, x1, [sp, #8]
1000ca318:     	add	x1, x1, #16
1000ca31c:     	cmp	x1, x8
1000ca320:     	b.ne	0x1000ca064 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000ca324:     	ldp	q0, q1, [sp, #368]
1000ca328:     	ldr	x8, [sp]
1000ca32c:     	stp	q0, q1, [x8, #192]
1000ca330:     	ldp	q0, q1, [sp, #400]
1000ca334:     	stp	q0, q1, [x8, #224]
1000ca338:     	ldp	q0, q1, [sp, #304]
1000ca33c:     	stp	q0, q1, [x8, #128]
1000ca340:     	ldp	q0, q1, [sp, #336]
1000ca344:     	stp	q0, q1, [x8, #160]
1000ca348:     	ldp	q0, q1, [sp, #240]
1000ca34c:     	stp	q0, q1, [x8, #64]
1000ca350:     	ldp	q0, q1, [sp, #272]
1000ca354:     	stp	q0, q1, [x8, #96]
1000ca358:     	ldp	q0, q1, [sp, #176]
1000ca35c:     	stp	q0, q1, [x8]
1000ca360:     	ldp	q0, q1, [sp, #208]
1000ca364:     	stp	q0, q1, [x8, #32]
1000ca368:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000ca36c:     	ldr	x8, [x8, #392]
1000ca370:     	ldr	x8, [x8]
1000ca374:     	ldur	x9, [x29, #-96]
1000ca378:     	cmp	x8, x9
1000ca37c:     	b.ne	0x1000ca3a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000ca380:     	add	sp, sp, #448
1000ca384:     	ldp	x29, x30, [sp, #80]
1000ca388:     	ldp	x20, x19, [sp, #64]
1000ca38c:     	ldp	x22, x21, [sp, #48]
1000ca390:     	ldp	x24, x23, [sp, #32]
1000ca394:     	ldp	x26, x25, [sp, #16]
1000ca398:     	ldp	x28, x27, [sp], #96
1000ca39c:     	ret
1000ca3a0:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000ca4b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ca4b4:     	stp	x28, x27, [sp, #-96]!
1000ca4b8:     	stp	x26, x25, [sp, #16]
1000ca4bc:     	stp	x24, x23, [sp, #32]
1000ca4c0:     	stp	x22, x21, [sp, #48]
1000ca4c4:     	stp	x20, x19, [sp, #64]
1000ca4c8:     	stp	x29, x30, [sp, #80]
1000ca4cc:     	add	x29, sp, #80
1000ca4d0:     	sub	sp, sp, #448
1000ca4d4:     	str	x3, [sp]
1000ca4d8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000ca4dc:     	ldr	x8, [x8, #392]
1000ca4e0:     	ldr	x8, [x8]
1000ca4e4:     	stur	x8, [x29, #-96]
1000ca4e8:     	movi.2d	v0, #0000000000000000
1000ca4ec:     	stp	q0, q0, [sp, #400]
1000ca4f0:     	lsl	x8, x2, #1
1000ca4f4:     	stp	q0, q0, [sp, #368]
1000ca4f8:     	stp	q0, q0, [sp, #336]
1000ca4fc:     	stp	q0, q0, [sp, #304]
1000ca500:     	stp	q0, q0, [sp, #272]
1000ca504:     	stp	q0, q0, [sp, #240]
1000ca508:     	stp	q0, q0, [sp, #208]
1000ca50c:     	stp	q0, q0, [sp, #176]
1000ca510:     	ands	x8, x8, #0xfffffffffffffffc
1000ca514:     	b.eq	0x1000ca7f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000ca518:     	add	x8, x1, x8
1000ca51c:     	str	x8, [sp, #8]
1000ca520:     	add	x8, sp, #176
1000ca524:     	add	x27, x8, #128
1000ca528:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000ca52c:     	add	x11, x11, #1468
1000ca530:     	mov	x12, #0
1000ca534:     	ldp	w8, w9, [x1]
1000ca538:     	ubfx	x10, x8, #8, #4
1000ca53c:     	str	x10, [sp, #168]
1000ca540:     	ubfx	x10, x8, #16, #4
1000ca544:     	str	x10, [sp, #160]
1000ca548:     	ubfx	x10, x8, #24, #4
1000ca54c:     	str	x10, [sp, #152]
1000ca550:     	ldp	w10, w17, [x1, #8]
1000ca554:     	str	x1, [sp, #16]
1000ca558:     	and	x14, x8, #0xf
1000ca55c:     	ubfx	x13, x8, #4, #4
1000ca560:     	stp	x13, x14, [sp, #136]
1000ca564:     	ubfx	x14, x8, #12, #4
1000ca568:     	ubfx	x13, x8, #20, #4
1000ca56c:     	stp	x13, x14, [sp, #120]
1000ca570:     	lsr	x8, x8, #28
1000ca574:     	str	x8, [sp, #112]
1000ca578:     	and	x8, x9, #0xf
1000ca57c:     	str	x8, [sp, #104]
1000ca580:     	ubfx	x8, x9, #8, #4
1000ca584:     	str	x8, [sp, #96]
1000ca588:     	ubfx	x8, x9, #16, #4
1000ca58c:     	str	x8, [sp, #88]
1000ca590:     	ubfx	x8, x9, #24, #4
1000ca594:     	str	x8, [sp, #80]
1000ca598:     	ubfx	x8, x9, #4, #4
1000ca59c:     	str	x8, [sp, #72]
1000ca5a0:     	ubfx	x8, x9, #12, #4
1000ca5a4:     	str	x8, [sp, #64]
1000ca5a8:     	ubfx	x8, x9, #20, #4
1000ca5ac:     	str	x8, [sp, #56]
1000ca5b0:     	lsr	x8, x9, #28
1000ca5b4:     	str	x8, [sp, #48]
1000ca5b8:     	and	x9, x10, #0xf
1000ca5bc:     	ubfx	x8, x10, #8, #4
1000ca5c0:     	stp	x8, x9, [sp, #32]
1000ca5c4:     	ubfx	x8, x10, #16, #4
1000ca5c8:     	str	x8, [sp, #24]
1000ca5cc:     	ubfx	x28, x10, #24, #4
1000ca5d0:     	ubfx	x30, x10, #4, #4
1000ca5d4:     	ubfx	x8, x10, #12, #4
1000ca5d8:     	ubfx	x3, x10, #20, #4
1000ca5dc:     	lsr	x9, x10, #28
1000ca5e0:     	and	x1, x17, #0xf
1000ca5e4:     	ubfx	x10, x17, #8, #4
1000ca5e8:     	ubfx	x13, x17, #16, #4
1000ca5ec:     	ubfx	x26, x17, #24, #4
1000ca5f0:     	ubfx	x14, x17, #4, #4
1000ca5f4:     	ubfx	x15, x17, #12, #4
1000ca5f8:     	ubfx	x16, x17, #20, #4
1000ca5fc:     	lsr	x17, x17, #28
1000ca600:     	ldr	w20, [x0, x12]
1000ca604:     	lsl	w2, w20, #4
1000ca608:     	and	x2, x2, #0xf0
1000ca60c:     	add	x5, x11, x2
1000ca610:     	and	x2, x20, #0xf0
1000ca614:     	add	x2, x11, x2
1000ca618:     	lsr	x4, x20, #4
1000ca61c:     	and	x4, x4, #0xf0
1000ca620:     	add	x7, x11, x4
1000ca624:     	lsr	x4, x20, #8
1000ca628:     	and	x4, x4, #0xf0
1000ca62c:     	add	x4, x11, x4
1000ca630:     	lsr	x6, x20, #12
1000ca634:     	and	x6, x6, #0xf0
1000ca638:     	add	x19, x11, x6
1000ca63c:     	lsr	x6, x20, #16
1000ca640:     	and	x6, x6, #0xf0
1000ca644:     	add	x6, x11, x6
1000ca648:     	lsr	x21, x20, #20
1000ca64c:     	and	x21, x21, #0xf0
1000ca650:     	add	x21, x11, x21
1000ca654:     	lsr	x20, x20, #24
1000ca658:     	and	x20, x20, #0xf0
1000ca65c:     	ldr	x22, [sp, #144]
1000ca660:     	ldrsb	w22, [x5, x22]
1000ca664:     	add	x20, x11, x20
1000ca668:     	ldp	x24, x23, [sp, #160]
1000ca66c:     	ldrsb	w23, [x7, x23]
1000ca670:     	ldrsb	w24, [x19, x24]
1000ca674:     	add	w22, w22, w23
1000ca678:     	add	w22, w22, w24
1000ca67c:     	ldr	x23, [sp, #152]
1000ca680:     	ldrsb	w23, [x21, x23]
1000ca684:     	ldr	x24, [sp, #136]
1000ca688:     	ldrsb	w24, [x2, x24]
1000ca68c:     	add	w22, w22, w23
1000ca690:     	add	w22, w22, w24
1000ca694:     	ldp	x24, x23, [sp, #120]
1000ca698:     	ldrsb	w23, [x4, x23]
1000ca69c:     	ldrsb	w24, [x6, x24]
1000ca6a0:     	add	w22, w22, w23
1000ca6a4:     	add	w22, w22, w24
1000ca6a8:     	ldr	x23, [sp, #112]
1000ca6ac:     	ldrsb	w23, [x20, x23]
1000ca6b0:     	add	w22, w22, w23
1000ca6b4:     	scvtf	s0, w22
1000ca6b8:     	ldp	x23, x22, [sp, #96]
1000ca6bc:     	ldrsb	w22, [x5, x22]
1000ca6c0:     	ldrsb	w23, [x7, x23]
1000ca6c4:     	ldp	x25, x24, [sp, #80]
1000ca6c8:     	ldrsb	w24, [x19, x24]
1000ca6cc:     	ldrsb	w25, [x21, x25]
1000ca6d0:     	add	w22, w22, w23
1000ca6d4:     	ldr	x23, [sp, #72]
1000ca6d8:     	ldrsb	w23, [x2, x23]
1000ca6dc:     	add	w22, w22, w24
1000ca6e0:     	ldr	x24, [sp, #64]
1000ca6e4:     	ldrsb	w24, [x4, x24]
1000ca6e8:     	add	w22, w22, w25
1000ca6ec:     	ldr	x25, [sp, #56]
1000ca6f0:     	ldrsb	w25, [x6, x25]
1000ca6f4:     	add	w22, w22, w23
1000ca6f8:     	add	w22, w22, w24
1000ca6fc:     	add	w22, w22, w25
1000ca700:     	ldr	x23, [sp, #48]
1000ca704:     	ldrsb	w23, [x20, x23]
1000ca708:     	add	w22, w22, w23
1000ca70c:     	scvtf	s1, w22
1000ca710:     	ldp	x23, x22, [sp, #32]
1000ca714:     	ldrsb	w22, [x5, x22]
1000ca718:     	ldrsb	w23, [x7, x23]
1000ca71c:     	ldr	x24, [sp, #24]
1000ca720:     	ldrsb	w24, [x19, x24]
1000ca724:     	add	w22, w22, w23
1000ca728:     	ldrsb	w23, [x21, x28]
1000ca72c:     	add	w22, w22, w24
1000ca730:     	ldrsb	w24, [x2, x30]
1000ca734:     	add	w22, w22, w23
1000ca738:     	ldrsb	w23, [x4, x8]
1000ca73c:     	add	w22, w22, w24
1000ca740:     	ldrsb	w24, [x6, x3]
1000ca744:     	add	w22, w22, w23
1000ca748:     	ldrsb	w23, [x20, x9]
1000ca74c:     	add	w22, w22, w24
1000ca750:     	add	w22, w22, w23
1000ca754:     	scvtf	s2, w22
1000ca758:     	ldrsb	w5, [x5, x1]
1000ca75c:     	ldrsb	w7, [x7, x10]
1000ca760:     	ldrsb	w19, [x19, x13]
1000ca764:     	add	w5, w5, w7
1000ca768:     	add	w5, w5, w19
1000ca76c:     	ldrsb	w7, [x21, x26]
1000ca770:     	ldrsb	w2, [x2, x14]
1000ca774:     	add	w5, w5, w7
1000ca778:     	add	w2, w5, w2
1000ca77c:     	ldrsb	w4, [x4, x15]
1000ca780:     	ldrsb	w5, [x6, x16]
1000ca784:     	add	w2, w2, w4
1000ca788:     	add	w2, w2, w5
1000ca78c:     	ldrsb	w4, [x20, x17]
1000ca790:     	add	w2, w2, w4
1000ca794:     	add	x4, sp, #176
1000ca798:     	scvtf	s3, w2
1000ca79c:     	add	x2, x27, x12
1000ca7a0:     	ldur	s4, [x2, #-64]
1000ca7a4:     	fadd	s1, s4, s1
1000ca7a8:     	stur	s1, [x2, #-64]
1000ca7ac:     	ldr	s1, [x2]
1000ca7b0:     	fadd	s1, s1, s2
1000ca7b4:     	str	s1, [x2]
1000ca7b8:     	ldr	s1, [x2, #64]
1000ca7bc:     	fadd	s1, s1, s3
1000ca7c0:     	ldr	s2, [x4, x12]
1000ca7c4:     	str	s1, [x2, #64]
1000ca7c8:     	fadd	s0, s2, s0
1000ca7cc:     	str	s0, [x4, x12]
1000ca7d0:     	add	x12, x12, #4
1000ca7d4:     	cmp	x12, #64
1000ca7d8:     	b.ne	0x1000ca600 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ca7dc:     	add	x0, x0, #64
1000ca7e0:     	ldp	x8, x1, [sp, #8]
1000ca7e4:     	add	x1, x1, #16
1000ca7e8:     	cmp	x1, x8
1000ca7ec:     	b.ne	0x1000ca530 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000ca7f0:     	ldp	q0, q1, [sp, #368]
1000ca7f4:     	ldr	x8, [sp]
1000ca7f8:     	stp	q0, q1, [x8, #192]
1000ca7fc:     	ldp	q0, q1, [sp, #400]
1000ca800:     	stp	q0, q1, [x8, #224]
1000ca804:     	ldp	q0, q1, [sp, #304]
1000ca808:     	stp	q0, q1, [x8, #128]
1000ca80c:     	ldp	q0, q1, [sp, #336]
1000ca810:     	stp	q0, q1, [x8, #160]
1000ca814:     	ldp	q0, q1, [sp, #240]
1000ca818:     	stp	q0, q1, [x8, #64]
1000ca81c:     	ldp	q0, q1, [sp, #272]
1000ca820:     	stp	q0, q1, [x8, #96]
1000ca824:     	ldp	q0, q1, [sp, #176]
1000ca828:     	stp	q0, q1, [x8]
1000ca82c:     	ldp	q0, q1, [sp, #208]
1000ca830:     	stp	q0, q1, [x8, #32]
1000ca834:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 8ul, false>(char const*)+0x24c>
1000ca838:     	ldr	x8, [x8, #392]
1000ca83c:     	ldr	x8, [x8]
1000ca840:     	ldur	x9, [x29, #-96]
1000ca844:     	cmp	x8, x9
1000ca848:     	b.ne	0x1000ca86c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000ca84c:     	add	sp, sp, #448
1000ca850:     	ldp	x29, x30, [sp, #80]
1000ca854:     	ldp	x20, x19, [sp, #64]
1000ca858:     	ldp	x22, x21, [sp, #48]
1000ca85c:     	ldp	x24, x23, [sp, #32]
1000ca860:     	ldp	x26, x25, [sp, #16]
1000ca864:     	ldp	x28, x27, [sp], #96
1000ca868:     	ret
1000ca86c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cc1c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cc1c4:     	stp	x28, x27, [sp, #-96]!
1000cc1c8:     	stp	x26, x25, [sp, #16]
1000cc1cc:     	stp	x24, x23, [sp, #32]
1000cc1d0:     	stp	x22, x21, [sp, #48]
1000cc1d4:     	stp	x20, x19, [sp, #64]
1000cc1d8:     	stp	x29, x30, [sp, #80]
1000cc1dc:     	add	x29, sp, #80
1000cc1e0:     	sub	sp, sp, #976
1000cc1e4:     	str	x3, [sp, #8]
1000cc1e8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a4>
1000cc1ec:     	ldr	x8, [x8, #392]
1000cc1f0:     	ldr	x8, [x8]
1000cc1f4:     	stur	x8, [x29, #-96]
1000cc1f8:     	movi.2d	v0, #0000000000000000
1000cc1fc:     	stp	q0, q0, [sp, #928]
1000cc200:     	lsl	x8, x2, #2
1000cc204:     	stp	q0, q0, [sp, #896]
1000cc208:     	stp	q0, q0, [sp, #864]
1000cc20c:     	stp	q0, q0, [sp, #832]
1000cc210:     	stp	q0, q0, [sp, #800]
1000cc214:     	stp	q0, q0, [sp, #768]
1000cc218:     	stp	q0, q0, [sp, #736]
1000cc21c:     	stp	q0, q0, [sp, #704]
1000cc220:     	stp	q0, q0, [sp, #672]
1000cc224:     	stp	q0, q0, [sp, #640]
1000cc228:     	stp	q0, q0, [sp, #608]
1000cc22c:     	stp	q0, q0, [sp, #576]
1000cc230:     	stp	q0, q0, [sp, #544]
1000cc234:     	stp	q0, q0, [sp, #512]
1000cc238:     	stp	q0, q0, [sp, #480]
1000cc23c:     	stp	q0, q0, [sp, #448]
1000cc240:     	ands	x8, x8, #0xfffffffffffffff8
1000cc244:     	b.eq	0x1000cc794 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cc248:     	add	x8, x1, x8
1000cc24c:     	str	x8, [sp, #16]
1000cc250:     	add	x8, sp, #448
1000cc254:     	add	x19, x8, #256
1000cc258:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000cc25c:     	add	x11, x11, #1212
1000cc260:     	mov	x12, #0
1000cc264:     	ldp	w8, w9, [x1]
1000cc268:     	ubfx	x10, x8, #8, #4
1000cc26c:     	str	x10, [sp, #440]
1000cc270:     	ubfx	x10, x8, #16, #4
1000cc274:     	str	x10, [sp, #432]
1000cc278:     	ubfx	x10, x8, #24, #4
1000cc27c:     	str	x10, [sp, #424]
1000cc280:     	ldp	w10, w13, [x1, #8]
1000cc284:     	and	x15, x8, #0xf
1000cc288:     	ubfx	x14, x8, #4, #4
1000cc28c:     	stp	x14, x15, [sp, #408]
1000cc290:     	ubfx	x15, x8, #12, #4
1000cc294:     	ubfx	x14, x8, #20, #4
1000cc298:     	stp	x14, x15, [sp, #392]
1000cc29c:     	lsr	x8, x8, #28
1000cc2a0:     	str	x8, [sp, #384]
1000cc2a4:     	and	x8, x9, #0xf
1000cc2a8:     	str	x8, [sp, #376]
1000cc2ac:     	ubfx	x8, x9, #8, #4
1000cc2b0:     	str	x8, [sp, #368]
1000cc2b4:     	ubfx	x8, x9, #16, #4
1000cc2b8:     	str	x8, [sp, #360]
1000cc2bc:     	ubfx	x8, x9, #24, #4
1000cc2c0:     	str	x8, [sp, #352]
1000cc2c4:     	ubfx	x8, x9, #4, #4
1000cc2c8:     	str	x8, [sp, #344]
1000cc2cc:     	ubfx	x8, x9, #12, #4
1000cc2d0:     	str	x8, [sp, #336]
1000cc2d4:     	ubfx	x8, x9, #20, #4
1000cc2d8:     	str	x8, [sp, #328]
1000cc2dc:     	lsr	x8, x9, #28
1000cc2e0:     	str	x8, [sp, #320]
1000cc2e4:     	and	x9, x10, #0xf
1000cc2e8:     	ubfx	x8, x10, #8, #4
1000cc2ec:     	stp	x8, x9, [sp, #304]
1000cc2f0:     	ubfx	x9, x10, #16, #4
1000cc2f4:     	ubfx	x8, x10, #24, #4
1000cc2f8:     	stp	x8, x9, [sp, #288]
1000cc2fc:     	ubfx	x9, x10, #4, #4
1000cc300:     	ubfx	x8, x10, #12, #4
1000cc304:     	stp	x8, x9, [sp, #272]
1000cc308:     	ubfx	x9, x10, #20, #4
1000cc30c:     	lsr	x8, x10, #28
1000cc310:     	stp	x8, x9, [sp, #256]
1000cc314:     	and	x9, x13, #0xf
1000cc318:     	ubfx	x8, x13, #8, #4
1000cc31c:     	stp	x8, x9, [sp, #240]
1000cc320:     	ubfx	x9, x13, #16, #4
1000cc324:     	ubfx	x8, x13, #24, #4
1000cc328:     	stp	x8, x9, [sp, #224]
1000cc32c:     	ubfx	x9, x13, #4, #4
1000cc330:     	ubfx	x8, x13, #12, #4
1000cc334:     	stp	x8, x9, [sp, #208]
1000cc338:     	ubfx	x9, x13, #20, #4
1000cc33c:     	lsr	x8, x13, #28
1000cc340:     	stp	x8, x9, [sp, #192]
1000cc344:     	ldp	w8, w9, [x1, #16]
1000cc348:     	and	x10, x8, #0xf
1000cc34c:     	str	x10, [sp, #184]
1000cc350:     	ubfx	x10, x8, #8, #4
1000cc354:     	str	x10, [sp, #176]
1000cc358:     	ubfx	x10, x8, #16, #4
1000cc35c:     	str	x10, [sp, #168]
1000cc360:     	ubfx	x10, x8, #24, #4
1000cc364:     	str	x10, [sp, #160]
1000cc368:     	ubfx	x10, x8, #4, #4
1000cc36c:     	str	x10, [sp, #152]
1000cc370:     	ubfx	x10, x8, #12, #4
1000cc374:     	str	x10, [sp, #144]
1000cc378:     	ubfx	x10, x8, #20, #4
1000cc37c:     	lsr	x8, x8, #28
1000cc380:     	stp	x8, x10, [sp, #128]
1000cc384:     	and	x10, x9, #0xf
1000cc388:     	ubfx	x8, x9, #8, #4
1000cc38c:     	stp	x8, x10, [sp, #112]
1000cc390:     	ubfx	x10, x9, #16, #4
1000cc394:     	ubfx	x8, x9, #24, #4
1000cc398:     	stp	x8, x10, [sp, #96]
1000cc39c:     	ubfx	x10, x9, #4, #4
1000cc3a0:     	ubfx	x8, x9, #12, #4
1000cc3a4:     	stp	x8, x10, [sp, #80]
1000cc3a8:     	ubfx	x10, x9, #20, #4
1000cc3ac:     	lsr	x8, x9, #28
1000cc3b0:     	stp	x8, x10, [sp, #64]
1000cc3b4:     	ldp	w14, w7, [x1, #24]
1000cc3b8:     	and	x9, x14, #0xf
1000cc3bc:     	ubfx	x8, x14, #8, #4
1000cc3c0:     	stp	x8, x9, [sp, #48]
1000cc3c4:     	ubfx	x8, x14, #16, #4
1000cc3c8:     	str	x8, [sp, #40]
1000cc3cc:     	ubfx	x8, x14, #24, #4
1000cc3d0:     	stp	x1, x8, [sp, #24]
1000cc3d4:     	ubfx	x10, x14, #4, #4
1000cc3d8:     	ubfx	x13, x14, #12, #4
1000cc3dc:     	ubfx	x9, x14, #20, #4
1000cc3e0:     	lsr	x14, x14, #28
1000cc3e4:     	and	x15, x7, #0xf
1000cc3e8:     	ubfx	x16, x7, #8, #4
1000cc3ec:     	ubfx	x17, x7, #16, #4
1000cc3f0:     	ubfx	x2, x7, #24, #4
1000cc3f4:     	ubfx	x4, x7, #4, #4
1000cc3f8:     	ubfx	x5, x7, #12, #4
1000cc3fc:     	ubfx	x6, x7, #20, #4
1000cc400:     	lsr	x7, x7, #28
1000cc404:     	ldr	w26, [x0, x12]
1000cc408:     	mov	x1, x19
1000cc40c:     	lsl	w19, w26, #4
1000cc410:     	and	x19, x19, #0xf0
1000cc414:     	add	x19, x11, x19
1000cc418:     	ldr	x8, [sp, #416]
1000cc41c:     	ldrb	w25, [x19, x8]
1000cc420:     	lsr	x20, x26, #4
1000cc424:     	and	x20, x20, #0xf0
1000cc428:     	add	x20, x11, x20
1000cc42c:     	ldr	x8, [sp, #440]
1000cc430:     	ldrb	w27, [x20, x8]
1000cc434:     	lsr	x21, x26, #12
1000cc438:     	and	x21, x21, #0xf0
1000cc43c:     	add	x21, x11, x21
1000cc440:     	ldr	x8, [sp, #432]
1000cc444:     	ldrb	w28, [x21, x8]
1000cc448:     	lsr	x22, x26, #20
1000cc44c:     	and	x22, x22, #0xf0
1000cc450:     	add	x23, x11, x22
1000cc454:     	ldr	x8, [sp, #424]
1000cc458:     	ldrb	w30, [x23, x8]
1000cc45c:     	and	x22, x26, #0xf0
1000cc460:     	add	x22, x11, x22
1000cc464:     	ldr	x8, [sp, #408]
1000cc468:     	ldrb	w3, [x22, x8]
1000cc46c:     	lsr	x24, x26, #8
1000cc470:     	and	x24, x24, #0xf0
1000cc474:     	add	x24, x11, x24
1000cc478:     	ldr	x8, [sp, #400]
1000cc47c:     	ldrb	w8, [x24, x8]
1000cc480:     	add	w27, w25, w27
1000cc484:     	lsr	x25, x26, #16
1000cc488:     	and	x25, x25, #0xf0
1000cc48c:     	add	x25, x11, x25
1000cc490:     	add	w27, w27, w28
1000cc494:     	ldr	x28, [sp, #392]
1000cc498:     	ldrb	w28, [x25, x28]
1000cc49c:     	lsr	x26, x26, #24
1000cc4a0:     	and	x26, x26, #0xf0
1000cc4a4:     	add	x26, x11, x26
1000cc4a8:     	add	w27, w27, w30
1000cc4ac:     	ldr	x30, [sp, #384]
1000cc4b0:     	ldrb	w30, [x26, x30]
1000cc4b4:     	add	w3, w27, w3
1000cc4b8:     	add	w8, w3, w8
1000cc4bc:     	add	w8, w8, w28
1000cc4c0:     	add	w8, w8, w30
1000cc4c4:     	scvtf	s0, w8
1000cc4c8:     	ldp	x3, x8, [sp, #368]
1000cc4cc:     	ldrb	w8, [x19, x8]
1000cc4d0:     	ldrb	w3, [x20, x3]
1000cc4d4:     	ldp	x28, x27, [sp, #352]
1000cc4d8:     	ldrb	w27, [x21, x27]
1000cc4dc:     	ldrb	w28, [x23, x28]
1000cc4e0:     	ldr	x30, [sp, #344]
1000cc4e4:     	ldrb	w30, [x22, x30]
1000cc4e8:     	add	w8, w8, w3
1000cc4ec:     	ldr	x3, [sp, #336]
1000cc4f0:     	ldrb	w3, [x24, x3]
1000cc4f4:     	add	w8, w8, w27
1000cc4f8:     	ldr	x27, [sp, #328]
1000cc4fc:     	ldrb	w27, [x25, x27]
1000cc500:     	add	w8, w8, w28
1000cc504:     	ldr	x28, [sp, #320]
1000cc508:     	ldrb	w28, [x26, x28]
1000cc50c:     	add	w8, w8, w30
1000cc510:     	add	w8, w8, w3
1000cc514:     	add	w8, w8, w27
1000cc518:     	add	w8, w8, w28
1000cc51c:     	scvtf	s1, w8
1000cc520:     	ldp	x3, x8, [sp, #304]
1000cc524:     	ldrb	w8, [x19, x8]
1000cc528:     	ldrb	w3, [x20, x3]
1000cc52c:     	ldp	x28, x27, [sp, #288]
1000cc530:     	ldrb	w27, [x21, x27]
1000cc534:     	ldrb	w28, [x23, x28]
1000cc538:     	add	w8, w8, w3
1000cc53c:     	ldr	x3, [sp, #280]
1000cc540:     	ldrb	w3, [x22, x3]
1000cc544:     	add	w8, w8, w27
1000cc548:     	ldr	x27, [sp, #272]
1000cc54c:     	ldrb	w27, [x24, x27]
1000cc550:     	add	w8, w8, w28
1000cc554:     	ldr	x28, [sp, #264]
1000cc558:     	ldrb	w28, [x25, x28]
1000cc55c:     	add	w8, w8, w3
1000cc560:     	ldr	x3, [sp, #256]
1000cc564:     	ldrb	w3, [x26, x3]
1000cc568:     	add	w8, w8, w27
1000cc56c:     	add	w8, w8, w28
1000cc570:     	add	w8, w8, w3
1000cc574:     	scvtf	s2, w8
1000cc578:     	ldp	x3, x8, [sp, #240]
1000cc57c:     	ldrb	w8, [x19, x8]
1000cc580:     	ldrb	w3, [x20, x3]
1000cc584:     	ldp	x28, x27, [sp, #224]
1000cc588:     	ldrb	w27, [x21, x27]
1000cc58c:     	ldrb	w28, [x23, x28]
1000cc590:     	add	w8, w8, w3
1000cc594:     	ldr	x3, [sp, #216]
1000cc598:     	ldrb	w3, [x22, x3]
1000cc59c:     	add	w8, w8, w27
1000cc5a0:     	ldr	x27, [sp, #208]
1000cc5a4:     	ldrb	w27, [x24, x27]
1000cc5a8:     	add	w8, w8, w28
1000cc5ac:     	ldr	x28, [sp, #200]
1000cc5b0:     	ldrb	w28, [x25, x28]
1000cc5b4:     	add	w8, w8, w3
1000cc5b8:     	ldr	x3, [sp, #192]
1000cc5bc:     	ldrb	w3, [x26, x3]
1000cc5c0:     	add	w8, w8, w27
1000cc5c4:     	add	w8, w8, w28
1000cc5c8:     	add	w8, w8, w3
1000cc5cc:     	scvtf	s3, w8
1000cc5d0:     	ldp	x3, x8, [sp, #176]
1000cc5d4:     	ldrb	w8, [x19, x8]
1000cc5d8:     	ldrb	w3, [x20, x3]
1000cc5dc:     	ldp	x28, x27, [sp, #160]
1000cc5e0:     	ldrb	w27, [x21, x27]
1000cc5e4:     	ldrb	w28, [x23, x28]
1000cc5e8:     	add	w8, w8, w3
1000cc5ec:     	add	w8, w8, w27
1000cc5f0:     	ldr	x3, [sp, #152]
1000cc5f4:     	ldrb	w3, [x22, x3]
1000cc5f8:     	add	w8, w8, w28
1000cc5fc:     	add	w8, w8, w3
1000cc600:     	ldp	x27, x3, [sp, #136]
1000cc604:     	ldrb	w3, [x24, x3]
1000cc608:     	ldrb	w27, [x25, x27]
1000cc60c:     	add	w8, w8, w3
1000cc610:     	add	w8, w8, w27
1000cc614:     	ldr	x3, [sp, #128]
1000cc618:     	ldrb	w3, [x26, x3]
1000cc61c:     	add	w8, w8, w3
1000cc620:     	scvtf	s4, w8
1000cc624:     	ldp	x3, x8, [sp, #112]
1000cc628:     	ldrb	w8, [x19, x8]
1000cc62c:     	ldrb	w3, [x20, x3]
1000cc630:     	ldp	x28, x27, [sp, #96]
1000cc634:     	ldrb	w27, [x21, x27]
1000cc638:     	ldrb	w28, [x23, x28]
1000cc63c:     	add	w8, w8, w3
1000cc640:     	ldr	x3, [sp, #88]
1000cc644:     	ldrb	w3, [x22, x3]
1000cc648:     	add	w8, w8, w27
1000cc64c:     	ldr	x27, [sp, #80]
1000cc650:     	ldrb	w27, [x24, x27]
1000cc654:     	add	w8, w8, w28
1000cc658:     	ldr	x28, [sp, #72]
1000cc65c:     	ldrb	w28, [x25, x28]
1000cc660:     	add	w8, w8, w3
1000cc664:     	add	w8, w8, w27
1000cc668:     	add	w8, w8, w28
1000cc66c:     	ldr	x3, [sp, #64]
1000cc670:     	ldrb	w3, [x26, x3]
1000cc674:     	add	w8, w8, w3
1000cc678:     	scvtf	s5, w8
1000cc67c:     	ldp	x3, x8, [sp, #48]
1000cc680:     	ldrb	w8, [x19, x8]
1000cc684:     	ldrb	w3, [x20, x3]
1000cc688:     	ldr	x27, [sp, #40]
1000cc68c:     	ldrb	w27, [x21, x27]
1000cc690:     	add	w8, w8, w3
1000cc694:     	ldr	x3, [sp, #32]
1000cc698:     	ldrb	w3, [x23, x3]
1000cc69c:     	add	w8, w8, w27
1000cc6a0:     	ldrb	w27, [x22, x10]
1000cc6a4:     	add	w8, w8, w3
1000cc6a8:     	ldrb	w3, [x24, x13]
1000cc6ac:     	add	w8, w8, w27
1000cc6b0:     	ldrb	w27, [x25, x9]
1000cc6b4:     	add	w8, w8, w3
1000cc6b8:     	ldrb	w3, [x26, x14]
1000cc6bc:     	add	w8, w8, w27
1000cc6c0:     	add	w8, w8, w3
1000cc6c4:     	scvtf	s6, w8
1000cc6c8:     	ldrb	w8, [x19, x15]
1000cc6cc:     	ldrb	w3, [x20, x16]
1000cc6d0:     	ldrb	w19, [x21, x17]
1000cc6d4:     	add	w8, w8, w3
1000cc6d8:     	add	w8, w8, w19
1000cc6dc:     	ldrb	w3, [x23, x2]
1000cc6e0:     	ldrb	w19, [x22, x4]
1000cc6e4:     	add	w8, w8, w3
1000cc6e8:     	add	w8, w8, w19
1000cc6ec:     	ldrb	w3, [x24, x5]
1000cc6f0:     	ldrb	w19, [x25, x6]
1000cc6f4:     	add	w8, w8, w3
1000cc6f8:     	add	w8, w8, w19
1000cc6fc:     	mov	x19, x1
1000cc700:     	ldrb	w3, [x26, x7]
1000cc704:     	add	w8, w8, w3
1000cc708:     	add	x3, sp, #448
1000cc70c:     	scvtf	s7, w8
1000cc710:     	add	x8, x1, x12
1000cc714:     	ldur	s16, [x8, #-192]
1000cc718:     	fadd	s1, s16, s1
1000cc71c:     	stur	s1, [x8, #-192]
1000cc720:     	ldur	s1, [x8, #-128]
1000cc724:     	fadd	s1, s1, s2
1000cc728:     	stur	s1, [x8, #-128]
1000cc72c:     	ldur	s1, [x8, #-64]
1000cc730:     	fadd	s1, s1, s3
1000cc734:     	stur	s1, [x8, #-64]
1000cc738:     	ldr	s1, [x8]
1000cc73c:     	fadd	s1, s1, s4
1000cc740:     	str	s1, [x8]
1000cc744:     	ldr	s1, [x8, #64]
1000cc748:     	fadd	s1, s1, s5
1000cc74c:     	str	s1, [x8, #64]
1000cc750:     	ldr	s1, [x8, #128]
1000cc754:     	fadd	s1, s1, s6
1000cc758:     	str	s1, [x8, #128]
1000cc75c:     	ldr	s1, [x8, #192]
1000cc760:     	fadd	s1, s1, s7
1000cc764:     	ldr	s2, [x3, x12]
1000cc768:     	str	s1, [x8, #192]
1000cc76c:     	fadd	s0, s2, s0
1000cc770:     	str	s0, [x3, x12]
1000cc774:     	add	x12, x12, #4
1000cc778:     	cmp	x12, #64
1000cc77c:     	b.ne	0x1000cc404 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000cc780:     	add	x0, x0, #64
1000cc784:     	ldp	x8, x1, [sp, #16]
1000cc788:     	add	x1, x1, #32
1000cc78c:     	cmp	x1, x8
1000cc790:     	b.ne	0x1000cc260 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000cc794:     	add	x1, sp, #448
1000cc798:     	ldr	x0, [sp, #8]
1000cc79c:     	mov	w2, #512
1000cc7a0:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000cc7a4:     	ldur	x8, [x29, #-96]
1000cc7a8:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x98>
1000cc7ac:     	ldr	x9, [x9, #392]
1000cc7b0:     	ldr	x9, [x9]
1000cc7b4:     	cmp	x9, x8
1000cc7b8:     	b.ne	0x1000cc7dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000cc7bc:     	add	sp, sp, #976
1000cc7c0:     	ldp	x29, x30, [sp, #80]
1000cc7c4:     	ldp	x20, x19, [sp, #64]
1000cc7c8:     	ldp	x22, x21, [sp, #48]
1000cc7cc:     	ldp	x24, x23, [sp, #32]
1000cc7d0:     	ldp	x26, x25, [sp, #16]
1000cc7d4:     	ldp	x28, x27, [sp], #96
1000cc7d8:     	ret
1000cc7dc:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cc990 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cc990:     	stp	x28, x27, [sp, #-96]!
1000cc994:     	stp	x26, x25, [sp, #16]
1000cc998:     	stp	x24, x23, [sp, #32]
1000cc99c:     	stp	x22, x21, [sp, #48]
1000cc9a0:     	stp	x20, x19, [sp, #64]
1000cc9a4:     	stp	x29, x30, [sp, #80]
1000cc9a8:     	add	x29, sp, #80
1000cc9ac:     	sub	sp, sp, #976
1000cc9b0:     	str	x3, [sp, #8]
1000cc9b4:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a4>
1000cc9b8:     	ldr	x8, [x8, #392]
1000cc9bc:     	ldr	x8, [x8]
1000cc9c0:     	stur	x8, [x29, #-96]
1000cc9c4:     	movi.2d	v0, #0000000000000000
1000cc9c8:     	stp	q0, q0, [sp, #928]
1000cc9cc:     	lsl	x8, x2, #2
1000cc9d0:     	stp	q0, q0, [sp, #896]
1000cc9d4:     	stp	q0, q0, [sp, #864]
1000cc9d8:     	stp	q0, q0, [sp, #832]
1000cc9dc:     	stp	q0, q0, [sp, #800]
1000cc9e0:     	stp	q0, q0, [sp, #768]
1000cc9e4:     	stp	q0, q0, [sp, #736]
1000cc9e8:     	stp	q0, q0, [sp, #704]
1000cc9ec:     	stp	q0, q0, [sp, #672]
1000cc9f0:     	stp	q0, q0, [sp, #640]
1000cc9f4:     	stp	q0, q0, [sp, #608]
1000cc9f8:     	stp	q0, q0, [sp, #576]
1000cc9fc:     	stp	q0, q0, [sp, #544]
1000cca00:     	stp	q0, q0, [sp, #512]
1000cca04:     	stp	q0, q0, [sp, #480]
1000cca08:     	stp	q0, q0, [sp, #448]
1000cca0c:     	ands	x8, x8, #0xfffffffffffffff8
1000cca10:     	b.eq	0x1000ccf60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cca14:     	add	x8, x1, x8
1000cca18:     	str	x8, [sp, #16]
1000cca1c:     	add	x8, sp, #448
1000cca20:     	add	x19, x8, #256
1000cca24:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000cca28:     	add	x11, x11, #1468
1000cca2c:     	mov	x12, #0
1000cca30:     	ldp	w8, w9, [x1]
1000cca34:     	ubfx	x10, x8, #8, #4
1000cca38:     	str	x10, [sp, #440]
1000cca3c:     	ubfx	x10, x8, #16, #4
1000cca40:     	str	x10, [sp, #432]
1000cca44:     	ubfx	x10, x8, #24, #4
1000cca48:     	str	x10, [sp, #424]
1000cca4c:     	ldp	w10, w13, [x1, #8]
1000cca50:     	and	x15, x8, #0xf
1000cca54:     	ubfx	x14, x8, #4, #4
1000cca58:     	stp	x14, x15, [sp, #408]
1000cca5c:     	ubfx	x15, x8, #12, #4
1000cca60:     	ubfx	x14, x8, #20, #4
1000cca64:     	stp	x14, x15, [sp, #392]
1000cca68:     	lsr	x8, x8, #28
1000cca6c:     	str	x8, [sp, #384]
1000cca70:     	and	x8, x9, #0xf
1000cca74:     	str	x8, [sp, #376]
1000cca78:     	ubfx	x8, x9, #8, #4
1000cca7c:     	str	x8, [sp, #368]
1000cca80:     	ubfx	x8, x9, #16, #4
1000cca84:     	str	x8, [sp, #360]
1000cca88:     	ubfx	x8, x9, #24, #4
1000cca8c:     	str	x8, [sp, #352]
1000cca90:     	ubfx	x8, x9, #4, #4
1000cca94:     	str	x8, [sp, #344]
1000cca98:     	ubfx	x8, x9, #12, #4
1000cca9c:     	str	x8, [sp, #336]
1000ccaa0:     	ubfx	x8, x9, #20, #4
1000ccaa4:     	str	x8, [sp, #328]
1000ccaa8:     	lsr	x8, x9, #28
1000ccaac:     	str	x8, [sp, #320]
1000ccab0:     	and	x9, x10, #0xf
1000ccab4:     	ubfx	x8, x10, #8, #4
1000ccab8:     	stp	x8, x9, [sp, #304]
1000ccabc:     	ubfx	x9, x10, #16, #4
1000ccac0:     	ubfx	x8, x10, #24, #4
1000ccac4:     	stp	x8, x9, [sp, #288]
1000ccac8:     	ubfx	x9, x10, #4, #4
1000ccacc:     	ubfx	x8, x10, #12, #4
1000ccad0:     	stp	x8, x9, [sp, #272]
1000ccad4:     	ubfx	x9, x10, #20, #4
1000ccad8:     	lsr	x8, x10, #28
1000ccadc:     	stp	x8, x9, [sp, #256]
1000ccae0:     	and	x9, x13, #0xf
1000ccae4:     	ubfx	x8, x13, #8, #4
1000ccae8:     	stp	x8, x9, [sp, #240]
1000ccaec:     	ubfx	x9, x13, #16, #4
1000ccaf0:     	ubfx	x8, x13, #24, #4
1000ccaf4:     	stp	x8, x9, [sp, #224]
1000ccaf8:     	ubfx	x9, x13, #4, #4
1000ccafc:     	ubfx	x8, x13, #12, #4
1000ccb00:     	stp	x8, x9, [sp, #208]
1000ccb04:     	ubfx	x9, x13, #20, #4
1000ccb08:     	lsr	x8, x13, #28
1000ccb0c:     	stp	x8, x9, [sp, #192]
1000ccb10:     	ldp	w8, w9, [x1, #16]
1000ccb14:     	and	x10, x8, #0xf
1000ccb18:     	str	x10, [sp, #184]
1000ccb1c:     	ubfx	x10, x8, #8, #4
1000ccb20:     	str	x10, [sp, #176]
1000ccb24:     	ubfx	x10, x8, #16, #4
1000ccb28:     	str	x10, [sp, #168]
1000ccb2c:     	ubfx	x10, x8, #24, #4
1000ccb30:     	str	x10, [sp, #160]
1000ccb34:     	ubfx	x10, x8, #4, #4
1000ccb38:     	str	x10, [sp, #152]
1000ccb3c:     	ubfx	x10, x8, #12, #4
1000ccb40:     	str	x10, [sp, #144]
1000ccb44:     	ubfx	x10, x8, #20, #4
1000ccb48:     	lsr	x8, x8, #28
1000ccb4c:     	stp	x8, x10, [sp, #128]
1000ccb50:     	and	x10, x9, #0xf
1000ccb54:     	ubfx	x8, x9, #8, #4
1000ccb58:     	stp	x8, x10, [sp, #112]
1000ccb5c:     	ubfx	x10, x9, #16, #4
1000ccb60:     	ubfx	x8, x9, #24, #4
1000ccb64:     	stp	x8, x10, [sp, #96]
1000ccb68:     	ubfx	x10, x9, #4, #4
1000ccb6c:     	ubfx	x8, x9, #12, #4
1000ccb70:     	stp	x8, x10, [sp, #80]
1000ccb74:     	ubfx	x10, x9, #20, #4
1000ccb78:     	lsr	x8, x9, #28
1000ccb7c:     	stp	x8, x10, [sp, #64]
1000ccb80:     	ldp	w14, w7, [x1, #24]
1000ccb84:     	and	x9, x14, #0xf
1000ccb88:     	ubfx	x8, x14, #8, #4
1000ccb8c:     	stp	x8, x9, [sp, #48]
1000ccb90:     	ubfx	x8, x14, #16, #4
1000ccb94:     	str	x8, [sp, #40]
1000ccb98:     	ubfx	x8, x14, #24, #4
1000ccb9c:     	stp	x1, x8, [sp, #24]
1000ccba0:     	ubfx	x10, x14, #4, #4
1000ccba4:     	ubfx	x13, x14, #12, #4
1000ccba8:     	ubfx	x9, x14, #20, #4
1000ccbac:     	lsr	x14, x14, #28
1000ccbb0:     	and	x15, x7, #0xf
1000ccbb4:     	ubfx	x16, x7, #8, #4
1000ccbb8:     	ubfx	x17, x7, #16, #4
1000ccbbc:     	ubfx	x2, x7, #24, #4
1000ccbc0:     	ubfx	x4, x7, #4, #4
1000ccbc4:     	ubfx	x5, x7, #12, #4
1000ccbc8:     	ubfx	x6, x7, #20, #4
1000ccbcc:     	lsr	x7, x7, #28
1000ccbd0:     	ldr	w26, [x0, x12]
1000ccbd4:     	mov	x1, x19
1000ccbd8:     	lsl	w19, w26, #4
1000ccbdc:     	and	x19, x19, #0xf0
1000ccbe0:     	add	x19, x11, x19
1000ccbe4:     	ldr	x8, [sp, #416]
1000ccbe8:     	ldrsb	w25, [x19, x8]
1000ccbec:     	lsr	x20, x26, #4
1000ccbf0:     	and	x20, x20, #0xf0
1000ccbf4:     	add	x20, x11, x20
1000ccbf8:     	ldr	x8, [sp, #440]
1000ccbfc:     	ldrsb	w27, [x20, x8]
1000ccc00:     	lsr	x21, x26, #12
1000ccc04:     	and	x21, x21, #0xf0
1000ccc08:     	add	x21, x11, x21
1000ccc0c:     	ldr	x8, [sp, #432]
1000ccc10:     	ldrsb	w28, [x21, x8]
1000ccc14:     	lsr	x22, x26, #20
1000ccc18:     	and	x22, x22, #0xf0
1000ccc1c:     	add	x23, x11, x22
1000ccc20:     	ldr	x8, [sp, #424]
1000ccc24:     	ldrsb	w30, [x23, x8]
1000ccc28:     	and	x22, x26, #0xf0
1000ccc2c:     	add	x22, x11, x22
1000ccc30:     	ldr	x8, [sp, #408]
1000ccc34:     	ldrsb	w3, [x22, x8]
1000ccc38:     	lsr	x24, x26, #8
1000ccc3c:     	and	x24, x24, #0xf0
1000ccc40:     	add	x24, x11, x24
1000ccc44:     	ldr	x8, [sp, #400]
1000ccc48:     	ldrsb	w8, [x24, x8]
1000ccc4c:     	add	w27, w25, w27
1000ccc50:     	lsr	x25, x26, #16
1000ccc54:     	and	x25, x25, #0xf0
1000ccc58:     	add	x25, x11, x25
1000ccc5c:     	add	w27, w27, w28
1000ccc60:     	ldr	x28, [sp, #392]
1000ccc64:     	ldrsb	w28, [x25, x28]
1000ccc68:     	lsr	x26, x26, #24
1000ccc6c:     	and	x26, x26, #0xf0
1000ccc70:     	add	x26, x11, x26
1000ccc74:     	add	w27, w27, w30
1000ccc78:     	ldr	x30, [sp, #384]
1000ccc7c:     	ldrsb	w30, [x26, x30]
1000ccc80:     	add	w3, w27, w3
1000ccc84:     	add	w8, w3, w8
1000ccc88:     	add	w8, w8, w28
1000ccc8c:     	add	w8, w8, w30
1000ccc90:     	scvtf	s0, w8
1000ccc94:     	ldp	x3, x8, [sp, #368]
1000ccc98:     	ldrsb	w8, [x19, x8]
1000ccc9c:     	ldrsb	w3, [x20, x3]
1000ccca0:     	ldp	x28, x27, [sp, #352]
1000ccca4:     	ldrsb	w27, [x21, x27]
1000ccca8:     	ldrsb	w28, [x23, x28]
1000cccac:     	ldr	x30, [sp, #344]
1000cccb0:     	ldrsb	w30, [x22, x30]
1000cccb4:     	add	w8, w8, w3
1000cccb8:     	ldr	x3, [sp, #336]
1000cccbc:     	ldrsb	w3, [x24, x3]
1000cccc0:     	add	w8, w8, w27
1000cccc4:     	ldr	x27, [sp, #328]
1000cccc8:     	ldrsb	w27, [x25, x27]
1000ccccc:     	add	w8, w8, w28
1000cccd0:     	ldr	x28, [sp, #320]
1000cccd4:     	ldrsb	w28, [x26, x28]
1000cccd8:     	add	w8, w8, w30
1000cccdc:     	add	w8, w8, w3
1000ccce0:     	add	w8, w8, w27
1000ccce4:     	add	w8, w8, w28
1000ccce8:     	scvtf	s1, w8
1000cccec:     	ldp	x3, x8, [sp, #304]
1000cccf0:     	ldrsb	w8, [x19, x8]
1000cccf4:     	ldrsb	w3, [x20, x3]
1000cccf8:     	ldp	x28, x27, [sp, #288]
1000cccfc:     	ldrsb	w27, [x21, x27]
1000ccd00:     	ldrsb	w28, [x23, x28]
1000ccd04:     	add	w8, w8, w3
1000ccd08:     	ldr	x3, [sp, #280]
1000ccd0c:     	ldrsb	w3, [x22, x3]
1000ccd10:     	add	w8, w8, w27
1000ccd14:     	ldr	x27, [sp, #272]
1000ccd18:     	ldrsb	w27, [x24, x27]
1000ccd1c:     	add	w8, w8, w28
1000ccd20:     	ldr	x28, [sp, #264]
1000ccd24:     	ldrsb	w28, [x25, x28]
1000ccd28:     	add	w8, w8, w3
1000ccd2c:     	ldr	x3, [sp, #256]
1000ccd30:     	ldrsb	w3, [x26, x3]
1000ccd34:     	add	w8, w8, w27
1000ccd38:     	add	w8, w8, w28
1000ccd3c:     	add	w8, w8, w3
1000ccd40:     	scvtf	s2, w8
1000ccd44:     	ldp	x3, x8, [sp, #240]
1000ccd48:     	ldrsb	w8, [x19, x8]
1000ccd4c:     	ldrsb	w3, [x20, x3]
1000ccd50:     	ldp	x28, x27, [sp, #224]
1000ccd54:     	ldrsb	w27, [x21, x27]
1000ccd58:     	ldrsb	w28, [x23, x28]
1000ccd5c:     	add	w8, w8, w3
1000ccd60:     	ldr	x3, [sp, #216]
1000ccd64:     	ldrsb	w3, [x22, x3]
1000ccd68:     	add	w8, w8, w27
1000ccd6c:     	ldr	x27, [sp, #208]
1000ccd70:     	ldrsb	w27, [x24, x27]
1000ccd74:     	add	w8, w8, w28
1000ccd78:     	ldr	x28, [sp, #200]
1000ccd7c:     	ldrsb	w28, [x25, x28]
1000ccd80:     	add	w8, w8, w3
1000ccd84:     	ldr	x3, [sp, #192]
1000ccd88:     	ldrsb	w3, [x26, x3]
1000ccd8c:     	add	w8, w8, w27
1000ccd90:     	add	w8, w8, w28
1000ccd94:     	add	w8, w8, w3
1000ccd98:     	scvtf	s3, w8
1000ccd9c:     	ldp	x3, x8, [sp, #176]
1000ccda0:     	ldrsb	w8, [x19, x8]
1000ccda4:     	ldrsb	w3, [x20, x3]
1000ccda8:     	ldp	x28, x27, [sp, #160]
1000ccdac:     	ldrsb	w27, [x21, x27]
1000ccdb0:     	ldrsb	w28, [x23, x28]
1000ccdb4:     	add	w8, w8, w3
1000ccdb8:     	add	w8, w8, w27
1000ccdbc:     	ldr	x3, [sp, #152]
1000ccdc0:     	ldrsb	w3, [x22, x3]
1000ccdc4:     	add	w8, w8, w28
1000ccdc8:     	add	w8, w8, w3
1000ccdcc:     	ldp	x27, x3, [sp, #136]
1000ccdd0:     	ldrsb	w3, [x24, x3]
1000ccdd4:     	ldrsb	w27, [x25, x27]
1000ccdd8:     	add	w8, w8, w3
1000ccddc:     	add	w8, w8, w27
1000ccde0:     	ldr	x3, [sp, #128]
1000ccde4:     	ldrsb	w3, [x26, x3]
1000ccde8:     	add	w8, w8, w3
1000ccdec:     	scvtf	s4, w8
1000ccdf0:     	ldp	x3, x8, [sp, #112]
1000ccdf4:     	ldrsb	w8, [x19, x8]
1000ccdf8:     	ldrsb	w3, [x20, x3]
1000ccdfc:     	ldp	x28, x27, [sp, #96]
1000cce00:     	ldrsb	w27, [x21, x27]
1000cce04:     	ldrsb	w28, [x23, x28]
1000cce08:     	add	w8, w8, w3
1000cce0c:     	ldr	x3, [sp, #88]
1000cce10:     	ldrsb	w3, [x22, x3]
1000cce14:     	add	w8, w8, w27
1000cce18:     	ldr	x27, [sp, #80]
1000cce1c:     	ldrsb	w27, [x24, x27]
1000cce20:     	add	w8, w8, w28
1000cce24:     	ldr	x28, [sp, #72]
1000cce28:     	ldrsb	w28, [x25, x28]
1000cce2c:     	add	w8, w8, w3
1000cce30:     	add	w8, w8, w27
1000cce34:     	add	w8, w8, w28
1000cce38:     	ldr	x3, [sp, #64]
1000cce3c:     	ldrsb	w3, [x26, x3]
1000cce40:     	add	w8, w8, w3
1000cce44:     	scvtf	s5, w8
1000cce48:     	ldp	x3, x8, [sp, #48]
1000cce4c:     	ldrsb	w8, [x19, x8]
1000cce50:     	ldrsb	w3, [x20, x3]
1000cce54:     	ldr	x27, [sp, #40]
1000cce58:     	ldrsb	w27, [x21, x27]
1000cce5c:     	add	w8, w8, w3
1000cce60:     	ldr	x3, [sp, #32]
1000cce64:     	ldrsb	w3, [x23, x3]
1000cce68:     	add	w8, w8, w27
1000cce6c:     	ldrsb	w27, [x22, x10]
1000cce70:     	add	w8, w8, w3
1000cce74:     	ldrsb	w3, [x24, x13]
1000cce78:     	add	w8, w8, w27
1000cce7c:     	ldrsb	w27, [x25, x9]
1000cce80:     	add	w8, w8, w3
1000cce84:     	ldrsb	w3, [x26, x14]
1000cce88:     	add	w8, w8, w27
1000cce8c:     	add	w8, w8, w3
1000cce90:     	scvtf	s6, w8
1000cce94:     	ldrsb	w8, [x19, x15]
1000cce98:     	ldrsb	w3, [x20, x16]
1000cce9c:     	ldrsb	w19, [x21, x17]
1000ccea0:     	add	w8, w8, w3
1000ccea4:     	add	w8, w8, w19
1000ccea8:     	ldrsb	w3, [x23, x2]
1000cceac:     	ldrsb	w19, [x22, x4]
1000cceb0:     	add	w8, w8, w3
1000cceb4:     	add	w8, w8, w19
1000cceb8:     	ldrsb	w3, [x24, x5]
1000ccebc:     	ldrsb	w19, [x25, x6]
1000ccec0:     	add	w8, w8, w3
1000ccec4:     	add	w8, w8, w19
1000ccec8:     	mov	x19, x1
1000ccecc:     	ldrsb	w3, [x26, x7]
1000cced0:     	add	w8, w8, w3
1000cced4:     	add	x3, sp, #448
1000cced8:     	scvtf	s7, w8
1000ccedc:     	add	x8, x1, x12
1000ccee0:     	ldur	s16, [x8, #-192]
1000ccee4:     	fadd	s1, s16, s1
1000ccee8:     	stur	s1, [x8, #-192]
1000cceec:     	ldur	s1, [x8, #-128]
1000ccef0:     	fadd	s1, s1, s2
1000ccef4:     	stur	s1, [x8, #-128]
1000ccef8:     	ldur	s1, [x8, #-64]
1000ccefc:     	fadd	s1, s1, s3
1000ccf00:     	stur	s1, [x8, #-64]
1000ccf04:     	ldr	s1, [x8]
1000ccf08:     	fadd	s1, s1, s4
1000ccf0c:     	str	s1, [x8]
1000ccf10:     	ldr	s1, [x8, #64]
1000ccf14:     	fadd	s1, s1, s5
1000ccf18:     	str	s1, [x8, #64]
1000ccf1c:     	ldr	s1, [x8, #128]
1000ccf20:     	fadd	s1, s1, s6
1000ccf24:     	str	s1, [x8, #128]
1000ccf28:     	ldr	s1, [x8, #192]
1000ccf2c:     	fadd	s1, s1, s7
1000ccf30:     	ldr	s2, [x3, x12]
1000ccf34:     	str	s1, [x8, #192]
1000ccf38:     	fadd	s0, s2, s0
1000ccf3c:     	str	s0, [x3, x12]
1000ccf40:     	add	x12, x12, #4
1000ccf44:     	cmp	x12, #64
1000ccf48:     	b.ne	0x1000ccbd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000ccf4c:     	add	x0, x0, #64
1000ccf50:     	ldp	x8, x1, [sp, #16]
1000ccf54:     	add	x1, x1, #32
1000ccf58:     	cmp	x1, x8
1000ccf5c:     	b.ne	0x1000cca2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000ccf60:     	add	x1, sp, #448
1000ccf64:     	ldr	x0, [sp, #8]
1000ccf68:     	mov	w2, #512
1000ccf6c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ccf70:     	ldur	x8, [x29, #-96]
1000ccf74:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x248>
1000ccf78:     	ldr	x9, [x9, #392]
1000ccf7c:     	ldr	x9, [x9]
1000ccf80:     	cmp	x9, x8
1000ccf84:     	b.ne	0x1000ccfa8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000ccf88:     	add	sp, sp, #976
1000ccf8c:     	ldp	x29, x30, [sp, #80]
1000ccf90:     	ldp	x20, x19, [sp, #64]
1000ccf94:     	ldp	x22, x21, [sp, #48]
1000ccf98:     	ldp	x24, x23, [sp, #32]
1000ccf9c:     	ldp	x26, x25, [sp, #16]
1000ccfa0:     	ldp	x28, x27, [sp], #96
1000ccfa4:     	ret
1000ccfa8:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000ce228 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce228:     	stp	x28, x27, [sp, #-80]!
1000ce22c:     	stp	x24, x23, [sp, #16]
1000ce230:     	stp	x22, x21, [sp, #32]
1000ce234:     	stp	x20, x19, [sp, #48]
1000ce238:     	stp	x29, x30, [sp, #64]
1000ce23c:     	add	x29, sp, #64
1000ce240:     	sub	sp, sp, #1168
1000ce244:     	mov	x19, x3
1000ce248:     	mov	x20, x1
1000ce24c:     	mov	x21, x0
1000ce250:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000ce254:     	ldr	x8, [x8, #392]
1000ce258:     	ldr	x8, [x8]
1000ce25c:     	stur	x8, [x29, #-72]
1000ce260:     	lsl	x8, x2, #3
1000ce264:     	and	x22, x8, #0xfffffffffffffff0
1000ce268:     	add	x0, sp, #136
1000ce26c:     	mov	w1, #1024
1000ce270:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000ce274:     	cbz	x22, 0x1000ce478 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000ce278:     	add	x8, x20, x22
1000ce27c:     	mov	w9, #252645135
1000ce280:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000ce284:     	add	x10, x10, #1212
1000ce288:     	add	x11, sp, #8
1000ce28c:     	mov	x12, #0
1000ce290:     	ldp	w13, w14, [x20]
1000ce294:     	and	w15, w13, w9
1000ce298:     	and	w13, w9, w13, lsr #4
1000ce29c:     	stp	w15, w13, [sp, #8]
1000ce2a0:     	and	w13, w14, w9
1000ce2a4:     	and	w14, w9, w14, lsr #4
1000ce2a8:     	stp	w13, w14, [sp, #16]
1000ce2ac:     	ldp	w13, w14, [x20, #8]
1000ce2b0:     	and	w15, w13, w9
1000ce2b4:     	and	w13, w9, w13, lsr #4
1000ce2b8:     	stp	w15, w13, [sp, #24]
1000ce2bc:     	and	w13, w14, w9
1000ce2c0:     	and	w14, w9, w14, lsr #4
1000ce2c4:     	stp	w13, w14, [sp, #32]
1000ce2c8:     	ldp	w13, w14, [x20, #16]
1000ce2cc:     	and	w15, w13, w9
1000ce2d0:     	and	w13, w9, w13, lsr #4
1000ce2d4:     	stp	w15, w13, [sp, #40]
1000ce2d8:     	and	w13, w14, w9
1000ce2dc:     	and	w14, w9, w14, lsr #4
1000ce2e0:     	stp	w13, w14, [sp, #48]
1000ce2e4:     	ldp	w13, w14, [x20, #24]
1000ce2e8:     	and	w15, w13, w9
1000ce2ec:     	and	w13, w9, w13, lsr #4
1000ce2f0:     	stp	w15, w13, [sp, #56]
1000ce2f4:     	and	w13, w14, w9
1000ce2f8:     	and	w14, w9, w14, lsr #4
1000ce2fc:     	stp	w13, w14, [sp, #64]
1000ce300:     	ldp	w13, w14, [x20, #32]
1000ce304:     	and	w15, w13, w9
1000ce308:     	and	w13, w9, w13, lsr #4
1000ce30c:     	stp	w15, w13, [sp, #72]
1000ce310:     	and	w13, w14, w9
1000ce314:     	and	w14, w9, w14, lsr #4
1000ce318:     	stp	w13, w14, [sp, #80]
1000ce31c:     	ldp	w13, w14, [x20, #40]
1000ce320:     	and	w15, w13, w9
1000ce324:     	and	w13, w9, w13, lsr #4
1000ce328:     	stp	w15, w13, [sp, #88]
1000ce32c:     	and	w13, w14, w9
1000ce330:     	and	w14, w9, w14, lsr #4
1000ce334:     	stp	w13, w14, [sp, #96]
1000ce338:     	ldp	w13, w14, [x20, #48]
1000ce33c:     	and	w15, w13, w9
1000ce340:     	and	w13, w9, w13, lsr #4
1000ce344:     	stp	w15, w13, [sp, #104]
1000ce348:     	and	w13, w14, w9
1000ce34c:     	and	w14, w9, w14, lsr #4
1000ce350:     	stp	w13, w14, [sp, #112]
1000ce354:     	ldp	w13, w14, [x20, #56]
1000ce358:     	and	w15, w13, w9
1000ce35c:     	and	w13, w9, w13, lsr #4
1000ce360:     	stp	w15, w13, [sp, #120]
1000ce364:     	and	w13, w14, w9
1000ce368:     	and	w14, w9, w14, lsr #4
1000ce36c:     	stp	w13, w14, [sp, #128]
1000ce370:     	add	x13, sp, #136
1000ce374:     	mov	x14, #0
1000ce378:     	ldr	w4, [x21, x12, lsl #2]
1000ce37c:     	lsl	w15, w4, #4
1000ce380:     	and	x15, x15, #0xf0
1000ce384:     	add	x15, x10, x15
1000ce388:     	and	x16, x4, #0xf0
1000ce38c:     	add	x16, x10, x16
1000ce390:     	lsr	x17, x4, #4
1000ce394:     	and	x17, x17, #0xf0
1000ce398:     	add	x17, x10, x17
1000ce39c:     	lsr	x0, x4, #8
1000ce3a0:     	and	x0, x0, #0xf0
1000ce3a4:     	add	x0, x10, x0
1000ce3a8:     	lsr	x1, x4, #12
1000ce3ac:     	and	x1, x1, #0xf0
1000ce3b0:     	add	x1, x10, x1
1000ce3b4:     	lsr	x2, x4, #16
1000ce3b8:     	and	x2, x2, #0xf0
1000ce3bc:     	add	x2, x10, x2
1000ce3c0:     	lsr	x3, x4, #20
1000ce3c4:     	and	x3, x3, #0xf0
1000ce3c8:     	add	x3, x10, x3
1000ce3cc:     	lsr	x4, x4, #24
1000ce3d0:     	and	x4, x4, #0xf0
1000ce3d4:     	add	x4, x10, x4
1000ce3d8:     	mov	x5, x13
1000ce3dc:     	add	x6, x11, x14
1000ce3e0:     	ldrb	w7, [x6]
1000ce3e4:     	ldrb	w7, [x15, x7]
1000ce3e8:     	ldrb	w22, [x6, #1]
1000ce3ec:     	ldrb	w22, [x17, x22]
1000ce3f0:     	ldrb	w23, [x6, #2]
1000ce3f4:     	ldrb	w23, [x1, x23]
1000ce3f8:     	add	w7, w7, w22
1000ce3fc:     	add	w7, w7, w23
1000ce400:     	ldrb	w22, [x6, #3]
1000ce404:     	ldrb	w22, [x3, x22]
1000ce408:     	ldrb	w23, [x6, #4]
1000ce40c:     	ldrb	w23, [x16, x23]
1000ce410:     	ldrb	w24, [x6, #5]
1000ce414:     	ldrb	w24, [x0, x24]
1000ce418:     	add	w7, w7, w22
1000ce41c:     	add	w7, w7, w23
1000ce420:     	ldrb	w22, [x6, #6]
1000ce424:     	ldrb	w22, [x2, x22]
1000ce428:     	add	w7, w7, w24
1000ce42c:     	add	w7, w7, w22
1000ce430:     	ldrb	w6, [x6, #7]
1000ce434:     	ldrb	w6, [x4, x6]
1000ce438:     	add	w6, w7, w6
1000ce43c:     	scvtf	s0, w6
1000ce440:     	ldr	s1, [x5]
1000ce444:     	fadd	s0, s1, s0
1000ce448:     	str	s0, [x5], #64
1000ce44c:     	add	x14, x14, #8
1000ce450:     	cmp	x14, #128
1000ce454:     	b.ne	0x1000ce3dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000ce458:     	add	x12, x12, #1
1000ce45c:     	add	x13, x13, #4
1000ce460:     	cmp	x12, #16
1000ce464:     	b.ne	0x1000ce374 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ce468:     	add	x21, x21, #64
1000ce46c:     	add	x20, x20, #64
1000ce470:     	cmp	x20, x8
1000ce474:     	b.ne	0x1000ce28c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000ce478:     	add	x1, sp, #136
1000ce47c:     	mov	x0, x19
1000ce480:     	mov	w2, #1024
1000ce484:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ce488:     	ldur	x8, [x29, #-72]
1000ce48c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000ce490:     	ldr	x9, [x9, #392]
1000ce494:     	ldr	x9, [x9]
1000ce498:     	cmp	x9, x8
1000ce49c:     	b.ne	0x1000ce4bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000ce4a0:     	add	sp, sp, #1168
1000ce4a4:     	ldp	x29, x30, [sp, #64]
1000ce4a8:     	ldp	x20, x19, [sp, #48]
1000ce4ac:     	ldp	x22, x21, [sp, #32]
1000ce4b0:     	ldp	x24, x23, [sp, #16]
1000ce4b4:     	ldp	x28, x27, [sp], #80
1000ce4b8:     	ret
1000ce4bc:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000ce734 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce734:     	stp	x28, x27, [sp, #-80]!
1000ce738:     	stp	x24, x23, [sp, #16]
1000ce73c:     	stp	x22, x21, [sp, #32]
1000ce740:     	stp	x20, x19, [sp, #48]
1000ce744:     	stp	x29, x30, [sp, #64]
1000ce748:     	add	x29, sp, #64
1000ce74c:     	sub	sp, sp, #1168
1000ce750:     	mov	x19, x3
1000ce754:     	mov	x20, x1
1000ce758:     	mov	x21, x0
1000ce75c:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x8>
1000ce760:     	ldr	x8, [x8, #392]
1000ce764:     	ldr	x8, [x8]
1000ce768:     	stur	x8, [x29, #-72]
1000ce76c:     	lsl	x8, x2, #3
1000ce770:     	and	x22, x8, #0xfffffffffffffff0
1000ce774:     	add	x0, sp, #136
1000ce778:     	mov	w1, #1024
1000ce77c:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000ce780:     	cbz	x22, 0x1000ce984 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000ce784:     	add	x8, x20, x22
1000ce788:     	mov	w9, #252645135
1000ce78c:     	adrp	x10, 0x10016a000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x30>
1000ce790:     	add	x10, x10, #1468
1000ce794:     	add	x11, sp, #8
1000ce798:     	mov	x12, #0
1000ce79c:     	ldp	w13, w14, [x20]
1000ce7a0:     	and	w15, w13, w9
1000ce7a4:     	and	w13, w9, w13, lsr #4
1000ce7a8:     	stp	w15, w13, [sp, #8]
1000ce7ac:     	and	w13, w14, w9
1000ce7b0:     	and	w14, w9, w14, lsr #4
1000ce7b4:     	stp	w13, w14, [sp, #16]
1000ce7b8:     	ldp	w13, w14, [x20, #8]
1000ce7bc:     	and	w15, w13, w9
1000ce7c0:     	and	w13, w9, w13, lsr #4
1000ce7c4:     	stp	w15, w13, [sp, #24]
1000ce7c8:     	and	w13, w14, w9
1000ce7cc:     	and	w14, w9, w14, lsr #4
1000ce7d0:     	stp	w13, w14, [sp, #32]
1000ce7d4:     	ldp	w13, w14, [x20, #16]
1000ce7d8:     	and	w15, w13, w9
1000ce7dc:     	and	w13, w9, w13, lsr #4
1000ce7e0:     	stp	w15, w13, [sp, #40]
1000ce7e4:     	and	w13, w14, w9
1000ce7e8:     	and	w14, w9, w14, lsr #4
1000ce7ec:     	stp	w13, w14, [sp, #48]
1000ce7f0:     	ldp	w13, w14, [x20, #24]
1000ce7f4:     	and	w15, w13, w9
1000ce7f8:     	and	w13, w9, w13, lsr #4
1000ce7fc:     	stp	w15, w13, [sp, #56]
1000ce800:     	and	w13, w14, w9
1000ce804:     	and	w14, w9, w14, lsr #4
1000ce808:     	stp	w13, w14, [sp, #64]
1000ce80c:     	ldp	w13, w14, [x20, #32]
1000ce810:     	and	w15, w13, w9
1000ce814:     	and	w13, w9, w13, lsr #4
1000ce818:     	stp	w15, w13, [sp, #72]
1000ce81c:     	and	w13, w14, w9
1000ce820:     	and	w14, w9, w14, lsr #4
1000ce824:     	stp	w13, w14, [sp, #80]
1000ce828:     	ldp	w13, w14, [x20, #40]
1000ce82c:     	and	w15, w13, w9
1000ce830:     	and	w13, w9, w13, lsr #4
1000ce834:     	stp	w15, w13, [sp, #88]
1000ce838:     	and	w13, w14, w9
1000ce83c:     	and	w14, w9, w14, lsr #4
1000ce840:     	stp	w13, w14, [sp, #96]
1000ce844:     	ldp	w13, w14, [x20, #48]
1000ce848:     	and	w15, w13, w9
1000ce84c:     	and	w13, w9, w13, lsr #4
1000ce850:     	stp	w15, w13, [sp, #104]
1000ce854:     	and	w13, w14, w9
1000ce858:     	and	w14, w9, w14, lsr #4
1000ce85c:     	stp	w13, w14, [sp, #112]
1000ce860:     	ldp	w13, w14, [x20, #56]
1000ce864:     	and	w15, w13, w9
1000ce868:     	and	w13, w9, w13, lsr #4
1000ce86c:     	stp	w15, w13, [sp, #120]
1000ce870:     	and	w13, w14, w9
1000ce874:     	and	w14, w9, w14, lsr #4
1000ce878:     	stp	w13, w14, [sp, #128]
1000ce87c:     	add	x13, sp, #136
1000ce880:     	mov	x14, #0
1000ce884:     	ldr	w4, [x21, x12, lsl #2]
1000ce888:     	lsl	w15, w4, #4
1000ce88c:     	and	x15, x15, #0xf0
1000ce890:     	add	x15, x10, x15
1000ce894:     	and	x16, x4, #0xf0
1000ce898:     	add	x16, x10, x16
1000ce89c:     	lsr	x17, x4, #4
1000ce8a0:     	and	x17, x17, #0xf0
1000ce8a4:     	add	x17, x10, x17
1000ce8a8:     	lsr	x0, x4, #8
1000ce8ac:     	and	x0, x0, #0xf0
1000ce8b0:     	add	x0, x10, x0
1000ce8b4:     	lsr	x1, x4, #12
1000ce8b8:     	and	x1, x1, #0xf0
1000ce8bc:     	add	x1, x10, x1
1000ce8c0:     	lsr	x2, x4, #16
1000ce8c4:     	and	x2, x2, #0xf0
1000ce8c8:     	add	x2, x10, x2
1000ce8cc:     	lsr	x3, x4, #20
1000ce8d0:     	and	x3, x3, #0xf0
1000ce8d4:     	add	x3, x10, x3
1000ce8d8:     	lsr	x4, x4, #24
1000ce8dc:     	and	x4, x4, #0xf0
1000ce8e0:     	add	x4, x10, x4
1000ce8e4:     	mov	x5, x13
1000ce8e8:     	add	x6, x11, x14
1000ce8ec:     	ldrb	w7, [x6]
1000ce8f0:     	ldrsb	w7, [x15, x7]
1000ce8f4:     	ldrb	w22, [x6, #1]
1000ce8f8:     	ldrsb	w22, [x17, x22]
1000ce8fc:     	ldrb	w23, [x6, #2]
1000ce900:     	ldrsb	w23, [x1, x23]
1000ce904:     	add	w7, w7, w22
1000ce908:     	add	w7, w7, w23
1000ce90c:     	ldrb	w22, [x6, #3]
1000ce910:     	ldrsb	w22, [x3, x22]
1000ce914:     	ldrb	w23, [x6, #4]
1000ce918:     	ldrsb	w23, [x16, x23]
1000ce91c:     	ldrb	w24, [x6, #5]
1000ce920:     	ldrsb	w24, [x0, x24]
1000ce924:     	add	w7, w7, w22
1000ce928:     	add	w7, w7, w23
1000ce92c:     	ldrb	w22, [x6, #6]
1000ce930:     	ldrsb	w22, [x2, x22]
1000ce934:     	add	w7, w7, w24
1000ce938:     	add	w7, w7, w22
1000ce93c:     	ldrb	w6, [x6, #7]
1000ce940:     	ldrsb	w6, [x4, x6]
1000ce944:     	add	w6, w7, w6
1000ce948:     	scvtf	s0, w6
1000ce94c:     	ldr	s1, [x5]
1000ce950:     	fadd	s0, s1, s0
1000ce954:     	str	s0, [x5], #64
1000ce958:     	add	x14, x14, #8
1000ce95c:     	cmp	x14, #128
1000ce960:     	b.ne	0x1000ce8e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000ce964:     	add	x12, x12, #1
1000ce968:     	add	x13, x13, #4
1000ce96c:     	cmp	x12, #16
1000ce970:     	b.ne	0x1000ce880 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ce974:     	add	x21, x21, #64
1000ce978:     	add	x20, x20, #64
1000ce97c:     	cmp	x20, x8
1000ce980:     	b.ne	0x1000ce798 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000ce984:     	add	x1, sp, #136
1000ce988:     	mov	x0, x19
1000ce98c:     	mov	w2, #1024
1000ce990:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ce994:     	ldur	x8, [x29, #-72]
1000ce998:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x244>
1000ce99c:     	ldr	x9, [x9, #392]
1000ce9a0:     	ldr	x9, [x9]
1000ce9a4:     	cmp	x9, x8
1000ce9a8:     	b.ne	0x1000ce9c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000ce9ac:     	add	sp, sp, #1168
1000ce9b0:     	ldp	x29, x30, [sp, #64]
1000ce9b4:     	ldp	x20, x19, [sp, #48]
1000ce9b8:     	ldp	x22, x21, [sp, #32]
1000ce9bc:     	ldp	x24, x23, [sp, #16]
1000ce9c0:     	ldp	x28, x27, [sp], #80
1000ce9c4:     	ret
1000ce9c8:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cfc14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000cfc14:     	stp	x22, x21, [sp, #-32]!
1000cfc18:     	stp	x20, x19, [sp, #16]
1000cfc1c:     	movi.2d	v0, #0000000000000000
1000cfc20:     	stp	q0, q0, [x3, #96]
1000cfc24:     	stp	q0, q0, [x3, #64]
1000cfc28:     	stp	q0, q0, [x3, #32]
1000cfc2c:     	stp	q0, q0, [x3]
1000cfc30:     	cmp	x2, #8
1000cfc34:     	b.hs	0x1000cfc40 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000cfc38:     	mov	x8, #0
1000cfc3c:     	b	0x1000cfd50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000cfc40:     	mov	x8, #0
1000cfc44:     	mov	w12, #8
1000cfc48:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x98>
1000cfc4c:     	add	x9, x9, #1724
1000cfc50:     	mov	x10, x0
1000cfc54:     	mov	x11, #0
1000cfc58:     	lsr	x8, x8, #1
1000cfc5c:     	mul	x8, x8, x4
1000cfc60:     	ldr	w6, [x1, x8]
1000cfc64:     	mov	x8, x12
1000cfc68:     	lsl	w12, w6, #4
1000cfc6c:     	and	x12, x12, #0xf0
1000cfc70:     	add	x12, x9, x12
1000cfc74:     	and	x13, x6, #0xf0
1000cfc78:     	add	x13, x9, x13
1000cfc7c:     	lsr	x14, x6, #4
1000cfc80:     	and	x14, x14, #0xf0
1000cfc84:     	add	x14, x9, x14
1000cfc88:     	lsr	x15, x6, #8
1000cfc8c:     	and	x15, x15, #0xf0
1000cfc90:     	add	x15, x9, x15
1000cfc94:     	lsr	x16, x6, #12
1000cfc98:     	and	x16, x16, #0xf0
1000cfc9c:     	add	x16, x9, x16
1000cfca0:     	lsr	x17, x6, #16
1000cfca4:     	and	x17, x17, #0xf0
1000cfca8:     	add	x17, x9, x17
1000cfcac:     	lsr	x5, x6, #20
1000cfcb0:     	and	x5, x5, #0xf0
1000cfcb4:     	add	x5, x9, x5
1000cfcb8:     	lsr	x6, x6, #24
1000cfcbc:     	and	x6, x6, #0xf0
1000cfcc0:     	add	x6, x9, x6
1000cfcc4:     	ldr	w7, [x10, x11]
1000cfcc8:     	and	x19, x7, #0xf
1000cfccc:     	ldrb	w19, [x12, x19]
1000cfcd0:     	ubfx	x20, x7, #4, #4
1000cfcd4:     	ldrb	w20, [x13, x20]
1000cfcd8:     	ubfx	x21, x7, #8, #4
1000cfcdc:     	ldrb	w21, [x14, x21]
1000cfce0:     	add	w19, w19, w20
1000cfce4:     	add	w19, w19, w21
1000cfce8:     	ubfx	x20, x7, #12, #4
1000cfcec:     	ldrb	w20, [x15, x20]
1000cfcf0:     	ubfx	x21, x7, #16, #4
1000cfcf4:     	ldrb	w21, [x16, x21]
1000cfcf8:     	add	w19, w19, w20
1000cfcfc:     	add	w19, w19, w21
1000cfd00:     	ubfx	x20, x7, #20, #4
1000cfd04:     	ldrb	w20, [x17, x20]
1000cfd08:     	ubfx	x21, x7, #24, #4
1000cfd0c:     	ldrb	w21, [x5, x21]
1000cfd10:     	lsr	x7, x7, #28
1000cfd14:     	ldrb	w7, [x6, x7]
1000cfd18:     	add	w19, w19, w20
1000cfd1c:     	add	w19, w19, w21
1000cfd20:     	add	w7, w19, w7
1000cfd24:     	scvtf	s0, w7
1000cfd28:     	ldr	s1, [x3, x11]
1000cfd2c:     	fadd	s0, s1, s0
1000cfd30:     	str	s0, [x3, x11]
1000cfd34:     	add	x11, x11, #4
1000cfd38:     	cmp	x11, #128
1000cfd3c:     	b.ne	0x1000cfcc4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000cfd40:     	add	x12, x8, #8
1000cfd44:     	add	x10, x10, #128
1000cfd48:     	cmp	x12, x2
1000cfd4c:     	b.ls	0x1000cfc54 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000cfd50:     	cmp	x8, x2
1000cfd54:     	b.hs	0x1000cfde4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1d0>
1000cfd58:     	lsl	x9, x4, #2
1000cfd5c:     	mov	w10, #-16
1000cfd60:     	mov	x11, #0
1000cfd64:     	lsr	x13, x8, #3
1000cfd68:     	lsl	x12, x13, #7
1000cfd6c:     	mul	x14, x9, x13
1000cfd70:     	ubfx	x13, x8, #1, #2
1000cfd74:     	orr	x14, x14, x13
1000cfd78:     	ldrb	w15, [x1, x14]
1000cfd7c:     	ubfiz	w14, w8, #2, #1
1000cfd80:     	lsr	w15, w15, w14
1000cfd84:     	and	w16, w15, #0xf
1000cfd88:     	cmp	w16, #8
1000cfd8c:     	csel	w16, wzr, w10, lo
1000cfd90:     	bfxil	w16, w15, #0, #4
1000cfd94:     	scvtf	s0, w16
1000cfd98:     	add	x15, x12, x11
1000cfd9c:     	orr	x15, x15, x13
1000cfda0:     	ldrb	w15, [x0, x15]
1000cfda4:     	lsr	w15, w15, w14
1000cfda8:     	and	w16, w15, #0xf
1000cfdac:     	cmp	w16, #8
1000cfdb0:     	csel	w16, wzr, w10, lo
1000cfdb4:     	bfxil	w16, w15, #0, #4
1000cfdb8:     	scvtf	s1, w16
1000cfdbc:     	ldr	s2, [x3, x11]
1000cfdc0:     	fsub	s1, s1, s0
1000cfdc4:     	fmadd	s1, s1, s1, s2
1000cfdc8:     	str	s1, [x3, x11]
1000cfdcc:     	add	x11, x11, #4
1000cfdd0:     	cmp	x11, #128
1000cfdd4:     	b.ne	0x1000cfd98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000cfdd8:     	add	x8, x8, #1
1000cfddc:     	cmp	x8, x2
1000cfde0:     	b.ne	0x1000cfd60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000cfde4:     	ldp	x20, x19, [sp, #16]
1000cfde8:     	ldp	x22, x21, [sp], #32
1000cfdec:     	ret

00000001000cfe1c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000cfe1c:     	stp	x22, x21, [sp, #-32]!
1000cfe20:     	stp	x20, x19, [sp, #16]
1000cfe24:     	movi.2d	v0, #0000000000000000
1000cfe28:     	stp	q0, q0, [x3, #96]
1000cfe2c:     	stp	q0, q0, [x3, #64]
1000cfe30:     	stp	q0, q0, [x3, #32]
1000cfe34:     	stp	q0, q0, [x3]
1000cfe38:     	cmp	x2, #8
1000cfe3c:     	b.hs	0x1000cfe48 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000cfe40:     	mov	x8, #0
1000cfe44:     	b	0x1000cff58 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000cfe48:     	mov	x8, #0
1000cfe4c:     	mov	w12, #8
1000cfe50:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 2ul, false>(char const*)+0xc8>
1000cfe54:     	add	x9, x9, #1980
1000cfe58:     	mov	x10, x0
1000cfe5c:     	mov	x11, #0
1000cfe60:     	lsr	x8, x8, #1
1000cfe64:     	mul	x8, x8, x4
1000cfe68:     	ldr	w6, [x1, x8]
1000cfe6c:     	mov	x8, x12
1000cfe70:     	lsl	w12, w6, #4
1000cfe74:     	and	x12, x12, #0xf0
1000cfe78:     	add	x12, x9, x12
1000cfe7c:     	and	x13, x6, #0xf0
1000cfe80:     	add	x13, x9, x13
1000cfe84:     	lsr	x14, x6, #4
1000cfe88:     	and	x14, x14, #0xf0
1000cfe8c:     	add	x14, x9, x14
1000cfe90:     	lsr	x15, x6, #8
1000cfe94:     	and	x15, x15, #0xf0
1000cfe98:     	add	x15, x9, x15
1000cfe9c:     	lsr	x16, x6, #12
1000cfea0:     	and	x16, x16, #0xf0
1000cfea4:     	add	x16, x9, x16
1000cfea8:     	lsr	x17, x6, #16
1000cfeac:     	and	x17, x17, #0xf0
1000cfeb0:     	add	x17, x9, x17
1000cfeb4:     	lsr	x5, x6, #20
1000cfeb8:     	and	x5, x5, #0xf0
1000cfebc:     	add	x5, x9, x5
1000cfec0:     	lsr	x6, x6, #24
1000cfec4:     	and	x6, x6, #0xf0
1000cfec8:     	add	x6, x9, x6
1000cfecc:     	ldr	w7, [x10, x11]
1000cfed0:     	and	x19, x7, #0xf
1000cfed4:     	ldrsb	w19, [x12, x19]
1000cfed8:     	ubfx	x20, x7, #4, #4
1000cfedc:     	ldrsb	w20, [x13, x20]
1000cfee0:     	ubfx	x21, x7, #8, #4
1000cfee4:     	ldrsb	w21, [x14, x21]
1000cfee8:     	add	w19, w19, w20
1000cfeec:     	add	w19, w19, w21
1000cfef0:     	ubfx	x20, x7, #12, #4
1000cfef4:     	ldrsb	w20, [x15, x20]
1000cfef8:     	ubfx	x21, x7, #16, #4
1000cfefc:     	ldrsb	w21, [x16, x21]
1000cff00:     	add	w19, w19, w20
1000cff04:     	add	w19, w19, w21
1000cff08:     	ubfx	x20, x7, #20, #4
1000cff0c:     	ldrsb	w20, [x17, x20]
1000cff10:     	ubfx	x21, x7, #24, #4
1000cff14:     	ldrsb	w21, [x5, x21]
1000cff18:     	lsr	x7, x7, #28
1000cff1c:     	ldrsb	w7, [x6, x7]
1000cff20:     	add	w19, w19, w20
1000cff24:     	add	w19, w19, w21
1000cff28:     	add	w7, w19, w7
1000cff2c:     	scvtf	s0, w7
1000cff30:     	ldr	s1, [x3, x11]
1000cff34:     	fadd	s0, s1, s0
1000cff38:     	str	s0, [x3, x11]
1000cff3c:     	add	x11, x11, #4
1000cff40:     	cmp	x11, #128
1000cff44:     	b.ne	0x1000cfecc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000cff48:     	add	x12, x8, #8
1000cff4c:     	add	x10, x10, #128
1000cff50:     	cmp	x12, x2
1000cff54:     	b.ls	0x1000cfe5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000cff58:     	cmp	x8, x2
1000cff5c:     	b.hs	0x1000cffe8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1cc>
1000cff60:     	lsl	x9, x4, #2
1000cff64:     	mov	w10, #-16
1000cff68:     	mov	x11, #0
1000cff6c:     	lsr	x13, x8, #3
1000cff70:     	lsl	x12, x13, #7
1000cff74:     	mul	x14, x9, x13
1000cff78:     	ubfx	x13, x8, #1, #2
1000cff7c:     	orr	x14, x14, x13
1000cff80:     	ldrb	w15, [x1, x14]
1000cff84:     	ubfiz	w14, w8, #2, #1
1000cff88:     	lsr	w15, w15, w14
1000cff8c:     	and	w16, w15, #0xf
1000cff90:     	cmp	w16, #8
1000cff94:     	csel	w16, wzr, w10, lo
1000cff98:     	bfxil	w16, w15, #0, #4
1000cff9c:     	scvtf	s0, w16
1000cffa0:     	add	x15, x12, x11
1000cffa4:     	orr	x15, x15, x13
1000cffa8:     	ldrb	w15, [x0, x15]
1000cffac:     	lsr	w15, w15, w14
1000cffb0:     	and	w16, w15, #0xf
1000cffb4:     	cmp	w16, #8
1000cffb8:     	csel	w16, wzr, w10, lo
1000cffbc:     	bfxil	w16, w15, #0, #4
1000cffc0:     	scvtf	s1, w16
1000cffc4:     	ldr	s2, [x3, x11]
1000cffc8:     	fmsub	s1, s1, s0, s2
1000cffcc:     	str	s1, [x3, x11]
1000cffd0:     	add	x11, x11, #4
1000cffd4:     	cmp	x11, #128
1000cffd8:     	b.ne	0x1000cffa0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000cffdc:     	add	x8, x8, #1
1000cffe0:     	cmp	x8, x2
1000cffe4:     	b.ne	0x1000cff68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000cffe8:     	ldp	x20, x19, [sp, #16]
1000cffec:     	ldp	x22, x21, [sp], #32
1000cfff0:     	ret

00000001000d159c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d159c:     	sub	sp, sp, #400
1000d15a0:     	stp	x28, x27, [sp, #304]
1000d15a4:     	stp	x26, x25, [sp, #320]
1000d15a8:     	stp	x24, x23, [sp, #336]
1000d15ac:     	stp	x22, x21, [sp, #352]
1000d15b0:     	stp	x20, x19, [sp, #368]
1000d15b4:     	stp	x29, x30, [sp, #384]
1000d15b8:     	add	x29, sp, #384
1000d15bc:     	str	x3, [sp]
1000d15c0:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30>
1000d15c4:     	ldr	x8, [x8, #392]
1000d15c8:     	ldr	x8, [x8]
1000d15cc:     	stur	x8, [x29, #-96]
1000d15d0:     	movi.2d	v0, #0000000000000000
1000d15d4:     	stp	q0, q0, [sp, #256]
1000d15d8:     	stp	q0, q0, [sp, #224]
1000d15dc:     	stp	q0, q0, [sp, #192]
1000d15e0:     	stp	q0, q0, [sp, #160]
1000d15e4:     	stp	q0, q0, [sp, #128]
1000d15e8:     	stp	q0, q0, [sp, #96]
1000d15ec:     	stp	q0, q0, [sp, #64]
1000d15f0:     	stp	q0, q0, [sp, #32]
1000d15f4:     	ands	x8, x2, #0xfffffffffffffffe
1000d15f8:     	b.eq	0x1000d177c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d15fc:     	add	x8, x1, x8
1000d1600:     	str	x8, [sp, #8]
1000d1604:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d1608:     	add	x9, x9, #1724
1000d160c:     	mov	x11, #0
1000d1610:     	ldp	w4, w23, [x1]
1000d1614:     	ubfx	x8, x4, #8, #4
1000d1618:     	stp	x1, x8, [sp, #16]
1000d161c:     	ubfx	x13, x4, #16, #4
1000d1620:     	and	x14, x4, #0xf
1000d1624:     	ubfx	x15, x4, #24, #4
1000d1628:     	ubfx	x16, x4, #4, #4
1000d162c:     	ubfx	x17, x4, #12, #4
1000d1630:     	ubfx	x2, x4, #20, #4
1000d1634:     	lsr	x4, x4, #28
1000d1638:     	and	x5, x23, #0xf
1000d163c:     	ubfx	x6, x23, #8, #4
1000d1640:     	ubfx	x7, x23, #16, #4
1000d1644:     	ubfx	x19, x23, #24, #4
1000d1648:     	ubfx	x20, x23, #4, #4
1000d164c:     	ubfx	x21, x23, #12, #4
1000d1650:     	ubfx	x22, x23, #20, #4
1000d1654:     	lsr	x23, x23, #28
1000d1658:     	ldr	w24, [x0, x11]
1000d165c:     	lsl	w25, w24, #4
1000d1660:     	and	x25, x25, #0xf0
1000d1664:     	add	x25, x9, x25
1000d1668:     	and	x26, x24, #0xf0
1000d166c:     	add	x26, x9, x26
1000d1670:     	lsr	x27, x24, #4
1000d1674:     	and	x27, x27, #0xf0
1000d1678:     	add	x27, x9, x27
1000d167c:     	lsr	x28, x24, #8
1000d1680:     	and	x28, x28, #0xf0
1000d1684:     	add	x28, x9, x28
1000d1688:     	lsr	x30, x24, #12
1000d168c:     	and	x30, x30, #0xf0
1000d1690:     	add	x30, x9, x30
1000d1694:     	lsr	x8, x24, #16
1000d1698:     	and	x8, x8, #0xf0
1000d169c:     	add	x8, x9, x8
1000d16a0:     	lsr	x3, x24, #20
1000d16a4:     	and	x3, x3, #0xf0
1000d16a8:     	add	x3, x9, x3
1000d16ac:     	lsr	x24, x24, #24
1000d16b0:     	and	x24, x24, #0xf0
1000d16b4:     	ldrb	w10, [x25, x14]
1000d16b8:     	ldr	x12, [sp, #24]
1000d16bc:     	ldrb	w1, [x27, x12]
1000d16c0:     	ldrb	w12, [x30, x13]
1000d16c4:     	add	w10, w10, w1
1000d16c8:     	add	w10, w10, w12
1000d16cc:     	ldrb	w12, [x3, x15]
1000d16d0:     	ldrb	w1, [x26, x16]
1000d16d4:     	add	w10, w10, w12
1000d16d8:     	add	w10, w10, w1
1000d16dc:     	ldrb	w12, [x28, x17]
1000d16e0:     	ldrb	w1, [x8, x2]
1000d16e4:     	add	x24, x9, x24
1000d16e8:     	add	w10, w10, w12
1000d16ec:     	add	w10, w10, w1
1000d16f0:     	ldrb	w12, [x24, x4]
1000d16f4:     	add	w10, w10, w12
1000d16f8:     	scvtf	s0, w10
1000d16fc:     	add	x10, sp, #32
1000d1700:     	add	x10, x10, x11
1000d1704:     	ldr	s1, [x10]
1000d1708:     	ldrb	w12, [x25, x5]
1000d170c:     	fadd	s0, s1, s0
1000d1710:     	ldrb	w1, [x27, x6]
1000d1714:     	ldrb	w25, [x30, x7]
1000d1718:     	add	w12, w12, w1
1000d171c:     	add	w12, w12, w25
1000d1720:     	ldrb	w1, [x3, x19]
1000d1724:     	ldrb	w3, [x26, x20]
1000d1728:     	add	w12, w12, w1
1000d172c:     	add	w12, w12, w3
1000d1730:     	ldrb	w1, [x28, x21]
1000d1734:     	ldrb	w8, [x8, x22]
1000d1738:     	add	w12, w12, w1
1000d173c:     	add	w8, w12, w8
1000d1740:     	ldrb	w12, [x24, x23]
1000d1744:     	add	w8, w8, w12
1000d1748:     	scvtf	s1, w8
1000d174c:     	str	s0, [x10]
1000d1750:     	ldr	s0, [x10, #128]
1000d1754:     	fadd	s0, s0, s1
1000d1758:     	str	s0, [x10, #128]
1000d175c:     	add	x11, x11, #4
1000d1760:     	cmp	x11, #128
1000d1764:     	b.ne	0x1000d1658 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d1768:     	add	x0, x0, #128
1000d176c:     	ldp	x8, x1, [sp, #8]
1000d1770:     	add	x1, x1, #8
1000d1774:     	cmp	x1, x8
1000d1778:     	b.ne	0x1000d160c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d177c:     	ldp	q0, q1, [sp, #224]
1000d1780:     	ldr	x8, [sp]
1000d1784:     	stp	q0, q1, [x8, #192]
1000d1788:     	ldp	q0, q1, [sp, #256]
1000d178c:     	stp	q0, q1, [x8, #224]
1000d1790:     	ldp	q0, q1, [sp, #160]
1000d1794:     	stp	q0, q1, [x8, #128]
1000d1798:     	ldp	q0, q1, [sp, #192]
1000d179c:     	stp	q0, q1, [x8, #160]
1000d17a0:     	ldp	q0, q1, [sp, #96]
1000d17a4:     	stp	q0, q1, [x8, #64]
1000d17a8:     	ldp	q0, q1, [sp, #128]
1000d17ac:     	stp	q0, q1, [x8, #96]
1000d17b0:     	ldp	q0, q1, [sp, #32]
1000d17b4:     	stp	q0, q1, [x8]
1000d17b8:     	ldp	q0, q1, [sp, #64]
1000d17bc:     	stp	q0, q1, [x8, #32]
1000d17c0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x164>
1000d17c4:     	ldr	x8, [x8, #392]
1000d17c8:     	ldr	x8, [x8]
1000d17cc:     	ldur	x9, [x29, #-96]
1000d17d0:     	cmp	x8, x9
1000d17d4:     	b.ne	0x1000d17f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d17d8:     	ldp	x29, x30, [sp, #384]
1000d17dc:     	ldp	x20, x19, [sp, #368]
1000d17e0:     	ldp	x22, x21, [sp, #352]
1000d17e4:     	ldp	x24, x23, [sp, #336]
1000d17e8:     	ldp	x26, x25, [sp, #320]
1000d17ec:     	ldp	x28, x27, [sp, #304]
1000d17f0:     	add	sp, sp, #400
1000d17f4:     	ret
1000d17f8:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d18c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d18c8:     	sub	sp, sp, #400
1000d18cc:     	stp	x28, x27, [sp, #304]
1000d18d0:     	stp	x26, x25, [sp, #320]
1000d18d4:     	stp	x24, x23, [sp, #336]
1000d18d8:     	stp	x22, x21, [sp, #352]
1000d18dc:     	stp	x20, x19, [sp, #368]
1000d18e0:     	stp	x29, x30, [sp, #384]
1000d18e4:     	add	x29, sp, #384
1000d18e8:     	str	x3, [sp]
1000d18ec:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x30>
1000d18f0:     	ldr	x8, [x8, #392]
1000d18f4:     	ldr	x8, [x8]
1000d18f8:     	stur	x8, [x29, #-96]
1000d18fc:     	movi.2d	v0, #0000000000000000
1000d1900:     	stp	q0, q0, [sp, #256]
1000d1904:     	stp	q0, q0, [sp, #224]
1000d1908:     	stp	q0, q0, [sp, #192]
1000d190c:     	stp	q0, q0, [sp, #160]
1000d1910:     	stp	q0, q0, [sp, #128]
1000d1914:     	stp	q0, q0, [sp, #96]
1000d1918:     	stp	q0, q0, [sp, #64]
1000d191c:     	stp	q0, q0, [sp, #32]
1000d1920:     	ands	x8, x2, #0xfffffffffffffffe
1000d1924:     	b.eq	0x1000d1aa8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d1928:     	add	x8, x1, x8
1000d192c:     	str	x8, [sp, #8]
1000d1930:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x6c>
1000d1934:     	add	x9, x9, #1980
1000d1938:     	mov	x11, #0
1000d193c:     	ldp	w4, w23, [x1]
1000d1940:     	ubfx	x8, x4, #8, #4
1000d1944:     	stp	x1, x8, [sp, #16]
1000d1948:     	ubfx	x13, x4, #16, #4
1000d194c:     	and	x14, x4, #0xf
1000d1950:     	ubfx	x15, x4, #24, #4
1000d1954:     	ubfx	x16, x4, #4, #4
1000d1958:     	ubfx	x17, x4, #12, #4
1000d195c:     	ubfx	x2, x4, #20, #4
1000d1960:     	lsr	x4, x4, #28
1000d1964:     	and	x5, x23, #0xf
1000d1968:     	ubfx	x6, x23, #8, #4
1000d196c:     	ubfx	x7, x23, #16, #4
1000d1970:     	ubfx	x19, x23, #24, #4
1000d1974:     	ubfx	x20, x23, #4, #4
1000d1978:     	ubfx	x21, x23, #12, #4
1000d197c:     	ubfx	x22, x23, #20, #4
1000d1980:     	lsr	x23, x23, #28
1000d1984:     	ldr	w24, [x0, x11]
1000d1988:     	lsl	w25, w24, #4
1000d198c:     	and	x25, x25, #0xf0
1000d1990:     	add	x25, x9, x25
1000d1994:     	and	x26, x24, #0xf0
1000d1998:     	add	x26, x9, x26
1000d199c:     	lsr	x27, x24, #4
1000d19a0:     	and	x27, x27, #0xf0
1000d19a4:     	add	x27, x9, x27
1000d19a8:     	lsr	x28, x24, #8
1000d19ac:     	and	x28, x28, #0xf0
1000d19b0:     	add	x28, x9, x28
1000d19b4:     	lsr	x30, x24, #12
1000d19b8:     	and	x30, x30, #0xf0
1000d19bc:     	add	x30, x9, x30
1000d19c0:     	lsr	x8, x24, #16
1000d19c4:     	and	x8, x8, #0xf0
1000d19c8:     	add	x8, x9, x8
1000d19cc:     	lsr	x3, x24, #20
1000d19d0:     	and	x3, x3, #0xf0
1000d19d4:     	add	x3, x9, x3
1000d19d8:     	lsr	x24, x24, #24
1000d19dc:     	and	x24, x24, #0xf0
1000d19e0:     	ldrsb	w10, [x25, x14]
1000d19e4:     	ldr	x12, [sp, #24]
1000d19e8:     	ldrsb	w1, [x27, x12]
1000d19ec:     	ldrsb	w12, [x30, x13]
1000d19f0:     	add	w10, w10, w1
1000d19f4:     	add	w10, w10, w12
1000d19f8:     	ldrsb	w12, [x3, x15]
1000d19fc:     	ldrsb	w1, [x26, x16]
1000d1a00:     	add	w10, w10, w12
1000d1a04:     	add	w10, w10, w1
1000d1a08:     	ldrsb	w12, [x28, x17]
1000d1a0c:     	ldrsb	w1, [x8, x2]
1000d1a10:     	add	x24, x9, x24
1000d1a14:     	add	w10, w10, w12
1000d1a18:     	add	w10, w10, w1
1000d1a1c:     	ldrsb	w12, [x24, x4]
1000d1a20:     	add	w10, w10, w12
1000d1a24:     	scvtf	s0, w10
1000d1a28:     	add	x10, sp, #32
1000d1a2c:     	add	x10, x10, x11
1000d1a30:     	ldr	s1, [x10]
1000d1a34:     	ldrsb	w12, [x25, x5]
1000d1a38:     	fadd	s0, s1, s0
1000d1a3c:     	ldrsb	w1, [x27, x6]
1000d1a40:     	ldrsb	w25, [x30, x7]
1000d1a44:     	add	w12, w12, w1
1000d1a48:     	add	w12, w12, w25
1000d1a4c:     	ldrsb	w1, [x3, x19]
1000d1a50:     	ldrsb	w3, [x26, x20]
1000d1a54:     	add	w12, w12, w1
1000d1a58:     	add	w12, w12, w3
1000d1a5c:     	ldrsb	w1, [x28, x21]
1000d1a60:     	ldrsb	w8, [x8, x22]
1000d1a64:     	add	w12, w12, w1
1000d1a68:     	add	w8, w12, w8
1000d1a6c:     	ldrsb	w12, [x24, x23]
1000d1a70:     	add	w8, w8, w12
1000d1a74:     	scvtf	s1, w8
1000d1a78:     	str	s0, [x10]
1000d1a7c:     	ldr	s0, [x10, #128]
1000d1a80:     	fadd	s0, s0, s1
1000d1a84:     	str	s0, [x10, #128]
1000d1a88:     	add	x11, x11, #4
1000d1a8c:     	cmp	x11, #128
1000d1a90:     	b.ne	0x1000d1984 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d1a94:     	add	x0, x0, #128
1000d1a98:     	ldp	x8, x1, [sp, #8]
1000d1a9c:     	add	x1, x1, #8
1000d1aa0:     	cmp	x1, x8
1000d1aa4:     	b.ne	0x1000d1938 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d1aa8:     	ldp	q0, q1, [sp, #224]
1000d1aac:     	ldr	x8, [sp]
1000d1ab0:     	stp	q0, q1, [x8, #192]
1000d1ab4:     	ldp	q0, q1, [sp, #256]
1000d1ab8:     	stp	q0, q1, [x8, #224]
1000d1abc:     	ldp	q0, q1, [sp, #160]
1000d1ac0:     	stp	q0, q1, [x8, #128]
1000d1ac4:     	ldp	q0, q1, [sp, #192]
1000d1ac8:     	stp	q0, q1, [x8, #160]
1000d1acc:     	ldp	q0, q1, [sp, #96]
1000d1ad0:     	stp	q0, q1, [x8, #64]
1000d1ad4:     	ldp	q0, q1, [sp, #128]
1000d1ad8:     	stp	q0, q1, [x8, #96]
1000d1adc:     	ldp	q0, q1, [sp, #32]
1000d1ae0:     	stp	q0, q1, [x8]
1000d1ae4:     	ldp	q0, q1, [sp, #64]
1000d1ae8:     	stp	q0, q1, [x8, #32]
1000d1aec:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x230>
1000d1af0:     	ldr	x8, [x8, #392]
1000d1af4:     	ldr	x8, [x8]
1000d1af8:     	ldur	x9, [x29, #-96]
1000d1afc:     	cmp	x8, x9
1000d1b00:     	b.ne	0x1000d1b24 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d1b04:     	ldp	x29, x30, [sp, #384]
1000d1b08:     	ldp	x20, x19, [sp, #368]
1000d1b0c:     	ldp	x22, x21, [sp, #352]
1000d1b10:     	ldp	x24, x23, [sp, #336]
1000d1b14:     	ldp	x26, x25, [sp, #320]
1000d1b18:     	ldp	x28, x27, [sp, #304]
1000d1b1c:     	add	sp, sp, #400
1000d1b20:     	ret
1000d1b24:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d3394 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d3394:     	stp	x28, x27, [sp, #-96]!
1000d3398:     	stp	x26, x25, [sp, #16]
1000d339c:     	stp	x24, x23, [sp, #32]
1000d33a0:     	stp	x22, x21, [sp, #48]
1000d33a4:     	stp	x20, x19, [sp, #64]
1000d33a8:     	stp	x29, x30, [sp, #80]
1000d33ac:     	add	x29, sp, #80
1000d33b0:     	sub	sp, sp, #704
1000d33b4:     	str	x3, [sp]
1000d33b8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d33bc:     	ldr	x8, [x8, #392]
1000d33c0:     	ldr	x8, [x8]
1000d33c4:     	stur	x8, [x29, #-96]
1000d33c8:     	movi.2d	v0, #0000000000000000
1000d33cc:     	stp	q0, q0, [sp, #656]
1000d33d0:     	lsl	x8, x2, #1
1000d33d4:     	stp	q0, q0, [sp, #624]
1000d33d8:     	stp	q0, q0, [sp, #592]
1000d33dc:     	stp	q0, q0, [sp, #560]
1000d33e0:     	stp	q0, q0, [sp, #528]
1000d33e4:     	stp	q0, q0, [sp, #496]
1000d33e8:     	stp	q0, q0, [sp, #464]
1000d33ec:     	stp	q0, q0, [sp, #432]
1000d33f0:     	stp	q0, q0, [sp, #400]
1000d33f4:     	stp	q0, q0, [sp, #368]
1000d33f8:     	stp	q0, q0, [sp, #336]
1000d33fc:     	stp	q0, q0, [sp, #304]
1000d3400:     	stp	q0, q0, [sp, #272]
1000d3404:     	stp	q0, q0, [sp, #240]
1000d3408:     	stp	q0, q0, [sp, #208]
1000d340c:     	stp	q0, q0, [sp, #176]
1000d3410:     	ands	x8, x8, #0xfffffffffffffffc
1000d3414:     	b.eq	0x1000d36f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d3418:     	add	x8, x1, x8
1000d341c:     	str	x8, [sp, #8]
1000d3420:     	add	x8, sp, #176
1000d3424:     	add	x27, x8, #256
1000d3428:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d342c:     	add	x11, x11, #1724
1000d3430:     	mov	x12, #0
1000d3434:     	ldp	w8, w9, [x1]
1000d3438:     	ubfx	x10, x8, #8, #4
1000d343c:     	str	x10, [sp, #168]
1000d3440:     	ubfx	x10, x8, #16, #4
1000d3444:     	str	x10, [sp, #160]
1000d3448:     	ubfx	x10, x8, #24, #4
1000d344c:     	str	x10, [sp, #152]
1000d3450:     	ldp	w10, w17, [x1, #8]
1000d3454:     	str	x1, [sp, #16]
1000d3458:     	and	x14, x8, #0xf
1000d345c:     	ubfx	x13, x8, #4, #4
1000d3460:     	stp	x13, x14, [sp, #136]
1000d3464:     	ubfx	x14, x8, #12, #4
1000d3468:     	ubfx	x13, x8, #20, #4
1000d346c:     	stp	x13, x14, [sp, #120]
1000d3470:     	lsr	x8, x8, #28
1000d3474:     	str	x8, [sp, #112]
1000d3478:     	and	x8, x9, #0xf
1000d347c:     	str	x8, [sp, #104]
1000d3480:     	ubfx	x8, x9, #8, #4
1000d3484:     	str	x8, [sp, #96]
1000d3488:     	ubfx	x8, x9, #16, #4
1000d348c:     	str	x8, [sp, #88]
1000d3490:     	ubfx	x8, x9, #24, #4
1000d3494:     	str	x8, [sp, #80]
1000d3498:     	ubfx	x8, x9, #4, #4
1000d349c:     	str	x8, [sp, #72]
1000d34a0:     	ubfx	x8, x9, #12, #4
1000d34a4:     	str	x8, [sp, #64]
1000d34a8:     	ubfx	x8, x9, #20, #4
1000d34ac:     	str	x8, [sp, #56]
1000d34b0:     	lsr	x8, x9, #28
1000d34b4:     	str	x8, [sp, #48]
1000d34b8:     	and	x9, x10, #0xf
1000d34bc:     	ubfx	x8, x10, #8, #4
1000d34c0:     	stp	x8, x9, [sp, #32]
1000d34c4:     	ubfx	x8, x10, #16, #4
1000d34c8:     	str	x8, [sp, #24]
1000d34cc:     	ubfx	x28, x10, #24, #4
1000d34d0:     	ubfx	x30, x10, #4, #4
1000d34d4:     	ubfx	x3, x10, #12, #4
1000d34d8:     	ubfx	x8, x10, #20, #4
1000d34dc:     	lsr	x9, x10, #28
1000d34e0:     	and	x1, x17, #0xf
1000d34e4:     	ubfx	x10, x17, #8, #4
1000d34e8:     	ubfx	x13, x17, #16, #4
1000d34ec:     	ubfx	x26, x17, #24, #4
1000d34f0:     	ubfx	x14, x17, #4, #4
1000d34f4:     	ubfx	x15, x17, #12, #4
1000d34f8:     	ubfx	x16, x17, #20, #4
1000d34fc:     	lsr	x17, x17, #28
1000d3500:     	ldr	w20, [x0, x12]
1000d3504:     	lsl	w2, w20, #4
1000d3508:     	and	x2, x2, #0xf0
1000d350c:     	add	x5, x11, x2
1000d3510:     	and	x2, x20, #0xf0
1000d3514:     	add	x2, x11, x2
1000d3518:     	lsr	x4, x20, #4
1000d351c:     	and	x4, x4, #0xf0
1000d3520:     	add	x7, x11, x4
1000d3524:     	lsr	x4, x20, #8
1000d3528:     	and	x4, x4, #0xf0
1000d352c:     	add	x4, x11, x4
1000d3530:     	lsr	x6, x20, #12
1000d3534:     	and	x6, x6, #0xf0
1000d3538:     	add	x19, x11, x6
1000d353c:     	lsr	x6, x20, #16
1000d3540:     	and	x6, x6, #0xf0
1000d3544:     	add	x6, x11, x6
1000d3548:     	lsr	x21, x20, #20
1000d354c:     	and	x21, x21, #0xf0
1000d3550:     	add	x21, x11, x21
1000d3554:     	lsr	x20, x20, #24
1000d3558:     	and	x20, x20, #0xf0
1000d355c:     	ldr	x22, [sp, #144]
1000d3560:     	ldrb	w22, [x5, x22]
1000d3564:     	add	x20, x11, x20
1000d3568:     	ldp	x24, x23, [sp, #160]
1000d356c:     	ldrb	w23, [x7, x23]
1000d3570:     	ldrb	w24, [x19, x24]
1000d3574:     	add	w22, w22, w23
1000d3578:     	add	w22, w22, w24
1000d357c:     	ldr	x23, [sp, #152]
1000d3580:     	ldrb	w23, [x21, x23]
1000d3584:     	ldr	x24, [sp, #136]
1000d3588:     	ldrb	w24, [x2, x24]
1000d358c:     	add	w22, w22, w23
1000d3590:     	add	w22, w22, w24
1000d3594:     	ldp	x24, x23, [sp, #120]
1000d3598:     	ldrb	w23, [x4, x23]
1000d359c:     	ldrb	w24, [x6, x24]
1000d35a0:     	add	w22, w22, w23
1000d35a4:     	add	w22, w22, w24
1000d35a8:     	ldr	x23, [sp, #112]
1000d35ac:     	ldrb	w23, [x20, x23]
1000d35b0:     	add	w22, w22, w23
1000d35b4:     	scvtf	s0, w22
1000d35b8:     	ldp	x23, x22, [sp, #96]
1000d35bc:     	ldrb	w22, [x5, x22]
1000d35c0:     	ldrb	w23, [x7, x23]
1000d35c4:     	ldp	x25, x24, [sp, #80]
1000d35c8:     	ldrb	w24, [x19, x24]
1000d35cc:     	ldrb	w25, [x21, x25]
1000d35d0:     	add	w22, w22, w23
1000d35d4:     	ldr	x23, [sp, #72]
1000d35d8:     	ldrb	w23, [x2, x23]
1000d35dc:     	add	w22, w22, w24
1000d35e0:     	ldr	x24, [sp, #64]
1000d35e4:     	ldrb	w24, [x4, x24]
1000d35e8:     	add	w22, w22, w25
1000d35ec:     	ldr	x25, [sp, #56]
1000d35f0:     	ldrb	w25, [x6, x25]
1000d35f4:     	add	w22, w22, w23
1000d35f8:     	add	w22, w22, w24
1000d35fc:     	add	w22, w22, w25
1000d3600:     	ldr	x23, [sp, #48]
1000d3604:     	ldrb	w23, [x20, x23]
1000d3608:     	add	w22, w22, w23
1000d360c:     	scvtf	s1, w22
1000d3610:     	ldp	x23, x22, [sp, #32]
1000d3614:     	ldrb	w22, [x5, x22]
1000d3618:     	ldrb	w23, [x7, x23]
1000d361c:     	ldr	x24, [sp, #24]
1000d3620:     	ldrb	w24, [x19, x24]
1000d3624:     	add	w22, w22, w23
1000d3628:     	ldrb	w23, [x21, x28]
1000d362c:     	add	w22, w22, w24
1000d3630:     	ldrb	w24, [x2, x30]
1000d3634:     	add	w22, w22, w23
1000d3638:     	ldrb	w23, [x4, x3]
1000d363c:     	add	w22, w22, w24
1000d3640:     	ldrb	w24, [x6, x8]
1000d3644:     	add	w22, w22, w23
1000d3648:     	ldrb	w23, [x20, x9]
1000d364c:     	add	w22, w22, w24
1000d3650:     	add	w22, w22, w23
1000d3654:     	scvtf	s2, w22
1000d3658:     	ldrb	w5, [x5, x1]
1000d365c:     	ldrb	w7, [x7, x10]
1000d3660:     	ldrb	w19, [x19, x13]
1000d3664:     	add	w5, w5, w7
1000d3668:     	add	w5, w5, w19
1000d366c:     	ldrb	w7, [x21, x26]
1000d3670:     	ldrb	w2, [x2, x14]
1000d3674:     	add	w5, w5, w7
1000d3678:     	add	w2, w5, w2
1000d367c:     	ldrb	w4, [x4, x15]
1000d3680:     	ldrb	w5, [x6, x16]
1000d3684:     	add	w2, w2, w4
1000d3688:     	add	w2, w2, w5
1000d368c:     	ldrb	w4, [x20, x17]
1000d3690:     	add	w2, w2, w4
1000d3694:     	add	x4, sp, #176
1000d3698:     	scvtf	s3, w2
1000d369c:     	add	x2, x27, x12
1000d36a0:     	ldur	s4, [x2, #-128]
1000d36a4:     	fadd	s1, s4, s1
1000d36a8:     	stur	s1, [x2, #-128]
1000d36ac:     	ldr	s1, [x2]
1000d36b0:     	fadd	s1, s1, s2
1000d36b4:     	str	s1, [x2]
1000d36b8:     	ldr	s1, [x2, #128]
1000d36bc:     	fadd	s1, s1, s3
1000d36c0:     	ldr	s2, [x4, x12]
1000d36c4:     	str	s1, [x2, #128]
1000d36c8:     	fadd	s0, s2, s0
1000d36cc:     	str	s0, [x4, x12]
1000d36d0:     	add	x12, x12, #4
1000d36d4:     	cmp	x12, #128
1000d36d8:     	b.ne	0x1000d3500 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d36dc:     	add	x0, x0, #128
1000d36e0:     	ldp	x8, x1, [sp, #8]
1000d36e4:     	add	x1, x1, #16
1000d36e8:     	cmp	x1, x8
1000d36ec:     	b.ne	0x1000d3430 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d36f0:     	add	x1, sp, #176
1000d36f4:     	ldr	x0, [sp]
1000d36f8:     	mov	w2, #512
1000d36fc:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d3700:     	ldur	x8, [x29, #-96]
1000d3704:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xfc>
1000d3708:     	ldr	x9, [x9, #392]
1000d370c:     	ldr	x9, [x9]
1000d3710:     	cmp	x9, x8
1000d3714:     	b.ne	0x1000d3738 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d3718:     	add	sp, sp, #704
1000d371c:     	ldp	x29, x30, [sp, #80]
1000d3720:     	ldp	x20, x19, [sp, #64]
1000d3724:     	ldp	x22, x21, [sp, #48]
1000d3728:     	ldp	x24, x23, [sp, #32]
1000d372c:     	ldp	x26, x25, [sp, #16]
1000d3730:     	ldp	x28, x27, [sp], #96
1000d3734:     	ret
1000d3738:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d386c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d386c:     	stp	x28, x27, [sp, #-96]!
1000d3870:     	stp	x26, x25, [sp, #16]
1000d3874:     	stp	x24, x23, [sp, #32]
1000d3878:     	stp	x22, x21, [sp, #48]
1000d387c:     	stp	x20, x19, [sp, #64]
1000d3880:     	stp	x29, x30, [sp, #80]
1000d3884:     	add	x29, sp, #80
1000d3888:     	sub	sp, sp, #704
1000d388c:     	str	x3, [sp]
1000d3890:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d3894:     	ldr	x8, [x8, #392]
1000d3898:     	ldr	x8, [x8]
1000d389c:     	stur	x8, [x29, #-96]
1000d38a0:     	movi.2d	v0, #0000000000000000
1000d38a4:     	stp	q0, q0, [sp, #656]
1000d38a8:     	lsl	x8, x2, #1
1000d38ac:     	stp	q0, q0, [sp, #624]
1000d38b0:     	stp	q0, q0, [sp, #592]
1000d38b4:     	stp	q0, q0, [sp, #560]
1000d38b8:     	stp	q0, q0, [sp, #528]
1000d38bc:     	stp	q0, q0, [sp, #496]
1000d38c0:     	stp	q0, q0, [sp, #464]
1000d38c4:     	stp	q0, q0, [sp, #432]
1000d38c8:     	stp	q0, q0, [sp, #400]
1000d38cc:     	stp	q0, q0, [sp, #368]
1000d38d0:     	stp	q0, q0, [sp, #336]
1000d38d4:     	stp	q0, q0, [sp, #304]
1000d38d8:     	stp	q0, q0, [sp, #272]
1000d38dc:     	stp	q0, q0, [sp, #240]
1000d38e0:     	stp	q0, q0, [sp, #208]
1000d38e4:     	stp	q0, q0, [sp, #176]
1000d38e8:     	ands	x8, x8, #0xfffffffffffffffc
1000d38ec:     	b.eq	0x1000d3bc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d38f0:     	add	x8, x1, x8
1000d38f4:     	str	x8, [sp, #8]
1000d38f8:     	add	x8, sp, #176
1000d38fc:     	add	x27, x8, #256
1000d3900:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d3904:     	add	x11, x11, #1980
1000d3908:     	mov	x12, #0
1000d390c:     	ldp	w8, w9, [x1]
1000d3910:     	ubfx	x10, x8, #8, #4
1000d3914:     	str	x10, [sp, #168]
1000d3918:     	ubfx	x10, x8, #16, #4
1000d391c:     	str	x10, [sp, #160]
1000d3920:     	ubfx	x10, x8, #24, #4
1000d3924:     	str	x10, [sp, #152]
1000d3928:     	ldp	w10, w17, [x1, #8]
1000d392c:     	str	x1, [sp, #16]
1000d3930:     	and	x14, x8, #0xf
1000d3934:     	ubfx	x13, x8, #4, #4
1000d3938:     	stp	x13, x14, [sp, #136]
1000d393c:     	ubfx	x14, x8, #12, #4
1000d3940:     	ubfx	x13, x8, #20, #4
1000d3944:     	stp	x13, x14, [sp, #120]
1000d3948:     	lsr	x8, x8, #28
1000d394c:     	str	x8, [sp, #112]
1000d3950:     	and	x8, x9, #0xf
1000d3954:     	str	x8, [sp, #104]
1000d3958:     	ubfx	x8, x9, #8, #4
1000d395c:     	str	x8, [sp, #96]
1000d3960:     	ubfx	x8, x9, #16, #4
1000d3964:     	str	x8, [sp, #88]
1000d3968:     	ubfx	x8, x9, #24, #4
1000d396c:     	str	x8, [sp, #80]
1000d3970:     	ubfx	x8, x9, #4, #4
1000d3974:     	str	x8, [sp, #72]
1000d3978:     	ubfx	x8, x9, #12, #4
1000d397c:     	str	x8, [sp, #64]
1000d3980:     	ubfx	x8, x9, #20, #4
1000d3984:     	str	x8, [sp, #56]
1000d3988:     	lsr	x8, x9, #28
1000d398c:     	str	x8, [sp, #48]
1000d3990:     	and	x9, x10, #0xf
1000d3994:     	ubfx	x8, x10, #8, #4
1000d3998:     	stp	x8, x9, [sp, #32]
1000d399c:     	ubfx	x8, x10, #16, #4
1000d39a0:     	str	x8, [sp, #24]
1000d39a4:     	ubfx	x28, x10, #24, #4
1000d39a8:     	ubfx	x30, x10, #4, #4
1000d39ac:     	ubfx	x3, x10, #12, #4
1000d39b0:     	ubfx	x8, x10, #20, #4
1000d39b4:     	lsr	x9, x10, #28
1000d39b8:     	and	x1, x17, #0xf
1000d39bc:     	ubfx	x10, x17, #8, #4
1000d39c0:     	ubfx	x13, x17, #16, #4
1000d39c4:     	ubfx	x26, x17, #24, #4
1000d39c8:     	ubfx	x14, x17, #4, #4
1000d39cc:     	ubfx	x15, x17, #12, #4
1000d39d0:     	ubfx	x16, x17, #20, #4
1000d39d4:     	lsr	x17, x17, #28
1000d39d8:     	ldr	w20, [x0, x12]
1000d39dc:     	lsl	w2, w20, #4
1000d39e0:     	and	x2, x2, #0xf0
1000d39e4:     	add	x5, x11, x2
1000d39e8:     	and	x2, x20, #0xf0
1000d39ec:     	add	x2, x11, x2
1000d39f0:     	lsr	x4, x20, #4
1000d39f4:     	and	x4, x4, #0xf0
1000d39f8:     	add	x7, x11, x4
1000d39fc:     	lsr	x4, x20, #8
1000d3a00:     	and	x4, x4, #0xf0
1000d3a04:     	add	x4, x11, x4
1000d3a08:     	lsr	x6, x20, #12
1000d3a0c:     	and	x6, x6, #0xf0
1000d3a10:     	add	x19, x11, x6
1000d3a14:     	lsr	x6, x20, #16
1000d3a18:     	and	x6, x6, #0xf0
1000d3a1c:     	add	x6, x11, x6
1000d3a20:     	lsr	x21, x20, #20
1000d3a24:     	and	x21, x21, #0xf0
1000d3a28:     	add	x21, x11, x21
1000d3a2c:     	lsr	x20, x20, #24
1000d3a30:     	and	x20, x20, #0xf0
1000d3a34:     	ldr	x22, [sp, #144]
1000d3a38:     	ldrsb	w22, [x5, x22]
1000d3a3c:     	add	x20, x11, x20
1000d3a40:     	ldp	x24, x23, [sp, #160]
1000d3a44:     	ldrsb	w23, [x7, x23]
1000d3a48:     	ldrsb	w24, [x19, x24]
1000d3a4c:     	add	w22, w22, w23
1000d3a50:     	add	w22, w22, w24
1000d3a54:     	ldr	x23, [sp, #152]
1000d3a58:     	ldrsb	w23, [x21, x23]
1000d3a5c:     	ldr	x24, [sp, #136]
1000d3a60:     	ldrsb	w24, [x2, x24]
1000d3a64:     	add	w22, w22, w23
1000d3a68:     	add	w22, w22, w24
1000d3a6c:     	ldp	x24, x23, [sp, #120]
1000d3a70:     	ldrsb	w23, [x4, x23]
1000d3a74:     	ldrsb	w24, [x6, x24]
1000d3a78:     	add	w22, w22, w23
1000d3a7c:     	add	w22, w22, w24
1000d3a80:     	ldr	x23, [sp, #112]
1000d3a84:     	ldrsb	w23, [x20, x23]
1000d3a88:     	add	w22, w22, w23
1000d3a8c:     	scvtf	s0, w22
1000d3a90:     	ldp	x23, x22, [sp, #96]
1000d3a94:     	ldrsb	w22, [x5, x22]
1000d3a98:     	ldrsb	w23, [x7, x23]
1000d3a9c:     	ldp	x25, x24, [sp, #80]
1000d3aa0:     	ldrsb	w24, [x19, x24]
1000d3aa4:     	ldrsb	w25, [x21, x25]
1000d3aa8:     	add	w22, w22, w23
1000d3aac:     	ldr	x23, [sp, #72]
1000d3ab0:     	ldrsb	w23, [x2, x23]
1000d3ab4:     	add	w22, w22, w24
1000d3ab8:     	ldr	x24, [sp, #64]
1000d3abc:     	ldrsb	w24, [x4, x24]
1000d3ac0:     	add	w22, w22, w25
1000d3ac4:     	ldr	x25, [sp, #56]
1000d3ac8:     	ldrsb	w25, [x6, x25]
1000d3acc:     	add	w22, w22, w23
1000d3ad0:     	add	w22, w22, w24
1000d3ad4:     	add	w22, w22, w25
1000d3ad8:     	ldr	x23, [sp, #48]
1000d3adc:     	ldrsb	w23, [x20, x23]
1000d3ae0:     	add	w22, w22, w23
1000d3ae4:     	scvtf	s1, w22
1000d3ae8:     	ldp	x23, x22, [sp, #32]
1000d3aec:     	ldrsb	w22, [x5, x22]
1000d3af0:     	ldrsb	w23, [x7, x23]
1000d3af4:     	ldr	x24, [sp, #24]
1000d3af8:     	ldrsb	w24, [x19, x24]
1000d3afc:     	add	w22, w22, w23
1000d3b00:     	ldrsb	w23, [x21, x28]
1000d3b04:     	add	w22, w22, w24
1000d3b08:     	ldrsb	w24, [x2, x30]
1000d3b0c:     	add	w22, w22, w23
1000d3b10:     	ldrsb	w23, [x4, x3]
1000d3b14:     	add	w22, w22, w24
1000d3b18:     	ldrsb	w24, [x6, x8]
1000d3b1c:     	add	w22, w22, w23
1000d3b20:     	ldrsb	w23, [x20, x9]
1000d3b24:     	add	w22, w22, w24
1000d3b28:     	add	w22, w22, w23
1000d3b2c:     	scvtf	s2, w22
1000d3b30:     	ldrsb	w5, [x5, x1]
1000d3b34:     	ldrsb	w7, [x7, x10]
1000d3b38:     	ldrsb	w19, [x19, x13]
1000d3b3c:     	add	w5, w5, w7
1000d3b40:     	add	w5, w5, w19
1000d3b44:     	ldrsb	w7, [x21, x26]
1000d3b48:     	ldrsb	w2, [x2, x14]
1000d3b4c:     	add	w5, w5, w7
1000d3b50:     	add	w2, w5, w2
1000d3b54:     	ldrsb	w4, [x4, x15]
1000d3b58:     	ldrsb	w5, [x6, x16]
1000d3b5c:     	add	w2, w2, w4
1000d3b60:     	add	w2, w2, w5
1000d3b64:     	ldrsb	w4, [x20, x17]
1000d3b68:     	add	w2, w2, w4
1000d3b6c:     	add	x4, sp, #176
1000d3b70:     	scvtf	s3, w2
1000d3b74:     	add	x2, x27, x12
1000d3b78:     	ldur	s4, [x2, #-128]
1000d3b7c:     	fadd	s1, s4, s1
1000d3b80:     	stur	s1, [x2, #-128]
1000d3b84:     	ldr	s1, [x2]
1000d3b88:     	fadd	s1, s1, s2
1000d3b8c:     	str	s1, [x2]
1000d3b90:     	ldr	s1, [x2, #128]
1000d3b94:     	fadd	s1, s1, s3
1000d3b98:     	ldr	s2, [x4, x12]
1000d3b9c:     	str	s1, [x2, #128]
1000d3ba0:     	fadd	s0, s2, s0
1000d3ba4:     	str	s0, [x4, x12]
1000d3ba8:     	add	x12, x12, #4
1000d3bac:     	cmp	x12, #128
1000d3bb0:     	b.ne	0x1000d39d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d3bb4:     	add	x0, x0, #128
1000d3bb8:     	ldp	x8, x1, [sp, #8]
1000d3bbc:     	add	x1, x1, #16
1000d3bc0:     	cmp	x1, x8
1000d3bc4:     	b.ne	0x1000d3908 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d3bc8:     	add	x1, sp, #176
1000d3bcc:     	ldr	x0, [sp]
1000d3bd0:     	mov	w2, #512
1000d3bd4:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d3bd8:     	ldur	x8, [x29, #-96]
1000d3bdc:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 8ul, false>(char const*)+0x22c>
1000d3be0:     	ldr	x9, [x9, #392]
1000d3be4:     	ldr	x9, [x9]
1000d3be8:     	cmp	x9, x8
1000d3bec:     	b.ne	0x1000d3c10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d3bf0:     	add	sp, sp, #704
1000d3bf4:     	ldp	x29, x30, [sp, #80]
1000d3bf8:     	ldp	x20, x19, [sp, #64]
1000d3bfc:     	ldp	x22, x21, [sp, #48]
1000d3c00:     	ldp	x24, x23, [sp, #32]
1000d3c04:     	ldp	x26, x25, [sp, #16]
1000d3c08:     	ldp	x28, x27, [sp], #96
1000d3c0c:     	ret
1000d3c10:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d5874 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5874:     	stp	x28, x27, [sp, #-96]!
1000d5878:     	stp	x26, x25, [sp, #16]
1000d587c:     	stp	x24, x23, [sp, #32]
1000d5880:     	stp	x22, x21, [sp, #48]
1000d5884:     	stp	x20, x19, [sp, #64]
1000d5888:     	stp	x29, x30, [sp, #80]
1000d588c:     	add	x29, sp, #80
1000d5890:     	sub	sp, sp, #1488
1000d5894:     	str	x3, [sp]
1000d5898:     	mov	x20, x1
1000d589c:     	mov	x22, x0
1000d58a0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d58a4:     	ldr	x8, [x8, #392]
1000d58a8:     	ldr	x8, [x8]
1000d58ac:     	stur	x8, [x29, #-96]
1000d58b0:     	lsl	x8, x2, #2
1000d58b4:     	and	x19, x8, #0xfffffffffffffff8
1000d58b8:     	add	x0, sp, #448
1000d58bc:     	mov	w1, #1024
1000d58c0:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d58c4:     	cbz	x19, 0x1000d5df0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d58c8:     	add	x8, x20, x19
1000d58cc:     	str	x8, [sp, #8]
1000d58d0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d58d4:     	add	x9, x9, #1724
1000d58d8:     	mov	x10, #0
1000d58dc:     	ldp	w8, w11, [x20]
1000d58e0:     	ubfx	x13, x8, #8, #4
1000d58e4:     	ubfx	x12, x8, #16, #4
1000d58e8:     	stp	x12, x13, [sp, #432]
1000d58ec:     	ubfx	x15, x8, #24, #4
1000d58f0:     	ldp	w12, w13, [x20, #8]
1000d58f4:     	and	x14, x8, #0xf
1000d58f8:     	stp	x14, x15, [sp, #416]
1000d58fc:     	ubfx	x15, x8, #4, #4
1000d5900:     	ubfx	x14, x8, #12, #4
1000d5904:     	stp	x14, x15, [sp, #400]
1000d5908:     	ubfx	x14, x8, #20, #4
1000d590c:     	lsr	x8, x8, #28
1000d5910:     	stp	x8, x14, [sp, #384]
1000d5914:     	and	x8, x11, #0xf
1000d5918:     	str	x8, [sp, #376]
1000d591c:     	ubfx	x8, x11, #8, #4
1000d5920:     	str	x8, [sp, #368]
1000d5924:     	ubfx	x8, x11, #16, #4
1000d5928:     	str	x8, [sp, #360]
1000d592c:     	ubfx	x8, x11, #24, #4
1000d5930:     	str	x8, [sp, #352]
1000d5934:     	ubfx	x8, x11, #4, #4
1000d5938:     	str	x8, [sp, #344]
1000d593c:     	ubfx	x8, x11, #12, #4
1000d5940:     	str	x8, [sp, #336]
1000d5944:     	ubfx	x8, x11, #20, #4
1000d5948:     	str	x8, [sp, #328]
1000d594c:     	lsr	x8, x11, #28
1000d5950:     	str	x8, [sp, #320]
1000d5954:     	and	x11, x12, #0xf
1000d5958:     	ubfx	x8, x12, #8, #4
1000d595c:     	stp	x8, x11, [sp, #304]
1000d5960:     	ubfx	x11, x12, #16, #4
1000d5964:     	ubfx	x8, x12, #24, #4
1000d5968:     	stp	x8, x11, [sp, #288]
1000d596c:     	ubfx	x11, x12, #4, #4
1000d5970:     	ubfx	x8, x12, #12, #4
1000d5974:     	stp	x8, x11, [sp, #272]
1000d5978:     	ubfx	x11, x12, #20, #4
1000d597c:     	lsr	x8, x12, #28
1000d5980:     	stp	x8, x11, [sp, #256]
1000d5984:     	and	x11, x13, #0xf
1000d5988:     	ubfx	x8, x13, #8, #4
1000d598c:     	stp	x8, x11, [sp, #240]
1000d5990:     	ubfx	x11, x13, #16, #4
1000d5994:     	ubfx	x8, x13, #24, #4
1000d5998:     	stp	x8, x11, [sp, #224]
1000d599c:     	ubfx	x11, x13, #4, #4
1000d59a0:     	ubfx	x8, x13, #12, #4
1000d59a4:     	stp	x8, x11, [sp, #208]
1000d59a8:     	ubfx	x11, x13, #20, #4
1000d59ac:     	lsr	x8, x13, #28
1000d59b0:     	stp	x8, x11, [sp, #192]
1000d59b4:     	ldp	w8, w11, [x20, #16]
1000d59b8:     	and	x13, x8, #0xf
1000d59bc:     	ubfx	x12, x8, #8, #4
1000d59c0:     	stp	x12, x13, [sp, #176]
1000d59c4:     	ubfx	x13, x8, #16, #4
1000d59c8:     	ubfx	x12, x8, #24, #4
1000d59cc:     	stp	x12, x13, [sp, #160]
1000d59d0:     	ubfx	x13, x8, #4, #4
1000d59d4:     	ubfx	x12, x8, #12, #4
1000d59d8:     	stp	x12, x13, [sp, #144]
1000d59dc:     	ubfx	x12, x8, #20, #4
1000d59e0:     	lsr	x8, x8, #28
1000d59e4:     	stp	x8, x12, [sp, #128]
1000d59e8:     	and	x8, x11, #0xf
1000d59ec:     	str	x8, [sp, #120]
1000d59f0:     	ubfx	x8, x11, #8, #4
1000d59f4:     	str	x8, [sp, #112]
1000d59f8:     	ubfx	x8, x11, #16, #4
1000d59fc:     	str	x8, [sp, #104]
1000d5a00:     	ubfx	x8, x11, #24, #4
1000d5a04:     	str	x8, [sp, #96]
1000d5a08:     	ubfx	x8, x11, #4, #4
1000d5a0c:     	str	x8, [sp, #88]
1000d5a10:     	ubfx	x8, x11, #12, #4
1000d5a14:     	str	x8, [sp, #80]
1000d5a18:     	ubfx	x8, x11, #20, #4
1000d5a1c:     	str	x8, [sp, #72]
1000d5a20:     	lsr	x8, x11, #28
1000d5a24:     	str	x8, [sp, #64]
1000d5a28:     	ldp	w13, w2, [x20, #24]
1000d5a2c:     	and	x11, x13, #0xf
1000d5a30:     	ubfx	x8, x13, #8, #4
1000d5a34:     	stp	x8, x11, [sp, #48]
1000d5a38:     	ubfx	x11, x13, #16, #4
1000d5a3c:     	ubfx	x8, x13, #24, #4
1000d5a40:     	stp	x8, x11, [sp, #32]
1000d5a44:     	ubfx	x8, x13, #4, #4
1000d5a48:     	stp	x20, x8, [sp, #16]
1000d5a4c:     	ubfx	x11, x13, #12, #4
1000d5a50:     	ubfx	x12, x13, #20, #4
1000d5a54:     	lsr	x13, x13, #28
1000d5a58:     	and	x14, x2, #0xf
1000d5a5c:     	ubfx	x21, x2, #8, #4
1000d5a60:     	ubfx	x15, x2, #16, #4
1000d5a64:     	ubfx	x16, x2, #24, #4
1000d5a68:     	ubfx	x17, x2, #4, #4
1000d5a6c:     	ubfx	x0, x2, #12, #4
1000d5a70:     	ubfx	x1, x2, #20, #4
1000d5a74:     	lsr	x2, x2, #28
1000d5a78:     	ldr	w25, [x22, x10]
1000d5a7c:     	lsl	w3, w25, #4
1000d5a80:     	and	x3, x3, #0xf0
1000d5a84:     	add	x3, x9, x3
1000d5a88:     	ldr	x8, [sp, #416]
1000d5a8c:     	ldrb	w26, [x3, x8]
1000d5a90:     	lsr	x4, x25, #4
1000d5a94:     	and	x4, x4, #0xf0
1000d5a98:     	add	x4, x9, x4
1000d5a9c:     	ldr	x8, [sp, #440]
1000d5aa0:     	ldrb	w27, [x4, x8]
1000d5aa4:     	lsr	x5, x25, #12
1000d5aa8:     	and	x5, x5, #0xf0
1000d5aac:     	add	x5, x9, x5
1000d5ab0:     	ldr	x8, [sp, #432]
1000d5ab4:     	ldrb	w28, [x5, x8]
1000d5ab8:     	lsr	x6, x25, #20
1000d5abc:     	and	x6, x6, #0xf0
1000d5ac0:     	add	x7, x9, x6
1000d5ac4:     	ldr	x8, [sp, #424]
1000d5ac8:     	ldrb	w30, [x7, x8]
1000d5acc:     	and	x6, x25, #0xf0
1000d5ad0:     	add	x6, x9, x6
1000d5ad4:     	ldr	x8, [sp, #408]
1000d5ad8:     	ldrb	w19, [x6, x8]
1000d5adc:     	lsr	x23, x25, #8
1000d5ae0:     	and	x23, x23, #0xf0
1000d5ae4:     	add	x23, x9, x23
1000d5ae8:     	ldp	x20, x8, [sp, #392]
1000d5aec:     	ldrb	w8, [x23, x8]
1000d5af0:     	lsr	x24, x25, #16
1000d5af4:     	and	x24, x24, #0xf0
1000d5af8:     	add	x24, x9, x24
1000d5afc:     	ldrb	w20, [x24, x20]
1000d5b00:     	lsr	x25, x25, #24
1000d5b04:     	and	x25, x25, #0xf0
1000d5b08:     	add	x25, x9, x25
1000d5b0c:     	add	w26, w26, w27
1000d5b10:     	ldr	x27, [sp, #384]
1000d5b14:     	ldrb	w27, [x25, x27]
1000d5b18:     	add	w26, w26, w28
1000d5b1c:     	add	w26, w26, w30
1000d5b20:     	add	w19, w26, w19
1000d5b24:     	add	w8, w19, w8
1000d5b28:     	add	w8, w8, w20
1000d5b2c:     	add	w8, w8, w27
1000d5b30:     	scvtf	s0, w8
1000d5b34:     	ldp	x19, x8, [sp, #368]
1000d5b38:     	ldrb	w8, [x3, x8]
1000d5b3c:     	ldrb	w19, [x4, x19]
1000d5b40:     	ldp	x26, x20, [sp, #352]
1000d5b44:     	ldrb	w20, [x5, x20]
1000d5b48:     	ldrb	w26, [x7, x26]
1000d5b4c:     	ldp	x28, x27, [sp, #336]
1000d5b50:     	ldrb	w27, [x6, x27]
1000d5b54:     	ldrb	w28, [x23, x28]
1000d5b58:     	add	w8, w8, w19
1000d5b5c:     	ldr	x19, [sp, #328]
1000d5b60:     	ldrb	w19, [x24, x19]
1000d5b64:     	add	w8, w8, w20
1000d5b68:     	add	w8, w8, w26
1000d5b6c:     	ldr	x20, [sp, #320]
1000d5b70:     	ldrb	w20, [x25, x20]
1000d5b74:     	add	w8, w8, w27
1000d5b78:     	add	w8, w8, w28
1000d5b7c:     	add	w8, w8, w19
1000d5b80:     	add	w8, w8, w20
1000d5b84:     	scvtf	s1, w8
1000d5b88:     	ldp	x19, x8, [sp, #304]
1000d5b8c:     	ldrb	w8, [x3, x8]
1000d5b90:     	ldrb	w19, [x4, x19]
1000d5b94:     	ldp	x26, x20, [sp, #288]
1000d5b98:     	ldrb	w20, [x5, x20]
1000d5b9c:     	ldrb	w26, [x7, x26]
1000d5ba0:     	ldr	x27, [sp, #280]
1000d5ba4:     	ldrb	w27, [x6, x27]
1000d5ba8:     	add	w8, w8, w19
1000d5bac:     	ldr	x19, [sp, #272]
1000d5bb0:     	ldrb	w19, [x23, x19]
1000d5bb4:     	add	w8, w8, w20
1000d5bb8:     	ldr	x20, [sp, #264]
1000d5bbc:     	ldrb	w20, [x24, x20]
1000d5bc0:     	add	w8, w8, w26
1000d5bc4:     	ldr	x26, [sp, #256]
1000d5bc8:     	ldrb	w26, [x25, x26]
1000d5bcc:     	add	w8, w8, w27
1000d5bd0:     	add	w8, w8, w19
1000d5bd4:     	add	w8, w8, w20
1000d5bd8:     	add	w8, w8, w26
1000d5bdc:     	scvtf	s2, w8
1000d5be0:     	ldp	x19, x8, [sp, #240]
1000d5be4:     	ldrb	w8, [x3, x8]
1000d5be8:     	ldrb	w19, [x4, x19]
1000d5bec:     	ldp	x26, x20, [sp, #224]
1000d5bf0:     	ldrb	w20, [x5, x20]
1000d5bf4:     	ldrb	w26, [x7, x26]
1000d5bf8:     	add	w8, w8, w19
1000d5bfc:     	ldr	x19, [sp, #216]
1000d5c00:     	ldrb	w19, [x6, x19]
1000d5c04:     	add	w8, w8, w20
1000d5c08:     	ldr	x20, [sp, #208]
1000d5c0c:     	ldrb	w20, [x23, x20]
1000d5c10:     	add	w8, w8, w26
1000d5c14:     	ldr	x26, [sp, #200]
1000d5c18:     	ldrb	w26, [x24, x26]
1000d5c1c:     	add	w8, w8, w19
1000d5c20:     	ldr	x19, [sp, #192]
1000d5c24:     	ldrb	w19, [x25, x19]
1000d5c28:     	add	w8, w8, w20
1000d5c2c:     	add	w8, w8, w26
1000d5c30:     	add	w8, w8, w19
1000d5c34:     	scvtf	s3, w8
1000d5c38:     	ldp	x19, x8, [sp, #176]
1000d5c3c:     	ldrb	w8, [x3, x8]
1000d5c40:     	ldrb	w19, [x4, x19]
1000d5c44:     	ldp	x26, x20, [sp, #160]
1000d5c48:     	ldrb	w20, [x5, x20]
1000d5c4c:     	ldrb	w26, [x7, x26]
1000d5c50:     	add	w8, w8, w19
1000d5c54:     	add	w8, w8, w20
1000d5c58:     	ldp	x20, x19, [sp, #144]
1000d5c5c:     	ldrb	w19, [x6, x19]
1000d5c60:     	ldrb	w20, [x23, x20]
1000d5c64:     	add	w8, w8, w26
1000d5c68:     	add	w8, w8, w19
1000d5c6c:     	ldp	x26, x19, [sp, #128]
1000d5c70:     	ldrb	w19, [x24, x19]
1000d5c74:     	ldrb	w26, [x25, x26]
1000d5c78:     	add	w8, w8, w20
1000d5c7c:     	add	w8, w8, w19
1000d5c80:     	add	w8, w8, w26
1000d5c84:     	scvtf	s4, w8
1000d5c88:     	ldp	x19, x8, [sp, #112]
1000d5c8c:     	ldrb	w8, [x3, x8]
1000d5c90:     	ldrb	w19, [x4, x19]
1000d5c94:     	ldr	x20, [sp, #104]
1000d5c98:     	ldrb	w20, [x5, x20]
1000d5c9c:     	add	w8, w8, w19
1000d5ca0:     	add	w8, w8, w20
1000d5ca4:     	ldp	x20, x19, [sp, #88]
1000d5ca8:     	ldrb	w19, [x7, x19]
1000d5cac:     	ldrb	w20, [x6, x20]
1000d5cb0:     	add	w8, w8, w19
1000d5cb4:     	add	w8, w8, w20
1000d5cb8:     	ldp	x20, x19, [sp, #72]
1000d5cbc:     	ldrb	w19, [x23, x19]
1000d5cc0:     	ldrb	w20, [x24, x20]
1000d5cc4:     	add	w8, w8, w19
1000d5cc8:     	add	w8, w8, w20
1000d5ccc:     	ldr	x19, [sp, #64]
1000d5cd0:     	ldrb	w19, [x25, x19]
1000d5cd4:     	add	w8, w8, w19
1000d5cd8:     	scvtf	s5, w8
1000d5cdc:     	ldp	x19, x8, [sp, #48]
1000d5ce0:     	ldrb	w8, [x3, x8]
1000d5ce4:     	ldrb	w19, [x4, x19]
1000d5ce8:     	ldp	x26, x20, [sp, #32]
1000d5cec:     	ldrb	w20, [x5, x20]
1000d5cf0:     	ldrb	w26, [x7, x26]
1000d5cf4:     	add	w8, w8, w19
1000d5cf8:     	ldr	x19, [sp, #24]
1000d5cfc:     	ldrb	w19, [x6, x19]
1000d5d00:     	add	w8, w8, w20
1000d5d04:     	ldrb	w20, [x23, x11]
1000d5d08:     	add	w8, w8, w26
1000d5d0c:     	ldrb	w26, [x24, x12]
1000d5d10:     	add	w8, w8, w19
1000d5d14:     	add	w8, w8, w20
1000d5d18:     	add	w8, w8, w26
1000d5d1c:     	ldrb	w19, [x25, x13]
1000d5d20:     	add	w8, w8, w19
1000d5d24:     	scvtf	s6, w8
1000d5d28:     	ldrb	w8, [x3, x14]
1000d5d2c:     	ldrb	w3, [x4, x21]
1000d5d30:     	ldrb	w4, [x5, x15]
1000d5d34:     	add	w8, w8, w3
1000d5d38:     	add	w8, w8, w4
1000d5d3c:     	ldrb	w3, [x7, x16]
1000d5d40:     	ldrb	w4, [x6, x17]
1000d5d44:     	add	w8, w8, w3
1000d5d48:     	add	w8, w8, w4
1000d5d4c:     	ldrb	w3, [x23, x0]
1000d5d50:     	add	x5, sp, #448
1000d5d54:     	ldrb	w4, [x24, x1]
1000d5d58:     	add	w8, w8, w3
1000d5d5c:     	add	w8, w8, w4
1000d5d60:     	ldrb	w3, [x25, x2]
1000d5d64:     	add	w8, w8, w3
1000d5d68:     	scvtf	s7, w8
1000d5d6c:     	add	x8, x5, x10
1000d5d70:     	ldr	s16, [x8]
1000d5d74:     	fadd	s0, s16, s0
1000d5d78:     	str	s0, [x8]
1000d5d7c:     	ldr	s0, [x8, #128]
1000d5d80:     	fadd	s0, s0, s1
1000d5d84:     	str	s0, [x8, #128]
1000d5d88:     	ldr	s0, [x8, #256]
1000d5d8c:     	fadd	s0, s0, s2
1000d5d90:     	str	s0, [x8, #256]
1000d5d94:     	ldr	s0, [x8, #384]
1000d5d98:     	fadd	s0, s0, s3
1000d5d9c:     	str	s0, [x8, #384]
1000d5da0:     	ldr	s0, [x8, #512]
1000d5da4:     	fadd	s0, s0, s4
1000d5da8:     	str	s0, [x8, #512]
1000d5dac:     	ldr	s0, [x8, #640]
1000d5db0:     	fadd	s0, s0, s5
1000d5db4:     	str	s0, [x8, #640]
1000d5db8:     	ldr	s0, [x8, #768]
1000d5dbc:     	fadd	s0, s0, s6
1000d5dc0:     	ldr	s1, [x8, #896]
1000d5dc4:     	fadd	s1, s1, s7
1000d5dc8:     	str	s0, [x8, #768]
1000d5dcc:     	str	s1, [x8, #896]
1000d5dd0:     	add	x10, x10, #4
1000d5dd4:     	cmp	x10, #128
1000d5dd8:     	b.ne	0x1000d5a78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d5ddc:     	add	x22, x22, #128
1000d5de0:     	ldp	x8, x20, [sp, #8]
1000d5de4:     	add	x20, x20, #32
1000d5de8:     	cmp	x20, x8
1000d5dec:     	b.ne	0x1000d58d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d5df0:     	add	x1, sp, #448
1000d5df4:     	ldr	x0, [sp]
1000d5df8:     	mov	w2, #1024
1000d5dfc:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d5e00:     	ldur	x8, [x29, #-96]
1000d5e04:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000d5e08:     	ldr	x9, [x9, #392]
1000d5e0c:     	ldr	x9, [x9]
1000d5e10:     	cmp	x9, x8
1000d5e14:     	b.ne	0x1000d5e38 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d5e18:     	add	sp, sp, #1488
1000d5e1c:     	ldp	x29, x30, [sp, #80]
1000d5e20:     	ldp	x20, x19, [sp, #64]
1000d5e24:     	ldp	x22, x21, [sp, #48]
1000d5e28:     	ldp	x24, x23, [sp, #32]
1000d5e2c:     	ldp	x26, x25, [sp, #16]
1000d5e30:     	ldp	x28, x27, [sp], #96
1000d5e34:     	ret
1000d5e38:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d5fb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5fb0:     	stp	x28, x27, [sp, #-96]!
1000d5fb4:     	stp	x26, x25, [sp, #16]
1000d5fb8:     	stp	x24, x23, [sp, #32]
1000d5fbc:     	stp	x22, x21, [sp, #48]
1000d5fc0:     	stp	x20, x19, [sp, #64]
1000d5fc4:     	stp	x29, x30, [sp, #80]
1000d5fc8:     	add	x29, sp, #80
1000d5fcc:     	sub	sp, sp, #1488
1000d5fd0:     	str	x3, [sp]
1000d5fd4:     	mov	x20, x1
1000d5fd8:     	mov	x22, x0
1000d5fdc:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d5fe0:     	ldr	x8, [x8, #392]
1000d5fe4:     	ldr	x8, [x8]
1000d5fe8:     	stur	x8, [x29, #-96]
1000d5fec:     	lsl	x8, x2, #2
1000d5ff0:     	and	x19, x8, #0xfffffffffffffff8
1000d5ff4:     	add	x0, sp, #448
1000d5ff8:     	mov	w1, #1024
1000d5ffc:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d6000:     	cbz	x19, 0x1000d652c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d6004:     	add	x8, x20, x19
1000d6008:     	str	x8, [sp, #8]
1000d600c:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d6010:     	add	x9, x9, #1980
1000d6014:     	mov	x10, #0
1000d6018:     	ldp	w8, w11, [x20]
1000d601c:     	ubfx	x13, x8, #8, #4
1000d6020:     	ubfx	x12, x8, #16, #4
1000d6024:     	stp	x12, x13, [sp, #432]
1000d6028:     	ubfx	x15, x8, #24, #4
1000d602c:     	ldp	w12, w13, [x20, #8]
1000d6030:     	and	x14, x8, #0xf
1000d6034:     	stp	x14, x15, [sp, #416]
1000d6038:     	ubfx	x15, x8, #4, #4
1000d603c:     	ubfx	x14, x8, #12, #4
1000d6040:     	stp	x14, x15, [sp, #400]
1000d6044:     	ubfx	x14, x8, #20, #4
1000d6048:     	lsr	x8, x8, #28
1000d604c:     	stp	x8, x14, [sp, #384]
1000d6050:     	and	x8, x11, #0xf
1000d6054:     	str	x8, [sp, #376]
1000d6058:     	ubfx	x8, x11, #8, #4
1000d605c:     	str	x8, [sp, #368]
1000d6060:     	ubfx	x8, x11, #16, #4
1000d6064:     	str	x8, [sp, #360]
1000d6068:     	ubfx	x8, x11, #24, #4
1000d606c:     	str	x8, [sp, #352]
1000d6070:     	ubfx	x8, x11, #4, #4
1000d6074:     	str	x8, [sp, #344]
1000d6078:     	ubfx	x8, x11, #12, #4
1000d607c:     	str	x8, [sp, #336]
1000d6080:     	ubfx	x8, x11, #20, #4
1000d6084:     	str	x8, [sp, #328]
1000d6088:     	lsr	x8, x11, #28
1000d608c:     	str	x8, [sp, #320]
1000d6090:     	and	x11, x12, #0xf
1000d6094:     	ubfx	x8, x12, #8, #4
1000d6098:     	stp	x8, x11, [sp, #304]
1000d609c:     	ubfx	x11, x12, #16, #4
1000d60a0:     	ubfx	x8, x12, #24, #4
1000d60a4:     	stp	x8, x11, [sp, #288]
1000d60a8:     	ubfx	x11, x12, #4, #4
1000d60ac:     	ubfx	x8, x12, #12, #4
1000d60b0:     	stp	x8, x11, [sp, #272]
1000d60b4:     	ubfx	x11, x12, #20, #4
1000d60b8:     	lsr	x8, x12, #28
1000d60bc:     	stp	x8, x11, [sp, #256]
1000d60c0:     	and	x11, x13, #0xf
1000d60c4:     	ubfx	x8, x13, #8, #4
1000d60c8:     	stp	x8, x11, [sp, #240]
1000d60cc:     	ubfx	x11, x13, #16, #4
1000d60d0:     	ubfx	x8, x13, #24, #4
1000d60d4:     	stp	x8, x11, [sp, #224]
1000d60d8:     	ubfx	x11, x13, #4, #4
1000d60dc:     	ubfx	x8, x13, #12, #4
1000d60e0:     	stp	x8, x11, [sp, #208]
1000d60e4:     	ubfx	x11, x13, #20, #4
1000d60e8:     	lsr	x8, x13, #28
1000d60ec:     	stp	x8, x11, [sp, #192]
1000d60f0:     	ldp	w8, w11, [x20, #16]
1000d60f4:     	and	x13, x8, #0xf
1000d60f8:     	ubfx	x12, x8, #8, #4
1000d60fc:     	stp	x12, x13, [sp, #176]
1000d6100:     	ubfx	x13, x8, #16, #4
1000d6104:     	ubfx	x12, x8, #24, #4
1000d6108:     	stp	x12, x13, [sp, #160]
1000d610c:     	ubfx	x13, x8, #4, #4
1000d6110:     	ubfx	x12, x8, #12, #4
1000d6114:     	stp	x12, x13, [sp, #144]
1000d6118:     	ubfx	x12, x8, #20, #4
1000d611c:     	lsr	x8, x8, #28
1000d6120:     	stp	x8, x12, [sp, #128]
1000d6124:     	and	x8, x11, #0xf
1000d6128:     	str	x8, [sp, #120]
1000d612c:     	ubfx	x8, x11, #8, #4
1000d6130:     	str	x8, [sp, #112]
1000d6134:     	ubfx	x8, x11, #16, #4
1000d6138:     	str	x8, [sp, #104]
1000d613c:     	ubfx	x8, x11, #24, #4
1000d6140:     	str	x8, [sp, #96]
1000d6144:     	ubfx	x8, x11, #4, #4
1000d6148:     	str	x8, [sp, #88]
1000d614c:     	ubfx	x8, x11, #12, #4
1000d6150:     	str	x8, [sp, #80]
1000d6154:     	ubfx	x8, x11, #20, #4
1000d6158:     	str	x8, [sp, #72]
1000d615c:     	lsr	x8, x11, #28
1000d6160:     	str	x8, [sp, #64]
1000d6164:     	ldp	w13, w2, [x20, #24]
1000d6168:     	and	x11, x13, #0xf
1000d616c:     	ubfx	x8, x13, #8, #4
1000d6170:     	stp	x8, x11, [sp, #48]
1000d6174:     	ubfx	x11, x13, #16, #4
1000d6178:     	ubfx	x8, x13, #24, #4
1000d617c:     	stp	x8, x11, [sp, #32]
1000d6180:     	ubfx	x8, x13, #4, #4
1000d6184:     	stp	x20, x8, [sp, #16]
1000d6188:     	ubfx	x11, x13, #12, #4
1000d618c:     	ubfx	x12, x13, #20, #4
1000d6190:     	lsr	x13, x13, #28
1000d6194:     	and	x14, x2, #0xf
1000d6198:     	ubfx	x21, x2, #8, #4
1000d619c:     	ubfx	x15, x2, #16, #4
1000d61a0:     	ubfx	x16, x2, #24, #4
1000d61a4:     	ubfx	x17, x2, #4, #4
1000d61a8:     	ubfx	x0, x2, #12, #4
1000d61ac:     	ubfx	x1, x2, #20, #4
1000d61b0:     	lsr	x2, x2, #28
1000d61b4:     	ldr	w25, [x22, x10]
1000d61b8:     	lsl	w3, w25, #4
1000d61bc:     	and	x3, x3, #0xf0
1000d61c0:     	add	x3, x9, x3
1000d61c4:     	ldr	x8, [sp, #416]
1000d61c8:     	ldrsb	w26, [x3, x8]
1000d61cc:     	lsr	x4, x25, #4
1000d61d0:     	and	x4, x4, #0xf0
1000d61d4:     	add	x4, x9, x4
1000d61d8:     	ldr	x8, [sp, #440]
1000d61dc:     	ldrsb	w27, [x4, x8]
1000d61e0:     	lsr	x5, x25, #12
1000d61e4:     	and	x5, x5, #0xf0
1000d61e8:     	add	x5, x9, x5
1000d61ec:     	ldr	x8, [sp, #432]
1000d61f0:     	ldrsb	w28, [x5, x8]
1000d61f4:     	lsr	x6, x25, #20
1000d61f8:     	and	x6, x6, #0xf0
1000d61fc:     	add	x7, x9, x6
1000d6200:     	ldr	x8, [sp, #424]
1000d6204:     	ldrsb	w30, [x7, x8]
1000d6208:     	and	x6, x25, #0xf0
1000d620c:     	add	x6, x9, x6
1000d6210:     	ldr	x8, [sp, #408]
1000d6214:     	ldrsb	w19, [x6, x8]
1000d6218:     	lsr	x23, x25, #8
1000d621c:     	and	x23, x23, #0xf0
1000d6220:     	add	x23, x9, x23
1000d6224:     	ldp	x20, x8, [sp, #392]
1000d6228:     	ldrsb	w8, [x23, x8]
1000d622c:     	lsr	x24, x25, #16
1000d6230:     	and	x24, x24, #0xf0
1000d6234:     	add	x24, x9, x24
1000d6238:     	ldrsb	w20, [x24, x20]
1000d623c:     	lsr	x25, x25, #24
1000d6240:     	and	x25, x25, #0xf0
1000d6244:     	add	x25, x9, x25
1000d6248:     	add	w26, w26, w27
1000d624c:     	ldr	x27, [sp, #384]
1000d6250:     	ldrsb	w27, [x25, x27]
1000d6254:     	add	w26, w26, w28
1000d6258:     	add	w26, w26, w30
1000d625c:     	add	w19, w26, w19
1000d6260:     	add	w8, w19, w8
1000d6264:     	add	w8, w8, w20
1000d6268:     	add	w8, w8, w27
1000d626c:     	scvtf	s0, w8
1000d6270:     	ldp	x19, x8, [sp, #368]
1000d6274:     	ldrsb	w8, [x3, x8]
1000d6278:     	ldrsb	w19, [x4, x19]
1000d627c:     	ldp	x26, x20, [sp, #352]
1000d6280:     	ldrsb	w20, [x5, x20]
1000d6284:     	ldrsb	w26, [x7, x26]
1000d6288:     	ldp	x28, x27, [sp, #336]
1000d628c:     	ldrsb	w27, [x6, x27]
1000d6290:     	ldrsb	w28, [x23, x28]
1000d6294:     	add	w8, w8, w19
1000d6298:     	ldr	x19, [sp, #328]
1000d629c:     	ldrsb	w19, [x24, x19]
1000d62a0:     	add	w8, w8, w20
1000d62a4:     	add	w8, w8, w26
1000d62a8:     	ldr	x20, [sp, #320]
1000d62ac:     	ldrsb	w20, [x25, x20]
1000d62b0:     	add	w8, w8, w27
1000d62b4:     	add	w8, w8, w28
1000d62b8:     	add	w8, w8, w19
1000d62bc:     	add	w8, w8, w20
1000d62c0:     	scvtf	s1, w8
1000d62c4:     	ldp	x19, x8, [sp, #304]
1000d62c8:     	ldrsb	w8, [x3, x8]
1000d62cc:     	ldrsb	w19, [x4, x19]
1000d62d0:     	ldp	x26, x20, [sp, #288]
1000d62d4:     	ldrsb	w20, [x5, x20]
1000d62d8:     	ldrsb	w26, [x7, x26]
1000d62dc:     	ldr	x27, [sp, #280]
1000d62e0:     	ldrsb	w27, [x6, x27]
1000d62e4:     	add	w8, w8, w19
1000d62e8:     	ldr	x19, [sp, #272]
1000d62ec:     	ldrsb	w19, [x23, x19]
1000d62f0:     	add	w8, w8, w20
1000d62f4:     	ldr	x20, [sp, #264]
1000d62f8:     	ldrsb	w20, [x24, x20]
1000d62fc:     	add	w8, w8, w26
1000d6300:     	ldr	x26, [sp, #256]
1000d6304:     	ldrsb	w26, [x25, x26]
1000d6308:     	add	w8, w8, w27
1000d630c:     	add	w8, w8, w19
1000d6310:     	add	w8, w8, w20
1000d6314:     	add	w8, w8, w26
1000d6318:     	scvtf	s2, w8
1000d631c:     	ldp	x19, x8, [sp, #240]
1000d6320:     	ldrsb	w8, [x3, x8]
1000d6324:     	ldrsb	w19, [x4, x19]
1000d6328:     	ldp	x26, x20, [sp, #224]
1000d632c:     	ldrsb	w20, [x5, x20]
1000d6330:     	ldrsb	w26, [x7, x26]
1000d6334:     	add	w8, w8, w19
1000d6338:     	ldr	x19, [sp, #216]
1000d633c:     	ldrsb	w19, [x6, x19]
1000d6340:     	add	w8, w8, w20
1000d6344:     	ldr	x20, [sp, #208]
1000d6348:     	ldrsb	w20, [x23, x20]
1000d634c:     	add	w8, w8, w26
1000d6350:     	ldr	x26, [sp, #200]
1000d6354:     	ldrsb	w26, [x24, x26]
1000d6358:     	add	w8, w8, w19
1000d635c:     	ldr	x19, [sp, #192]
1000d6360:     	ldrsb	w19, [x25, x19]
1000d6364:     	add	w8, w8, w20
1000d6368:     	add	w8, w8, w26
1000d636c:     	add	w8, w8, w19
1000d6370:     	scvtf	s3, w8
1000d6374:     	ldp	x19, x8, [sp, #176]
1000d6378:     	ldrsb	w8, [x3, x8]
1000d637c:     	ldrsb	w19, [x4, x19]
1000d6380:     	ldp	x26, x20, [sp, #160]
1000d6384:     	ldrsb	w20, [x5, x20]
1000d6388:     	ldrsb	w26, [x7, x26]
1000d638c:     	add	w8, w8, w19
1000d6390:     	add	w8, w8, w20
1000d6394:     	ldp	x20, x19, [sp, #144]
1000d6398:     	ldrsb	w19, [x6, x19]
1000d639c:     	ldrsb	w20, [x23, x20]
1000d63a0:     	add	w8, w8, w26
1000d63a4:     	add	w8, w8, w19
1000d63a8:     	ldp	x26, x19, [sp, #128]
1000d63ac:     	ldrsb	w19, [x24, x19]
1000d63b0:     	ldrsb	w26, [x25, x26]
1000d63b4:     	add	w8, w8, w20
1000d63b8:     	add	w8, w8, w19
1000d63bc:     	add	w8, w8, w26
1000d63c0:     	scvtf	s4, w8
1000d63c4:     	ldp	x19, x8, [sp, #112]
1000d63c8:     	ldrsb	w8, [x3, x8]
1000d63cc:     	ldrsb	w19, [x4, x19]
1000d63d0:     	ldr	x20, [sp, #104]
1000d63d4:     	ldrsb	w20, [x5, x20]
1000d63d8:     	add	w8, w8, w19
1000d63dc:     	add	w8, w8, w20
1000d63e0:     	ldp	x20, x19, [sp, #88]
1000d63e4:     	ldrsb	w19, [x7, x19]
1000d63e8:     	ldrsb	w20, [x6, x20]
1000d63ec:     	add	w8, w8, w19
1000d63f0:     	add	w8, w8, w20
1000d63f4:     	ldp	x20, x19, [sp, #72]
1000d63f8:     	ldrsb	w19, [x23, x19]
1000d63fc:     	ldrsb	w20, [x24, x20]
1000d6400:     	add	w8, w8, w19
1000d6404:     	add	w8, w8, w20
1000d6408:     	ldr	x19, [sp, #64]
1000d640c:     	ldrsb	w19, [x25, x19]
1000d6410:     	add	w8, w8, w19
1000d6414:     	scvtf	s5, w8
1000d6418:     	ldp	x19, x8, [sp, #48]
1000d641c:     	ldrsb	w8, [x3, x8]
1000d6420:     	ldrsb	w19, [x4, x19]
1000d6424:     	ldp	x26, x20, [sp, #32]
1000d6428:     	ldrsb	w20, [x5, x20]
1000d642c:     	ldrsb	w26, [x7, x26]
1000d6430:     	add	w8, w8, w19
1000d6434:     	ldr	x19, [sp, #24]
1000d6438:     	ldrsb	w19, [x6, x19]
1000d643c:     	add	w8, w8, w20
1000d6440:     	ldrsb	w20, [x23, x11]
1000d6444:     	add	w8, w8, w26
1000d6448:     	ldrsb	w26, [x24, x12]
1000d644c:     	add	w8, w8, w19
1000d6450:     	add	w8, w8, w20
1000d6454:     	add	w8, w8, w26
1000d6458:     	ldrsb	w19, [x25, x13]
1000d645c:     	add	w8, w8, w19
1000d6460:     	scvtf	s6, w8
1000d6464:     	ldrsb	w8, [x3, x14]
1000d6468:     	ldrsb	w3, [x4, x21]
1000d646c:     	ldrsb	w4, [x5, x15]
1000d6470:     	add	w8, w8, w3
1000d6474:     	add	w8, w8, w4
1000d6478:     	ldrsb	w3, [x7, x16]
1000d647c:     	ldrsb	w4, [x6, x17]
1000d6480:     	add	w8, w8, w3
1000d6484:     	add	w8, w8, w4
1000d6488:     	ldrsb	w3, [x23, x0]
1000d648c:     	add	x5, sp, #448
1000d6490:     	ldrsb	w4, [x24, x1]
1000d6494:     	add	w8, w8, w3
1000d6498:     	add	w8, w8, w4
1000d649c:     	ldrsb	w3, [x25, x2]
1000d64a0:     	add	w8, w8, w3
1000d64a4:     	scvtf	s7, w8
1000d64a8:     	add	x8, x5, x10
1000d64ac:     	ldr	s16, [x8]
1000d64b0:     	fadd	s0, s16, s0
1000d64b4:     	str	s0, [x8]
1000d64b8:     	ldr	s0, [x8, #128]
1000d64bc:     	fadd	s0, s0, s1
1000d64c0:     	str	s0, [x8, #128]
1000d64c4:     	ldr	s0, [x8, #256]
1000d64c8:     	fadd	s0, s0, s2
1000d64cc:     	str	s0, [x8, #256]
1000d64d0:     	ldr	s0, [x8, #384]
1000d64d4:     	fadd	s0, s0, s3
1000d64d8:     	str	s0, [x8, #384]
1000d64dc:     	ldr	s0, [x8, #512]
1000d64e0:     	fadd	s0, s0, s4
1000d64e4:     	str	s0, [x8, #512]
1000d64e8:     	ldr	s0, [x8, #640]
1000d64ec:     	fadd	s0, s0, s5
1000d64f0:     	str	s0, [x8, #640]
1000d64f4:     	ldr	s0, [x8, #768]
1000d64f8:     	fadd	s0, s0, s6
1000d64fc:     	ldr	s1, [x8, #896]
1000d6500:     	fadd	s1, s1, s7
1000d6504:     	str	s0, [x8, #768]
1000d6508:     	str	s1, [x8, #896]
1000d650c:     	add	x10, x10, #4
1000d6510:     	cmp	x10, #128
1000d6514:     	b.ne	0x1000d61b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d6518:     	add	x22, x22, #128
1000d651c:     	ldp	x8, x20, [sp, #8]
1000d6520:     	add	x20, x20, #32
1000d6524:     	cmp	x20, x8
1000d6528:     	b.ne	0x1000d6014 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d652c:     	add	x1, sp, #448
1000d6530:     	ldr	x0, [sp]
1000d6534:     	mov	w2, #1024
1000d6538:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d653c:     	ldur	x8, [x29, #-96]
1000d6540:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0x220>
1000d6544:     	ldr	x9, [x9, #392]
1000d6548:     	ldr	x9, [x9]
1000d654c:     	cmp	x9, x8
1000d6550:     	b.ne	0x1000d6574 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d6554:     	add	sp, sp, #1488
1000d6558:     	ldp	x29, x30, [sp, #80]
1000d655c:     	ldp	x20, x19, [sp, #64]
1000d6560:     	ldp	x22, x21, [sp, #48]
1000d6564:     	ldp	x24, x23, [sp, #32]
1000d6568:     	ldp	x26, x25, [sp, #16]
1000d656c:     	ldp	x28, x27, [sp], #96
1000d6570:     	ret
1000d6574:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d7c04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d7c04:     	stp	x28, x27, [sp, #-80]!
1000d7c08:     	stp	x24, x23, [sp, #16]
1000d7c0c:     	stp	x22, x21, [sp, #32]
1000d7c10:     	stp	x20, x19, [sp, #48]
1000d7c14:     	stp	x29, x30, [sp, #64]
1000d7c18:     	add	x29, sp, #64
1000d7c1c:     	sub	sp, sp, #2192
1000d7c20:     	mov	x19, x3
1000d7c24:     	mov	x20, x1
1000d7c28:     	mov	x21, x0
1000d7c2c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x27c>
1000d7c30:     	ldr	x8, [x8, #392]
1000d7c34:     	ldr	x8, [x8]
1000d7c38:     	stur	x8, [x29, #-72]
1000d7c3c:     	lsl	x8, x2, #3
1000d7c40:     	and	x22, x8, #0xfffffffffffffff0
1000d7c44:     	add	x0, sp, #136
1000d7c48:     	mov	w1, #2048
1000d7c4c:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d7c50:     	cbz	x22, 0x1000d7e54 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000d7c54:     	add	x8, x20, x22
1000d7c58:     	mov	w9, #252645135
1000d7c5c:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x8>
1000d7c60:     	add	x10, x10, #1724
1000d7c64:     	add	x11, sp, #8
1000d7c68:     	mov	x12, #0
1000d7c6c:     	ldp	w13, w14, [x20]
1000d7c70:     	and	w15, w13, w9
1000d7c74:     	and	w13, w9, w13, lsr #4
1000d7c78:     	stp	w15, w13, [sp, #8]
1000d7c7c:     	and	w13, w14, w9
1000d7c80:     	and	w14, w9, w14, lsr #4
1000d7c84:     	stp	w13, w14, [sp, #16]
1000d7c88:     	ldp	w13, w14, [x20, #8]
1000d7c8c:     	and	w15, w13, w9
1000d7c90:     	and	w13, w9, w13, lsr #4
1000d7c94:     	stp	w15, w13, [sp, #24]
1000d7c98:     	and	w13, w14, w9
1000d7c9c:     	and	w14, w9, w14, lsr #4
1000d7ca0:     	stp	w13, w14, [sp, #32]
1000d7ca4:     	ldp	w13, w14, [x20, #16]
1000d7ca8:     	and	w15, w13, w9
1000d7cac:     	and	w13, w9, w13, lsr #4
1000d7cb0:     	stp	w15, w13, [sp, #40]
1000d7cb4:     	and	w13, w14, w9
1000d7cb8:     	and	w14, w9, w14, lsr #4
1000d7cbc:     	stp	w13, w14, [sp, #48]
1000d7cc0:     	ldp	w13, w14, [x20, #24]
1000d7cc4:     	and	w15, w13, w9
1000d7cc8:     	and	w13, w9, w13, lsr #4
1000d7ccc:     	stp	w15, w13, [sp, #56]
1000d7cd0:     	and	w13, w14, w9
1000d7cd4:     	and	w14, w9, w14, lsr #4
1000d7cd8:     	stp	w13, w14, [sp, #64]
1000d7cdc:     	ldp	w13, w14, [x20, #32]
1000d7ce0:     	and	w15, w13, w9
1000d7ce4:     	and	w13, w9, w13, lsr #4
1000d7ce8:     	stp	w15, w13, [sp, #72]
1000d7cec:     	and	w13, w14, w9
1000d7cf0:     	and	w14, w9, w14, lsr #4
1000d7cf4:     	stp	w13, w14, [sp, #80]
1000d7cf8:     	ldp	w13, w14, [x20, #40]
1000d7cfc:     	and	w15, w13, w9
1000d7d00:     	and	w13, w9, w13, lsr #4
1000d7d04:     	stp	w15, w13, [sp, #88]
1000d7d08:     	and	w13, w14, w9
1000d7d0c:     	and	w14, w9, w14, lsr #4
1000d7d10:     	stp	w13, w14, [sp, #96]
1000d7d14:     	ldp	w13, w14, [x20, #48]
1000d7d18:     	and	w15, w13, w9
1000d7d1c:     	and	w13, w9, w13, lsr #4
1000d7d20:     	stp	w15, w13, [sp, #104]
1000d7d24:     	and	w13, w14, w9
1000d7d28:     	and	w14, w9, w14, lsr #4
1000d7d2c:     	stp	w13, w14, [sp, #112]
1000d7d30:     	ldp	w13, w14, [x20, #56]
1000d7d34:     	and	w15, w13, w9
1000d7d38:     	and	w13, w9, w13, lsr #4
1000d7d3c:     	stp	w15, w13, [sp, #120]
1000d7d40:     	and	w13, w14, w9
1000d7d44:     	and	w14, w9, w14, lsr #4
1000d7d48:     	stp	w13, w14, [sp, #128]
1000d7d4c:     	add	x13, sp, #136
1000d7d50:     	mov	x14, #0
1000d7d54:     	ldr	w4, [x21, x12, lsl #2]
1000d7d58:     	lsl	w15, w4, #4
1000d7d5c:     	and	x15, x15, #0xf0
1000d7d60:     	add	x15, x10, x15
1000d7d64:     	and	x16, x4, #0xf0
1000d7d68:     	add	x16, x10, x16
1000d7d6c:     	lsr	x17, x4, #4
1000d7d70:     	and	x17, x17, #0xf0
1000d7d74:     	add	x17, x10, x17
1000d7d78:     	lsr	x0, x4, #8
1000d7d7c:     	and	x0, x0, #0xf0
1000d7d80:     	add	x0, x10, x0
1000d7d84:     	lsr	x1, x4, #12
1000d7d88:     	and	x1, x1, #0xf0
1000d7d8c:     	add	x1, x10, x1
1000d7d90:     	lsr	x2, x4, #16
1000d7d94:     	and	x2, x2, #0xf0
1000d7d98:     	add	x2, x10, x2
1000d7d9c:     	lsr	x3, x4, #20
1000d7da0:     	and	x3, x3, #0xf0
1000d7da4:     	add	x3, x10, x3
1000d7da8:     	lsr	x4, x4, #24
1000d7dac:     	and	x4, x4, #0xf0
1000d7db0:     	add	x4, x10, x4
1000d7db4:     	mov	x5, x13
1000d7db8:     	add	x6, x11, x14
1000d7dbc:     	ldrb	w7, [x6]
1000d7dc0:     	ldrb	w7, [x15, x7]
1000d7dc4:     	ldrb	w22, [x6, #1]
1000d7dc8:     	ldrb	w22, [x17, x22]
1000d7dcc:     	ldrb	w23, [x6, #2]
1000d7dd0:     	ldrb	w23, [x1, x23]
1000d7dd4:     	add	w7, w7, w22
1000d7dd8:     	add	w7, w7, w23
1000d7ddc:     	ldrb	w22, [x6, #3]
1000d7de0:     	ldrb	w22, [x3, x22]
1000d7de4:     	ldrb	w23, [x6, #4]
1000d7de8:     	ldrb	w23, [x16, x23]
1000d7dec:     	ldrb	w24, [x6, #5]
1000d7df0:     	ldrb	w24, [x0, x24]
1000d7df4:     	add	w7, w7, w22
1000d7df8:     	add	w7, w7, w23
1000d7dfc:     	ldrb	w22, [x6, #6]
1000d7e00:     	ldrb	w22, [x2, x22]
1000d7e04:     	add	w7, w7, w24
1000d7e08:     	add	w7, w7, w22
1000d7e0c:     	ldrb	w6, [x6, #7]
1000d7e10:     	ldrb	w6, [x4, x6]
1000d7e14:     	add	w6, w7, w6
1000d7e18:     	scvtf	s0, w6
1000d7e1c:     	ldr	s1, [x5]
1000d7e20:     	fadd	s0, s1, s0
1000d7e24:     	str	s0, [x5], #128
1000d7e28:     	add	x14, x14, #8
1000d7e2c:     	cmp	x14, #128
1000d7e30:     	b.ne	0x1000d7db8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000d7e34:     	add	x12, x12, #1
1000d7e38:     	add	x13, x13, #4
1000d7e3c:     	cmp	x12, #32
1000d7e40:     	b.ne	0x1000d7d50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000d7e44:     	add	x21, x21, #128
1000d7e48:     	add	x20, x20, #64
1000d7e4c:     	cmp	x20, x8
1000d7e50:     	b.ne	0x1000d7c68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d7e54:     	add	x1, sp, #136
1000d7e58:     	mov	x0, x19
1000d7e5c:     	mov	w2, #2048
1000d7e60:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d7e64:     	ldur	x8, [x29, #-72]
1000d7e68:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x21c>
1000d7e6c:     	ldr	x9, [x9, #392]
1000d7e70:     	ldr	x9, [x9]
1000d7e74:     	cmp	x9, x8
1000d7e78:     	b.ne	0x1000d7e98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000d7e7c:     	add	sp, sp, #2192
1000d7e80:     	ldp	x29, x30, [sp, #64]
1000d7e84:     	ldp	x20, x19, [sp, #48]
1000d7e88:     	ldp	x22, x21, [sp, #32]
1000d7e8c:     	ldp	x24, x23, [sp, #16]
1000d7e90:     	ldp	x28, x27, [sp], #80
1000d7e94:     	ret
1000d7e98:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d8110 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d8110:     	stp	x28, x27, [sp, #-80]!
1000d8114:     	stp	x24, x23, [sp, #16]
1000d8118:     	stp	x22, x21, [sp, #32]
1000d811c:     	stp	x20, x19, [sp, #48]
1000d8120:     	stp	x29, x30, [sp, #64]
1000d8124:     	add	x29, sp, #64
1000d8128:     	sub	sp, sp, #2192
1000d812c:     	mov	x19, x3
1000d8130:     	mov	x20, x1
1000d8134:     	mov	x21, x0
1000d8138:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x278>
1000d813c:     	ldr	x8, [x8, #392]
1000d8140:     	ldr	x8, [x8]
1000d8144:     	stur	x8, [x29, #-72]
1000d8148:     	lsl	x8, x2, #3
1000d814c:     	and	x22, x8, #0xfffffffffffffff0
1000d8150:     	add	x0, sp, #136
1000d8154:     	mov	w1, #2048
1000d8158:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d815c:     	cbz	x22, 0x1000d8360 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000d8160:     	add	x8, x20, x22
1000d8164:     	mov	w9, #252645135
1000d8168:     	adrp	x10, 0x10016a000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x8>
1000d816c:     	add	x10, x10, #1980
1000d8170:     	add	x11, sp, #8
1000d8174:     	mov	x12, #0
1000d8178:     	ldp	w13, w14, [x20]
1000d817c:     	and	w15, w13, w9
1000d8180:     	and	w13, w9, w13, lsr #4
1000d8184:     	stp	w15, w13, [sp, #8]
1000d8188:     	and	w13, w14, w9
1000d818c:     	and	w14, w9, w14, lsr #4
1000d8190:     	stp	w13, w14, [sp, #16]
1000d8194:     	ldp	w13, w14, [x20, #8]
1000d8198:     	and	w15, w13, w9
1000d819c:     	and	w13, w9, w13, lsr #4
1000d81a0:     	stp	w15, w13, [sp, #24]
1000d81a4:     	and	w13, w14, w9
1000d81a8:     	and	w14, w9, w14, lsr #4
1000d81ac:     	stp	w13, w14, [sp, #32]
1000d81b0:     	ldp	w13, w14, [x20, #16]
1000d81b4:     	and	w15, w13, w9
1000d81b8:     	and	w13, w9, w13, lsr #4
1000d81bc:     	stp	w15, w13, [sp, #40]
1000d81c0:     	and	w13, w14, w9
1000d81c4:     	and	w14, w9, w14, lsr #4
1000d81c8:     	stp	w13, w14, [sp, #48]
1000d81cc:     	ldp	w13, w14, [x20, #24]
1000d81d0:     	and	w15, w13, w9
1000d81d4:     	and	w13, w9, w13, lsr #4
1000d81d8:     	stp	w15, w13, [sp, #56]
1000d81dc:     	and	w13, w14, w9
1000d81e0:     	and	w14, w9, w14, lsr #4
1000d81e4:     	stp	w13, w14, [sp, #64]
1000d81e8:     	ldp	w13, w14, [x20, #32]
1000d81ec:     	and	w15, w13, w9
1000d81f0:     	and	w13, w9, w13, lsr #4
1000d81f4:     	stp	w15, w13, [sp, #72]
1000d81f8:     	and	w13, w14, w9
1000d81fc:     	and	w14, w9, w14, lsr #4
1000d8200:     	stp	w13, w14, [sp, #80]
1000d8204:     	ldp	w13, w14, [x20, #40]
1000d8208:     	and	w15, w13, w9
1000d820c:     	and	w13, w9, w13, lsr #4
1000d8210:     	stp	w15, w13, [sp, #88]
1000d8214:     	and	w13, w14, w9
1000d8218:     	and	w14, w9, w14, lsr #4
1000d821c:     	stp	w13, w14, [sp, #96]
1000d8220:     	ldp	w13, w14, [x20, #48]
1000d8224:     	and	w15, w13, w9
1000d8228:     	and	w13, w9, w13, lsr #4
1000d822c:     	stp	w15, w13, [sp, #104]
1000d8230:     	and	w13, w14, w9
1000d8234:     	and	w14, w9, w14, lsr #4
1000d8238:     	stp	w13, w14, [sp, #112]
1000d823c:     	ldp	w13, w14, [x20, #56]
1000d8240:     	and	w15, w13, w9
1000d8244:     	and	w13, w9, w13, lsr #4
1000d8248:     	stp	w15, w13, [sp, #120]
1000d824c:     	and	w13, w14, w9
1000d8250:     	and	w14, w9, w14, lsr #4
1000d8254:     	stp	w13, w14, [sp, #128]
1000d8258:     	add	x13, sp, #136
1000d825c:     	mov	x14, #0
1000d8260:     	ldr	w4, [x21, x12, lsl #2]
1000d8264:     	lsl	w15, w4, #4
1000d8268:     	and	x15, x15, #0xf0
1000d826c:     	add	x15, x10, x15
1000d8270:     	and	x16, x4, #0xf0
1000d8274:     	add	x16, x10, x16
1000d8278:     	lsr	x17, x4, #4
1000d827c:     	and	x17, x17, #0xf0
1000d8280:     	add	x17, x10, x17
1000d8284:     	lsr	x0, x4, #8
1000d8288:     	and	x0, x0, #0xf0
1000d828c:     	add	x0, x10, x0
1000d8290:     	lsr	x1, x4, #12
1000d8294:     	and	x1, x1, #0xf0
1000d8298:     	add	x1, x10, x1
1000d829c:     	lsr	x2, x4, #16
1000d82a0:     	and	x2, x2, #0xf0
1000d82a4:     	add	x2, x10, x2
1000d82a8:     	lsr	x3, x4, #20
1000d82ac:     	and	x3, x3, #0xf0
1000d82b0:     	add	x3, x10, x3
1000d82b4:     	lsr	x4, x4, #24
1000d82b8:     	and	x4, x4, #0xf0
1000d82bc:     	add	x4, x10, x4
1000d82c0:     	mov	x5, x13
1000d82c4:     	add	x6, x11, x14
1000d82c8:     	ldrb	w7, [x6]
1000d82cc:     	ldrsb	w7, [x15, x7]
1000d82d0:     	ldrb	w22, [x6, #1]
1000d82d4:     	ldrsb	w22, [x17, x22]
1000d82d8:     	ldrb	w23, [x6, #2]
1000d82dc:     	ldrsb	w23, [x1, x23]
1000d82e0:     	add	w7, w7, w22
1000d82e4:     	add	w7, w7, w23
1000d82e8:     	ldrb	w22, [x6, #3]
1000d82ec:     	ldrsb	w22, [x3, x22]
1000d82f0:     	ldrb	w23, [x6, #4]
1000d82f4:     	ldrsb	w23, [x16, x23]
1000d82f8:     	ldrb	w24, [x6, #5]
1000d82fc:     	ldrsb	w24, [x0, x24]
1000d8300:     	add	w7, w7, w22
1000d8304:     	add	w7, w7, w23
1000d8308:     	ldrb	w22, [x6, #6]
1000d830c:     	ldrsb	w22, [x2, x22]
1000d8310:     	add	w7, w7, w24
1000d8314:     	add	w7, w7, w22
1000d8318:     	ldrb	w6, [x6, #7]
1000d831c:     	ldrsb	w6, [x4, x6]
1000d8320:     	add	w6, w7, w6
1000d8324:     	scvtf	s0, w6
1000d8328:     	ldr	s1, [x5]
1000d832c:     	fadd	s0, s1, s0
1000d8330:     	str	s0, [x5], #128
1000d8334:     	add	x14, x14, #8
1000d8338:     	cmp	x14, #128
1000d833c:     	b.ne	0x1000d82c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000d8340:     	add	x12, x12, #1
1000d8344:     	add	x13, x13, #4
1000d8348:     	cmp	x12, #32
1000d834c:     	b.ne	0x1000d825c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000d8350:     	add	x21, x21, #128
1000d8354:     	add	x20, x20, #64
1000d8358:     	cmp	x20, x8
1000d835c:     	b.ne	0x1000d8174 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d8360:     	add	x1, sp, #136
1000d8364:     	mov	x0, x19
1000d8368:     	mov	w2, #2048
1000d836c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d8370:     	ldur	x8, [x29, #-72]
1000d8374:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x21c>
1000d8378:     	ldr	x9, [x9, #392]
1000d837c:     	ldr	x9, [x9]
1000d8380:     	cmp	x9, x8
1000d8384:     	b.ne	0x1000d83a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000d8388:     	add	sp, sp, #2192
1000d838c:     	ldp	x29, x30, [sp, #64]
1000d8390:     	ldp	x20, x19, [sp, #48]
1000d8394:     	ldp	x22, x21, [sp, #32]
1000d8398:     	ldp	x24, x23, [sp, #16]
1000d839c:     	ldp	x28, x27, [sp], #80
1000d83a0:     	ret
1000d83a4:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d9818 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9818:     	stp	x28, x27, [sp, #-80]!
1000d981c:     	stp	x24, x23, [sp, #16]
1000d9820:     	stp	x22, x21, [sp, #32]
1000d9824:     	stp	x20, x19, [sp, #48]
1000d9828:     	stp	x29, x30, [sp, #64]
1000d982c:     	add	x29, sp, #64
1000d9830:     	mov	w9, #4368
1000d9834:     	adrp	x16, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x268>
1000d9838:     	ldr	x16, [x16, #304]
1000d983c:     	blr	x16
1000d9840:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9844:     	sub	sp, sp, #272
1000d9848:     	mov	x19, x3
1000d984c:     	mov	x20, x1
1000d9850:     	mov	x21, x0
1000d9854:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d9858:     	ldr	x8, [x8, #392]
1000d985c:     	ldr	x8, [x8]
1000d9860:     	stur	x8, [x29, #-72]
1000d9864:     	lsl	x8, x2, #4
1000d9868:     	and	x22, x8, #0xffffffffffffffe0
1000d986c:     	add	x0, sp, #264
1000d9870:     	mov	w1, #4096
1000d9874:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9878:     	cbz	x22, 0x1000d9b60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x348>
1000d987c:     	add	x8, x20, x22
1000d9880:     	mov	w9, #252645135
1000d9884:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d9888:     	add	x10, x10, #1724
1000d988c:     	add	x11, sp, #8
1000d9890:     	mov	x12, #0
1000d9894:     	ldp	w13, w14, [x20]
1000d9898:     	and	w15, w13, w9
1000d989c:     	and	w13, w9, w13, lsr #4
1000d98a0:     	stp	w15, w13, [sp, #8]
1000d98a4:     	and	w13, w14, w9
1000d98a8:     	and	w14, w9, w14, lsr #4
1000d98ac:     	stp	w13, w14, [sp, #16]
1000d98b0:     	ldp	w13, w14, [x20, #8]
1000d98b4:     	and	w15, w13, w9
1000d98b8:     	and	w13, w9, w13, lsr #4
1000d98bc:     	stp	w15, w13, [sp, #24]
1000d98c0:     	and	w13, w14, w9
1000d98c4:     	and	w14, w9, w14, lsr #4
1000d98c8:     	stp	w13, w14, [sp, #32]
1000d98cc:     	ldp	w13, w14, [x20, #16]
1000d98d0:     	and	w15, w13, w9
1000d98d4:     	and	w13, w9, w13, lsr #4
1000d98d8:     	stp	w15, w13, [sp, #40]
1000d98dc:     	and	w13, w14, w9
1000d98e0:     	and	w14, w9, w14, lsr #4
1000d98e4:     	stp	w13, w14, [sp, #48]
1000d98e8:     	ldp	w13, w14, [x20, #24]
1000d98ec:     	and	w15, w13, w9
1000d98f0:     	and	w13, w9, w13, lsr #4
1000d98f4:     	stp	w15, w13, [sp, #56]
1000d98f8:     	and	w13, w14, w9
1000d98fc:     	and	w14, w9, w14, lsr #4
1000d9900:     	stp	w13, w14, [sp, #64]
1000d9904:     	ldp	w13, w14, [x20, #32]
1000d9908:     	and	w15, w13, w9
1000d990c:     	and	w13, w9, w13, lsr #4
1000d9910:     	stp	w15, w13, [sp, #72]
1000d9914:     	and	w13, w14, w9
1000d9918:     	and	w14, w9, w14, lsr #4
1000d991c:     	stp	w13, w14, [sp, #80]
1000d9920:     	ldp	w13, w14, [x20, #40]
1000d9924:     	and	w15, w13, w9
1000d9928:     	and	w13, w9, w13, lsr #4
1000d992c:     	stp	w15, w13, [sp, #88]
1000d9930:     	and	w13, w14, w9
1000d9934:     	and	w14, w9, w14, lsr #4
1000d9938:     	stp	w13, w14, [sp, #96]
1000d993c:     	ldp	w13, w14, [x20, #48]
1000d9940:     	and	w15, w13, w9
1000d9944:     	and	w13, w9, w13, lsr #4
1000d9948:     	stp	w15, w13, [sp, #104]
1000d994c:     	and	w13, w14, w9
1000d9950:     	and	w14, w9, w14, lsr #4
1000d9954:     	stp	w13, w14, [sp, #112]
1000d9958:     	ldp	w13, w14, [x20, #56]
1000d995c:     	and	w15, w13, w9
1000d9960:     	and	w13, w9, w13, lsr #4
1000d9964:     	stp	w15, w13, [sp, #120]
1000d9968:     	and	w13, w14, w9
1000d996c:     	and	w14, w9, w14, lsr #4
1000d9970:     	stp	w13, w14, [sp, #128]
1000d9974:     	ldp	w13, w14, [x20, #64]
1000d9978:     	and	w15, w13, w9
1000d997c:     	and	w13, w9, w13, lsr #4
1000d9980:     	stp	w15, w13, [sp, #136]
1000d9984:     	and	w13, w14, w9
1000d9988:     	and	w14, w9, w14, lsr #4
1000d998c:     	stp	w13, w14, [sp, #144]
1000d9990:     	ldp	w13, w14, [x20, #72]
1000d9994:     	and	w15, w13, w9
1000d9998:     	and	w13, w9, w13, lsr #4
1000d999c:     	stp	w15, w13, [sp, #152]
1000d99a0:     	and	w13, w14, w9
1000d99a4:     	and	w14, w9, w14, lsr #4
1000d99a8:     	stp	w13, w14, [sp, #160]
1000d99ac:     	ldp	w13, w14, [x20, #80]
1000d99b0:     	and	w15, w13, w9
1000d99b4:     	and	w13, w9, w13, lsr #4
1000d99b8:     	stp	w15, w13, [sp, #168]
1000d99bc:     	and	w13, w14, w9
1000d99c0:     	and	w14, w9, w14, lsr #4
1000d99c4:     	stp	w13, w14, [sp, #176]
1000d99c8:     	ldp	w13, w14, [x20, #88]
1000d99cc:     	and	w15, w13, w9
1000d99d0:     	and	w13, w9, w13, lsr #4
1000d99d4:     	stp	w15, w13, [sp, #184]
1000d99d8:     	and	w13, w14, w9
1000d99dc:     	and	w14, w9, w14, lsr #4
1000d99e0:     	stp	w13, w14, [sp, #192]
1000d99e4:     	ldp	w13, w14, [x20, #96]
1000d99e8:     	and	w15, w13, w9
1000d99ec:     	and	w13, w9, w13, lsr #4
1000d99f0:     	stp	w15, w13, [sp, #200]
1000d99f4:     	and	w13, w14, w9
1000d99f8:     	and	w14, w9, w14, lsr #4
1000d99fc:     	stp	w13, w14, [sp, #208]
1000d9a00:     	ldp	w13, w14, [x20, #104]
1000d9a04:     	and	w15, w13, w9
1000d9a08:     	and	w13, w9, w13, lsr #4
1000d9a0c:     	stp	w15, w13, [sp, #216]
1000d9a10:     	and	w13, w14, w9
1000d9a14:     	and	w14, w9, w14, lsr #4
1000d9a18:     	stp	w13, w14, [sp, #224]
1000d9a1c:     	ldp	w13, w14, [x20, #112]
1000d9a20:     	and	w15, w13, w9
1000d9a24:     	and	w13, w9, w13, lsr #4
1000d9a28:     	stp	w15, w13, [sp, #232]
1000d9a2c:     	and	w13, w14, w9
1000d9a30:     	and	w14, w9, w14, lsr #4
1000d9a34:     	stp	w13, w14, [sp, #240]
1000d9a38:     	ldp	w13, w14, [x20, #120]
1000d9a3c:     	and	w15, w13, w9
1000d9a40:     	and	w13, w9, w13, lsr #4
1000d9a44:     	stp	w15, w13, [sp, #248]
1000d9a48:     	and	w13, w14, w9
1000d9a4c:     	and	w14, w9, w14, lsr #4
1000d9a50:     	str	w13, [sp, #256]
1000d9a54:     	str	w14, [sp, #260]
1000d9a58:     	add	x13, sp, #264
1000d9a5c:     	mov	x14, #0
1000d9a60:     	ldr	w4, [x21, x12, lsl #2]
1000d9a64:     	lsl	w15, w4, #4
1000d9a68:     	and	x15, x15, #0xf0
1000d9a6c:     	add	x15, x10, x15
1000d9a70:     	and	x16, x4, #0xf0
1000d9a74:     	add	x16, x10, x16
1000d9a78:     	lsr	x17, x4, #4
1000d9a7c:     	and	x17, x17, #0xf0
1000d9a80:     	add	x17, x10, x17
1000d9a84:     	lsr	x0, x4, #8
1000d9a88:     	and	x0, x0, #0xf0
1000d9a8c:     	add	x0, x10, x0
1000d9a90:     	lsr	x1, x4, #12
1000d9a94:     	and	x1, x1, #0xf0
1000d9a98:     	add	x1, x10, x1
1000d9a9c:     	lsr	x2, x4, #16
1000d9aa0:     	and	x2, x2, #0xf0
1000d9aa4:     	add	x2, x10, x2
1000d9aa8:     	lsr	x3, x4, #20
1000d9aac:     	and	x3, x3, #0xf0
1000d9ab0:     	add	x3, x10, x3
1000d9ab4:     	lsr	x4, x4, #24
1000d9ab8:     	and	x4, x4, #0xf0
1000d9abc:     	add	x4, x10, x4
1000d9ac0:     	mov	x5, x13
1000d9ac4:     	add	x6, x11, x14
1000d9ac8:     	ldrb	w7, [x6]
1000d9acc:     	ldrb	w7, [x15, x7]
1000d9ad0:     	ldrb	w22, [x6, #1]
1000d9ad4:     	ldrb	w22, [x17, x22]
1000d9ad8:     	ldrb	w23, [x6, #2]
1000d9adc:     	ldrb	w23, [x1, x23]
1000d9ae0:     	add	w7, w7, w22
1000d9ae4:     	add	w7, w7, w23
1000d9ae8:     	ldrb	w22, [x6, #3]
1000d9aec:     	ldrb	w22, [x3, x22]
1000d9af0:     	ldrb	w23, [x6, #4]
1000d9af4:     	ldrb	w23, [x16, x23]
1000d9af8:     	ldrb	w24, [x6, #5]
1000d9afc:     	ldrb	w24, [x0, x24]
1000d9b00:     	add	w7, w7, w22
1000d9b04:     	add	w7, w7, w23
1000d9b08:     	ldrb	w22, [x6, #6]
1000d9b0c:     	ldrb	w22, [x2, x22]
1000d9b10:     	add	w7, w7, w24
1000d9b14:     	add	w7, w7, w22
1000d9b18:     	ldrb	w6, [x6, #7]
1000d9b1c:     	ldrb	w6, [x4, x6]
1000d9b20:     	add	w6, w7, w6
1000d9b24:     	scvtf	s0, w6
1000d9b28:     	ldr	s1, [x5]
1000d9b2c:     	fadd	s0, s1, s0
1000d9b30:     	str	s0, [x5], #128
1000d9b34:     	add	x14, x14, #8
1000d9b38:     	cmp	x14, #256
1000d9b3c:     	b.ne	0x1000d9ac4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d9b40:     	add	x12, x12, #1
1000d9b44:     	add	x13, x13, #4
1000d9b48:     	cmp	x12, #32
1000d9b4c:     	b.ne	0x1000d9a5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000d9b50:     	add	x21, x21, #128
1000d9b54:     	add	x20, x20, #128
1000d9b58:     	cmp	x20, x8
1000d9b5c:     	b.ne	0x1000d9890 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x78>
1000d9b60:     	add	x1, sp, #264
1000d9b64:     	mov	x0, x19
1000d9b68:     	mov	w2, #4096
1000d9b6c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9b70:     	ldur	x8, [x29, #-72]
1000d9b74:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x15c>
1000d9b78:     	ldr	x9, [x9, #392]
1000d9b7c:     	ldr	x9, [x9]
1000d9b80:     	cmp	x9, x8
1000d9b84:     	b.ne	0x1000d9ba8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x390>
1000d9b88:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9b8c:     	add	sp, sp, #272
1000d9b90:     	ldp	x29, x30, [sp, #64]
1000d9b94:     	ldp	x20, x19, [sp, #48]
1000d9b98:     	ldp	x22, x21, [sp, #32]
1000d9b9c:     	ldp	x24, x23, [sp, #16]
1000d9ba0:     	ldp	x28, x27, [sp], #80
1000d9ba4:     	ret
1000d9ba8:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d9c64 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9c64:     	stp	x28, x27, [sp, #-80]!
1000d9c68:     	stp	x24, x23, [sp, #16]
1000d9c6c:     	stp	x22, x21, [sp, #32]
1000d9c70:     	stp	x20, x19, [sp, #48]
1000d9c74:     	stp	x29, x30, [sp, #64]
1000d9c78:     	add	x29, sp, #64
1000d9c7c:     	mov	w9, #4368
1000d9c80:     	adrp	x16, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x268>
1000d9c84:     	ldr	x16, [x16, #304]
1000d9c88:     	blr	x16
1000d9c8c:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9c90:     	sub	sp, sp, #272
1000d9c94:     	mov	x19, x3
1000d9c98:     	mov	x20, x1
1000d9c9c:     	mov	x21, x0
1000d9ca0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d9ca4:     	ldr	x8, [x8, #392]
1000d9ca8:     	ldr	x8, [x8]
1000d9cac:     	stur	x8, [x29, #-72]
1000d9cb0:     	lsl	x8, x2, #4
1000d9cb4:     	and	x22, x8, #0xffffffffffffffe0
1000d9cb8:     	add	x0, sp, #264
1000d9cbc:     	mov	w1, #4096
1000d9cc0:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9cc4:     	cbz	x22, 0x1000d9fac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x348>
1000d9cc8:     	add	x8, x20, x22
1000d9ccc:     	mov	w9, #252645135
1000d9cd0:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d9cd4:     	add	x10, x10, #1980
1000d9cd8:     	add	x11, sp, #8
1000d9cdc:     	mov	x12, #0
1000d9ce0:     	ldp	w13, w14, [x20]
1000d9ce4:     	and	w15, w13, w9
1000d9ce8:     	and	w13, w9, w13, lsr #4
1000d9cec:     	stp	w15, w13, [sp, #8]
1000d9cf0:     	and	w13, w14, w9
1000d9cf4:     	and	w14, w9, w14, lsr #4
1000d9cf8:     	stp	w13, w14, [sp, #16]
1000d9cfc:     	ldp	w13, w14, [x20, #8]
1000d9d00:     	and	w15, w13, w9
1000d9d04:     	and	w13, w9, w13, lsr #4
1000d9d08:     	stp	w15, w13, [sp, #24]
1000d9d0c:     	and	w13, w14, w9
1000d9d10:     	and	w14, w9, w14, lsr #4
1000d9d14:     	stp	w13, w14, [sp, #32]
1000d9d18:     	ldp	w13, w14, [x20, #16]
1000d9d1c:     	and	w15, w13, w9
1000d9d20:     	and	w13, w9, w13, lsr #4
1000d9d24:     	stp	w15, w13, [sp, #40]
1000d9d28:     	and	w13, w14, w9
1000d9d2c:     	and	w14, w9, w14, lsr #4
1000d9d30:     	stp	w13, w14, [sp, #48]
1000d9d34:     	ldp	w13, w14, [x20, #24]
1000d9d38:     	and	w15, w13, w9
1000d9d3c:     	and	w13, w9, w13, lsr #4
1000d9d40:     	stp	w15, w13, [sp, #56]
1000d9d44:     	and	w13, w14, w9
1000d9d48:     	and	w14, w9, w14, lsr #4
1000d9d4c:     	stp	w13, w14, [sp, #64]
1000d9d50:     	ldp	w13, w14, [x20, #32]
1000d9d54:     	and	w15, w13, w9
1000d9d58:     	and	w13, w9, w13, lsr #4
1000d9d5c:     	stp	w15, w13, [sp, #72]
1000d9d60:     	and	w13, w14, w9
1000d9d64:     	and	w14, w9, w14, lsr #4
1000d9d68:     	stp	w13, w14, [sp, #80]
1000d9d6c:     	ldp	w13, w14, [x20, #40]
1000d9d70:     	and	w15, w13, w9
1000d9d74:     	and	w13, w9, w13, lsr #4
1000d9d78:     	stp	w15, w13, [sp, #88]
1000d9d7c:     	and	w13, w14, w9
1000d9d80:     	and	w14, w9, w14, lsr #4
1000d9d84:     	stp	w13, w14, [sp, #96]
1000d9d88:     	ldp	w13, w14, [x20, #48]
1000d9d8c:     	and	w15, w13, w9
1000d9d90:     	and	w13, w9, w13, lsr #4
1000d9d94:     	stp	w15, w13, [sp, #104]
1000d9d98:     	and	w13, w14, w9
1000d9d9c:     	and	w14, w9, w14, lsr #4
1000d9da0:     	stp	w13, w14, [sp, #112]
1000d9da4:     	ldp	w13, w14, [x20, #56]
1000d9da8:     	and	w15, w13, w9
1000d9dac:     	and	w13, w9, w13, lsr #4
1000d9db0:     	stp	w15, w13, [sp, #120]
1000d9db4:     	and	w13, w14, w9
1000d9db8:     	and	w14, w9, w14, lsr #4
1000d9dbc:     	stp	w13, w14, [sp, #128]
1000d9dc0:     	ldp	w13, w14, [x20, #64]
1000d9dc4:     	and	w15, w13, w9
1000d9dc8:     	and	w13, w9, w13, lsr #4
1000d9dcc:     	stp	w15, w13, [sp, #136]
1000d9dd0:     	and	w13, w14, w9
1000d9dd4:     	and	w14, w9, w14, lsr #4
1000d9dd8:     	stp	w13, w14, [sp, #144]
1000d9ddc:     	ldp	w13, w14, [x20, #72]
1000d9de0:     	and	w15, w13, w9
1000d9de4:     	and	w13, w9, w13, lsr #4
1000d9de8:     	stp	w15, w13, [sp, #152]
1000d9dec:     	and	w13, w14, w9
1000d9df0:     	and	w14, w9, w14, lsr #4
1000d9df4:     	stp	w13, w14, [sp, #160]
1000d9df8:     	ldp	w13, w14, [x20, #80]
1000d9dfc:     	and	w15, w13, w9
1000d9e00:     	and	w13, w9, w13, lsr #4
1000d9e04:     	stp	w15, w13, [sp, #168]
1000d9e08:     	and	w13, w14, w9
1000d9e0c:     	and	w14, w9, w14, lsr #4
1000d9e10:     	stp	w13, w14, [sp, #176]
1000d9e14:     	ldp	w13, w14, [x20, #88]
1000d9e18:     	and	w15, w13, w9
1000d9e1c:     	and	w13, w9, w13, lsr #4
1000d9e20:     	stp	w15, w13, [sp, #184]
1000d9e24:     	and	w13, w14, w9
1000d9e28:     	and	w14, w9, w14, lsr #4
1000d9e2c:     	stp	w13, w14, [sp, #192]
1000d9e30:     	ldp	w13, w14, [x20, #96]
1000d9e34:     	and	w15, w13, w9
1000d9e38:     	and	w13, w9, w13, lsr #4
1000d9e3c:     	stp	w15, w13, [sp, #200]
1000d9e40:     	and	w13, w14, w9
1000d9e44:     	and	w14, w9, w14, lsr #4
1000d9e48:     	stp	w13, w14, [sp, #208]
1000d9e4c:     	ldp	w13, w14, [x20, #104]
1000d9e50:     	and	w15, w13, w9
1000d9e54:     	and	w13, w9, w13, lsr #4
1000d9e58:     	stp	w15, w13, [sp, #216]
1000d9e5c:     	and	w13, w14, w9
1000d9e60:     	and	w14, w9, w14, lsr #4
1000d9e64:     	stp	w13, w14, [sp, #224]
1000d9e68:     	ldp	w13, w14, [x20, #112]
1000d9e6c:     	and	w15, w13, w9
1000d9e70:     	and	w13, w9, w13, lsr #4
1000d9e74:     	stp	w15, w13, [sp, #232]
1000d9e78:     	and	w13, w14, w9
1000d9e7c:     	and	w14, w9, w14, lsr #4
1000d9e80:     	stp	w13, w14, [sp, #240]
1000d9e84:     	ldp	w13, w14, [x20, #120]
1000d9e88:     	and	w15, w13, w9
1000d9e8c:     	and	w13, w9, w13, lsr #4
1000d9e90:     	stp	w15, w13, [sp, #248]
1000d9e94:     	and	w13, w14, w9
1000d9e98:     	and	w14, w9, w14, lsr #4
1000d9e9c:     	str	w13, [sp, #256]
1000d9ea0:     	str	w14, [sp, #260]
1000d9ea4:     	add	x13, sp, #264
1000d9ea8:     	mov	x14, #0
1000d9eac:     	ldr	w4, [x21, x12, lsl #2]
1000d9eb0:     	lsl	w15, w4, #4
1000d9eb4:     	and	x15, x15, #0xf0
1000d9eb8:     	add	x15, x10, x15
1000d9ebc:     	and	x16, x4, #0xf0
1000d9ec0:     	add	x16, x10, x16
1000d9ec4:     	lsr	x17, x4, #4
1000d9ec8:     	and	x17, x17, #0xf0
1000d9ecc:     	add	x17, x10, x17
1000d9ed0:     	lsr	x0, x4, #8
1000d9ed4:     	and	x0, x0, #0xf0
1000d9ed8:     	add	x0, x10, x0
1000d9edc:     	lsr	x1, x4, #12
1000d9ee0:     	and	x1, x1, #0xf0
1000d9ee4:     	add	x1, x10, x1
1000d9ee8:     	lsr	x2, x4, #16
1000d9eec:     	and	x2, x2, #0xf0
1000d9ef0:     	add	x2, x10, x2
1000d9ef4:     	lsr	x3, x4, #20
1000d9ef8:     	and	x3, x3, #0xf0
1000d9efc:     	add	x3, x10, x3
1000d9f00:     	lsr	x4, x4, #24
1000d9f04:     	and	x4, x4, #0xf0
1000d9f08:     	add	x4, x10, x4
1000d9f0c:     	mov	x5, x13
1000d9f10:     	add	x6, x11, x14
1000d9f14:     	ldrb	w7, [x6]
1000d9f18:     	ldrsb	w7, [x15, x7]
1000d9f1c:     	ldrb	w22, [x6, #1]
1000d9f20:     	ldrsb	w22, [x17, x22]
1000d9f24:     	ldrb	w23, [x6, #2]
1000d9f28:     	ldrsb	w23, [x1, x23]
1000d9f2c:     	add	w7, w7, w22
1000d9f30:     	add	w7, w7, w23
1000d9f34:     	ldrb	w22, [x6, #3]
1000d9f38:     	ldrsb	w22, [x3, x22]
1000d9f3c:     	ldrb	w23, [x6, #4]
1000d9f40:     	ldrsb	w23, [x16, x23]
1000d9f44:     	ldrb	w24, [x6, #5]
1000d9f48:     	ldrsb	w24, [x0, x24]
1000d9f4c:     	add	w7, w7, w22
1000d9f50:     	add	w7, w7, w23
1000d9f54:     	ldrb	w22, [x6, #6]
1000d9f58:     	ldrsb	w22, [x2, x22]
1000d9f5c:     	add	w7, w7, w24
1000d9f60:     	add	w7, w7, w22
1000d9f64:     	ldrb	w6, [x6, #7]
1000d9f68:     	ldrsb	w6, [x4, x6]
1000d9f6c:     	add	w6, w7, w6
1000d9f70:     	scvtf	s0, w6
1000d9f74:     	ldr	s1, [x5]
1000d9f78:     	fadd	s0, s1, s0
1000d9f7c:     	str	s0, [x5], #128
1000d9f80:     	add	x14, x14, #8
1000d9f84:     	cmp	x14, #256
1000d9f88:     	b.ne	0x1000d9f10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d9f8c:     	add	x12, x12, #1
1000d9f90:     	add	x13, x13, #4
1000d9f94:     	cmp	x12, #32
1000d9f98:     	b.ne	0x1000d9ea8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000d9f9c:     	add	x21, x21, #128
1000d9fa0:     	add	x20, x20, #128
1000d9fa4:     	cmp	x20, x8
1000d9fa8:     	b.ne	0x1000d9cdc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x78>
1000d9fac:     	add	x1, sp, #264
1000d9fb0:     	mov	x0, x19
1000d9fb4:     	mov	w2, #4096
1000d9fb8:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9fbc:     	ldur	x8, [x29, #-72]
1000d9fc0:     	adrp	x9, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x1a0>
1000d9fc4:     	ldr	x9, [x9, #392]
1000d9fc8:     	ldr	x9, [x9]
1000d9fcc:     	cmp	x9, x8
1000d9fd0:     	b.ne	0x1000d9ff4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x390>
1000d9fd4:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9fd8:     	add	sp, sp, #272
1000d9fdc:     	ldp	x29, x30, [sp, #64]
1000d9fe0:     	ldp	x20, x19, [sp, #48]
1000d9fe4:     	ldp	x22, x21, [sp, #32]
1000d9fe8:     	ldp	x24, x23, [sp, #16]
1000d9fec:     	ldp	x28, x27, [sp], #80
1000d9ff0:     	ret
1000d9ff4:     	bl	0x100163694 <_strcmp+0x100163694>
