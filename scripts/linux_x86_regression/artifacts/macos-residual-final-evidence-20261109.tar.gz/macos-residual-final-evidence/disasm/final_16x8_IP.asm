00000001000cc990 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cc990:     	stp	x28, x27, [sp, #-96]!
1000cc994:     	stp	x26, x25, [sp, #16]
1000cc998:     	stp	x24, x23, [sp, #32]
1000cc99c:     	stp	x22, x21, [sp, #48]
1000cc9a0:     	stp	x20, x19, [sp, #64]
1000cc9a4:     	stp	x29, x30, [sp, #80]
1000cc9a8:     	add	x29, sp, #80
1000cc9ac:     	sub	sp, sp, #976
1000cc9b0:     	str	x3, [sp, #8]
1000cc9b4:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a4>
1000cc9b8:     	ldr	x8, [x8, #392]
1000cc9bc:     	ldr	x8, [x8]
1000cc9c0:     	stur	x8, [x29, #-96]
1000cc9c4:     	movi.2d	v0, #0000000000000000
1000cc9c8:     	stp	q0, q0, [sp, #928]
1000cc9cc:     	lsl	x8, x2, #2
1000cc9d0:     	stp	q0, q0, [sp, #896]
1000cc9d4:     	stp	q0, q0, [sp, #864]
1000cc9d8:     	stp	q0, q0, [sp, #832]
1000cc9dc:     	stp	q0, q0, [sp, #800]
1000cc9e0:     	stp	q0, q0, [sp, #768]
1000cc9e4:     	stp	q0, q0, [sp, #736]
1000cc9e8:     	stp	q0, q0, [sp, #704]
1000cc9ec:     	stp	q0, q0, [sp, #672]
1000cc9f0:     	stp	q0, q0, [sp, #640]
1000cc9f4:     	stp	q0, q0, [sp, #608]
1000cc9f8:     	stp	q0, q0, [sp, #576]
1000cc9fc:     	stp	q0, q0, [sp, #544]
1000cca00:     	stp	q0, q0, [sp, #512]
1000cca04:     	stp	q0, q0, [sp, #480]
1000cca08:     	stp	q0, q0, [sp, #448]
1000cca0c:     	ands	x8, x8, #0xfffffffffffffff8
1000cca10:     	b.eq	0x1000ccf60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cca14:     	add	x8, x1, x8
1000cca18:     	str	x8, [sp, #16]
1000cca1c:     	add	x8, sp, #448
1000cca20:     	add	x19, x8, #256
1000cca24:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000cca28:     	add	x11, x11, #1468
1000cca2c:     	mov	x12, #0
1000cca30:     	ldp	w8, w9, [x1]
1000cca34:     	ubfx	x10, x8, #8, #4
1000cca38:     	str	x10, [sp, #440]
1000cca3c:     	ubfx	x10, x8, #16, #4
1000cca40:     	str	x10, [sp, #432]
1000cca44:     	ubfx	x10, x8, #24, #4
1000cca48:     	str	x10, [sp, #424]
1000cca4c:     	ldp	w10, w13, [x1, #8]
1000cca50:     	and	x15, x8, #0xf
1000cca54:     	ubfx	x14, x8, #4, #4
1000cca58:     	stp	x14, x15, [sp, #408]
1000cca5c:     	ubfx	x15, x8, #12, #4
1000cca60:     	ubfx	x14, x8, #20, #4
1000cca64:     	stp	x14, x15, [sp, #392]
1000cca68:     	lsr	x8, x8, #28
1000cca6c:     	str	x8, [sp, #384]
1000cca70:     	and	x8, x9, #0xf
1000cca74:     	str	x8, [sp, #376]
1000cca78:     	ubfx	x8, x9, #8, #4
1000cca7c:     	str	x8, [sp, #368]
1000cca80:     	ubfx	x8, x9, #16, #4
1000cca84:     	str	x8, [sp, #360]
1000cca88:     	ubfx	x8, x9, #24, #4
1000cca8c:     	str	x8, [sp, #352]
1000cca90:     	ubfx	x8, x9, #4, #4
1000cca94:     	str	x8, [sp, #344]
1000cca98:     	ubfx	x8, x9, #12, #4
1000cca9c:     	str	x8, [sp, #336]
1000ccaa0:     	ubfx	x8, x9, #20, #4
1000ccaa4:     	str	x8, [sp, #328]
1000ccaa8:     	lsr	x8, x9, #28
1000ccaac:     	str	x8, [sp, #320]
1000ccab0:     	and	x9, x10, #0xf
1000ccab4:     	ubfx	x8, x10, #8, #4
1000ccab8:     	stp	x8, x9, [sp, #304]
1000ccabc:     	ubfx	x9, x10, #16, #4
1000ccac0:     	ubfx	x8, x10, #24, #4
1000ccac4:     	stp	x8, x9, [sp, #288]
1000ccac8:     	ubfx	x9, x10, #4, #4
1000ccacc:     	ubfx	x8, x10, #12, #4
1000ccad0:     	stp	x8, x9, [sp, #272]
1000ccad4:     	ubfx	x9, x10, #20, #4
1000ccad8:     	lsr	x8, x10, #28
1000ccadc:     	stp	x8, x9, [sp, #256]
1000ccae0:     	and	x9, x13, #0xf
1000ccae4:     	ubfx	x8, x13, #8, #4
1000ccae8:     	stp	x8, x9, [sp, #240]
1000ccaec:     	ubfx	x9, x13, #16, #4
1000ccaf0:     	ubfx	x8, x13, #24, #4
1000ccaf4:     	stp	x8, x9, [sp, #224]
1000ccaf8:     	ubfx	x9, x13, #4, #4
1000ccafc:     	ubfx	x8, x13, #12, #4
1000ccb00:     	stp	x8, x9, [sp, #208]
1000ccb04:     	ubfx	x9, x13, #20, #4
1000ccb08:     	lsr	x8, x13, #28
1000ccb0c:     	stp	x8, x9, [sp, #192]
1000ccb10:     	ldp	w8, w9, [x1, #16]
1000ccb14:     	and	x10, x8, #0xf
1000ccb18:     	str	x10, [sp, #184]
1000ccb1c:     	ubfx	x10, x8, #8, #4
1000ccb20:     	str	x10, [sp, #176]
1000ccb24:     	ubfx	x10, x8, #16, #4
1000ccb28:     	str	x10, [sp, #168]
1000ccb2c:     	ubfx	x10, x8, #24, #4
1000ccb30:     	str	x10, [sp, #160]
1000ccb34:     	ubfx	x10, x8, #4, #4
1000ccb38:     	str	x10, [sp, #152]
1000ccb3c:     	ubfx	x10, x8, #12, #4
1000ccb40:     	str	x10, [sp, #144]
1000ccb44:     	ubfx	x10, x8, #20, #4
1000ccb48:     	lsr	x8, x8, #28
1000ccb4c:     	stp	x8, x10, [sp, #128]
1000ccb50:     	and	x10, x9, #0xf
1000ccb54:     	ubfx	x8, x9, #8, #4
1000ccb58:     	stp	x8, x10, [sp, #112]
1000ccb5c:     	ubfx	x10, x9, #16, #4
1000ccb60:     	ubfx	x8, x9, #24, #4
1000ccb64:     	stp	x8, x10, [sp, #96]
1000ccb68:     	ubfx	x10, x9, #4, #4
1000ccb6c:     	ubfx	x8, x9, #12, #4
1000ccb70:     	stp	x8, x10, [sp, #80]
1000ccb74:     	ubfx	x10, x9, #20, #4
1000ccb78:     	lsr	x8, x9, #28
1000ccb7c:     	stp	x8, x10, [sp, #64]
1000ccb80:     	ldp	w14, w7, [x1, #24]
1000ccb84:     	and	x9, x14, #0xf
1000ccb88:     	ubfx	x8, x14, #8, #4
1000ccb8c:     	stp	x8, x9, [sp, #48]
1000ccb90:     	ubfx	x8, x14, #16, #4
1000ccb94:     	str	x8, [sp, #40]
1000ccb98:     	ubfx	x8, x14, #24, #4
1000ccb9c:     	stp	x1, x8, [sp, #24]
1000ccba0:     	ubfx	x10, x14, #4, #4
1000ccba4:     	ubfx	x13, x14, #12, #4
1000ccba8:     	ubfx	x9, x14, #20, #4
1000ccbac:     	lsr	x14, x14, #28
1000ccbb0:     	and	x15, x7, #0xf
1000ccbb4:     	ubfx	x16, x7, #8, #4
1000ccbb8:     	ubfx	x17, x7, #16, #4
1000ccbbc:     	ubfx	x2, x7, #24, #4
1000ccbc0:     	ubfx	x4, x7, #4, #4
1000ccbc4:     	ubfx	x5, x7, #12, #4
1000ccbc8:     	ubfx	x6, x7, #20, #4
1000ccbcc:     	lsr	x7, x7, #28
1000ccbd0:     	ldr	w26, [x0, x12]
1000ccbd4:     	mov	x1, x19
1000ccbd8:     	lsl	w19, w26, #4
1000ccbdc:     	and	x19, x19, #0xf0
1000ccbe0:     	add	x19, x11, x19
1000ccbe4:     	ldr	x8, [sp, #416]
1000ccbe8:     	ldrsb	w25, [x19, x8]
1000ccbec:     	lsr	x20, x26, #4
1000ccbf0:     	and	x20, x20, #0xf0
1000ccbf4:     	add	x20, x11, x20
1000ccbf8:     	ldr	x8, [sp, #440]
1000ccbfc:     	ldrsb	w27, [x20, x8]
1000ccc00:     	lsr	x21, x26, #12
1000ccc04:     	and	x21, x21, #0xf0
1000ccc08:     	add	x21, x11, x21
1000ccc0c:     	ldr	x8, [sp, #432]
1000ccc10:     	ldrsb	w28, [x21, x8]
1000ccc14:     	lsr	x22, x26, #20
1000ccc18:     	and	x22, x22, #0xf0
1000ccc1c:     	add	x23, x11, x22
1000ccc20:     	ldr	x8, [sp, #424]
1000ccc24:     	ldrsb	w30, [x23, x8]
1000ccc28:     	and	x22, x26, #0xf0
1000ccc2c:     	add	x22, x11, x22
1000ccc30:     	ldr	x8, [sp, #408]
1000ccc34:     	ldrsb	w3, [x22, x8]
1000ccc38:     	lsr	x24, x26, #8
1000ccc3c:     	and	x24, x24, #0xf0
1000ccc40:     	add	x24, x11, x24
1000ccc44:     	ldr	x8, [sp, #400]
1000ccc48:     	ldrsb	w8, [x24, x8]
1000ccc4c:     	add	w27, w25, w27
1000ccc50:     	lsr	x25, x26, #16
1000ccc54:     	and	x25, x25, #0xf0
1000ccc58:     	add	x25, x11, x25
1000ccc5c:     	add	w27, w27, w28
1000ccc60:     	ldr	x28, [sp, #392]
1000ccc64:     	ldrsb	w28, [x25, x28]
1000ccc68:     	lsr	x26, x26, #24
1000ccc6c:     	and	x26, x26, #0xf0
1000ccc70:     	add	x26, x11, x26
1000ccc74:     	add	w27, w27, w30
1000ccc78:     	ldr	x30, [sp, #384]
1000ccc7c:     	ldrsb	w30, [x26, x30]
1000ccc80:     	add	w3, w27, w3
1000ccc84:     	add	w8, w3, w8
1000ccc88:     	add	w8, w8, w28
1000ccc8c:     	add	w8, w8, w30
1000ccc90:     	scvtf	s0, w8
1000ccc94:     	ldp	x3, x8, [sp, #368]
1000ccc98:     	ldrsb	w8, [x19, x8]
1000ccc9c:     	ldrsb	w3, [x20, x3]
1000ccca0:     	ldp	x28, x27, [sp, #352]
1000ccca4:     	ldrsb	w27, [x21, x27]
1000ccca8:     	ldrsb	w28, [x23, x28]
1000cccac:     	ldr	x30, [sp, #344]
1000cccb0:     	ldrsb	w30, [x22, x30]
1000cccb4:     	add	w8, w8, w3
1000cccb8:     	ldr	x3, [sp, #336]
1000cccbc:     	ldrsb	w3, [x24, x3]
1000cccc0:     	add	w8, w8, w27
1000cccc4:     	ldr	x27, [sp, #328]
1000cccc8:     	ldrsb	w27, [x25, x27]
1000ccccc:     	add	w8, w8, w28
1000cccd0:     	ldr	x28, [sp, #320]
1000cccd4:     	ldrsb	w28, [x26, x28]
1000cccd8:     	add	w8, w8, w30
1000cccdc:     	add	w8, w8, w3
1000ccce0:     	add	w8, w8, w27
1000ccce4:     	add	w8, w8, w28
1000ccce8:     	scvtf	s1, w8
1000cccec:     	ldp	x3, x8, [sp, #304]
1000cccf0:     	ldrsb	w8, [x19, x8]
1000cccf4:     	ldrsb	w3, [x20, x3]
1000cccf8:     	ldp	x28, x27, [sp, #288]
1000cccfc:     	ldrsb	w27, [x21, x27]
1000ccd00:     	ldrsb	w28, [x23, x28]
1000ccd04:     	add	w8, w8, w3
1000ccd08:     	ldr	x3, [sp, #280]
1000ccd0c:     	ldrsb	w3, [x22, x3]
1000ccd10:     	add	w8, w8, w27
1000ccd14:     	ldr	x27, [sp, #272]
1000ccd18:     	ldrsb	w27, [x24, x27]
1000ccd1c:     	add	w8, w8, w28
1000ccd20:     	ldr	x28, [sp, #264]
1000ccd24:     	ldrsb	w28, [x25, x28]
1000ccd28:     	add	w8, w8, w3
1000ccd2c:     	ldr	x3, [sp, #256]
1000ccd30:     	ldrsb	w3, [x26, x3]
1000ccd34:     	add	w8, w8, w27
1000ccd38:     	add	w8, w8, w28
1000ccd3c:     	add	w8, w8, w3
1000ccd40:     	scvtf	s2, w8
1000ccd44:     	ldp	x3, x8, [sp, #240]
1000ccd48:     	ldrsb	w8, [x19, x8]
1000ccd4c:     	ldrsb	w3, [x20, x3]
1000ccd50:     	ldp	x28, x27, [sp, #224]
1000ccd54:     	ldrsb	w27, [x21, x27]
1000ccd58:     	ldrsb	w28, [x23, x28]
1000ccd5c:     	add	w8, w8, w3
1000ccd60:     	ldr	x3, [sp, #216]
1000ccd64:     	ldrsb	w3, [x22, x3]
1000ccd68:     	add	w8, w8, w27
1000ccd6c:     	ldr	x27, [sp, #208]
1000ccd70:     	ldrsb	w27, [x24, x27]
1000ccd74:     	add	w8, w8, w28
1000ccd78:     	ldr	x28, [sp, #200]
1000ccd7c:     	ldrsb	w28, [x25, x28]
1000ccd80:     	add	w8, w8, w3
1000ccd84:     	ldr	x3, [sp, #192]
1000ccd88:     	ldrsb	w3, [x26, x3]
1000ccd8c:     	add	w8, w8, w27
1000ccd90:     	add	w8, w8, w28
1000ccd94:     	add	w8, w8, w3
1000ccd98:     	scvtf	s3, w8
1000ccd9c:     	ldp	x3, x8, [sp, #176]
1000ccda0:     	ldrsb	w8, [x19, x8]
1000ccda4:     	ldrsb	w3, [x20, x3]
1000ccda8:     	ldp	x28, x27, [sp, #160]
1000ccdac:     	ldrsb	w27, [x21, x27]
1000ccdb0:     	ldrsb	w28, [x23, x28]
1000ccdb4:     	add	w8, w8, w3
1000ccdb8:     	add	w8, w8, w27
1000ccdbc:     	ldr	x3, [sp, #152]
1000ccdc0:     	ldrsb	w3, [x22, x3]
1000ccdc4:     	add	w8, w8, w28
1000ccdc8:     	add	w8, w8, w3
1000ccdcc:     	ldp	x27, x3, [sp, #136]
1000ccdd0:     	ldrsb	w3, [x24, x3]
1000ccdd4:     	ldrsb	w27, [x25, x27]
1000ccdd8:     	add	w8, w8, w3
1000ccddc:     	add	w8, w8, w27
1000ccde0:     	ldr	x3, [sp, #128]
1000ccde4:     	ldrsb	w3, [x26, x3]
1000ccde8:     	add	w8, w8, w3
1000ccdec:     	scvtf	s4, w8
1000ccdf0:     	ldp	x3, x8, [sp, #112]
1000ccdf4:     	ldrsb	w8, [x19, x8]
1000ccdf8:     	ldrsb	w3, [x20, x3]
1000ccdfc:     	ldp	x28, x27, [sp, #96]
1000cce00:     	ldrsb	w27, [x21, x27]
1000cce04:     	ldrsb	w28, [x23, x28]
1000cce08:     	add	w8, w8, w3
1000cce0c:     	ldr	x3, [sp, #88]
1000cce10:     	ldrsb	w3, [x22, x3]
1000cce14:     	add	w8, w8, w27
1000cce18:     	ldr	x27, [sp, #80]
1000cce1c:     	ldrsb	w27, [x24, x27]
1000cce20:     	add	w8, w8, w28
1000cce24:     	ldr	x28, [sp, #72]
1000cce28:     	ldrsb	w28, [x25, x28]
1000cce2c:     	add	w8, w8, w3
1000cce30:     	add	w8, w8, w27
1000cce34:     	add	w8, w8, w28
1000cce38:     	ldr	x3, [sp, #64]
1000cce3c:     	ldrsb	w3, [x26, x3]
1000cce40:     	add	w8, w8, w3
1000cce44:     	scvtf	s5, w8
1000cce48:     	ldp	x3, x8, [sp, #48]
1000cce4c:     	ldrsb	w8, [x19, x8]
1000cce50:     	ldrsb	w3, [x20, x3]
1000cce54:     	ldr	x27, [sp, #40]
1000cce58:     	ldrsb	w27, [x21, x27]
1000cce5c:     	add	w8, w8, w3
1000cce60:     	ldr	x3, [sp, #32]
1000cce64:     	ldrsb	w3, [x23, x3]
1000cce68:     	add	w8, w8, w27
1000cce6c:     	ldrsb	w27, [x22, x10]
1000cce70:     	add	w8, w8, w3
1000cce74:     	ldrsb	w3, [x24, x13]
1000cce78:     	add	w8, w8, w27
1000cce7c:     	ldrsb	w27, [x25, x9]
1000cce80:     	add	w8, w8, w3
1000cce84:     	ldrsb	w3, [x26, x14]
1000cce88:     	add	w8, w8, w27
1000cce8c:     	add	w8, w8, w3
1000cce90:     	scvtf	s6, w8
1000cce94:     	ldrsb	w8, [x19, x15]
1000cce98:     	ldrsb	w3, [x20, x16]
1000cce9c:     	ldrsb	w19, [x21, x17]
1000ccea0:     	add	w8, w8, w3
1000ccea4:     	add	w8, w8, w19
1000ccea8:     	ldrsb	w3, [x23, x2]
1000cceac:     	ldrsb	w19, [x22, x4]
1000cceb0:     	add	w8, w8, w3
1000cceb4:     	add	w8, w8, w19
1000cceb8:     	ldrsb	w3, [x24, x5]
1000ccebc:     	ldrsb	w19, [x25, x6]
1000ccec0:     	add	w8, w8, w3
1000ccec4:     	add	w8, w8, w19
1000ccec8:     	mov	x19, x1
1000ccecc:     	ldrsb	w3, [x26, x7]
1000cced0:     	add	w8, w8, w3
1000cced4:     	add	x3, sp, #448
1000cced8:     	scvtf	s7, w8
1000ccedc:     	add	x8, x1, x12
1000ccee0:     	ldur	s16, [x8, #-192]
1000ccee4:     	fadd	s1, s16, s1
1000ccee8:     	stur	s1, [x8, #-192]
1000cceec:     	ldur	s1, [x8, #-128]
1000ccef0:     	fadd	s1, s1, s2
1000ccef4:     	stur	s1, [x8, #-128]
1000ccef8:     	ldur	s1, [x8, #-64]
1000ccefc:     	fadd	s1, s1, s3
1000ccf00:     	stur	s1, [x8, #-64]
1000ccf04:     	ldr	s1, [x8]
1000ccf08:     	fadd	s1, s1, s4
1000ccf0c:     	str	s1, [x8]
1000ccf10:     	ldr	s1, [x8, #64]
1000ccf14:     	fadd	s1, s1, s5
1000ccf18:     	str	s1, [x8, #64]
1000ccf1c:     	ldr	s1, [x8, #128]
1000ccf20:     	fadd	s1, s1, s6
1000ccf24:     	str	s1, [x8, #128]
1000ccf28:     	ldr	s1, [x8, #192]
1000ccf2c:     	fadd	s1, s1, s7
1000ccf30:     	ldr	s2, [x3, x12]
1000ccf34:     	str	s1, [x8, #192]
1000ccf38:     	fadd	s0, s2, s0
1000ccf3c:     	str	s0, [x3, x12]
1000ccf40:     	add	x12, x12, #4
1000ccf44:     	cmp	x12, #64
1000ccf48:     	b.ne	0x1000ccbd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000ccf4c:     	add	x0, x0, #64
1000ccf50:     	ldp	x8, x1, [sp, #16]
1000ccf54:     	add	x1, x1, #32
1000ccf58:     	cmp	x1, x8
1000ccf5c:     	b.ne	0x1000cca2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000ccf60:     	add	x1, sp, #448
1000ccf64:     	ldr	x0, [sp, #8]
1000ccf68:     	mov	w2, #512
1000ccf6c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ccf70:     	ldur	x8, [x29, #-96]
1000ccf74:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x248>
1000ccf78:     	ldr	x9, [x9, #392]
1000ccf7c:     	ldr	x9, [x9]
1000ccf80:     	cmp	x9, x8
1000ccf84:     	b.ne	0x1000ccfa8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000ccf88:     	add	sp, sp, #976
1000ccf8c:     	ldp	x29, x30, [sp, #80]
1000ccf90:     	ldp	x20, x19, [sp, #64]
1000ccf94:     	ldp	x22, x21, [sp, #48]
1000ccf98:     	ldp	x24, x23, [sp, #32]
1000ccf9c:     	ldp	x26, x25, [sp, #16]
1000ccfa0:     	ldp	x28, x27, [sp], #96
1000ccfa4:     	ret
1000ccfa8:     	bl	0x100163694 <_strcmp+0x100163694>

