00000001000b9aa0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b9aa0:     	stp	x24, x23, [sp, #-48]!
1000b9aa4:     	stp	x22, x21, [sp, #16]
1000b9aa8:     	stp	x20, x19, [sp, #32]
1000b9aac:     	stp	xzr, xzr, [x3]
1000b9ab0:     	lsl	x8, x4, #2
1000b9ab4:     	cmp	x2, #8
1000b9ab8:     	b.hs	0x1000b9acc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b9abc:     	mov	x13, #0
1000b9ac0:     	movi	d1, #0000000000000000
1000b9ac4:     	movi	d0, #0000000000000000
1000b9ac8:     	b	0x1000b9d14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000b9acc:     	mov	x10, #0
1000b9ad0:     	add	x9, x0, #8
1000b9ad4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f8>
1000b9ad8:     	add	x11, x11, #444
1000b9adc:     	mov	x12, x1
1000b9ae0:     	ldr	w5, [x12]
1000b9ae4:     	lsl	w13, w5, #4
1000b9ae8:     	and	x14, x13, #0xf0
1000b9aec:     	and	x13, x5, #0xf0
1000b9af0:     	add	x13, x11, x13
1000b9af4:     	add	x14, x11, x14
1000b9af8:     	lsr	x15, x5, #4
1000b9afc:     	and	x15, x15, #0xf0
1000b9b00:     	add	x15, x11, x15
1000b9b04:     	lsr	x16, x5, #8
1000b9b08:     	and	x16, x16, #0xf0
1000b9b0c:     	add	x16, x11, x16
1000b9b10:     	lsr	x17, x5, #12
1000b9b14:     	and	x17, x17, #0xf0
1000b9b18:     	add	x17, x11, x17
1000b9b1c:     	lsr	x4, x5, #16
1000b9b20:     	and	x4, x4, #0xf0
1000b9b24:     	add	x4, x11, x4
1000b9b28:     	lsr	x6, x5, #20
1000b9b2c:     	and	x6, x6, #0xf0
1000b9b30:     	lsr	x5, x5, #24
1000b9b34:     	and	x7, x5, #0xf0
1000b9b38:     	ldur	w19, [x9, #-8]
1000b9b3c:     	add	x5, x11, x6
1000b9b40:     	and	x6, x19, #0xf
1000b9b44:     	ubfx	x20, x19, #4, #4
1000b9b48:     	ldrsb	w20, [x13, x20]
1000b9b4c:     	ldrsb	w21, [x14, x6]
1000b9b50:     	ubfx	x6, x19, #8, #4
1000b9b54:     	ldrsb	w22, [x15, x6]
1000b9b58:     	ubfx	x6, x19, #12, #4
1000b9b5c:     	ldrsb	w23, [x16, x6]
1000b9b60:     	add	x6, x11, x7
1000b9b64:     	ubfx	x7, x19, #16, #4
1000b9b68:     	ldrsb	w7, [x17, x7]
1000b9b6c:     	add	w20, w21, w20
1000b9b70:     	add	w20, w20, w22
1000b9b74:     	ubfx	x21, x19, #20, #4
1000b9b78:     	ldrsb	w21, [x4, x21]
1000b9b7c:     	ubfx	x22, x19, #24, #4
1000b9b80:     	add	w20, w20, w23
1000b9b84:     	add	w7, w20, w7
1000b9b88:     	ldrsb	w20, [x5, x22]
1000b9b8c:     	lsr	x19, x19, #28
1000b9b90:     	ldrsb	w19, [x6, x19]
1000b9b94:     	add	w7, w7, w21
1000b9b98:     	add	w7, w7, w20
1000b9b9c:     	add	w7, w7, w19
1000b9ba0:     	scvtf	s0, w7
1000b9ba4:     	ldp	s1, s2, [x3]
1000b9ba8:     	fadd	s0, s1, s0
1000b9bac:     	str	s0, [x3]
1000b9bb0:     	ldur	w7, [x9, #-4]
1000b9bb4:     	and	x19, x7, #0xf
1000b9bb8:     	ldrsb	w19, [x14, x19]
1000b9bbc:     	ubfx	x20, x7, #4, #4
1000b9bc0:     	ldrsb	w20, [x13, x20]
1000b9bc4:     	ubfx	x21, x7, #8, #4
1000b9bc8:     	ldrsb	w21, [x15, x21]
1000b9bcc:     	ubfx	x22, x7, #12, #4
1000b9bd0:     	ldrsb	w22, [x16, x22]
1000b9bd4:     	ubfx	x23, x7, #16, #4
1000b9bd8:     	add	w19, w19, w20
1000b9bdc:     	add	w19, w19, w21
1000b9be0:     	ldrsb	w20, [x17, x23]
1000b9be4:     	ubfx	x21, x7, #20, #4
1000b9be8:     	ldrsb	w21, [x4, x21]
1000b9bec:     	add	w19, w19, w22
1000b9bf0:     	add	w19, w19, w20
1000b9bf4:     	ubfx	x20, x7, #24, #4
1000b9bf8:     	ldrsb	w20, [x5, x20]
1000b9bfc:     	add	w19, w19, w21
1000b9c00:     	add	w19, w19, w20
1000b9c04:     	lsr	x7, x7, #28
1000b9c08:     	ldrsb	w7, [x6, x7]
1000b9c0c:     	add	w7, w19, w7
1000b9c10:     	scvtf	s0, w7
1000b9c14:     	fadd	s0, s2, s0
1000b9c18:     	str	s0, [x3, #4]
1000b9c1c:     	ldr	w7, [x9]
1000b9c20:     	and	x19, x7, #0xf
1000b9c24:     	ldrsb	w19, [x14, x19]
1000b9c28:     	ubfx	x20, x7, #4, #4
1000b9c2c:     	ldrsb	w20, [x13, x20]
1000b9c30:     	ubfx	x21, x7, #8, #4
1000b9c34:     	ldrsb	w21, [x15, x21]
1000b9c38:     	ubfx	x22, x7, #12, #4
1000b9c3c:     	ldrsb	w22, [x16, x22]
1000b9c40:     	ubfx	x23, x7, #16, #4
1000b9c44:     	add	w19, w19, w20
1000b9c48:     	add	w19, w19, w21
1000b9c4c:     	ldrsb	w20, [x17, x23]
1000b9c50:     	ubfx	x21, x7, #20, #4
1000b9c54:     	ldrsb	w21, [x4, x21]
1000b9c58:     	add	w19, w19, w22
1000b9c5c:     	add	w19, w19, w20
1000b9c60:     	ubfx	x20, x7, #24, #4
1000b9c64:     	ldrsb	w20, [x5, x20]
1000b9c68:     	add	w19, w19, w21
1000b9c6c:     	add	w19, w19, w20
1000b9c70:     	lsr	x7, x7, #28
1000b9c74:     	ldrsb	w7, [x6, x7]
1000b9c78:     	add	w7, w19, w7
1000b9c7c:     	scvtf	s0, w7
1000b9c80:     	ldp	s1, s2, [x3, #8]
1000b9c84:     	fadd	s0, s1, s0
1000b9c88:     	str	s0, [x3, #8]
1000b9c8c:     	ldr	w7, [x9, #4]
1000b9c90:     	and	x19, x7, #0xf
1000b9c94:     	ldrsb	w14, [x14, x19]
1000b9c98:     	ubfx	x19, x7, #4, #4
1000b9c9c:     	ldrsb	w13, [x13, x19]
1000b9ca0:     	ubfx	x19, x7, #8, #4
1000b9ca4:     	ldrsb	w15, [x15, x19]
1000b9ca8:     	ubfx	x19, x7, #12, #4
1000b9cac:     	ldrsb	w16, [x16, x19]
1000b9cb0:     	ubfx	x19, x7, #16, #4
1000b9cb4:     	ldrsb	w17, [x17, x19]
1000b9cb8:     	add	w13, w14, w13
1000b9cbc:     	add	w13, w13, w15
1000b9cc0:     	ubfx	x14, x7, #20, #4
1000b9cc4:     	ldrsb	w14, [x4, x14]
1000b9cc8:     	ubfx	x15, x7, #24, #4
1000b9ccc:     	add	w13, w13, w16
1000b9cd0:     	add	w13, w13, w17
1000b9cd4:     	ldrsb	w15, [x5, x15]
1000b9cd8:     	lsr	x16, x7, #28
1000b9cdc:     	ldrsb	w16, [x6, x16]
1000b9ce0:     	add	w13, w13, w14
1000b9ce4:     	add	w13, w13, w15
1000b9ce8:     	add	w13, w13, w16
1000b9cec:     	scvtf	s1, w13
1000b9cf0:     	fadd	s1, s2, s1
1000b9cf4:     	str	s1, [x3, #12]
1000b9cf8:     	add	x13, x10, #8
1000b9cfc:     	add	x12, x12, x8
1000b9d00:     	add	x9, x9, #16
1000b9d04:     	add	x14, x10, #16
1000b9d08:     	mov	x10, x13
1000b9d0c:     	cmp	x14, x2
1000b9d10:     	b.ls	0x1000b9ae0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000b9d14:     	cmp	x13, x2
1000b9d18:     	b.hs	0x1000b9e00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x360>
1000b9d1c:     	ldp	s2, s3, [x3]
1000b9d20:     	lsl	w9, w13, #2
1000b9d24:     	mov	w10, #-16
1000b9d28:     	lsr	x11, x13, #3
1000b9d2c:     	mul	x12, x8, x11
1000b9d30:     	ubfx	x14, x13, #1, #2
1000b9d34:     	orr	x12, x12, x14
1000b9d38:     	ldrb	w12, [x1, x12]
1000b9d3c:     	and	w15, w9, #0x4
1000b9d40:     	lsr	w12, w12, w15
1000b9d44:     	and	w16, w12, #0xf
1000b9d48:     	cmp	w16, #8
1000b9d4c:     	csel	w16, wzr, w10, lo
1000b9d50:     	bfxil	w16, w12, #0, #4
1000b9d54:     	bfi	x14, x11, #4, #60
1000b9d58:     	add	x11, x0, x14
1000b9d5c:     	ldrb	w12, [x11]
1000b9d60:     	lsr	w12, w12, w15
1000b9d64:     	scvtf	s4, w16
1000b9d68:     	and	w14, w12, #0xf
1000b9d6c:     	cmp	w14, #8
1000b9d70:     	csel	w14, wzr, w10, lo
1000b9d74:     	bfxil	w14, w12, #0, #4
1000b9d78:     	scvtf	s5, w14
1000b9d7c:     	fmsub	s2, s5, s4, s2
1000b9d80:     	str	s2, [x3]
1000b9d84:     	ldrb	w12, [x11, #4]
1000b9d88:     	lsr	w12, w12, w15
1000b9d8c:     	and	w14, w12, #0xf
1000b9d90:     	cmp	w14, #8
1000b9d94:     	csel	w14, wzr, w10, lo
1000b9d98:     	bfxil	w14, w12, #0, #4
1000b9d9c:     	scvtf	s5, w14
1000b9da0:     	fmsub	s3, s5, s4, s3
1000b9da4:     	str	s3, [x3, #4]
1000b9da8:     	ldrb	w12, [x11, #8]
1000b9dac:     	lsr	w12, w12, w15
1000b9db0:     	and	w14, w12, #0xf
1000b9db4:     	cmp	w14, #8
1000b9db8:     	csel	w14, wzr, w10, lo
1000b9dbc:     	bfxil	w14, w12, #0, #4
1000b9dc0:     	scvtf	s5, w14
1000b9dc4:     	fmsub	s0, s5, s4, s0
1000b9dc8:     	str	s0, [x3, #8]
1000b9dcc:     	ldrb	w11, [x11, #12]
1000b9dd0:     	lsr	w11, w11, w15
1000b9dd4:     	and	w12, w11, #0xf
1000b9dd8:     	cmp	w12, #8
1000b9ddc:     	csel	w12, wzr, w10, lo
1000b9de0:     	bfxil	w12, w11, #0, #4
1000b9de4:     	scvtf	s5, w12
1000b9de8:     	fmsub	s1, s5, s4, s1
1000b9dec:     	str	s1, [x3, #12]
1000b9df0:     	add	x13, x13, #1
1000b9df4:     	add	w9, w9, #4
1000b9df8:     	cmp	x2, x13
1000b9dfc:     	b.ne	0x1000b9d28 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000b9e00:     	ldp	x20, x19, [sp, #32]
1000b9e04:     	ldp	x22, x21, [sp, #16]
1000b9e08:     	ldp	x24, x23, [sp], #48
1000b9e0c:     	ret

