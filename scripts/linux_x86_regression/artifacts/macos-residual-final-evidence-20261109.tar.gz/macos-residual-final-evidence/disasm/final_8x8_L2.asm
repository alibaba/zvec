00000001000c4d24 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c4d24:     	stp	x28, x27, [sp, #-96]!
1000c4d28:     	stp	x26, x25, [sp, #16]
1000c4d2c:     	stp	x24, x23, [sp, #32]
1000c4d30:     	stp	x22, x21, [sp, #48]
1000c4d34:     	stp	x20, x19, [sp, #64]
1000c4d38:     	stp	x29, x30, [sp, #80]
1000c4d3c:     	add	x29, sp, #80
1000c4d40:     	sub	sp, sp, #720
1000c4d44:     	str	x3, [sp, #8]
1000c4d48:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c4>
1000c4d4c:     	ldr	x8, [x8, #392]
1000c4d50:     	ldr	x8, [x8]
1000c4d54:     	stur	x8, [x29, #-96]
1000c4d58:     	movi.2d	v0, #0000000000000000
1000c4d5c:     	stp	q0, q0, [sp, #672]
1000c4d60:     	lsl	x8, x2, #2
1000c4d64:     	stp	q0, q0, [sp, #640]
1000c4d68:     	stp	q0, q0, [sp, #608]
1000c4d6c:     	stp	q0, q0, [sp, #576]
1000c4d70:     	stp	q0, q0, [sp, #544]
1000c4d74:     	stp	q0, q0, [sp, #512]
1000c4d78:     	stp	q0, q0, [sp, #480]
1000c4d7c:     	stp	q0, q0, [sp, #448]
1000c4d80:     	ands	x8, x8, #0xfffffffffffffff8
1000c4d84:     	b.eq	0x1000c52d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c4d88:     	add	x8, x1, x8
1000c4d8c:     	str	x8, [sp, #16]
1000c4d90:     	add	x8, sp, #448
1000c4d94:     	add	x19, x8, #128
1000c4d98:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000c4d9c:     	add	x11, x11, #700
1000c4da0:     	mov	x12, #0
1000c4da4:     	ldp	w8, w9, [x1]
1000c4da8:     	ubfx	x10, x8, #8, #4
1000c4dac:     	str	x10, [sp, #440]
1000c4db0:     	ubfx	x10, x8, #16, #4
1000c4db4:     	str	x10, [sp, #432]
1000c4db8:     	ubfx	x10, x8, #24, #4
1000c4dbc:     	str	x10, [sp, #424]
1000c4dc0:     	ldp	w10, w13, [x1, #8]
1000c4dc4:     	and	x15, x8, #0xf
1000c4dc8:     	ubfx	x14, x8, #4, #4
1000c4dcc:     	stp	x14, x15, [sp, #408]
1000c4dd0:     	ubfx	x15, x8, #12, #4
1000c4dd4:     	ubfx	x14, x8, #20, #4
1000c4dd8:     	stp	x14, x15, [sp, #392]
1000c4ddc:     	lsr	x8, x8, #28
1000c4de0:     	str	x8, [sp, #384]
1000c4de4:     	and	x8, x9, #0xf
1000c4de8:     	str	x8, [sp, #376]
1000c4dec:     	ubfx	x8, x9, #8, #4
1000c4df0:     	str	x8, [sp, #368]
1000c4df4:     	ubfx	x8, x9, #16, #4
1000c4df8:     	str	x8, [sp, #360]
1000c4dfc:     	ubfx	x8, x9, #24, #4
1000c4e00:     	str	x8, [sp, #352]
1000c4e04:     	ubfx	x8, x9, #4, #4
1000c4e08:     	str	x8, [sp, #344]
1000c4e0c:     	ubfx	x8, x9, #12, #4
1000c4e10:     	str	x8, [sp, #336]
1000c4e14:     	ubfx	x8, x9, #20, #4
1000c4e18:     	str	x8, [sp, #328]
1000c4e1c:     	lsr	x8, x9, #28
1000c4e20:     	str	x8, [sp, #320]
1000c4e24:     	and	x9, x10, #0xf
1000c4e28:     	ubfx	x8, x10, #8, #4
1000c4e2c:     	stp	x8, x9, [sp, #304]
1000c4e30:     	ubfx	x9, x10, #16, #4
1000c4e34:     	ubfx	x8, x10, #24, #4
1000c4e38:     	stp	x8, x9, [sp, #288]
1000c4e3c:     	ubfx	x9, x10, #4, #4
1000c4e40:     	ubfx	x8, x10, #12, #4
1000c4e44:     	stp	x8, x9, [sp, #272]
1000c4e48:     	ubfx	x9, x10, #20, #4
1000c4e4c:     	lsr	x8, x10, #28
1000c4e50:     	stp	x8, x9, [sp, #256]
1000c4e54:     	and	x9, x13, #0xf
1000c4e58:     	ubfx	x8, x13, #8, #4
1000c4e5c:     	stp	x8, x9, [sp, #240]
1000c4e60:     	ubfx	x9, x13, #16, #4
1000c4e64:     	ubfx	x8, x13, #24, #4
1000c4e68:     	stp	x8, x9, [sp, #224]
1000c4e6c:     	ubfx	x9, x13, #4, #4
1000c4e70:     	ubfx	x8, x13, #12, #4
1000c4e74:     	stp	x8, x9, [sp, #208]
1000c4e78:     	ubfx	x9, x13, #20, #4
1000c4e7c:     	lsr	x8, x13, #28
1000c4e80:     	stp	x8, x9, [sp, #192]
1000c4e84:     	ldp	w8, w9, [x1, #16]
1000c4e88:     	and	x10, x8, #0xf
1000c4e8c:     	str	x10, [sp, #184]
1000c4e90:     	ubfx	x10, x8, #8, #4
1000c4e94:     	str	x10, [sp, #176]
1000c4e98:     	ubfx	x10, x8, #16, #4
1000c4e9c:     	str	x10, [sp, #168]
1000c4ea0:     	ubfx	x10, x8, #24, #4
1000c4ea4:     	str	x10, [sp, #160]
1000c4ea8:     	ubfx	x10, x8, #4, #4
1000c4eac:     	str	x10, [sp, #152]
1000c4eb0:     	ubfx	x10, x8, #12, #4
1000c4eb4:     	str	x10, [sp, #144]
1000c4eb8:     	ubfx	x10, x8, #20, #4
1000c4ebc:     	lsr	x8, x8, #28
1000c4ec0:     	stp	x8, x10, [sp, #128]
1000c4ec4:     	and	x10, x9, #0xf
1000c4ec8:     	ubfx	x8, x9, #8, #4
1000c4ecc:     	stp	x8, x10, [sp, #112]
1000c4ed0:     	ubfx	x10, x9, #16, #4
1000c4ed4:     	ubfx	x8, x9, #24, #4
1000c4ed8:     	stp	x8, x10, [sp, #96]
1000c4edc:     	ubfx	x10, x9, #4, #4
1000c4ee0:     	ubfx	x8, x9, #12, #4
1000c4ee4:     	stp	x8, x10, [sp, #80]
1000c4ee8:     	ubfx	x10, x9, #20, #4
1000c4eec:     	lsr	x8, x9, #28
1000c4ef0:     	stp	x8, x10, [sp, #64]
1000c4ef4:     	ldp	w14, w7, [x1, #24]
1000c4ef8:     	and	x9, x14, #0xf
1000c4efc:     	ubfx	x8, x14, #8, #4
1000c4f00:     	stp	x8, x9, [sp, #48]
1000c4f04:     	ubfx	x8, x14, #16, #4
1000c4f08:     	str	x8, [sp, #40]
1000c4f0c:     	ubfx	x8, x14, #24, #4
1000c4f10:     	stp	x1, x8, [sp, #24]
1000c4f14:     	ubfx	x10, x14, #4, #4
1000c4f18:     	ubfx	x13, x14, #12, #4
1000c4f1c:     	ubfx	x9, x14, #20, #4
1000c4f20:     	lsr	x14, x14, #28
1000c4f24:     	and	x15, x7, #0xf
1000c4f28:     	ubfx	x16, x7, #8, #4
1000c4f2c:     	ubfx	x17, x7, #16, #4
1000c4f30:     	ubfx	x2, x7, #24, #4
1000c4f34:     	ubfx	x4, x7, #4, #4
1000c4f38:     	ubfx	x5, x7, #12, #4
1000c4f3c:     	ubfx	x6, x7, #20, #4
1000c4f40:     	lsr	x7, x7, #28
1000c4f44:     	ldr	w26, [x0, x12]
1000c4f48:     	mov	x1, x19
1000c4f4c:     	lsl	w19, w26, #4
1000c4f50:     	and	x19, x19, #0xf0
1000c4f54:     	add	x19, x11, x19
1000c4f58:     	ldr	x8, [sp, #416]
1000c4f5c:     	ldrb	w25, [x19, x8]
1000c4f60:     	lsr	x20, x26, #4
1000c4f64:     	and	x20, x20, #0xf0
1000c4f68:     	add	x20, x11, x20
1000c4f6c:     	ldr	x8, [sp, #440]
1000c4f70:     	ldrb	w27, [x20, x8]
1000c4f74:     	lsr	x21, x26, #12
1000c4f78:     	and	x21, x21, #0xf0
1000c4f7c:     	add	x21, x11, x21
1000c4f80:     	ldr	x8, [sp, #432]
1000c4f84:     	ldrb	w28, [x21, x8]
1000c4f88:     	lsr	x22, x26, #20
1000c4f8c:     	and	x22, x22, #0xf0
1000c4f90:     	add	x23, x11, x22
1000c4f94:     	ldr	x8, [sp, #424]
1000c4f98:     	ldrb	w30, [x23, x8]
1000c4f9c:     	and	x22, x26, #0xf0
1000c4fa0:     	add	x22, x11, x22
1000c4fa4:     	ldp	x3, x8, [sp, #400]
1000c4fa8:     	ldrb	w8, [x22, x8]
1000c4fac:     	lsr	x24, x26, #8
1000c4fb0:     	and	x24, x24, #0xf0
1000c4fb4:     	add	x24, x11, x24
1000c4fb8:     	ldrb	w3, [x24, x3]
1000c4fbc:     	add	w27, w25, w27
1000c4fc0:     	lsr	x25, x26, #16
1000c4fc4:     	and	x25, x25, #0xf0
1000c4fc8:     	add	x25, x11, x25
1000c4fcc:     	add	w27, w27, w28
1000c4fd0:     	ldr	x28, [sp, #392]
1000c4fd4:     	ldrb	w28, [x25, x28]
1000c4fd8:     	lsr	x26, x26, #24
1000c4fdc:     	and	x26, x26, #0xf0
1000c4fe0:     	add	x26, x11, x26
1000c4fe4:     	add	w27, w27, w30
1000c4fe8:     	ldr	x30, [sp, #384]
1000c4fec:     	ldrb	w30, [x26, x30]
1000c4ff0:     	add	w8, w27, w8
1000c4ff4:     	add	w8, w8, w3
1000c4ff8:     	add	w8, w8, w28
1000c4ffc:     	add	w8, w8, w30
1000c5000:     	scvtf	s0, w8
1000c5004:     	ldp	x3, x8, [sp, #368]
1000c5008:     	ldrb	w8, [x19, x8]
1000c500c:     	ldrb	w3, [x20, x3]
1000c5010:     	ldp	x28, x27, [sp, #352]
1000c5014:     	ldrb	w27, [x21, x27]
1000c5018:     	ldrb	w28, [x23, x28]
1000c501c:     	ldr	x30, [sp, #344]
1000c5020:     	ldrb	w30, [x22, x30]
1000c5024:     	add	w8, w8, w3
1000c5028:     	ldr	x3, [sp, #336]
1000c502c:     	ldrb	w3, [x24, x3]
1000c5030:     	add	w8, w8, w27
1000c5034:     	ldr	x27, [sp, #328]
1000c5038:     	ldrb	w27, [x25, x27]
1000c503c:     	add	w8, w8, w28
1000c5040:     	ldr	x28, [sp, #320]
1000c5044:     	ldrb	w28, [x26, x28]
1000c5048:     	add	w8, w8, w30
1000c504c:     	add	w8, w8, w3
1000c5050:     	add	w8, w8, w27
1000c5054:     	add	w8, w8, w28
1000c5058:     	scvtf	s1, w8
1000c505c:     	ldp	x3, x8, [sp, #304]
1000c5060:     	ldrb	w8, [x19, x8]
1000c5064:     	ldrb	w3, [x20, x3]
1000c5068:     	ldp	x28, x27, [sp, #288]
1000c506c:     	ldrb	w27, [x21, x27]
1000c5070:     	ldrb	w28, [x23, x28]
1000c5074:     	add	w8, w8, w3
1000c5078:     	ldr	x3, [sp, #280]
1000c507c:     	ldrb	w3, [x22, x3]
1000c5080:     	add	w8, w8, w27
1000c5084:     	ldr	x27, [sp, #272]
1000c5088:     	ldrb	w27, [x24, x27]
1000c508c:     	add	w8, w8, w28
1000c5090:     	ldr	x28, [sp, #264]
1000c5094:     	ldrb	w28, [x25, x28]
1000c5098:     	add	w8, w8, w3
1000c509c:     	ldr	x3, [sp, #256]
1000c50a0:     	ldrb	w3, [x26, x3]
1000c50a4:     	add	w8, w8, w27
1000c50a8:     	add	w8, w8, w28
1000c50ac:     	add	w8, w8, w3
1000c50b0:     	scvtf	s2, w8
1000c50b4:     	ldp	x3, x8, [sp, #240]
1000c50b8:     	ldrb	w8, [x19, x8]
1000c50bc:     	ldrb	w3, [x20, x3]
1000c50c0:     	ldp	x28, x27, [sp, #224]
1000c50c4:     	ldrb	w27, [x21, x27]
1000c50c8:     	ldrb	w28, [x23, x28]
1000c50cc:     	add	w8, w8, w3
1000c50d0:     	ldr	x3, [sp, #216]
1000c50d4:     	ldrb	w3, [x22, x3]
1000c50d8:     	add	w8, w8, w27
1000c50dc:     	ldr	x27, [sp, #208]
1000c50e0:     	ldrb	w27, [x24, x27]
1000c50e4:     	add	w8, w8, w28
1000c50e8:     	ldr	x28, [sp, #200]
1000c50ec:     	ldrb	w28, [x25, x28]
1000c50f0:     	add	w8, w8, w3
1000c50f4:     	ldr	x3, [sp, #192]
1000c50f8:     	ldrb	w3, [x26, x3]
1000c50fc:     	add	w8, w8, w27
1000c5100:     	add	w8, w8, w28
1000c5104:     	add	w8, w8, w3
1000c5108:     	scvtf	s3, w8
1000c510c:     	ldp	x3, x8, [sp, #176]
1000c5110:     	ldrb	w8, [x19, x8]
1000c5114:     	ldrb	w3, [x20, x3]
1000c5118:     	ldp	x28, x27, [sp, #160]
1000c511c:     	ldrb	w27, [x21, x27]
1000c5120:     	ldrb	w28, [x23, x28]
1000c5124:     	add	w8, w8, w3
1000c5128:     	add	w8, w8, w27
1000c512c:     	ldr	x3, [sp, #152]
1000c5130:     	ldrb	w3, [x22, x3]
1000c5134:     	add	w8, w8, w28
1000c5138:     	add	w8, w8, w3
1000c513c:     	ldp	x27, x3, [sp, #136]
1000c5140:     	ldrb	w3, [x24, x3]
1000c5144:     	ldrb	w27, [x25, x27]
1000c5148:     	add	w8, w8, w3
1000c514c:     	add	w8, w8, w27
1000c5150:     	ldr	x3, [sp, #128]
1000c5154:     	ldrb	w3, [x26, x3]
1000c5158:     	add	w8, w8, w3
1000c515c:     	scvtf	s4, w8
1000c5160:     	ldp	x3, x8, [sp, #112]
1000c5164:     	ldrb	w8, [x19, x8]
1000c5168:     	ldrb	w3, [x20, x3]
1000c516c:     	ldp	x28, x27, [sp, #96]
1000c5170:     	ldrb	w27, [x21, x27]
1000c5174:     	ldrb	w28, [x23, x28]
1000c5178:     	add	w8, w8, w3
1000c517c:     	ldr	x3, [sp, #88]
1000c5180:     	ldrb	w3, [x22, x3]
1000c5184:     	add	w8, w8, w27
1000c5188:     	ldr	x27, [sp, #80]
1000c518c:     	ldrb	w27, [x24, x27]
1000c5190:     	add	w8, w8, w28
1000c5194:     	ldr	x28, [sp, #72]
1000c5198:     	ldrb	w28, [x25, x28]
1000c519c:     	add	w8, w8, w3
1000c51a0:     	add	w8, w8, w27
1000c51a4:     	add	w8, w8, w28
1000c51a8:     	ldr	x3, [sp, #64]
1000c51ac:     	ldrb	w3, [x26, x3]
1000c51b0:     	add	w8, w8, w3
1000c51b4:     	scvtf	s5, w8
1000c51b8:     	ldp	x3, x8, [sp, #48]
1000c51bc:     	ldrb	w8, [x19, x8]
1000c51c0:     	ldrb	w3, [x20, x3]
1000c51c4:     	ldr	x27, [sp, #40]
1000c51c8:     	ldrb	w27, [x21, x27]
1000c51cc:     	add	w8, w8, w3
1000c51d0:     	ldr	x3, [sp, #32]
1000c51d4:     	ldrb	w3, [x23, x3]
1000c51d8:     	add	w8, w8, w27
1000c51dc:     	ldrb	w27, [x22, x10]
1000c51e0:     	add	w8, w8, w3
1000c51e4:     	ldrb	w3, [x24, x13]
1000c51e8:     	add	w8, w8, w27
1000c51ec:     	ldrb	w27, [x25, x9]
1000c51f0:     	add	w8, w8, w3
1000c51f4:     	ldrb	w3, [x26, x14]
1000c51f8:     	add	w8, w8, w27
1000c51fc:     	add	w8, w8, w3
1000c5200:     	scvtf	s6, w8
1000c5204:     	ldrb	w8, [x19, x15]
1000c5208:     	ldrb	w3, [x20, x16]
1000c520c:     	ldrb	w19, [x21, x17]
1000c5210:     	add	w8, w8, w3
1000c5214:     	add	w8, w8, w19
1000c5218:     	ldrb	w3, [x23, x2]
1000c521c:     	ldrb	w19, [x22, x4]
1000c5220:     	add	w8, w8, w3
1000c5224:     	add	w8, w8, w19
1000c5228:     	ldrb	w3, [x24, x5]
1000c522c:     	ldrb	w19, [x25, x6]
1000c5230:     	add	w8, w8, w3
1000c5234:     	add	w8, w8, w19
1000c5238:     	mov	x19, x1
1000c523c:     	ldrb	w3, [x26, x7]
1000c5240:     	add	w8, w8, w3
1000c5244:     	add	x3, sp, #448
1000c5248:     	scvtf	s7, w8
1000c524c:     	add	x8, x1, x12
1000c5250:     	ldur	s16, [x8, #-96]
1000c5254:     	fadd	s1, s16, s1
1000c5258:     	stur	s1, [x8, #-96]
1000c525c:     	ldur	s1, [x8, #-64]
1000c5260:     	fadd	s1, s1, s2
1000c5264:     	stur	s1, [x8, #-64]
1000c5268:     	ldur	s1, [x8, #-32]
1000c526c:     	fadd	s1, s1, s3
1000c5270:     	stur	s1, [x8, #-32]
1000c5274:     	ldr	s1, [x8]
1000c5278:     	fadd	s1, s1, s4
1000c527c:     	str	s1, [x8]
1000c5280:     	ldr	s1, [x8, #32]
1000c5284:     	fadd	s1, s1, s5
1000c5288:     	str	s1, [x8, #32]
1000c528c:     	ldr	s1, [x8, #64]
1000c5290:     	fadd	s1, s1, s6
1000c5294:     	str	s1, [x8, #64]
1000c5298:     	ldr	s1, [x8, #96]
1000c529c:     	fadd	s1, s1, s7
1000c52a0:     	ldr	s2, [x3, x12]
1000c52a4:     	str	s1, [x8, #96]
1000c52a8:     	fadd	s0, s2, s0
1000c52ac:     	str	s0, [x3, x12]
1000c52b0:     	add	x12, x12, #4
1000c52b4:     	cmp	x12, #32
1000c52b8:     	b.ne	0x1000c4f44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c52bc:     	add	x0, x0, #32
1000c52c0:     	ldp	x8, x1, [sp, #16]
1000c52c4:     	add	x1, x1, #32
1000c52c8:     	cmp	x1, x8
1000c52cc:     	b.ne	0x1000c4da0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c52d0:     	ldp	q0, q1, [sp, #640]
1000c52d4:     	ldr	x8, [sp, #8]
1000c52d8:     	stp	q0, q1, [x8, #192]
1000c52dc:     	ldp	q0, q1, [sp, #672]
1000c52e0:     	stp	q0, q1, [x8, #224]
1000c52e4:     	ldp	q0, q1, [sp, #576]
1000c52e8:     	stp	q0, q1, [x8, #128]
1000c52ec:     	ldp	q0, q1, [sp, #608]
1000c52f0:     	stp	q0, q1, [x8, #160]
1000c52f4:     	ldp	q0, q1, [sp, #512]
1000c52f8:     	stp	q0, q1, [x8, #64]
1000c52fc:     	ldp	q0, q1, [sp, #544]
1000c5300:     	stp	q0, q1, [x8, #96]
1000c5304:     	ldp	q0, q1, [sp, #448]
1000c5308:     	stp	q0, q1, [x8]
1000c530c:     	ldp	q0, q1, [sp, #480]
1000c5310:     	stp	q0, q1, [x8, #32]
1000c5314:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c5318:     	ldr	x8, [x8, #392]
1000c531c:     	ldr	x8, [x8]
1000c5320:     	ldur	x9, [x29, #-96]
1000c5324:     	cmp	x8, x9
1000c5328:     	b.ne	0x1000c534c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c532c:     	add	sp, sp, #720
1000c5330:     	ldp	x29, x30, [sp, #80]
1000c5334:     	ldp	x20, x19, [sp, #64]
1000c5338:     	ldp	x22, x21, [sp, #48]
1000c533c:     	ldp	x24, x23, [sp, #32]
1000c5340:     	ldp	x26, x25, [sp, #16]
1000c5344:     	ldp	x28, x27, [sp], #96
1000c5348:     	ret
1000c534c:     	bl	0x100163694 <_strcmp+0x100163694>

