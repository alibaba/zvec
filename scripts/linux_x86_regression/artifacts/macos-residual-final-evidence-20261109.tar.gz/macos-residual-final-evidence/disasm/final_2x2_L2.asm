00000001000b7e0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b7e0c:     	stp	x22, x21, [sp, #-32]!
1000b7e10:     	stp	x20, x19, [sp, #16]
1000b7e14:     	ands	x8, x2, #0xfffffffffffffffe
1000b7e18:     	b.eq	0x1000b809c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b7e1c:     	add	x8, x1, x8
1000b7e20:     	movi	d0, #0000000000000000
1000b7e24:     	adrp	x9, 0x100169000 <void kernel<unsigned char, 2ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24>
1000b7e28:     	add	x9, x9, #3772
1000b7e2c:     	movi	d1, #0000000000000000
1000b7e30:     	movi	d2, #0000000000000000
1000b7e34:     	movi	d3, #0000000000000000
1000b7e38:     	ldp	w10, w11, [x0]
1000b7e3c:     	lsl	w12, w10, #4
1000b7e40:     	and	x14, x12, #0xf0
1000b7e44:     	mov	x15, x14
1000b7e48:     	ldp	w12, w13, [x1]
1000b7e4c:     	bfxil	x15, x12, #0, #4
1000b7e50:     	ldrb	w15, [x9, x15]
1000b7e54:     	and	x16, x10, #0xf0
1000b7e58:     	mov	x17, x16
1000b7e5c:     	bfxil	x17, x12, #4, #4
1000b7e60:     	ldrb	w17, [x9, x17]
1000b7e64:     	lsr	x2, x10, #4
1000b7e68:     	and	x2, x2, #0xf0
1000b7e6c:     	mov	x4, x2
1000b7e70:     	bfxil	x4, x12, #8, #4
1000b7e74:     	ldrb	w4, [x9, x4]
1000b7e78:     	lsr	x5, x10, #8
1000b7e7c:     	and	x5, x5, #0xf0
1000b7e80:     	mov	x6, x5
1000b7e84:     	bfxil	x6, x12, #12, #4
1000b7e88:     	ldrb	w6, [x9, x6]
1000b7e8c:     	lsr	x7, x10, #12
1000b7e90:     	and	x7, x7, #0xf0
1000b7e94:     	mov	x19, x7
1000b7e98:     	bfxil	x19, x12, #16, #4
1000b7e9c:     	ldrb	w19, [x9, x19]
1000b7ea0:     	add	w15, w15, w17
1000b7ea4:     	add	w15, w15, w4
1000b7ea8:     	lsr	x17, x10, #16
1000b7eac:     	and	x17, x17, #0xf0
1000b7eb0:     	mov	x4, x17
1000b7eb4:     	bfxil	x4, x12, #20, #4
1000b7eb8:     	add	w15, w15, w6
1000b7ebc:     	add	w15, w15, w19
1000b7ec0:     	ldrb	w4, [x9, x4]
1000b7ec4:     	lsr	x6, x10, #20
1000b7ec8:     	and	x6, x6, #0xf0
1000b7ecc:     	mov	x19, x6
1000b7ed0:     	bfxil	x19, x12, #24, #4
1000b7ed4:     	ldrb	w19, [x9, x19]
1000b7ed8:     	add	w15, w15, w4
1000b7edc:     	add	w15, w15, w19
1000b7ee0:     	lsr	x10, x10, #24
1000b7ee4:     	and	x4, x10, #0xf0
1000b7ee8:     	lsr	x10, x12, #28
1000b7eec:     	orr	x19, x4, x10
1000b7ef0:     	ldrb	w19, [x9, x19]
1000b7ef4:     	add	w15, w15, w19
1000b7ef8:     	scvtf	s4, w15
1000b7efc:     	fadd	s0, s0, s4
1000b7f00:     	bfxil	x14, x13, #0, #4
1000b7f04:     	ldrb	w14, [x9, x14]
1000b7f08:     	and	x15, x13, #0xf
1000b7f0c:     	ubfx	x19, x13, #4, #4
1000b7f10:     	bfxil	x16, x13, #4, #4
1000b7f14:     	ldrb	w16, [x9, x16]
1000b7f18:     	ubfx	x20, x13, #8, #4
1000b7f1c:     	bfxil	x2, x13, #8, #4
1000b7f20:     	ldrb	w2, [x9, x2]
1000b7f24:     	add	w14, w14, w16
1000b7f28:     	add	w14, w14, w2
1000b7f2c:     	ubfx	x16, x13, #12, #4
1000b7f30:     	bfxil	x5, x13, #12, #4
1000b7f34:     	ldrb	w2, [x9, x5]
1000b7f38:     	bfxil	x7, x13, #16, #4
1000b7f3c:     	ldrb	w5, [x9, x7]
1000b7f40:     	ubfx	x7, x13, #16, #4
1000b7f44:     	add	w14, w14, w2
1000b7f48:     	add	w14, w14, w5
1000b7f4c:     	bfxil	x17, x13, #20, #4
1000b7f50:     	ldrb	w17, [x9, x17]
1000b7f54:     	bfxil	x6, x13, #24, #4
1000b7f58:     	ldrb	w2, [x9, x6]
1000b7f5c:     	add	w14, w14, w17
1000b7f60:     	add	w17, w14, w2
1000b7f64:     	lsr	x14, x13, #28
1000b7f68:     	orr	x2, x4, x14
1000b7f6c:     	ldrb	w2, [x9, x2]
1000b7f70:     	add	w17, w17, w2
1000b7f74:     	scvtf	s4, w17
1000b7f78:     	ubfx	x17, x13, #20, #4
1000b7f7c:     	fadd	s2, s2, s4
1000b7f80:     	lsl	w2, w11, #4
1000b7f84:     	and	x2, x2, #0xf0
1000b7f88:     	orr	w15, w2, w15
1000b7f8c:     	bfxil	x2, x12, #0, #4
1000b7f90:     	ldrb	w2, [x9, x2]
1000b7f94:     	and	x4, x11, #0xf0
1000b7f98:     	orr	w5, w4, w19
1000b7f9c:     	bfxil	x4, x12, #4, #4
1000b7fa0:     	ldrb	w4, [x9, x4]
1000b7fa4:     	lsr	x6, x11, #4
1000b7fa8:     	and	x6, x6, #0xf0
1000b7fac:     	orr	w19, w6, w20
1000b7fb0:     	bfxil	x6, x12, #8, #4
1000b7fb4:     	ldrb	w6, [x9, x6]
1000b7fb8:     	add	w2, w2, w4
1000b7fbc:     	add	w2, w2, w6
1000b7fc0:     	lsr	x4, x11, #8
1000b7fc4:     	and	x4, x4, #0xf0
1000b7fc8:     	orr	w16, w4, w16
1000b7fcc:     	lsr	x6, x11, #12
1000b7fd0:     	and	x6, x6, #0xf0
1000b7fd4:     	orr	w7, w6, w7
1000b7fd8:     	lsr	x20, x11, #16
1000b7fdc:     	and	x20, x20, #0xf0
1000b7fe0:     	orr	w17, w20, w17
1000b7fe4:     	lsr	x21, x11, #20
1000b7fe8:     	and	x21, x21, #0xf0
1000b7fec:     	ubfx	x13, x13, #24, #4
1000b7ff0:     	orr	w13, w21, w13
1000b7ff4:     	bfxil	x4, x12, #12, #4
1000b7ff8:     	ldrb	w4, [x9, x4]
1000b7ffc:     	bfxil	x6, x12, #16, #4
1000b8000:     	ldrb	w6, [x9, x6]
1000b8004:     	bfxil	x20, x12, #20, #4
1000b8008:     	ldrb	w20, [x9, x20]
1000b800c:     	bfxil	x21, x12, #24, #4
1000b8010:     	ldrb	w12, [x9, x21]
1000b8014:     	add	w2, w2, w4
1000b8018:     	add	w2, w2, w6
1000b801c:     	add	w2, w2, w20
1000b8020:     	add	w12, w2, w12
1000b8024:     	lsr	x11, x11, #24
1000b8028:     	and	x11, x11, #0xf0
1000b802c:     	orr	x10, x11, x10
1000b8030:     	ldrb	w10, [x9, x10]
1000b8034:     	add	w10, w12, w10
1000b8038:     	scvtf	s4, w10
1000b803c:     	fadd	s1, s1, s4
1000b8040:     	ldrb	w10, [x9, w15, uxtw]
1000b8044:     	ldrb	w12, [x9, w5, uxtw]
1000b8048:     	ldrb	w15, [x9, w19, uxtw]
1000b804c:     	add	w10, w10, w12
1000b8050:     	add	w10, w10, w15
1000b8054:     	ldrb	w12, [x9, w16, uxtw]
1000b8058:     	ldrb	w15, [x9, w7, uxtw]
1000b805c:     	add	w10, w10, w12
1000b8060:     	add	w10, w10, w15
1000b8064:     	ldrb	w12, [x9, w17, uxtw]
1000b8068:     	ldrb	w13, [x9, w13, uxtw]
1000b806c:     	add	w10, w10, w12
1000b8070:     	add	w10, w10, w13
1000b8074:     	orr	w11, w11, w14
1000b8078:     	ldrb	w11, [x9, w11, uxtw]
1000b807c:     	add	w10, w10, w11
1000b8080:     	scvtf	s4, w10
1000b8084:     	fadd	s3, s3, s4
1000b8088:     	add	x0, x0, #8
1000b808c:     	add	x1, x1, #8
1000b8090:     	cmp	x1, x8
1000b8094:     	b.ne	0x1000b7e38 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8098:     	b	0x1000b80ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b809c:     	movi	d0, #0000000000000000
1000b80a0:     	movi	d1, #0000000000000000
1000b80a4:     	movi	d2, #0000000000000000
1000b80a8:     	movi	d3, #0000000000000000
1000b80ac:     	str	s0, [x3]
1000b80b0:     	str	s1, [x3, #4]
1000b80b4:     	str	s2, [x3, #8]
1000b80b8:     	str	s3, [x3, #12]
1000b80bc:     	ldp	x20, x19, [sp, #16]
1000b80c0:     	ldp	x22, x21, [sp], #32
1000b80c4:     	ret

