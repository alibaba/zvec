00000001000d9818 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9818:     	stp	x28, x27, [sp, #-80]!
1000d981c:     	stp	x24, x23, [sp, #16]
1000d9820:     	stp	x22, x21, [sp, #32]
1000d9824:     	stp	x20, x19, [sp, #48]
1000d9828:     	stp	x29, x30, [sp, #64]
1000d982c:     	add	x29, sp, #64
1000d9830:     	mov	w9, #4368
1000d9834:     	adrp	x16, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x268>
1000d9838:     	ldr	x16, [x16, #304]
1000d983c:     	blr	x16
1000d9840:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9844:     	sub	sp, sp, #272
1000d9848:     	mov	x19, x3
1000d984c:     	mov	x20, x1
1000d9850:     	mov	x21, x0
1000d9854:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d9858:     	ldr	x8, [x8, #392]
1000d985c:     	ldr	x8, [x8]
1000d9860:     	stur	x8, [x29, #-72]
1000d9864:     	lsl	x8, x2, #4
1000d9868:     	and	x22, x8, #0xffffffffffffffe0
1000d986c:     	add	x0, sp, #264
1000d9870:     	mov	w1, #4096
1000d9874:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9878:     	cbz	x22, 0x1000d9b60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x348>
1000d987c:     	add	x8, x20, x22
1000d9880:     	mov	w9, #252645135
1000d9884:     	adrp	x10, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d9888:     	add	x10, x10, #1724
1000d988c:     	add	x11, sp, #8
1000d9890:     	mov	x12, #0
1000d9894:     	ldp	w13, w14, [x20]
1000d9898:     	and	w15, w13, w9
1000d989c:     	and	w13, w9, w13, lsr #4
1000d98a0:     	stp	w15, w13, [sp, #8]
1000d98a4:     	and	w13, w14, w9
1000d98a8:     	and	w14, w9, w14, lsr #4
1000d98ac:     	stp	w13, w14, [sp, #16]
1000d98b0:     	ldp	w13, w14, [x20, #8]
1000d98b4:     	and	w15, w13, w9
1000d98b8:     	and	w13, w9, w13, lsr #4
1000d98bc:     	stp	w15, w13, [sp, #24]
1000d98c0:     	and	w13, w14, w9
1000d98c4:     	and	w14, w9, w14, lsr #4
1000d98c8:     	stp	w13, w14, [sp, #32]
1000d98cc:     	ldp	w13, w14, [x20, #16]
1000d98d0:     	and	w15, w13, w9
1000d98d4:     	and	w13, w9, w13, lsr #4
1000d98d8:     	stp	w15, w13, [sp, #40]
1000d98dc:     	and	w13, w14, w9
1000d98e0:     	and	w14, w9, w14, lsr #4
1000d98e4:     	stp	w13, w14, [sp, #48]
1000d98e8:     	ldp	w13, w14, [x20, #24]
1000d98ec:     	and	w15, w13, w9
1000d98f0:     	and	w13, w9, w13, lsr #4
1000d98f4:     	stp	w15, w13, [sp, #56]
1000d98f8:     	and	w13, w14, w9
1000d98fc:     	and	w14, w9, w14, lsr #4
1000d9900:     	stp	w13, w14, [sp, #64]
1000d9904:     	ldp	w13, w14, [x20, #32]
1000d9908:     	and	w15, w13, w9
1000d990c:     	and	w13, w9, w13, lsr #4
1000d9910:     	stp	w15, w13, [sp, #72]
1000d9914:     	and	w13, w14, w9
1000d9918:     	and	w14, w9, w14, lsr #4
1000d991c:     	stp	w13, w14, [sp, #80]
1000d9920:     	ldp	w13, w14, [x20, #40]
1000d9924:     	and	w15, w13, w9
1000d9928:     	and	w13, w9, w13, lsr #4
1000d992c:     	stp	w15, w13, [sp, #88]
1000d9930:     	and	w13, w14, w9
1000d9934:     	and	w14, w9, w14, lsr #4
1000d9938:     	stp	w13, w14, [sp, #96]
1000d993c:     	ldp	w13, w14, [x20, #48]
1000d9940:     	and	w15, w13, w9
1000d9944:     	and	w13, w9, w13, lsr #4
1000d9948:     	stp	w15, w13, [sp, #104]
1000d994c:     	and	w13, w14, w9
1000d9950:     	and	w14, w9, w14, lsr #4
1000d9954:     	stp	w13, w14, [sp, #112]
1000d9958:     	ldp	w13, w14, [x20, #56]
1000d995c:     	and	w15, w13, w9
1000d9960:     	and	w13, w9, w13, lsr #4
1000d9964:     	stp	w15, w13, [sp, #120]
1000d9968:     	and	w13, w14, w9
1000d996c:     	and	w14, w9, w14, lsr #4
1000d9970:     	stp	w13, w14, [sp, #128]
1000d9974:     	ldp	w13, w14, [x20, #64]
1000d9978:     	and	w15, w13, w9
1000d997c:     	and	w13, w9, w13, lsr #4
1000d9980:     	stp	w15, w13, [sp, #136]
1000d9984:     	and	w13, w14, w9
1000d9988:     	and	w14, w9, w14, lsr #4
1000d998c:     	stp	w13, w14, [sp, #144]
1000d9990:     	ldp	w13, w14, [x20, #72]
1000d9994:     	and	w15, w13, w9
1000d9998:     	and	w13, w9, w13, lsr #4
1000d999c:     	stp	w15, w13, [sp, #152]
1000d99a0:     	and	w13, w14, w9
1000d99a4:     	and	w14, w9, w14, lsr #4
1000d99a8:     	stp	w13, w14, [sp, #160]
1000d99ac:     	ldp	w13, w14, [x20, #80]
1000d99b0:     	and	w15, w13, w9
1000d99b4:     	and	w13, w9, w13, lsr #4
1000d99b8:     	stp	w15, w13, [sp, #168]
1000d99bc:     	and	w13, w14, w9
1000d99c0:     	and	w14, w9, w14, lsr #4
1000d99c4:     	stp	w13, w14, [sp, #176]
1000d99c8:     	ldp	w13, w14, [x20, #88]
1000d99cc:     	and	w15, w13, w9
1000d99d0:     	and	w13, w9, w13, lsr #4
1000d99d4:     	stp	w15, w13, [sp, #184]
1000d99d8:     	and	w13, w14, w9
1000d99dc:     	and	w14, w9, w14, lsr #4
1000d99e0:     	stp	w13, w14, [sp, #192]
1000d99e4:     	ldp	w13, w14, [x20, #96]
1000d99e8:     	and	w15, w13, w9
1000d99ec:     	and	w13, w9, w13, lsr #4
1000d99f0:     	stp	w15, w13, [sp, #200]
1000d99f4:     	and	w13, w14, w9
1000d99f8:     	and	w14, w9, w14, lsr #4
1000d99fc:     	stp	w13, w14, [sp, #208]
1000d9a00:     	ldp	w13, w14, [x20, #104]
1000d9a04:     	and	w15, w13, w9
1000d9a08:     	and	w13, w9, w13, lsr #4
1000d9a0c:     	stp	w15, w13, [sp, #216]
1000d9a10:     	and	w13, w14, w9
1000d9a14:     	and	w14, w9, w14, lsr #4
1000d9a18:     	stp	w13, w14, [sp, #224]
1000d9a1c:     	ldp	w13, w14, [x20, #112]
1000d9a20:     	and	w15, w13, w9
1000d9a24:     	and	w13, w9, w13, lsr #4
1000d9a28:     	stp	w15, w13, [sp, #232]
1000d9a2c:     	and	w13, w14, w9
1000d9a30:     	and	w14, w9, w14, lsr #4
1000d9a34:     	stp	w13, w14, [sp, #240]
1000d9a38:     	ldp	w13, w14, [x20, #120]
1000d9a3c:     	and	w15, w13, w9
1000d9a40:     	and	w13, w9, w13, lsr #4
1000d9a44:     	stp	w15, w13, [sp, #248]
1000d9a48:     	and	w13, w14, w9
1000d9a4c:     	and	w14, w9, w14, lsr #4
1000d9a50:     	str	w13, [sp, #256]
1000d9a54:     	str	w14, [sp, #260]
1000d9a58:     	add	x13, sp, #264
1000d9a5c:     	mov	x14, #0
1000d9a60:     	ldr	w4, [x21, x12, lsl #2]
1000d9a64:     	lsl	w15, w4, #4
1000d9a68:     	and	x15, x15, #0xf0
1000d9a6c:     	add	x15, x10, x15
1000d9a70:     	and	x16, x4, #0xf0
1000d9a74:     	add	x16, x10, x16
1000d9a78:     	lsr	x17, x4, #4
1000d9a7c:     	and	x17, x17, #0xf0
1000d9a80:     	add	x17, x10, x17
1000d9a84:     	lsr	x0, x4, #8
1000d9a88:     	and	x0, x0, #0xf0
1000d9a8c:     	add	x0, x10, x0
1000d9a90:     	lsr	x1, x4, #12
1000d9a94:     	and	x1, x1, #0xf0
1000d9a98:     	add	x1, x10, x1
1000d9a9c:     	lsr	x2, x4, #16
1000d9aa0:     	and	x2, x2, #0xf0
1000d9aa4:     	add	x2, x10, x2
1000d9aa8:     	lsr	x3, x4, #20
1000d9aac:     	and	x3, x3, #0xf0
1000d9ab0:     	add	x3, x10, x3
1000d9ab4:     	lsr	x4, x4, #24
1000d9ab8:     	and	x4, x4, #0xf0
1000d9abc:     	add	x4, x10, x4
1000d9ac0:     	mov	x5, x13
1000d9ac4:     	add	x6, x11, x14
1000d9ac8:     	ldrb	w7, [x6]
1000d9acc:     	ldrb	w7, [x15, x7]
1000d9ad0:     	ldrb	w22, [x6, #1]
1000d9ad4:     	ldrb	w22, [x17, x22]
1000d9ad8:     	ldrb	w23, [x6, #2]
1000d9adc:     	ldrb	w23, [x1, x23]
1000d9ae0:     	add	w7, w7, w22
1000d9ae4:     	add	w7, w7, w23
1000d9ae8:     	ldrb	w22, [x6, #3]
1000d9aec:     	ldrb	w22, [x3, x22]
1000d9af0:     	ldrb	w23, [x6, #4]
1000d9af4:     	ldrb	w23, [x16, x23]
1000d9af8:     	ldrb	w24, [x6, #5]
1000d9afc:     	ldrb	w24, [x0, x24]
1000d9b00:     	add	w7, w7, w22
1000d9b04:     	add	w7, w7, w23
1000d9b08:     	ldrb	w22, [x6, #6]
1000d9b0c:     	ldrb	w22, [x2, x22]
1000d9b10:     	add	w7, w7, w24
1000d9b14:     	add	w7, w7, w22
1000d9b18:     	ldrb	w6, [x6, #7]
1000d9b1c:     	ldrb	w6, [x4, x6]
1000d9b20:     	add	w6, w7, w6
1000d9b24:     	scvtf	s0, w6
1000d9b28:     	ldr	s1, [x5]
1000d9b2c:     	fadd	s0, s1, s0
1000d9b30:     	str	s0, [x5], #128
1000d9b34:     	add	x14, x14, #8
1000d9b38:     	cmp	x14, #256
1000d9b3c:     	b.ne	0x1000d9ac4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d9b40:     	add	x12, x12, #1
1000d9b44:     	add	x13, x13, #4
1000d9b48:     	cmp	x12, #32
1000d9b4c:     	b.ne	0x1000d9a5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000d9b50:     	add	x21, x21, #128
1000d9b54:     	add	x20, x20, #128
1000d9b58:     	cmp	x20, x8
1000d9b5c:     	b.ne	0x1000d9890 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x78>
1000d9b60:     	add	x1, sp, #264
1000d9b64:     	mov	x0, x19
1000d9b68:     	mov	w2, #4096
1000d9b6c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9b70:     	ldur	x8, [x29, #-72]
1000d9b74:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x15c>
1000d9b78:     	ldr	x9, [x9, #392]
1000d9b7c:     	ldr	x9, [x9]
1000d9b80:     	cmp	x9, x8
1000d9b84:     	b.ne	0x1000d9ba8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x390>
1000d9b88:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9b8c:     	add	sp, sp, #272
1000d9b90:     	ldp	x29, x30, [sp, #64]
1000d9b94:     	ldp	x20, x19, [sp, #48]
1000d9b98:     	ldp	x22, x21, [sp, #32]
1000d9b9c:     	ldp	x24, x23, [sp, #16]
1000d9ba0:     	ldp	x28, x27, [sp], #80
1000d9ba4:     	ret
1000d9ba8:     	bl	0x100163694 <_strcmp+0x100163694>

