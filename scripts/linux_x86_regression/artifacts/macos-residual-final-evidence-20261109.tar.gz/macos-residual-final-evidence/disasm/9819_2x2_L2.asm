00000001000b619c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b619c:     	stp	x22, x21, [sp, #-32]!
1000b61a0:     	stp	x20, x19, [sp, #16]
1000b61a4:     	ands	x8, x2, #0xfffffffffffffffe
1000b61a8:     	b.eq	0x1000b642c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b61ac:     	add	x8, x1, x8
1000b61b0:     	movi	d0, #0000000000000000
1000b61b4:     	adrp	x9, 0x100165000 <void kernel<unsigned char, 2ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18>
1000b61b8:     	add	x9, x9, #3804
1000b61bc:     	movi	d1, #0000000000000000
1000b61c0:     	movi	d2, #0000000000000000
1000b61c4:     	movi	d3, #0000000000000000
1000b61c8:     	ldp	w10, w11, [x0]
1000b61cc:     	lsl	w12, w10, #4
1000b61d0:     	and	x14, x12, #0xf0
1000b61d4:     	mov	x15, x14
1000b61d8:     	ldp	w12, w13, [x1]
1000b61dc:     	bfxil	x15, x12, #0, #4
1000b61e0:     	ldrb	w15, [x9, x15]
1000b61e4:     	and	x16, x10, #0xf0
1000b61e8:     	mov	x17, x16
1000b61ec:     	bfxil	x17, x12, #4, #4
1000b61f0:     	ldrb	w17, [x9, x17]
1000b61f4:     	lsr	x2, x10, #4
1000b61f8:     	and	x2, x2, #0xf0
1000b61fc:     	mov	x4, x2
1000b6200:     	bfxil	x4, x12, #8, #4
1000b6204:     	ldrb	w4, [x9, x4]
1000b6208:     	lsr	x5, x10, #8
1000b620c:     	and	x5, x5, #0xf0
1000b6210:     	mov	x6, x5
1000b6214:     	bfxil	x6, x12, #12, #4
1000b6218:     	ldrb	w6, [x9, x6]
1000b621c:     	lsr	x7, x10, #12
1000b6220:     	and	x7, x7, #0xf0
1000b6224:     	mov	x19, x7
1000b6228:     	bfxil	x19, x12, #16, #4
1000b622c:     	ldrb	w19, [x9, x19]
1000b6230:     	add	w15, w15, w17
1000b6234:     	add	w15, w15, w4
1000b6238:     	lsr	x17, x10, #16
1000b623c:     	and	x17, x17, #0xf0
1000b6240:     	mov	x4, x17
1000b6244:     	bfxil	x4, x12, #20, #4
1000b6248:     	add	w15, w15, w6
1000b624c:     	add	w15, w15, w19
1000b6250:     	ldrb	w4, [x9, x4]
1000b6254:     	lsr	x6, x10, #20
1000b6258:     	and	x6, x6, #0xf0
1000b625c:     	mov	x19, x6
1000b6260:     	bfxil	x19, x12, #24, #4
1000b6264:     	ldrb	w19, [x9, x19]
1000b6268:     	add	w15, w15, w4
1000b626c:     	add	w15, w15, w19
1000b6270:     	lsr	x10, x10, #24
1000b6274:     	and	x4, x10, #0xf0
1000b6278:     	lsr	x10, x12, #28
1000b627c:     	orr	x19, x4, x10
1000b6280:     	ldrb	w19, [x9, x19]
1000b6284:     	add	w15, w15, w19
1000b6288:     	scvtf	s4, w15
1000b628c:     	fadd	s0, s0, s4
1000b6290:     	bfxil	x14, x13, #0, #4
1000b6294:     	ldrb	w14, [x9, x14]
1000b6298:     	and	x15, x13, #0xf
1000b629c:     	ubfx	x19, x13, #4, #4
1000b62a0:     	bfxil	x16, x13, #4, #4
1000b62a4:     	ldrb	w16, [x9, x16]
1000b62a8:     	ubfx	x20, x13, #8, #4
1000b62ac:     	bfxil	x2, x13, #8, #4
1000b62b0:     	ldrb	w2, [x9, x2]
1000b62b4:     	add	w14, w14, w16
1000b62b8:     	add	w14, w14, w2
1000b62bc:     	ubfx	x16, x13, #12, #4
1000b62c0:     	bfxil	x5, x13, #12, #4
1000b62c4:     	ldrb	w2, [x9, x5]
1000b62c8:     	bfxil	x7, x13, #16, #4
1000b62cc:     	ldrb	w5, [x9, x7]
1000b62d0:     	ubfx	x7, x13, #16, #4
1000b62d4:     	add	w14, w14, w2
1000b62d8:     	add	w14, w14, w5
1000b62dc:     	bfxil	x17, x13, #20, #4
1000b62e0:     	ldrb	w17, [x9, x17]
1000b62e4:     	bfxil	x6, x13, #24, #4
1000b62e8:     	ldrb	w2, [x9, x6]
1000b62ec:     	add	w14, w14, w17
1000b62f0:     	add	w17, w14, w2
1000b62f4:     	lsr	x14, x13, #28
1000b62f8:     	orr	x2, x4, x14
1000b62fc:     	ldrb	w2, [x9, x2]
1000b6300:     	add	w17, w17, w2
1000b6304:     	scvtf	s4, w17
1000b6308:     	ubfx	x17, x13, #20, #4
1000b630c:     	fadd	s2, s2, s4
1000b6310:     	lsl	w2, w11, #4
1000b6314:     	and	x2, x2, #0xf0
1000b6318:     	orr	w15, w2, w15
1000b631c:     	bfxil	x2, x12, #0, #4
1000b6320:     	ldrb	w2, [x9, x2]
1000b6324:     	and	x4, x11, #0xf0
1000b6328:     	orr	w5, w4, w19
1000b632c:     	bfxil	x4, x12, #4, #4
1000b6330:     	ldrb	w4, [x9, x4]
1000b6334:     	lsr	x6, x11, #4
1000b6338:     	and	x6, x6, #0xf0
1000b633c:     	orr	w19, w6, w20
1000b6340:     	bfxil	x6, x12, #8, #4
1000b6344:     	ldrb	w6, [x9, x6]
1000b6348:     	add	w2, w2, w4
1000b634c:     	add	w2, w2, w6
1000b6350:     	lsr	x4, x11, #8
1000b6354:     	and	x4, x4, #0xf0
1000b6358:     	orr	w16, w4, w16
1000b635c:     	lsr	x6, x11, #12
1000b6360:     	and	x6, x6, #0xf0
1000b6364:     	orr	w7, w6, w7
1000b6368:     	lsr	x20, x11, #16
1000b636c:     	and	x20, x20, #0xf0
1000b6370:     	orr	w17, w20, w17
1000b6374:     	lsr	x21, x11, #20
1000b6378:     	and	x21, x21, #0xf0
1000b637c:     	ubfx	x13, x13, #24, #4
1000b6380:     	orr	w13, w21, w13
1000b6384:     	bfxil	x4, x12, #12, #4
1000b6388:     	ldrb	w4, [x9, x4]
1000b638c:     	bfxil	x6, x12, #16, #4
1000b6390:     	ldrb	w6, [x9, x6]
1000b6394:     	bfxil	x20, x12, #20, #4
1000b6398:     	ldrb	w20, [x9, x20]
1000b639c:     	bfxil	x21, x12, #24, #4
1000b63a0:     	ldrb	w12, [x9, x21]
1000b63a4:     	add	w2, w2, w4
1000b63a8:     	add	w2, w2, w6
1000b63ac:     	add	w2, w2, w20
1000b63b0:     	add	w12, w2, w12
1000b63b4:     	lsr	x11, x11, #24
1000b63b8:     	and	x11, x11, #0xf0
1000b63bc:     	orr	x10, x11, x10
1000b63c0:     	ldrb	w10, [x9, x10]
1000b63c4:     	add	w10, w12, w10
1000b63c8:     	scvtf	s4, w10
1000b63cc:     	fadd	s1, s1, s4
1000b63d0:     	ldrb	w10, [x9, w15, uxtw]
1000b63d4:     	ldrb	w12, [x9, w5, uxtw]
1000b63d8:     	ldrb	w15, [x9, w19, uxtw]
1000b63dc:     	add	w10, w10, w12
1000b63e0:     	add	w10, w10, w15
1000b63e4:     	ldrb	w12, [x9, w16, uxtw]
1000b63e8:     	ldrb	w15, [x9, w7, uxtw]
1000b63ec:     	add	w10, w10, w12
1000b63f0:     	add	w10, w10, w15
1000b63f4:     	ldrb	w12, [x9, w17, uxtw]
1000b63f8:     	ldrb	w13, [x9, w13, uxtw]
1000b63fc:     	add	w10, w10, w12
1000b6400:     	add	w10, w10, w13
1000b6404:     	orr	w11, w11, w14
1000b6408:     	ldrb	w11, [x9, w11, uxtw]
1000b640c:     	add	w10, w10, w11
1000b6410:     	scvtf	s4, w10
1000b6414:     	fadd	s3, s3, s4
1000b6418:     	add	x0, x0, #8
1000b641c:     	add	x1, x1, #8
1000b6420:     	cmp	x1, x8
1000b6424:     	b.ne	0x1000b61c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b6428:     	b	0x1000b643c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b642c:     	movi	d0, #0000000000000000
1000b6430:     	movi	d1, #0000000000000000
1000b6434:     	movi	d2, #0000000000000000
1000b6438:     	movi	d3, #0000000000000000
1000b643c:     	str	s0, [x3]
1000b6440:     	str	s1, [x3, #4]
1000b6444:     	str	s2, [x3, #8]
1000b6448:     	str	s3, [x3, #12]
1000b644c:     	ldp	x20, x19, [sp, #16]
1000b6450:     	ldp	x22, x21, [sp], #32
1000b6454:     	ret

