00000001000c2f80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c2f80:     	sub	sp, sp, #416
1000c2f84:     	stp	x28, x27, [sp, #320]
1000c2f88:     	stp	x26, x25, [sp, #336]
1000c2f8c:     	stp	x24, x23, [sp, #352]
1000c2f90:     	stp	x22, x21, [sp, #368]
1000c2f94:     	stp	x20, x19, [sp, #384]
1000c2f98:     	stp	x29, x30, [sp, #400]
1000c2f9c:     	add	x29, sp, #400
1000c2fa0:     	str	x3, [sp]
1000c2fa4:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2cc>
1000c2fa8:     	ldr	x8, [x8, #392]
1000c2fac:     	ldr	x8, [x8]
1000c2fb0:     	stur	x8, [x29, #-96]
1000c2fb4:     	movi.2d	v0, #0000000000000000
1000c2fb8:     	stp	q0, q0, [sp, #272]
1000c2fbc:     	lsl	x8, x2, #1
1000c2fc0:     	stp	q0, q0, [sp, #240]
1000c2fc4:     	stp	q0, q0, [sp, #208]
1000c2fc8:     	stp	q0, q0, [sp, #176]
1000c2fcc:     	ands	x8, x8, #0xfffffffffffffffc
1000c2fd0:     	b.eq	0x1000c32ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c2fd4:     	add	x8, x1, x8
1000c2fd8:     	str	x8, [sp, #8]
1000c2fdc:     	add	x8, sp, #176
1000c2fe0:     	add	x27, x8, #64
1000c2fe4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x304>
1000c2fe8:     	add	x11, x11, #700
1000c2fec:     	mov	x12, #0
1000c2ff0:     	ldp	w8, w9, [x1]
1000c2ff4:     	ubfx	x10, x8, #8, #4
1000c2ff8:     	str	x10, [sp, #168]
1000c2ffc:     	ubfx	x10, x8, #16, #4
1000c3000:     	str	x10, [sp, #160]
1000c3004:     	ubfx	x10, x8, #24, #4
1000c3008:     	str	x10, [sp, #152]
1000c300c:     	ldp	w10, w17, [x1, #8]
1000c3010:     	str	x1, [sp, #16]
1000c3014:     	and	x14, x8, #0xf
1000c3018:     	ubfx	x13, x8, #4, #4
1000c301c:     	stp	x13, x14, [sp, #136]
1000c3020:     	ubfx	x14, x8, #12, #4
1000c3024:     	ubfx	x13, x8, #20, #4
1000c3028:     	stp	x13, x14, [sp, #120]
1000c302c:     	lsr	x8, x8, #28
1000c3030:     	str	x8, [sp, #112]
1000c3034:     	and	x8, x9, #0xf
1000c3038:     	str	x8, [sp, #104]
1000c303c:     	ubfx	x8, x9, #8, #4
1000c3040:     	str	x8, [sp, #96]
1000c3044:     	ubfx	x8, x9, #16, #4
1000c3048:     	str	x8, [sp, #88]
1000c304c:     	ubfx	x8, x9, #24, #4
1000c3050:     	str	x8, [sp, #80]
1000c3054:     	ubfx	x8, x9, #4, #4
1000c3058:     	str	x8, [sp, #72]
1000c305c:     	ubfx	x8, x9, #12, #4
1000c3060:     	str	x8, [sp, #64]
1000c3064:     	ubfx	x8, x9, #20, #4
1000c3068:     	str	x8, [sp, #56]
1000c306c:     	lsr	x8, x9, #28
1000c3070:     	str	x8, [sp, #48]
1000c3074:     	and	x9, x10, #0xf
1000c3078:     	ubfx	x8, x10, #8, #4
1000c307c:     	stp	x8, x9, [sp, #32]
1000c3080:     	ubfx	x8, x10, #16, #4
1000c3084:     	str	x8, [sp, #24]
1000c3088:     	ubfx	x28, x10, #24, #4
1000c308c:     	ubfx	x30, x10, #4, #4
1000c3090:     	ubfx	x8, x10, #12, #4
1000c3094:     	ubfx	x3, x10, #20, #4
1000c3098:     	lsr	x9, x10, #28
1000c309c:     	and	x1, x17, #0xf
1000c30a0:     	ubfx	x10, x17, #8, #4
1000c30a4:     	ubfx	x13, x17, #16, #4
1000c30a8:     	ubfx	x26, x17, #24, #4
1000c30ac:     	ubfx	x14, x17, #4, #4
1000c30b0:     	ubfx	x15, x17, #12, #4
1000c30b4:     	ubfx	x16, x17, #20, #4
1000c30b8:     	lsr	x17, x17, #28
1000c30bc:     	ldr	w20, [x0, x12]
1000c30c0:     	lsl	w2, w20, #4
1000c30c4:     	and	x2, x2, #0xf0
1000c30c8:     	add	x5, x11, x2
1000c30cc:     	and	x2, x20, #0xf0
1000c30d0:     	add	x2, x11, x2
1000c30d4:     	lsr	x4, x20, #4
1000c30d8:     	and	x4, x4, #0xf0
1000c30dc:     	add	x7, x11, x4
1000c30e0:     	lsr	x4, x20, #8
1000c30e4:     	and	x4, x4, #0xf0
1000c30e8:     	add	x4, x11, x4
1000c30ec:     	lsr	x6, x20, #12
1000c30f0:     	and	x6, x6, #0xf0
1000c30f4:     	add	x19, x11, x6
1000c30f8:     	lsr	x6, x20, #16
1000c30fc:     	and	x6, x6, #0xf0
1000c3100:     	add	x6, x11, x6
1000c3104:     	lsr	x21, x20, #20
1000c3108:     	and	x21, x21, #0xf0
1000c310c:     	add	x21, x11, x21
1000c3110:     	lsr	x20, x20, #24
1000c3114:     	and	x20, x20, #0xf0
1000c3118:     	ldr	x22, [sp, #144]
1000c311c:     	ldrb	w22, [x5, x22]
1000c3120:     	add	x20, x11, x20
1000c3124:     	ldp	x24, x23, [sp, #160]
1000c3128:     	ldrb	w23, [x7, x23]
1000c312c:     	ldrb	w24, [x19, x24]
1000c3130:     	add	w22, w22, w23
1000c3134:     	add	w22, w22, w24
1000c3138:     	ldr	x23, [sp, #152]
1000c313c:     	ldrb	w23, [x21, x23]
1000c3140:     	ldr	x24, [sp, #136]
1000c3144:     	ldrb	w24, [x2, x24]
1000c3148:     	add	w22, w22, w23
1000c314c:     	add	w22, w22, w24
1000c3150:     	ldp	x24, x23, [sp, #120]
1000c3154:     	ldrb	w23, [x4, x23]
1000c3158:     	ldrb	w24, [x6, x24]
1000c315c:     	add	w22, w22, w23
1000c3160:     	add	w22, w22, w24
1000c3164:     	ldr	x23, [sp, #112]
1000c3168:     	ldrb	w23, [x20, x23]
1000c316c:     	add	w22, w22, w23
1000c3170:     	scvtf	s0, w22
1000c3174:     	ldp	x23, x22, [sp, #96]
1000c3178:     	ldrb	w22, [x5, x22]
1000c317c:     	ldrb	w23, [x7, x23]
1000c3180:     	ldp	x25, x24, [sp, #80]
1000c3184:     	ldrb	w24, [x19, x24]
1000c3188:     	ldrb	w25, [x21, x25]
1000c318c:     	add	w22, w22, w23
1000c3190:     	ldr	x23, [sp, #72]
1000c3194:     	ldrb	w23, [x2, x23]
1000c3198:     	add	w22, w22, w24
1000c319c:     	ldr	x24, [sp, #64]
1000c31a0:     	ldrb	w24, [x4, x24]
1000c31a4:     	add	w22, w22, w25
1000c31a8:     	ldr	x25, [sp, #56]
1000c31ac:     	ldrb	w25, [x6, x25]
1000c31b0:     	add	w22, w22, w23
1000c31b4:     	add	w22, w22, w24
1000c31b8:     	add	w22, w22, w25
1000c31bc:     	ldr	x23, [sp, #48]
1000c31c0:     	ldrb	w23, [x20, x23]
1000c31c4:     	add	w22, w22, w23
1000c31c8:     	scvtf	s1, w22
1000c31cc:     	ldp	x23, x22, [sp, #32]
1000c31d0:     	ldrb	w22, [x5, x22]
1000c31d4:     	ldrb	w23, [x7, x23]
1000c31d8:     	ldr	x24, [sp, #24]
1000c31dc:     	ldrb	w24, [x19, x24]
1000c31e0:     	add	w22, w22, w23
1000c31e4:     	ldrb	w23, [x21, x28]
1000c31e8:     	add	w22, w22, w24
1000c31ec:     	ldrb	w24, [x2, x30]
1000c31f0:     	add	w22, w22, w23
1000c31f4:     	ldrb	w23, [x4, x8]
1000c31f8:     	add	w22, w22, w24
1000c31fc:     	ldrb	w24, [x6, x3]
1000c3200:     	add	w22, w22, w23
1000c3204:     	ldrb	w23, [x20, x9]
1000c3208:     	add	w22, w22, w24
1000c320c:     	add	w22, w22, w23
1000c3210:     	scvtf	s2, w22
1000c3214:     	ldrb	w5, [x5, x1]
1000c3218:     	ldrb	w7, [x7, x10]
1000c321c:     	ldrb	w19, [x19, x13]
1000c3220:     	add	w5, w5, w7
1000c3224:     	add	w5, w5, w19
1000c3228:     	ldrb	w7, [x21, x26]
1000c322c:     	ldrb	w2, [x2, x14]
1000c3230:     	add	w5, w5, w7
1000c3234:     	add	w2, w5, w2
1000c3238:     	ldrb	w4, [x4, x15]
1000c323c:     	ldrb	w5, [x6, x16]
1000c3240:     	add	w2, w2, w4
1000c3244:     	add	w2, w2, w5
1000c3248:     	ldrb	w4, [x20, x17]
1000c324c:     	add	w2, w2, w4
1000c3250:     	add	x4, sp, #176
1000c3254:     	scvtf	s3, w2
1000c3258:     	add	x2, x27, x12
1000c325c:     	ldur	s4, [x2, #-32]
1000c3260:     	fadd	s1, s4, s1
1000c3264:     	stur	s1, [x2, #-32]
1000c3268:     	ldr	s1, [x2]
1000c326c:     	fadd	s1, s1, s2
1000c3270:     	str	s1, [x2]
1000c3274:     	ldr	s1, [x2, #32]
1000c3278:     	fadd	s1, s1, s3
1000c327c:     	ldr	s2, [x4, x12]
1000c3280:     	str	s1, [x2, #32]
1000c3284:     	fadd	s0, s2, s0
1000c3288:     	str	s0, [x4, x12]
1000c328c:     	add	x12, x12, #4
1000c3290:     	cmp	x12, #32
1000c3294:     	b.ne	0x1000c30bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3298:     	add	x0, x0, #32
1000c329c:     	ldp	x8, x1, [sp, #8]
1000c32a0:     	add	x1, x1, #16
1000c32a4:     	cmp	x1, x8
1000c32a8:     	b.ne	0x1000c2fec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c32ac:     	ldp	q0, q1, [sp, #240]
1000c32b0:     	ldr	x8, [sp]
1000c32b4:     	stp	q0, q1, [x8, #64]
1000c32b8:     	ldp	q0, q1, [sp, #272]
1000c32bc:     	stp	q0, q1, [x8, #96]
1000c32c0:     	ldp	q0, q1, [sp, #176]
1000c32c4:     	stp	q0, q1, [x8]
1000c32c8:     	ldp	q0, q1, [sp, #208]
1000c32cc:     	stp	q0, q1, [x8, #32]
1000c32d0:     	ldur	x8, [x29, #-96]
1000c32d4:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000c32d8:     	ldr	x9, [x9, #392]
1000c32dc:     	ldr	x9, [x9]
1000c32e0:     	cmp	x9, x8
1000c32e4:     	b.ne	0x1000c3308 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c32e8:     	ldp	x29, x30, [sp, #400]
1000c32ec:     	ldp	x20, x19, [sp, #384]
1000c32f0:     	ldp	x22, x21, [sp, #368]
1000c32f4:     	ldp	x24, x23, [sp, #352]
1000c32f8:     	ldp	x26, x25, [sp, #336]
1000c32fc:     	ldp	x28, x27, [sp, #320]
1000c3300:     	add	sp, sp, #416
1000c3304:     	ret
1000c3308:     	bl	0x100163694 <_strcmp+0x100163694>

