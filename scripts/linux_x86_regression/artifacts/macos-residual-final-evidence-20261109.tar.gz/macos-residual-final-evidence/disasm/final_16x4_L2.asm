00000001000c9fe8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c9fe8:     	stp	x28, x27, [sp, #-96]!
1000c9fec:     	stp	x26, x25, [sp, #16]
1000c9ff0:     	stp	x24, x23, [sp, #32]
1000c9ff4:     	stp	x22, x21, [sp, #48]
1000c9ff8:     	stp	x20, x19, [sp, #64]
1000c9ffc:     	stp	x29, x30, [sp, #80]
1000ca000:     	add	x29, sp, #80
1000ca004:     	sub	sp, sp, #448
1000ca008:     	str	x3, [sp]
1000ca00c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000ca010:     	ldr	x8, [x8, #392]
1000ca014:     	ldr	x8, [x8]
1000ca018:     	stur	x8, [x29, #-96]
1000ca01c:     	movi.2d	v0, #0000000000000000
1000ca020:     	stp	q0, q0, [sp, #400]
1000ca024:     	lsl	x8, x2, #1
1000ca028:     	stp	q0, q0, [sp, #368]
1000ca02c:     	stp	q0, q0, [sp, #336]
1000ca030:     	stp	q0, q0, [sp, #304]
1000ca034:     	stp	q0, q0, [sp, #272]
1000ca038:     	stp	q0, q0, [sp, #240]
1000ca03c:     	stp	q0, q0, [sp, #208]
1000ca040:     	stp	q0, q0, [sp, #176]
1000ca044:     	ands	x8, x8, #0xfffffffffffffffc
1000ca048:     	b.eq	0x1000ca324 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000ca04c:     	add	x8, x1, x8
1000ca050:     	str	x8, [sp, #8]
1000ca054:     	add	x8, sp, #176
1000ca058:     	add	x27, x8, #128
1000ca05c:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000ca060:     	add	x11, x11, #1212
1000ca064:     	mov	x12, #0
1000ca068:     	ldp	w8, w9, [x1]
1000ca06c:     	ubfx	x10, x8, #8, #4
1000ca070:     	str	x10, [sp, #168]
1000ca074:     	ubfx	x10, x8, #16, #4
1000ca078:     	str	x10, [sp, #160]
1000ca07c:     	ubfx	x10, x8, #24, #4
1000ca080:     	str	x10, [sp, #152]
1000ca084:     	ldp	w10, w17, [x1, #8]
1000ca088:     	str	x1, [sp, #16]
1000ca08c:     	and	x14, x8, #0xf
1000ca090:     	ubfx	x13, x8, #4, #4
1000ca094:     	stp	x13, x14, [sp, #136]
1000ca098:     	ubfx	x14, x8, #12, #4
1000ca09c:     	ubfx	x13, x8, #20, #4
1000ca0a0:     	stp	x13, x14, [sp, #120]
1000ca0a4:     	lsr	x8, x8, #28
1000ca0a8:     	str	x8, [sp, #112]
1000ca0ac:     	and	x8, x9, #0xf
1000ca0b0:     	str	x8, [sp, #104]
1000ca0b4:     	ubfx	x8, x9, #8, #4
1000ca0b8:     	str	x8, [sp, #96]
1000ca0bc:     	ubfx	x8, x9, #16, #4
1000ca0c0:     	str	x8, [sp, #88]
1000ca0c4:     	ubfx	x8, x9, #24, #4
1000ca0c8:     	str	x8, [sp, #80]
1000ca0cc:     	ubfx	x8, x9, #4, #4
1000ca0d0:     	str	x8, [sp, #72]
1000ca0d4:     	ubfx	x8, x9, #12, #4
1000ca0d8:     	str	x8, [sp, #64]
1000ca0dc:     	ubfx	x8, x9, #20, #4
1000ca0e0:     	str	x8, [sp, #56]
1000ca0e4:     	lsr	x8, x9, #28
1000ca0e8:     	str	x8, [sp, #48]
1000ca0ec:     	and	x9, x10, #0xf
1000ca0f0:     	ubfx	x8, x10, #8, #4
1000ca0f4:     	stp	x8, x9, [sp, #32]
1000ca0f8:     	ubfx	x8, x10, #16, #4
1000ca0fc:     	str	x8, [sp, #24]
1000ca100:     	ubfx	x28, x10, #24, #4
1000ca104:     	ubfx	x30, x10, #4, #4
1000ca108:     	ubfx	x8, x10, #12, #4
1000ca10c:     	ubfx	x3, x10, #20, #4
1000ca110:     	lsr	x9, x10, #28
1000ca114:     	and	x1, x17, #0xf
1000ca118:     	ubfx	x10, x17, #8, #4
1000ca11c:     	ubfx	x13, x17, #16, #4
1000ca120:     	ubfx	x26, x17, #24, #4
1000ca124:     	ubfx	x14, x17, #4, #4
1000ca128:     	ubfx	x15, x17, #12, #4
1000ca12c:     	ubfx	x16, x17, #20, #4
1000ca130:     	lsr	x17, x17, #28
1000ca134:     	ldr	w20, [x0, x12]
1000ca138:     	lsl	w2, w20, #4
1000ca13c:     	and	x2, x2, #0xf0
1000ca140:     	add	x5, x11, x2
1000ca144:     	and	x2, x20, #0xf0
1000ca148:     	add	x2, x11, x2
1000ca14c:     	lsr	x4, x20, #4
1000ca150:     	and	x4, x4, #0xf0
1000ca154:     	add	x7, x11, x4
1000ca158:     	lsr	x4, x20, #8
1000ca15c:     	and	x4, x4, #0xf0
1000ca160:     	add	x4, x11, x4
1000ca164:     	lsr	x6, x20, #12
1000ca168:     	and	x6, x6, #0xf0
1000ca16c:     	add	x19, x11, x6
1000ca170:     	lsr	x6, x20, #16
1000ca174:     	and	x6, x6, #0xf0
1000ca178:     	add	x6, x11, x6
1000ca17c:     	lsr	x21, x20, #20
1000ca180:     	and	x21, x21, #0xf0
1000ca184:     	add	x21, x11, x21
1000ca188:     	lsr	x20, x20, #24
1000ca18c:     	and	x20, x20, #0xf0
1000ca190:     	ldr	x22, [sp, #144]
1000ca194:     	ldrb	w22, [x5, x22]
1000ca198:     	add	x20, x11, x20
1000ca19c:     	ldp	x24, x23, [sp, #160]
1000ca1a0:     	ldrb	w23, [x7, x23]
1000ca1a4:     	ldrb	w24, [x19, x24]
1000ca1a8:     	add	w22, w22, w23
1000ca1ac:     	add	w22, w22, w24
1000ca1b0:     	ldr	x23, [sp, #152]
1000ca1b4:     	ldrb	w23, [x21, x23]
1000ca1b8:     	ldr	x24, [sp, #136]
1000ca1bc:     	ldrb	w24, [x2, x24]
1000ca1c0:     	add	w22, w22, w23
1000ca1c4:     	add	w22, w22, w24
1000ca1c8:     	ldp	x24, x23, [sp, #120]
1000ca1cc:     	ldrb	w23, [x4, x23]
1000ca1d0:     	ldrb	w24, [x6, x24]
1000ca1d4:     	add	w22, w22, w23
1000ca1d8:     	add	w22, w22, w24
1000ca1dc:     	ldr	x23, [sp, #112]
1000ca1e0:     	ldrb	w23, [x20, x23]
1000ca1e4:     	add	w22, w22, w23
1000ca1e8:     	scvtf	s0, w22
1000ca1ec:     	ldp	x23, x22, [sp, #96]
1000ca1f0:     	ldrb	w22, [x5, x22]
1000ca1f4:     	ldrb	w23, [x7, x23]
1000ca1f8:     	ldp	x25, x24, [sp, #80]
1000ca1fc:     	ldrb	w24, [x19, x24]
1000ca200:     	ldrb	w25, [x21, x25]
1000ca204:     	add	w22, w22, w23
1000ca208:     	ldr	x23, [sp, #72]
1000ca20c:     	ldrb	w23, [x2, x23]
1000ca210:     	add	w22, w22, w24
1000ca214:     	ldr	x24, [sp, #64]
1000ca218:     	ldrb	w24, [x4, x24]
1000ca21c:     	add	w22, w22, w25
1000ca220:     	ldr	x25, [sp, #56]
1000ca224:     	ldrb	w25, [x6, x25]
1000ca228:     	add	w22, w22, w23
1000ca22c:     	add	w22, w22, w24
1000ca230:     	add	w22, w22, w25
1000ca234:     	ldr	x23, [sp, #48]
1000ca238:     	ldrb	w23, [x20, x23]
1000ca23c:     	add	w22, w22, w23
1000ca240:     	scvtf	s1, w22
1000ca244:     	ldp	x23, x22, [sp, #32]
1000ca248:     	ldrb	w22, [x5, x22]
1000ca24c:     	ldrb	w23, [x7, x23]
1000ca250:     	ldr	x24, [sp, #24]
1000ca254:     	ldrb	w24, [x19, x24]
1000ca258:     	add	w22, w22, w23
1000ca25c:     	ldrb	w23, [x21, x28]
1000ca260:     	add	w22, w22, w24
1000ca264:     	ldrb	w24, [x2, x30]
1000ca268:     	add	w22, w22, w23
1000ca26c:     	ldrb	w23, [x4, x8]
1000ca270:     	add	w22, w22, w24
1000ca274:     	ldrb	w24, [x6, x3]
1000ca278:     	add	w22, w22, w23
1000ca27c:     	ldrb	w23, [x20, x9]
1000ca280:     	add	w22, w22, w24
1000ca284:     	add	w22, w22, w23
1000ca288:     	scvtf	s2, w22
1000ca28c:     	ldrb	w5, [x5, x1]
1000ca290:     	ldrb	w7, [x7, x10]
1000ca294:     	ldrb	w19, [x19, x13]
1000ca298:     	add	w5, w5, w7
1000ca29c:     	add	w5, w5, w19
1000ca2a0:     	ldrb	w7, [x21, x26]
1000ca2a4:     	ldrb	w2, [x2, x14]
1000ca2a8:     	add	w5, w5, w7
1000ca2ac:     	add	w2, w5, w2
1000ca2b0:     	ldrb	w4, [x4, x15]
1000ca2b4:     	ldrb	w5, [x6, x16]
1000ca2b8:     	add	w2, w2, w4
1000ca2bc:     	add	w2, w2, w5
1000ca2c0:     	ldrb	w4, [x20, x17]
1000ca2c4:     	add	w2, w2, w4
1000ca2c8:     	add	x4, sp, #176
1000ca2cc:     	scvtf	s3, w2
1000ca2d0:     	add	x2, x27, x12
1000ca2d4:     	ldur	s4, [x2, #-64]
1000ca2d8:     	fadd	s1, s4, s1
1000ca2dc:     	stur	s1, [x2, #-64]
1000ca2e0:     	ldr	s1, [x2]
1000ca2e4:     	fadd	s1, s1, s2
1000ca2e8:     	str	s1, [x2]
1000ca2ec:     	ldr	s1, [x2, #64]
1000ca2f0:     	fadd	s1, s1, s3
1000ca2f4:     	ldr	s2, [x4, x12]
1000ca2f8:     	str	s1, [x2, #64]
1000ca2fc:     	fadd	s0, s2, s0
1000ca300:     	str	s0, [x4, x12]
1000ca304:     	add	x12, x12, #4
1000ca308:     	cmp	x12, #64
1000ca30c:     	b.ne	0x1000ca134 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ca310:     	add	x0, x0, #64
1000ca314:     	ldp	x8, x1, [sp, #8]
1000ca318:     	add	x1, x1, #16
1000ca31c:     	cmp	x1, x8
1000ca320:     	b.ne	0x1000ca064 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000ca324:     	ldp	q0, q1, [sp, #368]
1000ca328:     	ldr	x8, [sp]
1000ca32c:     	stp	q0, q1, [x8, #192]
1000ca330:     	ldp	q0, q1, [sp, #400]
1000ca334:     	stp	q0, q1, [x8, #224]
1000ca338:     	ldp	q0, q1, [sp, #304]
1000ca33c:     	stp	q0, q1, [x8, #128]
1000ca340:     	ldp	q0, q1, [sp, #336]
1000ca344:     	stp	q0, q1, [x8, #160]
1000ca348:     	ldp	q0, q1, [sp, #240]
1000ca34c:     	stp	q0, q1, [x8, #64]
1000ca350:     	ldp	q0, q1, [sp, #272]
1000ca354:     	stp	q0, q1, [x8, #96]
1000ca358:     	ldp	q0, q1, [sp, #176]
1000ca35c:     	stp	q0, q1, [x8]
1000ca360:     	ldp	q0, q1, [sp, #208]
1000ca364:     	stp	q0, q1, [x8, #32]
1000ca368:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000ca36c:     	ldr	x8, [x8, #392]
1000ca370:     	ldr	x8, [x8]
1000ca374:     	ldur	x9, [x29, #-96]
1000ca378:     	cmp	x8, x9
1000ca37c:     	b.ne	0x1000ca3a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000ca380:     	add	sp, sp, #448
1000ca384:     	ldp	x29, x30, [sp, #80]
1000ca388:     	ldp	x20, x19, [sp, #64]
1000ca38c:     	ldp	x22, x21, [sp, #48]
1000ca390:     	ldp	x24, x23, [sp, #32]
1000ca394:     	ldp	x26, x25, [sp, #16]
1000ca398:     	ldp	x28, x27, [sp], #96
1000ca39c:     	ret
1000ca3a0:     	bl	0x100163694 <_strcmp+0x100163694>

