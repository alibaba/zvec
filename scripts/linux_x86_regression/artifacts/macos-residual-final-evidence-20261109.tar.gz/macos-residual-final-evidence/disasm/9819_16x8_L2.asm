00000001000c997c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c997c:     	stp	x22, x21, [sp, #-48]!
1000c9980:     	stp	x20, x19, [sp, #16]
1000c9984:     	stp	x29, x30, [sp, #32]
1000c9988:     	add	x29, sp, #32
1000c998c:     	sub	sp, sp, #528
1000c9990:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xc4>
1000c9994:     	ldr	x8, [x8, #392]
1000c9998:     	ldr	x8, [x8]
1000c999c:     	stur	x8, [x29, #-40]
1000c99a0:     	movi.2d	v0, #0000000000000000
1000c99a4:     	stp	q0, q0, [sp, #480]
1000c99a8:     	lsl	x8, x2, #2
1000c99ac:     	stp	q0, q0, [sp, #448]
1000c99b0:     	stp	q0, q0, [sp, #416]
1000c99b4:     	stp	q0, q0, [sp, #384]
1000c99b8:     	stp	q0, q0, [sp, #352]
1000c99bc:     	stp	q0, q0, [sp, #320]
1000c99c0:     	stp	q0, q0, [sp, #288]
1000c99c4:     	stp	q0, q0, [sp, #256]
1000c99c8:     	stp	q0, q0, [sp, #224]
1000c99cc:     	stp	q0, q0, [sp, #192]
1000c99d0:     	stp	q0, q0, [sp, #160]
1000c99d4:     	stp	q0, q0, [sp, #128]
1000c99d8:     	stp	q0, q0, [sp, #96]
1000c99dc:     	stp	q0, q0, [sp, #64]
1000c99e0:     	stp	q0, q0, [sp, #32]
1000c99e4:     	stp	q0, q0, [sp]
1000c99e8:     	ands	x8, x8, #0xfffffffffffffff8
1000c99ec:     	b.eq	0x1000c9b04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x188>
1000c99f0:     	add	x8, x1, x8
1000c99f4:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x120>
1000c99f8:     	add	x9, x9, #1244
1000c99fc:     	mov	x10, #0
1000c9a00:     	mov	x11, sp
1000c9a04:     	mov	x12, #0
1000c9a08:     	ldr	w5, [x0, x10, lsl #2]
1000c9a0c:     	lsl	w13, w5, #4
1000c9a10:     	and	x13, x13, #0xf0
1000c9a14:     	and	x14, x5, #0xf0
1000c9a18:     	lsr	x15, x5, #4
1000c9a1c:     	and	x15, x15, #0xf0
1000c9a20:     	lsr	x16, x5, #8
1000c9a24:     	and	x16, x16, #0xf0
1000c9a28:     	lsr	x17, x5, #12
1000c9a2c:     	and	x17, x17, #0xf0
1000c9a30:     	lsr	x2, x5, #16
1000c9a34:     	and	x2, x2, #0xf0
1000c9a38:     	lsr	x4, x5, #20
1000c9a3c:     	and	x4, x4, #0xf0
1000c9a40:     	lsr	x5, x5, #24
1000c9a44:     	and	x5, x5, #0xf0
1000c9a48:     	mov	x6, x11
1000c9a4c:     	ldr	w7, [x1, x12]
1000c9a50:     	and	x19, x7, #0xf
1000c9a54:     	orr	x19, x13, x19
1000c9a58:     	ldrb	w19, [x9, x19]
1000c9a5c:     	ubfx	x20, x7, #4, #4
1000c9a60:     	orr	x20, x14, x20
1000c9a64:     	ldrb	w20, [x9, x20]
1000c9a68:     	ubfx	x21, x7, #8, #4
1000c9a6c:     	orr	x21, x15, x21
1000c9a70:     	ldrb	w21, [x9, x21]
1000c9a74:     	add	w19, w19, w20
1000c9a78:     	add	w19, w19, w21
1000c9a7c:     	ubfx	x20, x7, #12, #4
1000c9a80:     	orr	x20, x16, x20
1000c9a84:     	ldrb	w20, [x9, x20]
1000c9a88:     	ubfx	x21, x7, #16, #4
1000c9a8c:     	orr	x21, x17, x21
1000c9a90:     	ldrb	w21, [x9, x21]
1000c9a94:     	add	w19, w19, w20
1000c9a98:     	add	w19, w19, w21
1000c9a9c:     	ubfx	x20, x7, #20, #4
1000c9aa0:     	orr	x20, x2, x20
1000c9aa4:     	ldrb	w20, [x9, x20]
1000c9aa8:     	ubfx	x21, x7, #24, #4
1000c9aac:     	orr	x21, x4, x21
1000c9ab0:     	ldrb	w21, [x9, x21]
1000c9ab4:     	add	w19, w19, w20
1000c9ab8:     	add	w19, w19, w21
1000c9abc:     	orr	x7, x5, x7, lsr #28
1000c9ac0:     	ldrb	w7, [x9, x7]
1000c9ac4:     	add	w7, w19, w7
1000c9ac8:     	scvtf	s0, w7
1000c9acc:     	ldr	s1, [x6]
1000c9ad0:     	fadd	s0, s1, s0
1000c9ad4:     	str	s0, [x6], #64
1000c9ad8:     	add	x12, x12, #4
1000c9adc:     	cmp	x12, #32
1000c9ae0:     	b.ne	0x1000c9a4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c9ae4:     	add	x10, x10, #1
1000c9ae8:     	add	x11, x11, #4
1000c9aec:     	cmp	x10, #16
1000c9af0:     	b.ne	0x1000c9a04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x88>
1000c9af4:     	add	x0, x0, #64
1000c9af8:     	add	x1, x1, #32
1000c9afc:     	cmp	x1, x8
1000c9b00:     	b.ne	0x1000c99fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x80>
1000c9b04:     	mov	x1, sp
1000c9b08:     	mov	x0, x3
1000c9b0c:     	mov	w2, #512
1000c9b10:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000c9b14:     	ldur	x8, [x29, #-40]
1000c9b18:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000c9b1c:     	ldr	x9, [x9, #392]
1000c9b20:     	ldr	x9, [x9]
1000c9b24:     	cmp	x9, x8
1000c9b28:     	b.ne	0x1000c9b40 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c4>
1000c9b2c:     	add	sp, sp, #528
1000c9b30:     	ldp	x29, x30, [sp, #32]
1000c9b34:     	ldp	x20, x19, [sp, #16]
1000c9b38:     	ldp	x22, x21, [sp], #48
1000c9b3c:     	ret
1000c9b40:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

