00000001000d0620 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d0620:     	stp	x28, x27, [sp, #-96]!
1000d0624:     	stp	x26, x25, [sp, #16]
1000d0628:     	stp	x24, x23, [sp, #32]
1000d062c:     	stp	x22, x21, [sp, #48]
1000d0630:     	stp	x20, x19, [sp, #64]
1000d0634:     	stp	x29, x30, [sp, #80]
1000d0638:     	add	x29, sp, #80
1000d063c:     	sub	sp, sp, #704
1000d0640:     	str	x3, [sp]
1000d0644:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x284>
1000d0648:     	ldr	x8, [x8, #392]
1000d064c:     	ldr	x8, [x8]
1000d0650:     	stur	x8, [x29, #-96]
1000d0654:     	movi.2d	v0, #0000000000000000
1000d0658:     	stp	q0, q0, [sp, #656]
1000d065c:     	lsl	x8, x2, #1
1000d0660:     	stp	q0, q0, [sp, #624]
1000d0664:     	stp	q0, q0, [sp, #592]
1000d0668:     	stp	q0, q0, [sp, #560]
1000d066c:     	stp	q0, q0, [sp, #528]
1000d0670:     	stp	q0, q0, [sp, #496]
1000d0674:     	stp	q0, q0, [sp, #464]
1000d0678:     	stp	q0, q0, [sp, #432]
1000d067c:     	stp	q0, q0, [sp, #400]
1000d0680:     	stp	q0, q0, [sp, #368]
1000d0684:     	stp	q0, q0, [sp, #336]
1000d0688:     	stp	q0, q0, [sp, #304]
1000d068c:     	stp	q0, q0, [sp, #272]
1000d0690:     	stp	q0, q0, [sp, #240]
1000d0694:     	stp	q0, q0, [sp, #208]
1000d0698:     	stp	q0, q0, [sp, #176]
1000d069c:     	ands	x8, x8, #0xfffffffffffffffc
1000d06a0:     	b.eq	0x1000d09c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a8>
1000d06a4:     	add	x8, x1, x8
1000d06a8:     	str	x8, [sp, #8]
1000d06ac:     	add	x8, sp, #176
1000d06b0:     	add	x27, x8, #256
1000d06b4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ec>
1000d06b8:     	add	x11, x11, #2012
1000d06bc:     	mov	x12, #0
1000d06c0:     	ldp	w8, w9, [x1]
1000d06c4:     	ubfx	x10, x8, #4, #4
1000d06c8:     	str	x10, [sp, #168]
1000d06cc:     	ubfx	x10, x8, #8, #4
1000d06d0:     	str	x10, [sp, #160]
1000d06d4:     	and	x10, x8, #0xf
1000d06d8:     	str	x10, [sp, #152]
1000d06dc:     	ubfx	x10, x8, #12, #4
1000d06e0:     	str	x10, [sp, #144]
1000d06e4:     	ubfx	x10, x8, #16, #4
1000d06e8:     	str	x10, [sp, #136]
1000d06ec:     	ubfx	x10, x8, #20, #4
1000d06f0:     	str	x10, [sp, #128]
1000d06f4:     	ubfx	x10, x8, #24, #4
1000d06f8:     	lsr	x8, x8, #28
1000d06fc:     	stp	x8, x10, [sp, #112]
1000d0700:     	and	x10, x9, #0xf
1000d0704:     	ubfx	x8, x9, #4, #4
1000d0708:     	stp	x8, x10, [sp, #96]
1000d070c:     	ubfx	x10, x9, #8, #4
1000d0710:     	ubfx	x8, x9, #12, #4
1000d0714:     	stp	x8, x10, [sp, #80]
1000d0718:     	ubfx	x10, x9, #16, #4
1000d071c:     	ubfx	x8, x9, #20, #4
1000d0720:     	stp	x8, x10, [sp, #64]
1000d0724:     	ubfx	x10, x9, #24, #4
1000d0728:     	lsr	x8, x9, #28
1000d072c:     	stp	x8, x10, [sp, #48]
1000d0730:     	ldp	w9, w17, [x1, #8]
1000d0734:     	and	x10, x9, #0xf
1000d0738:     	ubfx	x8, x9, #4, #4
1000d073c:     	stp	x8, x10, [sp, #32]
1000d0740:     	ubfx	x8, x9, #8, #4
1000d0744:     	stp	x1, x8, [sp, #16]
1000d0748:     	ubfx	x28, x9, #12, #4
1000d074c:     	ubfx	x30, x9, #16, #4
1000d0750:     	ubfx	x3, x9, #20, #4
1000d0754:     	ubfx	x8, x9, #24, #4
1000d0758:     	lsr	x9, x9, #28
1000d075c:     	and	x1, x17, #0xf
1000d0760:     	ubfx	x10, x17, #4, #4
1000d0764:     	ubfx	x13, x17, #8, #4
1000d0768:     	ubfx	x26, x17, #12, #4
1000d076c:     	ubfx	x14, x17, #16, #4
1000d0770:     	ubfx	x15, x17, #20, #4
1000d0774:     	ubfx	x16, x17, #24, #4
1000d0778:     	lsr	x17, x17, #28
1000d077c:     	ldr	w21, [x0, x12]
1000d0780:     	lsl	w2, w21, #4
1000d0784:     	and	x2, x2, #0xf0
1000d0788:     	ldp	x4, x19, [sp, #152]
1000d078c:     	orr	x4, x2, x4
1000d0790:     	ldrsb	w6, [x11, x4]
1000d0794:     	and	x4, x21, #0xf0
1000d0798:     	ldr	x5, [sp, #168]
1000d079c:     	orr	x5, x4, x5
1000d07a0:     	ldrsb	w7, [x11, x5]
1000d07a4:     	lsr	x5, x21, #4
1000d07a8:     	and	x5, x5, #0xf0
1000d07ac:     	orr	x19, x5, x19
1000d07b0:     	ldrsb	w19, [x11, x19]
1000d07b4:     	add	w6, w6, w7
1000d07b8:     	add	w19, w6, w19
1000d07bc:     	lsr	x6, x21, #8
1000d07c0:     	and	x6, x6, #0xf0
1000d07c4:     	ldp	x22, x7, [sp, #136]
1000d07c8:     	orr	x7, x6, x7
1000d07cc:     	ldrsb	w20, [x11, x7]
1000d07d0:     	lsr	x7, x21, #12
1000d07d4:     	and	x7, x7, #0xf0
1000d07d8:     	orr	x22, x7, x22
1000d07dc:     	ldrsb	w22, [x11, x22]
1000d07e0:     	add	w19, w19, w20
1000d07e4:     	add	w22, w19, w22
1000d07e8:     	lsr	x19, x21, #16
1000d07ec:     	and	x19, x19, #0xf0
1000d07f0:     	ldp	x24, x20, [sp, #120]
1000d07f4:     	orr	x20, x19, x20
1000d07f8:     	ldrsb	w23, [x11, x20]
1000d07fc:     	lsr	x20, x21, #20
1000d0800:     	and	x20, x20, #0xf0
1000d0804:     	orr	x24, x20, x24
1000d0808:     	ldrsb	w24, [x11, x24]
1000d080c:     	add	w22, w22, w23
1000d0810:     	add	w22, w22, w24
1000d0814:     	lsr	x21, x21, #24
1000d0818:     	and	x21, x21, #0xf0
1000d081c:     	ldr	x23, [sp, #112]
1000d0820:     	orr	x23, x21, x23
1000d0824:     	ldrsb	w23, [x11, x23]
1000d0828:     	add	w22, w22, w23
1000d082c:     	scvtf	s0, w22
1000d0830:     	ldp	x23, x22, [sp, #96]
1000d0834:     	orr	x22, x2, x22
1000d0838:     	ldrsb	w22, [x11, x22]
1000d083c:     	orr	x23, x4, x23
1000d0840:     	ldrsb	w23, [x11, x23]
1000d0844:     	ldr	x24, [sp, #88]
1000d0848:     	orr	x24, x5, x24
1000d084c:     	ldrsb	w24, [x11, x24]
1000d0850:     	add	w22, w22, w23
1000d0854:     	add	w22, w22, w24
1000d0858:     	ldp	x24, x23, [sp, #72]
1000d085c:     	orr	x23, x6, x23
1000d0860:     	ldrsb	w23, [x11, x23]
1000d0864:     	orr	x24, x7, x24
1000d0868:     	ldrsb	w24, [x11, x24]
1000d086c:     	ldr	x25, [sp, #64]
1000d0870:     	orr	x25, x19, x25
1000d0874:     	ldrsb	w25, [x11, x25]
1000d0878:     	add	w22, w22, w23
1000d087c:     	add	w22, w22, w24
1000d0880:     	ldr	x23, [sp, #56]
1000d0884:     	orr	x23, x20, x23
1000d0888:     	ldrsb	w23, [x11, x23]
1000d088c:     	add	w22, w22, w25
1000d0890:     	add	w22, w22, w23
1000d0894:     	ldr	x23, [sp, #48]
1000d0898:     	orr	x23, x21, x23
1000d089c:     	ldrsb	w23, [x11, x23]
1000d08a0:     	add	w22, w22, w23
1000d08a4:     	scvtf	s1, w22
1000d08a8:     	ldp	x23, x22, [sp, #32]
1000d08ac:     	orr	x22, x2, x22
1000d08b0:     	ldrsb	w22, [x11, x22]
1000d08b4:     	orr	x23, x4, x23
1000d08b8:     	ldrsb	w23, [x11, x23]
1000d08bc:     	ldr	x24, [sp, #24]
1000d08c0:     	orr	x24, x5, x24
1000d08c4:     	ldrsb	w24, [x11, x24]
1000d08c8:     	add	w22, w22, w23
1000d08cc:     	add	w22, w22, w24
1000d08d0:     	orr	x23, x6, x28
1000d08d4:     	ldrsb	w23, [x11, x23]
1000d08d8:     	orr	x24, x7, x30
1000d08dc:     	ldrsb	w24, [x11, x24]
1000d08e0:     	orr	x25, x19, x3
1000d08e4:     	ldrsb	w25, [x11, x25]
1000d08e8:     	add	w22, w22, w23
1000d08ec:     	orr	x23, x20, x8
1000d08f0:     	ldrsb	w23, [x11, x23]
1000d08f4:     	add	w22, w22, w24
1000d08f8:     	add	w22, w22, w25
1000d08fc:     	add	w22, w22, w23
1000d0900:     	orr	x23, x21, x9
1000d0904:     	ldrsb	w23, [x11, x23]
1000d0908:     	add	w22, w22, w23
1000d090c:     	scvtf	s2, w22
1000d0910:     	orr	x2, x2, x1
1000d0914:     	ldrsb	w2, [x11, x2]
1000d0918:     	orr	x4, x4, x10
1000d091c:     	ldrsb	w4, [x11, x4]
1000d0920:     	orr	x5, x5, x13
1000d0924:     	ldrsb	w5, [x11, x5]
1000d0928:     	add	w2, w2, w4
1000d092c:     	add	w2, w2, w5
1000d0930:     	orr	x4, x6, x26
1000d0934:     	ldrsb	w4, [x11, x4]
1000d0938:     	orr	x5, x7, x14
1000d093c:     	ldrsb	w5, [x11, x5]
1000d0940:     	add	w2, w2, w4
1000d0944:     	orr	x4, x19, x15
1000d0948:     	ldrsb	w4, [x11, x4]
1000d094c:     	add	w2, w2, w5
1000d0950:     	orr	x5, x20, x16
1000d0954:     	ldrsb	w5, [x11, x5]
1000d0958:     	add	w2, w2, w4
1000d095c:     	add	w2, w2, w5
1000d0960:     	orr	x4, x21, x17
1000d0964:     	ldrsb	w4, [x11, x4]
1000d0968:     	add	w2, w2, w4
1000d096c:     	add	x4, sp, #176
1000d0970:     	scvtf	s3, w2
1000d0974:     	add	x2, x27, x12
1000d0978:     	ldur	s4, [x2, #-128]
1000d097c:     	fadd	s1, s4, s1
1000d0980:     	stur	s1, [x2, #-128]
1000d0984:     	ldr	s1, [x2]
1000d0988:     	fadd	s1, s1, s2
1000d098c:     	str	s1, [x2]
1000d0990:     	ldr	s1, [x2, #128]
1000d0994:     	fadd	s1, s1, s3
1000d0998:     	ldr	s2, [x4, x12]
1000d099c:     	str	s1, [x2, #128]
1000d09a0:     	fadd	s0, s2, s0
1000d09a4:     	str	s0, [x4, x12]
1000d09a8:     	add	x12, x12, #4
1000d09ac:     	cmp	x12, #128
1000d09b0:     	b.ne	0x1000d077c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x15c>
1000d09b4:     	add	x0, x0, #128
1000d09b8:     	ldp	x8, x1, [sp, #8]
1000d09bc:     	add	x1, x1, #16
1000d09c0:     	cmp	x1, x8
1000d09c4:     	b.ne	0x1000d06bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d09c8:     	add	x1, sp, #176
1000d09cc:     	ldr	x0, [sp]
1000d09d0:     	mov	w2, #512
1000d09d4:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d09d8:     	ldur	x8, [x29, #-96]
1000d09dc:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 8ul, false>(char const*)+0x228>
1000d09e0:     	ldr	x9, [x9, #392]
1000d09e4:     	ldr	x9, [x9]
1000d09e8:     	cmp	x9, x8
1000d09ec:     	b.ne	0x1000d0a10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3f0>
1000d09f0:     	add	sp, sp, #704
1000d09f4:     	ldp	x29, x30, [sp, #80]
1000d09f8:     	ldp	x20, x19, [sp, #64]
1000d09fc:     	ldp	x22, x21, [sp, #48]
1000d0a00:     	ldp	x24, x23, [sp, #32]
1000d0a04:     	ldp	x26, x25, [sp, #16]
1000d0a08:     	ldp	x28, x27, [sp], #96
1000d0a0c:     	ret
1000d0a10:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

