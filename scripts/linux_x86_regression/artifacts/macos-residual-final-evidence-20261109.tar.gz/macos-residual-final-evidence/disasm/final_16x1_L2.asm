00000001000c6a44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c6a44:     	stp	x22, x21, [sp, #-32]!
1000c6a48:     	stp	x20, x19, [sp, #16]
1000c6a4c:     	movi.2d	v0, #0000000000000000
1000c6a50:     	stp	q0, q0, [x3, #32]
1000c6a54:     	stp	q0, q0, [x3]
1000c6a58:     	cmp	x2, #8
1000c6a5c:     	b.hs	0x1000c6a68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c6a60:     	mov	x8, #0
1000c6a64:     	b	0x1000c6b78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c6a68:     	mov	x8, #0
1000c6a6c:     	mov	w12, #8
1000c6a70:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2bc>
1000c6a74:     	add	x9, x9, #1212
1000c6a78:     	mov	x10, x0
1000c6a7c:     	mov	x11, #0
1000c6a80:     	lsr	x8, x8, #1
1000c6a84:     	mul	x8, x8, x4
1000c6a88:     	ldr	w6, [x1, x8]
1000c6a8c:     	mov	x8, x12
1000c6a90:     	lsl	w12, w6, #4
1000c6a94:     	and	x12, x12, #0xf0
1000c6a98:     	add	x12, x9, x12
1000c6a9c:     	and	x13, x6, #0xf0
1000c6aa0:     	add	x13, x9, x13
1000c6aa4:     	lsr	x14, x6, #4
1000c6aa8:     	and	x14, x14, #0xf0
1000c6aac:     	add	x14, x9, x14
1000c6ab0:     	lsr	x15, x6, #8
1000c6ab4:     	and	x15, x15, #0xf0
1000c6ab8:     	add	x15, x9, x15
1000c6abc:     	lsr	x16, x6, #12
1000c6ac0:     	and	x16, x16, #0xf0
1000c6ac4:     	add	x16, x9, x16
1000c6ac8:     	lsr	x17, x6, #16
1000c6acc:     	and	x17, x17, #0xf0
1000c6ad0:     	add	x17, x9, x17
1000c6ad4:     	lsr	x5, x6, #20
1000c6ad8:     	and	x5, x5, #0xf0
1000c6adc:     	add	x5, x9, x5
1000c6ae0:     	lsr	x6, x6, #24
1000c6ae4:     	and	x6, x6, #0xf0
1000c6ae8:     	add	x6, x9, x6
1000c6aec:     	ldr	w7, [x10, x11]
1000c6af0:     	and	x19, x7, #0xf
1000c6af4:     	ldrb	w19, [x12, x19]
1000c6af8:     	ubfx	x20, x7, #4, #4
1000c6afc:     	ldrb	w20, [x13, x20]
1000c6b00:     	ubfx	x21, x7, #8, #4
1000c6b04:     	ldrb	w21, [x14, x21]
1000c6b08:     	add	w19, w19, w20
1000c6b0c:     	add	w19, w19, w21
1000c6b10:     	ubfx	x20, x7, #12, #4
1000c6b14:     	ldrb	w20, [x15, x20]
1000c6b18:     	ubfx	x21, x7, #16, #4
1000c6b1c:     	ldrb	w21, [x16, x21]
1000c6b20:     	add	w19, w19, w20
1000c6b24:     	add	w19, w19, w21
1000c6b28:     	ubfx	x20, x7, #20, #4
1000c6b2c:     	ldrb	w20, [x17, x20]
1000c6b30:     	ubfx	x21, x7, #24, #4
1000c6b34:     	ldrb	w21, [x5, x21]
1000c6b38:     	lsr	x7, x7, #28
1000c6b3c:     	ldrb	w7, [x6, x7]
1000c6b40:     	add	w19, w19, w20
1000c6b44:     	add	w19, w19, w21
1000c6b48:     	add	w7, w19, w7
1000c6b4c:     	scvtf	s0, w7
1000c6b50:     	ldr	s1, [x3, x11]
1000c6b54:     	fadd	s0, s1, s0
1000c6b58:     	str	s0, [x3, x11]
1000c6b5c:     	add	x11, x11, #4
1000c6b60:     	cmp	x11, #64
1000c6b64:     	b.ne	0x1000c6aec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c6b68:     	add	x12, x8, #8
1000c6b6c:     	add	x10, x10, #64
1000c6b70:     	cmp	x12, x2
1000c6b74:     	b.ls	0x1000c6a7c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c6b78:     	cmp	x8, x2
1000c6b7c:     	b.hs	0x1000c6e74 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x430>
1000c6b80:     	lsl	x9, x4, #2
1000c6b84:     	lsl	w10, w8, #2
1000c6b88:     	mov	w11, #-16
1000c6b8c:     	lsr	x13, x8, #3
1000c6b90:     	mul	x12, x9, x13
1000c6b94:     	ubfx	x14, x8, #1, #2
1000c6b98:     	orr	x15, x12, x14
1000c6b9c:     	and	w12, w10, #0x4
1000c6ba0:     	ldrb	w15, [x1, x15]
1000c6ba4:     	lsr	w15, w15, w12
1000c6ba8:     	and	w16, w15, #0xf
1000c6bac:     	cmp	w16, #8
1000c6bb0:     	csel	w16, wzr, w11, lo
1000c6bb4:     	bfi	x14, x13, #6, #58
1000c6bb8:     	bfxil	w16, w15, #0, #4
1000c6bbc:     	add	x13, x0, x14
1000c6bc0:     	ldrb	w14, [x13]
1000c6bc4:     	lsr	w14, w14, w12
1000c6bc8:     	and	w15, w14, #0xf
1000c6bcc:     	scvtf	s0, w16
1000c6bd0:     	cmp	w15, #8
1000c6bd4:     	csel	w15, wzr, w11, lo
1000c6bd8:     	bfxil	w15, w14, #0, #4
1000c6bdc:     	scvtf	s1, w15
1000c6be0:     	fsub	s1, s1, s0
1000c6be4:     	ldp	s2, s3, [x3]
1000c6be8:     	fmadd	s1, s1, s1, s2
1000c6bec:     	str	s1, [x3]
1000c6bf0:     	ldrb	w14, [x13, #4]
1000c6bf4:     	lsr	w14, w14, w12
1000c6bf8:     	and	w15, w14, #0xf
1000c6bfc:     	cmp	w15, #8
1000c6c00:     	csel	w15, wzr, w11, lo
1000c6c04:     	bfxil	w15, w14, #0, #4
1000c6c08:     	scvtf	s1, w15
1000c6c0c:     	fsub	s1, s1, s0
1000c6c10:     	fmadd	s1, s1, s1, s3
1000c6c14:     	str	s1, [x3, #4]
1000c6c18:     	ldrb	w14, [x13, #8]
1000c6c1c:     	lsr	w14, w14, w12
1000c6c20:     	and	w15, w14, #0xf
1000c6c24:     	cmp	w15, #8
1000c6c28:     	csel	w15, wzr, w11, lo
1000c6c2c:     	bfxil	w15, w14, #0, #4
1000c6c30:     	scvtf	s1, w15
1000c6c34:     	fsub	s1, s1, s0
1000c6c38:     	ldp	s2, s3, [x3, #8]
1000c6c3c:     	fmadd	s1, s1, s1, s2
1000c6c40:     	str	s1, [x3, #8]
1000c6c44:     	ldrb	w14, [x13, #12]
1000c6c48:     	lsr	w14, w14, w12
1000c6c4c:     	and	w15, w14, #0xf
1000c6c50:     	cmp	w15, #8
1000c6c54:     	csel	w15, wzr, w11, lo
1000c6c58:     	bfxil	w15, w14, #0, #4
1000c6c5c:     	scvtf	s1, w15
1000c6c60:     	fsub	s1, s1, s0
1000c6c64:     	fmadd	s1, s1, s1, s3
1000c6c68:     	str	s1, [x3, #12]
1000c6c6c:     	ldrb	w14, [x13, #16]
1000c6c70:     	lsr	w14, w14, w12
1000c6c74:     	and	w15, w14, #0xf
1000c6c78:     	cmp	w15, #8
1000c6c7c:     	csel	w15, wzr, w11, lo
1000c6c80:     	bfxil	w15, w14, #0, #4
1000c6c84:     	scvtf	s1, w15
1000c6c88:     	fsub	s1, s1, s0
1000c6c8c:     	ldp	s2, s3, [x3, #16]
1000c6c90:     	fmadd	s1, s1, s1, s2
1000c6c94:     	str	s1, [x3, #16]
1000c6c98:     	ldrb	w14, [x13, #20]
1000c6c9c:     	lsr	w14, w14, w12
1000c6ca0:     	and	w15, w14, #0xf
1000c6ca4:     	cmp	w15, #8
1000c6ca8:     	csel	w15, wzr, w11, lo
1000c6cac:     	bfxil	w15, w14, #0, #4
1000c6cb0:     	scvtf	s1, w15
1000c6cb4:     	fsub	s1, s1, s0
1000c6cb8:     	fmadd	s1, s1, s1, s3
1000c6cbc:     	str	s1, [x3, #20]
1000c6cc0:     	ldrb	w14, [x13, #24]
1000c6cc4:     	lsr	w14, w14, w12
1000c6cc8:     	and	w15, w14, #0xf
1000c6ccc:     	cmp	w15, #8
1000c6cd0:     	csel	w15, wzr, w11, lo
1000c6cd4:     	bfxil	w15, w14, #0, #4
1000c6cd8:     	scvtf	s1, w15
1000c6cdc:     	fsub	s1, s1, s0
1000c6ce0:     	ldp	s2, s3, [x3, #24]
1000c6ce4:     	fmadd	s1, s1, s1, s2
1000c6ce8:     	str	s1, [x3, #24]
1000c6cec:     	ldrb	w14, [x13, #28]
1000c6cf0:     	lsr	w14, w14, w12
1000c6cf4:     	and	w15, w14, #0xf
1000c6cf8:     	cmp	w15, #8
1000c6cfc:     	csel	w15, wzr, w11, lo
1000c6d00:     	bfxil	w15, w14, #0, #4
1000c6d04:     	scvtf	s1, w15
1000c6d08:     	fsub	s1, s1, s0
1000c6d0c:     	fmadd	s1, s1, s1, s3
1000c6d10:     	str	s1, [x3, #28]
1000c6d14:     	ldrb	w14, [x13, #32]
1000c6d18:     	lsr	w14, w14, w12
1000c6d1c:     	and	w15, w14, #0xf
1000c6d20:     	cmp	w15, #8
1000c6d24:     	csel	w15, wzr, w11, lo
1000c6d28:     	bfxil	w15, w14, #0, #4
1000c6d2c:     	scvtf	s1, w15
1000c6d30:     	fsub	s1, s1, s0
1000c6d34:     	ldp	s2, s3, [x3, #32]
1000c6d38:     	fmadd	s1, s1, s1, s2
1000c6d3c:     	str	s1, [x3, #32]
1000c6d40:     	ldrb	w14, [x13, #36]
1000c6d44:     	lsr	w14, w14, w12
1000c6d48:     	and	w15, w14, #0xf
1000c6d4c:     	cmp	w15, #8
1000c6d50:     	csel	w15, wzr, w11, lo
1000c6d54:     	bfxil	w15, w14, #0, #4
1000c6d58:     	scvtf	s1, w15
1000c6d5c:     	fsub	s1, s1, s0
1000c6d60:     	fmadd	s1, s1, s1, s3
1000c6d64:     	str	s1, [x3, #36]
1000c6d68:     	ldrb	w14, [x13, #40]
1000c6d6c:     	lsr	w14, w14, w12
1000c6d70:     	and	w15, w14, #0xf
1000c6d74:     	cmp	w15, #8
1000c6d78:     	csel	w15, wzr, w11, lo
1000c6d7c:     	bfxil	w15, w14, #0, #4
1000c6d80:     	scvtf	s1, w15
1000c6d84:     	fsub	s1, s1, s0
1000c6d88:     	ldp	s2, s3, [x3, #40]
1000c6d8c:     	fmadd	s1, s1, s1, s2
1000c6d90:     	str	s1, [x3, #40]
1000c6d94:     	ldrb	w14, [x13, #44]
1000c6d98:     	lsr	w14, w14, w12
1000c6d9c:     	and	w15, w14, #0xf
1000c6da0:     	cmp	w15, #8
1000c6da4:     	csel	w15, wzr, w11, lo
1000c6da8:     	bfxil	w15, w14, #0, #4
1000c6dac:     	scvtf	s1, w15
1000c6db0:     	fsub	s1, s1, s0
1000c6db4:     	fmadd	s1, s1, s1, s3
1000c6db8:     	str	s1, [x3, #44]
1000c6dbc:     	ldrb	w14, [x13, #48]
1000c6dc0:     	lsr	w14, w14, w12
1000c6dc4:     	and	w15, w14, #0xf
1000c6dc8:     	cmp	w15, #8
1000c6dcc:     	csel	w15, wzr, w11, lo
1000c6dd0:     	bfxil	w15, w14, #0, #4
1000c6dd4:     	scvtf	s1, w15
1000c6dd8:     	fsub	s1, s1, s0
1000c6ddc:     	ldp	s2, s3, [x3, #48]
1000c6de0:     	fmadd	s1, s1, s1, s2
1000c6de4:     	str	s1, [x3, #48]
1000c6de8:     	ldrb	w14, [x13, #52]
1000c6dec:     	lsr	w14, w14, w12
1000c6df0:     	and	w15, w14, #0xf
1000c6df4:     	cmp	w15, #8
1000c6df8:     	csel	w15, wzr, w11, lo
1000c6dfc:     	bfxil	w15, w14, #0, #4
1000c6e00:     	scvtf	s1, w15
1000c6e04:     	fsub	s1, s1, s0
1000c6e08:     	fmadd	s1, s1, s1, s3
1000c6e0c:     	str	s1, [x3, #52]
1000c6e10:     	ldrb	w14, [x13, #56]
1000c6e14:     	lsr	w14, w14, w12
1000c6e18:     	and	w15, w14, #0xf
1000c6e1c:     	cmp	w15, #8
1000c6e20:     	csel	w15, wzr, w11, lo
1000c6e24:     	bfxil	w15, w14, #0, #4
1000c6e28:     	scvtf	s1, w15
1000c6e2c:     	fsub	s1, s1, s0
1000c6e30:     	ldp	s2, s3, [x3, #56]
1000c6e34:     	fmadd	s1, s1, s1, s2
1000c6e38:     	str	s1, [x3, #56]
1000c6e3c:     	ldrb	w13, [x13, #60]
1000c6e40:     	lsr	w12, w13, w12
1000c6e44:     	and	w13, w12, #0xf
1000c6e48:     	cmp	w13, #8
1000c6e4c:     	csel	w13, wzr, w11, lo
1000c6e50:     	bfxil	w13, w12, #0, #4
1000c6e54:     	scvtf	s1, w13
1000c6e58:     	fsub	s0, s1, s0
1000c6e5c:     	fmadd	s0, s0, s0, s3
1000c6e60:     	str	s0, [x3, #60]
1000c6e64:     	add	x8, x8, #1
1000c6e68:     	add	w10, w10, #4
1000c6e6c:     	cmp	x2, x8
1000c6e70:     	b.ne	0x1000c6b8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c6e74:     	ldp	x20, x19, [sp, #16]
1000c6e78:     	ldp	x22, x21, [sp], #32
1000c6e7c:     	ret

