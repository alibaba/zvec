00000001000d00fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d00fc:     	stp	x28, x27, [sp, #-96]!
1000d0100:     	stp	x26, x25, [sp, #16]
1000d0104:     	stp	x24, x23, [sp, #32]
1000d0108:     	stp	x22, x21, [sp, #48]
1000d010c:     	stp	x20, x19, [sp, #64]
1000d0110:     	stp	x29, x30, [sp, #80]
1000d0114:     	add	x29, sp, #80
1000d0118:     	sub	sp, sp, #704
1000d011c:     	str	x3, [sp]
1000d0120:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x284>
1000d0124:     	ldr	x8, [x8, #392]
1000d0128:     	ldr	x8, [x8]
1000d012c:     	stur	x8, [x29, #-96]
1000d0130:     	movi.2d	v0, #0000000000000000
1000d0134:     	stp	q0, q0, [sp, #656]
1000d0138:     	lsl	x8, x2, #1
1000d013c:     	stp	q0, q0, [sp, #624]
1000d0140:     	stp	q0, q0, [sp, #592]
1000d0144:     	stp	q0, q0, [sp, #560]
1000d0148:     	stp	q0, q0, [sp, #528]
1000d014c:     	stp	q0, q0, [sp, #496]
1000d0150:     	stp	q0, q0, [sp, #464]
1000d0154:     	stp	q0, q0, [sp, #432]
1000d0158:     	stp	q0, q0, [sp, #400]
1000d015c:     	stp	q0, q0, [sp, #368]
1000d0160:     	stp	q0, q0, [sp, #336]
1000d0164:     	stp	q0, q0, [sp, #304]
1000d0168:     	stp	q0, q0, [sp, #272]
1000d016c:     	stp	q0, q0, [sp, #240]
1000d0170:     	stp	q0, q0, [sp, #208]
1000d0174:     	stp	q0, q0, [sp, #176]
1000d0178:     	ands	x8, x8, #0xfffffffffffffffc
1000d017c:     	b.eq	0x1000d04a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a8>
1000d0180:     	add	x8, x1, x8
1000d0184:     	str	x8, [sp, #8]
1000d0188:     	add	x8, sp, #176
1000d018c:     	add	x27, x8, #256
1000d0190:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ec>
1000d0194:     	add	x11, x11, #1756
1000d0198:     	mov	x12, #0
1000d019c:     	ldp	w8, w9, [x1]
1000d01a0:     	ubfx	x10, x8, #4, #4
1000d01a4:     	str	x10, [sp, #168]
1000d01a8:     	ubfx	x10, x8, #8, #4
1000d01ac:     	str	x10, [sp, #160]
1000d01b0:     	and	x10, x8, #0xf
1000d01b4:     	str	x10, [sp, #152]
1000d01b8:     	ubfx	x10, x8, #12, #4
1000d01bc:     	str	x10, [sp, #144]
1000d01c0:     	ubfx	x10, x8, #16, #4
1000d01c4:     	str	x10, [sp, #136]
1000d01c8:     	ubfx	x10, x8, #20, #4
1000d01cc:     	str	x10, [sp, #128]
1000d01d0:     	ubfx	x10, x8, #24, #4
1000d01d4:     	lsr	x8, x8, #28
1000d01d8:     	stp	x8, x10, [sp, #112]
1000d01dc:     	and	x10, x9, #0xf
1000d01e0:     	ubfx	x8, x9, #4, #4
1000d01e4:     	stp	x8, x10, [sp, #96]
1000d01e8:     	ubfx	x10, x9, #8, #4
1000d01ec:     	ubfx	x8, x9, #12, #4
1000d01f0:     	stp	x8, x10, [sp, #80]
1000d01f4:     	ubfx	x10, x9, #16, #4
1000d01f8:     	ubfx	x8, x9, #20, #4
1000d01fc:     	stp	x8, x10, [sp, #64]
1000d0200:     	ubfx	x10, x9, #24, #4
1000d0204:     	lsr	x8, x9, #28
1000d0208:     	stp	x8, x10, [sp, #48]
1000d020c:     	ldp	w9, w17, [x1, #8]
1000d0210:     	and	x10, x9, #0xf
1000d0214:     	ubfx	x8, x9, #4, #4
1000d0218:     	stp	x8, x10, [sp, #32]
1000d021c:     	ubfx	x8, x9, #8, #4
1000d0220:     	stp	x1, x8, [sp, #16]
1000d0224:     	ubfx	x28, x9, #12, #4
1000d0228:     	ubfx	x30, x9, #16, #4
1000d022c:     	ubfx	x3, x9, #20, #4
1000d0230:     	ubfx	x8, x9, #24, #4
1000d0234:     	lsr	x9, x9, #28
1000d0238:     	and	x1, x17, #0xf
1000d023c:     	ubfx	x10, x17, #4, #4
1000d0240:     	ubfx	x13, x17, #8, #4
1000d0244:     	ubfx	x26, x17, #12, #4
1000d0248:     	ubfx	x14, x17, #16, #4
1000d024c:     	ubfx	x15, x17, #20, #4
1000d0250:     	ubfx	x16, x17, #24, #4
1000d0254:     	lsr	x17, x17, #28
1000d0258:     	ldr	w21, [x0, x12]
1000d025c:     	lsl	w2, w21, #4
1000d0260:     	and	x2, x2, #0xf0
1000d0264:     	ldp	x4, x19, [sp, #152]
1000d0268:     	orr	x4, x2, x4
1000d026c:     	ldrb	w6, [x11, x4]
1000d0270:     	and	x4, x21, #0xf0
1000d0274:     	ldr	x5, [sp, #168]
1000d0278:     	orr	x5, x4, x5
1000d027c:     	ldrb	w7, [x11, x5]
1000d0280:     	lsr	x5, x21, #4
1000d0284:     	and	x5, x5, #0xf0
1000d0288:     	orr	x19, x5, x19
1000d028c:     	ldrb	w19, [x11, x19]
1000d0290:     	add	w6, w6, w7
1000d0294:     	add	w19, w6, w19
1000d0298:     	lsr	x6, x21, #8
1000d029c:     	and	x6, x6, #0xf0
1000d02a0:     	ldp	x22, x7, [sp, #136]
1000d02a4:     	orr	x7, x6, x7
1000d02a8:     	ldrb	w20, [x11, x7]
1000d02ac:     	lsr	x7, x21, #12
1000d02b0:     	and	x7, x7, #0xf0
1000d02b4:     	orr	x22, x7, x22
1000d02b8:     	ldrb	w22, [x11, x22]
1000d02bc:     	add	w19, w19, w20
1000d02c0:     	add	w22, w19, w22
1000d02c4:     	lsr	x19, x21, #16
1000d02c8:     	and	x19, x19, #0xf0
1000d02cc:     	ldp	x24, x20, [sp, #120]
1000d02d0:     	orr	x20, x19, x20
1000d02d4:     	ldrb	w23, [x11, x20]
1000d02d8:     	lsr	x20, x21, #20
1000d02dc:     	and	x20, x20, #0xf0
1000d02e0:     	orr	x24, x20, x24
1000d02e4:     	ldrb	w24, [x11, x24]
1000d02e8:     	add	w22, w22, w23
1000d02ec:     	add	w22, w22, w24
1000d02f0:     	lsr	x21, x21, #24
1000d02f4:     	and	x21, x21, #0xf0
1000d02f8:     	ldr	x23, [sp, #112]
1000d02fc:     	orr	x23, x21, x23
1000d0300:     	ldrb	w23, [x11, x23]
1000d0304:     	add	w22, w22, w23
1000d0308:     	scvtf	s0, w22
1000d030c:     	ldp	x23, x22, [sp, #96]
1000d0310:     	orr	x22, x2, x22
1000d0314:     	ldrb	w22, [x11, x22]
1000d0318:     	orr	x23, x4, x23
1000d031c:     	ldrb	w23, [x11, x23]
1000d0320:     	ldr	x24, [sp, #88]
1000d0324:     	orr	x24, x5, x24
1000d0328:     	ldrb	w24, [x11, x24]
1000d032c:     	add	w22, w22, w23
1000d0330:     	add	w22, w22, w24
1000d0334:     	ldp	x24, x23, [sp, #72]
1000d0338:     	orr	x23, x6, x23
1000d033c:     	ldrb	w23, [x11, x23]
1000d0340:     	orr	x24, x7, x24
1000d0344:     	ldrb	w24, [x11, x24]
1000d0348:     	ldr	x25, [sp, #64]
1000d034c:     	orr	x25, x19, x25
1000d0350:     	ldrb	w25, [x11, x25]
1000d0354:     	add	w22, w22, w23
1000d0358:     	add	w22, w22, w24
1000d035c:     	ldr	x23, [sp, #56]
1000d0360:     	orr	x23, x20, x23
1000d0364:     	ldrb	w23, [x11, x23]
1000d0368:     	add	w22, w22, w25
1000d036c:     	add	w22, w22, w23
1000d0370:     	ldr	x23, [sp, #48]
1000d0374:     	orr	x23, x21, x23
1000d0378:     	ldrb	w23, [x11, x23]
1000d037c:     	add	w22, w22, w23
1000d0380:     	scvtf	s1, w22
1000d0384:     	ldp	x23, x22, [sp, #32]
1000d0388:     	orr	x22, x2, x22
1000d038c:     	ldrb	w22, [x11, x22]
1000d0390:     	orr	x23, x4, x23
1000d0394:     	ldrb	w23, [x11, x23]
1000d0398:     	ldr	x24, [sp, #24]
1000d039c:     	orr	x24, x5, x24
1000d03a0:     	ldrb	w24, [x11, x24]
1000d03a4:     	add	w22, w22, w23
1000d03a8:     	add	w22, w22, w24
1000d03ac:     	orr	x23, x6, x28
1000d03b0:     	ldrb	w23, [x11, x23]
1000d03b4:     	orr	x24, x7, x30
1000d03b8:     	ldrb	w24, [x11, x24]
1000d03bc:     	orr	x25, x19, x3
1000d03c0:     	ldrb	w25, [x11, x25]
1000d03c4:     	add	w22, w22, w23
1000d03c8:     	orr	x23, x20, x8
1000d03cc:     	ldrb	w23, [x11, x23]
1000d03d0:     	add	w22, w22, w24
1000d03d4:     	add	w22, w22, w25
1000d03d8:     	add	w22, w22, w23
1000d03dc:     	orr	x23, x21, x9
1000d03e0:     	ldrb	w23, [x11, x23]
1000d03e4:     	add	w22, w22, w23
1000d03e8:     	scvtf	s2, w22
1000d03ec:     	orr	x2, x2, x1
1000d03f0:     	ldrb	w2, [x11, x2]
1000d03f4:     	orr	x4, x4, x10
1000d03f8:     	ldrb	w4, [x11, x4]
1000d03fc:     	orr	x5, x5, x13
1000d0400:     	ldrb	w5, [x11, x5]
1000d0404:     	add	w2, w2, w4
1000d0408:     	add	w2, w2, w5
1000d040c:     	orr	x4, x6, x26
1000d0410:     	ldrb	w4, [x11, x4]
1000d0414:     	orr	x5, x7, x14
1000d0418:     	ldrb	w5, [x11, x5]
1000d041c:     	add	w2, w2, w4
1000d0420:     	orr	x4, x19, x15
1000d0424:     	ldrb	w4, [x11, x4]
1000d0428:     	add	w2, w2, w5
1000d042c:     	orr	x5, x20, x16
1000d0430:     	ldrb	w5, [x11, x5]
1000d0434:     	add	w2, w2, w4
1000d0438:     	add	w2, w2, w5
1000d043c:     	orr	x4, x21, x17
1000d0440:     	ldrb	w4, [x11, x4]
1000d0444:     	add	w2, w2, w4
1000d0448:     	add	x4, sp, #176
1000d044c:     	scvtf	s3, w2
1000d0450:     	add	x2, x27, x12
1000d0454:     	ldur	s4, [x2, #-128]
1000d0458:     	fadd	s1, s4, s1
1000d045c:     	stur	s1, [x2, #-128]
1000d0460:     	ldr	s1, [x2]
1000d0464:     	fadd	s1, s1, s2
1000d0468:     	str	s1, [x2]
1000d046c:     	ldr	s1, [x2, #128]
1000d0470:     	fadd	s1, s1, s3
1000d0474:     	ldr	s2, [x4, x12]
1000d0478:     	str	s1, [x2, #128]
1000d047c:     	fadd	s0, s2, s0
1000d0480:     	str	s0, [x4, x12]
1000d0484:     	add	x12, x12, #4
1000d0488:     	cmp	x12, #128
1000d048c:     	b.ne	0x1000d0258 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x15c>
1000d0490:     	add	x0, x0, #128
1000d0494:     	ldp	x8, x1, [sp, #8]
1000d0498:     	add	x1, x1, #16
1000d049c:     	cmp	x1, x8
1000d04a0:     	b.ne	0x1000d0198 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d04a4:     	add	x1, sp, #176
1000d04a8:     	ldr	x0, [sp]
1000d04ac:     	mov	w2, #512
1000d04b0:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d04b4:     	ldur	x8, [x29, #-96]
1000d04b8:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf8>
1000d04bc:     	ldr	x9, [x9, #392]
1000d04c0:     	ldr	x9, [x9]
1000d04c4:     	cmp	x9, x8
1000d04c8:     	b.ne	0x1000d04ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3f0>
1000d04cc:     	add	sp, sp, #704
1000d04d0:     	ldp	x29, x30, [sp, #80]
1000d04d4:     	ldp	x20, x19, [sp, #64]
1000d04d8:     	ldp	x22, x21, [sp, #48]
1000d04dc:     	ldp	x24, x23, [sp, #32]
1000d04e0:     	ldp	x26, x25, [sp, #16]
1000d04e4:     	ldp	x28, x27, [sp], #96
1000d04e8:     	ret
1000d04ec:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

