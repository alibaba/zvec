00000001000ce734 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce734:     	stp	x28, x27, [sp, #-80]!
1000ce738:     	stp	x24, x23, [sp, #16]
1000ce73c:     	stp	x22, x21, [sp, #32]
1000ce740:     	stp	x20, x19, [sp, #48]
1000ce744:     	stp	x29, x30, [sp, #64]
1000ce748:     	add	x29, sp, #64
1000ce74c:     	sub	sp, sp, #1168
1000ce750:     	mov	x19, x3
1000ce754:     	mov	x20, x1
1000ce758:     	mov	x21, x0
1000ce75c:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x8>
1000ce760:     	ldr	x8, [x8, #392]
1000ce764:     	ldr	x8, [x8]
1000ce768:     	stur	x8, [x29, #-72]
1000ce76c:     	lsl	x8, x2, #3
1000ce770:     	and	x22, x8, #0xfffffffffffffff0
1000ce774:     	add	x0, sp, #136
1000ce778:     	mov	w1, #1024
1000ce77c:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000ce780:     	cbz	x22, 0x1000ce984 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x250>
1000ce784:     	add	x8, x20, x22
1000ce788:     	mov	w9, #252645135
1000ce78c:     	adrp	x10, 0x10016a000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x30>
1000ce790:     	add	x10, x10, #1468
1000ce794:     	add	x11, sp, #8
1000ce798:     	mov	x12, #0
1000ce79c:     	ldp	w13, w14, [x20]
1000ce7a0:     	and	w15, w13, w9
1000ce7a4:     	and	w13, w9, w13, lsr #4
1000ce7a8:     	stp	w15, w13, [sp, #8]
1000ce7ac:     	and	w13, w14, w9
1000ce7b0:     	and	w14, w9, w14, lsr #4
1000ce7b4:     	stp	w13, w14, [sp, #16]
1000ce7b8:     	ldp	w13, w14, [x20, #8]
1000ce7bc:     	and	w15, w13, w9
1000ce7c0:     	and	w13, w9, w13, lsr #4
1000ce7c4:     	stp	w15, w13, [sp, #24]
1000ce7c8:     	and	w13, w14, w9
1000ce7cc:     	and	w14, w9, w14, lsr #4
1000ce7d0:     	stp	w13, w14, [sp, #32]
1000ce7d4:     	ldp	w13, w14, [x20, #16]
1000ce7d8:     	and	w15, w13, w9
1000ce7dc:     	and	w13, w9, w13, lsr #4
1000ce7e0:     	stp	w15, w13, [sp, #40]
1000ce7e4:     	and	w13, w14, w9
1000ce7e8:     	and	w14, w9, w14, lsr #4
1000ce7ec:     	stp	w13, w14, [sp, #48]
1000ce7f0:     	ldp	w13, w14, [x20, #24]
1000ce7f4:     	and	w15, w13, w9
1000ce7f8:     	and	w13, w9, w13, lsr #4
1000ce7fc:     	stp	w15, w13, [sp, #56]
1000ce800:     	and	w13, w14, w9
1000ce804:     	and	w14, w9, w14, lsr #4
1000ce808:     	stp	w13, w14, [sp, #64]
1000ce80c:     	ldp	w13, w14, [x20, #32]
1000ce810:     	and	w15, w13, w9
1000ce814:     	and	w13, w9, w13, lsr #4
1000ce818:     	stp	w15, w13, [sp, #72]
1000ce81c:     	and	w13, w14, w9
1000ce820:     	and	w14, w9, w14, lsr #4
1000ce824:     	stp	w13, w14, [sp, #80]
1000ce828:     	ldp	w13, w14, [x20, #40]
1000ce82c:     	and	w15, w13, w9
1000ce830:     	and	w13, w9, w13, lsr #4
1000ce834:     	stp	w15, w13, [sp, #88]
1000ce838:     	and	w13, w14, w9
1000ce83c:     	and	w14, w9, w14, lsr #4
1000ce840:     	stp	w13, w14, [sp, #96]
1000ce844:     	ldp	w13, w14, [x20, #48]
1000ce848:     	and	w15, w13, w9
1000ce84c:     	and	w13, w9, w13, lsr #4
1000ce850:     	stp	w15, w13, [sp, #104]
1000ce854:     	and	w13, w14, w9
1000ce858:     	and	w14, w9, w14, lsr #4
1000ce85c:     	stp	w13, w14, [sp, #112]
1000ce860:     	ldp	w13, w14, [x20, #56]
1000ce864:     	and	w15, w13, w9
1000ce868:     	and	w13, w9, w13, lsr #4
1000ce86c:     	stp	w15, w13, [sp, #120]
1000ce870:     	and	w13, w14, w9
1000ce874:     	and	w14, w9, w14, lsr #4
1000ce878:     	stp	w13, w14, [sp, #128]
1000ce87c:     	add	x13, sp, #136
1000ce880:     	mov	x14, #0
1000ce884:     	ldr	w4, [x21, x12, lsl #2]
1000ce888:     	lsl	w15, w4, #4
1000ce88c:     	and	x15, x15, #0xf0
1000ce890:     	add	x15, x10, x15
1000ce894:     	and	x16, x4, #0xf0
1000ce898:     	add	x16, x10, x16
1000ce89c:     	lsr	x17, x4, #4
1000ce8a0:     	and	x17, x17, #0xf0
1000ce8a4:     	add	x17, x10, x17
1000ce8a8:     	lsr	x0, x4, #8
1000ce8ac:     	and	x0, x0, #0xf0
1000ce8b0:     	add	x0, x10, x0
1000ce8b4:     	lsr	x1, x4, #12
1000ce8b8:     	and	x1, x1, #0xf0
1000ce8bc:     	add	x1, x10, x1
1000ce8c0:     	lsr	x2, x4, #16
1000ce8c4:     	and	x2, x2, #0xf0
1000ce8c8:     	add	x2, x10, x2
1000ce8cc:     	lsr	x3, x4, #20
1000ce8d0:     	and	x3, x3, #0xf0
1000ce8d4:     	add	x3, x10, x3
1000ce8d8:     	lsr	x4, x4, #24
1000ce8dc:     	and	x4, x4, #0xf0
1000ce8e0:     	add	x4, x10, x4
1000ce8e4:     	mov	x5, x13
1000ce8e8:     	add	x6, x11, x14
1000ce8ec:     	ldrb	w7, [x6]
1000ce8f0:     	ldrsb	w7, [x15, x7]
1000ce8f4:     	ldrb	w22, [x6, #1]
1000ce8f8:     	ldrsb	w22, [x17, x22]
1000ce8fc:     	ldrb	w23, [x6, #2]
1000ce900:     	ldrsb	w23, [x1, x23]
1000ce904:     	add	w7, w7, w22
1000ce908:     	add	w7, w7, w23
1000ce90c:     	ldrb	w22, [x6, #3]
1000ce910:     	ldrsb	w22, [x3, x22]
1000ce914:     	ldrb	w23, [x6, #4]
1000ce918:     	ldrsb	w23, [x16, x23]
1000ce91c:     	ldrb	w24, [x6, #5]
1000ce920:     	ldrsb	w24, [x0, x24]
1000ce924:     	add	w7, w7, w22
1000ce928:     	add	w7, w7, w23
1000ce92c:     	ldrb	w22, [x6, #6]
1000ce930:     	ldrsb	w22, [x2, x22]
1000ce934:     	add	w7, w7, w24
1000ce938:     	add	w7, w7, w22
1000ce93c:     	ldrb	w6, [x6, #7]
1000ce940:     	ldrsb	w6, [x4, x6]
1000ce944:     	add	w6, w7, w6
1000ce948:     	scvtf	s0, w6
1000ce94c:     	ldr	s1, [x5]
1000ce950:     	fadd	s0, s1, s0
1000ce954:     	str	s0, [x5], #64
1000ce958:     	add	x14, x14, #8
1000ce95c:     	cmp	x14, #128
1000ce960:     	b.ne	0x1000ce8e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b4>
1000ce964:     	add	x12, x12, #1
1000ce968:     	add	x13, x13, #4
1000ce96c:     	cmp	x12, #16
1000ce970:     	b.ne	0x1000ce880 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000ce974:     	add	x21, x21, #64
1000ce978:     	add	x20, x20, #64
1000ce97c:     	cmp	x20, x8
1000ce980:     	b.ne	0x1000ce798 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000ce984:     	add	x1, sp, #136
1000ce988:     	mov	x0, x19
1000ce98c:     	mov	w2, #1024
1000ce990:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ce994:     	ldur	x8, [x29, #-72]
1000ce998:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x244>
1000ce99c:     	ldr	x9, [x9, #392]
1000ce9a0:     	ldr	x9, [x9]
1000ce9a4:     	cmp	x9, x8
1000ce9a8:     	b.ne	0x1000ce9c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x294>
1000ce9ac:     	add	sp, sp, #1168
1000ce9b0:     	ldp	x29, x30, [sp, #64]
1000ce9b4:     	ldp	x20, x19, [sp, #48]
1000ce9b8:     	ldp	x22, x21, [sp, #32]
1000ce9bc:     	ldp	x24, x23, [sp, #16]
1000ce9c0:     	ldp	x28, x27, [sp], #80
1000ce9c4:     	ret
1000ce9c8:     	bl	0x100163694 <_strcmp+0x100163694>

