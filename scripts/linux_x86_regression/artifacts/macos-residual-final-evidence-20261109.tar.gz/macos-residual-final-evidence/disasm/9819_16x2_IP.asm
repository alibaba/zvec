00000001000c606c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c606c:     	sub	sp, sp, #272
1000c6070:     	stp	x28, x27, [sp, #176]
1000c6074:     	stp	x26, x25, [sp, #192]
1000c6078:     	stp	x24, x23, [sp, #208]
1000c607c:     	stp	x22, x21, [sp, #224]
1000c6080:     	stp	x20, x19, [sp, #240]
1000c6084:     	stp	x29, x30, [sp, #256]
1000c6088:     	add	x29, sp, #256
1000c608c:     	str	x3, [sp]
1000c6090:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x5c>
1000c6094:     	ldr	x8, [x8, #392]
1000c6098:     	ldr	x8, [x8]
1000c609c:     	stur	x8, [x29, #-96]
1000c60a0:     	movi.2d	v0, #0000000000000000
1000c60a4:     	stp	q0, q0, [sp, #128]
1000c60a8:     	stp	q0, q0, [sp, #96]
1000c60ac:     	stp	q0, q0, [sp, #64]
1000c60b0:     	stp	q0, q0, [sp, #32]
1000c60b4:     	ands	x8, x2, #0xfffffffffffffffe
1000c60b8:     	b.eq	0x1000c625c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1f0>
1000c60bc:     	add	x8, x1, x8
1000c60c0:     	str	x8, [sp, #8]
1000c60c4:     	adrp	x9, 0x100166000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x88>
1000c60c8:     	add	x9, x9, #1500
1000c60cc:     	mov	x11, #0
1000c60d0:     	ldp	w4, w23, [x1]
1000c60d4:     	ubfx	x8, x4, #4, #4
1000c60d8:     	stp	x1, x8, [sp, #16]
1000c60dc:     	ubfx	x13, x4, #8, #4
1000c60e0:     	and	x14, x4, #0xf
1000c60e4:     	ubfx	x15, x4, #12, #4
1000c60e8:     	ubfx	x16, x4, #16, #4
1000c60ec:     	ubfx	x17, x4, #20, #4
1000c60f0:     	ubfx	x2, x4, #24, #4
1000c60f4:     	lsr	x4, x4, #28
1000c60f8:     	and	x5, x23, #0xf
1000c60fc:     	ubfx	x6, x23, #4, #4
1000c6100:     	ubfx	x7, x23, #8, #4
1000c6104:     	ubfx	x19, x23, #12, #4
1000c6108:     	ubfx	x20, x23, #16, #4
1000c610c:     	ubfx	x21, x23, #20, #4
1000c6110:     	ubfx	x22, x23, #24, #4
1000c6114:     	lsr	x23, x23, #28
1000c6118:     	ldr	w24, [x0, x11]
1000c611c:     	lsl	w25, w24, #4
1000c6120:     	and	x25, x25, #0xf0
1000c6124:     	orr	x26, x25, x14
1000c6128:     	ldrsb	w26, [x9, x26]
1000c612c:     	and	x27, x24, #0xf0
1000c6130:     	ldr	x8, [sp, #24]
1000c6134:     	orr	x28, x27, x8
1000c6138:     	ldrsb	w28, [x9, x28]
1000c613c:     	lsr	x30, x24, #4
1000c6140:     	and	x30, x30, #0xf0
1000c6144:     	orr	x8, x30, x13
1000c6148:     	ldrsb	w8, [x9, x8]
1000c614c:     	add	w26, w26, w28
1000c6150:     	add	w8, w26, w8
1000c6154:     	lsr	x26, x24, #8
1000c6158:     	and	x26, x26, #0xf0
1000c615c:     	orr	x28, x26, x15
1000c6160:     	ldrsb	w28, [x9, x28]
1000c6164:     	lsr	x3, x24, #12
1000c6168:     	and	x3, x3, #0xf0
1000c616c:     	orr	x10, x3, x16
1000c6170:     	ldrsb	w10, [x9, x10]
1000c6174:     	add	w8, w8, w28
1000c6178:     	add	w8, w8, w10
1000c617c:     	lsr	x10, x24, #16
1000c6180:     	and	x10, x10, #0xf0
1000c6184:     	orr	x28, x10, x17
1000c6188:     	ldrsb	w28, [x9, x28]
1000c618c:     	lsr	x1, x24, #20
1000c6190:     	and	x1, x1, #0xf0
1000c6194:     	orr	x12, x1, x2
1000c6198:     	ldrsb	w12, [x9, x12]
1000c619c:     	add	w8, w8, w28
1000c61a0:     	add	x28, sp, #32
1000c61a4:     	add	w8, w8, w12
1000c61a8:     	lsr	x12, x24, #24
1000c61ac:     	and	x12, x12, #0xf0
1000c61b0:     	orr	x24, x12, x4
1000c61b4:     	ldrsb	w24, [x9, x24]
1000c61b8:     	add	w8, w8, w24
1000c61bc:     	scvtf	s0, w8
1000c61c0:     	add	x8, x28, x11
1000c61c4:     	ldr	s1, [x8]
1000c61c8:     	fadd	s0, s1, s0
1000c61cc:     	orr	x24, x25, x5
1000c61d0:     	ldrsb	w24, [x9, x24]
1000c61d4:     	orr	x25, x27, x6
1000c61d8:     	ldrsb	w25, [x9, x25]
1000c61dc:     	orr	x27, x30, x7
1000c61e0:     	ldrsb	w27, [x9, x27]
1000c61e4:     	add	w24, w24, w25
1000c61e8:     	add	w24, w24, w27
1000c61ec:     	orr	x25, x26, x19
1000c61f0:     	ldrsb	w25, [x9, x25]
1000c61f4:     	orr	x3, x3, x20
1000c61f8:     	ldrsb	w3, [x9, x3]
1000c61fc:     	orr	x10, x10, x21
1000c6200:     	ldrsb	w10, [x9, x10]
1000c6204:     	add	w24, w24, w25
1000c6208:     	add	w3, w24, w3
1000c620c:     	orr	x1, x1, x22
1000c6210:     	ldrsb	w1, [x9, x1]
1000c6214:     	add	w10, w3, w10
1000c6218:     	add	w10, w10, w1
1000c621c:     	orr	x12, x12, x23
1000c6220:     	ldrsb	w12, [x9, x12]
1000c6224:     	add	w10, w10, w12
1000c6228:     	scvtf	s1, w10
1000c622c:     	str	s0, [x8]
1000c6230:     	ldr	s0, [x8, #64]
1000c6234:     	fadd	s0, s0, s1
1000c6238:     	str	s0, [x8, #64]
1000c623c:     	add	x11, x11, #4
1000c6240:     	cmp	x11, #64
1000c6244:     	b.ne	0x1000c6118 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c6248:     	add	x0, x0, #64
1000c624c:     	ldp	x8, x1, [sp, #8]
1000c6250:     	add	x1, x1, #8
1000c6254:     	cmp	x1, x8
1000c6258:     	b.ne	0x1000c60cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c625c:     	ldp	q0, q1, [sp, #96]
1000c6260:     	ldr	x8, [sp]
1000c6264:     	stp	q0, q1, [x8, #64]
1000c6268:     	ldp	q0, q1, [sp, #128]
1000c626c:     	stp	q0, q1, [x8, #96]
1000c6270:     	ldp	q0, q1, [sp, #32]
1000c6274:     	stp	q0, q1, [x8]
1000c6278:     	ldp	q0, q1, [sp, #64]
1000c627c:     	stp	q0, q1, [x8, #32]
1000c6280:     	ldur	x8, [x29, #-96]
1000c6284:     	adrp	x9, 0x100168000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x250>
1000c6288:     	ldr	x9, [x9, #392]
1000c628c:     	ldr	x9, [x9]
1000c6290:     	cmp	x9, x8
1000c6294:     	b.ne	0x1000c62b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24c>
1000c6298:     	ldp	x29, x30, [sp, #256]
1000c629c:     	ldp	x20, x19, [sp, #240]
1000c62a0:     	ldp	x22, x21, [sp, #224]
1000c62a4:     	ldp	x24, x23, [sp, #208]
1000c62a8:     	ldp	x26, x25, [sp, #192]
1000c62ac:     	ldp	x28, x27, [sp, #176]
1000c62b0:     	add	sp, sp, #272
1000c62b4:     	ret
1000c62b8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

