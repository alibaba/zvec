00000001000bf33c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bf33c:     	sub	sp, sp, #208
1000bf340:     	stp	x28, x27, [sp, #112]
1000bf344:     	stp	x26, x25, [sp, #128]
1000bf348:     	stp	x24, x23, [sp, #144]
1000bf34c:     	stp	x22, x21, [sp, #160]
1000bf350:     	stp	x20, x19, [sp, #176]
1000bf354:     	stp	x29, x30, [sp, #192]
1000bf358:     	add	x29, sp, #192
1000bf35c:     	str	x3, [sp]
1000bf360:     	adrp	x8, 0x100168000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x90>
1000bf364:     	ldr	x8, [x8, #392]
1000bf368:     	ldr	x8, [x8]
1000bf36c:     	stur	x8, [x29, #-88]
1000bf370:     	movi.2d	v0, #0000000000000000
1000bf374:     	stp	q0, q0, [sp, #64]
1000bf378:     	stp	q0, q0, [sp, #32]
1000bf37c:     	ands	x8, x2, #0xfffffffffffffffe
1000bf380:     	b.eq	0x1000bf524 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e8>
1000bf384:     	add	x8, x1, x8
1000bf388:     	str	x8, [sp, #8]
1000bf38c:     	adrp	x9, 0x100166000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xb4>
1000bf390:     	add	x9, x9, #988
1000bf394:     	mov	x11, #0
1000bf398:     	ldp	w4, w23, [x1]
1000bf39c:     	ubfx	x8, x4, #4, #4
1000bf3a0:     	stp	x1, x8, [sp, #16]
1000bf3a4:     	ubfx	x13, x4, #8, #4
1000bf3a8:     	and	x14, x4, #0xf
1000bf3ac:     	ubfx	x15, x4, #12, #4
1000bf3b0:     	ubfx	x16, x4, #16, #4
1000bf3b4:     	ubfx	x17, x4, #20, #4
1000bf3b8:     	ubfx	x2, x4, #24, #4
1000bf3bc:     	lsr	x4, x4, #28
1000bf3c0:     	and	x5, x23, #0xf
1000bf3c4:     	ubfx	x6, x23, #4, #4
1000bf3c8:     	ubfx	x7, x23, #8, #4
1000bf3cc:     	ubfx	x19, x23, #12, #4
1000bf3d0:     	ubfx	x20, x23, #16, #4
1000bf3d4:     	ubfx	x21, x23, #20, #4
1000bf3d8:     	ubfx	x22, x23, #24, #4
1000bf3dc:     	lsr	x23, x23, #28
1000bf3e0:     	ldr	w24, [x0, x11]
1000bf3e4:     	lsl	w25, w24, #4
1000bf3e8:     	and	x25, x25, #0xf0
1000bf3ec:     	orr	x26, x25, x14
1000bf3f0:     	ldrsb	w26, [x9, x26]
1000bf3f4:     	and	x27, x24, #0xf0
1000bf3f8:     	ldr	x8, [sp, #24]
1000bf3fc:     	orr	x28, x27, x8
1000bf400:     	ldrsb	w28, [x9, x28]
1000bf404:     	lsr	x30, x24, #4
1000bf408:     	and	x30, x30, #0xf0
1000bf40c:     	orr	x8, x30, x13
1000bf410:     	ldrsb	w8, [x9, x8]
1000bf414:     	add	w26, w26, w28
1000bf418:     	add	w8, w26, w8
1000bf41c:     	lsr	x26, x24, #8
1000bf420:     	and	x26, x26, #0xf0
1000bf424:     	orr	x28, x26, x15
1000bf428:     	ldrsb	w28, [x9, x28]
1000bf42c:     	lsr	x3, x24, #12
1000bf430:     	and	x3, x3, #0xf0
1000bf434:     	orr	x10, x3, x16
1000bf438:     	ldrsb	w10, [x9, x10]
1000bf43c:     	add	w8, w8, w28
1000bf440:     	add	w8, w8, w10
1000bf444:     	lsr	x10, x24, #16
1000bf448:     	and	x10, x10, #0xf0
1000bf44c:     	orr	x28, x10, x17
1000bf450:     	ldrsb	w28, [x9, x28]
1000bf454:     	lsr	x1, x24, #20
1000bf458:     	and	x1, x1, #0xf0
1000bf45c:     	orr	x12, x1, x2
1000bf460:     	ldrsb	w12, [x9, x12]
1000bf464:     	add	w8, w8, w28
1000bf468:     	add	x28, sp, #32
1000bf46c:     	add	w8, w8, w12
1000bf470:     	lsr	x12, x24, #24
1000bf474:     	and	x12, x12, #0xf0
1000bf478:     	orr	x24, x12, x4
1000bf47c:     	ldrsb	w24, [x9, x24]
1000bf480:     	add	w8, w8, w24
1000bf484:     	scvtf	s0, w8
1000bf488:     	add	x8, x28, x11
1000bf48c:     	ldr	s1, [x8]
1000bf490:     	fadd	s0, s1, s0
1000bf494:     	orr	x24, x25, x5
1000bf498:     	ldrsb	w24, [x9, x24]
1000bf49c:     	orr	x25, x27, x6
1000bf4a0:     	ldrsb	w25, [x9, x25]
1000bf4a4:     	orr	x27, x30, x7
1000bf4a8:     	ldrsb	w27, [x9, x27]
1000bf4ac:     	add	w24, w24, w25
1000bf4b0:     	add	w24, w24, w27
1000bf4b4:     	orr	x25, x26, x19
1000bf4b8:     	ldrsb	w25, [x9, x25]
1000bf4bc:     	orr	x3, x3, x20
1000bf4c0:     	ldrsb	w3, [x9, x3]
1000bf4c4:     	orr	x10, x10, x21
1000bf4c8:     	ldrsb	w10, [x9, x10]
1000bf4cc:     	add	w24, w24, w25
1000bf4d0:     	add	w3, w24, w3
1000bf4d4:     	orr	x1, x1, x22
1000bf4d8:     	ldrsb	w1, [x9, x1]
1000bf4dc:     	add	w10, w3, w10
1000bf4e0:     	add	w10, w10, w1
1000bf4e4:     	orr	x12, x12, x23
1000bf4e8:     	ldrsb	w12, [x9, x12]
1000bf4ec:     	add	w10, w10, w12
1000bf4f0:     	scvtf	s1, w10
1000bf4f4:     	str	s0, [x8]
1000bf4f8:     	ldr	s0, [x8, #32]
1000bf4fc:     	fadd	s0, s0, s1
1000bf500:     	str	s0, [x8, #32]
1000bf504:     	add	x11, x11, #4
1000bf508:     	cmp	x11, #32
1000bf50c:     	b.ne	0x1000bf3e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000bf510:     	add	x0, x0, #32
1000bf514:     	ldp	x8, x1, [sp, #8]
1000bf518:     	add	x1, x1, #8
1000bf51c:     	cmp	x1, x8
1000bf520:     	b.ne	0x1000bf394 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000bf524:     	ldp	q0, q1, [sp, #32]
1000bf528:     	ldr	x8, [sp]
1000bf52c:     	stp	q0, q1, [x8]
1000bf530:     	ldp	q0, q1, [sp, #64]
1000bf534:     	stp	q0, q1, [x8, #32]
1000bf538:     	ldur	x8, [x29, #-88]
1000bf53c:     	adrp	x9, 0x100168000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x26c>
1000bf540:     	ldr	x9, [x9, #392]
1000bf544:     	ldr	x9, [x9]
1000bf548:     	cmp	x9, x8
1000bf54c:     	b.ne	0x1000bf570 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x234>
1000bf550:     	ldp	x29, x30, [sp, #192]
1000bf554:     	ldp	x20, x19, [sp, #176]
1000bf558:     	ldp	x22, x21, [sp, #160]
1000bf55c:     	ldp	x24, x23, [sp, #144]
1000bf560:     	ldp	x26, x25, [sp, #128]
1000bf564:     	ldp	x28, x27, [sp, #112]
1000bf568:     	add	sp, sp, #208
1000bf56c:     	ret
1000bf570:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

