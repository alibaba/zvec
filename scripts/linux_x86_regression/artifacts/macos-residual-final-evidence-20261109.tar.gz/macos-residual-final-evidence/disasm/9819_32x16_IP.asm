00000001000d45d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d45d4:     	stp	x28, x27, [sp, #-64]!
1000d45d8:     	stp	x22, x21, [sp, #16]
1000d45dc:     	stp	x20, x19, [sp, #32]
1000d45e0:     	stp	x29, x30, [sp, #48]
1000d45e4:     	add	x29, sp, #48
1000d45e8:     	sub	sp, sp, #2064
1000d45ec:     	mov	x19, x3
1000d45f0:     	mov	x20, x1
1000d45f4:     	mov	x21, x0
1000d45f8:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xd0>
1000d45fc:     	ldr	x8, [x8, #392]
1000d4600:     	ldr	x8, [x8]
1000d4604:     	stur	x8, [x29, #-56]
1000d4608:     	lsl	x8, x2, #3
1000d460c:     	and	x22, x8, #0xfffffffffffffff0
1000d4610:     	add	x0, sp, #8
1000d4614:     	mov	w1, #2048
1000d4618:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d461c:     	cbz	x22, 0x1000d4734 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d4620:     	add	x8, x20, x22
1000d4624:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xf4>
1000d4628:     	add	x9, x9, #2012
1000d462c:     	mov	x10, #0
1000d4630:     	add	x11, sp, #8
1000d4634:     	mov	x12, #0
1000d4638:     	ldr	w2, [x21, x10, lsl #2]
1000d463c:     	lsl	w13, w2, #4
1000d4640:     	and	x13, x13, #0xf0
1000d4644:     	and	x14, x2, #0xf0
1000d4648:     	lsr	x15, x2, #4
1000d464c:     	and	x15, x15, #0xf0
1000d4650:     	lsr	x16, x2, #8
1000d4654:     	and	x16, x16, #0xf0
1000d4658:     	lsr	x17, x2, #12
1000d465c:     	and	x17, x17, #0xf0
1000d4660:     	lsr	x0, x2, #16
1000d4664:     	and	x0, x0, #0xf0
1000d4668:     	lsr	x1, x2, #20
1000d466c:     	and	x1, x1, #0xf0
1000d4670:     	lsr	x2, x2, #24
1000d4674:     	and	x2, x2, #0xf0
1000d4678:     	mov	x3, x11
1000d467c:     	ldr	w4, [x20, x12]
1000d4680:     	and	x5, x4, #0xf
1000d4684:     	orr	x5, x13, x5
1000d4688:     	ldrsb	w5, [x9, x5]
1000d468c:     	ubfx	x6, x4, #4, #4
1000d4690:     	orr	x6, x14, x6
1000d4694:     	ldrsb	w6, [x9, x6]
1000d4698:     	ubfx	x7, x4, #8, #4
1000d469c:     	orr	x7, x15, x7
1000d46a0:     	ldrsb	w7, [x9, x7]
1000d46a4:     	add	w5, w5, w6
1000d46a8:     	add	w5, w5, w7
1000d46ac:     	ubfx	x6, x4, #12, #4
1000d46b0:     	orr	x6, x16, x6
1000d46b4:     	ldrsb	w6, [x9, x6]
1000d46b8:     	ubfx	x7, x4, #16, #4
1000d46bc:     	orr	x7, x17, x7
1000d46c0:     	ldrsb	w7, [x9, x7]
1000d46c4:     	add	w5, w5, w6
1000d46c8:     	add	w5, w5, w7
1000d46cc:     	ubfx	x6, x4, #20, #4
1000d46d0:     	orr	x6, x0, x6
1000d46d4:     	ldrsb	w6, [x9, x6]
1000d46d8:     	ubfx	x7, x4, #24, #4
1000d46dc:     	orr	x7, x1, x7
1000d46e0:     	ldrsb	w7, [x9, x7]
1000d46e4:     	add	w5, w5, w6
1000d46e8:     	add	w5, w5, w7
1000d46ec:     	orr	x4, x2, x4, lsr #28
1000d46f0:     	ldrsb	w4, [x9, x4]
1000d46f4:     	add	w4, w5, w4
1000d46f8:     	scvtf	s0, w4
1000d46fc:     	ldr	s1, [x3]
1000d4700:     	fadd	s0, s1, s0
1000d4704:     	str	s0, [x3], #128
1000d4708:     	add	x12, x12, #4
1000d470c:     	cmp	x12, #64
1000d4710:     	b.ne	0x1000d467c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d4714:     	add	x10, x10, #1
1000d4718:     	add	x11, x11, #4
1000d471c:     	cmp	x10, #32
1000d4720:     	b.ne	0x1000d4634 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d4724:     	add	x21, x21, #128
1000d4728:     	add	x20, x20, #64
1000d472c:     	cmp	x20, x8
1000d4730:     	b.ne	0x1000d462c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d4734:     	add	x1, sp, #8
1000d4738:     	mov	x0, x19
1000d473c:     	mov	w2, #2048
1000d4740:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d4744:     	ldur	x8, [x29, #-56]
1000d4748:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x220>
1000d474c:     	ldr	x9, [x9, #392]
1000d4750:     	ldr	x9, [x9]
1000d4754:     	cmp	x9, x8
1000d4758:     	b.ne	0x1000d4774 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d475c:     	add	sp, sp, #2064
1000d4760:     	ldp	x29, x30, [sp, #48]
1000d4764:     	ldp	x20, x19, [sp, #32]
1000d4768:     	ldp	x22, x21, [sp, #16]
1000d476c:     	ldp	x28, x27, [sp], #64
1000d4770:     	ret
1000d4774:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

