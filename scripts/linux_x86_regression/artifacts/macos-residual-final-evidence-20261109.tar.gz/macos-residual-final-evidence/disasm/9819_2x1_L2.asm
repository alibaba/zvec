00000001000b4618 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b4618:     	str	xzr, [x3]
1000b461c:     	lsl	x8, x4, #2
1000b4620:     	cmp	x2, #8
1000b4624:     	b.hs	0x1000b4638 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000b4628:     	mov	x12, #0
1000b462c:     	movi	d1, #0000000000000000
1000b4630:     	movi	d0, #0000000000000000
1000b4634:     	b	0x1000b47c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1ac>
1000b4638:     	mov	x11, #0
1000b463c:     	movi	d0, #0000000000000000
1000b4640:     	adrp	x9, 0x100165000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x74>
1000b4644:     	add	x9, x9, #3804
1000b4648:     	mov	x10, x1
1000b464c:     	ldr	w12, [x10]
1000b4650:     	add	x13, x0, x11
1000b4654:     	ldr	w14, [x13]
1000b4658:     	lsl	w15, w14, #4
1000b465c:     	and	x15, x15, #0xf0
1000b4660:     	bfxil	x15, x12, #0, #4
1000b4664:     	and	x16, x14, #0xf0
1000b4668:     	bfxil	x16, x12, #4, #4
1000b466c:     	ldrb	w16, [x9, x16]
1000b4670:     	ldrb	w15, [x9, x15]
1000b4674:     	lsr	x17, x14, #4
1000b4678:     	and	x17, x17, #0xf0
1000b467c:     	bfxil	x17, x12, #8, #4
1000b4680:     	ldrb	w17, [x9, x17]
1000b4684:     	lsr	x4, x14, #8
1000b4688:     	and	x4, x4, #0xf0
1000b468c:     	bfxil	x4, x12, #12, #4
1000b4690:     	ldrb	w4, [x9, x4]
1000b4694:     	lsr	x5, x14, #12
1000b4698:     	and	x5, x5, #0xf0
1000b469c:     	bfxil	x5, x12, #16, #4
1000b46a0:     	lsr	x6, x14, #16
1000b46a4:     	ldrb	w5, [x9, x5]
1000b46a8:     	and	x6, x6, #0xf0
1000b46ac:     	bfxil	x6, x12, #20, #4
1000b46b0:     	ldrb	w6, [x9, x6]
1000b46b4:     	add	w15, w15, w16
1000b46b8:     	add	w15, w15, w17
1000b46bc:     	lsr	x16, x14, #20
1000b46c0:     	and	x16, x16, #0xf0
1000b46c4:     	bfxil	x16, x12, #24, #4
1000b46c8:     	ldrb	w16, [x9, x16]
1000b46cc:     	add	w15, w15, w4
1000b46d0:     	add	w15, w15, w5
1000b46d4:     	lsr	x14, x14, #24
1000b46d8:     	and	x14, x14, #0xf0
1000b46dc:     	lsr	x17, x12, #28
1000b46e0:     	add	w15, w15, w6
1000b46e4:     	add	w15, w15, w16
1000b46e8:     	orr	x14, x14, x17
1000b46ec:     	ldrb	w14, [x9, x14]
1000b46f0:     	add	w14, w15, w14
1000b46f4:     	scvtf	s1, w14
1000b46f8:     	fadd	s0, s0, s1
1000b46fc:     	str	s0, [x3]
1000b4700:     	ldr	w13, [x13, #4]
1000b4704:     	lsl	w14, w13, #4
1000b4708:     	and	x14, x14, #0xf0
1000b470c:     	bfxil	x14, x12, #0, #4
1000b4710:     	and	x15, x13, #0xf0
1000b4714:     	bfxil	x15, x12, #4, #4
1000b4718:     	lsr	x16, x13, #4
1000b471c:     	and	x16, x16, #0xf0
1000b4720:     	bfxil	x16, x12, #8, #4
1000b4724:     	lsr	x4, x13, #8
1000b4728:     	and	x4, x4, #0xf0
1000b472c:     	bfxil	x4, x12, #12, #4
1000b4730:     	lsr	x5, x13, #12
1000b4734:     	and	x5, x5, #0xf0
1000b4738:     	bfxil	x5, x12, #16, #4
1000b473c:     	lsr	x6, x13, #16
1000b4740:     	and	x6, x6, #0xf0
1000b4744:     	bfxil	x6, x12, #20, #4
1000b4748:     	lsr	x7, x13, #20
1000b474c:     	and	x7, x7, #0xf0
1000b4750:     	bfxil	x7, x12, #24, #4
1000b4754:     	ldrb	w12, [x9, x14]
1000b4758:     	ldrb	w14, [x9, x15]
1000b475c:     	ldrb	w15, [x9, x16]
1000b4760:     	ldrb	w16, [x9, x4]
1000b4764:     	ldrb	w4, [x9, x5]
1000b4768:     	add	w12, w12, w14
1000b476c:     	add	w12, w12, w15
1000b4770:     	ldrb	w14, [x9, x6]
1000b4774:     	ldrb	w15, [x9, x7]
1000b4778:     	add	w12, w12, w16
1000b477c:     	add	w12, w12, w4
1000b4780:     	lsr	x13, x13, #24
1000b4784:     	and	x13, x13, #0xf0
1000b4788:     	orr	x13, x13, x17
1000b478c:     	ldrb	w13, [x9, x13]
1000b4790:     	add	w12, w12, w14
1000b4794:     	add	w12, w12, w15
1000b4798:     	add	w12, w12, w13
1000b479c:     	scvtf	s1, w12
1000b47a0:     	ldr	s2, [x3, #4]
1000b47a4:     	fadd	s1, s2, s1
1000b47a8:     	str	s1, [x3, #4]
1000b47ac:     	add	x12, x11, #8
1000b47b0:     	add	x10, x10, x8
1000b47b4:     	add	x13, x11, #16
1000b47b8:     	mov	x11, x12
1000b47bc:     	cmp	x13, x2
1000b47c0:     	b.ls	0x1000b464c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000b47c4:     	cmp	x12, x2
1000b47c8:     	b.hs	0x1000b4870 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x258>
1000b47cc:     	lsl	w9, w12, #2
1000b47d0:     	mov	w10, #-16
1000b47d4:     	lsr	x11, x12, #3
1000b47d8:     	mul	x11, x8, x11
1000b47dc:     	ubfx	x13, x12, #1, #2
1000b47e0:     	orr	x11, x11, x13
1000b47e4:     	and	w13, w9, #0x4
1000b47e8:     	ldrb	w11, [x1, x11]
1000b47ec:     	lsr	w11, w11, w13
1000b47f0:     	and	w14, w11, #0xf
1000b47f4:     	cmp	w14, #8
1000b47f8:     	csel	w14, wzr, w10, lo
1000b47fc:     	and	x15, x12, #0xfffffffffffffff8
1000b4800:     	bfxil	w14, w11, #0, #4
1000b4804:     	bfxil	x15, x12, #1, #2
1000b4808:     	add	x11, x0, x15
1000b480c:     	ldrb	w15, [x11]
1000b4810:     	lsr	w15, w15, w13
1000b4814:     	scvtf	s2, w14
1000b4818:     	and	w14, w15, #0xf
1000b481c:     	cmp	w14, #8
1000b4820:     	csel	w14, wzr, w10, lo
1000b4824:     	bfxil	w14, w15, #0, #4
1000b4828:     	scvtf	s3, w14
1000b482c:     	fsub	s3, s3, s2
1000b4830:     	fmadd	s0, s3, s3, s0
1000b4834:     	str	s0, [x3]
1000b4838:     	ldrb	w11, [x11, #4]
1000b483c:     	lsr	w11, w11, w13
1000b4840:     	and	w13, w11, #0xf
1000b4844:     	cmp	w13, #8
1000b4848:     	csel	w13, wzr, w10, lo
1000b484c:     	bfxil	w13, w11, #0, #4
1000b4850:     	scvtf	s3, w13
1000b4854:     	fsub	s2, s3, s2
1000b4858:     	fmadd	s1, s2, s2, s1
1000b485c:     	str	s1, [x3, #4]
1000b4860:     	add	x12, x12, #1
1000b4864:     	add	w9, w9, #4
1000b4868:     	cmp	x2, x12
1000b486c:     	b.ne	0x1000b47d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1bc>
1000b4870:     	ret

