00000001000bd4c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bd4c0:     	stp	x22, x21, [sp, #-32]!
1000bd4c4:     	stp	x20, x19, [sp, #16]
1000bd4c8:     	movi.2d	v0, #0000000000000000
1000bd4cc:     	stp	q0, q0, [x3]
1000bd4d0:     	cmp	x2, #8
1000bd4d4:     	b.hs	0x1000bd4e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000bd4d8:     	mov	x8, #0
1000bd4dc:     	b	0x1000bd5f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x130>
1000bd4e0:     	mov	x8, #0
1000bd4e4:     	mov	w14, #8
1000bd4e8:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2cc>
1000bd4ec:     	add	x9, x9, #732
1000bd4f0:     	mov	x10, x0
1000bd4f4:     	mov	x11, #0
1000bd4f8:     	lsr	x8, x8, #1
1000bd4fc:     	mul	x8, x8, x4
1000bd500:     	ldr	w6, [x1, x8]
1000bd504:     	ubfx	x12, x6, #4, #4
1000bd508:     	ubfx	x13, x6, #8, #4
1000bd50c:     	mov	x8, x14
1000bd510:     	ubfx	x14, x6, #12, #4
1000bd514:     	and	x15, x6, #0xf
1000bd518:     	ubfx	x16, x6, #16, #4
1000bd51c:     	ubfx	x17, x6, #20, #4
1000bd520:     	ubfx	x5, x6, #24, #4
1000bd524:     	lsr	x6, x6, #28
1000bd528:     	ldr	w7, [x10, x11]
1000bd52c:     	lsl	w19, w7, #4
1000bd530:     	and	x19, x19, #0xf0
1000bd534:     	orr	x19, x19, x15
1000bd538:     	ldrb	w19, [x9, x19]
1000bd53c:     	and	x20, x7, #0xf0
1000bd540:     	orr	x20, x20, x12
1000bd544:     	ldrb	w20, [x9, x20]
1000bd548:     	lsr	x21, x7, #4
1000bd54c:     	and	x21, x21, #0xf0
1000bd550:     	orr	x21, x21, x13
1000bd554:     	ldrb	w21, [x9, x21]
1000bd558:     	lsr	x22, x7, #8
1000bd55c:     	and	x22, x22, #0xf0
1000bd560:     	orr	x22, x22, x14
1000bd564:     	ldrb	w22, [x9, x22]
1000bd568:     	add	w19, w19, w20
1000bd56c:     	add	w19, w19, w21
1000bd570:     	lsr	x20, x7, #12
1000bd574:     	and	x20, x20, #0xf0
1000bd578:     	orr	x20, x20, x16
1000bd57c:     	ldrb	w20, [x9, x20]
1000bd580:     	lsr	x21, x7, #16
1000bd584:     	and	x21, x21, #0xf0
1000bd588:     	orr	x21, x21, x17
1000bd58c:     	ldrb	w21, [x9, x21]
1000bd590:     	add	w19, w19, w22
1000bd594:     	add	w19, w19, w20
1000bd598:     	lsr	x20, x7, #20
1000bd59c:     	and	x20, x20, #0xf0
1000bd5a0:     	orr	x20, x20, x5
1000bd5a4:     	ldrb	w20, [x9, x20]
1000bd5a8:     	lsr	x7, x7, #24
1000bd5ac:     	and	x7, x7, #0xf0
1000bd5b0:     	orr	x7, x7, x6
1000bd5b4:     	ldrb	w7, [x9, x7]
1000bd5b8:     	add	w19, w19, w21
1000bd5bc:     	add	w19, w19, w20
1000bd5c0:     	add	w7, w19, w7
1000bd5c4:     	scvtf	s0, w7
1000bd5c8:     	ldr	s1, [x3, x11]
1000bd5cc:     	fadd	s0, s1, s0
1000bd5d0:     	str	s0, [x3, x11]
1000bd5d4:     	add	x11, x11, #4
1000bd5d8:     	cmp	x11, #32
1000bd5dc:     	b.ne	0x1000bd528 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x68>
1000bd5e0:     	add	x14, x8, #8
1000bd5e4:     	add	x10, x10, #32
1000bd5e8:     	cmp	x14, x2
1000bd5ec:     	b.ls	0x1000bd4f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000bd5f0:     	cmp	x8, x2
1000bd5f4:     	b.hs	0x1000bd7ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2ec>
1000bd5f8:     	lsl	x9, x4, #2
1000bd5fc:     	ldp	s0, s1, [x3, #8]
1000bd600:     	lsl	x10, x8, #2
1000bd604:     	mov	w11, #-16
1000bd608:     	ldr	s2, [x3, #16]
1000bd60c:     	lsr	x12, x8, #3
1000bd610:     	mul	x13, x9, x12
1000bd614:     	ubfx	x12, x8, #1, #2
1000bd618:     	orr	x13, x13, x12
1000bd61c:     	ldrb	w14, [x1, x13]
1000bd620:     	and	w13, w10, #0x4
1000bd624:     	lsr	w14, w14, w13
1000bd628:     	and	w15, w14, #0xf
1000bd62c:     	cmp	w15, #8
1000bd630:     	csel	w15, wzr, w11, lo
1000bd634:     	and	x16, x10, #0xffffffffffffffe0
1000bd638:     	bfxil	x16, x8, #1, #2
1000bd63c:     	bfxil	w15, w14, #0, #4
1000bd640:     	add	x14, x0, x16
1000bd644:     	ldrb	w16, [x14]
1000bd648:     	lsr	w16, w16, w13
1000bd64c:     	and	w17, w16, #0xf
1000bd650:     	scvtf	s3, w15
1000bd654:     	cmp	w17, #8
1000bd658:     	csel	w15, wzr, w11, lo
1000bd65c:     	bfxil	w15, w16, #0, #4
1000bd660:     	scvtf	s4, w15
1000bd664:     	fsub	s4, s4, s3
1000bd668:     	ldp	s5, s6, [x3]
1000bd66c:     	fmadd	s4, s4, s4, s5
1000bd670:     	str	s4, [x3]
1000bd674:     	ldrb	w15, [x14, #4]
1000bd678:     	lsr	w15, w15, w13
1000bd67c:     	and	w16, w15, #0xf
1000bd680:     	cmp	w16, #8
1000bd684:     	csel	w16, wzr, w11, lo
1000bd688:     	bfxil	w16, w15, #0, #4
1000bd68c:     	scvtf	s4, w16
1000bd690:     	fsub	s4, s4, s3
1000bd694:     	fmadd	s4, s4, s4, s6
1000bd698:     	str	s4, [x3, #4]
1000bd69c:     	ldrb	w15, [x14, #8]
1000bd6a0:     	lsr	w15, w15, w13
1000bd6a4:     	and	w16, w15, #0xf
1000bd6a8:     	cmp	w16, #8
1000bd6ac:     	csel	w16, wzr, w11, lo
1000bd6b0:     	bfxil	w16, w15, #0, #4
1000bd6b4:     	scvtf	s4, w16
1000bd6b8:     	fsub	s4, s4, s3
1000bd6bc:     	fmadd	s0, s4, s4, s0
1000bd6c0:     	str	s0, [x3, #8]
1000bd6c4:     	ldrb	w15, [x14, #12]
1000bd6c8:     	lsr	w15, w15, w13
1000bd6cc:     	and	w16, w15, #0xf
1000bd6d0:     	cmp	w16, #8
1000bd6d4:     	csel	w16, wzr, w11, lo
1000bd6d8:     	bfxil	w16, w15, #0, #4
1000bd6dc:     	scvtf	s4, w16
1000bd6e0:     	fsub	s4, s4, s3
1000bd6e4:     	fmadd	s1, s4, s4, s1
1000bd6e8:     	str	s1, [x3, #12]
1000bd6ec:     	ldrb	w15, [x14, #16]
1000bd6f0:     	lsr	w15, w15, w13
1000bd6f4:     	and	w16, w15, #0xf
1000bd6f8:     	cmp	w16, #8
1000bd6fc:     	csel	w16, wzr, w11, lo
1000bd700:     	bfxil	w16, w15, #0, #4
1000bd704:     	scvtf	s4, w16
1000bd708:     	fsub	s4, s4, s3
1000bd70c:     	fmadd	s2, s4, s4, s2
1000bd710:     	str	s2, [x3, #16]
1000bd714:     	ldrb	w15, [x14, #20]
1000bd718:     	lsr	w15, w15, w13
1000bd71c:     	and	w16, w15, #0xf
1000bd720:     	cmp	w16, #8
1000bd724:     	csel	w16, wzr, w11, lo
1000bd728:     	bfxil	w16, w15, #0, #4
1000bd72c:     	scvtf	s4, w16
1000bd730:     	fsub	s4, s4, s3
1000bd734:     	ldp	s5, s6, [x3, #20]
1000bd738:     	fmadd	s4, s4, s4, s5
1000bd73c:     	str	s4, [x3, #20]
1000bd740:     	ldrb	w14, [x14, #24]
1000bd744:     	lsr	w14, w14, w13
1000bd748:     	and	w15, w14, #0xf
1000bd74c:     	cmp	w15, #8
1000bd750:     	csel	w15, wzr, w11, lo
1000bd754:     	bfxil	w15, w14, #0, #4
1000bd758:     	scvtf	s4, w15
1000bd75c:     	fsub	s4, s4, s3
1000bd760:     	fmadd	s4, s4, s4, s6
1000bd764:     	str	s4, [x3, #24]
1000bd768:     	orr	x12, x10, x12
1000bd76c:     	orr	x12, x12, #0x1c
1000bd770:     	ldrb	w12, [x0, x12]
1000bd774:     	lsr	w12, w12, w13
1000bd778:     	and	w13, w12, #0xf
1000bd77c:     	cmp	w13, #8
1000bd780:     	csel	w13, wzr, w11, lo
1000bd784:     	bfxil	w13, w12, #0, #4
1000bd788:     	scvtf	s4, w13
1000bd78c:     	fsub	s3, s4, s3
1000bd790:     	ldr	s4, [x3, #28]
1000bd794:     	fmadd	s3, s3, s3, s4
1000bd798:     	str	s3, [x3, #28]
1000bd79c:     	add	x8, x8, #1
1000bd7a0:     	add	x10, x10, #4
1000bd7a4:     	cmp	x2, x8
1000bd7a8:     	b.ne	0x1000bd60c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000bd7ac:     	ldp	x20, x19, [sp, #16]
1000bd7b0:     	ldp	x22, x21, [sp], #32
1000bd7b4:     	ret

