00000001000c0e70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c0e70:     	sub	sp, sp, #416
1000c0e74:     	stp	x28, x27, [sp, #320]
1000c0e78:     	stp	x26, x25, [sp, #336]
1000c0e7c:     	stp	x24, x23, [sp, #352]
1000c0e80:     	stp	x22, x21, [sp, #368]
1000c0e84:     	stp	x20, x19, [sp, #384]
1000c0e88:     	stp	x29, x30, [sp, #400]
1000c0e8c:     	add	x29, sp, #400
1000c0e90:     	str	x3, [sp]
1000c0e94:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c4>
1000c0e98:     	ldr	x8, [x8, #392]
1000c0e9c:     	ldr	x8, [x8]
1000c0ea0:     	stur	x8, [x29, #-96]
1000c0ea4:     	movi.2d	v0, #0000000000000000
1000c0ea8:     	stp	q0, q0, [sp, #272]
1000c0eac:     	lsl	x8, x2, #1
1000c0eb0:     	stp	q0, q0, [sp, #240]
1000c0eb4:     	stp	q0, q0, [sp, #208]
1000c0eb8:     	stp	q0, q0, [sp, #176]
1000c0ebc:     	ands	x8, x8, #0xfffffffffffffffc
1000c0ec0:     	b.eq	0x1000c11e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x378>
1000c0ec4:     	add	x8, x1, x8
1000c0ec8:     	str	x8, [sp, #8]
1000c0ecc:     	add	x8, sp, #176
1000c0ed0:     	add	x27, x8, #64
1000c0ed4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2fc>
1000c0ed8:     	add	x11, x11, #732
1000c0edc:     	mov	x12, #0
1000c0ee0:     	ldp	w8, w9, [x1]
1000c0ee4:     	ubfx	x10, x8, #4, #4
1000c0ee8:     	str	x10, [sp, #168]
1000c0eec:     	ubfx	x10, x8, #8, #4
1000c0ef0:     	str	x10, [sp, #160]
1000c0ef4:     	and	x10, x8, #0xf
1000c0ef8:     	str	x10, [sp, #152]
1000c0efc:     	ubfx	x10, x8, #12, #4
1000c0f00:     	str	x10, [sp, #144]
1000c0f04:     	ubfx	x10, x8, #16, #4
1000c0f08:     	str	x10, [sp, #136]
1000c0f0c:     	ubfx	x10, x8, #20, #4
1000c0f10:     	str	x10, [sp, #128]
1000c0f14:     	ubfx	x10, x8, #24, #4
1000c0f18:     	lsr	x8, x8, #28
1000c0f1c:     	stp	x8, x10, [sp, #112]
1000c0f20:     	and	x10, x9, #0xf
1000c0f24:     	ubfx	x8, x9, #4, #4
1000c0f28:     	stp	x8, x10, [sp, #96]
1000c0f2c:     	ubfx	x10, x9, #8, #4
1000c0f30:     	ubfx	x8, x9, #12, #4
1000c0f34:     	stp	x8, x10, [sp, #80]
1000c0f38:     	ubfx	x10, x9, #16, #4
1000c0f3c:     	ubfx	x8, x9, #20, #4
1000c0f40:     	stp	x8, x10, [sp, #64]
1000c0f44:     	ubfx	x10, x9, #24, #4
1000c0f48:     	lsr	x8, x9, #28
1000c0f4c:     	stp	x8, x10, [sp, #48]
1000c0f50:     	ldp	w9, w17, [x1, #8]
1000c0f54:     	and	x10, x9, #0xf
1000c0f58:     	ubfx	x8, x9, #4, #4
1000c0f5c:     	stp	x8, x10, [sp, #32]
1000c0f60:     	ubfx	x8, x9, #8, #4
1000c0f64:     	stp	x1, x8, [sp, #16]
1000c0f68:     	ubfx	x28, x9, #12, #4
1000c0f6c:     	ubfx	x30, x9, #16, #4
1000c0f70:     	ubfx	x8, x9, #20, #4
1000c0f74:     	ubfx	x3, x9, #24, #4
1000c0f78:     	lsr	x9, x9, #28
1000c0f7c:     	and	x1, x17, #0xf
1000c0f80:     	ubfx	x10, x17, #4, #4
1000c0f84:     	ubfx	x13, x17, #8, #4
1000c0f88:     	ubfx	x26, x17, #12, #4
1000c0f8c:     	ubfx	x14, x17, #16, #4
1000c0f90:     	ubfx	x15, x17, #20, #4
1000c0f94:     	ubfx	x16, x17, #24, #4
1000c0f98:     	lsr	x17, x17, #28
1000c0f9c:     	ldr	w21, [x0, x12]
1000c0fa0:     	lsl	w2, w21, #4
1000c0fa4:     	and	x2, x2, #0xf0
1000c0fa8:     	ldp	x4, x19, [sp, #152]
1000c0fac:     	orr	x4, x2, x4
1000c0fb0:     	ldrb	w6, [x11, x4]
1000c0fb4:     	and	x4, x21, #0xf0
1000c0fb8:     	ldr	x5, [sp, #168]
1000c0fbc:     	orr	x5, x4, x5
1000c0fc0:     	ldrb	w7, [x11, x5]
1000c0fc4:     	lsr	x5, x21, #4
1000c0fc8:     	and	x5, x5, #0xf0
1000c0fcc:     	orr	x19, x5, x19
1000c0fd0:     	ldrb	w19, [x11, x19]
1000c0fd4:     	add	w6, w6, w7
1000c0fd8:     	add	w19, w6, w19
1000c0fdc:     	lsr	x6, x21, #8
1000c0fe0:     	and	x6, x6, #0xf0
1000c0fe4:     	ldp	x22, x7, [sp, #136]
1000c0fe8:     	orr	x7, x6, x7
1000c0fec:     	ldrb	w20, [x11, x7]
1000c0ff0:     	lsr	x7, x21, #12
1000c0ff4:     	and	x7, x7, #0xf0
1000c0ff8:     	orr	x22, x7, x22
1000c0ffc:     	ldrb	w22, [x11, x22]
1000c1000:     	add	w19, w19, w20
1000c1004:     	add	w22, w19, w22
1000c1008:     	lsr	x19, x21, #16
1000c100c:     	and	x19, x19, #0xf0
1000c1010:     	ldp	x24, x20, [sp, #120]
1000c1014:     	orr	x20, x19, x20
1000c1018:     	ldrb	w23, [x11, x20]
1000c101c:     	lsr	x20, x21, #20
1000c1020:     	and	x20, x20, #0xf0
1000c1024:     	orr	x24, x20, x24
1000c1028:     	ldrb	w24, [x11, x24]
1000c102c:     	add	w22, w22, w23
1000c1030:     	add	w22, w22, w24
1000c1034:     	lsr	x21, x21, #24
1000c1038:     	and	x21, x21, #0xf0
1000c103c:     	ldr	x23, [sp, #112]
1000c1040:     	orr	x23, x21, x23
1000c1044:     	ldrb	w23, [x11, x23]
1000c1048:     	add	w22, w22, w23
1000c104c:     	scvtf	s0, w22
1000c1050:     	ldp	x23, x22, [sp, #96]
1000c1054:     	orr	x22, x2, x22
1000c1058:     	ldrb	w22, [x11, x22]
1000c105c:     	orr	x23, x4, x23
1000c1060:     	ldrb	w23, [x11, x23]
1000c1064:     	ldr	x24, [sp, #88]
1000c1068:     	orr	x24, x5, x24
1000c106c:     	ldrb	w24, [x11, x24]
1000c1070:     	add	w22, w22, w23
1000c1074:     	add	w22, w22, w24
1000c1078:     	ldp	x24, x23, [sp, #72]
1000c107c:     	orr	x23, x6, x23
1000c1080:     	ldrb	w23, [x11, x23]
1000c1084:     	orr	x24, x7, x24
1000c1088:     	ldrb	w24, [x11, x24]
1000c108c:     	ldr	x25, [sp, #64]
1000c1090:     	orr	x25, x19, x25
1000c1094:     	ldrb	w25, [x11, x25]
1000c1098:     	add	w22, w22, w23
1000c109c:     	add	w22, w22, w24
1000c10a0:     	ldr	x23, [sp, #56]
1000c10a4:     	orr	x23, x20, x23
1000c10a8:     	ldrb	w23, [x11, x23]
1000c10ac:     	add	w22, w22, w25
1000c10b0:     	add	w22, w22, w23
1000c10b4:     	ldr	x23, [sp, #48]
1000c10b8:     	orr	x23, x21, x23
1000c10bc:     	ldrb	w23, [x11, x23]
1000c10c0:     	add	w22, w22, w23
1000c10c4:     	scvtf	s1, w22
1000c10c8:     	ldp	x23, x22, [sp, #32]
1000c10cc:     	orr	x22, x2, x22
1000c10d0:     	ldrb	w22, [x11, x22]
1000c10d4:     	orr	x23, x4, x23
1000c10d8:     	ldrb	w23, [x11, x23]
1000c10dc:     	ldr	x24, [sp, #24]
1000c10e0:     	orr	x24, x5, x24
1000c10e4:     	ldrb	w24, [x11, x24]
1000c10e8:     	add	w22, w22, w23
1000c10ec:     	add	w22, w22, w24
1000c10f0:     	orr	x23, x6, x28
1000c10f4:     	ldrb	w23, [x11, x23]
1000c10f8:     	orr	x24, x7, x30
1000c10fc:     	ldrb	w24, [x11, x24]
1000c1100:     	orr	x25, x19, x8
1000c1104:     	ldrb	w25, [x11, x25]
1000c1108:     	add	w22, w22, w23
1000c110c:     	orr	x23, x20, x3
1000c1110:     	ldrb	w23, [x11, x23]
1000c1114:     	add	w22, w22, w24
1000c1118:     	add	w22, w22, w25
1000c111c:     	add	w22, w22, w23
1000c1120:     	orr	x23, x21, x9
1000c1124:     	ldrb	w23, [x11, x23]
1000c1128:     	add	w22, w22, w23
1000c112c:     	scvtf	s2, w22
1000c1130:     	orr	x2, x2, x1
1000c1134:     	ldrb	w2, [x11, x2]
1000c1138:     	orr	x4, x4, x10
1000c113c:     	ldrb	w4, [x11, x4]
1000c1140:     	orr	x5, x5, x13
1000c1144:     	ldrb	w5, [x11, x5]
1000c1148:     	add	w2, w2, w4
1000c114c:     	add	w2, w2, w5
1000c1150:     	orr	x4, x6, x26
1000c1154:     	ldrb	w4, [x11, x4]
1000c1158:     	orr	x5, x7, x14
1000c115c:     	ldrb	w5, [x11, x5]
1000c1160:     	add	w2, w2, w4
1000c1164:     	orr	x4, x19, x15
1000c1168:     	ldrb	w4, [x11, x4]
1000c116c:     	add	w2, w2, w5
1000c1170:     	orr	x5, x20, x16
1000c1174:     	ldrb	w5, [x11, x5]
1000c1178:     	add	w2, w2, w4
1000c117c:     	add	w2, w2, w5
1000c1180:     	orr	x4, x21, x17
1000c1184:     	ldrb	w4, [x11, x4]
1000c1188:     	add	w2, w2, w4
1000c118c:     	add	x4, sp, #176
1000c1190:     	scvtf	s3, w2
1000c1194:     	add	x2, x27, x12
1000c1198:     	ldur	s4, [x2, #-32]
1000c119c:     	fadd	s1, s4, s1
1000c11a0:     	stur	s1, [x2, #-32]
1000c11a4:     	ldr	s1, [x2]
1000c11a8:     	fadd	s1, s1, s2
1000c11ac:     	str	s1, [x2]
1000c11b0:     	ldr	s1, [x2, #32]
1000c11b4:     	fadd	s1, s1, s3
1000c11b8:     	ldr	s2, [x4, x12]
1000c11bc:     	str	s1, [x2, #32]
1000c11c0:     	fadd	s0, s2, s0
1000c11c4:     	str	s0, [x4, x12]
1000c11c8:     	add	x12, x12, #4
1000c11cc:     	cmp	x12, #32
1000c11d0:     	b.ne	0x1000c0f9c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x12c>
1000c11d4:     	add	x0, x0, #32
1000c11d8:     	ldp	x8, x1, [sp, #8]
1000c11dc:     	add	x1, x1, #16
1000c11e0:     	cmp	x1, x8
1000c11e4:     	b.ne	0x1000c0edc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c11e8:     	ldp	q0, q1, [sp, #240]
1000c11ec:     	ldr	x8, [sp]
1000c11f0:     	stp	q0, q1, [x8, #64]
1000c11f4:     	ldp	q0, q1, [sp, #272]
1000c11f8:     	stp	q0, q1, [x8, #96]
1000c11fc:     	ldp	q0, q1, [sp, #176]
1000c1200:     	stp	q0, q1, [x8]
1000c1204:     	ldp	q0, q1, [sp, #208]
1000c1208:     	stp	q0, q1, [x8, #32]
1000c120c:     	ldur	x8, [x29, #-96]
1000c1210:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x164>
1000c1214:     	ldr	x9, [x9, #392]
1000c1218:     	ldr	x9, [x9]
1000c121c:     	cmp	x9, x8
1000c1220:     	b.ne	0x1000c1244 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3d4>
1000c1224:     	ldp	x29, x30, [sp, #400]
1000c1228:     	ldp	x20, x19, [sp, #384]
1000c122c:     	ldp	x22, x21, [sp, #368]
1000c1230:     	ldp	x24, x23, [sp, #352]
1000c1234:     	ldp	x26, x25, [sp, #336]
1000c1238:     	ldp	x28, x27, [sp, #320]
1000c123c:     	add	sp, sp, #416
1000c1240:     	ret
1000c1244:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

