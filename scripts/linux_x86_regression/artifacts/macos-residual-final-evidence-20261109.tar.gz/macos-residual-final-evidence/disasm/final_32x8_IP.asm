00000001000d5fb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5fb0:     	stp	x28, x27, [sp, #-96]!
1000d5fb4:     	stp	x26, x25, [sp, #16]
1000d5fb8:     	stp	x24, x23, [sp, #32]
1000d5fbc:     	stp	x22, x21, [sp, #48]
1000d5fc0:     	stp	x20, x19, [sp, #64]
1000d5fc4:     	stp	x29, x30, [sp, #80]
1000d5fc8:     	add	x29, sp, #80
1000d5fcc:     	sub	sp, sp, #1488
1000d5fd0:     	str	x3, [sp]
1000d5fd4:     	mov	x20, x1
1000d5fd8:     	mov	x22, x0
1000d5fdc:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d5fe0:     	ldr	x8, [x8, #392]
1000d5fe4:     	ldr	x8, [x8]
1000d5fe8:     	stur	x8, [x29, #-96]
1000d5fec:     	lsl	x8, x2, #2
1000d5ff0:     	and	x19, x8, #0xfffffffffffffff8
1000d5ff4:     	add	x0, sp, #448
1000d5ff8:     	mov	w1, #1024
1000d5ffc:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d6000:     	cbz	x19, 0x1000d652c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d6004:     	add	x8, x20, x19
1000d6008:     	str	x8, [sp, #8]
1000d600c:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d6010:     	add	x9, x9, #1980
1000d6014:     	mov	x10, #0
1000d6018:     	ldp	w8, w11, [x20]
1000d601c:     	ubfx	x13, x8, #8, #4
1000d6020:     	ubfx	x12, x8, #16, #4
1000d6024:     	stp	x12, x13, [sp, #432]
1000d6028:     	ubfx	x15, x8, #24, #4
1000d602c:     	ldp	w12, w13, [x20, #8]
1000d6030:     	and	x14, x8, #0xf
1000d6034:     	stp	x14, x15, [sp, #416]
1000d6038:     	ubfx	x15, x8, #4, #4
1000d603c:     	ubfx	x14, x8, #12, #4
1000d6040:     	stp	x14, x15, [sp, #400]
1000d6044:     	ubfx	x14, x8, #20, #4
1000d6048:     	lsr	x8, x8, #28
1000d604c:     	stp	x8, x14, [sp, #384]
1000d6050:     	and	x8, x11, #0xf
1000d6054:     	str	x8, [sp, #376]
1000d6058:     	ubfx	x8, x11, #8, #4
1000d605c:     	str	x8, [sp, #368]
1000d6060:     	ubfx	x8, x11, #16, #4
1000d6064:     	str	x8, [sp, #360]
1000d6068:     	ubfx	x8, x11, #24, #4
1000d606c:     	str	x8, [sp, #352]
1000d6070:     	ubfx	x8, x11, #4, #4
1000d6074:     	str	x8, [sp, #344]
1000d6078:     	ubfx	x8, x11, #12, #4
1000d607c:     	str	x8, [sp, #336]
1000d6080:     	ubfx	x8, x11, #20, #4
1000d6084:     	str	x8, [sp, #328]
1000d6088:     	lsr	x8, x11, #28
1000d608c:     	str	x8, [sp, #320]
1000d6090:     	and	x11, x12, #0xf
1000d6094:     	ubfx	x8, x12, #8, #4
1000d6098:     	stp	x8, x11, [sp, #304]
1000d609c:     	ubfx	x11, x12, #16, #4
1000d60a0:     	ubfx	x8, x12, #24, #4
1000d60a4:     	stp	x8, x11, [sp, #288]
1000d60a8:     	ubfx	x11, x12, #4, #4
1000d60ac:     	ubfx	x8, x12, #12, #4
1000d60b0:     	stp	x8, x11, [sp, #272]
1000d60b4:     	ubfx	x11, x12, #20, #4
1000d60b8:     	lsr	x8, x12, #28
1000d60bc:     	stp	x8, x11, [sp, #256]
1000d60c0:     	and	x11, x13, #0xf
1000d60c4:     	ubfx	x8, x13, #8, #4
1000d60c8:     	stp	x8, x11, [sp, #240]
1000d60cc:     	ubfx	x11, x13, #16, #4
1000d60d0:     	ubfx	x8, x13, #24, #4
1000d60d4:     	stp	x8, x11, [sp, #224]
1000d60d8:     	ubfx	x11, x13, #4, #4
1000d60dc:     	ubfx	x8, x13, #12, #4
1000d60e0:     	stp	x8, x11, [sp, #208]
1000d60e4:     	ubfx	x11, x13, #20, #4
1000d60e8:     	lsr	x8, x13, #28
1000d60ec:     	stp	x8, x11, [sp, #192]
1000d60f0:     	ldp	w8, w11, [x20, #16]
1000d60f4:     	and	x13, x8, #0xf
1000d60f8:     	ubfx	x12, x8, #8, #4
1000d60fc:     	stp	x12, x13, [sp, #176]
1000d6100:     	ubfx	x13, x8, #16, #4
1000d6104:     	ubfx	x12, x8, #24, #4
1000d6108:     	stp	x12, x13, [sp, #160]
1000d610c:     	ubfx	x13, x8, #4, #4
1000d6110:     	ubfx	x12, x8, #12, #4
1000d6114:     	stp	x12, x13, [sp, #144]
1000d6118:     	ubfx	x12, x8, #20, #4
1000d611c:     	lsr	x8, x8, #28
1000d6120:     	stp	x8, x12, [sp, #128]
1000d6124:     	and	x8, x11, #0xf
1000d6128:     	str	x8, [sp, #120]
1000d612c:     	ubfx	x8, x11, #8, #4
1000d6130:     	str	x8, [sp, #112]
1000d6134:     	ubfx	x8, x11, #16, #4
1000d6138:     	str	x8, [sp, #104]
1000d613c:     	ubfx	x8, x11, #24, #4
1000d6140:     	str	x8, [sp, #96]
1000d6144:     	ubfx	x8, x11, #4, #4
1000d6148:     	str	x8, [sp, #88]
1000d614c:     	ubfx	x8, x11, #12, #4
1000d6150:     	str	x8, [sp, #80]
1000d6154:     	ubfx	x8, x11, #20, #4
1000d6158:     	str	x8, [sp, #72]
1000d615c:     	lsr	x8, x11, #28
1000d6160:     	str	x8, [sp, #64]
1000d6164:     	ldp	w13, w2, [x20, #24]
1000d6168:     	and	x11, x13, #0xf
1000d616c:     	ubfx	x8, x13, #8, #4
1000d6170:     	stp	x8, x11, [sp, #48]
1000d6174:     	ubfx	x11, x13, #16, #4
1000d6178:     	ubfx	x8, x13, #24, #4
1000d617c:     	stp	x8, x11, [sp, #32]
1000d6180:     	ubfx	x8, x13, #4, #4
1000d6184:     	stp	x20, x8, [sp, #16]
1000d6188:     	ubfx	x11, x13, #12, #4
1000d618c:     	ubfx	x12, x13, #20, #4
1000d6190:     	lsr	x13, x13, #28
1000d6194:     	and	x14, x2, #0xf
1000d6198:     	ubfx	x21, x2, #8, #4
1000d619c:     	ubfx	x15, x2, #16, #4
1000d61a0:     	ubfx	x16, x2, #24, #4
1000d61a4:     	ubfx	x17, x2, #4, #4
1000d61a8:     	ubfx	x0, x2, #12, #4
1000d61ac:     	ubfx	x1, x2, #20, #4
1000d61b0:     	lsr	x2, x2, #28
1000d61b4:     	ldr	w25, [x22, x10]
1000d61b8:     	lsl	w3, w25, #4
1000d61bc:     	and	x3, x3, #0xf0
1000d61c0:     	add	x3, x9, x3
1000d61c4:     	ldr	x8, [sp, #416]
1000d61c8:     	ldrsb	w26, [x3, x8]
1000d61cc:     	lsr	x4, x25, #4
1000d61d0:     	and	x4, x4, #0xf0
1000d61d4:     	add	x4, x9, x4
1000d61d8:     	ldr	x8, [sp, #440]
1000d61dc:     	ldrsb	w27, [x4, x8]
1000d61e0:     	lsr	x5, x25, #12
1000d61e4:     	and	x5, x5, #0xf0
1000d61e8:     	add	x5, x9, x5
1000d61ec:     	ldr	x8, [sp, #432]
1000d61f0:     	ldrsb	w28, [x5, x8]
1000d61f4:     	lsr	x6, x25, #20
1000d61f8:     	and	x6, x6, #0xf0
1000d61fc:     	add	x7, x9, x6
1000d6200:     	ldr	x8, [sp, #424]
1000d6204:     	ldrsb	w30, [x7, x8]
1000d6208:     	and	x6, x25, #0xf0
1000d620c:     	add	x6, x9, x6
1000d6210:     	ldr	x8, [sp, #408]
1000d6214:     	ldrsb	w19, [x6, x8]
1000d6218:     	lsr	x23, x25, #8
1000d621c:     	and	x23, x23, #0xf0
1000d6220:     	add	x23, x9, x23
1000d6224:     	ldp	x20, x8, [sp, #392]
1000d6228:     	ldrsb	w8, [x23, x8]
1000d622c:     	lsr	x24, x25, #16
1000d6230:     	and	x24, x24, #0xf0
1000d6234:     	add	x24, x9, x24
1000d6238:     	ldrsb	w20, [x24, x20]
1000d623c:     	lsr	x25, x25, #24
1000d6240:     	and	x25, x25, #0xf0
1000d6244:     	add	x25, x9, x25
1000d6248:     	add	w26, w26, w27
1000d624c:     	ldr	x27, [sp, #384]
1000d6250:     	ldrsb	w27, [x25, x27]
1000d6254:     	add	w26, w26, w28
1000d6258:     	add	w26, w26, w30
1000d625c:     	add	w19, w26, w19
1000d6260:     	add	w8, w19, w8
1000d6264:     	add	w8, w8, w20
1000d6268:     	add	w8, w8, w27
1000d626c:     	scvtf	s0, w8
1000d6270:     	ldp	x19, x8, [sp, #368]
1000d6274:     	ldrsb	w8, [x3, x8]
1000d6278:     	ldrsb	w19, [x4, x19]
1000d627c:     	ldp	x26, x20, [sp, #352]
1000d6280:     	ldrsb	w20, [x5, x20]
1000d6284:     	ldrsb	w26, [x7, x26]
1000d6288:     	ldp	x28, x27, [sp, #336]
1000d628c:     	ldrsb	w27, [x6, x27]
1000d6290:     	ldrsb	w28, [x23, x28]
1000d6294:     	add	w8, w8, w19
1000d6298:     	ldr	x19, [sp, #328]
1000d629c:     	ldrsb	w19, [x24, x19]
1000d62a0:     	add	w8, w8, w20
1000d62a4:     	add	w8, w8, w26
1000d62a8:     	ldr	x20, [sp, #320]
1000d62ac:     	ldrsb	w20, [x25, x20]
1000d62b0:     	add	w8, w8, w27
1000d62b4:     	add	w8, w8, w28
1000d62b8:     	add	w8, w8, w19
1000d62bc:     	add	w8, w8, w20
1000d62c0:     	scvtf	s1, w8
1000d62c4:     	ldp	x19, x8, [sp, #304]
1000d62c8:     	ldrsb	w8, [x3, x8]
1000d62cc:     	ldrsb	w19, [x4, x19]
1000d62d0:     	ldp	x26, x20, [sp, #288]
1000d62d4:     	ldrsb	w20, [x5, x20]
1000d62d8:     	ldrsb	w26, [x7, x26]
1000d62dc:     	ldr	x27, [sp, #280]
1000d62e0:     	ldrsb	w27, [x6, x27]
1000d62e4:     	add	w8, w8, w19
1000d62e8:     	ldr	x19, [sp, #272]
1000d62ec:     	ldrsb	w19, [x23, x19]
1000d62f0:     	add	w8, w8, w20
1000d62f4:     	ldr	x20, [sp, #264]
1000d62f8:     	ldrsb	w20, [x24, x20]
1000d62fc:     	add	w8, w8, w26
1000d6300:     	ldr	x26, [sp, #256]
1000d6304:     	ldrsb	w26, [x25, x26]
1000d6308:     	add	w8, w8, w27
1000d630c:     	add	w8, w8, w19
1000d6310:     	add	w8, w8, w20
1000d6314:     	add	w8, w8, w26
1000d6318:     	scvtf	s2, w8
1000d631c:     	ldp	x19, x8, [sp, #240]
1000d6320:     	ldrsb	w8, [x3, x8]
1000d6324:     	ldrsb	w19, [x4, x19]
1000d6328:     	ldp	x26, x20, [sp, #224]
1000d632c:     	ldrsb	w20, [x5, x20]
1000d6330:     	ldrsb	w26, [x7, x26]
1000d6334:     	add	w8, w8, w19
1000d6338:     	ldr	x19, [sp, #216]
1000d633c:     	ldrsb	w19, [x6, x19]
1000d6340:     	add	w8, w8, w20
1000d6344:     	ldr	x20, [sp, #208]
1000d6348:     	ldrsb	w20, [x23, x20]
1000d634c:     	add	w8, w8, w26
1000d6350:     	ldr	x26, [sp, #200]
1000d6354:     	ldrsb	w26, [x24, x26]
1000d6358:     	add	w8, w8, w19
1000d635c:     	ldr	x19, [sp, #192]
1000d6360:     	ldrsb	w19, [x25, x19]
1000d6364:     	add	w8, w8, w20
1000d6368:     	add	w8, w8, w26
1000d636c:     	add	w8, w8, w19
1000d6370:     	scvtf	s3, w8
1000d6374:     	ldp	x19, x8, [sp, #176]
1000d6378:     	ldrsb	w8, [x3, x8]
1000d637c:     	ldrsb	w19, [x4, x19]
1000d6380:     	ldp	x26, x20, [sp, #160]
1000d6384:     	ldrsb	w20, [x5, x20]
1000d6388:     	ldrsb	w26, [x7, x26]
1000d638c:     	add	w8, w8, w19
1000d6390:     	add	w8, w8, w20
1000d6394:     	ldp	x20, x19, [sp, #144]
1000d6398:     	ldrsb	w19, [x6, x19]
1000d639c:     	ldrsb	w20, [x23, x20]
1000d63a0:     	add	w8, w8, w26
1000d63a4:     	add	w8, w8, w19
1000d63a8:     	ldp	x26, x19, [sp, #128]
1000d63ac:     	ldrsb	w19, [x24, x19]
1000d63b0:     	ldrsb	w26, [x25, x26]
1000d63b4:     	add	w8, w8, w20
1000d63b8:     	add	w8, w8, w19
1000d63bc:     	add	w8, w8, w26
1000d63c0:     	scvtf	s4, w8
1000d63c4:     	ldp	x19, x8, [sp, #112]
1000d63c8:     	ldrsb	w8, [x3, x8]
1000d63cc:     	ldrsb	w19, [x4, x19]
1000d63d0:     	ldr	x20, [sp, #104]
1000d63d4:     	ldrsb	w20, [x5, x20]
1000d63d8:     	add	w8, w8, w19
1000d63dc:     	add	w8, w8, w20
1000d63e0:     	ldp	x20, x19, [sp, #88]
1000d63e4:     	ldrsb	w19, [x7, x19]
1000d63e8:     	ldrsb	w20, [x6, x20]
1000d63ec:     	add	w8, w8, w19
1000d63f0:     	add	w8, w8, w20
1000d63f4:     	ldp	x20, x19, [sp, #72]
1000d63f8:     	ldrsb	w19, [x23, x19]
1000d63fc:     	ldrsb	w20, [x24, x20]
1000d6400:     	add	w8, w8, w19
1000d6404:     	add	w8, w8, w20
1000d6408:     	ldr	x19, [sp, #64]
1000d640c:     	ldrsb	w19, [x25, x19]
1000d6410:     	add	w8, w8, w19
1000d6414:     	scvtf	s5, w8
1000d6418:     	ldp	x19, x8, [sp, #48]
1000d641c:     	ldrsb	w8, [x3, x8]
1000d6420:     	ldrsb	w19, [x4, x19]
1000d6424:     	ldp	x26, x20, [sp, #32]
1000d6428:     	ldrsb	w20, [x5, x20]
1000d642c:     	ldrsb	w26, [x7, x26]
1000d6430:     	add	w8, w8, w19
1000d6434:     	ldr	x19, [sp, #24]
1000d6438:     	ldrsb	w19, [x6, x19]
1000d643c:     	add	w8, w8, w20
1000d6440:     	ldrsb	w20, [x23, x11]
1000d6444:     	add	w8, w8, w26
1000d6448:     	ldrsb	w26, [x24, x12]
1000d644c:     	add	w8, w8, w19
1000d6450:     	add	w8, w8, w20
1000d6454:     	add	w8, w8, w26
1000d6458:     	ldrsb	w19, [x25, x13]
1000d645c:     	add	w8, w8, w19
1000d6460:     	scvtf	s6, w8
1000d6464:     	ldrsb	w8, [x3, x14]
1000d6468:     	ldrsb	w3, [x4, x21]
1000d646c:     	ldrsb	w4, [x5, x15]
1000d6470:     	add	w8, w8, w3
1000d6474:     	add	w8, w8, w4
1000d6478:     	ldrsb	w3, [x7, x16]
1000d647c:     	ldrsb	w4, [x6, x17]
1000d6480:     	add	w8, w8, w3
1000d6484:     	add	w8, w8, w4
1000d6488:     	ldrsb	w3, [x23, x0]
1000d648c:     	add	x5, sp, #448
1000d6490:     	ldrsb	w4, [x24, x1]
1000d6494:     	add	w8, w8, w3
1000d6498:     	add	w8, w8, w4
1000d649c:     	ldrsb	w3, [x25, x2]
1000d64a0:     	add	w8, w8, w3
1000d64a4:     	scvtf	s7, w8
1000d64a8:     	add	x8, x5, x10
1000d64ac:     	ldr	s16, [x8]
1000d64b0:     	fadd	s0, s16, s0
1000d64b4:     	str	s0, [x8]
1000d64b8:     	ldr	s0, [x8, #128]
1000d64bc:     	fadd	s0, s0, s1
1000d64c0:     	str	s0, [x8, #128]
1000d64c4:     	ldr	s0, [x8, #256]
1000d64c8:     	fadd	s0, s0, s2
1000d64cc:     	str	s0, [x8, #256]
1000d64d0:     	ldr	s0, [x8, #384]
1000d64d4:     	fadd	s0, s0, s3
1000d64d8:     	str	s0, [x8, #384]
1000d64dc:     	ldr	s0, [x8, #512]
1000d64e0:     	fadd	s0, s0, s4
1000d64e4:     	str	s0, [x8, #512]
1000d64e8:     	ldr	s0, [x8, #640]
1000d64ec:     	fadd	s0, s0, s5
1000d64f0:     	str	s0, [x8, #640]
1000d64f4:     	ldr	s0, [x8, #768]
1000d64f8:     	fadd	s0, s0, s6
1000d64fc:     	ldr	s1, [x8, #896]
1000d6500:     	fadd	s1, s1, s7
1000d6504:     	str	s0, [x8, #768]
1000d6508:     	str	s1, [x8, #896]
1000d650c:     	add	x10, x10, #4
1000d6510:     	cmp	x10, #128
1000d6514:     	b.ne	0x1000d61b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d6518:     	add	x22, x22, #128
1000d651c:     	ldp	x8, x20, [sp, #8]
1000d6520:     	add	x20, x20, #32
1000d6524:     	cmp	x20, x8
1000d6528:     	b.ne	0x1000d6014 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d652c:     	add	x1, sp, #448
1000d6530:     	ldr	x0, [sp]
1000d6534:     	mov	w2, #1024
1000d6538:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d653c:     	ldur	x8, [x29, #-96]
1000d6540:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0x220>
1000d6544:     	ldr	x9, [x9, #392]
1000d6548:     	ldr	x9, [x9]
1000d654c:     	cmp	x9, x8
1000d6550:     	b.ne	0x1000d6574 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d6554:     	add	sp, sp, #1488
1000d6558:     	ldp	x29, x30, [sp, #80]
1000d655c:     	ldp	x20, x19, [sp, #64]
1000d6560:     	ldp	x22, x21, [sp, #48]
1000d6564:     	ldp	x24, x23, [sp, #32]
1000d6568:     	ldp	x26, x25, [sp, #16]
1000d656c:     	ldp	x28, x27, [sp], #96
1000d6570:     	ret
1000d6574:     	bl	0x100163694 <_strcmp+0x100163694>

