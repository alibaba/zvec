import csv
import argparse
import json
import pathlib
import re
import statistics
import subprocess

root = pathlib.Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--group', choices=['matrix', 'adapter', 'ivf'])
parser.add_argument('--results-dir', default='results')
args = parser.parse_args()
results = root / args.results_dir
results.mkdir(exist_ok=True)
previous = root.parent / 'x86_followup'
groups = {
    'matrix': {'previous_fix': previous/'bin/matrix_candidate', 'candidate': root/'bin/matrix_candidate'},
    'adapter': {'previous_fix': previous/'bin/current_adapter', 'candidate': root/'bin/current_adapter'},
    'ivf': {'previous_fix': previous/'bin/current_ivf', 'candidate': root/'bin/current_ivf'},
}
summary = {}
for group, variants in groups.items():
    if args.group and group != args.group: continue
    expected = {'matrix':504, 'adapter':32, 'ivf':24}[group]
    keys = ['type','metric','dim','record'] if group == 'ivf' else ['type','metric','rows','columns','dim']
    values = {}
    for repetition in range(3):
        names = list(variants)
        if repetition % 2: names.reverse()
        for name in names:
            command = ['/usr/sbin/taskpolicy', '-a', str(variants[name])]
            if group == 'ivf': command += ['--gtest_also_run_disabled_tests','--gtest_filter=*Warm*Benchmark*']
            path = results/f'{group}_{name}_{repetition}.log'
            with path.open('w') as stream:
                subprocess.run(command, cwd=root/'runtime', stdout=stream, stderr=subprocess.STDOUT, check=True)
            if group == 'ivf':
                rows = [dict(re.findall(r'(\w+)=([^,\s]+)', line)) for line in path.read_text().splitlines() if line.startswith('LEGACY_BENCH,')]
            else:
                rows = list(csv.DictReader(path.open()))
            assert len(rows) == expected, (path,len(rows))
            for row in rows:
                key = tuple(row[k] for k in keys)
                values.setdefault(key,{}).setdefault(name,[]).append(float(row['median_us' if group == 'ivf' else 'ns_per_matrix']))
            print(group,name,repetition,'complete',flush=True)
    output=[]
    for key,data in values.items():
        row=dict(zip(keys,key))
        for name,samples in data.items():
            row[name]=statistics.median(samples)
            row[name+'_min']=min(samples)
            row[name+'_max']=max(samples)
        row['candidate_vs_previous_fix']=row['candidate']/row['previous_fix']
        output.append(row)
    with (results/f'{group}_comparison.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(output[0])); writer.writeheader(); writer.writerows(output)
    summary[group]={'count':len(output),'over_5pct':[r for r in output if r['candidate_vs_previous_fix']>1.05]}
    (results/'performance_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(group,'over 5%:',len(summary[group]['over_5pct']),flush=True)
