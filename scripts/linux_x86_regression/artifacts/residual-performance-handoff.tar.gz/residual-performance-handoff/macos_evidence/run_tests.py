import json, pathlib, subprocess, time, xml.etree.ElementTree as ET
root = pathlib.Path(__file__).resolve().parent
repo = root.parent.parent / 'zvec'
runtime = root / 'runtime'
runtime.mkdir(exist_ok=True)
targets = [p.stem for d in ['tests/core/metric', 'tests/turbo'] for p in sorted((repo / d).glob('*_test.cc'))]
targets += ['legacy_quantized_index_test', 'flat_quantizer_distance_test', 'mips_callback_lifetime_test', 'multi_chunk_cluster_test', 'opt_kmeans_cluster_test', 'ivf_legacy_matrix_test', 'ivf_searcher_test']
ivf = ['TestInit', 'LegacyQuantizerDescriptorDoesNotSelectTurboFormat', 'TestColumnMajorFloatWithBuildMemory', 'TestColumnMajorFloatWithFilter', 'TestRowMajorFloatWithBuildMemory', 'TestRowMajorFloatWithFilter', 'TestColumnMajorFloatWith1LevelAndBuildMemory', 'TestColumnMajorInt8WithBuildMemory', 'TestColumnMajorFp16WithBuildMemory', 'TestSearchWithEmptyCentroid', 'TestNprobeScansAllSelectedLists', 'TestNprobeClampToListCount', 'TestMipsEuclideanMetric']
results = {}
for name in targets:
    xml = root / 'results' / (name + '.xml')
    args = [str(root / 'bin' / name), '--gtest_output=xml:' + str(xml)]
    if name == 'ivf_searcher_test': args += ['--gtest_filter=' + ':'.join('IVFSearcherTest.' + x for x in ivf)]
    start = time.monotonic()
    with open(root / 'results' / (name + '.log'), 'w') as log:
        try:
            result = subprocess.run(args, cwd=runtime, stdout=log, stderr=log, timeout=240)
            entry = {'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3)}
        except subprocess.TimeoutExpired:
            entry = {'timeout': 240}
    if xml.exists(): entry['gtest'] = ET.parse(xml).getroot().attrib
    results[name] = entry
    (root / 'results/tests_summary.json').write_text(json.dumps(results, indent=2))
    print(name, entry, flush=True)
