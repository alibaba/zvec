from pathlib import Path
import subprocess,shlex,json,hashlib,re,struct
r=Path(__file__).resolve().parent
commands=json.loads((r/'build/compile_commands.json').read_text())
c=next(x for x in commands if x['file'].endswith('turbo_matrix_test.cc') and 'sanitized' not in x['command'])
base=shlex.split(c['command'])
i=base.index('-arch');del base[i:i+2]
base=[('-march=x86-64' if x.startswith('-march=') else x) for x in base]
base[1:1]=['-target','x86_64-apple-macos14.5','-include',str(r/'benchmark_qos.h')]
base[base.index('-c')+1]=str(r.parent/'audit/matrix_sweep.cc')
metadata={}
for version,header in [('unguarded',r/'buildinfo/matrix_unguarded.h'),('guarded',r/'source/src/turbo/distance/matrix.h')]:
 include=r/'x86_check'/version/'turbo/distance';include.mkdir(parents=True,exist_ok=True);(include/'matrix.h').write_bytes(header.read_bytes())
 args=base.copy();args[1:1]=['-I'+str(include.parent.parent)]
 args[args.index('-o')+1]=str(r/'x86_check'/f'{version}.o')
 pp=args.copy();pp[pp.index('-c')]='-E';pp.insert(1,'-P');pp[pp.index('-o')+1]=str(r/'x86_check'/f'{version}.ii')
 subprocess.run(pp,cwd=c['directory'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run(args,cwd=c['directory'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 text=(r/'x86_check'/f'{version}.ii').read_text()
 tokens=re.findall(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\d+|[^\s]',text)
 b=(r/'x86_check'/f'{version}.o').read_bytes();off=32;sections={}
 for i in range(struct.unpack_from('<I',b,16)[0]):
  cmd,sz=struct.unpack_from('<2I',b,off)
  if cmd==0x19:
   for j in range(struct.unpack_from('<I',b,off+64)[0]):
    pos=off+72+j*80;name=b[pos:pos+16].split(b'\0')[0].decode();seg=b[pos+16:pos+32].split(b'\0')[0].decode();addr,size,foff=struct.unpack_from('<QQI',b,pos+32)
    if seg=='__TEXT':sections[name]={'size':size,'sha256':hashlib.sha256(b[foff:foff+size]).hexdigest()}
  off+=sz
 metadata[version]={'command':args,'preprocessed_token_sha256':hashlib.sha256(json.dumps(tokens).encode()).hexdigest(),'object_sha256':hashlib.sha256(b).hexdigest(),'sections':sections}
metadata['equal_tokens']=metadata['unguarded']['preprocessed_token_sha256']==metadata['guarded']['preprocessed_token_sha256']
metadata['equal_object']=metadata['unguarded']['object_sha256']==metadata['guarded']['object_sha256']
metadata['equal_text_sections']=metadata['unguarded']['sections']==metadata['guarded']['sections']
(r/'buildinfo/x86_unchanged.json').write_text(json.dumps(metadata,indent=2));print({k:metadata[k] for k in ['equal_tokens','equal_object','equal_text_sections']},flush=True)
assert metadata['equal_tokens'] and metadata['equal_text_sections']
