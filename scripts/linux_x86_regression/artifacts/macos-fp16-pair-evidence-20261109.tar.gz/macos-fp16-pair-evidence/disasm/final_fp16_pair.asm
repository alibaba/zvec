
bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000447e4 <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000447e4:     	b	0x100146ff0 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>

0000000100146ff0 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>:
100146ff0:     	add	x8, x0, x2, lsl #1
100146ff4:     	ands	x9, x2, #0xfffffffffffffff8
100146ff8:     	b.eq	0x100147090 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xa0>
100146ffc:     	add	x11, x0, x9, lsl #1
100147000:     	lsl	x9, x2, #1
100147004:     	and	x9, x9, #0xfffffffffffffff0
100147008:     	movi.2d	v0, #0000000000000000
10014700c:     	mov	x10, x0
100147010:     	movi.2d	v1, #0000000000000000
100147014:     	ldr	q2, [x10], #16
100147018:     	ldr	q3, [x1], #16
10014701c:     	fcvtl	v4.4s, v2.4h
100147020:     	fcvtl	v5.4s, v3.4h
100147024:     	fmla.4s	v0, v5, v4
100147028:     	fcvtl2	v2.4s, v2.8h
10014702c:     	fcvtl2	v3.4s, v3.8h
100147030:     	fmla.4s	v1, v3, v2
100147034:     	subs	x9, x9, #16
100147038:     	b.ne	0x100147014 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x24>
10014703c:     	sub	x9, x8, x11
100147040:     	cmp	x9, #7
100147044:     	b.lt	0x10014705c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147048:     	ldr	d2, [x11], #8
10014704c:     	fcvtl	v2.4s, v2.4h
100147050:     	ldr	d3, [x1], #8
100147054:     	fcvtl	v3.4s, v3.4h
100147058:     	fmla.4s	v0, v3, v2
10014705c:     	fadd.4s	v0, v1, v0
100147060:     	faddp.4s	v0, v0, v0
100147064:     	faddp.2s	s0, v0
100147068:     	cmp	x11, x8
10014706c:     	b.eq	0x1001471ac <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
100147070:     	add	x9, x0, x2, lsl #1
100147074:     	sub	x9, x9, x11
100147078:     	sub	x9, x9, #2
10014707c:     	cmp	x9, #30
100147080:     	b.hs	0x1001470ac <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xbc>
100147084:     	mov	x9, x11
100147088:     	mov	x10, x1
10014708c:     	b	0x100147190 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
100147090:     	movi.2d	v1, #0000000000000000
100147094:     	movi.2d	v0, #0000000000000000
100147098:     	mov	x11, x0
10014709c:     	sub	x9, x8, x0
1001470a0:     	cmp	x9, #7
1001470a4:     	b.ge	0x100147048 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x58>
1001470a8:     	b	0x10014705c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
1001470ac:     	lsr	x9, x9, #1
1001470b0:     	add	x12, x9, #1
1001470b4:     	and	x13, x12, #0xfffffffffffffff0
1001470b8:     	lsl	x10, x13, #1
1001470bc:     	add	x9, x11, x10
1001470c0:     	add	x10, x1, x10
1001470c4:     	add	x14, x1, #16
1001470c8:     	add	x11, x11, #16
1001470cc:     	mov	x15, x13
1001470d0:     	ldp	q1, q2, [x11, #-16]
1001470d4:     	fcvtl	v3.4s, v1.4h
1001470d8:     	fcvtl2	v1.4s, v1.8h
1001470dc:     	fcvtl	v4.4s, v2.4h
1001470e0:     	fcvtl2	v2.4s, v2.8h
1001470e4:     	ldp	q5, q6, [x14, #-16]
1001470e8:     	fcvtl	v7.4s, v5.4h
1001470ec:     	fcvtl2	v5.4s, v5.8h
1001470f0:     	fcvtl	v16.4s, v6.4h
1001470f4:     	fcvtl2	v6.4s, v6.8h
1001470f8:     	fmul.4s	v1, v1, v5
1001470fc:     	mov	s5, v1[3]
100147100:     	mov	s17, v1[2]
100147104:     	mov	s18, v1[1]
100147108:     	fmul.4s	v3, v3, v7
10014710c:     	mov	s7, v3[3]
100147110:     	mov	s19, v3[2]
100147114:     	mov	s20, v3[1]
100147118:     	fmul.4s	v2, v2, v6
10014711c:     	mov	s6, v2[3]
100147120:     	mov	s21, v2[2]
100147124:     	mov	s22, v2[1]
100147128:     	fmul.4s	v4, v4, v16
10014712c:     	mov	s16, v4[3]
100147130:     	mov	s23, v4[2]
100147134:     	mov	s24, v4[1]
100147138:     	fadd	s0, s0, s3
10014713c:     	fadd	s0, s0, s20
100147140:     	fadd	s0, s0, s19
100147144:     	fadd	s0, s0, s7
100147148:     	fadd	s0, s0, s1
10014714c:     	fadd	s0, s0, s18
100147150:     	fadd	s0, s0, s17
100147154:     	fadd	s0, s0, s5
100147158:     	fadd	s0, s0, s4
10014715c:     	fadd	s0, s0, s24
100147160:     	fadd	s0, s0, s23
100147164:     	fadd	s0, s0, s16
100147168:     	fadd	s0, s0, s2
10014716c:     	fadd	s0, s0, s22
100147170:     	fadd	s0, s0, s21
100147174:     	fadd	s0, s0, s6
100147178:     	add	x14, x14, #32
10014717c:     	add	x11, x11, #32
100147180:     	subs	x15, x15, #16
100147184:     	b.ne	0x1001470d0 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xe0>
100147188:     	cmp	x12, x13
10014718c:     	b.eq	0x1001471ac <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
100147190:     	ldr	h1, [x9], #2
100147194:     	fcvt	s1, h1
100147198:     	ldr	h2, [x10], #2
10014719c:     	fcvt	s2, h2
1001471a0:     	fmadd	s0, s1, s2, s0
1001471a4:     	cmp	x9, x8
1001471a8:     	b.ne	0x100147190 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
1001471ac:     	fneg	s0, s0
1001471b0:     	str	s0, [x3]
1001471b4:     	ret
