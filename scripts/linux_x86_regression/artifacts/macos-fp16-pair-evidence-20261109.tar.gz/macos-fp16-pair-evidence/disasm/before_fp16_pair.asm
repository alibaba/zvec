
bin/before_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000446d0 <void kernel<zvec::ailego::Float16, 1ul, 1ul, true>(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000446d0:     	b	0x1000446d4 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>

00000001000446d4 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000446d4:     	sub	sp, sp, #80
1000446d8:     	stp	x22, x21, [sp, #32]
1000446dc:     	stp	x20, x19, [sp, #48]
1000446e0:     	stp	x29, x30, [sp, #64]
1000446e4:     	add	x29, sp, #64
1000446e8:     	mov	x19, x3
1000446ec:     	mov	x20, x2
1000446f0:     	mov	x21, x1
1000446f4:     	mov	x22, x0
1000446f8:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3d4>
1000446fc:     	ldr	x8, [x8, #24]
100044700:     	ldaprb	w8, [x8]
100044704:     	tbz	w8, #0, 0x100044750 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100044708:     	stp	x21, x22, [sp, #16]
10004470c:     	stp	x19, x20, [sp]
100044710:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3ec>
100044714:     	ldr	x8, [x8, #200]
100044718:     	ldr	x0, [x8, #24]
10004471c:     	cbz	x0, 0x1000447a8 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100044720:     	ldr	x8, [x0]
100044724:     	ldr	x8, [x8, #48]
100044728:     	add	x1, sp, #24
10004472c:     	add	x2, sp, #16
100044730:     	add	x3, sp, #8
100044734:     	mov	x4, sp
100044738:     	blr	x8
10004473c:     	ldp	x29, x30, [sp, #64]
100044740:     	ldp	x20, x19, [sp, #48]
100044744:     	ldp	x22, x21, [sp, #32]
100044748:     	add	sp, sp, #80
10004474c:     	ret
100044750:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x42c>
100044754:     	ldr	x0, [x0, #24]
100044758:     	bl	0x100163670 <_strcmp+0x100163670>
10004475c:     	cbz	w0, 0x100044708 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100044760:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x43c>
100044764:     	ldr	x8, [x8, #200]
100044768:     	mov	w0, #2
10004476c:     	mov	w1, #2
100044770:     	mov	w2, #8
100044774:     	mov	w3, #0
100044778:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
10004477c:     	adrp	x0, 0x100005000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa0>
100044780:     	add	x0, x0, #3000
100044784:     	adrp	x1, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x460>
100044788:     	ldr	x1, [x1, #200]
10004478c:     	adrp	x2, 0x100000000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x9c>
100044790:     	add	x2, x2, #0
100044794:     	bl	0x100163640 <_strcmp+0x100163640>
100044798:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x474>
10004479c:     	ldr	x0, [x0, #24]
1000447a0:     	bl	0x10016367c <_strcmp+0x10016367c>
1000447a4:     	b	0x100044708 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000447a8:     	bl	0x100005c04 <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000447ac:     	mov	x19, x0
1000447b0:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x48c>
1000447b4:     	ldr	x0, [x0, #24]
1000447b8:     	bl	0x100163664 <_strcmp+0x100163664>
1000447bc:     	mov	x0, x19
1000447c0:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

0000000100146fcc <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>:
100146fcc:     	add	x8, x0, x2, lsl #1
100146fd0:     	ands	x9, x2, #0xfffffffffffffff8
100146fd4:     	b.eq	0x10014706c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xa0>
100146fd8:     	add	x11, x0, x9, lsl #1
100146fdc:     	lsl	x9, x2, #1
100146fe0:     	and	x9, x9, #0xfffffffffffffff0
100146fe4:     	movi.2d	v0, #0000000000000000
100146fe8:     	mov	x10, x0
100146fec:     	movi.2d	v1, #0000000000000000
100146ff0:     	ldr	q2, [x10], #16
100146ff4:     	ldr	q3, [x1], #16
100146ff8:     	fcvtl	v4.4s, v2.4h
100146ffc:     	fcvtl	v5.4s, v3.4h
100147000:     	fmla.4s	v0, v5, v4
100147004:     	fcvtl2	v2.4s, v2.8h
100147008:     	fcvtl2	v3.4s, v3.8h
10014700c:     	fmla.4s	v1, v3, v2
100147010:     	subs	x9, x9, #16
100147014:     	b.ne	0x100146ff0 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x24>
100147018:     	sub	x9, x8, x11
10014701c:     	cmp	x9, #7
100147020:     	b.lt	0x100147038 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147024:     	ldr	d2, [x11], #8
100147028:     	fcvtl	v2.4s, v2.4h
10014702c:     	ldr	d3, [x1], #8
100147030:     	fcvtl	v3.4s, v3.4h
100147034:     	fmla.4s	v0, v3, v2
100147038:     	fadd.4s	v0, v1, v0
10014703c:     	faddp.4s	v0, v0, v0
100147040:     	faddp.2s	s0, v0
100147044:     	cmp	x11, x8
100147048:     	b.eq	0x100147188 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014704c:     	add	x9, x0, x2, lsl #1
100147050:     	sub	x9, x9, x11
100147054:     	sub	x9, x9, #2
100147058:     	cmp	x9, #30
10014705c:     	b.hs	0x100147088 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xbc>
100147060:     	mov	x9, x11
100147064:     	mov	x10, x1
100147068:     	b	0x10014716c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
10014706c:     	movi.2d	v1, #0000000000000000
100147070:     	movi.2d	v0, #0000000000000000
100147074:     	mov	x11, x0
100147078:     	sub	x9, x8, x0
10014707c:     	cmp	x9, #7
100147080:     	b.ge	0x100147024 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x58>
100147084:     	b	0x100147038 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147088:     	lsr	x9, x9, #1
10014708c:     	add	x12, x9, #1
100147090:     	and	x13, x12, #0xfffffffffffffff0
100147094:     	lsl	x10, x13, #1
100147098:     	add	x9, x11, x10
10014709c:     	add	x10, x1, x10
1001470a0:     	add	x14, x1, #16
1001470a4:     	add	x11, x11, #16
1001470a8:     	mov	x15, x13
1001470ac:     	ldp	q1, q2, [x11, #-16]
1001470b0:     	fcvtl	v3.4s, v1.4h
1001470b4:     	fcvtl2	v1.4s, v1.8h
1001470b8:     	fcvtl	v4.4s, v2.4h
1001470bc:     	fcvtl2	v2.4s, v2.8h
1001470c0:     	ldp	q5, q6, [x14, #-16]
1001470c4:     	fcvtl	v7.4s, v5.4h
1001470c8:     	fcvtl2	v5.4s, v5.8h
1001470cc:     	fcvtl	v16.4s, v6.4h
1001470d0:     	fcvtl2	v6.4s, v6.8h
1001470d4:     	fmul.4s	v1, v1, v5
1001470d8:     	mov	s5, v1[3]
1001470dc:     	mov	s17, v1[2]
1001470e0:     	mov	s18, v1[1]
1001470e4:     	fmul.4s	v3, v3, v7
1001470e8:     	mov	s7, v3[3]
1001470ec:     	mov	s19, v3[2]
1001470f0:     	mov	s20, v3[1]
1001470f4:     	fmul.4s	v2, v2, v6
1001470f8:     	mov	s6, v2[3]
1001470fc:     	mov	s21, v2[2]
100147100:     	mov	s22, v2[1]
100147104:     	fmul.4s	v4, v4, v16
100147108:     	mov	s16, v4[3]
10014710c:     	mov	s23, v4[2]
100147110:     	mov	s24, v4[1]
100147114:     	fadd	s0, s0, s3
100147118:     	fadd	s0, s0, s20
10014711c:     	fadd	s0, s0, s19
100147120:     	fadd	s0, s0, s7
100147124:     	fadd	s0, s0, s1
100147128:     	fadd	s0, s0, s18
10014712c:     	fadd	s0, s0, s17
100147130:     	fadd	s0, s0, s5
100147134:     	fadd	s0, s0, s4
100147138:     	fadd	s0, s0, s24
10014713c:     	fadd	s0, s0, s23
100147140:     	fadd	s0, s0, s16
100147144:     	fadd	s0, s0, s2
100147148:     	fadd	s0, s0, s22
10014714c:     	fadd	s0, s0, s21
100147150:     	fadd	s0, s0, s6
100147154:     	add	x14, x14, #32
100147158:     	add	x11, x11, #32
10014715c:     	subs	x15, x15, #16
100147160:     	b.ne	0x1001470ac <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xe0>
100147164:     	cmp	x12, x13
100147168:     	b.eq	0x100147188 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014716c:     	ldr	h1, [x9], #2
100147170:     	fcvt	s1, h1
100147174:     	ldr	h2, [x10], #2
100147178:     	fcvt	s2, h2
10014717c:     	fmadd	s0, s1, s2, s0
100147180:     	cmp	x9, x8
100147184:     	b.ne	0x10014716c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
100147188:     	fneg	s0, s0
10014718c:     	str	s0, [x3]
100147190:     	ret
