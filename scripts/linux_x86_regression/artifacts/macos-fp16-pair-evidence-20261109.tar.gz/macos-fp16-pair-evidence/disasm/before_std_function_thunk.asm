
bin/before_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100162aa0 <std::__1::__function::__func<void (*)(void const*, void const*, unsigned long, float*), std::__1::allocator<void (*)(void const*, void const*, unsigned long, float*)>, void (void const*, void const*, unsigned long, float*)>::operator()(void const*&&, void const*&&, unsigned long&&, float*&&)>:
100162aa0:     	ldr	x5, [x0, #8]
100162aa4:     	ldr	x0, [x1]
100162aa8:     	ldr	x1, [x2]
100162aac:     	ldr	x2, [x3]
100162ab0:     	ldr	x3, [x4]
100162ab4:     	br	x5
