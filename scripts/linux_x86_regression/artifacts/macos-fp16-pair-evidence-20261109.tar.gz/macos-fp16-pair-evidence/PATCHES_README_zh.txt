先读 FP16_PAIR_REPORT_zh.md。选择且仅选择匹配当前源码的一份补丁：

A. 当前源码是 9819c706 或 c65ac889，尚未应用任何候选：
   git apply --check /证据包绝对路径/buildinfo/final_vs_9819c706.patch
   git apply /证据包绝对路径/buildinfo/final_vs_9819c706.patch

B. 已应用上一轮 ARM64 INT4 大多列条件保护：
   git apply --check /证据包绝对路径/buildinfo/fp16_pair_only.patch
   git apply /证据包绝对路径/buildinfo/fp16_pair_only.patch

C. 已应用 Linux final（原 SHA256 81a2909b… 交接包），尚未应用 ARM64 两项修复：
   git apply --check /证据包绝对路径/buildinfo/macos_fixes_vs_x86_final.patch
   git apply /证据包绝对路径/buildinfo/macos_fixes_vs_x86_final.patch

建议独立工作树，不覆盖已有改动；三份补丁不要叠加使用。
本次没有提交、推送或合入主分支。
FP16 最小补丁仅 matrix.h 的 ARM64 include/单对 IP 直接调用，共 13 行新增。
完整候选仍仅修改 matrix.h。

本包是复验材料，脚本保留本机 checkout/build/deps 绝对路径，不是跨机一键运行包。
交叉编译验证证明本次 x86 代码/目标文件相同；没有声称本轮重跑了 Linux 服务器性能。
