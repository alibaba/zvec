import json, pathlib, shlex, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
name = sys.argv[1]
commands = json.load(open('/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_fp16_pair_20261109/build/compile_commands.json'))
c = next(c for c in commands if c['file'].endswith('turbo_matrix_test.cc') and 'sanitized' not in c['command'])
args = shlex.split(c['command'])
variant = next((x.split('=', 1)[1] for x in sys.argv if x.startswith('--variant=')), 'current')
build = pathlib.Path('/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_fp16_pair_20261109/build')
if variant == 'parent':
    args = [x.replace(str(root.parent.parent / 'zvec'), '/tmp/zvec-legacy-ivf-parent') for x in args]
    args.insert(1, '-DLEGACY')
    build = pathlib.Path('/tmp/zvec-legacy-ivf-parent-build')
elif variant == 'before':
    args[1:1] = ['-I' + str(root / 'frozen_before')]
    build = pathlib.Path('/tmp/zvec-legacy-ivf-before-build')
args[1:1] = ['-include', str(root / 'benchmark_qos.h')]
args[args.index('-c') + 1] = next((x.split('=', 1)[1] for x in sys.argv if x.startswith('--source=')), str(root.parent / 'audit/matrix_sweep.cc'))
args[args.index('-o') + 1] = str(root / (name + '.o'))
with open(root / (name + '_compile.log'), 'w') as log:
    subprocess.run(args, cwd=c['directory'], check=True, stdout=log, stderr=log)
subprocess.run([args[0], '-isysroot', args[args.index('-isysroot') + 1], str(root / (name + '.o')), str(build / 'lib/libzvec_turbo.a'), str(build / 'lib/libzvec_ailego.a'), '-o', str(root / 'bin' / name)], check=True)
if '--build-only' not in sys.argv:
    with open(root / 'results' / (name + '.csv'), 'w') as out:
        subprocess.run([str(root / 'bin' / name)], stdout=out, check=True)
