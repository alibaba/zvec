import pathlib, re, shlex, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
build = pathlib.Path('/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_fp16_pair_20261109/build')
for name in sys.argv[1:]:
    command = subprocess.check_output(['ninja', '-t', 'commands', name], cwd=build, text=True).splitlines()[-1]
    args = shlex.split(command)[2:-2]
    args[args.index('-o') + 1] = str(root / 'bin' / name)
    static = []
    for arg in args:
        if arg.endswith('.dylib'):
            static += ['-Wl,-force_load', re.sub(r'\.\d+\.\d+\.\d+\.dylib$', '.a', arg)]
        elif not arg.startswith('-Wl,-rpath,'):
            static.append(arg)
    subprocess.run(static, cwd=build, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print('linked', name, flush=True)
