#include <algorithm>
#include <array>
#include <cstdio>
#include <cstring>
#include <vector>
#include <turbo/distance/matrix.h>
#include <turbo/distance/neon/fp16/inner_product.h>
using namespace zvec;
using Half=ailego::Float16;
using Fn=void(*)(const void*,const void*,size_t,float*);
volatile float consumed_probe;
__attribute__((noinline)) void dispatched(const void* a,const void* b,size_t n,float* out) {
 static const auto f=turbo::get_distance_func(turbo::MetricType::kInnerProduct,turbo::DataType::kFp16,turbo::QuantizeType::kRaw);
 f(a,b,n,out);
}
__attribute__((noinline)) void direct(const void* a,const void* b,size_t n,float* out) {
 turbo::neon::inner_product_fp16_distance(a,b,n,out);
}
__attribute__((noinline)) void candidate(const void* a,const void* b,size_t n,float* out) {
 turbo::MinusInnerProductMatrix<Half,1,1>::Compute(static_cast<const Half*>(a),static_cast<const Half*>(b),n,out);
}
int main() {
 auto f=turbo::get_distance_func(turbo::MetricType::kInnerProduct,turbo::DataType::kFp16,turbo::QuantizeType::kRaw);
 auto target=f.target<Fn>();
 if(!target || *target!=&turbo::neon::inner_product_fp16_distance) {std::fprintf(stderr,"auto dispatch differs\n");return 1;}
 std::fprintf(stderr,"auto_dispatch_is_neon=1\n");
 std::vector<Half>a(513),b(513);
 for(size_t i=0;i<513;++i){a[i]=Half(float(int(i%17)-8)/7);b[i]=Half(float(int(i%13)-6)/7);}
 for(size_t n:{0U,1U,3U,4U,7U,8U,9U,17U,127U,128U,129U,512U,513U}){
  float x,y,z;dispatched(a.data(),b.data(),n,&x);direct(a.data(),b.data(),n,&y);candidate(a.data(),b.data(),n,&z);
  if(std::memcmp(&x,&y,4)||std::memcmp(&x,&z,4))return 2;
 }
 std::puts("path,dim,ns_per_pair");
 std::array<Fn,3> funcs{dispatched,direct,candidate};const char* names[]={"std_function","direct_neon","matrix_candidate"};
 for(size_t n:{128U,512U})for(int repeat=0;repeat<5;++repeat)for(int j=0;j<3;++j){
  int index=repeat%2?2-j:j;Fn fn=funcs[index];float result;
  auto time=[&](size_t count){auto start=BenchmarkClock::now();for(size_t i=0;i<count;++i)fn(a.data(),b.data(),n,&result);consumed_probe=result;return std::chrono::duration<double,std::nano>(BenchmarkClock::now()-start).count();};
  size_t count=1;while(time(count)<20000000)count*=2;
  std::array<double,5> times;for(auto& t:times)t=time(count)/count;std::sort(times.begin(),times.end());
  std::printf("%s,%zu,%.3f\n",names[index],n,times[2]);
 }
}
