# FINAL two-round summary (candidate = FINAL)

## matrix
- round1: >5% vs 955: 2, vs 7abc: 2, vs before: 15, vs parent: 68; median FINAL/955 0.997, FINAL/7abc 0.999
- round2: >5% vs 955: 2, vs 7abc: 2, vs before: 15, vs parent: 71; median FINAL/955 0.998, FINAL/7abc 0.999
- >5% vs 955 in BOTH rounds: 2
    ('FP32', 'L2', '1', '1', '128'): r1 1.073, r2 1.075
    ('INT8', 'L2', '2', '1', '128'): r1 1.070, r2 1.076
- >5% vs 7abc in BOTH rounds: 2
    ('FP32', 'L2', '1', '1', '128'): r1 1.062, r2 1.079
    ('FP32', 'L2', '1', '1', '512'): r1 1.058, r2 1.059

## adapter
- round1: >5% vs 955: 0, vs 7abc: 0, vs before: 0, vs parent: 0; median FINAL/955 0.847, FINAL/7abc 0.998
- round2: >5% vs 955: 0, vs 7abc: 0, vs before: 0, vs parent: 0; median FINAL/955 0.862, FINAL/7abc 0.997
- >5% vs 955 in BOTH rounds: 0
- >5% vs 7abc in BOTH rounds: 0

## ivf
- round1: >5% vs 955: 0, vs 7abc: 0, vs before: 0, vs parent: 0; median FINAL/955 0.990, FINAL/7abc 0.991
- round2: >5% vs 955: 0, vs 7abc: 0, vs before: 0, vs parent: 0; median FINAL/955 0.874, FINAL/7abc 0.989
- >5% vs 955 in BOTH rounds: 0
- >5% vs 7abc in BOTH rounds: 0

## Target A: 13 integer raw-matrix items
| type | metric | shape | dim | 955 | 7abc | 9819 | FINAL r1 | FINAL r2 | FINAL/7abc r1 | r2 | FINAL/955 r1 | r2 | status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| INT4 | IP | 16x2 | 128 | 1152.6/1135.7 | 1246.2/1252.4 | 1223.9 | 1084.2 | 1086.8 | 0.870 | 0.868 | 0.941 | 0.957 | PASS |
| INT4 | IP | 16x2 | 512 | 4551.7/4475.4 | 4945.3/5020.1 | 4753.5 | 4273.2 | 4268.5 | 0.864 | 0.850 | 0.939 | 0.954 | PASS |
| INT4 | IP | 32x32 | 128 | 36803.9/36944.8 | 41644.9/40937.5 | 42282.7 | 28684.0 | 28520.7 | 0.689 | 0.697 | 0.779 | 0.772 | PASS |
| INT4 | IP | 32x32 | 512 | 146343.8/146164.5 | 152562.2/161816.4 | 165691.5 | 115494.7 | 113948.3 | 0.757 | 0.704 | 0.789 | 0.780 | PASS |
| INT4 | L2 | 32x1 | 128 | 1215.5/1182.1 | 1265.7/1223.8 | 1234.3 | 991.9 | 991.8 | 0.784 | 0.810 | 0.816 | 0.839 | PASS |
| INT4 | L2 | 32x1 | 512 | 5021.9/4653.0 | 4998.5/4985.0 | 4921.3 | 3756.8 | 3737.9 | 0.752 | 0.750 | 0.748 | 0.803 | PASS |
| INT4 | L2 | 32x16 | 128 | 17893.6/17865.4 | 24264.4/24154.1 | 20066.9 | 13480.2 | 13466.3 | 0.556 | 0.558 | 0.753 | 0.754 | PASS |
| INT4 | L2 | 32x16 | 512 | 71309.5/71656.2 | 84494.8/96172.2 | 81056.6 | 53768.2 | 53590.3 | 0.636 | 0.557 | 0.754 | 0.748 | PASS |
| INT4 | L2 | 32x2 | 128 | 2256.1/2224.0 | 2424.3/2400.1 | 2401.1 | 2238.4 | 2260.6 | 0.923 | 0.942 | 0.992 | 1.016 | PASS |
| INT4 | L2 | 32x2 | 512 | 8857.9/8932.1 | 9682.1/9498.1 | 9588.6 | 8921.1 | 8915.9 | 0.921 | 0.939 | 1.007 | 0.998 | PASS |
| INT4 | L2 | 8x8 | 128 | 2574.6/2575.3 | 2781.5/2920.6 | 2732.5 | 1828.4 | 1808.4 | 0.657 | 0.619 | 0.710 | 0.702 | PASS |
| INT4 | L2 | 8x8 | 512 | 10335.3/10403.0 | 12038.1/11184.7 | 10145.5 | 7256.8 | 7183.6 | 0.603 | 0.642 | 0.702 | 0.691 | PASS |
| INT8 | L2 | 2x2 | 128 | 141.9/141.2 | 152.4/144.8 | 165.4 | 142.1 | 145.5 | 0.933 | 1.005 | 1.002 | 1.031 | FAIL vs 7abc |

## Target B: INT4 record quantized (adapter type 6) and legacy INT4 record IVF
| case | parent | before | 955 | 7abc | 9819 | FINAL r1 | FINAL r2 | FINAL/before r1 | r2 | FINAL/7abc r1 | r2 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| INT4 RecordIP 32x1 d128 | 1297 | 960 | 1380 | 993 | 516 | 499 | 496 | 0.519 | 0.519 | 0.502 | 0.480 |
| INT4 RecordIP 32x1 d512 | 5131 | 2808 | 5306 | 2805 | 1538 | 1478 | 1473 | 0.526 | 0.520 | 0.527 | 0.519 |
| INT4 RecordIP 32x32 d128 | 40431 | 9321 | 9341 | 9406 | 9398 | 9303 | 9387 | 0.998 | 1.005 | 0.989 | 1.000 |
| INT4 RecordIP 32x32 d512 | 159305 | 27721 | 27298 | 27260 | 27291 | 27401 | 27399 | 0.988 | 0.984 | 1.005 | 0.998 |
| INT4 RecordL2 32x1 d128 | 1181 | 987 | 1354 | 1060 | 527 | 516 | 514 | 0.523 | 0.536 | 0.487 | 0.489 |
| INT4 RecordL2 32x1 d512 | 4647 | 2810 | 5424 | 2799 | 1555 | 1493 | 1490 | 0.531 | 0.530 | 0.534 | 0.532 |
| INT4 RecordL2 32x32 d128 | 40686 | 10003 | 9980 | 10017 | 10035 | 9964 | 9989 | 0.996 | 1.005 | 0.995 | 0.991 |
| INT4 RecordL2 32x32 d512 | 160262 | 27869 | 27379 | 27399 | 27392 | 27438 | 27541 | 0.985 | 0.985 | 1.001 | 0.998 |
| IVF INT4 record InnerProduct d128 (us/query) | 383 | 309 | 404 | 316 | 196 | 191 | 192 | 0.619 | 0.638 | 0.605 | 0.617 |
| IVF INT4 record InnerProduct d512 (us/query) | 1378 | 852 | 1395 | 852 | 493 | 485 | 483 | 0.569 | 0.565 | 0.569 | 0.569 |
| IVF INT4 record SquaredEuclidean d128 (us/query) | 365 | 309 | 398 | 321 | 198 | 195 | 195 | 0.629 | 0.632 | 0.607 | 0.605 |
| IVF INT4 record SquaredEuclidean d512 (us/query) | 1305 | 850 | 1413 | 857 | 496 | 486 | 488 | 0.571 | 0.575 | 0.567 | 0.574 |

## Target C: protected paths (worst FINAL/7abc over both rounds)
- FP16 raw matrix: 84 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 0.987; worst: FP16/IP/1/1/128 r1 0.956 r2 1.042 (vs955 0.946/0.989), FP16/IP/8/2/128 r1 1.024 r2 1.002 (vs955 0.050/0.047), FP16/IP/32/32/512 r1 1.016 r2 0.995 (vs955 0.040/0.040)
- FP16 adapter: 4 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 1.006; worst: 1/MIPS/32/32/128 r1 1.006 r2 1.020 (vs955 0.172/0.170), 1/MIPS/32/1/512 r1 1.011 r2 1.011 (vs955 0.337/0.336), 1/MIPS/32/1/128 r1 0.999 r2 1.005 (vs955 0.371/0.368)
- FP16 IVF: 4 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 0.966; worst: 1/InnerProduct/128/0 r1 0.992 r2 0.953 (vs955 0.096/0.085), 1/SquaredEuclidean/128/0 r1 0.979 r2 0.961 (vs955 0.067/0.060), 1/SquaredEuclidean/512/0 r1 0.975 r2 0.944 (vs955 0.057/0.052)
- INT8 record adapter 32x1/32x32: 8 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 1.001; worst: 4/RecordL2/32/32/512 r1 1.025 r2 0.992 (vs955 0.218/0.207), 4/RecordIP/32/32/128 r1 1.019 r2 1.002 (vs955 0.448/0.436), 4/RecordL2/32/32/128 r1 1.012 r2 0.996 (vs955 0.387/0.375)
- FP32 MIPS adapter: 4 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 0.998; worst: 2/MIPS/32/32/128 r1 1.014 r2 0.999 (vs955 1.013/0.979), 2/MIPS/32/1/512 r1 0.998 r2 1.002 (vs955 0.622/0.622), 2/MIPS/32/32/512 r1 0.993 r2 0.998 (vs955 0.993/0.980)
- INT8 fused MIPS adapter: 4 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 1.000; worst: 4/MIPS/32/1/128 r1 1.009 r2 0.996 (vs955 1.010/0.985), 4/MIPS/32/32/512 r1 1.002 r2 0.998 (vs955 1.004/0.984), 4/MIPS/32/32/128 r1 1.001 r2 0.998 (vs955 1.000/0.981)
- INT8 single-column raw matrix: 24 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 1.000; worst: INT8/L2/2/1/128 r1 1.027 r2 1.027 (vs955 1.070/1.076), INT8/IP/1/1/128 r1 1.017 r2 0.999 (vs955 1.015/0.984), INT8/L2/2/1/512 r1 1.009 r2 1.006 (vs955 1.025/1.022)
- INT8 raw matrix (all): 84 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 1.000; worst: INT8/L2/4/4/128 r1 1.048 r2 1.016 (vs955 0.996/1.000), INT8/IP/2/2/128 r1 1.007 r2 1.031 (vs955 0.984/1.009), INT8/L2/2/1/128 r1 1.027 r2 1.027 (vs955 1.070/1.076)
- INT4 raw matrix (all): 84 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 0.875; worst: INT4/IP/4/2/512 r1 1.000 r2 1.048 (vs955 0.999/1.049), INT4/L2/1/1/128 r1 1.016 r2 1.016 (vs955 1.017/1.019), INT4/L2/4/2/128 r1 1.011 r2 0.999 (vs955 1.011/1.003)
- FP32 raw matrix: 84 cases, >5% vs 7abc in both rounds: 2, median FINAL/7abc 1.000; worst: FP32/L2/1/1/128 r1 1.062 r2 1.079 (vs955 1.073/1.075), FP32/L2/1/1/512 r1 1.058 r2 1.059 (vs955 1.023/1.024), FP32/IP/4/4/128 r1 1.003 r2 1.016 (vs955 0.998/0.999)
- FP64/INT16 raw matrix (inherited list): 168 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 1.001; worst: INT16/IP/1/1/512 r1 1.032 r2 0.999 (vs955 1.026/1.000), FP64/IP/1/1/512 r1 1.023 r2 1.016 (vs955 1.016/1.006), INT16/IP/16/1/512 r1 0.996 r2 1.021 (vs955 0.984/0.995)
- legacy IVF (all 24): 24 cases, >5% vs 7abc in both rounds: 0, median FINAL/7abc 0.997; worst: 4/InnerProduct/512/0 r1 0.993 r2 1.026 (vs955 0.978/0.948), 2/InnerProduct/512/0 r1 0.994 r2 1.018 (vs955 0.995/0.994), 2/SquaredEuclidean/128/0 r1 1.004 r2 1.018 (vs955 1.011/0.911)

