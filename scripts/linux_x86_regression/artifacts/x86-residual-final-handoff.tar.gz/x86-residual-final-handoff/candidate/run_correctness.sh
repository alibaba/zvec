#!/bin/bash
set -x
source /tmp/zvec_residual_env.sh
cd $FINAL
python3 $BUNDLE/run.py build --root $FINAL --deps $DEPS --jobs 12 > $FINAL/build2.log 2>&1
echo "build exit=$?"
python3 $BUNDLE/run.py correctness --root $FINAL --deps $DEPS > $FINAL/correctness_run.log 2>&1
echo "correctness exit=$?"
mkdir -p $FINAL/runtime/manual_fixed_read_parent && cd $FINAL/runtime/manual_fixed_read_parent
env -u GTEST_FILTER -u GTEST_OUTPUT ZVEC_LEGACY_READ_FIXTURES=$FINAL/parent-fixtures strace -f -e trace=openat -o $FINAL/results/manual_fixed_read_parent.strace $FINAL/build-fixed/bin/legacy_ivf_comparison --gtest_output=xml:$FINAL/results/manual_fixed_read_parent.xml > $FINAL/results/manual_fixed_read_parent.log 2>&1
echo $? > $FINAL/results/manual_fixed_read_parent.exit
grep -o '"[^"]*parent-fixtures/[^"]*\.index"' $FINAL/results/manual_fixed_read_parent.strace | sort -u | tr -d '"' > $FINAL/results/manual_fixed_read_parent.opened_index_paths.txt
echo "manual exit=$(cat $FINAL/results/manual_fixed_read_parent.exit)"
