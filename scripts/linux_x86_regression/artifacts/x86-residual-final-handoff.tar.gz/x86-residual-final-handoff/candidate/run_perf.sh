#!/bin/bash
source /tmp/zvec_residual_env.sh
# round 1: OLDER and REF already measured (results/); FINAL now
python3 $BUNDLE/run.py perf --root $FINAL --deps $DEPS --cpu $CPU > $FINAL/perf_round1.log 2>&1
echo "round1 FINAL exit=$?"
python3 $BUNDLE/compare_followup.py --baseline $REF/results --candidate $FINAL/results --output $FINAL/vs_7abc_round1
python3 $BUNDLE/compare_followup.py --baseline $OLDER/results --candidate $FINAL/results --output $FINAL/vs_955_round1
for R in $OLDER $REF $FINAL; do mv $R/results $R/results_round1; done
# round 2: FINAL, REF, OLDER
for R in $FINAL $REF $OLDER; do python3 $BUNDLE/run.py perf --root $R --deps $DEPS --cpu $CPU > $R/perf_round2.log 2>&1; echo "round2 $R exit=$?"; done
python3 $BUNDLE/compare_followup.py --baseline $REF/results --candidate $FINAL/results --output $FINAL/vs_7abc_round2
python3 $BUNDLE/compare_followup.py --baseline $OLDER/results --candidate $FINAL/results --output $FINAL/vs_955_round2
echo ALLDONE
