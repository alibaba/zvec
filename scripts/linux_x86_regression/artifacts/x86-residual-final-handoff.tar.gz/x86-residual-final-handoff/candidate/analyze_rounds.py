#!/usr/bin/env python3
"""Summarize FINAL vs 955/7abc/9819c706 over two perf rounds (targets A-D)."""
import csv
import json
import os
import pathlib
import statistics
import sys

FINAL = pathlib.Path(os.environ['FINAL'])
RUN = pathlib.Path(os.environ['RUN'])
OUT = FINAL / 'analysis'
OUT.mkdir(exist_ok=True)

MATRIX_KEYS = ['type', 'metric', 'rows', 'columns', 'dim']
ADAPTER_KEYS = ['type', 'metric', 'rows', 'columns', 'dim']
IVF_KEYS = ['type', 'metric', 'dim', 'record']
KEYS = {'matrix': MATRIX_KEYS, 'adapter': ADAPTER_KEYS, 'ivf': IVF_KEYS}

# The 13 integer raw-matrix items from the 7abc63fe report (>5% vs 955ae841).
ITEMS_13 = [
    ('INT4', 'IP', '16', '2', '128'), ('INT4', 'IP', '16', '2', '512'),
    ('INT4', 'IP', '32', '32', '128'), ('INT4', 'IP', '32', '32', '512'),
    ('INT4', 'L2', '32', '1', '128'), ('INT4', 'L2', '32', '1', '512'),
    ('INT4', 'L2', '32', '16', '128'), ('INT4', 'L2', '32', '16', '512'),
    ('INT4', 'L2', '32', '2', '128'), ('INT4', 'L2', '32', '2', '512'),
    ('INT4', 'L2', '8', '8', '128'), ('INT4', 'L2', '8', '8', '512'),
    ('INT8', 'L2', '2', '2', '128'),
]


def load(path, keys):
    with open(path) as stream:
        return {tuple(r[k] for k in keys): r for r in csv.DictReader(stream)}


def sort_key(k):
    return tuple(int(x) if x.isdigit() else x for x in k)


rounds = {}
for rnd in (1, 2):
    rounds[rnd] = {}
    for group in ('matrix', 'adapter', 'ivf'):
        v955 = load(FINAL / f'vs_955_round{rnd}' / f'{group}_four_versions.csv', KEYS[group])
        v7abc = load(FINAL / f'vs_7abc_round{rnd}' / f'{group}_four_versions.csv', KEYS[group])
        rounds[rnd][group] = (v955, v7abc)

# 9819c706 (RUN) round-1 values for the five-version table.
run_vals = {g: load(RUN / 'results_round1' / f'{g}_comparison.csv', KEYS[g])
            if (RUN / 'results_round1').exists() else load(RUN / 'results' / f'{g}_comparison.csv', KEYS[g])
            for g in ('matrix', 'adapter', 'ivf')}

lines = []


def p(s=''):
    lines.append(s)
    print(s)


def ratio(a, b):
    return float(a) / float(b)


def both_rounds_over(group, thresh=1.05):
    """Items >thresh vs previous_fix in both rounds, for 955 and 7abc baselines."""
    out = {}
    for base in ('955', '7abc'):
        idx = 0 if base == '955' else 1
        r1 = rounds[1][group][idx]
        r2 = rounds[2][group][idx]
        both = []
        for k in r1:
            a = float(r1[k]['vs_previous_fix'])
            b = float(r2[k]['vs_previous_fix'])
            if a > thresh and b > thresh:
                both.append((k, a, b))
        out[base] = sorted(both, key=lambda t: sort_key(t[0]))
    return out


summary = {}
p('# FINAL two-round summary (candidate = FINAL)')
p()
for group in ('matrix', 'adapter', 'ivf'):
    p(f'## {group}')
    for rnd in (1, 2):
        v955, v7abc = rounds[rnd][group]
        n955 = sum(1 for r in v955.values() if float(r['vs_previous_fix']) > 1.05)
        n7 = sum(1 for r in v7abc.values() if float(r['vs_previous_fix']) > 1.05)
        nb = sum(1 for r in v955.values() if float(r['vs_before']) > 1.05)
        npar = sum(1 for r in v955.values() if float(r['vs_parent']) > 1.05)
        med955 = statistics.median(float(r['vs_previous_fix']) for r in v955.values())
        med7 = statistics.median(float(r['vs_previous_fix']) for r in v7abc.values())
        p(f'- round{rnd}: >5% vs 955: {n955}, vs 7abc: {n7}, vs before: {nb}, vs parent: {npar}; '
          f'median FINAL/955 {med955:.3f}, FINAL/7abc {med7:.3f}')
        summary[f'{group}_round{rnd}'] = dict(over_955=n955, over_7abc=n7, over_before=nb,
                                              over_parent=npar, median_vs_955=med955, median_vs_7abc=med7)
    both = both_rounds_over(group)
    for base in ('955', '7abc'):
        p(f'- >5% vs {base} in BOTH rounds: {len(both[base])}')
        for k, a, b in both[base]:
            p(f'    {k}: r1 {a:.3f}, r2 {b:.3f}')
        summary[f'{group}_both_rounds_over_{base}'] = [list(k) + [a, b] for k, a, b in both[base]]
    p()

# Target A: 13 items
p('## Target A: 13 integer raw-matrix items')
p('| type | metric | shape | dim | 955 | 7abc | 9819 | FINAL r1 | FINAL r2 | FINAL/7abc r1 | r2 | FINAL/955 r1 | r2 | status |')
p('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
a_status = []
for k in ITEMS_13:
    r1_955, r1_7 = rounds[1]['matrix']
    r2_955, r2_7 = rounds[2]['matrix']
    f1 = float(r1_955[k]['candidate']); f2 = float(r2_955[k]['candidate'])
    o1 = float(r1_955[k]['previous_fix']); o2 = float(r2_955[k]['previous_fix'])
    s1 = float(r1_7[k]['previous_fix']); s2 = float(r2_7[k]['previous_fix'])
    v9 = float(run_vals['matrix'][k]['fixed'])
    beats_7abc = f1 < s1 and f2 < s2
    over_955 = (f1 / o1 > 1.05) and (f2 / o2 > 1.05)
    status = 'PASS' if beats_7abc and not over_955 else ('beats 7abc, >5% vs 955 both rounds' if beats_7abc else 'FAIL vs 7abc')
    a_status.append((k, status))
    p(f'| {k[0]} | {k[1]} | {k[2]}x{k[3]} | {k[4]} | {o1:.1f}/{o2:.1f} | {s1:.1f}/{s2:.1f} | {v9:.1f} | {f1:.1f} | {f2:.1f} | '
      f'{f1/s1:.3f} | {f2/s2:.3f} | {f1/o1:.3f} | {f2/o2:.3f} | {status} |')
summary['target_A'] = [list(k) + [s] for k, s in a_status]
p()

# Target B: INT4 record 32x1 (adapter type 6 RecordL2/RecordIP) and INT4 record IVF
p('## Target B: INT4 record quantized (adapter type 6) and legacy INT4 record IVF')
p('| case | parent | before | 955 | 7abc | 9819 | FINAL r1 | FINAL r2 | FINAL/before r1 | r2 | FINAL/7abc r1 | r2 |')
p('|---|---|---|---|---|---|---|---|---|---|---|---|')
b_rows = []
for k in sorted(rounds[1]['adapter'][0], key=sort_key):
    if k[0] != '6' or not k[1].startswith('Record'):
        continue
    r1_955, r1_7 = rounds[1]['adapter']; r2_955, r2_7 = rounds[2]['adapter']
    f1 = float(r1_955[k]['candidate']); f2 = float(r2_955[k]['candidate'])
    bf1 = float(r1_955[k]['before']); bf2 = float(r2_955[k]['before'])
    pa1 = float(r1_955[k]['parent'])
    o1 = float(r1_955[k]['previous_fix']); s1 = float(r1_7[k]['previous_fix']); s2 = float(r2_7[k]['previous_fix'])
    v9 = float(run_vals['adapter'][k]['fixed'])
    p(f'| INT4 {k[1]} {k[2]}x{k[3]} d{k[4]} | {pa1:.0f} | {bf1:.0f} | {o1:.0f} | {s1:.0f} | {v9:.0f} | {f1:.0f} | {f2:.0f} | '
      f'{f1/bf1:.3f} | {f2/bf2:.3f} | {f1/s1:.3f} | {f2/s2:.3f} |')
    b_rows.append(list(k) + [f1 / bf1, f2 / bf2, f1 / s1, f2 / s2])
for k in sorted(rounds[1]['ivf'][0], key=sort_key):
    if k[0] != '6' or k[3] != '1':
        continue
    r1_955, r1_7 = rounds[1]['ivf']; r2_955, r2_7 = rounds[2]['ivf']
    f1 = float(r1_955[k]['candidate']); f2 = float(r2_955[k]['candidate'])
    bf1 = float(r1_955[k]['before']); bf2 = float(r2_955[k]['before'])
    pa1 = float(r1_955[k]['parent'])
    o1 = float(r1_955[k]['previous_fix']); s1 = float(r1_7[k]['previous_fix']); s2 = float(r2_7[k]['previous_fix'])
    v9 = float(run_vals['ivf'][k]['fixed'])
    p(f'| IVF INT4 record {k[1]} d{k[2]} (us/query) | {pa1:.0f} | {bf1:.0f} | {o1:.0f} | {s1:.0f} | {v9:.0f} | {f1:.0f} | {f2:.0f} | '
      f'{f1/bf1:.3f} | {f2/bf2:.3f} | {f1/s1:.3f} | {f2/s2:.3f} |')
    b_rows.append(list(k) + [f1 / bf1, f2 / bf2, f1 / s1, f2 / s2])
summary['target_B'] = b_rows
p()

# Target C: protected paths
p('## Target C: protected paths (worst FINAL/7abc over both rounds)')


def worst(group, pred, label):
    r1_955, r1_7 = rounds[1][group]; r2_955, r2_7 = rounds[2][group]
    items = [k for k in r1_7 if pred(k)]
    vals = []
    for k in items:
        a = float(r1_7[k]['vs_previous_fix']); b = float(r2_7[k]['vs_previous_fix'])
        a9 = float(r1_955[k]['vs_previous_fix']); b9 = float(r2_955[k]['vs_previous_fix'])
        vals.append((max(a, b), min(a, b), k, a, b, a9, b9))
    vals.sort(reverse=True)
    n_both = sum(1 for v in vals if v[1] > 1.05)
    med = statistics.median([(v[3] + v[4]) / 2 for v in vals]) if vals else float('nan')
    p(f'- {label}: {len(items)} cases, >5% vs 7abc in both rounds: {n_both}, median FINAL/7abc {med:.3f}; worst: '
      + ', '.join(f'{"/".join(v[2])} r1 {v[3]:.3f} r2 {v[4]:.3f} (vs955 {v[5]:.3f}/{v[6]:.3f})' for v in vals[:3]))
    summary[f'target_C_{label}'] = dict(cases=len(items), both_over_7abc=n_both, median_vs_7abc=med,
                                        worst=[list(v[2]) + [v[3], v[4], v[5], v[6]] for v in vals[:5]])


worst('matrix', lambda k: k[0] == 'FP16', 'FP16 raw matrix')
worst('adapter', lambda k: k[0] == '1', 'FP16 adapter')
worst('ivf', lambda k: k[0] == '1', 'FP16 IVF')
worst('adapter', lambda k: k[0] == '4' and k[1].startswith('Record'), 'INT8 record adapter 32x1/32x32')
worst('adapter', lambda k: k[0] == '2' and k[1] == 'MIPS', 'FP32 MIPS adapter')
worst('adapter', lambda k: k[0] == '4' and k[1] == 'MIPS', 'INT8 fused MIPS adapter')
worst('matrix', lambda k: k[0] == 'INT8' and k[3] == '1', 'INT8 single-column raw matrix')
worst('matrix', lambda k: k[0] == 'INT8', 'INT8 raw matrix (all)')
worst('matrix', lambda k: k[0] == 'INT4', 'INT4 raw matrix (all)')
worst('matrix', lambda k: k[0] in ('FP32',), 'FP32 raw matrix')
worst('matrix', lambda k: k[0] in ('FP64', 'INT16'), 'FP64/INT16 raw matrix (inherited list)')
worst('ivf', lambda k: True, 'legacy IVF (all 24)')
p()

(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'summary.md').write_text('\n'.join(lines) + '\n')
