
build-fixed/bin/matrix_sweep:     file format elf64-x86-64


Disassembly of section .text:

0000000000039080 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]>:
   39080:	push   %r15
   39082:	mov    %rcx,%rax
   39085:	mov    %rcx,%r9
   39088:	push   %r14
   3908a:	push   %r13
   3908c:	push   %r12
   3908e:	push   %rbp
   3908f:	push   %rbx
   39090:	mov    %rdi,-0x20(%rsp)
   39095:	lea    0x8(%rcx),%rdi
   39099:	and    $0xfffffffffffffff8,%rdi
   3909d:	mov    %rsi,-0x18(%rsp)
   390a2:	mov    %rdx,%rsi
   390a5:	sub    %rdi,%rax
   390a8:	mov    %r8,-0x8(%rsp)
   390ad:	movq   $0x0,(%rcx)
   390b4:	movq   $0x0,0x78(%rcx)
   390bc:	mov    %rax,%rcx
   390bf:	xor    %eax,%eax
   390c1:	sub    $0xffffff80,%ecx
   390c4:	shr    $0x3,%ecx
   390c7:	rep stos %rax,%es:(%rdi)
   390ca:	cmp    $0x7,%rdx
   390ce:	jbe    39313 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x293>
   390d4:	mov    %rdx,-0x10(%rsp)
   390d9:	mov    $0x8,%r15d
   390df:	mov    %r8,%rcx
   390e2:	lea    -0x8(%r15),%r8
   390e6:	mov    -0x18(%rsp),%rdi
   390eb:	mov    %r15,-0x28(%rsp)
   390f0:	xor    %edx,%edx
   390f2:	shr    $1,%r8
   390f5:	mov    %r8,%rax
   390f8:	shl    $0x5,%r8
   390fc:	imul   %rcx,%rax
   39100:	mov    (%rdi,%rax,1),%eax
   39103:	mov    %rax,%r13
   39106:	mov    %eax,%r14d
   39109:	mov    %eax,%r12d
   3910c:	mov    %eax,%ebp
   3910e:	mov    %eax,%ebx
   39110:	mov    %eax,%r11d
   39113:	mov    %eax,%r10d
   39116:	shr    $0x1c,%eax
   39119:	shl    $0x4,%r13
   3911d:	mov    %eax,%edi
   3911f:	mov    -0x20(%rsp),%rax
   39124:	shr    $0x4,%r12d
   39128:	shr    $0x8,%ebp
   3912b:	shr    $0xc,%ebx
   3912e:	and    $0xf0,%r13d
   39135:	and    $0xf0,%r14d
   3913c:	shr    $0x10,%r11d
   39140:	and    $0xf0,%ebp
   39146:	shl    $0x4,%edi
   39149:	add    %rax,%r8
   3914c:	shr    $0x14,%r10d
   39150:	lea    0x19e2a9(%rip),%rax        # 1d7400 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table>
   39157:	and    $0xf0,%r12d
   3915e:	and    $0xf0,%ebx
   39164:	and    $0xf0,%r11d
   3916b:	add    %rax,%r14
   3916e:	add    %rax,%r13
   39171:	add    %rax,%r12
   39174:	and    $0xf0,%r10d
   3917b:	add    %rax,%rbp
   3917e:	add    %rax,%rbx
   39181:	add    %rax,%r11
   39184:	add    %rax,%r10
   39187:	add    %rax,%rdi
   3918a:	nopw   0x0(%rax,%rax,1)
   39190:	mov    (%r8,%rdx,4),%eax
   39194:	pxor   %xmm0,%xmm0
   39198:	mov    %eax,%esi
   3919a:	shr    $0x4,%esi
   3919d:	and    $0xf,%esi
   391a0:	movzbl (%r14,%rsi,1),%r15d
   391a5:	mov    %eax,%esi
   391a7:	and    $0xf,%esi
   391aa:	movzbl 0x0(%r13,%rsi,1),%esi
   391b0:	add    %esi,%r15d
   391b3:	mov    %eax,%esi
   391b5:	shr    $0x8,%esi
   391b8:	and    $0xf,%esi
   391bb:	movzbl (%r12,%rsi,1),%esi
   391c0:	add    %r15d,%esi
   391c3:	mov    %eax,%r15d
   391c6:	shr    $0xc,%r15d
   391ca:	and    $0xf,%r15d
   391ce:	movzbl 0x0(%rbp,%r15,1),%r15d
   391d4:	add    %esi,%r15d
   391d7:	mov    %eax,%esi
   391d9:	shr    $0x10,%esi
   391dc:	and    $0xf,%esi
   391df:	movzbl (%rbx,%rsi,1),%esi
   391e3:	add    %r15d,%esi
   391e6:	mov    %eax,%r15d
   391e9:	shr    $0x14,%r15d
   391ed:	and    $0xf,%r15d
   391f1:	movzbl (%r11,%r15,1),%r15d
   391f6:	add    %esi,%r15d
   391f9:	mov    %eax,%esi
   391fb:	shr    $0x1c,%eax
   391fe:	shr    $0x18,%esi
   39201:	movzbl (%rdi,%rax,1),%eax
   39205:	and    $0xf,%esi
   39208:	movzbl (%r10,%rsi,1),%esi
   3920d:	add    %r15d,%esi
   39210:	add    %esi,%eax
   39212:	cvtsi2ss %eax,%xmm0
   39216:	addss  (%r9,%rdx,4),%xmm0
   3921c:	movss  %xmm0,(%r9,%rdx,4)
   39222:	add    $0x1,%rdx
   39226:	cmp    $0x20,%rdx
   3922a:	jne    39190 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x110>
   39230:	mov    -0x28(%rsp),%r15
   39235:	lea    0x8(%r15),%rax
   39239:	cmp    %rax,-0x10(%rsp)
   3923e:	jb     39248 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x1c8>
   39240:	mov    %rax,%r15
   39243:	jmp    390e2 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x62>
   39248:	mov    -0x10(%rsp),%rsi
   3924d:	cmp    %rsi,%r15
   39250:	jae    392fe <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x27e>
   39256:	mov    -0x20(%rsp),%r8
   3925b:	mov    -0x18(%rsp),%r10
   39260:	mov    -0x8(%rsp),%r11
   39265:	mov    %r15,%rax
   39268:	mov    %r11,%rdi
   3926b:	mov    %r15,%rdx
   3926e:	mov    %r15,%rcx
   39271:	shr    $0x3,%rax
   39275:	shr    $1,%rdx
   39278:	and    $0x1,%ecx
   3927b:	imul   %rax,%rdi
   3927f:	and    $0x3,%edx
   39282:	shl    $0x2,%ecx
   39285:	lea    (%r10,%rdi,4),%rdi
   39289:	movzbl (%rdi,%rdx,1),%edi
   3928d:	sar    %cl,%edi
   3928f:	mov    %edi,%ebx
   39291:	and    $0xf,%ebx
   39294:	and    $0x8,%edi
   39297:	je     39309 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x289>
   39299:	sub    $0x10,%ebx
   3929c:	pxor   %xmm1,%xmm1
   392a0:	cvtsi2ss %ebx,%xmm1
   392a4:	shl    $0x7,%rax
   392a8:	lea    (%rax,%rdx,1),%rdi
   392ac:	xor    %eax,%eax
   392ae:	add    %r8,%rdi
   392b1:	nopl   0x0(%rax)
   392b8:	movzbl (%rdi,%rax,4),%edx
   392bc:	sar    %cl,%edx
   392be:	mov    %edx,%ebx
   392c0:	and    $0xf,%ebx
   392c3:	and    $0x8,%edx
   392c6:	je     392cb <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x24b>
   392c8:	sub    $0x10,%ebx
   392cb:	pxor   %xmm0,%xmm0
   392cf:	cvtsi2ss %ebx,%xmm0
   392d3:	subss  %xmm1,%xmm0
   392d7:	mulss  %xmm0,%xmm0
   392db:	addss  (%r9,%rax,4),%xmm0
   392e1:	movss  %xmm0,(%r9,%rax,4)
   392e7:	add    $0x1,%rax
   392eb:	cmp    $0x20,%rax
   392ef:	jne    392b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x238>
   392f1:	add    $0x1,%r15
   392f5:	cmp    %r15,%rsi
   392f8:	jne    39265 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x1e5>
   392fe:	pop    %rbx
   392ff:	pop    %rbp
   39300:	pop    %r12
   39302:	pop    %r13
   39304:	pop    %r14
   39306:	pop    %r15
   39308:	ret
   39309:	pxor   %xmm1,%xmm1
   3930d:	cvtsi2ss %ebx,%xmm1
   39311:	jmp    392a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x224>
   39313:	xor    %r15d,%r15d
   39316:	jmp    3924d <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .isra.0]+0x1cd>
