Residual two-round >5% matrix items (FINAL vs 955ae841 / 7abc63fe):
  FP32 L2 1x1 d128 (vs 955 1.073/1.075, vs 7abc 1.062/1.079), FP32 L2 1x1 d512 (vs 7abc 1.058/1.059, vs 955 1.023/1.024),
  INT8 L2 2x1 d128 (vs 955 1.070/1.076, vs 7abc 1.027/1.027).
Files: matrix_sweep wrapper kernel<T,Rows,Cols,IP> disassembly for OLDER(955)/REF(7abc)/FINAL with addresses normalized
(sed: strip addresses, RIP-relative displacements, symbol names). diff(FINAL,OLDER)=0 lines and diff(FINAL,REF)=0 lines for all three
kernels, i.e. byte-for-byte identical instruction streams (77 / 182 / 198 instructions); the final patch does not touch FP32 or
INT8 code paths. Differences are confined to absolute placement (function offsets differ between binaries).
fp32_l2_callees/: kernel<float,1,1,false> computes through an indirect call (get_distance_func dispatch) into the arch-specific
squared_euclidean_fp32_distance_{avx2,avx512,scalar}; these are also identical (normalized diff = 0) across OLDER/REF/FINAL.
Per-call cost is ~8 ns (d128); the 6-8% delta is ~0.5 ns, consistent with call-site/indirect-branch placement, not kernel logic.
