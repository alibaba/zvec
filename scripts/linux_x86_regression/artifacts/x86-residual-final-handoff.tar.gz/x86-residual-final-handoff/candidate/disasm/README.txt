FINAL candidate matrix_sweep (build-fixed/bin/matrix_sweep, sha256 in matrix_sweep.sha256)
- matrix_sweep_hot_symbols.txt: nm of ComputePackedColumns / ComputeSingleColumn instances (no GCC alignment attributes; 26 symbols, INT8 single-column inlined again as in 7abc).
- single32_int4_l2_final.asm: InterleavedDistanceMatrix<uint8_t,32,L2>::ComputeSingleColumn<false> (.isra clone). Row loop 0x39190-0x3922a: 39 insns / 8 table lookups; the 8 query table rows live in registers (r14,r13,r12,rbp,rbx,r11,r10,rdi) for the whole row loop. 955/7abc/9819c706 kernel: 53 insns / 8 lookups.
- packed16_rows32_int4_l2_final.asm: ComputePackedColumns<16> for Rows=32 (expanded-nibble kernel, Rows>=8 path).
- kernel_uchar_32_16_false_final.asm: matrix_sweep wrapper (Rows=32, Columns=16, L2).
- kernel_uchar_4_4_false_final.asm: Rows=4 Columns=4 keeps the legacy fully unrolled loop (Rows<=4 path).
