
build-fixed/bin/matrix_sweep:     file format elf64-x86-64


Disassembly of section .text:

00000000000e2af0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
   e2af0:	endbr64
   e2af4:	push   %r15
   e2af6:	mov    %rdx,%rax
   e2af9:	mov    %rcx,%rdx
   e2afc:	push   %r14
   e2afe:	shr    $1,%rax
   e2b01:	push   %r13
   e2b03:	shl    $0x4,%rax
   e2b07:	push   %r12
   e2b09:	lea    (%rsi,%rax,1),%r10
   e2b0d:	xor    %eax,%eax
   e2b0f:	push   %rbp
   e2b10:	push   %rbx
   e2b11:	sub    $0x8d8,%rsp
   e2b18:	mov    %rdi,0x10(%rsp)
   e2b1d:	lea    0x40(%rsp),%r8
   e2b22:	mov    %r8,%rdi
   e2b25:	mov    %fs:0x28,%rcx
   e2b2e:	mov    %rcx,0x8c8(%rsp)
   e2b36:	xor    %ecx,%ecx
   e2b38:	mov    $0x100,%ecx
   e2b3d:	rep stos %rax,%es:(%rdi)
   e2b40:	cmp    %r10,%rsi
   e2b43:	je     e2daf <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2bf>
   e2b49:	lea    0x840(%rsp),%rcx
   e2b51:	mov    %rdx,0x20(%rsp)
   e2b56:	movdqa 0xf5252(%rip),%xmm1        # 1d7db0 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x1b0>
   e2b5e:	lea    0x8c0(%rsp),%r13
   e2b66:	mov    %rcx,0x18(%rsp)
   e2b6b:	lea    0xf488e(%rip),%r15        # 1d7400 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table>
   e2b72:	mov    %rsi,%rax
   e2b75:	mov    %r8,%rdx
   e2b78:	movdqu (%rax),%xmm0
   e2b7c:	movdqu (%rax),%xmm2
   e2b80:	mov    %r10,0x28(%rsp)
   e2b85:	mov    %rdx,%rsi
   e2b88:	mov    %rax,0x30(%rsp)
   e2b8d:	xor    %r14d,%r14d
   e2b90:	psrld  $0x4,%xmm0
   e2b95:	pand   %xmm1,%xmm2
   e2b99:	mov    %rdx,0x38(%rsp)
   e2b9e:	pand   %xmm1,%xmm0
   e2ba2:	movdqa %xmm2,%xmm3
   e2ba6:	punpckhdq %xmm0,%xmm2
   e2baa:	punpckldq %xmm0,%xmm3
   e2bae:	movdqu 0x10(%rax),%xmm0
   e2bb3:	movaps %xmm2,0x850(%rsp)
   e2bbb:	movdqu 0x10(%rax),%xmm2
   e2bc0:	psrld  $0x4,%xmm0
   e2bc5:	movaps %xmm3,0x840(%rsp)
   e2bcd:	pand   %xmm1,%xmm2
   e2bd1:	pand   %xmm1,%xmm0
   e2bd5:	movdqa %xmm2,%xmm3
   e2bd9:	punpckhdq %xmm0,%xmm2
   e2bdd:	punpckldq %xmm0,%xmm3
   e2be1:	movdqu 0x20(%rax),%xmm0
   e2be6:	movaps %xmm2,0x870(%rsp)
   e2bee:	movdqu 0x20(%rax),%xmm2
   e2bf3:	movaps %xmm3,0x860(%rsp)
   e2bfb:	psrld  $0x4,%xmm0
   e2c00:	pand   %xmm1,%xmm2
   e2c04:	pand   %xmm1,%xmm0
   e2c08:	movdqa %xmm2,%xmm3
   e2c0c:	punpckhdq %xmm0,%xmm2
   e2c10:	punpckldq %xmm0,%xmm3
   e2c14:	movdqu 0x30(%rax),%xmm0
   e2c19:	movaps %xmm2,0x890(%rsp)
   e2c21:	movdqu 0x30(%rax),%xmm2
   e2c26:	psrld  $0x4,%xmm0
   e2c2b:	movaps %xmm3,0x880(%rsp)
   e2c33:	pand   %xmm1,%xmm2
   e2c37:	pand   %xmm1,%xmm0
   e2c3b:	movdqa %xmm2,%xmm3
   e2c3f:	punpckhdq %xmm0,%xmm2
   e2c43:	punpckldq %xmm0,%xmm3
   e2c47:	movaps %xmm2,0x8b0(%rsp)
   e2c4f:	movaps %xmm3,0x8a0(%rsp)
   e2c57:	mov    0x10(%rsp),%rax
   e2c5c:	mov    %r14,0x8(%rsp)
   e2c61:	mov    %rsi,%rdx
   e2c64:	mov    (%rax,%r14,4),%eax
   e2c68:	mov    %rax,%rbp
   e2c6b:	mov    %eax,%r12d
   e2c6e:	mov    %eax,%ebx
   e2c70:	mov    %eax,%r9d
   e2c73:	mov    %eax,%r11d
   e2c76:	mov    %eax,%r8d
   e2c79:	mov    %eax,%r10d
   e2c7c:	shr    $0x1c,%eax
   e2c7f:	shl    $0x4,%eax
   e2c82:	shl    $0x4,%rbp
   e2c86:	and    $0xf0,%r12d
   e2c8d:	shr    $0x4,%ebx
   e2c90:	shr    $0x8,%r9d
   e2c94:	mov    %eax,%edi
   e2c96:	and    $0xf0,%ebp
   e2c9c:	shr    $0xc,%r11d
   e2ca0:	shr    $0x10,%r8d
   e2ca4:	mov    0x18(%rsp),%rax
   e2ca9:	add    %r15,%rbp
   e2cac:	shr    $0x14,%r10d
   e2cb0:	and    $0xf0,%ebx
   e2cb6:	add    %r15,%r12
   e2cb9:	add    %r15,%rdi
   e2cbc:	and    $0xf0,%r9d
   e2cc3:	and    $0xf0,%r11d
   e2cca:	add    %r15,%rbx
   e2ccd:	and    $0xf0,%r8d
   e2cd4:	and    $0xf0,%r10d
   e2cdb:	add    %r15,%r11
   e2cde:	add    %r15,%r9
   e2ce1:	add    %r15,%r8
   e2ce4:	add    %r15,%r10
   e2ce7:	nopw   0x0(%rax,%rax,1)
   e2cf0:	movzbl (%rax),%ecx
   e2cf3:	movzbl 0x1(%rax),%r14d
   e2cf8:	pxor   %xmm0,%xmm0
   e2cfc:	add    $0x8,%rax
   e2d00:	sub    $0xffffffffffffff80,%rdx
   e2d04:	movzbl (%rbx,%r14,1),%r14d
   e2d09:	movzbl 0x0(%rbp,%rcx,1),%ecx
   e2d0e:	add    %r14d,%ecx
   e2d11:	movzbl -0x6(%rax),%r14d
   e2d16:	movzbl (%r11,%r14,1),%r14d
   e2d1b:	add    %ecx,%r14d
   e2d1e:	movzbl -0x5(%rax),%ecx
   e2d22:	movzbl (%r10,%rcx,1),%ecx
   e2d27:	add    %r14d,%ecx
   e2d2a:	movzbl -0x4(%rax),%r14d
   e2d2f:	movzbl (%r12,%r14,1),%r14d
   e2d34:	add    %ecx,%r14d
   e2d37:	movzbl -0x3(%rax),%ecx
   e2d3b:	movzbl (%r9,%rcx,1),%ecx
   e2d40:	add    %r14d,%ecx
   e2d43:	movzbl -0x2(%rax),%r14d
   e2d48:	movzbl (%r8,%r14,1),%r14d
   e2d4d:	add    %ecx,%r14d
   e2d50:	movzbl -0x1(%rax),%ecx
   e2d54:	movzbl (%rdi,%rcx,1),%ecx
   e2d58:	add    %r14d,%ecx
   e2d5b:	cvtsi2ss %ecx,%xmm0
   e2d5f:	addss  -0x80(%rdx),%xmm0
   e2d64:	movss  %xmm0,-0x80(%rdx)
   e2d69:	cmp    %r13,%rax
   e2d6c:	jne    e2cf0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x200>
   e2d6e:	mov    0x8(%rsp),%r14
   e2d73:	add    $0x4,%rsi
   e2d77:	add    $0x1,%r14
   e2d7b:	cmp    $0x20,%r14
   e2d7f:	jne    e2c57 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x167>
   e2d85:	mov    0x30(%rsp),%rax
   e2d8a:	mov    0x28(%rsp),%r10
   e2d8f:	subq   $0xffffffffffffff80,0x10(%rsp)
   e2d95:	mov    0x38(%rsp),%rdx
   e2d9a:	add    $0x40,%rax
   e2d9e:	cmp    %rax,%r10
   e2da1:	jne    e2b78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x88>
   e2da7:	mov    %rdx,%r8
   e2daa:	mov    0x20(%rsp),%rdx
   e2daf:	mov    0x40(%rsp),%rax
   e2db4:	lea    0x8(%rdx),%rdi
   e2db8:	mov    %r8,%rsi
   e2dbb:	and    $0xfffffffffffffff8,%rdi
   e2dbf:	mov    %rax,(%rdx)
   e2dc2:	mov    0x838(%rsp),%rax
   e2dca:	mov    %rax,0x7f8(%rdx)
   e2dd1:	sub    %rdi,%rdx
   e2dd4:	sub    %rdx,%rsi
   e2dd7:	add    $0x800,%edx
   e2ddd:	shr    $0x3,%edx
   e2de0:	mov    %edx,%ecx
   e2de2:	rep movsq %ds:(%rsi),%es:(%rdi)
   e2de5:	mov    0x8c8(%rsp),%rax
   e2ded:	sub    %fs:0x28,%rax
   e2df6:	jne    e2e0a <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x31a>
   e2df8:	add    $0x8d8,%rsp
   e2dff:	pop    %rbx
   e2e00:	pop    %rbp
   e2e01:	pop    %r12
   e2e03:	pop    %r13
   e2e05:	pop    %r14
   e2e07:	pop    %r15
   e2e09:	ret
   e2e0a:	call   30b60 <__stack_chk_fail@plt>
