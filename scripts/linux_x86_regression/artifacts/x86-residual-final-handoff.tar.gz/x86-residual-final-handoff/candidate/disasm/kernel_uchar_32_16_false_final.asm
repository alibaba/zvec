
build-fixed/bin/matrix_sweep:     file format elf64-x86-64


Disassembly of section .text:

00000000000e2e10 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
   e2e10:	endbr64
   e2e14:	push   %r15
   e2e16:	push   %r14
   e2e18:	mov    %rdx,%r14
   e2e1b:	push   %r13
   e2e1d:	push   %r12
   e2e1f:	push   %rbp
   e2e20:	push   %rbx
   e2e21:	test   %rdx,%rdx
   e2e24:	je     e30d8 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
   e2e2a:	mov    %rdi,%rbp
   e2e2d:	test   $0x7,%dl
   e2e30:	je     e310f <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ff>
   e2e36:	mov    %rsi,%r15
   e2e39:	mov    %rcx,%r13
   e2e3c:	lea    0x800(%rcx),%r12
   e2e43:	lea    0xf45b6(%rip),%rsi        # 1d7400 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table>
   e2e4a:	lea    0x8(%r13),%rdi
   e2e4e:	mov    %r13,%rcx
   e2e51:	xor    %eax,%eax
   e2e53:	movq   $0x0,0x0(%r13)
   e2e5b:	and    $0xfffffffffffffff8,%rdi
   e2e5f:	movq   $0x0,0x78(%r13)
   e2e67:	sub    %rdi,%rcx
   e2e6a:	sub    $0xffffff80,%ecx
   e2e6d:	shr    $0x3,%ecx
   e2e70:	rep stos %rax,%es:(%rdi)
   e2e73:	cmp    $0x7,%r14
   e2e77:	jbe    e30d1 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c1>
   e2e7d:	mov    %r12,-0x10(%rsp)
   e2e82:	mov    $0x8,%edx
   e2e87:	lea    -0x8(%rdx),%rbx
   e2e8b:	shr    $1,%rbx
   e2e8e:	mov    %rbx,%rax
   e2e91:	shl    $0x5,%rbx
   e2e95:	shl    $0x4,%rax
   e2e99:	add    %rbp,%rbx
   e2e9c:	mov    (%r15,%rax,1),%eax
   e2ea0:	mov    %rbx,-0x38(%rsp)
   e2ea5:	xor    %ebx,%ebx
   e2ea7:	mov    %eax,%edi
   e2ea9:	mov    %eax,%ecx
   e2eab:	mov    %rax,%r11
   e2eae:	mov    %eax,%r12d
   e2eb1:	shr    $0x10,%edi
   e2eb4:	mov    %eax,%r10d
   e2eb7:	mov    %eax,%r9d
   e2eba:	mov    %eax,%r8d
   e2ebd:	and    $0xf0,%edi
   e2ec3:	shr    $0x14,%ecx
   e2ec6:	and    $0xf0,%r12d
   e2ecd:	shr    $0x1c,%eax
   e2ed0:	add    %rsi,%rdi
   e2ed3:	and    $0xf0,%ecx
   e2ed9:	shl    $0x4,%r11
   e2edd:	shl    $0x4,%eax
   e2ee0:	mov    %rdi,-0x30(%rsp)
   e2ee5:	lea    (%rsi,%rcx,1),%rdi
   e2ee9:	shr    $0x4,%r10d
   e2eed:	add    %rsi,%rax
   e2ef0:	shr    $0x8,%r9d
   e2ef4:	mov    %rdi,-0x28(%rsp)
   e2ef9:	add    %rsi,%r12
   e2efc:	shr    $0xc,%r8d
   e2f00:	mov    %rax,-0x20(%rsp)
   e2f05:	and    $0xf0,%r11d
   e2f0c:	and    $0xf0,%r10d
   e2f13:	and    $0xf0,%r9d
   e2f1a:	and    $0xf0,%r8d
   e2f21:	add    %rsi,%r11
   e2f24:	add    %rsi,%r10
   e2f27:	add    %rsi,%r9
   e2f2a:	add    %rsi,%r8
   e2f2d:	nopl   (%rax)
   e2f30:	mov    -0x38(%rsp),%rax
   e2f35:	pxor   %xmm0,%xmm0
   e2f39:	mov    (%rax,%rbx,4),%eax
   e2f3c:	mov    %eax,%ecx
   e2f3e:	shr    $0x4,%ecx
   e2f41:	and    $0xf,%ecx
   e2f44:	movzbl (%r12,%rcx,1),%edi
   e2f49:	mov    %eax,%ecx
   e2f4b:	and    $0xf,%ecx
   e2f4e:	movzbl (%r11,%rcx,1),%ecx
   e2f53:	add    %ecx,%edi
   e2f55:	mov    %eax,%ecx
   e2f57:	shr    $0x8,%ecx
   e2f5a:	and    $0xf,%ecx
   e2f5d:	movzbl (%r10,%rcx,1),%ecx
   e2f62:	add    %edi,%ecx
   e2f64:	mov    %eax,%edi
   e2f66:	shr    $0xc,%edi
   e2f69:	and    $0xf,%edi
   e2f6c:	movzbl (%r9,%rdi,1),%edi
   e2f71:	add    %ecx,%edi
   e2f73:	mov    %eax,%ecx
   e2f75:	shr    $0x10,%ecx
   e2f78:	and    $0xf,%ecx
   e2f7b:	movzbl (%r8,%rcx,1),%ecx
   e2f80:	add    %ecx,%edi
   e2f82:	mov    -0x30(%rsp),%rcx
   e2f87:	mov    %edi,-0x14(%rsp)
   e2f8b:	mov    %eax,%edi
   e2f8d:	shr    $0x14,%edi
   e2f90:	and    $0xf,%edi
   e2f93:	movzbl (%rcx,%rdi,1),%edi
   e2f97:	mov    -0x14(%rsp),%ecx
   e2f9b:	add    %edi,%ecx
   e2f9d:	mov    -0x28(%rsp),%rdi
   e2fa2:	mov    %ecx,-0x14(%rsp)
   e2fa6:	mov    %eax,%ecx
   e2fa8:	shr    $0x1c,%eax
   e2fab:	shr    $0x18,%ecx
   e2fae:	and    $0xf,%ecx
   e2fb1:	movzbl (%rdi,%rcx,1),%ecx
   e2fb5:	mov    -0x14(%rsp),%edi
   e2fb9:	add    %edi,%ecx
   e2fbb:	mov    -0x20(%rsp),%rdi
   e2fc0:	movzbl (%rdi,%rax,1),%eax
   e2fc4:	add    %ecx,%eax
   e2fc6:	cvtsi2ss %eax,%xmm0
   e2fca:	addss  0x0(%r13,%rbx,4),%xmm0
   e2fd1:	movss  %xmm0,0x0(%r13,%rbx,4)
   e2fd8:	add    $0x1,%rbx
   e2fdc:	cmp    $0x20,%rbx
   e2fe0:	jne    e2f30 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x120>
   e2fe6:	lea    0x8(%rdx),%rax
   e2fea:	cmp    %rax,%r14
   e2fed:	jb     e2ff7 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e7>
   e2fef:	mov    %rax,%rdx
   e2ff2:	jmp    e2e87 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x77>
   e2ff7:	mov    -0x10(%rsp),%r12
   e2ffc:	cmp    %r14,%rdx
   e2fff:	jae    e30a7 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x297>
   e3005:	mov    %rdx,%rax
   e3008:	mov    %rdx,%rdi
   e300b:	mov    %rdx,%rcx
   e300e:	shr    $0x3,%rax
   e3012:	shr    $1,%rdi
   e3015:	and    $0x1,%ecx
   e3018:	shl    $0x6,%rax
   e301c:	and    $0x3,%edi
   e301f:	shl    $0x2,%ecx
   e3022:	add    %rax,%rdi
   e3025:	movzbl (%r15,%rdi,1),%r8d
   e302a:	sar    %cl,%r8d
   e302d:	mov    %r8d,%r9d
   e3030:	and    $0xf,%r9d
   e3034:	and    $0x8,%r8d
   e3038:	je     e30c3 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b3>
   e303e:	sub    $0x10,%r9d
   e3042:	pxor   %xmm1,%xmm1
   e3046:	cvtsi2ss %r9d,%xmm1
   e304b:	add    %rdi,%rax
   e304e:	lea    0x0(%rbp,%rax,1),%rdi
   e3053:	xor    %eax,%eax
   e3055:	nopl   (%rax)
   e3058:	movzbl (%rdi,%rax,4),%r8d
   e305d:	sar    %cl,%r8d
   e3060:	mov    %r8d,%r9d
   e3063:	and    $0xf,%r9d
   e3067:	and    $0x8,%r8d
   e306b:	je     e3071 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x261>
   e306d:	sub    $0x10,%r9d
   e3071:	pxor   %xmm0,%xmm0
   e3075:	cvtsi2ss %r9d,%xmm0
   e307a:	subss  %xmm1,%xmm0
   e307e:	mulss  %xmm0,%xmm0
   e3082:	addss  0x0(%r13,%rax,4),%xmm0
   e3089:	movss  %xmm0,0x0(%r13,%rax,4)
   e3090:	add    $0x1,%rax
   e3094:	cmp    $0x20,%rax
   e3098:	jne    e3058 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x248>
   e309a:	add    $0x1,%rdx
   e309e:	cmp    %rdx,%r14
   e30a1:	jne    e3005 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1f5>
   e30a7:	sub    $0xffffffffffffff80,%r13
   e30ab:	add    $0x4,%r15
   e30af:	cmp    %r12,%r13
   e30b2:	jne    e2e4a <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a>
   e30b8:	pop    %rbx
   e30b9:	pop    %rbp
   e30ba:	pop    %r12
   e30bc:	pop    %r13
   e30be:	pop    %r14
   e30c0:	pop    %r15
   e30c2:	ret
   e30c3:	pxor   %xmm1,%xmm1
   e30c7:	cvtsi2ss %r9d,%xmm1
   e30cc:	jmp    e304b <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x23b>
   e30d1:	xor    %edx,%edx
   e30d3:	jmp    e3005 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1f5>
   e30d8:	lea    0x8(%rcx),%rdi
   e30dc:	movq   $0x0,(%rcx)
   e30e3:	mov    %rdx,%rax
   e30e6:	movq   $0x0,0x7f8(%rcx)
   e30f1:	and    $0xfffffffffffffff8,%rdi
   e30f5:	sub    %rdi,%rcx
   e30f8:	add    $0x800,%ecx
   e30fe:	shr    $0x3,%ecx
   e3101:	rep stos %rax,%es:(%rdi)
   e3104:	pop    %rbx
   e3105:	pop    %rbp
   e3106:	pop    %r12
   e3108:	pop    %r13
   e310a:	pop    %r14
   e310c:	pop    %r15
   e310e:	ret
   e310f:	pop    %rbx
   e3110:	pop    %rbp
   e3111:	pop    %r12
   e3113:	pop    %r13
   e3115:	pop    %r14
   e3117:	pop    %r15
   e3119:	jmp    e2af0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>
