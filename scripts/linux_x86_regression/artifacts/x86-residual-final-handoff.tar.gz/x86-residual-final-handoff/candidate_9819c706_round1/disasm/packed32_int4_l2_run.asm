
/home/xingrui/workspace/zvec/ivf_matrix/zvec-residual-new.en2dYQ/build-fixed/bin/matrix_sweep:     file format elf64-x86-64


Disassembly of section .text:

00000000000e4480 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
   e4480:	endbr64
   e4484:	push   %r15
   e4486:	push   %r14
   e4488:	push   %r13
   e448a:	push   %r12
   e448c:	push   %rbp
   e448d:	push   %rbx
   e448e:	sub    $0x1000,%rsp
   e4495:	orq    $0x0,(%rsp)
   e449a:	sub    $0x58,%rsp
   e449e:	mov    %rdi,0x18(%rsp)
   e44a3:	mov    %rdx,%rax
   e44a6:	lea    0x40(%rsp),%r13
   e44ab:	mov    %rcx,%rdx
   e44ae:	shr    $1,%rax
   e44b1:	mov    %r13,%rdi
   e44b4:	shl    $0x5,%rax
   e44b8:	mov    %fs:0x28,%rcx
   e44c1:	mov    %rcx,0x1048(%rsp)
   e44c9:	xor    %ecx,%ecx
   e44cb:	lea    (%rsi,%rax,1),%r8
   e44cf:	mov    $0x200,%ecx
   e44d4:	xor    %eax,%eax
   e44d6:	rep stos %rax,%es:(%rdi)
   e44d9:	cmp    %r8,%rsi
   e44dc:	je     e46ae <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22e>
   e44e2:	mov    %rsi,0x8(%rsp)
   e44e7:	lea    0xf2ef2(%rip),%r15        # 1d73e0 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table>
   e44ee:	mov    %r8,%rdi
   e44f1:	lea    0x1040(%rsp),%rax
   e44f9:	mov    %rdx,0x20(%rsp)
   e44fe:	mov    %r13,0x28(%rsp)
   e4503:	mov    %rdi,0x30(%rsp)
   e4508:	mov    %rax,%r13
   e450b:	xor    %esi,%esi
   e450d:	mov    %rax,0x38(%rsp)
   e4512:	mov    0x18(%rsp),%rax
   e4517:	mov    %rsi,0x10(%rsp)
   e451c:	lea    -0x1000(%r13),%rcx
   e4523:	mov    0x8(%rsp),%rdi
   e4528:	mov    (%rax,%rsi,4),%r8d
   e452c:	mov    %r8d,%r12d
   e452f:	mov    %r8d,%ebp
   e4532:	mov    %r8d,%ebx
   e4535:	mov    %r8d,%r11d
   e4538:	mov    %r8d,%r10d
   e453b:	mov    %r8d,%r9d
   e453e:	mov    %r8d,%r14d
   e4541:	and    $0xf,%r12d
   e4545:	shr    $0x4,%ebp
   e4548:	shr    $0x8,%ebx
   e454b:	and    $0xf0,%r14d
   e4552:	shr    $0xc,%r11d
   e4556:	shr    $0x10,%r10d
   e455a:	and    $0xf0,%ebp
   e4560:	and    $0xf0,%ebx
   e4566:	shr    $0x14,%r9d
   e456a:	shr    $0x1c,%r8d
   e456e:	and    $0xf0,%r11d
   e4575:	and    $0xf0,%r10d
   e457c:	shl    $0x4,%r12d
   e4580:	and    $0xf0,%r9d
   e4587:	shl    $0x4,%r8d
   e458b:	data16 cs nopw 0x0(%rax,%rax,1)
   e4596:	data16 cs nopw 0x0(%rax,%rax,1)
   e45a1:	data16 cs nopw 0x0(%rax,%rax,1)
   e45ac:	data16 cs nopw 0x0(%rax,%rax,1)
   e45b7:	nopw   0x0(%rax,%rax,1)
   e45c0:	mov    (%rdi),%eax
   e45c2:	pxor   %xmm0,%xmm0
   e45c6:	sub    $0xffffffffffffff80,%rcx
   e45ca:	add    $0x4,%rdi
   e45ce:	mov    %eax,%edx
   e45d0:	shr    $0x4,%edx
   e45d3:	and    $0xf,%edx
   e45d6:	add    %r14d,%edx
   e45d9:	movzbl (%r15,%rdx,1),%esi
   e45de:	mov    %eax,%edx
   e45e0:	and    $0xf,%edx
   e45e3:	add    %r12d,%edx
   e45e6:	movzbl (%r15,%rdx,1),%edx
   e45eb:	add    %edx,%esi
   e45ed:	mov    %eax,%edx
   e45ef:	shr    $0x8,%edx
   e45f2:	and    $0xf,%edx
   e45f5:	add    %ebp,%edx
   e45f7:	movzbl (%r15,%rdx,1),%edx
   e45fc:	add    %edx,%esi
   e45fe:	mov    %eax,%edx
   e4600:	shr    $0xc,%edx
   e4603:	and    $0xf,%edx
   e4606:	add    %ebx,%edx
   e4608:	movzbl (%r15,%rdx,1),%edx
   e460d:	add    %edx,%esi
   e460f:	mov    %eax,%edx
   e4611:	shr    $0x10,%edx
   e4614:	and    $0xf,%edx
   e4617:	add    %r11d,%edx
   e461a:	movzbl (%r15,%rdx,1),%edx
   e461f:	add    %edx,%esi
   e4621:	mov    %eax,%edx
   e4623:	shr    $0x14,%edx
   e4626:	and    $0xf,%edx
   e4629:	add    %r10d,%edx
   e462c:	movzbl (%r15,%rdx,1),%edx
   e4631:	add    %edx,%esi
   e4633:	mov    %eax,%edx
   e4635:	shr    $0x1c,%eax
   e4638:	shr    $0x18,%edx
   e463b:	add    %r8d,%eax
   e463e:	and    $0xf,%edx
   e4641:	movzbl (%r15,%rax,1),%eax
   e4646:	add    %r9d,%edx
   e4649:	movzbl (%r15,%rdx,1),%edx
   e464e:	add    %esi,%edx
   e4650:	add    %edx,%eax
   e4652:	cvtsi2ss %eax,%xmm0
   e4656:	addss  -0x80(%rcx),%xmm0
   e465b:	movss  %xmm0,-0x80(%rcx)
   e4660:	cmp    %r13,%rcx
   e4663:	jne    e45c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x140>
   e4669:	mov    0x10(%rsp),%rsi
   e466e:	lea    0x4(%rcx),%r13
   e4672:	add    $0x1,%rsi
   e4676:	cmp    $0x20,%rsi
   e467a:	jne    e4512 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x92>
   e4680:	subq   $0xffffffffffffff80,0x8(%rsp)
   e4686:	mov    0x30(%rsp),%rdi
   e468b:	mov    0x8(%rsp),%rbx
   e4690:	subq   $0xffffffffffffff80,0x18(%rsp)
   e4696:	mov    0x38(%rsp),%rax
   e469b:	cmp    %rbx,%rdi
   e469e:	jne    e4503 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x83>
   e46a4:	mov    0x20(%rsp),%rdx
   e46a9:	mov    0x28(%rsp),%r13
   e46ae:	mov    0x40(%rsp),%rax
   e46b3:	lea    0x8(%rdx),%rdi
   e46b7:	mov    %r13,%rsi
   e46ba:	and    $0xfffffffffffffff8,%rdi
   e46be:	mov    %rax,(%rdx)
   e46c1:	mov    0x1038(%rsp),%rax
   e46c9:	mov    %rax,0xff8(%rdx)
   e46d0:	sub    %rdi,%rdx
   e46d3:	sub    %rdx,%rsi
   e46d6:	add    $0x1000,%edx
   e46dc:	mov    %edx,%ecx
   e46de:	shr    $0x3,%ecx
   e46e1:	rep movsq %ds:(%rsi),%es:(%rdi)
   e46e4:	mov    0x1048(%rsp),%rax
   e46ec:	sub    %fs:0x28,%rax
   e46f5:	jne    e4709 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x289>
   e46f7:	add    $0x1058,%rsp
   e46fe:	pop    %rbx
   e46ff:	pop    %rbp
   e4700:	pop    %r12
   e4702:	pop    %r13
   e4704:	pop    %r14
   e4706:	pop    %r15
   e4708:	ret
   e4709:	call   31b60 <__stack_chk_fail@plt>
   e470e:	xchg   %ax,%ax

00000000000e4710 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
   e4710:	endbr64
   e4714:	push   %r14
   e4716:	push   %r13
   e4718:	mov    %rdx,%r13
   e471b:	push   %r12
   e471d:	push   %rbp
   e471e:	push   %rbx
   e471f:	test   %rdx,%rdx
   e4722:	je     e4770 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
   e4724:	mov    %rdi,%r12
   e4727:	test   $0x7,%dl
   e472a:	je     e47a5 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x95>
   e472c:	mov    %rsi,%rbx
   e472f:	mov    %rcx,%rbp
   e4732:	lea    0x80(%rsi),%r14
   e4739:	nopl   0x0(%rax)
   e4740:	mov    %rbp,%rcx
   e4743:	mov    %rbx,%rsi
   e4746:	mov    %r13,%rdx
   e4749:	mov    %r12,%rdi
   e474c:	call   6d840 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .constprop.1]>
   e4751:	add    $0x4,%rbx
   e4755:	sub    $0xffffffffffffff80,%rbp
   e4759:	cmp    %rbx,%r14
   e475c:	jne    e4740 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30>
   e475e:	pop    %rbx
   e475f:	pop    %rbp
   e4760:	pop    %r12
   e4762:	pop    %r13
   e4764:	pop    %r14
   e4766:	ret
   e4767:	nopw   0x0(%rax,%rax,1)
   e4770:	lea    0x8(%rcx),%rdi
   e4774:	movq   $0x0,(%rcx)
   e477b:	mov    %rdx,%rax
   e477e:	movq   $0x0,0xff8(%rcx)
   e4789:	and    $0xfffffffffffffff8,%rdi
   e478d:	sub    %rdi,%rcx
   e4790:	add    $0x1000,%ecx
   e4796:	shr    $0x3,%ecx
   e4799:	rep stos %rax,%es:(%rdi)
   e479c:	pop    %rbx
   e479d:	pop    %rbp
   e479e:	pop    %r12
   e47a0:	pop    %r13
   e47a2:	pop    %r14
   e47a4:	ret
   e47a5:	pop    %rbx
   e47a6:	pop    %rbp
   e47a7:	pop    %r12
   e47a9:	pop    %r13
   e47ab:	pop    %r14
   e47ad:	jmp    e4480 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>
   e47b2:	cs nopw 0x0(%rax,%rax,1)
   e47bc:	nopl   0x0(%rax)

00000000000e47c0 <void run<unsigned char, 32ul, 32ul, false>(char const*)>:
   e47c0:	endbr64
   e47c4:	push   %rbp
   e47c5:	mov    %rsp,%rbp
   e47c8:	push   %r15
   e47ca:	push   %r14
   e47cc:	push   %r13
   e47ce:	push   %r12
   e47d0:	push   %rbx
   e47d1:	sub    $0x128,%rsp
   e47d8:	mov    %rdi,-0x120(%rbp)
   e47df:	mov    %fs:0x28,%rax
   e47e8:	mov    %rax,-0x38(%rbp)
   e47ec:	xor    %eax,%eax
   e47ee:	mov    0xf49b3(%rip),%rax        # 1d91a8 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x15c8>
   e47f5:	mov    %rax,-0x40(%rbp)
   e47f9:	lea    -0x40(%rbp),%rax
   e47fd:	mov    %rax,-0x110(%rbp)
   e4804:	lea    -0x38(%rbp),%rax
   e4808:	mov    %rax,-0x118(%rbp)
   e480f:	lea    -0xc0(%rbp),%rax
   e4816:	mov    %rax,-0x130(%rbp)
   e481d:	lea    -0xa0(%rbp),%rax
   e4824:	mov    %rax,-0x128(%rbp)
   e482b:	mov    -0x110(%rbp),%rax
   e4832:	mov    -0x130(%rbp),%rdi
   e4839:	xor    %edx,%edx
   e483b:	mov    (%rax),%ebx
   e483d:	mov    %rbx,%rsi
   e4840:	call   3edd0 <std::vector<unsigned char, std::allocator<unsigned char> > fill<unsigned char>(unsigned long, unsigned long, int) [clone .constprop.5]>
   e4845:	mov    -0x128(%rbp),%rdi
   e484c:	mov    $0x3,%edx
   e4851:	mov    %rbx,%rsi
   e4854:	call   3edd0 <std::vector<unsigned char, std::allocator<unsigned char> > fill<unsigned char>(unsigned long, unsigned long, int) [clone .constprop.5]>
   e4859:	pxor   %xmm0,%xmm0
   e485d:	mov    $0x1000,%edi
   e4862:	movups %xmm0,-0x78(%rbp)
   e4866:	call   31b20 <operator new(unsigned long)@plt>
   e486b:	lea    0xc(%rax),%rdi
   e486f:	lea    0x1000(%rax),%rdx
   e4876:	mov    %rax,-0x80(%rbp)
   e487a:	mov    %rax,%r13
   e487d:	and    $0xfffffffffffffff8,%rdi
   e4881:	mov    %rdx,-0x70(%rbp)
   e4885:	movl   $0x0,(%rax)
   e488b:	movq   $0x0,0x4(%rax)
   e4893:	movq   $0x0,0xff8(%rax)
   e489e:	sub    %edi,%eax
   e48a0:	lea    0x1000(%rax),%ecx
   e48a6:	xor    %eax,%eax
   e48a8:	shr    $0x3,%ecx
   e48ab:	rep stos %rax,%es:(%rdi)
   e48ae:	mov    %rdx,-0x78(%rbp)
   e48b2:	mov    %r13,%rcx
   e48b5:	mov    %rbx,%rdx
   e48b8:	mov    -0xa0(%rbp),%r15
   e48bf:	mov    -0xc0(%rbp),%r14
   e48c6:	mov    %r15,%rsi
   e48c9:	mov    %r14,%rdi
   e48cc:	call   e4710 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)>
   e48d1:	mov    %r13,%rcx
   e48d4:	xor    %r10d,%r10d
   e48d7:	xor    %edx,%edx
   e48d9:	movsd  0xf48bf(%rip),%xmm4        # 1d91a0 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x15c0>
   e48e1:	mov    $0xfffffe60,%r9d
   e48e7:	pxor   %xmm5,%xmm5
   e48eb:	mov    %r13,%rax
   e48ee:	mov    %r10d,%r11d
   e48f1:	mov    %rcx,%r12
   e48f4:	nopl   0x0(%rax)
   e48f8:	test   %rbx,%rbx
   e48fb:	je     e4ab0 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x2f0>
   e4901:	mov    %r10d,%esi
   e4904:	xor    %edi,%edi
   e4906:	pxor   %xmm2,%xmm2
   e490a:	mov    %rax,%r13
   e490d:	sub    %r11d,%esi
   e4910:	lea    0x3(%r11),%r8d
   e4914:	nopl   0x0(%rax)
   e4918:	mov    %esi,%eax
   e491a:	pxor   %xmm0,%xmm0
   e491e:	pxor   %xmm1,%xmm1
   e4922:	add    $0x1,%rdi
   e4926:	and    $0xf,%eax
   e4929:	sub    $0x8,%eax
   e492c:	cvtsi2sd %eax,%xmm0
   e4930:	lea    (%r8,%rsi,1),%eax
   e4934:	add    $0x7,%esi
   e4937:	and    $0xf,%eax
   e493a:	sub    $0x8,%eax
   e493d:	cvtsi2sd %eax,%xmm1
   e4941:	subsd  %xmm1,%xmm0
   e4945:	mulsd  %xmm0,%xmm0
   e4949:	addsd  %xmm0,%xmm2
   e494d:	cmp    %rdi,%rbx
   e4950:	jne    e4918 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x158>
   e4952:	movapd %xmm2,%xmm0
   e4956:	pxor   %xmm1,%xmm1
   e495a:	movapd %xmm2,%xmm3
   e495e:	mov    %r13,%rax
   e4961:	andpd  0xf34b7(%rip),%xmm0        # 1d7e20 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x240>
   e4969:	cvtss2sd (%r12),%xmm1
   e496f:	subsd  %xmm1,%xmm3
   e4973:	andpd  0xf34a5(%rip),%xmm3        # 1d7e20 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x240>
   e497b:	mulsd  0xf482d(%rip),%xmm0        # 1d91b0 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x15d0>
   e4983:	maxsd  %xmm4,%xmm0
   e4987:	comisd %xmm0,%xmm3
   e498b:	ja     e4adc <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x31c>
   e4991:	sub    $0xd,%r11d
   e4995:	add    $0x4,%r12
   e4999:	cmp    %r11d,%r9d
   e499c:	jne    e48f8 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x138>
   e49a2:	add    $0x1,%rdx
   e49a6:	add    $0xd,%r9d
   e49aa:	add    $0xd,%r10d
   e49ae:	sub    $0xffffffffffffff80,%rcx
   e49b2:	cmp    $0x20,%rdx
   e49b6:	jne    e48ee <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x12e>
   e49bc:	lea    -0x100(%rbp),%rdx
   e49c3:	mov    %rax,-0x108(%rbp)
   e49ca:	mov    $0x1,%r12d
   e49d0:	mov    %rdx,-0x140(%rbp)
   e49d7:	mov    -0x140(%rbp),%rsi
   e49de:	mov    $0x3,%edi
   e49e3:	call   31ad0 <clock_gettime@plt>
   e49e8:	test   %eax,%eax
   e49ea:	jne    e4d74 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x5b4>
   e49f0:	imul   $0x3b9aca00,-0x100(%rbp),%r13
   e49fb:	add    -0xf8(%rbp),%r13
   e4a02:	mov    %r13,-0x138(%rbp)
   e4a09:	xor    %r13d,%r13d
   e4a0c:	test   %r12,%r12
   e4a0f:	je     e4a2f <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x26f>
   e4a11:	mov    -0x108(%rbp),%rcx
   e4a18:	mov    %rbx,%rdx
   e4a1b:	mov    %r15,%rsi
   e4a1e:	mov    %r14,%rdi
   e4a21:	add    $0x1,%r13
   e4a25:	call   e4710 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)>
   e4a2a:	cmp    %r13,%r12
   e4a2d:	jne    e4a11 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x251>
   e4a2f:	mov    -0x108(%rbp),%rax
   e4a36:	lea    -0xf0(%rbp),%rsi
   e4a3d:	mov    $0x3,%edi
   e4a42:	movss  0xffc(%rax),%xmm0
   e4a4a:	movss  %xmm0,0x12867a(%rip)        # 20d0cc <consumed>
   e4a52:	call   31ad0 <clock_gettime@plt>
   e4a57:	test   %eax,%eax
   e4a59:	jne    e4d74 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x5b4>
   e4a5f:	mov    -0x138(%rbp),%rcx
   e4a66:	pxor   %xmm0,%xmm0
   e4a6a:	imul   $0x3b9aca00,-0xf0(%rbp),%rax
   e4a75:	add    -0xe8(%rbp),%rax
   e4a7c:	movsd  0xf4734(%rip),%xmm6        # 1d91b8 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x15d8>
   e4a84:	sub    %rcx,%rax
   e4a87:	cvtsi2sd %rax,%xmm0
   e4a8c:	comisd %xmm0,%xmm6
   e4a90:	jbe    e4b1f <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x35f>
   e4a96:	cmp    $0xffffff,%r12
   e4a9d:	ja     e4b1f <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x35f>
   e4aa3:	add    %r12,%r12
   e4aa6:	jmp    e49d7 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x217>
   e4aab:	nopl   0x0(%rax,%rax,1)
   e4ab0:	pxor   %xmm1,%xmm1
   e4ab4:	movapd %xmm5,%xmm3
   e4ab8:	movapd %xmm4,%xmm0
   e4abc:	cvtss2sd (%r12),%xmm1
   e4ac2:	subsd  %xmm1,%xmm3
   e4ac6:	pxor   %xmm2,%xmm2
   e4aca:	andpd  0xf334e(%rip),%xmm3        # 1d7e20 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table+0x240>
   e4ad2:	comisd %xmm0,%xmm3
   e4ad6:	jbe    e4991 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x1d1>
   e4adc:	push   $0x0
   e4ade:	mov    -0x120(%rbp),%rcx
   e4ae5:	movapd %xmm2,%xmm0
   e4ae9:	mov    $0x20,%r9d
   e4aef:	push   %rbx
   e4af0:	mov    0x1285c9(%rip),%rdi        # 20d0c0 <stderr@GLIBC_2.2.5>
   e4af7:	mov    $0x20,%r8d
   e4afd:	lea    0xf1634(%rip),%rdx        # 1d6138 <_IO_stdin_used+0x138>
   e4b04:	mov    $0x2,%esi
   e4b09:	mov    $0x2,%eax
   e4b0e:	call   31d10 <__fprintf_chk@plt>
   e4b13:	pop    %rcx
   e4b14:	mov    $0x1,%edi
   e4b19:	pop    %rsi
   e4b1a:	call   31bb0 <exit@plt>
   e4b1f:	lea    -0xe0(%rbp),%rax
   e4b26:	movq   $0x0,-0x50(%rbp)
   e4b2e:	pxor   %xmm0,%xmm0
   e4b32:	mov    %rax,-0x150(%rbp)
   e4b39:	lea    -0xd0(%rbp),%rax
   e4b40:	movl   $0x5,-0x144(%rbp)
   e4b4a:	mov    %rax,-0x138(%rbp)
   e4b51:	movaps %xmm0,-0x60(%rbp)
   e4b55:	mov    -0x150(%rbp),%rsi
   e4b5c:	mov    $0x3,%edi
   e4b61:	call   31ad0 <clock_gettime@plt>
   e4b66:	test   %eax,%eax
   e4b68:	jne    e4d74 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x5b4>
   e4b6e:	imul   $0x3b9aca00,-0xe0(%rbp),%r13
   e4b79:	add    -0xd8(%rbp),%r13
   e4b80:	mov    %r13,-0x140(%rbp)
   e4b87:	xor    %r13d,%r13d
   e4b8a:	test   %r12,%r12
   e4b8d:	je     e4bad <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x3ed>
   e4b8f:	mov    -0x108(%rbp),%rcx
   e4b96:	mov    %rbx,%rdx
   e4b99:	mov    %r15,%rsi
   e4b9c:	mov    %r14,%rdi
   e4b9f:	add    $0x1,%r13
   e4ba3:	call   e4710 <void kernel<unsigned char, 32ul, 32ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)>
   e4ba8:	cmp    %r13,%r12
   e4bab:	jne    e4b8f <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x3cf>
   e4bad:	mov    -0x108(%rbp),%rax
   e4bb4:	mov    -0x138(%rbp),%rsi
   e4bbb:	mov    $0x3,%edi
   e4bc0:	movss  0xffc(%rax),%xmm0
   e4bc8:	movss  %xmm0,0x1284fc(%rip)        # 20d0cc <consumed>
   e4bd0:	call   31ad0 <clock_gettime@plt>
   e4bd5:	test   %eax,%eax
   e4bd7:	jne    e4d74 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x5b4>
   e4bdd:	mov    -0x140(%rbp),%rdx
   e4be4:	pxor   %xmm0,%xmm0
   e4be8:	pxor   %xmm1,%xmm1
   e4bec:	lea    -0x60(%rbp),%r13
   e4bf0:	cvtsi2sd %r12,%xmm1
   e4bf5:	mov    -0x138(%rbp),%rsi
   e4bfc:	mov    %r13,%rdi
   e4bff:	imul   $0x3b9aca00,-0xd0(%rbp),%rax
   e4c0a:	add    -0xc8(%rbp),%rax
   e4c11:	sub    %rdx,%rax
   e4c14:	cvtsi2sd %rax,%xmm0
   e4c19:	divsd  %xmm1,%xmm0
   e4c1d:	movsd  %xmm0,-0xd0(%rbp)
   e4c25:	call   40170 <double& std::vector<double, std::allocator<double> >::emplace_back<double>(double&&) [clone .isra.0]>
   e4c2a:	subl   $0x1,-0x144(%rbp)
   e4c31:	jne    e4b55 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x395>
   e4c37:	mov    -0x60(%rbp),%r12
   e4c3b:	mov    -0x58(%rbp),%rsi
   e4c3f:	mov    %r12,%rdi
   e4c42:	call   3cf30 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__ops::_Iter_less_iter>(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__ops::_Iter_less_iter) [clone .isra.0]>
   e4c47:	sub    $0x8,%rsp
   e4c4b:	mov    $0x2,%edi
   e4c50:	movsd  0x10(%r12),%xmm0
   e4c57:	push   %rbx
   e4c58:	mov    -0x120(%rbp),%rdx
   e4c5f:	mov    $0x20,%r9d
   e4c65:	mov    $0x20,%r8d
   e4c6b:	lea    0xf2153(%rip),%rcx        # 1d6dc5 <_IO_stdin_used+0xdc5>
   e4c72:	lea    0xf2134(%rip),%rsi        # 1d6dad <_IO_stdin_used+0xdad>
   e4c79:	mov    $0x1,%eax
   e4c7e:	call   31750 <__printf_chk@plt>
   e4c83:	pop    %rax
   e4c84:	mov    %r13,%rdi
   e4c87:	pop    %rdx
   e4c88:	call   6f880 <std::vector<double, std::allocator<double> >::~vector()>
   e4c8d:	lea    -0x80(%rbp),%rdi
   e4c91:	call   6f850 <std::vector<float, std::allocator<float> >::~vector()>
   e4c96:	test   %r15,%r15
   e4c99:	je     e4cad <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x4ed>
   e4c9b:	mov    -0x90(%rbp),%rsi
   e4ca2:	mov    %r15,%rdi
   e4ca5:	sub    %r15,%rsi
   e4ca8:	call   31b30 <operator delete(void*, unsigned long)@plt>
   e4cad:	test   %r14,%r14
   e4cb0:	je     e4cfe <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x53e>
   e4cb2:	mov    -0xb0(%rbp),%rsi
   e4cb9:	mov    %r14,%rdi
   e4cbc:	sub    %r14,%rsi
   e4cbf:	call   31b30 <operator delete(void*, unsigned long)@plt>
   e4cc4:	addq   $0x4,-0x110(%rbp)
   e4ccc:	mov    -0x110(%rbp),%rax
   e4cd3:	cmp    %rax,-0x118(%rbp)
   e4cda:	jne    e482b <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x6b>
   e4ce0:	mov    -0x38(%rbp),%rax
   e4ce4:	sub    %fs:0x28,%rax
   e4ced:	jne    e4d54 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x594>
   e4cef:	lea    -0x28(%rbp),%rsp
   e4cf3:	pop    %rbx
   e4cf4:	pop    %r12
   e4cf6:	pop    %r13
   e4cf8:	pop    %r14
   e4cfa:	pop    %r15
   e4cfc:	pop    %rbp
   e4cfd:	ret
   e4cfe:	addq   $0x4,-0x110(%rbp)
   e4d06:	mov    -0x110(%rbp),%rax
   e4d0d:	cmp    %rax,-0x118(%rbp)
   e4d14:	jne    e482b <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x6b>
   e4d1a:	jmp    e4ce0 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x520>
   e4d1c:	mov    %r13,%rdi
   e4d1f:	call   6f880 <std::vector<double, std::allocator<double> >::~vector()>
   e4d24:	lea    -0x80(%rbp),%rdi
   e4d28:	call   6f850 <std::vector<float, std::allocator<float> >::~vector()>
   e4d2d:	mov    -0x128(%rbp),%rdi
   e4d34:	call   6f910 <std::vector<unsigned char, std::allocator<unsigned char> >::~vector()>
   e4d39:	mov    -0x130(%rbp),%rdi
   e4d40:	call   6f910 <std::vector<unsigned char, std::allocator<unsigned char> >::~vector()>
   e4d45:	mov    -0x38(%rbp),%rax
   e4d49:	sub    %fs:0x28,%rax
   e4d52:	je     e4d82 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x5c2>
   e4d54:	call   31b60 <__stack_chk_fail@plt>
   e4d59:	endbr64
   e4d5d:	mov    %rax,%rbx
   e4d60:	jmp    e4d24 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x564>
   e4d62:	endbr64
   e4d66:	mov    %rax,%rbx
   e4d69:	jmp    e4d1c <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x55c>
   e4d6b:	endbr64
   e4d6f:	mov    %rax,%rbx
   e4d72:	jmp    e4d2d <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x56d>
   e4d74:	call   318e0 <abort@plt>
   e4d79:	endbr64
   e4d7d:	mov    %rax,%rbx
   e4d80:	jmp    e4d39 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x579>
   e4d82:	mov    %rbx,%rdi
   e4d85:	call   31db0 <_Unwind_Resume@plt>
   e4d8a:	cs nopw 0x0(%rax,%rax,1)
   e4d94:	cs nopw 0x0(%rax,%rax,1)
   e4d9e:	cs nopw 0x0(%rax,%rax,1)
   e4da8:	cs nopw 0x0(%rax,%rax,1)
   e4db2:	cs nopw 0x0(%rax,%rax,1)
   e4dbc:	nopl   0x0(%rax)
