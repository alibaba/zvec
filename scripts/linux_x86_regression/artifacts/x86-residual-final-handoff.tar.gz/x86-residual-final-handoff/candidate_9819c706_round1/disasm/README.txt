Disassembly evidence from DEFAULT builds (no extra alignment flags).
- matrix_sweep.sha256: binary hash
- matrix_sweep_hot_symbols.txt: nm -C -n of ComputePackedColumns/ComputeSingleColumn (incl. constprop/isra clones)
  RUN: 86 symbols, all addresses % 64 == 0 (aligned(64) attribute effective; noinline outlined 40 INT8 ComputeSingleColumn clones
  that were inlined in REF). REF: 20 symbols, 5 happen to be 64-aligned. OLDER: 20 symbols.
- packed32_int4_l2_run.asm: RUN ComputePackedColumns<32> for <uint8_t,32,L2> @0xe4480; loop heads 0xe45c0 / 0xe4740 are 64-aligned.
- kernel_uchar_32_16_false_run.asm: matrix_sweep wrapper now tail-calls ComputePackedColumns<16> and calls ComputeSingleColumn constprop clone.
- matrix_sweep_kernel_wrappers.txt: nm -S of all 255 kernel<> wrappers (sizes shrink in RUN because bodies are outlined).
