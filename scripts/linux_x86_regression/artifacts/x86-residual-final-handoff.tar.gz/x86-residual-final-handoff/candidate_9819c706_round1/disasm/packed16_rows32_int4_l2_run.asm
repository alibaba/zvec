
/home/xingrui/workspace/zvec/ivf_matrix/zvec-residual-new.en2dYQ/build-fixed/bin/matrix_sweep:     file format elf64-x86-64


Disassembly of section .text:

00000000000e3200 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
   e3200:	endbr64
   e3204:	push   %r15
   e3206:	mov    %rdx,%rax
   e3209:	mov    %rcx,%rdx
   e320c:	push   %r14
   e320e:	shr    $1,%rax
   e3211:	push   %r13
   e3213:	shl    $0x4,%rax
   e3217:	push   %r12
   e3219:	lea    (%rsi,%rax,1),%r8
   e321d:	xor    %eax,%eax
   e321f:	push   %rbp
   e3220:	push   %rbx
   e3221:	sub    $0x858,%rsp
   e3228:	mov    %rdi,0x18(%rsp)
   e322d:	lea    0x40(%rsp),%r13
   e3232:	mov    %r13,%rdi
   e3235:	mov    %fs:0x28,%rcx
   e323e:	mov    %rcx,0x848(%rsp)
   e3246:	xor    %ecx,%ecx
   e3248:	mov    $0x100,%ecx
   e324d:	rep stos %rax,%es:(%rdi)
   e3250:	cmp    %r8,%rsi
   e3253:	je     e342e <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22e>
   e3259:	mov    %rsi,0x10(%rsp)
   e325e:	lea    0xf417b(%rip),%r15        # 1d73e0 <zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::PackedDistances()::distance_table>
   e3265:	mov    %r8,%rdi
   e3268:	lea    0x840(%rsp),%rax
   e3270:	mov    %rdx,0x20(%rsp)
   e3275:	mov    %r13,0x28(%rsp)
   e327a:	mov    %rdi,0x30(%rsp)
   e327f:	mov    %rax,%r13
   e3282:	xor    %esi,%esi
   e3284:	mov    %rax,0x38(%rsp)
   e3289:	mov    0x18(%rsp),%rax
   e328e:	mov    %rsi,0x8(%rsp)
   e3293:	lea    -0x800(%r13),%rcx
   e329a:	mov    0x10(%rsp),%rdi
   e329f:	mov    (%rax,%rsi,4),%r8d
   e32a3:	mov    %r8d,%r12d
   e32a6:	mov    %r8d,%ebp
   e32a9:	mov    %r8d,%ebx
   e32ac:	mov    %r8d,%r11d
   e32af:	mov    %r8d,%r10d
   e32b2:	mov    %r8d,%r9d
   e32b5:	mov    %r8d,%r14d
   e32b8:	and    $0xf,%r12d
   e32bc:	shr    $0x4,%ebp
   e32bf:	shr    $0x8,%ebx
   e32c2:	and    $0xf0,%r14d
   e32c9:	shr    $0xc,%r11d
   e32cd:	shr    $0x10,%r10d
   e32d1:	and    $0xf0,%ebp
   e32d7:	and    $0xf0,%ebx
   e32dd:	shr    $0x14,%r9d
   e32e1:	shr    $0x1c,%r8d
   e32e5:	and    $0xf0,%r11d
   e32ec:	and    $0xf0,%r10d
   e32f3:	shl    $0x4,%r12d
   e32f7:	and    $0xf0,%r9d
   e32fe:	shl    $0x4,%r8d
   e3302:	data16 cs nopw 0x0(%rax,%rax,1)
   e330d:	data16 cs nopw 0x0(%rax,%rax,1)
   e3318:	data16 cs nopw 0x0(%rax,%rax,1)
   e3323:	data16 cs nopw 0x0(%rax,%rax,1)
   e332e:	data16 cs nopw 0x0(%rax,%rax,1)
   e3339:	nopl   0x0(%rax)
   e3340:	mov    (%rdi),%eax
   e3342:	pxor   %xmm0,%xmm0
   e3346:	sub    $0xffffffffffffff80,%rcx
   e334a:	add    $0x4,%rdi
   e334e:	mov    %eax,%edx
   e3350:	shr    $0x4,%edx
   e3353:	and    $0xf,%edx
   e3356:	add    %r14d,%edx
   e3359:	movzbl (%r15,%rdx,1),%esi
   e335e:	mov    %eax,%edx
   e3360:	and    $0xf,%edx
   e3363:	add    %r12d,%edx
   e3366:	movzbl (%r15,%rdx,1),%edx
   e336b:	add    %edx,%esi
   e336d:	mov    %eax,%edx
   e336f:	shr    $0x8,%edx
   e3372:	and    $0xf,%edx
   e3375:	add    %ebp,%edx
   e3377:	movzbl (%r15,%rdx,1),%edx
   e337c:	add    %edx,%esi
   e337e:	mov    %eax,%edx
   e3380:	shr    $0xc,%edx
   e3383:	and    $0xf,%edx
   e3386:	add    %ebx,%edx
   e3388:	movzbl (%r15,%rdx,1),%edx
   e338d:	add    %edx,%esi
   e338f:	mov    %eax,%edx
   e3391:	shr    $0x10,%edx
   e3394:	and    $0xf,%edx
   e3397:	add    %r11d,%edx
   e339a:	movzbl (%r15,%rdx,1),%edx
   e339f:	add    %edx,%esi
   e33a1:	mov    %eax,%edx
   e33a3:	shr    $0x14,%edx
   e33a6:	and    $0xf,%edx
   e33a9:	add    %r10d,%edx
   e33ac:	movzbl (%r15,%rdx,1),%edx
   e33b1:	add    %edx,%esi
   e33b3:	mov    %eax,%edx
   e33b5:	shr    $0x1c,%eax
   e33b8:	shr    $0x18,%edx
   e33bb:	add    %r8d,%eax
   e33be:	and    $0xf,%edx
   e33c1:	movzbl (%r15,%rax,1),%eax
   e33c6:	add    %r9d,%edx
   e33c9:	movzbl (%r15,%rdx,1),%edx
   e33ce:	add    %esi,%edx
   e33d0:	add    %edx,%eax
   e33d2:	cvtsi2ss %eax,%xmm0
   e33d6:	addss  -0x80(%rcx),%xmm0
   e33db:	movss  %xmm0,-0x80(%rcx)
   e33e0:	cmp    %r13,%rcx
   e33e3:	jne    e3340 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x140>
   e33e9:	mov    0x8(%rsp),%rsi
   e33ee:	lea    0x4(%rcx),%r13
   e33f2:	add    $0x1,%rsi
   e33f6:	cmp    $0x20,%rsi
   e33fa:	jne    e3289 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x89>
   e3400:	addq   $0x40,0x10(%rsp)
   e3406:	mov    0x30(%rsp),%rdi
   e340b:	mov    0x10(%rsp),%rbx
   e3410:	subq   $0xffffffffffffff80,0x18(%rsp)
   e3416:	mov    0x38(%rsp),%rax
   e341b:	cmp    %rbx,%rdi
   e341e:	jne    e327a <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7a>
   e3424:	mov    0x20(%rsp),%rdx
   e3429:	mov    0x28(%rsp),%r13
   e342e:	mov    0x40(%rsp),%rax
   e3433:	lea    0x8(%rdx),%rdi
   e3437:	mov    %r13,%rsi
   e343a:	and    $0xfffffffffffffff8,%rdi
   e343e:	mov    %rax,(%rdx)
   e3441:	mov    0x838(%rsp),%rax
   e3449:	mov    %rax,0x7f8(%rdx)
   e3450:	sub    %rdi,%rdx
   e3453:	sub    %rdx,%rsi
   e3456:	add    $0x800,%edx
   e345c:	mov    %edx,%ecx
   e345e:	shr    $0x3,%ecx
   e3461:	rep movsq %ds:(%rsi),%es:(%rdi)
   e3464:	mov    0x848(%rsp),%rax
   e346c:	sub    %fs:0x28,%rax
   e3475:	jne    e3489 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x289>
   e3477:	add    $0x858,%rsp
   e347e:	pop    %rbx
   e347f:	pop    %rbp
   e3480:	pop    %r12
   e3482:	pop    %r13
   e3484:	pop    %r14
   e3486:	pop    %r15
   e3488:	ret
   e3489:	call   31b60 <__stack_chk_fail@plt>
   e348e:	xchg   %ax,%ax
