# RUN matrix_sweep e874708d54d709a4041874a68dce0eef88df771bc5004cba43fceeab2feb59b7  /home/xingrui/workspace/zvec/ivf_matrix/zvec-residual-new.en2dYQ/build-fixed/bin/matrix_sweep
# kernel<unsigned char,32,16,false> @0xe3490 size 0xa5

/home/xingrui/workspace/zvec/ivf_matrix/zvec-residual-new.en2dYQ/build-fixed/bin/matrix_sweep:     file format elf64-x86-64


Disassembly of section .text:

00000000000e3490 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
   e3490:	endbr64
   e3494:	push   %r14
   e3496:	push   %r13
   e3498:	mov    %rdx,%r13
   e349b:	push   %r12
   e349d:	push   %rbp
   e349e:	push   %rbx
   e349f:	test   %rdx,%rdx
   e34a2:	je     e34f0 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
   e34a4:	mov    %rdi,%r12
   e34a7:	test   $0x7,%dl
   e34aa:	je     e3528 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x98>
   e34ac:	mov    %rsi,%rbx
   e34af:	mov    %rcx,%rbp
   e34b2:	lea    0x40(%rsi),%r14
   e34b6:	cs nopw 0x0(%rax,%rax,1)
   e34c0:	mov    %rbp,%rcx
   e34c3:	mov    %rbx,%rsi
   e34c6:	mov    %r13,%rdx
   e34c9:	mov    %r12,%rdi
   e34cc:	call   6d580 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*) [clone .constprop.0]>
   e34d1:	add    $0x4,%rbx
   e34d5:	sub    $0xffffffffffffff80,%rbp
   e34d9:	cmp    %rbx,%r14
   e34dc:	jne    e34c0 <void kernel<unsigned char, 32ul, 16ul, false>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30>
   e34de:	pop    %rbx
   e34df:	pop    %rbp
   e34e0:	pop    %r12
   e34e2:	pop    %r13
   e34e4:	pop    %r14
   e34e6:	ret
   e34e7:	nopw   0x0(%rax,%rax,1)
   e34f0:	lea    0x8(%rcx),%rdi
   e34f4:	movq   $0x0,(%rcx)
   e34fb:	mov    %rdx,%rax
   e34fe:	movq   $0x0,0x7f8(%rcx)
   e3509:	and    $0xfffffffffffffff8,%rdi
   e350d:	sub    %rdi,%rcx
   e3510:	add    $0x800,%ecx
   e3516:	shr    $0x3,%ecx
   e3519:	rep stos %rax,%es:(%rdi)
   e351c:	pop    %rbx
   e351d:	pop    %rbp
   e351e:	pop    %r12
   e3520:	pop    %r13
   e3522:	pop    %r14
   e3524:	ret
   e3525:	nopl   (%rax)
   e3528:	pop    %rbx
   e3529:	pop    %rbp
   e352a:	pop    %r12
   e352c:	pop    %r13
   e352e:	pop    %r14
   e3530:	jmp    e3200 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>
