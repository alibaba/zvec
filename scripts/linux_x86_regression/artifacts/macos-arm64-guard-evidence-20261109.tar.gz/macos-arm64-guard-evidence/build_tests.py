import pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
repo = root / 'source'
targets = [p.stem for d in ['tests/core/metric','tests/turbo'] for p in sorted((repo/d).glob('*_test.cc'))]
targets += ['legacy_quantized_index_test','flat_quantizer_distance_test','mips_callback_lifetime_test','multi_chunk_cluster_test','opt_kmeans_cluster_test','ivf_legacy_matrix_test','ivf_searcher_test']
with open(root / 'full_build_final.log', 'w') as log:
    subprocess.run(['cmake','--build','/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_arm64_guard_20261109/build','--parallel','6','--target',*targets], stdout=log, stderr=log, check=True)
subprocess.run(['python3',str(root/'relink.py'),*targets],check=True)
subprocess.run(['python3',str(root/'run_tests.py')],check=True)
