from pathlib import Path
import csv,json,statistics
r=Path(__file__).resolve().parent
s=json.loads((r/'results/two_round_summary.json').read_text());focus=json.loads((r/'results/focused_summary.json').read_text())
data={n:{g:list(csv.DictReader((r/n/(g+'_comparison.csv')).open())) for g in ['matrix','adapter','ivf']} for n in ['round1','round2']}
text=['# ARM64 大多列最小修复与回归结果','',
'2026-11-09，Apple M3 Pro / macOS 26.6.2 / AppleClang 15。','',
'**本次目标已修复：之前 12 项 INT4 大多列矩阵回退 + 2 项 INT4 MIPS 32×32 回退均消除；相对调整前候选，三组性能均没有新增两轮共同 >5% 的回退。** 正确性与旧索引兼容通过。',
'范围限定：完整 sweep 相对历史基线仍有 FP16 1×1 布局相关回退，不能表述为所有形状都零回退；另有只对部分基线复现的波动项，定点复测已单独记录。本轮未在 Linux x86 服务器重跑。','',
'## 1. 具体改动','',
'独立工作树 `source/` 基于 9819c706，先应用已校验 x86 最终候选，再只修改 `src/turbo/distance/matrix.h:151`：',
'```cpp',
'if constexpr (Rows <= 4',
'#if defined(__aarch64__) || defined(_M_ARM64)',
'              || Columns >= 16',
'#endif',
') {',
'  // 原直接提取 packed word 的循环',
'} else {',
'  // 查询半字节展开的循环',
'}',
'```','',
'- ARM64 Columns≥16 使用旧循环，消除 query_nibbles 落栈后逐字节读取的额外成本。',
'- ARM64 Rows≤4 继续原循环；其余 Columns=2/4/8 的优化和所有 INT4 单列查询表行提升保留。',
'- x86 条件和实现保持 Linux 已验证候选的内容；未修改记录量化公式、存储格式、IVF 或测试期望。',
'- 相对调整前候选只有一个编译期条件变化，差分 7 行新增/1 行删除（含注释与条件格式）；相对 9819 的完整差分仍仅 matrix.h。',
'- 主分支仍为 c65ac889 且干净；本轮改动仅位于独立工作树，没有提交、推送或合入。','',
'补丁：`buildinfo/arm64_guard_vs_unguarded.patch` 适用于已经应用 x86 final 的源码；`buildinfo/guarded_vs_9819c706.patch` 是可直接应用到 9819/c65 的完整候选。两者勿重复应用。','',
'## 2. 正确性与兼容','',
'| 检查 | 结果 |','|---|---|',
'| 44 个程序 | 498 通过、33 跳过、25 禁用、0 失败；退出码全部 0 |',
'| 新增历史记录矩统计用例 | Int4RecordMatricesPreserveStoredMoments 通过 |',
'| parent 499eab89 重写旧索引 | 200 个文件；12 通过、4 跳过、16 禁用、0 失败 |',
'| 新候选读取上述索引 | 12 通过、4 跳过、16 禁用、0 失败 |','',
'测试范围沿用交接包：10 metric + 27 Turbo + 2 flat + 3 clustering + ivf_legacy_matrix + IVFSearcher 指定 13 项。旧索引覆盖 4 类型 raw、INT8/INT4 record、L2/IP、对齐/尾部维度、块边界/空列表/过滤/多存储、批量/单查询和 BF/普通搜索；200 fixtures 对应测试循环 28,800 份结果列表。未运行全产品测试集，也未做新的 sanitizer 验证。详见 results/ XML、日志和 fixture 哈希。','',
'## 3. 性能方法与版本','',
'每轮原始矩阵 504、适配器 32、旧 IVF warm 扫描 24 项；五版本各 3 个进程，交错运行，第二轮反转起始顺序。共 90 个完整基准进程。每进程内部取中位数，再取 3 进程中位数，保留 min/max/原始日志。',
'版本：955 / 7abc / 9819 / unguarded（上一轮未加 ARM64 条件的 x86 final）/ final（本次候选）。四个对照使用保留的静态二进制重新计时，没有使用旧轮次的性能数字。955/7abc/9819 原始矩阵的代码和常量区地址/哈希一致。',
'使用同一 toolkit、Release `-march=armv8 -O3 -DNDEBUG`、无全局对齐或新增架构参数。静态 force_load 链接保留工厂注册；统一 USER_INTERACTIVE QoS + taskpolicy -a，**没有硬绑 CPU 核**。matrix/adapter 线程 CPU 计时，IVF warm search_impl 墙钟计时。编译/其他基准与性能运行串行。此调度限制使小形状/墙钟波动需要定点复测。','',
'## 4. 完整两轮计数（>5%）','',
'| 组 | 对照 | 第一轮 | 第二轮 | 两轮共同 |','|---|---|---:|---:|---:|']
for g in ['matrix','adapter','ivf']:
 for v in ['9819','7abc','955','unguarded']:
  a=s[g][v];text.append(f"| {g} | {v} | {a['r1_count']} | {a['r2_count']} | {len(a['both'])} |")
text += ['', '## 5. 14 项目标闭环（相对 9819）','',
'| 类型/度量/形状 | dim | 9819 ns R1 / R2 | 修复后 ns R1 / R2 | 修复后/9819 R1 / R2 | 修复后/调整前 R1 / R2 |','|---|---:|---|---|---|---|']
for g in ['matrix','adapter']:
 for a,b in zip(data['round1'][g],data['round2'][g]):
  target=(g=='matrix' and a['type']=='INT4' and int(a['columns'])>=16) or (g=='adapter' and a['type']=='6' and a['metric']=='MIPS' and a['columns']=='32')
  if target:
   label='INT4 '+a['metric']+' '+a['rows']+'×'+a['columns']+(' adapter' if g=='adapter' else '')
   text.append('| '+label+' | '+a['dim']+' | '+' | '.join(f'{float(a[v]):.3f} / {float(b[v]):.3f}' for v in ['9819','final','final_vs_9819','final_vs_unguarded'])+' |')
text += ['', '12 项 raw 目标相对 9819 两轮范围为 0.939～1.014；MIPS 32×32 为 0.999～1.012，均无 >5% 回退。相对调整前候选，12 项 raw 的耗时中位数为 0.862 / 0.835。','',
'## 6. 已有收益保留','',
'| 路径 | FINAL/9819 中位数 R1 / R2 |','|---|---|']
filters=[('INT4 单列 Rows≥4','matrix',lambda x:x['type']=='INT4' and x['columns']=='1' and int(x['rows'])>=4),('INT4 多列 Rows≥8、Columns=2/4/8','matrix',lambda x:x['type']=='INT4' and int(x['rows'])>=8 and 2<=int(x['columns'])<=8),('INT4 RecordL2/IP 32×1','adapter',lambda x:x['type']=='6' and x['columns']=='1' and x['metric'].startswith('Record')),('旧 IVF INT4 record','ivf',lambda x:x['type']=='6' and x['record']=='1')]
for label,g,pred in filters:
 med=[statistics.median(float(x['final_vs_9819']) for x in data[n][g] if pred(x)) for n in ['round1','round2']];text.append(f'| {label} | {med[0]:.3f} / {med[1]:.3f} |')
text += ['', '本次旧 IVF 基准为 warm 单查询列扫描；不把这 24 项外推为全部 IVF 服务负载吞吐。','',
'## 7. 残余项与定点复测','',
'所有两轮共同 >5% 的历史基线比较项如下（原始数值未删除或以复测替换）：','',
'| 组/形状 | dim | 对照 | R1 / R2 |','|---|---:|---|---|']
for g in s:
 for v in ['9819','7abc','955','unguarded']:
  for a in s[g][v]['both']:
   label=g+' '+a['type']+' '+a['metric']+' '+(a['rows']+'×'+a['columns'] if g!='ivf' else 'record='+a['record']);text.append(f"| {label} | {a['dim']} | {v} | {a['r1']:.3f} / {a['r2']:.3f} |")
text += ['',
'- FP16 IP 1×1 d128 的完整 sweep 布局相关回退仍在，相对 9819 为 1.309 / 1.368；相对本轮调整前 unguarded 没有两轮共同 >5% 回退。本次没有为这个既存现象加入对齐参数或改 FP16 算法。',
'- 另外 INT16 IP 1×1 d512 对 7abc，以及 FP32 IVF IP d512 对 7abc 两轮超过阈值，但对其他历史基线不一致；FP64 1×1/2×1 出现过较大单轮异常，均纳入定点复测。',
'- 微形状重新以相同编译/链接配置和 50ms 采样窗口构建，9819/final 各 10 进程交错测试；两文件完整 __text 地址、长度、SHA256 **相同**。',
'- IVF 定点直接复用五个完整二进制，各 10 进程交错，只筛选 FP32 IP warm scan 测试，没有重新编译或修改测试计时。','',
'| 定点微基准 | dim | FINAL/9819 |','|---|---:|---:|']
for a in focus['micro']:text.append(f"| {a['type']} {a['metric']} {a['rows']}×{a['columns']} | {a['dim']} | {a['final_vs_9819']:.3f} |")
text += ['', '| 定点 FP32 IVF IP | FINAL/955 | FINAL/7abc | FINAL/9819 | FINAL/unguarded |','|---|---:|---:|---:|---:|']
for a in focus['ivf']:text.append('| d'+a['dim']+' | '+' | '.join(f"{a['final_vs_'+v]:.3f}" for v in ['955','7abc','9819','unguarded'])+' |')
text += ['',
'以上定点均≤1.05。证据支持布局/运行环境敏感性，不是新增算术变化；未用硬件计数器进一步分离分支预测、缓存或调度原因。**这不等于完整 sweep 的 FP16 回退不存在，也不能将定点值替换掉完整扫描值。**','',
'## 8. 汇编与 x86 检查','',
'- 16×16 / 32×16：全函数静态指令 166→105，直接 [sp] 访问 26→8；32×32：229→111、43→8，恢复历史直接提取循环，避免大查询字节数组落栈。单列优化保留。计数是静态汇编统计，不是硬件事件。',
'- FP16 warm dispatch 前 31 条归一化指令相同，NEON IP 完整 114 条指令相同；FP64/INT16 raw_numeric 内核归一化指令相同。见 disasm/。',
'- 对调整前/后完整 matrix_sweep 做 x86_64 交叉编译：预处理 token SHA256 相同，完整 Mach-O 目标文件 SHA256 相同，全部 __TEXT 节相同，见 buildinfo/x86_unchanged.json 与 check_x86_unchanged.py。',
'- **这项编译检查使用 AppleClang 的 x86_64 Darwin 目标，不是 Linux/GCC 实机性能复跑。** ARM 条件在 x86 被预处理移除；原 Linux final 报告继续作为既有实机证据，本轮没有新 Linux 性能数字。','',
'## 9. 判定与交付','',
'本次最小 ARM64 调整解决了用户要求处理的 14 项真实 INT4 回退，正确性/兼容通过，且相对待修候选没有新增两轮共同 >5% 回退；可提交给评审。若要求“全矩阵所有形状相对 9819 都≤5%”，当前仍不满足（FP16 1×1 完整 sweep 既存布局项），不能直接宣称两平台所有形状无退化。',
'交付包含两份补丁、两轮全部 504/32/24 项对比表、90 份完整基准原始日志、70 份定点日志、44 程序 XML/日志、200 fixtures、汇编和 x86 编译一致性证据。补丁应用方法见 PATCHES_README_zh.txt。','']
(r/'ARM64_GUARD_REPORT_zh.md').write_text('\n'.join(text))
t=['# ARM64 条件调整后两轮完整性能表','','matrix/adapter 单位 ns，IVF 单位 µs；每个单元格为 R1 / R2。unguarded 为调整前，final 为本次。完整 min/max 和所有比值见 CSV。','']
for g in ['matrix','adapter','ivf']:
 t += [f'## {g}','','| 类型/度量/形状或record/dim | 955 | 7abc | 9819 | unguarded | final | final/9819 | final/unguarded |','|---|---|---|---|---|---|---|---|']
 for a,b in zip(data['round1'][g],data['round2'][g]):
  key='/'.join([a['type'],a['metric'],a.get('rows','')+'×'+a.get('columns','') if g!='ivf' else 'record='+a['record'],a['dim']]);t.append('| '+key+' | '+' | '.join(f'{float(a[v]):.3f} / {float(b[v]):.3f}' for v in ['955','7abc','9819','unguarded','final','final_vs_9819','final_vs_unguarded'])+' |')
 t.append('')
(r/'PERFORMANCE_TABLES.md').write_text('\n'.join(t))
