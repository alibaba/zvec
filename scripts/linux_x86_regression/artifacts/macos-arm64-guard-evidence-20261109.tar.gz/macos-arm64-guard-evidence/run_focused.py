from pathlib import Path
import subprocess,csv,re,json,statistics,struct,hashlib
r=Path(__file__).resolve().parent;out={};(r/'focused').mkdir(exist_ok=True)
for group,variants in [('micro',['9819','final']),('ivf',['955','7abc','9819','unguarded','final'])]:
 samples={}
 for i in range(10):
  for v in variants if i%2==0 else variants[::-1]:
   cmd=['/usr/sbin/taskpolicy','-a',str(r/'bin'/f'{v}_{"focus" if group=="micro" else "ivf"}')]
   if group=='ivf':cmd+=['--gtest_also_run_disabled_tests','--gtest_filter=RawTypes/IVFLegacyMatrixTest.DISABLED_WarmColumnScanBenchmark/1']
   text=subprocess.check_output(cmd,cwd=r/'runtime',text=True,stderr=subprocess.STDOUT);(r/'focused'/f'{group}_{v}_{i}.log').write_text(text)
   if group=='micro':rows=list(csv.DictReader(text.splitlines()));keys=['type','metric','rows','columns','dim'];value='ns_per_matrix'
   else:rows=[dict(re.findall(r'(\w+)=([^,\s]+)',l)) for l in text.splitlines() if l.startswith('LEGACY_BENCH,')];keys=['type','metric','dim','record'];value='median_us'
   assert len(rows)==(8 if group=='micro' else 2)
   for row in rows:samples.setdefault(tuple(row[k] for k in keys),{}).setdefault(v,[]).append(float(row[value]))
 result=[]
 for key,vs in samples.items():
  row=dict(zip(keys,key));row['samples']=vs
  for v,x in vs.items():row[v]=statistics.median(x)
  for v in variants:
   if v!='final':row['final_vs_'+v]=row['final']/row[v]
  result.append(row)
 out[group]=result
 (r/'results/focused_summary.json').write_text(json.dumps(out,indent=2));print(group,'complete',flush=True)
for v in ['9819','final']:
 b=(r/'bin'/f'{v}_focus').read_bytes();off=32
 for i in range(struct.unpack_from('<I',b,16)[0]):
  cmd,sz=struct.unpack_from('<2I',b,off)
  if cmd==0x19:
   for j in range(struct.unpack_from('<I',b,off+64)[0]):
    pos=off+72+j*80
    if b[pos:pos+16].split(b'\0')[0]==b'__text':
     addr,size,foff=struct.unpack_from('<QQI',b,pos+32);out[v+'_micro_text']={'address':hex(addr),'size':size,'sha256':hashlib.sha256(b[foff:foff+size]).hexdigest()}
  off+=sz
(r/'results/focused_summary.json').write_text(json.dumps(out,indent=2))
