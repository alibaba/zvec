import pathlib, re, shlex, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
repo = root / 'source'
for variant in sys.argv[1:]:
    build = pathlib.Path('/tmp/zvec-legacy-ivf-' + variant + '-build' if variant in ('parent', 'before') else '/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_arm64_guard_20261109/build')
    commands = subprocess.check_output(['ninja', '-t', 'commands', 'legacy_ivf_comparison'], cwd=build, text=True).splitlines()
    compile_command = next(x for x in commands if ' -c ' in x and 'ivf_legacy_matrix_test.cc' in x)
    for kind, source in [('ivf', repo / 'tests/core/algorithm/ivf/ivf_legacy_matrix_test.cc'), ('adapter', root.parent / 'audit/adapter_sweep.cc')]:
        obj = root / (variant + '_' + kind + '.o')
        args = shlex.split(compile_command)
        args[1:1] = ['-include', str(root / 'benchmark_qos.h')]
        args[args.index('-c') + 1] = str(source)
        args[args.index('-o') + 1] = str(obj)
        if variant == 'parent': args.insert(1, '-DLEGACY')
        subprocess.run(args, cwd=build, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        args = shlex.split(commands[-1])[2:-2]
        args[args.index('-o') + 1] = str(root / 'bin' / (variant + '_' + kind))
        static = []
        for arg in args:
            if arg.endswith('ivf_legacy_matrix_test.cc.o'): static.append(str(obj))
            elif arg.endswith('.dylib'): static += ['-Wl,-force_load', re.sub(r'\.\d+\.\d+\.\d+\.dylib$', '.a', arg)]
            elif not arg.startswith('-Wl,-rpath,'): static.append(arg)
        subprocess.run(static, cwd=build, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print('built', variant, kind, flush=True)
