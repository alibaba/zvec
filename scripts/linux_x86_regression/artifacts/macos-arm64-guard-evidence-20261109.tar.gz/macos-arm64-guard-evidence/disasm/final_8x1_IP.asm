00000001000bfdb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bfdb0:     	stp	x24, x23, [sp, #-48]!
1000bfdb4:     	stp	x22, x21, [sp, #16]
1000bfdb8:     	stp	x20, x19, [sp, #32]
1000bfdbc:     	movi.2d	v0, #0000000000000000
1000bfdc0:     	stp	q0, q0, [x3]
1000bfdc4:     	lsl	x8, x4, #2
1000bfdc8:     	cmp	x2, #8
1000bfdcc:     	b.hs	0x1000bfdd8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bfdd0:     	mov	x13, #0
1000bfdd4:     	b	0x1000c01d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bfdd8:     	mov	x10, #0
1000bfddc:     	add	x9, x0, #16
1000bfde0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bfde4:     	add	x11, x11, #956
1000bfde8:     	mov	x12, x1
1000bfdec:     	ldr	w5, [x12]
1000bfdf0:     	lsr	x13, x5, #24
1000bfdf4:     	and	x13, x13, #0xf0
1000bfdf8:     	lsr	x14, x5, #20
1000bfdfc:     	and	x14, x14, #0xf0
1000bfe00:     	add	x13, x11, x13
1000bfe04:     	add	x14, x11, x14
1000bfe08:     	lsr	x15, x5, #16
1000bfe0c:     	and	x15, x15, #0xf0
1000bfe10:     	lsr	x16, x5, #12
1000bfe14:     	and	x6, x16, #0xf0
1000bfe18:     	add	x15, x11, x15
1000bfe1c:     	lsr	x16, x5, #8
1000bfe20:     	and	x16, x16, #0xf0
1000bfe24:     	add	x16, x11, x16
1000bfe28:     	lsr	x17, x5, #4
1000bfe2c:     	and	x17, x17, #0xf0
1000bfe30:     	add	x17, x11, x17
1000bfe34:     	and	x4, x5, #0xf0
1000bfe38:     	add	x4, x11, x4
1000bfe3c:     	lsl	w5, w5, #4
1000bfe40:     	and	x5, x5, #0xf0
1000bfe44:     	ldur	w7, [x9, #-16]
1000bfe48:     	add	x5, x11, x5
1000bfe4c:     	and	x19, x7, #0xf
1000bfe50:     	ubfx	x20, x7, #4, #4
1000bfe54:     	ldrsb	w20, [x4, x20]
1000bfe58:     	ldrsb	w19, [x5, x19]
1000bfe5c:     	ubfx	x21, x7, #8, #4
1000bfe60:     	ldrsb	w21, [x17, x21]
1000bfe64:     	ubfx	x22, x7, #12, #4
1000bfe68:     	ldrsb	w22, [x16, x22]
1000bfe6c:     	add	x6, x11, x6
1000bfe70:     	ubfx	x23, x7, #16, #4
1000bfe74:     	ldrsb	w23, [x6, x23]
1000bfe78:     	add	w19, w19, w20
1000bfe7c:     	add	w19, w19, w21
1000bfe80:     	ubfx	x20, x7, #20, #4
1000bfe84:     	ldrsb	w20, [x15, x20]
1000bfe88:     	ubfx	x21, x7, #24, #4
1000bfe8c:     	add	w19, w19, w22
1000bfe90:     	add	w19, w19, w23
1000bfe94:     	ldrsb	w21, [x14, x21]
1000bfe98:     	lsr	x7, x7, #28
1000bfe9c:     	ldrsb	w7, [x13, x7]
1000bfea0:     	add	w19, w19, w20
1000bfea4:     	add	w19, w19, w21
1000bfea8:     	add	w7, w19, w7
1000bfeac:     	scvtf	s0, w7
1000bfeb0:     	ldp	s1, s2, [x3]
1000bfeb4:     	fadd	s0, s1, s0
1000bfeb8:     	str	s0, [x3]
1000bfebc:     	ldur	w7, [x9, #-12]
1000bfec0:     	and	x19, x7, #0xf
1000bfec4:     	ldrsb	w19, [x5, x19]
1000bfec8:     	ubfx	x20, x7, #4, #4
1000bfecc:     	ldrsb	w20, [x4, x20]
1000bfed0:     	ubfx	x21, x7, #8, #4
1000bfed4:     	ldrsb	w21, [x17, x21]
1000bfed8:     	ubfx	x22, x7, #12, #4
1000bfedc:     	ldrsb	w22, [x16, x22]
1000bfee0:     	ubfx	x23, x7, #16, #4
1000bfee4:     	add	w19, w19, w20
1000bfee8:     	add	w19, w19, w21
1000bfeec:     	ldrsb	w20, [x6, x23]
1000bfef0:     	ubfx	x21, x7, #20, #4
1000bfef4:     	ldrsb	w21, [x15, x21]
1000bfef8:     	add	w19, w19, w22
1000bfefc:     	add	w19, w19, w20
1000bff00:     	ubfx	x20, x7, #24, #4
1000bff04:     	ldrsb	w20, [x14, x20]
1000bff08:     	add	w19, w19, w21
1000bff0c:     	add	w19, w19, w20
1000bff10:     	lsr	x7, x7, #28
1000bff14:     	ldrsb	w7, [x13, x7]
1000bff18:     	add	w7, w19, w7
1000bff1c:     	scvtf	s0, w7
1000bff20:     	fadd	s0, s2, s0
1000bff24:     	str	s0, [x3, #4]
1000bff28:     	ldur	w7, [x9, #-8]
1000bff2c:     	and	x19, x7, #0xf
1000bff30:     	ldrsb	w19, [x5, x19]
1000bff34:     	ubfx	x20, x7, #4, #4
1000bff38:     	ldrsb	w20, [x4, x20]
1000bff3c:     	ubfx	x21, x7, #8, #4
1000bff40:     	ldrsb	w21, [x17, x21]
1000bff44:     	ubfx	x22, x7, #12, #4
1000bff48:     	ldrsb	w22, [x16, x22]
1000bff4c:     	ubfx	x23, x7, #16, #4
1000bff50:     	add	w19, w19, w20
1000bff54:     	add	w19, w19, w21
1000bff58:     	ldrsb	w20, [x6, x23]
1000bff5c:     	ubfx	x21, x7, #20, #4
1000bff60:     	ldrsb	w21, [x15, x21]
1000bff64:     	add	w19, w19, w22
1000bff68:     	add	w19, w19, w20
1000bff6c:     	ubfx	x20, x7, #24, #4
1000bff70:     	ldrsb	w20, [x14, x20]
1000bff74:     	add	w19, w19, w21
1000bff78:     	add	w19, w19, w20
1000bff7c:     	lsr	x7, x7, #28
1000bff80:     	ldrsb	w7, [x13, x7]
1000bff84:     	add	w7, w19, w7
1000bff88:     	scvtf	s0, w7
1000bff8c:     	ldp	s1, s2, [x3, #8]
1000bff90:     	fadd	s0, s1, s0
1000bff94:     	str	s0, [x3, #8]
1000bff98:     	ldur	w7, [x9, #-4]
1000bff9c:     	and	x19, x7, #0xf
1000bffa0:     	ldrsb	w19, [x5, x19]
1000bffa4:     	ubfx	x20, x7, #4, #4
1000bffa8:     	ldrsb	w20, [x4, x20]
1000bffac:     	ubfx	x21, x7, #8, #4
1000bffb0:     	ldrsb	w21, [x17, x21]
1000bffb4:     	ubfx	x22, x7, #12, #4
1000bffb8:     	ldrsb	w22, [x16, x22]
1000bffbc:     	ubfx	x23, x7, #16, #4
1000bffc0:     	ldrsb	w23, [x6, x23]
1000bffc4:     	ubfx	x24, x7, #20, #4
1000bffc8:     	add	w19, w19, w20
1000bffcc:     	add	w19, w19, w21
1000bffd0:     	ldrsb	w20, [x15, x24]
1000bffd4:     	ubfx	x21, x7, #24, #4
1000bffd8:     	ldrsb	w21, [x14, x21]
1000bffdc:     	add	w19, w19, w22
1000bffe0:     	add	w19, w19, w23
1000bffe4:     	lsr	x7, x7, #28
1000bffe8:     	ldrsb	w7, [x13, x7]
1000bffec:     	add	w19, w19, w20
1000bfff0:     	add	w19, w19, w21
1000bfff4:     	add	w7, w19, w7
1000bfff8:     	scvtf	s0, w7
1000bfffc:     	fadd	s0, s2, s0
1000c0000:     	str	s0, [x3, #12]
1000c0004:     	ldr	w7, [x9]
1000c0008:     	and	x19, x7, #0xf
1000c000c:     	ldrsb	w19, [x5, x19]
1000c0010:     	ubfx	x20, x7, #4, #4
1000c0014:     	ldrsb	w20, [x4, x20]
1000c0018:     	ubfx	x21, x7, #8, #4
1000c001c:     	ldrsb	w21, [x17, x21]
1000c0020:     	ubfx	x22, x7, #12, #4
1000c0024:     	ldrsb	w22, [x16, x22]
1000c0028:     	ubfx	x23, x7, #16, #4
1000c002c:     	ldrsb	w23, [x6, x23]
1000c0030:     	add	w19, w19, w20
1000c0034:     	add	w19, w19, w21
1000c0038:     	ubfx	x20, x7, #20, #4
1000c003c:     	ldrsb	w20, [x15, x20]
1000c0040:     	ubfx	x21, x7, #24, #4
1000c0044:     	add	w19, w19, w22
1000c0048:     	add	w19, w19, w23
1000c004c:     	ldrsb	w21, [x14, x21]
1000c0050:     	lsr	x7, x7, #28
1000c0054:     	ldrsb	w7, [x13, x7]
1000c0058:     	add	w19, w19, w20
1000c005c:     	add	w19, w19, w21
1000c0060:     	add	w7, w19, w7
1000c0064:     	scvtf	s0, w7
1000c0068:     	ldp	s1, s2, [x3, #16]
1000c006c:     	fadd	s0, s1, s0
1000c0070:     	str	s0, [x3, #16]
1000c0074:     	ldr	w7, [x9, #4]
1000c0078:     	and	x19, x7, #0xf
1000c007c:     	ldrsb	w19, [x5, x19]
1000c0080:     	ubfx	x20, x7, #4, #4
1000c0084:     	ldrsb	w20, [x4, x20]
1000c0088:     	ubfx	x21, x7, #8, #4
1000c008c:     	ldrsb	w21, [x17, x21]
1000c0090:     	ubfx	x22, x7, #12, #4
1000c0094:     	ldrsb	w22, [x16, x22]
1000c0098:     	ubfx	x23, x7, #16, #4
1000c009c:     	add	w19, w19, w20
1000c00a0:     	add	w19, w19, w21
1000c00a4:     	ldrsb	w20, [x6, x23]
1000c00a8:     	ubfx	x21, x7, #20, #4
1000c00ac:     	ldrsb	w21, [x15, x21]
1000c00b0:     	add	w19, w19, w22
1000c00b4:     	add	w19, w19, w20
1000c00b8:     	ubfx	x20, x7, #24, #4
1000c00bc:     	ldrsb	w20, [x14, x20]
1000c00c0:     	add	w19, w19, w21
1000c00c4:     	add	w19, w19, w20
1000c00c8:     	lsr	x7, x7, #28
1000c00cc:     	ldrsb	w7, [x13, x7]
1000c00d0:     	add	w7, w19, w7
1000c00d4:     	scvtf	s0, w7
1000c00d8:     	fadd	s0, s2, s0
1000c00dc:     	str	s0, [x3, #20]
1000c00e0:     	ldr	w7, [x9, #8]
1000c00e4:     	and	x19, x7, #0xf
1000c00e8:     	ldrsb	w19, [x5, x19]
1000c00ec:     	ubfx	x20, x7, #4, #4
1000c00f0:     	ldrsb	w20, [x4, x20]
1000c00f4:     	ubfx	x21, x7, #8, #4
1000c00f8:     	ldrsb	w21, [x17, x21]
1000c00fc:     	ubfx	x22, x7, #12, #4
1000c0100:     	ldrsb	w22, [x16, x22]
1000c0104:     	ubfx	x23, x7, #16, #4
1000c0108:     	add	w19, w19, w20
1000c010c:     	add	w19, w19, w21
1000c0110:     	ldrsb	w20, [x6, x23]
1000c0114:     	ubfx	x21, x7, #20, #4
1000c0118:     	ldrsb	w21, [x15, x21]
1000c011c:     	add	w19, w19, w22
1000c0120:     	add	w19, w19, w20
1000c0124:     	ubfx	x20, x7, #24, #4
1000c0128:     	ldrsb	w20, [x14, x20]
1000c012c:     	add	w19, w19, w21
1000c0130:     	add	w19, w19, w20
1000c0134:     	lsr	x7, x7, #28
1000c0138:     	ldrsb	w7, [x13, x7]
1000c013c:     	add	w7, w19, w7
1000c0140:     	scvtf	s0, w7
1000c0144:     	ldp	s1, s2, [x3, #24]
1000c0148:     	fadd	s0, s1, s0
1000c014c:     	str	s0, [x3, #24]
1000c0150:     	ldr	w7, [x9, #12]
1000c0154:     	and	x19, x7, #0xf
1000c0158:     	ldrsb	w5, [x5, x19]
1000c015c:     	ubfx	x19, x7, #4, #4
1000c0160:     	ldrsb	w4, [x4, x19]
1000c0164:     	ubfx	x19, x7, #8, #4
1000c0168:     	ldrsb	w17, [x17, x19]
1000c016c:     	ubfx	x19, x7, #12, #4
1000c0170:     	ldrsb	w16, [x16, x19]
1000c0174:     	ubfx	x19, x7, #16, #4
1000c0178:     	ldrsb	w6, [x6, x19]
1000c017c:     	add	w4, w5, w4
1000c0180:     	add	w17, w4, w17
1000c0184:     	ubfx	x4, x7, #20, #4
1000c0188:     	ldrsb	w15, [x15, x4]
1000c018c:     	ubfx	x4, x7, #24, #4
1000c0190:     	add	w16, w17, w16
1000c0194:     	add	w16, w16, w6
1000c0198:     	ldrsb	w14, [x14, x4]
1000c019c:     	lsr	x17, x7, #28
1000c01a0:     	ldrsb	w13, [x13, x17]
1000c01a4:     	add	w15, w16, w15
1000c01a8:     	add	w14, w15, w14
1000c01ac:     	add	w13, w14, w13
1000c01b0:     	scvtf	s0, w13
1000c01b4:     	fadd	s0, s2, s0
1000c01b8:     	str	s0, [x3, #28]
1000c01bc:     	add	x13, x10, #8
1000c01c0:     	add	x12, x12, x8
1000c01c4:     	add	x14, x10, #16
1000c01c8:     	add	x9, x9, #32
1000c01cc:     	mov	x10, x13
1000c01d0:     	cmp	x14, x2
1000c01d4:     	b.ls	0x1000bfdec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000c01d8:     	cmp	x13, x2
1000c01dc:     	b.hs	0x1000c0370 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5c0>
1000c01e0:     	ldp	s0, s1, [x3, #8]
1000c01e4:     	lsl	x9, x13, #2
1000c01e8:     	mov	w10, #-16
1000c01ec:     	ldr	s2, [x3, #16]
1000c01f0:     	lsr	x11, x13, #3
1000c01f4:     	mul	x12, x8, x11
1000c01f8:     	ubfx	x11, x13, #1, #2
1000c01fc:     	orr	x14, x12, x11
1000c0200:     	and	w12, w9, #0x4
1000c0204:     	ldrb	w14, [x1, x14]
1000c0208:     	lsr	w14, w14, w12
1000c020c:     	and	w15, w14, #0xf
1000c0210:     	cmp	w15, #8
1000c0214:     	csel	w15, wzr, w10, lo
1000c0218:     	and	x16, x9, #0xffffffffffffffe0
1000c021c:     	bfxil	w15, w14, #0, #4
1000c0220:     	bfxil	x16, x13, #1, #2
1000c0224:     	add	x14, x0, x16
1000c0228:     	ldrb	w16, [x14]
1000c022c:     	lsr	w16, w16, w12
1000c0230:     	scvtf	s3, w15
1000c0234:     	and	w15, w16, #0xf
1000c0238:     	cmp	w15, #8
1000c023c:     	csel	w15, wzr, w10, lo
1000c0240:     	bfxil	w15, w16, #0, #4
1000c0244:     	scvtf	s4, w15
1000c0248:     	ldp	s5, s6, [x3]
1000c024c:     	fmsub	s4, s4, s3, s5
1000c0250:     	str	s4, [x3]
1000c0254:     	ldrb	w15, [x14, #4]
1000c0258:     	lsr	w15, w15, w12
1000c025c:     	and	w16, w15, #0xf
1000c0260:     	cmp	w16, #8
1000c0264:     	csel	w16, wzr, w10, lo
1000c0268:     	bfxil	w16, w15, #0, #4
1000c026c:     	scvtf	s4, w16
1000c0270:     	fmsub	s4, s4, s3, s6
1000c0274:     	str	s4, [x3, #4]
1000c0278:     	ldrb	w15, [x14, #8]
1000c027c:     	lsr	w15, w15, w12
1000c0280:     	and	w16, w15, #0xf
1000c0284:     	cmp	w16, #8
1000c0288:     	csel	w16, wzr, w10, lo
1000c028c:     	bfxil	w16, w15, #0, #4
1000c0290:     	scvtf	s4, w16
1000c0294:     	fmsub	s0, s4, s3, s0
1000c0298:     	str	s0, [x3, #8]
1000c029c:     	ldrb	w15, [x14, #12]
1000c02a0:     	lsr	w15, w15, w12
1000c02a4:     	and	w16, w15, #0xf
1000c02a8:     	cmp	w16, #8
1000c02ac:     	csel	w16, wzr, w10, lo
1000c02b0:     	bfxil	w16, w15, #0, #4
1000c02b4:     	scvtf	s4, w16
1000c02b8:     	fmsub	s1, s4, s3, s1
1000c02bc:     	str	s1, [x3, #12]
1000c02c0:     	ldrb	w15, [x14, #16]
1000c02c4:     	lsr	w15, w15, w12
1000c02c8:     	and	w16, w15, #0xf
1000c02cc:     	cmp	w16, #8
1000c02d0:     	csel	w16, wzr, w10, lo
1000c02d4:     	bfxil	w16, w15, #0, #4
1000c02d8:     	scvtf	s4, w16
1000c02dc:     	fmsub	s2, s4, s3, s2
1000c02e0:     	str	s2, [x3, #16]
1000c02e4:     	ldrb	w15, [x14, #20]
1000c02e8:     	lsr	w15, w15, w12
1000c02ec:     	and	w16, w15, #0xf
1000c02f0:     	cmp	w16, #8
1000c02f4:     	csel	w16, wzr, w10, lo
1000c02f8:     	bfxil	w16, w15, #0, #4
1000c02fc:     	scvtf	s4, w16
1000c0300:     	ldp	s5, s6, [x3, #20]
1000c0304:     	fmsub	s4, s4, s3, s5
1000c0308:     	str	s4, [x3, #20]
1000c030c:     	ldrb	w14, [x14, #24]
1000c0310:     	lsr	w14, w14, w12
1000c0314:     	and	w15, w14, #0xf
1000c0318:     	cmp	w15, #8
1000c031c:     	csel	w15, wzr, w10, lo
1000c0320:     	bfxil	w15, w14, #0, #4
1000c0324:     	scvtf	s4, w15
1000c0328:     	fmsub	s4, s4, s3, s6
1000c032c:     	str	s4, [x3, #24]
1000c0330:     	orr	x11, x9, x11
1000c0334:     	orr	x11, x11, #0x1c
1000c0338:     	ldrb	w11, [x0, x11]
1000c033c:     	lsr	w11, w11, w12
1000c0340:     	and	w12, w11, #0xf
1000c0344:     	cmp	w12, #8
1000c0348:     	csel	w12, wzr, w10, lo
1000c034c:     	bfxil	w12, w11, #0, #4
1000c0350:     	scvtf	s4, w12
1000c0354:     	ldr	s5, [x3, #28]
1000c0358:     	fmsub	s3, s4, s3, s5
1000c035c:     	str	s3, [x3, #28]
1000c0360:     	add	x13, x13, #1
1000c0364:     	add	x9, x9, #4
1000c0368:     	cmp	x2, x13
1000c036c:     	b.ne	0x1000c01f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000c0370:     	ldp	x20, x19, [sp, #32]
1000c0374:     	ldp	x22, x21, [sp, #16]
1000c0378:     	ldp	x24, x23, [sp], #48
1000c037c:     	ret

