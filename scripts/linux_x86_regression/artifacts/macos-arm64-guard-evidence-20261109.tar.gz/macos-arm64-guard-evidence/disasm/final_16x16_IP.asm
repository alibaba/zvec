00000001000cedc0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cedc0:     	stp	x28, x27, [sp, #-64]!
1000cedc4:     	stp	x22, x21, [sp, #16]
1000cedc8:     	stp	x20, x19, [sp, #32]
1000cedcc:     	stp	x29, x30, [sp, #48]
1000cedd0:     	add	x29, sp, #48
1000cedd4:     	sub	sp, sp, #1040
1000cedd8:     	mov	x19, x3
1000ceddc:     	mov	x20, x1
1000cede0:     	mov	x21, x0
1000cede4:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0xf8>
1000cede8:     	ldr	x8, [x8, #392]
1000cedec:     	ldr	x8, [x8]
1000cedf0:     	stur	x8, [x29, #-56]
1000cedf4:     	lsl	x8, x2, #3
1000cedf8:     	and	x22, x8, #0xfffffffffffffff0
1000cedfc:     	add	x0, sp, #8
1000cee00:     	mov	w1, #1024
1000cee04:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000cee08:     	cbz	x22, 0x1000cef20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000cee0c:     	add	x8, x20, x22
1000cee10:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x11c>
1000cee14:     	add	x9, x9, #1468
1000cee18:     	mov	x10, #0
1000cee1c:     	add	x11, sp, #8
1000cee20:     	mov	x12, #0
1000cee24:     	ldr	w2, [x21, x10, lsl #2]
1000cee28:     	lsl	w13, w2, #4
1000cee2c:     	and	x13, x13, #0xf0
1000cee30:     	and	x14, x2, #0xf0
1000cee34:     	lsr	x15, x2, #4
1000cee38:     	and	x15, x15, #0xf0
1000cee3c:     	lsr	x16, x2, #8
1000cee40:     	and	x16, x16, #0xf0
1000cee44:     	lsr	x17, x2, #12
1000cee48:     	and	x17, x17, #0xf0
1000cee4c:     	lsr	x0, x2, #16
1000cee50:     	and	x0, x0, #0xf0
1000cee54:     	lsr	x1, x2, #20
1000cee58:     	and	x1, x1, #0xf0
1000cee5c:     	lsr	x2, x2, #24
1000cee60:     	and	x2, x2, #0xf0
1000cee64:     	mov	x3, x11
1000cee68:     	ldr	w4, [x20, x12]
1000cee6c:     	and	x5, x4, #0xf
1000cee70:     	orr	x5, x13, x5
1000cee74:     	ldrsb	w5, [x9, x5]
1000cee78:     	ubfx	x6, x4, #4, #4
1000cee7c:     	orr	x6, x14, x6
1000cee80:     	ldrsb	w6, [x9, x6]
1000cee84:     	ubfx	x7, x4, #8, #4
1000cee88:     	orr	x7, x15, x7
1000cee8c:     	ldrsb	w7, [x9, x7]
1000cee90:     	add	w5, w5, w6
1000cee94:     	add	w5, w5, w7
1000cee98:     	ubfx	x6, x4, #12, #4
1000cee9c:     	orr	x6, x16, x6
1000ceea0:     	ldrsb	w6, [x9, x6]
1000ceea4:     	ubfx	x7, x4, #16, #4
1000ceea8:     	orr	x7, x17, x7
1000ceeac:     	ldrsb	w7, [x9, x7]
1000ceeb0:     	add	w5, w5, w6
1000ceeb4:     	add	w5, w5, w7
1000ceeb8:     	ubfx	x6, x4, #20, #4
1000ceebc:     	orr	x6, x0, x6
1000ceec0:     	ldrsb	w6, [x9, x6]
1000ceec4:     	ubfx	x7, x4, #24, #4
1000ceec8:     	orr	x7, x1, x7
1000ceecc:     	ldrsb	w7, [x9, x7]
1000ceed0:     	add	w5, w5, w6
1000ceed4:     	add	w5, w5, w7
1000ceed8:     	orr	x4, x2, x4, lsr #28
1000ceedc:     	ldrsb	w4, [x9, x4]
1000ceee0:     	add	w4, w5, w4
1000ceee4:     	scvtf	s0, w4
1000ceee8:     	ldr	s1, [x3]
1000ceeec:     	fadd	s0, s1, s0
1000ceef0:     	str	s0, [x3], #64
1000ceef4:     	add	x12, x12, #4
1000ceef8:     	cmp	x12, #64
1000ceefc:     	b.ne	0x1000cee68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000cef00:     	add	x10, x10, #1
1000cef04:     	add	x11, x11, #4
1000cef08:     	cmp	x10, #16
1000cef0c:     	b.ne	0x1000cee20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000cef10:     	add	x21, x21, #64
1000cef14:     	add	x20, x20, #64
1000cef18:     	cmp	x20, x8
1000cef1c:     	b.ne	0x1000cee18 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000cef20:     	add	x1, sp, #8
1000cef24:     	mov	x0, x19
1000cef28:     	mov	w2, #1024
1000cef2c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000cef30:     	ldur	x8, [x29, #-56]
1000cef34:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x248>
1000cef38:     	ldr	x9, [x9, #392]
1000cef3c:     	ldr	x9, [x9]
1000cef40:     	cmp	x9, x8
1000cef44:     	b.ne	0x1000cef60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000cef48:     	add	sp, sp, #1040
1000cef4c:     	ldp	x29, x30, [sp, #48]
1000cef50:     	ldp	x20, x19, [sp, #32]
1000cef54:     	ldp	x22, x21, [sp, #16]
1000cef58:     	ldp	x28, x27, [sp], #64
1000cef5c:     	ret
1000cef60:     	bl	0x100163694 <_strcmp+0x100163694>

