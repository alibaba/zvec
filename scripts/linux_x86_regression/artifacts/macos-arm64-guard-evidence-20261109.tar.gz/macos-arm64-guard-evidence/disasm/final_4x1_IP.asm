00000001000ba220 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000ba220:     	stp	x24, x23, [sp, #-48]!
1000ba224:     	stp	x22, x21, [sp, #16]
1000ba228:     	stp	x20, x19, [sp, #32]
1000ba22c:     	stp	xzr, xzr, [x3]
1000ba230:     	lsl	x8, x4, #2
1000ba234:     	cmp	x2, #8
1000ba238:     	b.hs	0x1000ba24c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000ba23c:     	mov	x13, #0
1000ba240:     	movi	d1, #0000000000000000
1000ba244:     	movi	d0, #0000000000000000
1000ba248:     	b	0x1000ba494 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000ba24c:     	mov	x10, #0
1000ba250:     	add	x9, x0, #8
1000ba254:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f4>
1000ba258:     	add	x11, x11, #444
1000ba25c:     	mov	x12, x1
1000ba260:     	ldr	w5, [x12]
1000ba264:     	lsl	w13, w5, #4
1000ba268:     	and	x14, x13, #0xf0
1000ba26c:     	and	x13, x5, #0xf0
1000ba270:     	add	x13, x11, x13
1000ba274:     	add	x14, x11, x14
1000ba278:     	lsr	x15, x5, #4
1000ba27c:     	and	x15, x15, #0xf0
1000ba280:     	add	x15, x11, x15
1000ba284:     	lsr	x16, x5, #8
1000ba288:     	and	x16, x16, #0xf0
1000ba28c:     	add	x16, x11, x16
1000ba290:     	lsr	x17, x5, #12
1000ba294:     	and	x17, x17, #0xf0
1000ba298:     	add	x17, x11, x17
1000ba29c:     	lsr	x4, x5, #16
1000ba2a0:     	and	x4, x4, #0xf0
1000ba2a4:     	add	x4, x11, x4
1000ba2a8:     	lsr	x6, x5, #20
1000ba2ac:     	and	x6, x6, #0xf0
1000ba2b0:     	lsr	x5, x5, #24
1000ba2b4:     	and	x7, x5, #0xf0
1000ba2b8:     	ldur	w19, [x9, #-8]
1000ba2bc:     	add	x5, x11, x6
1000ba2c0:     	and	x6, x19, #0xf
1000ba2c4:     	ubfx	x20, x19, #4, #4
1000ba2c8:     	ldrsb	w20, [x13, x20]
1000ba2cc:     	ldrsb	w21, [x14, x6]
1000ba2d0:     	ubfx	x6, x19, #8, #4
1000ba2d4:     	ldrsb	w22, [x15, x6]
1000ba2d8:     	ubfx	x6, x19, #12, #4
1000ba2dc:     	ldrsb	w23, [x16, x6]
1000ba2e0:     	add	x6, x11, x7
1000ba2e4:     	ubfx	x7, x19, #16, #4
1000ba2e8:     	ldrsb	w7, [x17, x7]
1000ba2ec:     	add	w20, w21, w20
1000ba2f0:     	add	w20, w20, w22
1000ba2f4:     	ubfx	x21, x19, #20, #4
1000ba2f8:     	ldrsb	w21, [x4, x21]
1000ba2fc:     	ubfx	x22, x19, #24, #4
1000ba300:     	add	w20, w20, w23
1000ba304:     	add	w7, w20, w7
1000ba308:     	ldrsb	w20, [x5, x22]
1000ba30c:     	lsr	x19, x19, #28
1000ba310:     	ldrsb	w19, [x6, x19]
1000ba314:     	add	w7, w7, w21
1000ba318:     	add	w7, w7, w20
1000ba31c:     	add	w7, w7, w19
1000ba320:     	scvtf	s0, w7
1000ba324:     	ldp	s1, s2, [x3]
1000ba328:     	fadd	s0, s1, s0
1000ba32c:     	str	s0, [x3]
1000ba330:     	ldur	w7, [x9, #-4]
1000ba334:     	and	x19, x7, #0xf
1000ba338:     	ldrsb	w19, [x14, x19]
1000ba33c:     	ubfx	x20, x7, #4, #4
1000ba340:     	ldrsb	w20, [x13, x20]
1000ba344:     	ubfx	x21, x7, #8, #4
1000ba348:     	ldrsb	w21, [x15, x21]
1000ba34c:     	ubfx	x22, x7, #12, #4
1000ba350:     	ldrsb	w22, [x16, x22]
1000ba354:     	ubfx	x23, x7, #16, #4
1000ba358:     	add	w19, w19, w20
1000ba35c:     	add	w19, w19, w21
1000ba360:     	ldrsb	w20, [x17, x23]
1000ba364:     	ubfx	x21, x7, #20, #4
1000ba368:     	ldrsb	w21, [x4, x21]
1000ba36c:     	add	w19, w19, w22
1000ba370:     	add	w19, w19, w20
1000ba374:     	ubfx	x20, x7, #24, #4
1000ba378:     	ldrsb	w20, [x5, x20]
1000ba37c:     	add	w19, w19, w21
1000ba380:     	add	w19, w19, w20
1000ba384:     	lsr	x7, x7, #28
1000ba388:     	ldrsb	w7, [x6, x7]
1000ba38c:     	add	w7, w19, w7
1000ba390:     	scvtf	s0, w7
1000ba394:     	fadd	s0, s2, s0
1000ba398:     	str	s0, [x3, #4]
1000ba39c:     	ldr	w7, [x9]
1000ba3a0:     	and	x19, x7, #0xf
1000ba3a4:     	ldrsb	w19, [x14, x19]
1000ba3a8:     	ubfx	x20, x7, #4, #4
1000ba3ac:     	ldrsb	w20, [x13, x20]
1000ba3b0:     	ubfx	x21, x7, #8, #4
1000ba3b4:     	ldrsb	w21, [x15, x21]
1000ba3b8:     	ubfx	x22, x7, #12, #4
1000ba3bc:     	ldrsb	w22, [x16, x22]
1000ba3c0:     	ubfx	x23, x7, #16, #4
1000ba3c4:     	add	w19, w19, w20
1000ba3c8:     	add	w19, w19, w21
1000ba3cc:     	ldrsb	w20, [x17, x23]
1000ba3d0:     	ubfx	x21, x7, #20, #4
1000ba3d4:     	ldrsb	w21, [x4, x21]
1000ba3d8:     	add	w19, w19, w22
1000ba3dc:     	add	w19, w19, w20
1000ba3e0:     	ubfx	x20, x7, #24, #4
1000ba3e4:     	ldrsb	w20, [x5, x20]
1000ba3e8:     	add	w19, w19, w21
1000ba3ec:     	add	w19, w19, w20
1000ba3f0:     	lsr	x7, x7, #28
1000ba3f4:     	ldrsb	w7, [x6, x7]
1000ba3f8:     	add	w7, w19, w7
1000ba3fc:     	scvtf	s0, w7
1000ba400:     	ldp	s1, s2, [x3, #8]
1000ba404:     	fadd	s0, s1, s0
1000ba408:     	str	s0, [x3, #8]
1000ba40c:     	ldr	w7, [x9, #4]
1000ba410:     	and	x19, x7, #0xf
1000ba414:     	ldrsb	w14, [x14, x19]
1000ba418:     	ubfx	x19, x7, #4, #4
1000ba41c:     	ldrsb	w13, [x13, x19]
1000ba420:     	ubfx	x19, x7, #8, #4
1000ba424:     	ldrsb	w15, [x15, x19]
1000ba428:     	ubfx	x19, x7, #12, #4
1000ba42c:     	ldrsb	w16, [x16, x19]
1000ba430:     	ubfx	x19, x7, #16, #4
1000ba434:     	ldrsb	w17, [x17, x19]
1000ba438:     	add	w13, w14, w13
1000ba43c:     	add	w13, w13, w15
1000ba440:     	ubfx	x14, x7, #20, #4
1000ba444:     	ldrsb	w14, [x4, x14]
1000ba448:     	ubfx	x15, x7, #24, #4
1000ba44c:     	add	w13, w13, w16
1000ba450:     	add	w13, w13, w17
1000ba454:     	ldrsb	w15, [x5, x15]
1000ba458:     	lsr	x16, x7, #28
1000ba45c:     	ldrsb	w16, [x6, x16]
1000ba460:     	add	w13, w13, w14
1000ba464:     	add	w13, w13, w15
1000ba468:     	add	w13, w13, w16
1000ba46c:     	scvtf	s1, w13
1000ba470:     	fadd	s1, s2, s1
1000ba474:     	str	s1, [x3, #12]
1000ba478:     	add	x13, x10, #8
1000ba47c:     	add	x12, x12, x8
1000ba480:     	add	x9, x9, #16
1000ba484:     	add	x14, x10, #16
1000ba488:     	mov	x10, x13
1000ba48c:     	cmp	x14, x2
1000ba490:     	b.ls	0x1000ba260 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000ba494:     	cmp	x13, x2
1000ba498:     	b.hs	0x1000ba580 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x360>
1000ba49c:     	ldp	s2, s3, [x3]
1000ba4a0:     	lsl	w9, w13, #2
1000ba4a4:     	mov	w10, #-16
1000ba4a8:     	lsr	x11, x13, #3
1000ba4ac:     	mul	x12, x8, x11
1000ba4b0:     	ubfx	x14, x13, #1, #2
1000ba4b4:     	orr	x12, x12, x14
1000ba4b8:     	ldrb	w12, [x1, x12]
1000ba4bc:     	and	w15, w9, #0x4
1000ba4c0:     	lsr	w12, w12, w15
1000ba4c4:     	and	w16, w12, #0xf
1000ba4c8:     	cmp	w16, #8
1000ba4cc:     	csel	w16, wzr, w10, lo
1000ba4d0:     	bfxil	w16, w12, #0, #4
1000ba4d4:     	bfi	x14, x11, #4, #60
1000ba4d8:     	add	x11, x0, x14
1000ba4dc:     	ldrb	w12, [x11]
1000ba4e0:     	lsr	w12, w12, w15
1000ba4e4:     	scvtf	s4, w16
1000ba4e8:     	and	w14, w12, #0xf
1000ba4ec:     	cmp	w14, #8
1000ba4f0:     	csel	w14, wzr, w10, lo
1000ba4f4:     	bfxil	w14, w12, #0, #4
1000ba4f8:     	scvtf	s5, w14
1000ba4fc:     	fmsub	s2, s5, s4, s2
1000ba500:     	str	s2, [x3]
1000ba504:     	ldrb	w12, [x11, #4]
1000ba508:     	lsr	w12, w12, w15
1000ba50c:     	and	w14, w12, #0xf
1000ba510:     	cmp	w14, #8
1000ba514:     	csel	w14, wzr, w10, lo
1000ba518:     	bfxil	w14, w12, #0, #4
1000ba51c:     	scvtf	s5, w14
1000ba520:     	fmsub	s3, s5, s4, s3
1000ba524:     	str	s3, [x3, #4]
1000ba528:     	ldrb	w12, [x11, #8]
1000ba52c:     	lsr	w12, w12, w15
1000ba530:     	and	w14, w12, #0xf
1000ba534:     	cmp	w14, #8
1000ba538:     	csel	w14, wzr, w10, lo
1000ba53c:     	bfxil	w14, w12, #0, #4
1000ba540:     	scvtf	s5, w14
1000ba544:     	fmsub	s0, s5, s4, s0
1000ba548:     	str	s0, [x3, #8]
1000ba54c:     	ldrb	w11, [x11, #12]
1000ba550:     	lsr	w11, w11, w15
1000ba554:     	and	w12, w11, #0xf
1000ba558:     	cmp	w12, #8
1000ba55c:     	csel	w12, wzr, w10, lo
1000ba560:     	bfxil	w12, w11, #0, #4
1000ba564:     	scvtf	s5, w12
1000ba568:     	fmsub	s1, s5, s4, s1
1000ba56c:     	str	s1, [x3, #12]
1000ba570:     	add	x13, x13, #1
1000ba574:     	add	w9, w9, #4
1000ba578:     	cmp	x2, x13
1000ba57c:     	b.ne	0x1000ba4a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000ba580:     	ldp	x20, x19, [sp, #32]
1000ba584:     	ldp	x22, x21, [sp, #16]
1000ba588:     	ldp	x24, x23, [sp], #48
1000ba58c:     	ret

