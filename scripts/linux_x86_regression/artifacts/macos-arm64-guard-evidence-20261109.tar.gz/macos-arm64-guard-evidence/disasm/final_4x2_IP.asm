00000001000bc378 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bc378:     	sub	sp, sp, #176
1000bc37c:     	stp	x28, x27, [sp, #80]
1000bc380:     	stp	x26, x25, [sp, #96]
1000bc384:     	stp	x24, x23, [sp, #112]
1000bc388:     	stp	x22, x21, [sp, #128]
1000bc38c:     	stp	x20, x19, [sp, #144]
1000bc390:     	stp	x29, x30, [sp, #160]
1000bc394:     	add	x29, sp, #160
1000bc398:     	str	x3, [sp]
1000bc39c:     	adrp	x8, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xb8>
1000bc3a0:     	ldr	x8, [x8, #392]
1000bc3a4:     	ldr	x8, [x8]
1000bc3a8:     	str	x8, [sp, #72]
1000bc3ac:     	movi.2d	v0, #0000000000000000
1000bc3b0:     	stp	q0, q0, [sp, #32]
1000bc3b4:     	ands	x8, x2, #0xfffffffffffffffe
1000bc3b8:     	b.eq	0x1000bc55c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bc3bc:     	add	x8, x1, x8
1000bc3c0:     	str	x8, [sp, #8]
1000bc3c4:     	adrp	x9, 0x10016a000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xd8>
1000bc3c8:     	add	x9, x9, #444
1000bc3cc:     	mov	x11, #0
1000bc3d0:     	ldp	w4, w23, [x1]
1000bc3d4:     	ubfx	x8, x4, #4, #4
1000bc3d8:     	stp	x1, x8, [sp, #16]
1000bc3dc:     	ubfx	x13, x4, #8, #4
1000bc3e0:     	and	x14, x4, #0xf
1000bc3e4:     	ubfx	x15, x4, #12, #4
1000bc3e8:     	ubfx	x16, x4, #16, #4
1000bc3ec:     	ubfx	x17, x4, #20, #4
1000bc3f0:     	ubfx	x2, x4, #24, #4
1000bc3f4:     	lsr	x4, x4, #28
1000bc3f8:     	and	x5, x23, #0xf
1000bc3fc:     	ubfx	x6, x23, #4, #4
1000bc400:     	ubfx	x7, x23, #8, #4
1000bc404:     	ubfx	x19, x23, #12, #4
1000bc408:     	ubfx	x20, x23, #16, #4
1000bc40c:     	ubfx	x21, x23, #20, #4
1000bc410:     	ubfx	x22, x23, #24, #4
1000bc414:     	lsr	x23, x23, #28
1000bc418:     	ldr	w24, [x0, x11]
1000bc41c:     	lsl	w25, w24, #4
1000bc420:     	and	x25, x25, #0xf0
1000bc424:     	orr	x26, x25, x14
1000bc428:     	ldrsb	w26, [x9, x26]
1000bc42c:     	and	x27, x24, #0xf0
1000bc430:     	ldr	x8, [sp, #24]
1000bc434:     	orr	x28, x27, x8
1000bc438:     	ldrsb	w28, [x9, x28]
1000bc43c:     	lsr	x30, x24, #4
1000bc440:     	and	x30, x30, #0xf0
1000bc444:     	orr	x8, x30, x13
1000bc448:     	ldrsb	w8, [x9, x8]
1000bc44c:     	add	w26, w26, w28
1000bc450:     	add	w8, w26, w8
1000bc454:     	lsr	x26, x24, #8
1000bc458:     	and	x26, x26, #0xf0
1000bc45c:     	orr	x28, x26, x15
1000bc460:     	ldrsb	w28, [x9, x28]
1000bc464:     	lsr	x3, x24, #12
1000bc468:     	and	x3, x3, #0xf0
1000bc46c:     	orr	x10, x3, x16
1000bc470:     	ldrsb	w10, [x9, x10]
1000bc474:     	add	w8, w8, w28
1000bc478:     	add	w8, w8, w10
1000bc47c:     	lsr	x10, x24, #16
1000bc480:     	and	x10, x10, #0xf0
1000bc484:     	orr	x28, x10, x17
1000bc488:     	ldrsb	w28, [x9, x28]
1000bc48c:     	lsr	x1, x24, #20
1000bc490:     	and	x1, x1, #0xf0
1000bc494:     	orr	x12, x1, x2
1000bc498:     	ldrsb	w12, [x9, x12]
1000bc49c:     	add	w8, w8, w28
1000bc4a0:     	add	x28, sp, #32
1000bc4a4:     	add	w8, w8, w12
1000bc4a8:     	lsr	x12, x24, #24
1000bc4ac:     	and	x12, x12, #0xf0
1000bc4b0:     	orr	x24, x12, x4
1000bc4b4:     	ldrsb	w24, [x9, x24]
1000bc4b8:     	add	w8, w8, w24
1000bc4bc:     	scvtf	s0, w8
1000bc4c0:     	add	x8, x28, x11
1000bc4c4:     	ldr	s1, [x8]
1000bc4c8:     	fadd	s0, s1, s0
1000bc4cc:     	orr	x24, x25, x5
1000bc4d0:     	ldrsb	w24, [x9, x24]
1000bc4d4:     	orr	x25, x27, x6
1000bc4d8:     	ldrsb	w25, [x9, x25]
1000bc4dc:     	orr	x27, x30, x7
1000bc4e0:     	ldrsb	w27, [x9, x27]
1000bc4e4:     	add	w24, w24, w25
1000bc4e8:     	add	w24, w24, w27
1000bc4ec:     	orr	x25, x26, x19
1000bc4f0:     	ldrsb	w25, [x9, x25]
1000bc4f4:     	orr	x3, x3, x20
1000bc4f8:     	ldrsb	w3, [x9, x3]
1000bc4fc:     	orr	x10, x10, x21
1000bc500:     	ldrsb	w10, [x9, x10]
1000bc504:     	add	w24, w24, w25
1000bc508:     	add	w3, w24, w3
1000bc50c:     	orr	x1, x1, x22
1000bc510:     	ldrsb	w1, [x9, x1]
1000bc514:     	add	w10, w3, w10
1000bc518:     	add	w10, w10, w1
1000bc51c:     	orr	x12, x12, x23
1000bc520:     	ldrsb	w12, [x9, x12]
1000bc524:     	add	w10, w10, w12
1000bc528:     	scvtf	s1, w10
1000bc52c:     	str	s0, [x8]
1000bc530:     	ldr	s0, [x8, #16]
1000bc534:     	fadd	s0, s0, s1
1000bc538:     	str	s0, [x8, #16]
1000bc53c:     	add	x11, x11, #4
1000bc540:     	cmp	x11, #16
1000bc544:     	b.ne	0x1000bc418 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bc548:     	add	x0, x0, #16
1000bc54c:     	ldp	x8, x1, [sp, #8]
1000bc550:     	add	x1, x1, #8
1000bc554:     	cmp	x1, x8
1000bc558:     	b.ne	0x1000bc3cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bc55c:     	ldp	q0, q1, [sp, #32]
1000bc560:     	ldr	x8, [sp]
1000bc564:     	stp	q0, q1, [x8]
1000bc568:     	ldr	x8, [sp, #72]
1000bc56c:     	adrp	x9, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0x288>
1000bc570:     	ldr	x9, [x9, #392]
1000bc574:     	ldr	x9, [x9]
1000bc578:     	cmp	x9, x8
1000bc57c:     	b.ne	0x1000bc5a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bc580:     	ldp	x29, x30, [sp, #160]
1000bc584:     	ldp	x20, x19, [sp, #144]
1000bc588:     	ldp	x22, x21, [sp, #128]
1000bc58c:     	ldp	x24, x23, [sp, #112]
1000bc590:     	ldp	x26, x25, [sp, #96]
1000bc594:     	ldp	x28, x27, [sp, #80]
1000bc598:     	add	sp, sp, #176
1000bc59c:     	ret
1000bc5a0:     	bl	0x100163694 <_strcmp+0x100163694>

