
/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_arm64_guard_20261109/bin/9819_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000421d8 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000421d8:     	sub	sp, sp, #80
1000421dc:     	stp	x22, x21, [sp, #32]
1000421e0:     	stp	x20, x19, [sp, #48]
1000421e4:     	stp	x29, x30, [sp, #64]
1000421e8:     	add	x29, sp, #64
1000421ec:     	mov	x19, x3
1000421f0:     	mov	x20, x2
1000421f4:     	mov	x21, x1
1000421f8:     	mov	x22, x0
1000421fc:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2d8>
100042200:     	ldr	x8, [x8, #16]
100042204:     	ldaprb	w8, [x8]
100042208:     	tbz	w8, #0, 0x100042254 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
10004220c:     	stp	x21, x22, [sp, #16]
100042210:     	stp	x19, x20, [sp]
100042214:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2f0>
100042218:     	ldr	x8, [x8, #192]
10004221c:     	ldr	x0, [x8, #24]
100042220:     	cbz	x0, 0x1000422ac <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100042224:     	ldr	x8, [x0]
100042228:     	ldr	x8, [x8, #48]
10004222c:     	add	x1, sp, #24
100042230:     	add	x2, sp, #16
100042234:     	add	x3, sp, #8
100042238:     	mov	x4, sp
10004223c:     	blr	x8
100042240:     	ldp	x29, x30, [sp, #64]
100042244:     	ldp	x20, x19, [sp, #48]
100042248:     	ldp	x22, x21, [sp, #32]
10004224c:     	add	sp, sp, #80
100042250:     	ret
100042254:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x330>
100042258:     	ldr	x0, [x0, #16]
10004225c:     	bl	0x10015f690 <_strcmp+0x10015f690>
100042260:     	cbz	w0, 0x10004220c <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100042264:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x340>
100042268:     	ldr	x8, [x8, #192]
10004226c:     	mov	w0, #0
100042270:     	mov	w1, #2
100042274:     	mov	w2, #8
100042278:     	mov	w3, #0
10004227c:     	bl	0x10015c718 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100042280:     	adrp	x0, 0x100003000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa0c>
100042284:     	add	x0, x0, #1968
100042288:     	adrp	x1, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x364>
10004228c:     	ldr	x1, [x1, #192]
100042290:     	adrp	x2, 0x100000000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa10>
100042294:     	add	x2, x2, #0
100042298:     	bl	0x10015f660 <_strcmp+0x10015f660>
10004229c:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x378>
1000422a0:     	ldr	x0, [x0, #16]
1000422a4:     	bl	0x10015f69c <_strcmp+0x10015f69c>
1000422a8:     	b	0x10004220c <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000422ac:     	bl	0x1000037fc <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000422b0:     	mov	x19, x0
1000422b4:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x390>
1000422b8:     	ldr	x0, [x0, #16]
1000422bc:     	bl	0x10015f684 <_strcmp+0x10015f684>
1000422c0:     	mov	x0, x19
1000422c4:     	bl	0x10015f5f4 <_strcmp+0x10015f5f4>

00000001000422cc <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000422cc:     	sub	sp, sp, #80
1000422d0:     	stp	x22, x21, [sp, #32]
1000422d4:     	stp	x20, x19, [sp, #48]
1000422d8:     	stp	x29, x30, [sp, #64]
1000422dc:     	add	x29, sp, #64
1000422e0:     	mov	x19, x3
1000422e4:     	mov	x20, x2
1000422e8:     	mov	x21, x1
1000422ec:     	mov	x22, x0
1000422f0:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3cc>
1000422f4:     	ldr	x8, [x8, #24]
1000422f8:     	ldaprb	w8, [x8]
1000422fc:     	tbz	w8, #0, 0x100042348 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100042300:     	stp	x21, x22, [sp, #16]
100042304:     	stp	x19, x20, [sp]
100042308:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3e4>
10004230c:     	ldr	x8, [x8, #200]
100042310:     	ldr	x0, [x8, #24]
100042314:     	cbz	x0, 0x1000423a0 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100042318:     	ldr	x8, [x0]
10004231c:     	ldr	x8, [x8, #48]
100042320:     	add	x1, sp, #24
100042324:     	add	x2, sp, #16
100042328:     	add	x3, sp, #8
10004232c:     	mov	x4, sp
100042330:     	blr	x8
100042334:     	ldp	x29, x30, [sp, #64]
100042338:     	ldp	x20, x19, [sp, #48]
10004233c:     	ldp	x22, x21, [sp, #32]
100042340:     	add	sp, sp, #80
100042344:     	ret
100042348:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x424>
10004234c:     	ldr	x0, [x0, #24]
100042350:     	bl	0x10015f690 <_strcmp+0x10015f690>
100042354:     	cbz	w0, 0x100042300 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100042358:     	adrp	x8, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x434>
10004235c:     	ldr	x8, [x8, #200]
100042360:     	mov	w0, #2
100042364:     	mov	w1, #2
100042368:     	mov	w2, #8
10004236c:     	mov	w3, #0
100042370:     	bl	0x10015c718 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100042374:     	adrp	x0, 0x100003000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa0>
100042378:     	add	x0, x0, #1968
10004237c:     	adrp	x1, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x458>
100042380:     	ldr	x1, [x1, #200]
100042384:     	adrp	x2, 0x100000000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa4>
100042388:     	add	x2, x2, #0
10004238c:     	bl	0x10015f660 <_strcmp+0x10015f660>
100042390:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x46c>
100042394:     	ldr	x0, [x0, #24]
100042398:     	bl	0x10015f69c <_strcmp+0x10015f69c>
10004239c:     	b	0x100042300 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000423a0:     	bl	0x1000037fc <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000423a4:     	mov	x19, x0
1000423a8:     	adrp	x0, 0x100168000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x484>
1000423ac:     	ldr	x0, [x0, #24]
1000423b0:     	bl	0x10015f684 <_strcmp+0x10015f684>
1000423b4:     	mov	x0, x19
1000423b8:     	bl	0x10015f5f4 <_strcmp+0x10015f5f4>

00000001000b4618 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b4618:     	str	xzr, [x3]
1000b461c:     	lsl	x8, x4, #2
1000b4620:     	cmp	x2, #8
1000b4624:     	b.hs	0x1000b4638 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000b4628:     	mov	x12, #0
1000b462c:     	movi	d1, #0000000000000000
1000b4630:     	movi	d0, #0000000000000000
1000b4634:     	b	0x1000b47c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1ac>
1000b4638:     	mov	x11, #0
1000b463c:     	movi	d0, #0000000000000000
1000b4640:     	adrp	x9, 0x100165000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x74>
1000b4644:     	add	x9, x9, #3804
1000b4648:     	mov	x10, x1
1000b464c:     	ldr	w12, [x10]
1000b4650:     	add	x13, x0, x11
1000b4654:     	ldr	w14, [x13]
1000b4658:     	lsl	w15, w14, #4
1000b465c:     	and	x15, x15, #0xf0
1000b4660:     	bfxil	x15, x12, #0, #4
1000b4664:     	and	x16, x14, #0xf0
1000b4668:     	bfxil	x16, x12, #4, #4
1000b466c:     	ldrb	w16, [x9, x16]
1000b4670:     	ldrb	w15, [x9, x15]
1000b4674:     	lsr	x17, x14, #4
1000b4678:     	and	x17, x17, #0xf0
1000b467c:     	bfxil	x17, x12, #8, #4
1000b4680:     	ldrb	w17, [x9, x17]
1000b4684:     	lsr	x4, x14, #8
1000b4688:     	and	x4, x4, #0xf0
1000b468c:     	bfxil	x4, x12, #12, #4
1000b4690:     	ldrb	w4, [x9, x4]
1000b4694:     	lsr	x5, x14, #12
1000b4698:     	and	x5, x5, #0xf0
1000b469c:     	bfxil	x5, x12, #16, #4
1000b46a0:     	lsr	x6, x14, #16
1000b46a4:     	ldrb	w5, [x9, x5]
1000b46a8:     	and	x6, x6, #0xf0
1000b46ac:     	bfxil	x6, x12, #20, #4
1000b46b0:     	ldrb	w6, [x9, x6]
1000b46b4:     	add	w15, w15, w16
1000b46b8:     	add	w15, w15, w17
1000b46bc:     	lsr	x16, x14, #20
1000b46c0:     	and	x16, x16, #0xf0
1000b46c4:     	bfxil	x16, x12, #24, #4
1000b46c8:     	ldrb	w16, [x9, x16]
1000b46cc:     	add	w15, w15, w4
1000b46d0:     	add	w15, w15, w5
1000b46d4:     	lsr	x14, x14, #24
1000b46d8:     	and	x14, x14, #0xf0
1000b46dc:     	lsr	x17, x12, #28
1000b46e0:     	add	w15, w15, w6
1000b46e4:     	add	w15, w15, w16
1000b46e8:     	orr	x14, x14, x17
1000b46ec:     	ldrb	w14, [x9, x14]
1000b46f0:     	add	w14, w15, w14
1000b46f4:     	scvtf	s1, w14
1000b46f8:     	fadd	s0, s0, s1
1000b46fc:     	str	s0, [x3]
1000b4700:     	ldr	w13, [x13, #4]
1000b4704:     	lsl	w14, w13, #4
1000b4708:     	and	x14, x14, #0xf0
1000b470c:     	bfxil	x14, x12, #0, #4
1000b4710:     	and	x15, x13, #0xf0
1000b4714:     	bfxil	x15, x12, #4, #4
1000b4718:     	lsr	x16, x13, #4
1000b471c:     	and	x16, x16, #0xf0
1000b4720:     	bfxil	x16, x12, #8, #4
1000b4724:     	lsr	x4, x13, #8
1000b4728:     	and	x4, x4, #0xf0
1000b472c:     	bfxil	x4, x12, #12, #4
1000b4730:     	lsr	x5, x13, #12
1000b4734:     	and	x5, x5, #0xf0
1000b4738:     	bfxil	x5, x12, #16, #4
1000b473c:     	lsr	x6, x13, #16
1000b4740:     	and	x6, x6, #0xf0
1000b4744:     	bfxil	x6, x12, #20, #4
1000b4748:     	lsr	x7, x13, #20
1000b474c:     	and	x7, x7, #0xf0
1000b4750:     	bfxil	x7, x12, #24, #4
1000b4754:     	ldrb	w12, [x9, x14]
1000b4758:     	ldrb	w14, [x9, x15]
1000b475c:     	ldrb	w15, [x9, x16]
1000b4760:     	ldrb	w16, [x9, x4]
1000b4764:     	ldrb	w4, [x9, x5]
1000b4768:     	add	w12, w12, w14
1000b476c:     	add	w12, w12, w15
1000b4770:     	ldrb	w14, [x9, x6]
1000b4774:     	ldrb	w15, [x9, x7]
1000b4778:     	add	w12, w12, w16
1000b477c:     	add	w12, w12, w4
1000b4780:     	lsr	x13, x13, #24
1000b4784:     	and	x13, x13, #0xf0
1000b4788:     	orr	x13, x13, x17
1000b478c:     	ldrb	w13, [x9, x13]
1000b4790:     	add	w12, w12, w14
1000b4794:     	add	w12, w12, w15
1000b4798:     	add	w12, w12, w13
1000b479c:     	scvtf	s1, w12
1000b47a0:     	ldr	s2, [x3, #4]
1000b47a4:     	fadd	s1, s2, s1
1000b47a8:     	str	s1, [x3, #4]
1000b47ac:     	add	x12, x11, #8
1000b47b0:     	add	x10, x10, x8
1000b47b4:     	add	x13, x11, #16
1000b47b8:     	mov	x11, x12
1000b47bc:     	cmp	x13, x2
1000b47c0:     	b.ls	0x1000b464c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000b47c4:     	cmp	x12, x2
1000b47c8:     	b.hs	0x1000b4870 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x258>
1000b47cc:     	lsl	w9, w12, #2
1000b47d0:     	mov	w10, #-16
1000b47d4:     	lsr	x11, x12, #3
1000b47d8:     	mul	x11, x8, x11
1000b47dc:     	ubfx	x13, x12, #1, #2
1000b47e0:     	orr	x11, x11, x13
1000b47e4:     	and	w13, w9, #0x4
1000b47e8:     	ldrb	w11, [x1, x11]
1000b47ec:     	lsr	w11, w11, w13
1000b47f0:     	and	w14, w11, #0xf
1000b47f4:     	cmp	w14, #8
1000b47f8:     	csel	w14, wzr, w10, lo
1000b47fc:     	and	x15, x12, #0xfffffffffffffff8
1000b4800:     	bfxil	w14, w11, #0, #4
1000b4804:     	bfxil	x15, x12, #1, #2
1000b4808:     	add	x11, x0, x15
1000b480c:     	ldrb	w15, [x11]
1000b4810:     	lsr	w15, w15, w13
1000b4814:     	scvtf	s2, w14
1000b4818:     	and	w14, w15, #0xf
1000b481c:     	cmp	w14, #8
1000b4820:     	csel	w14, wzr, w10, lo
1000b4824:     	bfxil	w14, w15, #0, #4
1000b4828:     	scvtf	s3, w14
1000b482c:     	fsub	s3, s3, s2
1000b4830:     	fmadd	s0, s3, s3, s0
1000b4834:     	str	s0, [x3]
1000b4838:     	ldrb	w11, [x11, #4]
1000b483c:     	lsr	w11, w11, w13
1000b4840:     	and	w13, w11, #0xf
1000b4844:     	cmp	w13, #8
1000b4848:     	csel	w13, wzr, w10, lo
1000b484c:     	bfxil	w13, w11, #0, #4
1000b4850:     	scvtf	s3, w13
1000b4854:     	fsub	s2, s3, s2
1000b4858:     	fmadd	s1, s2, s2, s1
1000b485c:     	str	s1, [x3, #4]
1000b4860:     	add	x12, x12, #1
1000b4864:     	add	w9, w9, #4
1000b4868:     	cmp	x2, x12
1000b486c:     	b.ne	0x1000b47d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1bc>
1000b4870:     	ret

00000001000b4890 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b4890:     	str	xzr, [x3]
1000b4894:     	lsl	x8, x4, #2
1000b4898:     	cmp	x2, #8
1000b489c:     	b.hs	0x1000b48b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000b48a0:     	mov	x12, #0
1000b48a4:     	movi	d1, #0000000000000000
1000b48a8:     	movi	d0, #0000000000000000
1000b48ac:     	b	0x1000b4a3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1ac>
1000b48b0:     	mov	x11, #0
1000b48b4:     	movi	d0, #0000000000000000
1000b48b8:     	adrp	x9, 0x100165000 <void run<unsigned char, 2ul, 2ul, false>(char const*)+0x98>
1000b48bc:     	add	x9, x9, #4060
1000b48c0:     	mov	x10, x1
1000b48c4:     	ldr	w12, [x10]
1000b48c8:     	add	x13, x0, x11
1000b48cc:     	ldr	w14, [x13]
1000b48d0:     	lsl	w15, w14, #4
1000b48d4:     	and	x15, x15, #0xf0
1000b48d8:     	bfxil	x15, x12, #0, #4
1000b48dc:     	and	x16, x14, #0xf0
1000b48e0:     	bfxil	x16, x12, #4, #4
1000b48e4:     	ldrsb	w16, [x9, x16]
1000b48e8:     	ldrsb	w15, [x9, x15]
1000b48ec:     	lsr	x17, x14, #4
1000b48f0:     	and	x17, x17, #0xf0
1000b48f4:     	bfxil	x17, x12, #8, #4
1000b48f8:     	ldrsb	w17, [x9, x17]
1000b48fc:     	lsr	x4, x14, #8
1000b4900:     	and	x4, x4, #0xf0
1000b4904:     	bfxil	x4, x12, #12, #4
1000b4908:     	ldrsb	w4, [x9, x4]
1000b490c:     	lsr	x5, x14, #12
1000b4910:     	and	x5, x5, #0xf0
1000b4914:     	bfxil	x5, x12, #16, #4
1000b4918:     	lsr	x6, x14, #16
1000b491c:     	ldrsb	w5, [x9, x5]
1000b4920:     	and	x6, x6, #0xf0
1000b4924:     	bfxil	x6, x12, #20, #4
1000b4928:     	ldrsb	w6, [x9, x6]
1000b492c:     	add	w15, w15, w16
1000b4930:     	add	w15, w15, w17
1000b4934:     	lsr	x16, x14, #20
1000b4938:     	and	x16, x16, #0xf0
1000b493c:     	bfxil	x16, x12, #24, #4
1000b4940:     	ldrsb	w16, [x9, x16]
1000b4944:     	add	w15, w15, w4
1000b4948:     	add	w15, w15, w5
1000b494c:     	lsr	x14, x14, #24
1000b4950:     	and	x14, x14, #0xf0
1000b4954:     	lsr	x17, x12, #28
1000b4958:     	add	w15, w15, w6
1000b495c:     	add	w15, w15, w16
1000b4960:     	orr	x14, x14, x17
1000b4964:     	ldrsb	w14, [x9, x14]
1000b4968:     	add	w14, w15, w14
1000b496c:     	scvtf	s1, w14
1000b4970:     	fadd	s0, s0, s1
1000b4974:     	str	s0, [x3]
1000b4978:     	ldr	w13, [x13, #4]
1000b497c:     	lsl	w14, w13, #4
1000b4980:     	and	x14, x14, #0xf0
1000b4984:     	bfxil	x14, x12, #0, #4
1000b4988:     	and	x15, x13, #0xf0
1000b498c:     	bfxil	x15, x12, #4, #4
1000b4990:     	lsr	x16, x13, #4
1000b4994:     	and	x16, x16, #0xf0
1000b4998:     	bfxil	x16, x12, #8, #4
1000b499c:     	lsr	x4, x13, #8
1000b49a0:     	and	x4, x4, #0xf0
1000b49a4:     	bfxil	x4, x12, #12, #4
1000b49a8:     	lsr	x5, x13, #12
1000b49ac:     	and	x5, x5, #0xf0
1000b49b0:     	bfxil	x5, x12, #16, #4
1000b49b4:     	lsr	x6, x13, #16
1000b49b8:     	and	x6, x6, #0xf0
1000b49bc:     	bfxil	x6, x12, #20, #4
1000b49c0:     	lsr	x7, x13, #20
1000b49c4:     	and	x7, x7, #0xf0
1000b49c8:     	bfxil	x7, x12, #24, #4
1000b49cc:     	ldrsb	w12, [x9, x14]
1000b49d0:     	ldrsb	w14, [x9, x15]
1000b49d4:     	ldrsb	w15, [x9, x16]
1000b49d8:     	ldrsb	w16, [x9, x4]
1000b49dc:     	ldrsb	w4, [x9, x5]
1000b49e0:     	add	w12, w12, w14
1000b49e4:     	add	w12, w12, w15
1000b49e8:     	ldrsb	w14, [x9, x6]
1000b49ec:     	ldrsb	w15, [x9, x7]
1000b49f0:     	add	w12, w12, w16
1000b49f4:     	add	w12, w12, w4
1000b49f8:     	lsr	x13, x13, #24
1000b49fc:     	and	x13, x13, #0xf0
1000b4a00:     	orr	x13, x13, x17
1000b4a04:     	ldrsb	w13, [x9, x13]
1000b4a08:     	add	w12, w12, w14
1000b4a0c:     	add	w12, w12, w15
1000b4a10:     	add	w12, w12, w13
1000b4a14:     	scvtf	s1, w12
1000b4a18:     	ldr	s2, [x3, #4]
1000b4a1c:     	fadd	s1, s2, s1
1000b4a20:     	str	s1, [x3, #4]
1000b4a24:     	add	x12, x11, #8
1000b4a28:     	add	x10, x10, x8
1000b4a2c:     	add	x13, x11, #16
1000b4a30:     	mov	x11, x12
1000b4a34:     	cmp	x13, x2
1000b4a38:     	b.ls	0x1000b48c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000b4a3c:     	cmp	x12, x2
1000b4a40:     	b.hs	0x1000b4ae0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x250>
1000b4a44:     	lsl	w9, w12, #2
1000b4a48:     	mov	w10, #-16
1000b4a4c:     	lsr	x11, x12, #3
1000b4a50:     	mul	x11, x8, x11
1000b4a54:     	ubfx	x13, x12, #1, #2
1000b4a58:     	orr	x11, x11, x13
1000b4a5c:     	ldrb	w11, [x1, x11]
1000b4a60:     	and	w13, w9, #0x4
1000b4a64:     	lsr	w11, w11, w13
1000b4a68:     	and	w14, w11, #0xf
1000b4a6c:     	cmp	w14, #8
1000b4a70:     	csel	w14, wzr, w10, lo
1000b4a74:     	and	x15, x12, #0xfffffffffffffff8
1000b4a78:     	bfxil	x15, x12, #1, #2
1000b4a7c:     	add	x15, x0, x15
1000b4a80:     	ldrb	w16, [x15]
1000b4a84:     	lsr	w16, w16, w13
1000b4a88:     	bfxil	w14, w11, #0, #4
1000b4a8c:     	and	w11, w16, #0xf
1000b4a90:     	cmp	w11, #8
1000b4a94:     	csel	w11, wzr, w10, lo
1000b4a98:     	bfxil	w11, w16, #0, #4
1000b4a9c:     	scvtf	s2, w14
1000b4aa0:     	scvtf	s3, w11
1000b4aa4:     	fmsub	s0, s3, s2, s0
1000b4aa8:     	str	s0, [x3]
1000b4aac:     	ldrb	w11, [x15, #4]
1000b4ab0:     	lsr	w11, w11, w13
1000b4ab4:     	and	w13, w11, #0xf
1000b4ab8:     	cmp	w13, #8
1000b4abc:     	csel	w13, wzr, w10, lo
1000b4ac0:     	bfxil	w13, w11, #0, #4
1000b4ac4:     	scvtf	s3, w13
1000b4ac8:     	fmsub	s1, s3, s2, s1
1000b4acc:     	str	s1, [x3, #4]
1000b4ad0:     	add	x12, x12, #1
1000b4ad4:     	add	w9, w9, #4
1000b4ad8:     	cmp	x2, x12
1000b4adc:     	b.ne	0x1000b4a4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1bc>
1000b4ae0:     	ret

00000001000b619c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b619c:     	stp	x22, x21, [sp, #-32]!
1000b61a0:     	stp	x20, x19, [sp, #16]
1000b61a4:     	ands	x8, x2, #0xfffffffffffffffe
1000b61a8:     	b.eq	0x1000b642c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b61ac:     	add	x8, x1, x8
1000b61b0:     	movi	d0, #0000000000000000
1000b61b4:     	adrp	x9, 0x100165000 <void kernel<unsigned char, 2ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18>
1000b61b8:     	add	x9, x9, #3804
1000b61bc:     	movi	d1, #0000000000000000
1000b61c0:     	movi	d2, #0000000000000000
1000b61c4:     	movi	d3, #0000000000000000
1000b61c8:     	ldp	w10, w11, [x0]
1000b61cc:     	lsl	w12, w10, #4
1000b61d0:     	and	x14, x12, #0xf0
1000b61d4:     	mov	x15, x14
1000b61d8:     	ldp	w12, w13, [x1]
1000b61dc:     	bfxil	x15, x12, #0, #4
1000b61e0:     	ldrb	w15, [x9, x15]
1000b61e4:     	and	x16, x10, #0xf0
1000b61e8:     	mov	x17, x16
1000b61ec:     	bfxil	x17, x12, #4, #4
1000b61f0:     	ldrb	w17, [x9, x17]
1000b61f4:     	lsr	x2, x10, #4
1000b61f8:     	and	x2, x2, #0xf0
1000b61fc:     	mov	x4, x2
1000b6200:     	bfxil	x4, x12, #8, #4
1000b6204:     	ldrb	w4, [x9, x4]
1000b6208:     	lsr	x5, x10, #8
1000b620c:     	and	x5, x5, #0xf0
1000b6210:     	mov	x6, x5
1000b6214:     	bfxil	x6, x12, #12, #4
1000b6218:     	ldrb	w6, [x9, x6]
1000b621c:     	lsr	x7, x10, #12
1000b6220:     	and	x7, x7, #0xf0
1000b6224:     	mov	x19, x7
1000b6228:     	bfxil	x19, x12, #16, #4
1000b622c:     	ldrb	w19, [x9, x19]
1000b6230:     	add	w15, w15, w17
1000b6234:     	add	w15, w15, w4
1000b6238:     	lsr	x17, x10, #16
1000b623c:     	and	x17, x17, #0xf0
1000b6240:     	mov	x4, x17
1000b6244:     	bfxil	x4, x12, #20, #4
1000b6248:     	add	w15, w15, w6
1000b624c:     	add	w15, w15, w19
1000b6250:     	ldrb	w4, [x9, x4]
1000b6254:     	lsr	x6, x10, #20
1000b6258:     	and	x6, x6, #0xf0
1000b625c:     	mov	x19, x6
1000b6260:     	bfxil	x19, x12, #24, #4
1000b6264:     	ldrb	w19, [x9, x19]
1000b6268:     	add	w15, w15, w4
1000b626c:     	add	w15, w15, w19
1000b6270:     	lsr	x10, x10, #24
1000b6274:     	and	x4, x10, #0xf0
1000b6278:     	lsr	x10, x12, #28
1000b627c:     	orr	x19, x4, x10
1000b6280:     	ldrb	w19, [x9, x19]
1000b6284:     	add	w15, w15, w19
1000b6288:     	scvtf	s4, w15
1000b628c:     	fadd	s0, s0, s4
1000b6290:     	bfxil	x14, x13, #0, #4
1000b6294:     	ldrb	w14, [x9, x14]
1000b6298:     	and	x15, x13, #0xf
1000b629c:     	ubfx	x19, x13, #4, #4
1000b62a0:     	bfxil	x16, x13, #4, #4
1000b62a4:     	ldrb	w16, [x9, x16]
1000b62a8:     	ubfx	x20, x13, #8, #4
1000b62ac:     	bfxil	x2, x13, #8, #4
1000b62b0:     	ldrb	w2, [x9, x2]
1000b62b4:     	add	w14, w14, w16
1000b62b8:     	add	w14, w14, w2
1000b62bc:     	ubfx	x16, x13, #12, #4
1000b62c0:     	bfxil	x5, x13, #12, #4
1000b62c4:     	ldrb	w2, [x9, x5]
1000b62c8:     	bfxil	x7, x13, #16, #4
1000b62cc:     	ldrb	w5, [x9, x7]
1000b62d0:     	ubfx	x7, x13, #16, #4
1000b62d4:     	add	w14, w14, w2
1000b62d8:     	add	w14, w14, w5
1000b62dc:     	bfxil	x17, x13, #20, #4
1000b62e0:     	ldrb	w17, [x9, x17]
1000b62e4:     	bfxil	x6, x13, #24, #4
1000b62e8:     	ldrb	w2, [x9, x6]
1000b62ec:     	add	w14, w14, w17
1000b62f0:     	add	w17, w14, w2
1000b62f4:     	lsr	x14, x13, #28
1000b62f8:     	orr	x2, x4, x14
1000b62fc:     	ldrb	w2, [x9, x2]
1000b6300:     	add	w17, w17, w2
1000b6304:     	scvtf	s4, w17
1000b6308:     	ubfx	x17, x13, #20, #4
1000b630c:     	fadd	s2, s2, s4
1000b6310:     	lsl	w2, w11, #4
1000b6314:     	and	x2, x2, #0xf0
1000b6318:     	orr	w15, w2, w15
1000b631c:     	bfxil	x2, x12, #0, #4
1000b6320:     	ldrb	w2, [x9, x2]
1000b6324:     	and	x4, x11, #0xf0
1000b6328:     	orr	w5, w4, w19
1000b632c:     	bfxil	x4, x12, #4, #4
1000b6330:     	ldrb	w4, [x9, x4]
1000b6334:     	lsr	x6, x11, #4
1000b6338:     	and	x6, x6, #0xf0
1000b633c:     	orr	w19, w6, w20
1000b6340:     	bfxil	x6, x12, #8, #4
1000b6344:     	ldrb	w6, [x9, x6]
1000b6348:     	add	w2, w2, w4
1000b634c:     	add	w2, w2, w6
1000b6350:     	lsr	x4, x11, #8
1000b6354:     	and	x4, x4, #0xf0
1000b6358:     	orr	w16, w4, w16
1000b635c:     	lsr	x6, x11, #12
1000b6360:     	and	x6, x6, #0xf0
1000b6364:     	orr	w7, w6, w7
1000b6368:     	lsr	x20, x11, #16
1000b636c:     	and	x20, x20, #0xf0
1000b6370:     	orr	w17, w20, w17
1000b6374:     	lsr	x21, x11, #20
1000b6378:     	and	x21, x21, #0xf0
1000b637c:     	ubfx	x13, x13, #24, #4
1000b6380:     	orr	w13, w21, w13
1000b6384:     	bfxil	x4, x12, #12, #4
1000b6388:     	ldrb	w4, [x9, x4]
1000b638c:     	bfxil	x6, x12, #16, #4
1000b6390:     	ldrb	w6, [x9, x6]
1000b6394:     	bfxil	x20, x12, #20, #4
1000b6398:     	ldrb	w20, [x9, x20]
1000b639c:     	bfxil	x21, x12, #24, #4
1000b63a0:     	ldrb	w12, [x9, x21]
1000b63a4:     	add	w2, w2, w4
1000b63a8:     	add	w2, w2, w6
1000b63ac:     	add	w2, w2, w20
1000b63b0:     	add	w12, w2, w12
1000b63b4:     	lsr	x11, x11, #24
1000b63b8:     	and	x11, x11, #0xf0
1000b63bc:     	orr	x10, x11, x10
1000b63c0:     	ldrb	w10, [x9, x10]
1000b63c4:     	add	w10, w12, w10
1000b63c8:     	scvtf	s4, w10
1000b63cc:     	fadd	s1, s1, s4
1000b63d0:     	ldrb	w10, [x9, w15, uxtw]
1000b63d4:     	ldrb	w12, [x9, w5, uxtw]
1000b63d8:     	ldrb	w15, [x9, w19, uxtw]
1000b63dc:     	add	w10, w10, w12
1000b63e0:     	add	w10, w10, w15
1000b63e4:     	ldrb	w12, [x9, w16, uxtw]
1000b63e8:     	ldrb	w15, [x9, w7, uxtw]
1000b63ec:     	add	w10, w10, w12
1000b63f0:     	add	w10, w10, w15
1000b63f4:     	ldrb	w12, [x9, w17, uxtw]
1000b63f8:     	ldrb	w13, [x9, w13, uxtw]
1000b63fc:     	add	w10, w10, w12
1000b6400:     	add	w10, w10, w13
1000b6404:     	orr	w11, w11, w14
1000b6408:     	ldrb	w11, [x9, w11, uxtw]
1000b640c:     	add	w10, w10, w11
1000b6410:     	scvtf	s4, w10
1000b6414:     	fadd	s3, s3, s4
1000b6418:     	add	x0, x0, #8
1000b641c:     	add	x1, x1, #8
1000b6420:     	cmp	x1, x8
1000b6424:     	b.ne	0x1000b61c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b6428:     	b	0x1000b643c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b642c:     	movi	d0, #0000000000000000
1000b6430:     	movi	d1, #0000000000000000
1000b6434:     	movi	d2, #0000000000000000
1000b6438:     	movi	d3, #0000000000000000
1000b643c:     	str	s0, [x3]
1000b6440:     	str	s1, [x3, #4]
1000b6444:     	str	s2, [x3, #8]
1000b6448:     	str	s3, [x3, #12]
1000b644c:     	ldp	x20, x19, [sp, #16]
1000b6450:     	ldp	x22, x21, [sp], #32
1000b6454:     	ret

00000001000b6504 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b6504:     	stp	x22, x21, [sp, #-32]!
1000b6508:     	stp	x20, x19, [sp, #16]
1000b650c:     	ands	x8, x2, #0xfffffffffffffffe
1000b6510:     	b.eq	0x1000b6794 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b6514:     	add	x8, x1, x8
1000b6518:     	movi	d0, #0000000000000000
1000b651c:     	adrp	x9, 0x100165000 <void run<unsigned char, 4ul, 1ul, false>(char const*)+0x18>
1000b6520:     	add	x9, x9, #4060
1000b6524:     	movi	d1, #0000000000000000
1000b6528:     	movi	d2, #0000000000000000
1000b652c:     	movi	d3, #0000000000000000
1000b6530:     	ldp	w10, w11, [x0]
1000b6534:     	lsl	w12, w10, #4
1000b6538:     	and	x14, x12, #0xf0
1000b653c:     	mov	x15, x14
1000b6540:     	ldp	w12, w13, [x1]
1000b6544:     	bfxil	x15, x12, #0, #4
1000b6548:     	ldrsb	w15, [x9, x15]
1000b654c:     	and	x16, x10, #0xf0
1000b6550:     	mov	x17, x16
1000b6554:     	bfxil	x17, x12, #4, #4
1000b6558:     	ldrsb	w17, [x9, x17]
1000b655c:     	lsr	x2, x10, #4
1000b6560:     	and	x2, x2, #0xf0
1000b6564:     	mov	x4, x2
1000b6568:     	bfxil	x4, x12, #8, #4
1000b656c:     	ldrsb	w4, [x9, x4]
1000b6570:     	lsr	x5, x10, #8
1000b6574:     	and	x5, x5, #0xf0
1000b6578:     	mov	x6, x5
1000b657c:     	bfxil	x6, x12, #12, #4
1000b6580:     	ldrsb	w6, [x9, x6]
1000b6584:     	lsr	x7, x10, #12
1000b6588:     	and	x7, x7, #0xf0
1000b658c:     	mov	x19, x7
1000b6590:     	bfxil	x19, x12, #16, #4
1000b6594:     	ldrsb	w19, [x9, x19]
1000b6598:     	add	w15, w15, w17
1000b659c:     	add	w15, w15, w4
1000b65a0:     	lsr	x17, x10, #16
1000b65a4:     	and	x17, x17, #0xf0
1000b65a8:     	mov	x4, x17
1000b65ac:     	bfxil	x4, x12, #20, #4
1000b65b0:     	add	w15, w15, w6
1000b65b4:     	add	w15, w15, w19
1000b65b8:     	ldrsb	w4, [x9, x4]
1000b65bc:     	lsr	x6, x10, #20
1000b65c0:     	and	x6, x6, #0xf0
1000b65c4:     	mov	x19, x6
1000b65c8:     	bfxil	x19, x12, #24, #4
1000b65cc:     	ldrsb	w19, [x9, x19]
1000b65d0:     	add	w15, w15, w4
1000b65d4:     	add	w15, w15, w19
1000b65d8:     	lsr	x10, x10, #24
1000b65dc:     	and	x4, x10, #0xf0
1000b65e0:     	lsr	x10, x12, #28
1000b65e4:     	orr	x19, x4, x10
1000b65e8:     	ldrsb	w19, [x9, x19]
1000b65ec:     	add	w15, w15, w19
1000b65f0:     	scvtf	s4, w15
1000b65f4:     	fadd	s0, s0, s4
1000b65f8:     	bfxil	x14, x13, #0, #4
1000b65fc:     	ldrsb	w14, [x9, x14]
1000b6600:     	and	x15, x13, #0xf
1000b6604:     	ubfx	x19, x13, #4, #4
1000b6608:     	bfxil	x16, x13, #4, #4
1000b660c:     	ldrsb	w16, [x9, x16]
1000b6610:     	ubfx	x20, x13, #8, #4
1000b6614:     	bfxil	x2, x13, #8, #4
1000b6618:     	ldrsb	w2, [x9, x2]
1000b661c:     	add	w14, w14, w16
1000b6620:     	add	w14, w14, w2
1000b6624:     	ubfx	x16, x13, #12, #4
1000b6628:     	bfxil	x5, x13, #12, #4
1000b662c:     	ldrsb	w2, [x9, x5]
1000b6630:     	bfxil	x7, x13, #16, #4
1000b6634:     	ldrsb	w5, [x9, x7]
1000b6638:     	ubfx	x7, x13, #16, #4
1000b663c:     	add	w14, w14, w2
1000b6640:     	add	w14, w14, w5
1000b6644:     	bfxil	x17, x13, #20, #4
1000b6648:     	ldrsb	w17, [x9, x17]
1000b664c:     	bfxil	x6, x13, #24, #4
1000b6650:     	ldrsb	w2, [x9, x6]
1000b6654:     	add	w14, w14, w17
1000b6658:     	add	w17, w14, w2
1000b665c:     	lsr	x14, x13, #28
1000b6660:     	orr	x2, x4, x14
1000b6664:     	ldrsb	w2, [x9, x2]
1000b6668:     	add	w17, w17, w2
1000b666c:     	scvtf	s4, w17
1000b6670:     	ubfx	x17, x13, #20, #4
1000b6674:     	fadd	s2, s2, s4
1000b6678:     	lsl	w2, w11, #4
1000b667c:     	and	x2, x2, #0xf0
1000b6680:     	orr	w15, w2, w15
1000b6684:     	bfxil	x2, x12, #0, #4
1000b6688:     	ldrsb	w2, [x9, x2]
1000b668c:     	and	x4, x11, #0xf0
1000b6690:     	orr	w5, w4, w19
1000b6694:     	bfxil	x4, x12, #4, #4
1000b6698:     	ldrsb	w4, [x9, x4]
1000b669c:     	lsr	x6, x11, #4
1000b66a0:     	and	x6, x6, #0xf0
1000b66a4:     	orr	w19, w6, w20
1000b66a8:     	bfxil	x6, x12, #8, #4
1000b66ac:     	ldrsb	w6, [x9, x6]
1000b66b0:     	add	w2, w2, w4
1000b66b4:     	add	w2, w2, w6
1000b66b8:     	lsr	x4, x11, #8
1000b66bc:     	and	x4, x4, #0xf0
1000b66c0:     	orr	w16, w4, w16
1000b66c4:     	lsr	x6, x11, #12
1000b66c8:     	and	x6, x6, #0xf0
1000b66cc:     	orr	w7, w6, w7
1000b66d0:     	lsr	x20, x11, #16
1000b66d4:     	and	x20, x20, #0xf0
1000b66d8:     	orr	w17, w20, w17
1000b66dc:     	lsr	x21, x11, #20
1000b66e0:     	and	x21, x21, #0xf0
1000b66e4:     	ubfx	x13, x13, #24, #4
1000b66e8:     	orr	w13, w21, w13
1000b66ec:     	bfxil	x4, x12, #12, #4
1000b66f0:     	ldrsb	w4, [x9, x4]
1000b66f4:     	bfxil	x6, x12, #16, #4
1000b66f8:     	ldrsb	w6, [x9, x6]
1000b66fc:     	bfxil	x20, x12, #20, #4
1000b6700:     	ldrsb	w20, [x9, x20]
1000b6704:     	bfxil	x21, x12, #24, #4
1000b6708:     	ldrsb	w12, [x9, x21]
1000b670c:     	add	w2, w2, w4
1000b6710:     	add	w2, w2, w6
1000b6714:     	add	w2, w2, w20
1000b6718:     	add	w12, w2, w12
1000b671c:     	lsr	x11, x11, #24
1000b6720:     	and	x11, x11, #0xf0
1000b6724:     	orr	x10, x11, x10
1000b6728:     	ldrsb	w10, [x9, x10]
1000b672c:     	add	w10, w12, w10
1000b6730:     	scvtf	s4, w10
1000b6734:     	fadd	s1, s1, s4
1000b6738:     	ldrsb	w10, [x9, w15, uxtw]
1000b673c:     	ldrsb	w12, [x9, w5, uxtw]
1000b6740:     	ldrsb	w15, [x9, w19, uxtw]
1000b6744:     	add	w10, w10, w12
1000b6748:     	add	w10, w10, w15
1000b674c:     	ldrsb	w12, [x9, w16, uxtw]
1000b6750:     	ldrsb	w15, [x9, w7, uxtw]
1000b6754:     	add	w10, w10, w12
1000b6758:     	add	w10, w10, w15
1000b675c:     	ldrsb	w12, [x9, w17, uxtw]
1000b6760:     	ldrsb	w13, [x9, w13, uxtw]
1000b6764:     	add	w10, w10, w12
1000b6768:     	add	w10, w10, w13
1000b676c:     	orr	w11, w11, w14
1000b6770:     	ldrsb	w11, [x9, w11, uxtw]
1000b6774:     	add	w10, w10, w11
1000b6778:     	scvtf	s4, w10
1000b677c:     	fadd	s3, s3, s4
1000b6780:     	add	x0, x0, #8
1000b6784:     	add	x1, x1, #8
1000b6788:     	cmp	x1, x8
1000b678c:     	b.ne	0x1000b6530 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b6790:     	b	0x1000b67a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b6794:     	movi	d0, #0000000000000000
1000b6798:     	movi	d1, #0000000000000000
1000b679c:     	movi	d2, #0000000000000000
1000b67a0:     	movi	d3, #0000000000000000
1000b67a4:     	str	s0, [x3]
1000b67a8:     	str	s1, [x3, #4]
1000b67ac:     	str	s2, [x3, #8]
1000b67b0:     	str	s3, [x3, #12]
1000b67b4:     	ldp	x20, x19, [sp, #16]
1000b67b8:     	ldp	x22, x21, [sp], #32
1000b67bc:     	ret

00000001000b7a94 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b7a94:     	stp	x20, x19, [sp, #-16]!
1000b7a98:     	stp	xzr, xzr, [x3]
1000b7a9c:     	lsl	x8, x4, #2
1000b7aa0:     	cmp	x2, #8
1000b7aa4:     	b.hs	0x1000b7ab8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000b7aa8:     	mov	x13, #0
1000b7aac:     	movi	d1, #0000000000000000
1000b7ab0:     	movi	d0, #0000000000000000
1000b7ab4:     	b	0x1000b7d98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x304>
1000b7ab8:     	mov	x10, #0
1000b7abc:     	add	x9, x0, #8
1000b7ac0:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2e8>
1000b7ac4:     	add	x11, x11, #220
1000b7ac8:     	mov	x12, x1
1000b7acc:     	ldr	w13, [x12]
1000b7ad0:     	ldur	w14, [x9, #-8]
1000b7ad4:     	lsl	w15, w14, #4
1000b7ad8:     	and	x15, x15, #0xf0
1000b7adc:     	bfxil	x15, x13, #0, #4
1000b7ae0:     	and	x16, x14, #0xf0
1000b7ae4:     	bfxil	x16, x13, #4, #4
1000b7ae8:     	ldrb	w16, [x11, x16]
1000b7aec:     	ldrb	w15, [x11, x15]
1000b7af0:     	lsr	x17, x14, #4
1000b7af4:     	and	x17, x17, #0xf0
1000b7af8:     	bfxil	x17, x13, #8, #4
1000b7afc:     	lsr	x4, x14, #8
1000b7b00:     	ldrb	w17, [x11, x17]
1000b7b04:     	and	x4, x4, #0xf0
1000b7b08:     	bfxil	x4, x13, #12, #4
1000b7b0c:     	lsr	x5, x14, #12
1000b7b10:     	and	x5, x5, #0xf0
1000b7b14:     	ldrb	w4, [x11, x4]
1000b7b18:     	bfxil	x5, x13, #16, #4
1000b7b1c:     	lsr	x6, x14, #16
1000b7b20:     	and	x6, x6, #0xf0
1000b7b24:     	bfxil	x6, x13, #20, #4
1000b7b28:     	ldrb	w5, [x11, x5]
1000b7b2c:     	ldrb	w6, [x11, x6]
1000b7b30:     	lsr	x7, x14, #20
1000b7b34:     	and	x7, x7, #0xf0
1000b7b38:     	add	w15, w15, w16
1000b7b3c:     	add	w15, w15, w17
1000b7b40:     	bfxil	x7, x13, #24, #4
1000b7b44:     	ldrb	w16, [x11, x7]
1000b7b48:     	lsr	x14, x14, #24
1000b7b4c:     	add	w15, w15, w4
1000b7b50:     	add	w15, w15, w5
1000b7b54:     	and	x17, x14, #0xf0
1000b7b58:     	lsr	x14, x13, #28
1000b7b5c:     	orr	x17, x17, x14
1000b7b60:     	ldrb	w17, [x11, x17]
1000b7b64:     	add	w15, w15, w6
1000b7b68:     	add	w15, w15, w16
1000b7b6c:     	add	w15, w15, w17
1000b7b70:     	scvtf	s0, w15
1000b7b74:     	ldp	s1, s2, [x3]
1000b7b78:     	fadd	s0, s1, s0
1000b7b7c:     	str	s0, [x3]
1000b7b80:     	ldur	w15, [x9, #-4]
1000b7b84:     	lsl	w16, w15, #4
1000b7b88:     	and	x16, x16, #0xf0
1000b7b8c:     	bfxil	x16, x13, #0, #4
1000b7b90:     	and	x17, x15, #0xf0
1000b7b94:     	bfxil	x17, x13, #4, #4
1000b7b98:     	ldrb	w17, [x11, x17]
1000b7b9c:     	ldrb	w16, [x11, x16]
1000b7ba0:     	lsr	x4, x15, #4
1000b7ba4:     	and	x4, x4, #0xf0
1000b7ba8:     	bfxil	x4, x13, #8, #4
1000b7bac:     	ldrb	w4, [x11, x4]
1000b7bb0:     	lsr	x5, x15, #8
1000b7bb4:     	and	x5, x5, #0xf0
1000b7bb8:     	bfxil	x5, x13, #12, #4
1000b7bbc:     	ldrb	w5, [x11, x5]
1000b7bc0:     	lsr	x6, x15, #12
1000b7bc4:     	and	x6, x6, #0xf0
1000b7bc8:     	bfxil	x6, x13, #16, #4
1000b7bcc:     	ldrb	w6, [x11, x6]
1000b7bd0:     	lsr	x7, x15, #16
1000b7bd4:     	and	x7, x7, #0xf0
1000b7bd8:     	bfxil	x7, x13, #20, #4
1000b7bdc:     	ldrb	w7, [x11, x7]
1000b7be0:     	add	w16, w16, w17
1000b7be4:     	add	w16, w16, w4
1000b7be8:     	lsr	x17, x15, #20
1000b7bec:     	and	x17, x17, #0xf0
1000b7bf0:     	bfxil	x17, x13, #24, #4
1000b7bf4:     	add	w16, w16, w5
1000b7bf8:     	add	w16, w16, w6
1000b7bfc:     	ldrb	w17, [x11, x17]
1000b7c00:     	lsr	x15, x15, #24
1000b7c04:     	and	x15, x15, #0xf0
1000b7c08:     	add	w16, w16, w7
1000b7c0c:     	add	w16, w16, w17
1000b7c10:     	orr	x15, x15, x14
1000b7c14:     	ldrb	w15, [x11, x15]
1000b7c18:     	add	w15, w16, w15
1000b7c1c:     	scvtf	s0, w15
1000b7c20:     	fadd	s0, s2, s0
1000b7c24:     	str	s0, [x3, #4]
1000b7c28:     	ldr	w15, [x9]
1000b7c2c:     	lsl	w16, w15, #4
1000b7c30:     	and	x16, x16, #0xf0
1000b7c34:     	bfxil	x16, x13, #0, #4
1000b7c38:     	and	x17, x15, #0xf0
1000b7c3c:     	bfxil	x17, x13, #4, #4
1000b7c40:     	ldrb	w17, [x11, x17]
1000b7c44:     	ldrb	w16, [x11, x16]
1000b7c48:     	lsr	x4, x15, #4
1000b7c4c:     	and	x4, x4, #0xf0
1000b7c50:     	bfxil	x4, x13, #8, #4
1000b7c54:     	ldrb	w4, [x11, x4]
1000b7c58:     	lsr	x5, x15, #8
1000b7c5c:     	and	x5, x5, #0xf0
1000b7c60:     	bfxil	x5, x13, #12, #4
1000b7c64:     	ldrb	w5, [x11, x5]
1000b7c68:     	lsr	x6, x15, #12
1000b7c6c:     	and	x6, x6, #0xf0
1000b7c70:     	bfxil	x6, x13, #16, #4
1000b7c74:     	lsr	x7, x15, #16
1000b7c78:     	ldrb	w6, [x11, x6]
1000b7c7c:     	and	x7, x7, #0xf0
1000b7c80:     	bfxil	x7, x13, #20, #4
1000b7c84:     	ldrb	w7, [x11, x7]
1000b7c88:     	add	w16, w16, w17
1000b7c8c:     	add	w16, w16, w4
1000b7c90:     	lsr	x17, x15, #20
1000b7c94:     	and	x17, x17, #0xf0
1000b7c98:     	bfxil	x17, x13, #24, #4
1000b7c9c:     	ldrb	w17, [x11, x17]
1000b7ca0:     	add	w16, w16, w5
1000b7ca4:     	add	w16, w16, w6
1000b7ca8:     	lsr	x15, x15, #24
1000b7cac:     	and	x15, x15, #0xf0
1000b7cb0:     	orr	x15, x15, x14
1000b7cb4:     	add	w16, w16, w7
1000b7cb8:     	add	w16, w16, w17
1000b7cbc:     	ldrb	w15, [x11, x15]
1000b7cc0:     	add	w15, w16, w15
1000b7cc4:     	scvtf	s0, w15
1000b7cc8:     	ldp	s1, s2, [x3, #8]
1000b7ccc:     	fadd	s0, s1, s0
1000b7cd0:     	str	s0, [x3, #8]
1000b7cd4:     	ldr	w15, [x9, #4]
1000b7cd8:     	lsl	w16, w15, #4
1000b7cdc:     	and	x16, x16, #0xf0
1000b7ce0:     	bfxil	x16, x13, #0, #4
1000b7ce4:     	and	x17, x15, #0xf0
1000b7ce8:     	bfxil	x17, x13, #4, #4
1000b7cec:     	lsr	x4, x15, #4
1000b7cf0:     	and	x4, x4, #0xf0
1000b7cf4:     	bfxil	x4, x13, #8, #4
1000b7cf8:     	lsr	x5, x15, #8
1000b7cfc:     	and	x5, x5, #0xf0
1000b7d00:     	bfxil	x5, x13, #12, #4
1000b7d04:     	lsr	x6, x15, #12
1000b7d08:     	and	x6, x6, #0xf0
1000b7d0c:     	bfxil	x6, x13, #16, #4
1000b7d10:     	lsr	x7, x15, #16
1000b7d14:     	and	x7, x7, #0xf0
1000b7d18:     	bfxil	x7, x13, #20, #4
1000b7d1c:     	lsr	x19, x15, #20
1000b7d20:     	and	x19, x19, #0xf0
1000b7d24:     	bfxil	x19, x13, #24, #4
1000b7d28:     	ldrb	w13, [x11, x16]
1000b7d2c:     	ldrb	w16, [x11, x17]
1000b7d30:     	ldrb	w17, [x11, x4]
1000b7d34:     	ldrb	w4, [x11, x5]
1000b7d38:     	ldrb	w5, [x11, x6]
1000b7d3c:     	add	w13, w13, w16
1000b7d40:     	add	w13, w13, w17
1000b7d44:     	ldrb	w16, [x11, x7]
1000b7d48:     	ldrb	w17, [x11, x19]
1000b7d4c:     	add	w13, w13, w4
1000b7d50:     	add	w13, w13, w5
1000b7d54:     	lsr	x15, x15, #24
1000b7d58:     	and	x15, x15, #0xf0
1000b7d5c:     	orr	x14, x15, x14
1000b7d60:     	ldrb	w14, [x11, x14]
1000b7d64:     	add	w13, w13, w16
1000b7d68:     	add	w13, w13, w17
1000b7d6c:     	add	w13, w13, w14
1000b7d70:     	scvtf	s1, w13
1000b7d74:     	fadd	s1, s2, s1
1000b7d78:     	str	s1, [x3, #12]
1000b7d7c:     	add	x13, x10, #8
1000b7d80:     	add	x12, x12, x8
1000b7d84:     	add	x9, x9, #16
1000b7d88:     	add	x14, x10, #16
1000b7d8c:     	mov	x10, x13
1000b7d90:     	cmp	x14, x2
1000b7d94:     	b.ls	0x1000b7acc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000b7d98:     	cmp	x13, x2
1000b7d9c:     	b.hs	0x1000b7e94 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x400>
1000b7da0:     	ldp	s2, s3, [x3]
1000b7da4:     	lsl	w9, w13, #2
1000b7da8:     	mov	w10, #-16
1000b7dac:     	lsr	x11, x13, #3
1000b7db0:     	mul	x12, x8, x11
1000b7db4:     	ubfx	x14, x13, #1, #2
1000b7db8:     	orr	x12, x12, x14
1000b7dbc:     	ldrb	w12, [x1, x12]
1000b7dc0:     	and	w15, w9, #0x4
1000b7dc4:     	lsr	w12, w12, w15
1000b7dc8:     	and	w16, w12, #0xf
1000b7dcc:     	cmp	w16, #8
1000b7dd0:     	csel	w16, wzr, w10, lo
1000b7dd4:     	bfxil	w16, w12, #0, #4
1000b7dd8:     	bfi	x14, x11, #4, #60
1000b7ddc:     	add	x11, x0, x14
1000b7de0:     	ldrb	w12, [x11]
1000b7de4:     	lsr	w12, w12, w15
1000b7de8:     	scvtf	s4, w16
1000b7dec:     	and	w14, w12, #0xf
1000b7df0:     	cmp	w14, #8
1000b7df4:     	csel	w14, wzr, w10, lo
1000b7df8:     	bfxil	w14, w12, #0, #4
1000b7dfc:     	scvtf	s5, w14
1000b7e00:     	fsub	s5, s5, s4
1000b7e04:     	fmadd	s2, s5, s5, s2
1000b7e08:     	str	s2, [x3]
1000b7e0c:     	ldrb	w12, [x11, #4]
1000b7e10:     	lsr	w12, w12, w15
1000b7e14:     	and	w14, w12, #0xf
1000b7e18:     	cmp	w14, #8
1000b7e1c:     	csel	w14, wzr, w10, lo
1000b7e20:     	bfxil	w14, w12, #0, #4
1000b7e24:     	scvtf	s5, w14
1000b7e28:     	fsub	s5, s5, s4
1000b7e2c:     	fmadd	s3, s5, s5, s3
1000b7e30:     	str	s3, [x3, #4]
1000b7e34:     	ldrb	w12, [x11, #8]
1000b7e38:     	lsr	w12, w12, w15
1000b7e3c:     	and	w14, w12, #0xf
1000b7e40:     	cmp	w14, #8
1000b7e44:     	csel	w14, wzr, w10, lo
1000b7e48:     	bfxil	w14, w12, #0, #4
1000b7e4c:     	scvtf	s5, w14
1000b7e50:     	fsub	s5, s5, s4
1000b7e54:     	fmadd	s0, s5, s5, s0
1000b7e58:     	str	s0, [x3, #8]
1000b7e5c:     	ldrb	w11, [x11, #12]
1000b7e60:     	lsr	w11, w11, w15
1000b7e64:     	and	w12, w11, #0xf
1000b7e68:     	cmp	w12, #8
1000b7e6c:     	csel	w12, wzr, w10, lo
1000b7e70:     	bfxil	w12, w11, #0, #4
1000b7e74:     	scvtf	s5, w12
1000b7e78:     	fsub	s4, s5, s4
1000b7e7c:     	fmadd	s1, s4, s4, s1
1000b7e80:     	str	s1, [x3, #12]
1000b7e84:     	add	x13, x13, #1
1000b7e88:     	add	w9, w9, #4
1000b7e8c:     	cmp	x2, x13
1000b7e90:     	b.ne	0x1000b7dac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x318>
1000b7e94:     	ldp	x20, x19, [sp], #16
1000b7e98:     	ret

00000001000b7eb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b7eb8:     	stp	x20, x19, [sp, #-16]!
1000b7ebc:     	stp	xzr, xzr, [x3]
1000b7ec0:     	lsl	x8, x4, #2
1000b7ec4:     	cmp	x2, #8
1000b7ec8:     	b.hs	0x1000b7edc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000b7ecc:     	mov	x13, #0
1000b7ed0:     	movi	d1, #0000000000000000
1000b7ed4:     	movi	d0, #0000000000000000
1000b7ed8:     	b	0x1000b81bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x304>
1000b7edc:     	mov	x10, #0
1000b7ee0:     	add	x9, x0, #8
1000b7ee4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2e8>
1000b7ee8:     	add	x11, x11, #476
1000b7eec:     	mov	x12, x1
1000b7ef0:     	ldr	w13, [x12]
1000b7ef4:     	ldur	w14, [x9, #-8]
1000b7ef8:     	lsl	w15, w14, #4
1000b7efc:     	and	x15, x15, #0xf0
1000b7f00:     	bfxil	x15, x13, #0, #4
1000b7f04:     	and	x16, x14, #0xf0
1000b7f08:     	bfxil	x16, x13, #4, #4
1000b7f0c:     	ldrsb	w16, [x11, x16]
1000b7f10:     	ldrsb	w15, [x11, x15]
1000b7f14:     	lsr	x17, x14, #4
1000b7f18:     	and	x17, x17, #0xf0
1000b7f1c:     	bfxil	x17, x13, #8, #4
1000b7f20:     	lsr	x4, x14, #8
1000b7f24:     	ldrsb	w17, [x11, x17]
1000b7f28:     	and	x4, x4, #0xf0
1000b7f2c:     	bfxil	x4, x13, #12, #4
1000b7f30:     	lsr	x5, x14, #12
1000b7f34:     	and	x5, x5, #0xf0
1000b7f38:     	ldrsb	w4, [x11, x4]
1000b7f3c:     	bfxil	x5, x13, #16, #4
1000b7f40:     	lsr	x6, x14, #16
1000b7f44:     	and	x6, x6, #0xf0
1000b7f48:     	bfxil	x6, x13, #20, #4
1000b7f4c:     	ldrsb	w5, [x11, x5]
1000b7f50:     	ldrsb	w6, [x11, x6]
1000b7f54:     	lsr	x7, x14, #20
1000b7f58:     	and	x7, x7, #0xf0
1000b7f5c:     	add	w15, w15, w16
1000b7f60:     	add	w15, w15, w17
1000b7f64:     	bfxil	x7, x13, #24, #4
1000b7f68:     	ldrsb	w16, [x11, x7]
1000b7f6c:     	lsr	x14, x14, #24
1000b7f70:     	add	w15, w15, w4
1000b7f74:     	add	w15, w15, w5
1000b7f78:     	and	x17, x14, #0xf0
1000b7f7c:     	lsr	x14, x13, #28
1000b7f80:     	orr	x17, x17, x14
1000b7f84:     	ldrsb	w17, [x11, x17]
1000b7f88:     	add	w15, w15, w6
1000b7f8c:     	add	w15, w15, w16
1000b7f90:     	add	w15, w15, w17
1000b7f94:     	scvtf	s0, w15
1000b7f98:     	ldp	s1, s2, [x3]
1000b7f9c:     	fadd	s0, s1, s0
1000b7fa0:     	str	s0, [x3]
1000b7fa4:     	ldur	w15, [x9, #-4]
1000b7fa8:     	lsl	w16, w15, #4
1000b7fac:     	and	x16, x16, #0xf0
1000b7fb0:     	bfxil	x16, x13, #0, #4
1000b7fb4:     	and	x17, x15, #0xf0
1000b7fb8:     	bfxil	x17, x13, #4, #4
1000b7fbc:     	ldrsb	w17, [x11, x17]
1000b7fc0:     	ldrsb	w16, [x11, x16]
1000b7fc4:     	lsr	x4, x15, #4
1000b7fc8:     	and	x4, x4, #0xf0
1000b7fcc:     	bfxil	x4, x13, #8, #4
1000b7fd0:     	ldrsb	w4, [x11, x4]
1000b7fd4:     	lsr	x5, x15, #8
1000b7fd8:     	and	x5, x5, #0xf0
1000b7fdc:     	bfxil	x5, x13, #12, #4
1000b7fe0:     	ldrsb	w5, [x11, x5]
1000b7fe4:     	lsr	x6, x15, #12
1000b7fe8:     	and	x6, x6, #0xf0
1000b7fec:     	bfxil	x6, x13, #16, #4
1000b7ff0:     	ldrsb	w6, [x11, x6]
1000b7ff4:     	lsr	x7, x15, #16
1000b7ff8:     	and	x7, x7, #0xf0
1000b7ffc:     	bfxil	x7, x13, #20, #4
1000b8000:     	ldrsb	w7, [x11, x7]
1000b8004:     	add	w16, w16, w17
1000b8008:     	add	w16, w16, w4
1000b800c:     	lsr	x17, x15, #20
1000b8010:     	and	x17, x17, #0xf0
1000b8014:     	bfxil	x17, x13, #24, #4
1000b8018:     	add	w16, w16, w5
1000b801c:     	add	w16, w16, w6
1000b8020:     	ldrsb	w17, [x11, x17]
1000b8024:     	lsr	x15, x15, #24
1000b8028:     	and	x15, x15, #0xf0
1000b802c:     	add	w16, w16, w7
1000b8030:     	add	w16, w16, w17
1000b8034:     	orr	x15, x15, x14
1000b8038:     	ldrsb	w15, [x11, x15]
1000b803c:     	add	w15, w16, w15
1000b8040:     	scvtf	s0, w15
1000b8044:     	fadd	s0, s2, s0
1000b8048:     	str	s0, [x3, #4]
1000b804c:     	ldr	w15, [x9]
1000b8050:     	lsl	w16, w15, #4
1000b8054:     	and	x16, x16, #0xf0
1000b8058:     	bfxil	x16, x13, #0, #4
1000b805c:     	and	x17, x15, #0xf0
1000b8060:     	bfxil	x17, x13, #4, #4
1000b8064:     	ldrsb	w17, [x11, x17]
1000b8068:     	ldrsb	w16, [x11, x16]
1000b806c:     	lsr	x4, x15, #4
1000b8070:     	and	x4, x4, #0xf0
1000b8074:     	bfxil	x4, x13, #8, #4
1000b8078:     	ldrsb	w4, [x11, x4]
1000b807c:     	lsr	x5, x15, #8
1000b8080:     	and	x5, x5, #0xf0
1000b8084:     	bfxil	x5, x13, #12, #4
1000b8088:     	ldrsb	w5, [x11, x5]
1000b808c:     	lsr	x6, x15, #12
1000b8090:     	and	x6, x6, #0xf0
1000b8094:     	bfxil	x6, x13, #16, #4
1000b8098:     	lsr	x7, x15, #16
1000b809c:     	ldrsb	w6, [x11, x6]
1000b80a0:     	and	x7, x7, #0xf0
1000b80a4:     	bfxil	x7, x13, #20, #4
1000b80a8:     	ldrsb	w7, [x11, x7]
1000b80ac:     	add	w16, w16, w17
1000b80b0:     	add	w16, w16, w4
1000b80b4:     	lsr	x17, x15, #20
1000b80b8:     	and	x17, x17, #0xf0
1000b80bc:     	bfxil	x17, x13, #24, #4
1000b80c0:     	ldrsb	w17, [x11, x17]
1000b80c4:     	add	w16, w16, w5
1000b80c8:     	add	w16, w16, w6
1000b80cc:     	lsr	x15, x15, #24
1000b80d0:     	and	x15, x15, #0xf0
1000b80d4:     	orr	x15, x15, x14
1000b80d8:     	add	w16, w16, w7
1000b80dc:     	add	w16, w16, w17
1000b80e0:     	ldrsb	w15, [x11, x15]
1000b80e4:     	add	w15, w16, w15
1000b80e8:     	scvtf	s0, w15
1000b80ec:     	ldp	s1, s2, [x3, #8]
1000b80f0:     	fadd	s0, s1, s0
1000b80f4:     	str	s0, [x3, #8]
1000b80f8:     	ldr	w15, [x9, #4]
1000b80fc:     	lsl	w16, w15, #4
1000b8100:     	and	x16, x16, #0xf0
1000b8104:     	bfxil	x16, x13, #0, #4
1000b8108:     	and	x17, x15, #0xf0
1000b810c:     	bfxil	x17, x13, #4, #4
1000b8110:     	lsr	x4, x15, #4
1000b8114:     	and	x4, x4, #0xf0
1000b8118:     	bfxil	x4, x13, #8, #4
1000b811c:     	lsr	x5, x15, #8
1000b8120:     	and	x5, x5, #0xf0
1000b8124:     	bfxil	x5, x13, #12, #4
1000b8128:     	lsr	x6, x15, #12
1000b812c:     	and	x6, x6, #0xf0
1000b8130:     	bfxil	x6, x13, #16, #4
1000b8134:     	lsr	x7, x15, #16
1000b8138:     	and	x7, x7, #0xf0
1000b813c:     	bfxil	x7, x13, #20, #4
1000b8140:     	lsr	x19, x15, #20
1000b8144:     	and	x19, x19, #0xf0
1000b8148:     	bfxil	x19, x13, #24, #4
1000b814c:     	ldrsb	w13, [x11, x16]
1000b8150:     	ldrsb	w16, [x11, x17]
1000b8154:     	ldrsb	w17, [x11, x4]
1000b8158:     	ldrsb	w4, [x11, x5]
1000b815c:     	ldrsb	w5, [x11, x6]
1000b8160:     	add	w13, w13, w16
1000b8164:     	add	w13, w13, w17
1000b8168:     	ldrsb	w16, [x11, x7]
1000b816c:     	ldrsb	w17, [x11, x19]
1000b8170:     	add	w13, w13, w4
1000b8174:     	add	w13, w13, w5
1000b8178:     	lsr	x15, x15, #24
1000b817c:     	and	x15, x15, #0xf0
1000b8180:     	orr	x14, x15, x14
1000b8184:     	ldrsb	w14, [x11, x14]
1000b8188:     	add	w13, w13, w16
1000b818c:     	add	w13, w13, w17
1000b8190:     	add	w13, w13, w14
1000b8194:     	scvtf	s1, w13
1000b8198:     	fadd	s1, s2, s1
1000b819c:     	str	s1, [x3, #12]
1000b81a0:     	add	x13, x10, #8
1000b81a4:     	add	x12, x12, x8
1000b81a8:     	add	x9, x9, #16
1000b81ac:     	add	x14, x10, #16
1000b81b0:     	mov	x10, x13
1000b81b4:     	cmp	x14, x2
1000b81b8:     	b.ls	0x1000b7ef0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000b81bc:     	cmp	x13, x2
1000b81c0:     	b.hs	0x1000b82a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000b81c4:     	ldp	s2, s3, [x3]
1000b81c8:     	lsl	w9, w13, #2
1000b81cc:     	mov	w10, #-16
1000b81d0:     	lsr	x11, x13, #3
1000b81d4:     	mul	x12, x8, x11
1000b81d8:     	ubfx	x14, x13, #1, #2
1000b81dc:     	orr	x12, x12, x14
1000b81e0:     	ldrb	w12, [x1, x12]
1000b81e4:     	and	w15, w9, #0x4
1000b81e8:     	lsr	w12, w12, w15
1000b81ec:     	and	w16, w12, #0xf
1000b81f0:     	cmp	w16, #8
1000b81f4:     	csel	w16, wzr, w10, lo
1000b81f8:     	bfxil	w16, w12, #0, #4
1000b81fc:     	bfi	x14, x11, #4, #60
1000b8200:     	add	x11, x0, x14
1000b8204:     	ldrb	w12, [x11]
1000b8208:     	lsr	w12, w12, w15
1000b820c:     	scvtf	s4, w16
1000b8210:     	and	w14, w12, #0xf
1000b8214:     	cmp	w14, #8
1000b8218:     	csel	w14, wzr, w10, lo
1000b821c:     	bfxil	w14, w12, #0, #4
1000b8220:     	scvtf	s5, w14
1000b8224:     	fmsub	s2, s5, s4, s2
1000b8228:     	str	s2, [x3]
1000b822c:     	ldrb	w12, [x11, #4]
1000b8230:     	lsr	w12, w12, w15
1000b8234:     	and	w14, w12, #0xf
1000b8238:     	cmp	w14, #8
1000b823c:     	csel	w14, wzr, w10, lo
1000b8240:     	bfxil	w14, w12, #0, #4
1000b8244:     	scvtf	s5, w14
1000b8248:     	fmsub	s3, s5, s4, s3
1000b824c:     	str	s3, [x3, #4]
1000b8250:     	ldrb	w12, [x11, #8]
1000b8254:     	lsr	w12, w12, w15
1000b8258:     	and	w14, w12, #0xf
1000b825c:     	cmp	w14, #8
1000b8260:     	csel	w14, wzr, w10, lo
1000b8264:     	bfxil	w14, w12, #0, #4
1000b8268:     	scvtf	s5, w14
1000b826c:     	fmsub	s0, s5, s4, s0
1000b8270:     	str	s0, [x3, #8]
1000b8274:     	ldrb	w11, [x11, #12]
1000b8278:     	lsr	w11, w11, w15
1000b827c:     	and	w12, w11, #0xf
1000b8280:     	cmp	w12, #8
1000b8284:     	csel	w12, wzr, w10, lo
1000b8288:     	bfxil	w12, w11, #0, #4
1000b828c:     	scvtf	s5, w12
1000b8290:     	fmsub	s1, s5, s4, s1
1000b8294:     	str	s1, [x3, #12]
1000b8298:     	add	x13, x13, #1
1000b829c:     	add	w9, w9, #4
1000b82a0:     	cmp	x2, x13
1000b82a4:     	b.ne	0x1000b81d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x318>
1000b82a8:     	ldp	x20, x19, [sp], #16
1000b82ac:     	ret

00000001000b9dbc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b9dbc:     	sub	sp, sp, #176
1000b9dc0:     	stp	x28, x27, [sp, #80]
1000b9dc4:     	stp	x26, x25, [sp, #96]
1000b9dc8:     	stp	x24, x23, [sp, #112]
1000b9dcc:     	stp	x22, x21, [sp, #128]
1000b9dd0:     	stp	x20, x19, [sp, #144]
1000b9dd4:     	stp	x29, x30, [sp, #160]
1000b9dd8:     	add	x29, sp, #160
1000b9ddc:     	str	x3, [sp]
1000b9de0:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000b9de4:     	ldr	x8, [x8, #392]
1000b9de8:     	ldr	x8, [x8]
1000b9dec:     	str	x8, [sp, #72]
1000b9df0:     	movi.2d	v0, #0000000000000000
1000b9df4:     	stp	q0, q0, [sp, #32]
1000b9df8:     	ands	x8, x2, #0xfffffffffffffffe
1000b9dfc:     	b.eq	0x1000b9fa0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000b9e00:     	add	x8, x1, x8
1000b9e04:     	str	x8, [sp, #8]
1000b9e08:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24>
1000b9e0c:     	add	x9, x9, #220
1000b9e10:     	mov	x11, #0
1000b9e14:     	ldp	w4, w23, [x1]
1000b9e18:     	ubfx	x8, x4, #4, #4
1000b9e1c:     	stp	x1, x8, [sp, #16]
1000b9e20:     	ubfx	x13, x4, #8, #4
1000b9e24:     	and	x14, x4, #0xf
1000b9e28:     	ubfx	x15, x4, #12, #4
1000b9e2c:     	ubfx	x16, x4, #16, #4
1000b9e30:     	ubfx	x17, x4, #20, #4
1000b9e34:     	ubfx	x2, x4, #24, #4
1000b9e38:     	lsr	x4, x4, #28
1000b9e3c:     	and	x5, x23, #0xf
1000b9e40:     	ubfx	x6, x23, #4, #4
1000b9e44:     	ubfx	x7, x23, #8, #4
1000b9e48:     	ubfx	x19, x23, #12, #4
1000b9e4c:     	ubfx	x20, x23, #16, #4
1000b9e50:     	ubfx	x21, x23, #20, #4
1000b9e54:     	ubfx	x22, x23, #24, #4
1000b9e58:     	lsr	x23, x23, #28
1000b9e5c:     	ldr	w24, [x0, x11]
1000b9e60:     	lsl	w25, w24, #4
1000b9e64:     	and	x25, x25, #0xf0
1000b9e68:     	orr	x26, x25, x14
1000b9e6c:     	ldrb	w26, [x9, x26]
1000b9e70:     	and	x27, x24, #0xf0
1000b9e74:     	ldr	x8, [sp, #24]
1000b9e78:     	orr	x28, x27, x8
1000b9e7c:     	ldrb	w28, [x9, x28]
1000b9e80:     	lsr	x30, x24, #4
1000b9e84:     	and	x30, x30, #0xf0
1000b9e88:     	orr	x8, x30, x13
1000b9e8c:     	ldrb	w8, [x9, x8]
1000b9e90:     	add	w26, w26, w28
1000b9e94:     	add	w8, w26, w8
1000b9e98:     	lsr	x26, x24, #8
1000b9e9c:     	and	x26, x26, #0xf0
1000b9ea0:     	orr	x28, x26, x15
1000b9ea4:     	ldrb	w28, [x9, x28]
1000b9ea8:     	lsr	x3, x24, #12
1000b9eac:     	and	x3, x3, #0xf0
1000b9eb0:     	orr	x10, x3, x16
1000b9eb4:     	ldrb	w10, [x9, x10]
1000b9eb8:     	add	w8, w8, w28
1000b9ebc:     	add	w8, w8, w10
1000b9ec0:     	lsr	x10, x24, #16
1000b9ec4:     	and	x10, x10, #0xf0
1000b9ec8:     	orr	x28, x10, x17
1000b9ecc:     	ldrb	w28, [x9, x28]
1000b9ed0:     	lsr	x1, x24, #20
1000b9ed4:     	and	x1, x1, #0xf0
1000b9ed8:     	orr	x12, x1, x2
1000b9edc:     	ldrb	w12, [x9, x12]
1000b9ee0:     	add	w8, w8, w28
1000b9ee4:     	add	x28, sp, #32
1000b9ee8:     	add	w8, w8, w12
1000b9eec:     	lsr	x12, x24, #24
1000b9ef0:     	and	x12, x12, #0xf0
1000b9ef4:     	orr	x24, x12, x4
1000b9ef8:     	ldrb	w24, [x9, x24]
1000b9efc:     	add	w8, w8, w24
1000b9f00:     	scvtf	s0, w8
1000b9f04:     	add	x8, x28, x11
1000b9f08:     	ldr	s1, [x8]
1000b9f0c:     	fadd	s0, s1, s0
1000b9f10:     	orr	x24, x25, x5
1000b9f14:     	ldrb	w24, [x9, x24]
1000b9f18:     	orr	x25, x27, x6
1000b9f1c:     	ldrb	w25, [x9, x25]
1000b9f20:     	orr	x27, x30, x7
1000b9f24:     	ldrb	w27, [x9, x27]
1000b9f28:     	add	w24, w24, w25
1000b9f2c:     	add	w24, w24, w27
1000b9f30:     	orr	x25, x26, x19
1000b9f34:     	ldrb	w25, [x9, x25]
1000b9f38:     	orr	x3, x3, x20
1000b9f3c:     	ldrb	w3, [x9, x3]
1000b9f40:     	orr	x10, x10, x21
1000b9f44:     	ldrb	w10, [x9, x10]
1000b9f48:     	add	w24, w24, w25
1000b9f4c:     	add	w3, w24, w3
1000b9f50:     	orr	x1, x1, x22
1000b9f54:     	ldrb	w1, [x9, x1]
1000b9f58:     	add	w10, w3, w10
1000b9f5c:     	add	w10, w10, w1
1000b9f60:     	orr	x12, x12, x23
1000b9f64:     	ldrb	w12, [x9, x12]
1000b9f68:     	add	w10, w10, w12
1000b9f6c:     	scvtf	s1, w10
1000b9f70:     	str	s0, [x8]
1000b9f74:     	ldr	s0, [x8, #16]
1000b9f78:     	fadd	s0, s0, s1
1000b9f7c:     	str	s0, [x8, #16]
1000b9f80:     	add	x11, x11, #4
1000b9f84:     	cmp	x11, #16
1000b9f88:     	b.ne	0x1000b9e5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000b9f8c:     	add	x0, x0, #16
1000b9f90:     	ldp	x8, x1, [sp, #8]
1000b9f94:     	add	x1, x1, #8
1000b9f98:     	cmp	x1, x8
1000b9f9c:     	b.ne	0x1000b9e10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000b9fa0:     	ldp	q0, q1, [sp, #32]
1000b9fa4:     	ldr	x8, [sp]
1000b9fa8:     	stp	q0, q1, [x8]
1000b9fac:     	ldr	x8, [sp, #72]
1000b9fb0:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d4>
1000b9fb4:     	ldr	x9, [x9, #392]
1000b9fb8:     	ldr	x9, [x9]
1000b9fbc:     	cmp	x9, x8
1000b9fc0:     	b.ne	0x1000b9fe4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000b9fc4:     	ldp	x29, x30, [sp, #160]
1000b9fc8:     	ldp	x20, x19, [sp, #144]
1000b9fcc:     	ldp	x22, x21, [sp, #128]
1000b9fd0:     	ldp	x24, x23, [sp, #112]
1000b9fd4:     	ldp	x26, x25, [sp, #96]
1000b9fd8:     	ldp	x28, x27, [sp, #80]
1000b9fdc:     	add	sp, sp, #176
1000b9fe0:     	ret
1000b9fe4:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000ba098 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ba098:     	sub	sp, sp, #176
1000ba09c:     	stp	x28, x27, [sp, #80]
1000ba0a0:     	stp	x26, x25, [sp, #96]
1000ba0a4:     	stp	x24, x23, [sp, #112]
1000ba0a8:     	stp	x22, x21, [sp, #128]
1000ba0ac:     	stp	x20, x19, [sp, #144]
1000ba0b0:     	stp	x29, x30, [sp, #160]
1000ba0b4:     	add	x29, sp, #160
1000ba0b8:     	str	x3, [sp]
1000ba0bc:     	adrp	x8, 0x100168000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xb0>
1000ba0c0:     	ldr	x8, [x8, #392]
1000ba0c4:     	ldr	x8, [x8]
1000ba0c8:     	str	x8, [sp, #72]
1000ba0cc:     	movi.2d	v0, #0000000000000000
1000ba0d0:     	stp	q0, q0, [sp, #32]
1000ba0d4:     	ands	x8, x2, #0xfffffffffffffffe
1000ba0d8:     	b.eq	0x1000ba27c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000ba0dc:     	add	x8, x1, x8
1000ba0e0:     	str	x8, [sp, #8]
1000ba0e4:     	adrp	x9, 0x100166000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xd0>
1000ba0e8:     	add	x9, x9, #476
1000ba0ec:     	mov	x11, #0
1000ba0f0:     	ldp	w4, w23, [x1]
1000ba0f4:     	ubfx	x8, x4, #4, #4
1000ba0f8:     	stp	x1, x8, [sp, #16]
1000ba0fc:     	ubfx	x13, x4, #8, #4
1000ba100:     	and	x14, x4, #0xf
1000ba104:     	ubfx	x15, x4, #12, #4
1000ba108:     	ubfx	x16, x4, #16, #4
1000ba10c:     	ubfx	x17, x4, #20, #4
1000ba110:     	ubfx	x2, x4, #24, #4
1000ba114:     	lsr	x4, x4, #28
1000ba118:     	and	x5, x23, #0xf
1000ba11c:     	ubfx	x6, x23, #4, #4
1000ba120:     	ubfx	x7, x23, #8, #4
1000ba124:     	ubfx	x19, x23, #12, #4
1000ba128:     	ubfx	x20, x23, #16, #4
1000ba12c:     	ubfx	x21, x23, #20, #4
1000ba130:     	ubfx	x22, x23, #24, #4
1000ba134:     	lsr	x23, x23, #28
1000ba138:     	ldr	w24, [x0, x11]
1000ba13c:     	lsl	w25, w24, #4
1000ba140:     	and	x25, x25, #0xf0
1000ba144:     	orr	x26, x25, x14
1000ba148:     	ldrsb	w26, [x9, x26]
1000ba14c:     	and	x27, x24, #0xf0
1000ba150:     	ldr	x8, [sp, #24]
1000ba154:     	orr	x28, x27, x8
1000ba158:     	ldrsb	w28, [x9, x28]
1000ba15c:     	lsr	x30, x24, #4
1000ba160:     	and	x30, x30, #0xf0
1000ba164:     	orr	x8, x30, x13
1000ba168:     	ldrsb	w8, [x9, x8]
1000ba16c:     	add	w26, w26, w28
1000ba170:     	add	w8, w26, w8
1000ba174:     	lsr	x26, x24, #8
1000ba178:     	and	x26, x26, #0xf0
1000ba17c:     	orr	x28, x26, x15
1000ba180:     	ldrsb	w28, [x9, x28]
1000ba184:     	lsr	x3, x24, #12
1000ba188:     	and	x3, x3, #0xf0
1000ba18c:     	orr	x10, x3, x16
1000ba190:     	ldrsb	w10, [x9, x10]
1000ba194:     	add	w8, w8, w28
1000ba198:     	add	w8, w8, w10
1000ba19c:     	lsr	x10, x24, #16
1000ba1a0:     	and	x10, x10, #0xf0
1000ba1a4:     	orr	x28, x10, x17
1000ba1a8:     	ldrsb	w28, [x9, x28]
1000ba1ac:     	lsr	x1, x24, #20
1000ba1b0:     	and	x1, x1, #0xf0
1000ba1b4:     	orr	x12, x1, x2
1000ba1b8:     	ldrsb	w12, [x9, x12]
1000ba1bc:     	add	w8, w8, w28
1000ba1c0:     	add	x28, sp, #32
1000ba1c4:     	add	w8, w8, w12
1000ba1c8:     	lsr	x12, x24, #24
1000ba1cc:     	and	x12, x12, #0xf0
1000ba1d0:     	orr	x24, x12, x4
1000ba1d4:     	ldrsb	w24, [x9, x24]
1000ba1d8:     	add	w8, w8, w24
1000ba1dc:     	scvtf	s0, w8
1000ba1e0:     	add	x8, x28, x11
1000ba1e4:     	ldr	s1, [x8]
1000ba1e8:     	fadd	s0, s1, s0
1000ba1ec:     	orr	x24, x25, x5
1000ba1f0:     	ldrsb	w24, [x9, x24]
1000ba1f4:     	orr	x25, x27, x6
1000ba1f8:     	ldrsb	w25, [x9, x25]
1000ba1fc:     	orr	x27, x30, x7
1000ba200:     	ldrsb	w27, [x9, x27]
1000ba204:     	add	w24, w24, w25
1000ba208:     	add	w24, w24, w27
1000ba20c:     	orr	x25, x26, x19
1000ba210:     	ldrsb	w25, [x9, x25]
1000ba214:     	orr	x3, x3, x20
1000ba218:     	ldrsb	w3, [x9, x3]
1000ba21c:     	orr	x10, x10, x21
1000ba220:     	ldrsb	w10, [x9, x10]
1000ba224:     	add	w24, w24, w25
1000ba228:     	add	w3, w24, w3
1000ba22c:     	orr	x1, x1, x22
1000ba230:     	ldrsb	w1, [x9, x1]
1000ba234:     	add	w10, w3, w10
1000ba238:     	add	w10, w10, w1
1000ba23c:     	orr	x12, x12, x23
1000ba240:     	ldrsb	w12, [x9, x12]
1000ba244:     	add	w10, w10, w12
1000ba248:     	scvtf	s1, w10
1000ba24c:     	str	s0, [x8]
1000ba250:     	ldr	s0, [x8, #16]
1000ba254:     	fadd	s0, s0, s1
1000ba258:     	str	s0, [x8, #16]
1000ba25c:     	add	x11, x11, #4
1000ba260:     	cmp	x11, #16
1000ba264:     	b.ne	0x1000ba138 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000ba268:     	add	x0, x0, #16
1000ba26c:     	ldp	x8, x1, [sp, #8]
1000ba270:     	add	x1, x1, #8
1000ba274:     	cmp	x1, x8
1000ba278:     	b.ne	0x1000ba0ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000ba27c:     	ldp	q0, q1, [sp, #32]
1000ba280:     	ldr	x8, [sp]
1000ba284:     	stp	q0, q1, [x8]
1000ba288:     	ldr	x8, [sp, #72]
1000ba28c:     	adrp	x9, 0x100168000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0x280>
1000ba290:     	ldr	x9, [x9, #392]
1000ba294:     	ldr	x9, [x9]
1000ba298:     	cmp	x9, x8
1000ba29c:     	b.ne	0x1000ba2c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000ba2a0:     	ldp	x29, x30, [sp, #160]
1000ba2a4:     	ldp	x20, x19, [sp, #144]
1000ba2a8:     	ldp	x22, x21, [sp, #128]
1000ba2ac:     	ldp	x24, x23, [sp, #112]
1000ba2b0:     	ldp	x26, x25, [sp, #96]
1000ba2b4:     	ldp	x28, x27, [sp, #80]
1000ba2b8:     	add	sp, sp, #176
1000ba2bc:     	ret
1000ba2c0:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000bb548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bb548:     	sub	sp, sp, #352
1000bb54c:     	stp	x28, x27, [sp, #256]
1000bb550:     	stp	x26, x25, [sp, #272]
1000bb554:     	stp	x24, x23, [sp, #288]
1000bb558:     	stp	x22, x21, [sp, #304]
1000bb55c:     	stp	x20, x19, [sp, #320]
1000bb560:     	stp	x29, x30, [sp, #336]
1000bb564:     	add	x29, sp, #336
1000bb568:     	str	x3, [sp]
1000bb56c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2d8>
1000bb570:     	ldr	x8, [x8, #392]
1000bb574:     	ldr	x8, [x8]
1000bb578:     	stur	x8, [x29, #-96]
1000bb57c:     	movi.2d	v0, #0000000000000000
1000bb580:     	stp	q0, q0, [x29, #-128]
1000bb584:     	lsl	x8, x2, #1
1000bb588:     	stp	q0, q0, [x29, #-160]
1000bb58c:     	ands	x8, x8, #0xfffffffffffffffc
1000bb590:     	b.eq	0x1000bb8b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bb594:     	add	x8, x1, x8
1000bb598:     	str	x8, [sp, #8]
1000bb59c:     	sub	x8, x29, #160
1000bb5a0:     	add	x27, x8, #32
1000bb5a4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000bb5a8:     	add	x11, x11, #220
1000bb5ac:     	mov	x12, #0
1000bb5b0:     	ldp	w8, w9, [x1]
1000bb5b4:     	ubfx	x10, x8, #4, #4
1000bb5b8:     	str	x10, [sp, #168]
1000bb5bc:     	ubfx	x10, x8, #8, #4
1000bb5c0:     	str	x10, [sp, #160]
1000bb5c4:     	and	x10, x8, #0xf
1000bb5c8:     	str	x10, [sp, #152]
1000bb5cc:     	ubfx	x10, x8, #12, #4
1000bb5d0:     	str	x10, [sp, #144]
1000bb5d4:     	ubfx	x10, x8, #16, #4
1000bb5d8:     	str	x10, [sp, #136]
1000bb5dc:     	ubfx	x10, x8, #20, #4
1000bb5e0:     	str	x10, [sp, #128]
1000bb5e4:     	ubfx	x10, x8, #24, #4
1000bb5e8:     	lsr	x8, x8, #28
1000bb5ec:     	stp	x8, x10, [sp, #112]
1000bb5f0:     	and	x10, x9, #0xf
1000bb5f4:     	ubfx	x8, x9, #4, #4
1000bb5f8:     	stp	x8, x10, [sp, #96]
1000bb5fc:     	ubfx	x10, x9, #8, #4
1000bb600:     	ubfx	x8, x9, #12, #4
1000bb604:     	stp	x8, x10, [sp, #80]
1000bb608:     	ubfx	x10, x9, #16, #4
1000bb60c:     	ubfx	x8, x9, #20, #4
1000bb610:     	stp	x8, x10, [sp, #64]
1000bb614:     	ubfx	x10, x9, #24, #4
1000bb618:     	lsr	x8, x9, #28
1000bb61c:     	stp	x8, x10, [sp, #48]
1000bb620:     	ldp	w9, w17, [x1, #8]
1000bb624:     	and	x10, x9, #0xf
1000bb628:     	ubfx	x8, x9, #4, #4
1000bb62c:     	stp	x8, x10, [sp, #32]
1000bb630:     	ubfx	x8, x9, #8, #4
1000bb634:     	stp	x1, x8, [sp, #16]
1000bb638:     	ubfx	x28, x9, #12, #4
1000bb63c:     	ubfx	x30, x9, #16, #4
1000bb640:     	ubfx	x8, x9, #20, #4
1000bb644:     	ubfx	x3, x9, #24, #4
1000bb648:     	lsr	x9, x9, #28
1000bb64c:     	and	x1, x17, #0xf
1000bb650:     	ubfx	x10, x17, #4, #4
1000bb654:     	ubfx	x13, x17, #8, #4
1000bb658:     	ubfx	x26, x17, #12, #4
1000bb65c:     	ubfx	x14, x17, #16, #4
1000bb660:     	ubfx	x15, x17, #20, #4
1000bb664:     	ubfx	x16, x17, #24, #4
1000bb668:     	lsr	x17, x17, #28
1000bb66c:     	ldr	w21, [x0, x12]
1000bb670:     	lsl	w2, w21, #4
1000bb674:     	and	x2, x2, #0xf0
1000bb678:     	ldp	x4, x19, [sp, #152]
1000bb67c:     	orr	x4, x2, x4
1000bb680:     	ldrb	w6, [x11, x4]
1000bb684:     	and	x4, x21, #0xf0
1000bb688:     	ldr	x5, [sp, #168]
1000bb68c:     	orr	x5, x4, x5
1000bb690:     	ldrb	w7, [x11, x5]
1000bb694:     	lsr	x5, x21, #4
1000bb698:     	and	x5, x5, #0xf0
1000bb69c:     	orr	x19, x5, x19
1000bb6a0:     	ldrb	w19, [x11, x19]
1000bb6a4:     	add	w6, w6, w7
1000bb6a8:     	add	w19, w6, w19
1000bb6ac:     	lsr	x6, x21, #8
1000bb6b0:     	and	x6, x6, #0xf0
1000bb6b4:     	ldp	x22, x7, [sp, #136]
1000bb6b8:     	orr	x7, x6, x7
1000bb6bc:     	ldrb	w20, [x11, x7]
1000bb6c0:     	lsr	x7, x21, #12
1000bb6c4:     	and	x7, x7, #0xf0
1000bb6c8:     	orr	x22, x7, x22
1000bb6cc:     	ldrb	w22, [x11, x22]
1000bb6d0:     	add	w19, w19, w20
1000bb6d4:     	add	w22, w19, w22
1000bb6d8:     	lsr	x19, x21, #16
1000bb6dc:     	and	x19, x19, #0xf0
1000bb6e0:     	ldp	x24, x20, [sp, #120]
1000bb6e4:     	orr	x20, x19, x20
1000bb6e8:     	ldrb	w23, [x11, x20]
1000bb6ec:     	lsr	x20, x21, #20
1000bb6f0:     	and	x20, x20, #0xf0
1000bb6f4:     	orr	x24, x20, x24
1000bb6f8:     	ldrb	w24, [x11, x24]
1000bb6fc:     	add	w22, w22, w23
1000bb700:     	add	w22, w22, w24
1000bb704:     	lsr	x21, x21, #24
1000bb708:     	and	x21, x21, #0xf0
1000bb70c:     	ldr	x23, [sp, #112]
1000bb710:     	orr	x23, x21, x23
1000bb714:     	ldrb	w23, [x11, x23]
1000bb718:     	add	w22, w22, w23
1000bb71c:     	scvtf	s0, w22
1000bb720:     	ldp	x23, x22, [sp, #96]
1000bb724:     	orr	x22, x2, x22
1000bb728:     	ldrb	w22, [x11, x22]
1000bb72c:     	orr	x23, x4, x23
1000bb730:     	ldrb	w23, [x11, x23]
1000bb734:     	ldr	x24, [sp, #88]
1000bb738:     	orr	x24, x5, x24
1000bb73c:     	ldrb	w24, [x11, x24]
1000bb740:     	add	w22, w22, w23
1000bb744:     	add	w22, w22, w24
1000bb748:     	ldp	x24, x23, [sp, #72]
1000bb74c:     	orr	x23, x6, x23
1000bb750:     	ldrb	w23, [x11, x23]
1000bb754:     	orr	x24, x7, x24
1000bb758:     	ldrb	w24, [x11, x24]
1000bb75c:     	ldr	x25, [sp, #64]
1000bb760:     	orr	x25, x19, x25
1000bb764:     	ldrb	w25, [x11, x25]
1000bb768:     	add	w22, w22, w23
1000bb76c:     	add	w22, w22, w24
1000bb770:     	ldr	x23, [sp, #56]
1000bb774:     	orr	x23, x20, x23
1000bb778:     	ldrb	w23, [x11, x23]
1000bb77c:     	add	w22, w22, w25
1000bb780:     	add	w22, w22, w23
1000bb784:     	ldr	x23, [sp, #48]
1000bb788:     	orr	x23, x21, x23
1000bb78c:     	ldrb	w23, [x11, x23]
1000bb790:     	add	w22, w22, w23
1000bb794:     	scvtf	s1, w22
1000bb798:     	ldp	x23, x22, [sp, #32]
1000bb79c:     	orr	x22, x2, x22
1000bb7a0:     	ldrb	w22, [x11, x22]
1000bb7a4:     	orr	x23, x4, x23
1000bb7a8:     	ldrb	w23, [x11, x23]
1000bb7ac:     	ldr	x24, [sp, #24]
1000bb7b0:     	orr	x24, x5, x24
1000bb7b4:     	ldrb	w24, [x11, x24]
1000bb7b8:     	add	w22, w22, w23
1000bb7bc:     	add	w22, w22, w24
1000bb7c0:     	orr	x23, x6, x28
1000bb7c4:     	ldrb	w23, [x11, x23]
1000bb7c8:     	orr	x24, x7, x30
1000bb7cc:     	ldrb	w24, [x11, x24]
1000bb7d0:     	orr	x25, x19, x8
1000bb7d4:     	ldrb	w25, [x11, x25]
1000bb7d8:     	add	w22, w22, w23
1000bb7dc:     	orr	x23, x20, x3
1000bb7e0:     	ldrb	w23, [x11, x23]
1000bb7e4:     	add	w22, w22, w24
1000bb7e8:     	add	w22, w22, w25
1000bb7ec:     	add	w22, w22, w23
1000bb7f0:     	orr	x23, x21, x9
1000bb7f4:     	ldrb	w23, [x11, x23]
1000bb7f8:     	add	w22, w22, w23
1000bb7fc:     	scvtf	s2, w22
1000bb800:     	orr	x2, x2, x1
1000bb804:     	ldrb	w2, [x11, x2]
1000bb808:     	orr	x4, x4, x10
1000bb80c:     	ldrb	w4, [x11, x4]
1000bb810:     	orr	x5, x5, x13
1000bb814:     	ldrb	w5, [x11, x5]
1000bb818:     	add	w2, w2, w4
1000bb81c:     	add	w2, w2, w5
1000bb820:     	orr	x4, x6, x26
1000bb824:     	ldrb	w4, [x11, x4]
1000bb828:     	orr	x5, x7, x14
1000bb82c:     	ldrb	w5, [x11, x5]
1000bb830:     	add	w2, w2, w4
1000bb834:     	orr	x4, x19, x15
1000bb838:     	ldrb	w4, [x11, x4]
1000bb83c:     	add	w2, w2, w5
1000bb840:     	orr	x5, x20, x16
1000bb844:     	ldrb	w5, [x11, x5]
1000bb848:     	add	w2, w2, w4
1000bb84c:     	add	w2, w2, w5
1000bb850:     	orr	x4, x21, x17
1000bb854:     	ldrb	w4, [x11, x4]
1000bb858:     	add	w2, w2, w4
1000bb85c:     	sub	x4, x29, #160
1000bb860:     	scvtf	s3, w2
1000bb864:     	add	x2, x27, x12
1000bb868:     	ldur	s4, [x2, #-16]
1000bb86c:     	fadd	s1, s4, s1
1000bb870:     	stur	s1, [x2, #-16]
1000bb874:     	ldr	s1, [x2]
1000bb878:     	fadd	s1, s1, s2
1000bb87c:     	str	s1, [x2]
1000bb880:     	ldr	s1, [x2, #16]
1000bb884:     	fadd	s1, s1, s3
1000bb888:     	ldr	s2, [x4, x12]
1000bb88c:     	str	s1, [x2, #16]
1000bb890:     	fadd	s0, s2, s0
1000bb894:     	str	s0, [x4, x12]
1000bb898:     	add	x12, x12, #4
1000bb89c:     	cmp	x12, #16
1000bb8a0:     	b.ne	0x1000bb66c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bb8a4:     	add	x0, x0, #16
1000bb8a8:     	ldp	x8, x1, [sp, #8]
1000bb8ac:     	add	x1, x1, #16
1000bb8b0:     	cmp	x1, x8
1000bb8b4:     	b.ne	0x1000bb5ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bb8b8:     	ldp	q0, q1, [x29, #-160]
1000bb8bc:     	ldr	x8, [sp]
1000bb8c0:     	stp	q0, q1, [x8]
1000bb8c4:     	ldp	q0, q1, [x29, #-128]
1000bb8c8:     	stp	q0, q1, [x8, #32]
1000bb8cc:     	ldur	x8, [x29, #-96]
1000bb8d0:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x184>
1000bb8d4:     	ldr	x9, [x9, #392]
1000bb8d8:     	ldr	x9, [x9]
1000bb8dc:     	cmp	x9, x8
1000bb8e0:     	b.ne	0x1000bb904 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bb8e4:     	ldp	x29, x30, [sp, #336]
1000bb8e8:     	ldp	x20, x19, [sp, #320]
1000bb8ec:     	ldp	x22, x21, [sp, #304]
1000bb8f0:     	ldp	x24, x23, [sp, #288]
1000bb8f4:     	ldp	x26, x25, [sp, #272]
1000bb8f8:     	ldp	x28, x27, [sp, #256]
1000bb8fc:     	add	sp, sp, #352
1000bb900:     	ret
1000bb904:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000bba00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bba00:     	sub	sp, sp, #352
1000bba04:     	stp	x28, x27, [sp, #256]
1000bba08:     	stp	x26, x25, [sp, #272]
1000bba0c:     	stp	x24, x23, [sp, #288]
1000bba10:     	stp	x22, x21, [sp, #304]
1000bba14:     	stp	x20, x19, [sp, #320]
1000bba18:     	stp	x29, x30, [sp, #336]
1000bba1c:     	add	x29, sp, #336
1000bba20:     	str	x3, [sp]
1000bba24:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2d8>
1000bba28:     	ldr	x8, [x8, #392]
1000bba2c:     	ldr	x8, [x8]
1000bba30:     	stur	x8, [x29, #-96]
1000bba34:     	movi.2d	v0, #0000000000000000
1000bba38:     	stp	q0, q0, [x29, #-128]
1000bba3c:     	lsl	x8, x2, #1
1000bba40:     	stp	q0, q0, [x29, #-160]
1000bba44:     	ands	x8, x8, #0xfffffffffffffffc
1000bba48:     	b.eq	0x1000bbd70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bba4c:     	add	x8, x1, x8
1000bba50:     	str	x8, [sp, #8]
1000bba54:     	sub	x8, x29, #160
1000bba58:     	add	x27, x8, #32
1000bba5c:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000bba60:     	add	x11, x11, #476
1000bba64:     	mov	x12, #0
1000bba68:     	ldp	w8, w9, [x1]
1000bba6c:     	ubfx	x10, x8, #4, #4
1000bba70:     	str	x10, [sp, #168]
1000bba74:     	ubfx	x10, x8, #8, #4
1000bba78:     	str	x10, [sp, #160]
1000bba7c:     	and	x10, x8, #0xf
1000bba80:     	str	x10, [sp, #152]
1000bba84:     	ubfx	x10, x8, #12, #4
1000bba88:     	str	x10, [sp, #144]
1000bba8c:     	ubfx	x10, x8, #16, #4
1000bba90:     	str	x10, [sp, #136]
1000bba94:     	ubfx	x10, x8, #20, #4
1000bba98:     	str	x10, [sp, #128]
1000bba9c:     	ubfx	x10, x8, #24, #4
1000bbaa0:     	lsr	x8, x8, #28
1000bbaa4:     	stp	x8, x10, [sp, #112]
1000bbaa8:     	and	x10, x9, #0xf
1000bbaac:     	ubfx	x8, x9, #4, #4
1000bbab0:     	stp	x8, x10, [sp, #96]
1000bbab4:     	ubfx	x10, x9, #8, #4
1000bbab8:     	ubfx	x8, x9, #12, #4
1000bbabc:     	stp	x8, x10, [sp, #80]
1000bbac0:     	ubfx	x10, x9, #16, #4
1000bbac4:     	ubfx	x8, x9, #20, #4
1000bbac8:     	stp	x8, x10, [sp, #64]
1000bbacc:     	ubfx	x10, x9, #24, #4
1000bbad0:     	lsr	x8, x9, #28
1000bbad4:     	stp	x8, x10, [sp, #48]
1000bbad8:     	ldp	w9, w17, [x1, #8]
1000bbadc:     	and	x10, x9, #0xf
1000bbae0:     	ubfx	x8, x9, #4, #4
1000bbae4:     	stp	x8, x10, [sp, #32]
1000bbae8:     	ubfx	x8, x9, #8, #4
1000bbaec:     	stp	x1, x8, [sp, #16]
1000bbaf0:     	ubfx	x28, x9, #12, #4
1000bbaf4:     	ubfx	x30, x9, #16, #4
1000bbaf8:     	ubfx	x8, x9, #20, #4
1000bbafc:     	ubfx	x3, x9, #24, #4
1000bbb00:     	lsr	x9, x9, #28
1000bbb04:     	and	x1, x17, #0xf
1000bbb08:     	ubfx	x10, x17, #4, #4
1000bbb0c:     	ubfx	x13, x17, #8, #4
1000bbb10:     	ubfx	x26, x17, #12, #4
1000bbb14:     	ubfx	x14, x17, #16, #4
1000bbb18:     	ubfx	x15, x17, #20, #4
1000bbb1c:     	ubfx	x16, x17, #24, #4
1000bbb20:     	lsr	x17, x17, #28
1000bbb24:     	ldr	w21, [x0, x12]
1000bbb28:     	lsl	w2, w21, #4
1000bbb2c:     	and	x2, x2, #0xf0
1000bbb30:     	ldp	x4, x19, [sp, #152]
1000bbb34:     	orr	x4, x2, x4
1000bbb38:     	ldrsb	w6, [x11, x4]
1000bbb3c:     	and	x4, x21, #0xf0
1000bbb40:     	ldr	x5, [sp, #168]
1000bbb44:     	orr	x5, x4, x5
1000bbb48:     	ldrsb	w7, [x11, x5]
1000bbb4c:     	lsr	x5, x21, #4
1000bbb50:     	and	x5, x5, #0xf0
1000bbb54:     	orr	x19, x5, x19
1000bbb58:     	ldrsb	w19, [x11, x19]
1000bbb5c:     	add	w6, w6, w7
1000bbb60:     	add	w19, w6, w19
1000bbb64:     	lsr	x6, x21, #8
1000bbb68:     	and	x6, x6, #0xf0
1000bbb6c:     	ldp	x22, x7, [sp, #136]
1000bbb70:     	orr	x7, x6, x7
1000bbb74:     	ldrsb	w20, [x11, x7]
1000bbb78:     	lsr	x7, x21, #12
1000bbb7c:     	and	x7, x7, #0xf0
1000bbb80:     	orr	x22, x7, x22
1000bbb84:     	ldrsb	w22, [x11, x22]
1000bbb88:     	add	w19, w19, w20
1000bbb8c:     	add	w22, w19, w22
1000bbb90:     	lsr	x19, x21, #16
1000bbb94:     	and	x19, x19, #0xf0
1000bbb98:     	ldp	x24, x20, [sp, #120]
1000bbb9c:     	orr	x20, x19, x20
1000bbba0:     	ldrsb	w23, [x11, x20]
1000bbba4:     	lsr	x20, x21, #20
1000bbba8:     	and	x20, x20, #0xf0
1000bbbac:     	orr	x24, x20, x24
1000bbbb0:     	ldrsb	w24, [x11, x24]
1000bbbb4:     	add	w22, w22, w23
1000bbbb8:     	add	w22, w22, w24
1000bbbbc:     	lsr	x21, x21, #24
1000bbbc0:     	and	x21, x21, #0xf0
1000bbbc4:     	ldr	x23, [sp, #112]
1000bbbc8:     	orr	x23, x21, x23
1000bbbcc:     	ldrsb	w23, [x11, x23]
1000bbbd0:     	add	w22, w22, w23
1000bbbd4:     	scvtf	s0, w22
1000bbbd8:     	ldp	x23, x22, [sp, #96]
1000bbbdc:     	orr	x22, x2, x22
1000bbbe0:     	ldrsb	w22, [x11, x22]
1000bbbe4:     	orr	x23, x4, x23
1000bbbe8:     	ldrsb	w23, [x11, x23]
1000bbbec:     	ldr	x24, [sp, #88]
1000bbbf0:     	orr	x24, x5, x24
1000bbbf4:     	ldrsb	w24, [x11, x24]
1000bbbf8:     	add	w22, w22, w23
1000bbbfc:     	add	w22, w22, w24
1000bbc00:     	ldp	x24, x23, [sp, #72]
1000bbc04:     	orr	x23, x6, x23
1000bbc08:     	ldrsb	w23, [x11, x23]
1000bbc0c:     	orr	x24, x7, x24
1000bbc10:     	ldrsb	w24, [x11, x24]
1000bbc14:     	ldr	x25, [sp, #64]
1000bbc18:     	orr	x25, x19, x25
1000bbc1c:     	ldrsb	w25, [x11, x25]
1000bbc20:     	add	w22, w22, w23
1000bbc24:     	add	w22, w22, w24
1000bbc28:     	ldr	x23, [sp, #56]
1000bbc2c:     	orr	x23, x20, x23
1000bbc30:     	ldrsb	w23, [x11, x23]
1000bbc34:     	add	w22, w22, w25
1000bbc38:     	add	w22, w22, w23
1000bbc3c:     	ldr	x23, [sp, #48]
1000bbc40:     	orr	x23, x21, x23
1000bbc44:     	ldrsb	w23, [x11, x23]
1000bbc48:     	add	w22, w22, w23
1000bbc4c:     	scvtf	s1, w22
1000bbc50:     	ldp	x23, x22, [sp, #32]
1000bbc54:     	orr	x22, x2, x22
1000bbc58:     	ldrsb	w22, [x11, x22]
1000bbc5c:     	orr	x23, x4, x23
1000bbc60:     	ldrsb	w23, [x11, x23]
1000bbc64:     	ldr	x24, [sp, #24]
1000bbc68:     	orr	x24, x5, x24
1000bbc6c:     	ldrsb	w24, [x11, x24]
1000bbc70:     	add	w22, w22, w23
1000bbc74:     	add	w22, w22, w24
1000bbc78:     	orr	x23, x6, x28
1000bbc7c:     	ldrsb	w23, [x11, x23]
1000bbc80:     	orr	x24, x7, x30
1000bbc84:     	ldrsb	w24, [x11, x24]
1000bbc88:     	orr	x25, x19, x8
1000bbc8c:     	ldrsb	w25, [x11, x25]
1000bbc90:     	add	w22, w22, w23
1000bbc94:     	orr	x23, x20, x3
1000bbc98:     	ldrsb	w23, [x11, x23]
1000bbc9c:     	add	w22, w22, w24
1000bbca0:     	add	w22, w22, w25
1000bbca4:     	add	w22, w22, w23
1000bbca8:     	orr	x23, x21, x9
1000bbcac:     	ldrsb	w23, [x11, x23]
1000bbcb0:     	add	w22, w22, w23
1000bbcb4:     	scvtf	s2, w22
1000bbcb8:     	orr	x2, x2, x1
1000bbcbc:     	ldrsb	w2, [x11, x2]
1000bbcc0:     	orr	x4, x4, x10
1000bbcc4:     	ldrsb	w4, [x11, x4]
1000bbcc8:     	orr	x5, x5, x13
1000bbccc:     	ldrsb	w5, [x11, x5]
1000bbcd0:     	add	w2, w2, w4
1000bbcd4:     	add	w2, w2, w5
1000bbcd8:     	orr	x4, x6, x26
1000bbcdc:     	ldrsb	w4, [x11, x4]
1000bbce0:     	orr	x5, x7, x14
1000bbce4:     	ldrsb	w5, [x11, x5]
1000bbce8:     	add	w2, w2, w4
1000bbcec:     	orr	x4, x19, x15
1000bbcf0:     	ldrsb	w4, [x11, x4]
1000bbcf4:     	add	w2, w2, w5
1000bbcf8:     	orr	x5, x20, x16
1000bbcfc:     	ldrsb	w5, [x11, x5]
1000bbd00:     	add	w2, w2, w4
1000bbd04:     	add	w2, w2, w5
1000bbd08:     	orr	x4, x21, x17
1000bbd0c:     	ldrsb	w4, [x11, x4]
1000bbd10:     	add	w2, w2, w4
1000bbd14:     	sub	x4, x29, #160
1000bbd18:     	scvtf	s3, w2
1000bbd1c:     	add	x2, x27, x12
1000bbd20:     	ldur	s4, [x2, #-16]
1000bbd24:     	fadd	s1, s4, s1
1000bbd28:     	stur	s1, [x2, #-16]
1000bbd2c:     	ldr	s1, [x2]
1000bbd30:     	fadd	s1, s1, s2
1000bbd34:     	str	s1, [x2]
1000bbd38:     	ldr	s1, [x2, #16]
1000bbd3c:     	fadd	s1, s1, s3
1000bbd40:     	ldr	s2, [x4, x12]
1000bbd44:     	str	s1, [x2, #16]
1000bbd48:     	fadd	s0, s2, s0
1000bbd4c:     	str	s0, [x4, x12]
1000bbd50:     	add	x12, x12, #4
1000bbd54:     	cmp	x12, #16
1000bbd58:     	b.ne	0x1000bbb24 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bbd5c:     	add	x0, x0, #16
1000bbd60:     	ldp	x8, x1, [sp, #8]
1000bbd64:     	add	x1, x1, #16
1000bbd68:     	cmp	x1, x8
1000bbd6c:     	b.ne	0x1000bba64 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bbd70:     	ldp	q0, q1, [x29, #-160]
1000bbd74:     	ldr	x8, [sp]
1000bbd78:     	stp	q0, q1, [x8]
1000bbd7c:     	ldp	q0, q1, [x29, #-128]
1000bbd80:     	stp	q0, q1, [x8, #32]
1000bbd84:     	ldur	x8, [x29, #-96]
1000bbd88:     	adrp	x9, 0x100168000 <void run<unsigned char, 8ul, 1ul, false>(char const*)+0x27c>
1000bbd8c:     	ldr	x9, [x9, #392]
1000bbd90:     	ldr	x9, [x9]
1000bbd94:     	cmp	x9, x8
1000bbd98:     	b.ne	0x1000bbdbc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bbd9c:     	ldp	x29, x30, [sp, #336]
1000bbda0:     	ldp	x20, x19, [sp, #320]
1000bbda4:     	ldp	x22, x21, [sp, #304]
1000bbda8:     	ldp	x24, x23, [sp, #288]
1000bbdac:     	ldp	x26, x25, [sp, #272]
1000bbdb0:     	ldp	x28, x27, [sp, #256]
1000bbdb4:     	add	sp, sp, #352
1000bbdb8:     	ret
1000bbdbc:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000bd4c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bd4c0:     	stp	x22, x21, [sp, #-32]!
1000bd4c4:     	stp	x20, x19, [sp, #16]
1000bd4c8:     	movi.2d	v0, #0000000000000000
1000bd4cc:     	stp	q0, q0, [x3]
1000bd4d0:     	cmp	x2, #8
1000bd4d4:     	b.hs	0x1000bd4e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000bd4d8:     	mov	x8, #0
1000bd4dc:     	b	0x1000bd5f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x130>
1000bd4e0:     	mov	x8, #0
1000bd4e4:     	mov	w14, #8
1000bd4e8:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2cc>
1000bd4ec:     	add	x9, x9, #732
1000bd4f0:     	mov	x10, x0
1000bd4f4:     	mov	x11, #0
1000bd4f8:     	lsr	x8, x8, #1
1000bd4fc:     	mul	x8, x8, x4
1000bd500:     	ldr	w6, [x1, x8]
1000bd504:     	ubfx	x12, x6, #4, #4
1000bd508:     	ubfx	x13, x6, #8, #4
1000bd50c:     	mov	x8, x14
1000bd510:     	ubfx	x14, x6, #12, #4
1000bd514:     	and	x15, x6, #0xf
1000bd518:     	ubfx	x16, x6, #16, #4
1000bd51c:     	ubfx	x17, x6, #20, #4
1000bd520:     	ubfx	x5, x6, #24, #4
1000bd524:     	lsr	x6, x6, #28
1000bd528:     	ldr	w7, [x10, x11]
1000bd52c:     	lsl	w19, w7, #4
1000bd530:     	and	x19, x19, #0xf0
1000bd534:     	orr	x19, x19, x15
1000bd538:     	ldrb	w19, [x9, x19]
1000bd53c:     	and	x20, x7, #0xf0
1000bd540:     	orr	x20, x20, x12
1000bd544:     	ldrb	w20, [x9, x20]
1000bd548:     	lsr	x21, x7, #4
1000bd54c:     	and	x21, x21, #0xf0
1000bd550:     	orr	x21, x21, x13
1000bd554:     	ldrb	w21, [x9, x21]
1000bd558:     	lsr	x22, x7, #8
1000bd55c:     	and	x22, x22, #0xf0
1000bd560:     	orr	x22, x22, x14
1000bd564:     	ldrb	w22, [x9, x22]
1000bd568:     	add	w19, w19, w20
1000bd56c:     	add	w19, w19, w21
1000bd570:     	lsr	x20, x7, #12
1000bd574:     	and	x20, x20, #0xf0
1000bd578:     	orr	x20, x20, x16
1000bd57c:     	ldrb	w20, [x9, x20]
1000bd580:     	lsr	x21, x7, #16
1000bd584:     	and	x21, x21, #0xf0
1000bd588:     	orr	x21, x21, x17
1000bd58c:     	ldrb	w21, [x9, x21]
1000bd590:     	add	w19, w19, w22
1000bd594:     	add	w19, w19, w20
1000bd598:     	lsr	x20, x7, #20
1000bd59c:     	and	x20, x20, #0xf0
1000bd5a0:     	orr	x20, x20, x5
1000bd5a4:     	ldrb	w20, [x9, x20]
1000bd5a8:     	lsr	x7, x7, #24
1000bd5ac:     	and	x7, x7, #0xf0
1000bd5b0:     	orr	x7, x7, x6
1000bd5b4:     	ldrb	w7, [x9, x7]
1000bd5b8:     	add	w19, w19, w21
1000bd5bc:     	add	w19, w19, w20
1000bd5c0:     	add	w7, w19, w7
1000bd5c4:     	scvtf	s0, w7
1000bd5c8:     	ldr	s1, [x3, x11]
1000bd5cc:     	fadd	s0, s1, s0
1000bd5d0:     	str	s0, [x3, x11]
1000bd5d4:     	add	x11, x11, #4
1000bd5d8:     	cmp	x11, #32
1000bd5dc:     	b.ne	0x1000bd528 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x68>
1000bd5e0:     	add	x14, x8, #8
1000bd5e4:     	add	x10, x10, #32
1000bd5e8:     	cmp	x14, x2
1000bd5ec:     	b.ls	0x1000bd4f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000bd5f0:     	cmp	x8, x2
1000bd5f4:     	b.hs	0x1000bd7ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2ec>
1000bd5f8:     	lsl	x9, x4, #2
1000bd5fc:     	ldp	s0, s1, [x3, #8]
1000bd600:     	lsl	x10, x8, #2
1000bd604:     	mov	w11, #-16
1000bd608:     	ldr	s2, [x3, #16]
1000bd60c:     	lsr	x12, x8, #3
1000bd610:     	mul	x13, x9, x12
1000bd614:     	ubfx	x12, x8, #1, #2
1000bd618:     	orr	x13, x13, x12
1000bd61c:     	ldrb	w14, [x1, x13]
1000bd620:     	and	w13, w10, #0x4
1000bd624:     	lsr	w14, w14, w13
1000bd628:     	and	w15, w14, #0xf
1000bd62c:     	cmp	w15, #8
1000bd630:     	csel	w15, wzr, w11, lo
1000bd634:     	and	x16, x10, #0xffffffffffffffe0
1000bd638:     	bfxil	x16, x8, #1, #2
1000bd63c:     	bfxil	w15, w14, #0, #4
1000bd640:     	add	x14, x0, x16
1000bd644:     	ldrb	w16, [x14]
1000bd648:     	lsr	w16, w16, w13
1000bd64c:     	and	w17, w16, #0xf
1000bd650:     	scvtf	s3, w15
1000bd654:     	cmp	w17, #8
1000bd658:     	csel	w15, wzr, w11, lo
1000bd65c:     	bfxil	w15, w16, #0, #4
1000bd660:     	scvtf	s4, w15
1000bd664:     	fsub	s4, s4, s3
1000bd668:     	ldp	s5, s6, [x3]
1000bd66c:     	fmadd	s4, s4, s4, s5
1000bd670:     	str	s4, [x3]
1000bd674:     	ldrb	w15, [x14, #4]
1000bd678:     	lsr	w15, w15, w13
1000bd67c:     	and	w16, w15, #0xf
1000bd680:     	cmp	w16, #8
1000bd684:     	csel	w16, wzr, w11, lo
1000bd688:     	bfxil	w16, w15, #0, #4
1000bd68c:     	scvtf	s4, w16
1000bd690:     	fsub	s4, s4, s3
1000bd694:     	fmadd	s4, s4, s4, s6
1000bd698:     	str	s4, [x3, #4]
1000bd69c:     	ldrb	w15, [x14, #8]
1000bd6a0:     	lsr	w15, w15, w13
1000bd6a4:     	and	w16, w15, #0xf
1000bd6a8:     	cmp	w16, #8
1000bd6ac:     	csel	w16, wzr, w11, lo
1000bd6b0:     	bfxil	w16, w15, #0, #4
1000bd6b4:     	scvtf	s4, w16
1000bd6b8:     	fsub	s4, s4, s3
1000bd6bc:     	fmadd	s0, s4, s4, s0
1000bd6c0:     	str	s0, [x3, #8]
1000bd6c4:     	ldrb	w15, [x14, #12]
1000bd6c8:     	lsr	w15, w15, w13
1000bd6cc:     	and	w16, w15, #0xf
1000bd6d0:     	cmp	w16, #8
1000bd6d4:     	csel	w16, wzr, w11, lo
1000bd6d8:     	bfxil	w16, w15, #0, #4
1000bd6dc:     	scvtf	s4, w16
1000bd6e0:     	fsub	s4, s4, s3
1000bd6e4:     	fmadd	s1, s4, s4, s1
1000bd6e8:     	str	s1, [x3, #12]
1000bd6ec:     	ldrb	w15, [x14, #16]
1000bd6f0:     	lsr	w15, w15, w13
1000bd6f4:     	and	w16, w15, #0xf
1000bd6f8:     	cmp	w16, #8
1000bd6fc:     	csel	w16, wzr, w11, lo
1000bd700:     	bfxil	w16, w15, #0, #4
1000bd704:     	scvtf	s4, w16
1000bd708:     	fsub	s4, s4, s3
1000bd70c:     	fmadd	s2, s4, s4, s2
1000bd710:     	str	s2, [x3, #16]
1000bd714:     	ldrb	w15, [x14, #20]
1000bd718:     	lsr	w15, w15, w13
1000bd71c:     	and	w16, w15, #0xf
1000bd720:     	cmp	w16, #8
1000bd724:     	csel	w16, wzr, w11, lo
1000bd728:     	bfxil	w16, w15, #0, #4
1000bd72c:     	scvtf	s4, w16
1000bd730:     	fsub	s4, s4, s3
1000bd734:     	ldp	s5, s6, [x3, #20]
1000bd738:     	fmadd	s4, s4, s4, s5
1000bd73c:     	str	s4, [x3, #20]
1000bd740:     	ldrb	w14, [x14, #24]
1000bd744:     	lsr	w14, w14, w13
1000bd748:     	and	w15, w14, #0xf
1000bd74c:     	cmp	w15, #8
1000bd750:     	csel	w15, wzr, w11, lo
1000bd754:     	bfxil	w15, w14, #0, #4
1000bd758:     	scvtf	s4, w15
1000bd75c:     	fsub	s4, s4, s3
1000bd760:     	fmadd	s4, s4, s4, s6
1000bd764:     	str	s4, [x3, #24]
1000bd768:     	orr	x12, x10, x12
1000bd76c:     	orr	x12, x12, #0x1c
1000bd770:     	ldrb	w12, [x0, x12]
1000bd774:     	lsr	w12, w12, w13
1000bd778:     	and	w13, w12, #0xf
1000bd77c:     	cmp	w13, #8
1000bd780:     	csel	w13, wzr, w11, lo
1000bd784:     	bfxil	w13, w12, #0, #4
1000bd788:     	scvtf	s4, w13
1000bd78c:     	fsub	s3, s4, s3
1000bd790:     	ldr	s4, [x3, #28]
1000bd794:     	fmadd	s3, s3, s3, s4
1000bd798:     	str	s3, [x3, #28]
1000bd79c:     	add	x8, x8, #1
1000bd7a0:     	add	x10, x10, #4
1000bd7a4:     	cmp	x2, x8
1000bd7a8:     	b.ne	0x1000bd60c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000bd7ac:     	ldp	x20, x19, [sp, #16]
1000bd7b0:     	ldp	x22, x21, [sp], #32
1000bd7b4:     	ret

00000001000bd7d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bd7d8:     	stp	x22, x21, [sp, #-32]!
1000bd7dc:     	stp	x20, x19, [sp, #16]
1000bd7e0:     	movi.2d	v0, #0000000000000000
1000bd7e4:     	stp	q0, q0, [x3]
1000bd7e8:     	cmp	x2, #8
1000bd7ec:     	b.hs	0x1000bd7f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x20>
1000bd7f0:     	mov	x8, #0
1000bd7f4:     	b	0x1000bd908 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x130>
1000bd7f8:     	mov	x8, #0
1000bd7fc:     	mov	w14, #8
1000bd800:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2cc>
1000bd804:     	add	x9, x9, #988
1000bd808:     	mov	x10, x0
1000bd80c:     	mov	x11, #0
1000bd810:     	lsr	x8, x8, #1
1000bd814:     	mul	x8, x8, x4
1000bd818:     	ldr	w6, [x1, x8]
1000bd81c:     	ubfx	x12, x6, #4, #4
1000bd820:     	ubfx	x13, x6, #8, #4
1000bd824:     	mov	x8, x14
1000bd828:     	ubfx	x14, x6, #12, #4
1000bd82c:     	and	x15, x6, #0xf
1000bd830:     	ubfx	x16, x6, #16, #4
1000bd834:     	ubfx	x17, x6, #20, #4
1000bd838:     	ubfx	x5, x6, #24, #4
1000bd83c:     	lsr	x6, x6, #28
1000bd840:     	ldr	w7, [x10, x11]
1000bd844:     	lsl	w19, w7, #4
1000bd848:     	and	x19, x19, #0xf0
1000bd84c:     	orr	x19, x19, x15
1000bd850:     	ldrsb	w19, [x9, x19]
1000bd854:     	and	x20, x7, #0xf0
1000bd858:     	orr	x20, x20, x12
1000bd85c:     	ldrsb	w20, [x9, x20]
1000bd860:     	lsr	x21, x7, #4
1000bd864:     	and	x21, x21, #0xf0
1000bd868:     	orr	x21, x21, x13
1000bd86c:     	ldrsb	w21, [x9, x21]
1000bd870:     	lsr	x22, x7, #8
1000bd874:     	and	x22, x22, #0xf0
1000bd878:     	orr	x22, x22, x14
1000bd87c:     	ldrsb	w22, [x9, x22]
1000bd880:     	add	w19, w19, w20
1000bd884:     	add	w19, w19, w21
1000bd888:     	lsr	x20, x7, #12
1000bd88c:     	and	x20, x20, #0xf0
1000bd890:     	orr	x20, x20, x16
1000bd894:     	ldrsb	w20, [x9, x20]
1000bd898:     	lsr	x21, x7, #16
1000bd89c:     	and	x21, x21, #0xf0
1000bd8a0:     	orr	x21, x21, x17
1000bd8a4:     	ldrsb	w21, [x9, x21]
1000bd8a8:     	add	w19, w19, w22
1000bd8ac:     	add	w19, w19, w20
1000bd8b0:     	lsr	x20, x7, #20
1000bd8b4:     	and	x20, x20, #0xf0
1000bd8b8:     	orr	x20, x20, x5
1000bd8bc:     	ldrsb	w20, [x9, x20]
1000bd8c0:     	lsr	x7, x7, #24
1000bd8c4:     	and	x7, x7, #0xf0
1000bd8c8:     	orr	x7, x7, x6
1000bd8cc:     	ldrsb	w7, [x9, x7]
1000bd8d0:     	add	w19, w19, w21
1000bd8d4:     	add	w19, w19, w20
1000bd8d8:     	add	w7, w19, w7
1000bd8dc:     	scvtf	s0, w7
1000bd8e0:     	ldr	s1, [x3, x11]
1000bd8e4:     	fadd	s0, s1, s0
1000bd8e8:     	str	s0, [x3, x11]
1000bd8ec:     	add	x11, x11, #4
1000bd8f0:     	cmp	x11, #32
1000bd8f4:     	b.ne	0x1000bd840 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x68>
1000bd8f8:     	add	x14, x8, #8
1000bd8fc:     	add	x10, x10, #32
1000bd900:     	cmp	x14, x2
1000bd904:     	b.ls	0x1000bd80c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x34>
1000bd908:     	cmp	x8, x2
1000bd90c:     	b.hs	0x1000bdaa4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2cc>
1000bd910:     	lsl	x9, x4, #2
1000bd914:     	ldp	s0, s1, [x3, #8]
1000bd918:     	lsl	x10, x8, #2
1000bd91c:     	mov	w11, #-16
1000bd920:     	ldr	s2, [x3, #16]
1000bd924:     	lsr	x12, x8, #3
1000bd928:     	mul	x13, x9, x12
1000bd92c:     	ubfx	x12, x8, #1, #2
1000bd930:     	orr	x14, x13, x12
1000bd934:     	and	w13, w10, #0x4
1000bd938:     	ldrb	w14, [x1, x14]
1000bd93c:     	lsr	w14, w14, w13
1000bd940:     	and	w15, w14, #0xf
1000bd944:     	cmp	w15, #8
1000bd948:     	csel	w15, wzr, w11, lo
1000bd94c:     	and	x16, x10, #0xffffffffffffffe0
1000bd950:     	bfxil	w15, w14, #0, #4
1000bd954:     	bfxil	x16, x8, #1, #2
1000bd958:     	add	x14, x0, x16
1000bd95c:     	ldrb	w16, [x14]
1000bd960:     	lsr	w16, w16, w13
1000bd964:     	scvtf	s3, w15
1000bd968:     	and	w15, w16, #0xf
1000bd96c:     	cmp	w15, #8
1000bd970:     	csel	w15, wzr, w11, lo
1000bd974:     	bfxil	w15, w16, #0, #4
1000bd978:     	scvtf	s4, w15
1000bd97c:     	ldp	s5, s6, [x3]
1000bd980:     	fmsub	s4, s4, s3, s5
1000bd984:     	str	s4, [x3]
1000bd988:     	ldrb	w15, [x14, #4]
1000bd98c:     	lsr	w15, w15, w13
1000bd990:     	and	w16, w15, #0xf
1000bd994:     	cmp	w16, #8
1000bd998:     	csel	w16, wzr, w11, lo
1000bd99c:     	bfxil	w16, w15, #0, #4
1000bd9a0:     	scvtf	s4, w16
1000bd9a4:     	fmsub	s4, s4, s3, s6
1000bd9a8:     	str	s4, [x3, #4]
1000bd9ac:     	ldrb	w15, [x14, #8]
1000bd9b0:     	lsr	w15, w15, w13
1000bd9b4:     	and	w16, w15, #0xf
1000bd9b8:     	cmp	w16, #8
1000bd9bc:     	csel	w16, wzr, w11, lo
1000bd9c0:     	bfxil	w16, w15, #0, #4
1000bd9c4:     	scvtf	s4, w16
1000bd9c8:     	fmsub	s0, s4, s3, s0
1000bd9cc:     	str	s0, [x3, #8]
1000bd9d0:     	ldrb	w15, [x14, #12]
1000bd9d4:     	lsr	w15, w15, w13
1000bd9d8:     	and	w16, w15, #0xf
1000bd9dc:     	cmp	w16, #8
1000bd9e0:     	csel	w16, wzr, w11, lo
1000bd9e4:     	bfxil	w16, w15, #0, #4
1000bd9e8:     	scvtf	s4, w16
1000bd9ec:     	fmsub	s1, s4, s3, s1
1000bd9f0:     	str	s1, [x3, #12]
1000bd9f4:     	ldrb	w15, [x14, #16]
1000bd9f8:     	lsr	w15, w15, w13
1000bd9fc:     	and	w16, w15, #0xf
1000bda00:     	cmp	w16, #8
1000bda04:     	csel	w16, wzr, w11, lo
1000bda08:     	bfxil	w16, w15, #0, #4
1000bda0c:     	scvtf	s4, w16
1000bda10:     	fmsub	s2, s4, s3, s2
1000bda14:     	str	s2, [x3, #16]
1000bda18:     	ldrb	w15, [x14, #20]
1000bda1c:     	lsr	w15, w15, w13
1000bda20:     	and	w16, w15, #0xf
1000bda24:     	cmp	w16, #8
1000bda28:     	csel	w16, wzr, w11, lo
1000bda2c:     	bfxil	w16, w15, #0, #4
1000bda30:     	scvtf	s4, w16
1000bda34:     	ldp	s5, s6, [x3, #20]
1000bda38:     	fmsub	s4, s4, s3, s5
1000bda3c:     	str	s4, [x3, #20]
1000bda40:     	ldrb	w14, [x14, #24]
1000bda44:     	lsr	w14, w14, w13
1000bda48:     	and	w15, w14, #0xf
1000bda4c:     	cmp	w15, #8
1000bda50:     	csel	w15, wzr, w11, lo
1000bda54:     	bfxil	w15, w14, #0, #4
1000bda58:     	scvtf	s4, w15
1000bda5c:     	fmsub	s4, s4, s3, s6
1000bda60:     	str	s4, [x3, #24]
1000bda64:     	orr	x12, x10, x12
1000bda68:     	orr	x12, x12, #0x1c
1000bda6c:     	ldrb	w12, [x0, x12]
1000bda70:     	lsr	w12, w12, w13
1000bda74:     	and	w13, w12, #0xf
1000bda78:     	cmp	w13, #8
1000bda7c:     	csel	w13, wzr, w11, lo
1000bda80:     	bfxil	w13, w12, #0, #4
1000bda84:     	scvtf	s4, w13
1000bda88:     	ldr	s5, [x3, #28]
1000bda8c:     	fmsub	s3, s4, s3, s5
1000bda90:     	str	s3, [x3, #28]
1000bda94:     	add	x8, x8, #1
1000bda98:     	add	x10, x10, #4
1000bda9c:     	cmp	x2, x8
1000bdaa0:     	b.ne	0x1000bd924 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000bdaa4:     	ldp	x20, x19, [sp, #16]
1000bdaa8:     	ldp	x22, x21, [sp], #32
1000bdaac:     	ret

00000001000bf050 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bf050:     	sub	sp, sp, #208
1000bf054:     	stp	x28, x27, [sp, #112]
1000bf058:     	stp	x26, x25, [sp, #128]
1000bf05c:     	stp	x24, x23, [sp, #144]
1000bf060:     	stp	x22, x21, [sp, #160]
1000bf064:     	stp	x20, x19, [sp, #176]
1000bf068:     	stp	x29, x30, [sp, #192]
1000bf06c:     	add	x29, sp, #192
1000bf070:     	str	x3, [sp]
1000bf074:     	adrp	x8, 0x100168000 <void kernel<unsigned char, 8ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x90>
1000bf078:     	ldr	x8, [x8, #392]
1000bf07c:     	ldr	x8, [x8]
1000bf080:     	stur	x8, [x29, #-88]
1000bf084:     	movi.2d	v0, #0000000000000000
1000bf088:     	stp	q0, q0, [sp, #64]
1000bf08c:     	stp	q0, q0, [sp, #32]
1000bf090:     	ands	x8, x2, #0xfffffffffffffffe
1000bf094:     	b.eq	0x1000bf238 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e8>
1000bf098:     	add	x8, x1, x8
1000bf09c:     	str	x8, [sp, #8]
1000bf0a0:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>
1000bf0a4:     	add	x9, x9, #732
1000bf0a8:     	mov	x11, #0
1000bf0ac:     	ldp	w4, w23, [x1]
1000bf0b0:     	ubfx	x8, x4, #4, #4
1000bf0b4:     	stp	x1, x8, [sp, #16]
1000bf0b8:     	ubfx	x13, x4, #8, #4
1000bf0bc:     	and	x14, x4, #0xf
1000bf0c0:     	ubfx	x15, x4, #12, #4
1000bf0c4:     	ubfx	x16, x4, #16, #4
1000bf0c8:     	ubfx	x17, x4, #20, #4
1000bf0cc:     	ubfx	x2, x4, #24, #4
1000bf0d0:     	lsr	x4, x4, #28
1000bf0d4:     	and	x5, x23, #0xf
1000bf0d8:     	ubfx	x6, x23, #4, #4
1000bf0dc:     	ubfx	x7, x23, #8, #4
1000bf0e0:     	ubfx	x19, x23, #12, #4
1000bf0e4:     	ubfx	x20, x23, #16, #4
1000bf0e8:     	ubfx	x21, x23, #20, #4
1000bf0ec:     	ubfx	x22, x23, #24, #4
1000bf0f0:     	lsr	x23, x23, #28
1000bf0f4:     	ldr	w24, [x0, x11]
1000bf0f8:     	lsl	w25, w24, #4
1000bf0fc:     	and	x25, x25, #0xf0
1000bf100:     	orr	x26, x25, x14
1000bf104:     	ldrb	w26, [x9, x26]
1000bf108:     	and	x27, x24, #0xf0
1000bf10c:     	ldr	x8, [sp, #24]
1000bf110:     	orr	x28, x27, x8
1000bf114:     	ldrb	w28, [x9, x28]
1000bf118:     	lsr	x30, x24, #4
1000bf11c:     	and	x30, x30, #0xf0
1000bf120:     	orr	x8, x30, x13
1000bf124:     	ldrb	w8, [x9, x8]
1000bf128:     	add	w26, w26, w28
1000bf12c:     	add	w8, w26, w8
1000bf130:     	lsr	x26, x24, #8
1000bf134:     	and	x26, x26, #0xf0
1000bf138:     	orr	x28, x26, x15
1000bf13c:     	ldrb	w28, [x9, x28]
1000bf140:     	lsr	x3, x24, #12
1000bf144:     	and	x3, x3, #0xf0
1000bf148:     	orr	x10, x3, x16
1000bf14c:     	ldrb	w10, [x9, x10]
1000bf150:     	add	w8, w8, w28
1000bf154:     	add	w8, w8, w10
1000bf158:     	lsr	x10, x24, #16
1000bf15c:     	and	x10, x10, #0xf0
1000bf160:     	orr	x28, x10, x17
1000bf164:     	ldrb	w28, [x9, x28]
1000bf168:     	lsr	x1, x24, #20
1000bf16c:     	and	x1, x1, #0xf0
1000bf170:     	orr	x12, x1, x2
1000bf174:     	ldrb	w12, [x9, x12]
1000bf178:     	add	w8, w8, w28
1000bf17c:     	add	x28, sp, #32
1000bf180:     	add	w8, w8, w12
1000bf184:     	lsr	x12, x24, #24
1000bf188:     	and	x12, x12, #0xf0
1000bf18c:     	orr	x24, x12, x4
1000bf190:     	ldrb	w24, [x9, x24]
1000bf194:     	add	w8, w8, w24
1000bf198:     	scvtf	s0, w8
1000bf19c:     	add	x8, x28, x11
1000bf1a0:     	ldr	s1, [x8]
1000bf1a4:     	fadd	s0, s1, s0
1000bf1a8:     	orr	x24, x25, x5
1000bf1ac:     	ldrb	w24, [x9, x24]
1000bf1b0:     	orr	x25, x27, x6
1000bf1b4:     	ldrb	w25, [x9, x25]
1000bf1b8:     	orr	x27, x30, x7
1000bf1bc:     	ldrb	w27, [x9, x27]
1000bf1c0:     	add	w24, w24, w25
1000bf1c4:     	add	w24, w24, w27
1000bf1c8:     	orr	x25, x26, x19
1000bf1cc:     	ldrb	w25, [x9, x25]
1000bf1d0:     	orr	x3, x3, x20
1000bf1d4:     	ldrb	w3, [x9, x3]
1000bf1d8:     	orr	x10, x10, x21
1000bf1dc:     	ldrb	w10, [x9, x10]
1000bf1e0:     	add	w24, w24, w25
1000bf1e4:     	add	w3, w24, w3
1000bf1e8:     	orr	x1, x1, x22
1000bf1ec:     	ldrb	w1, [x9, x1]
1000bf1f0:     	add	w10, w3, w10
1000bf1f4:     	add	w10, w10, w1
1000bf1f8:     	orr	x12, x12, x23
1000bf1fc:     	ldrb	w12, [x9, x12]
1000bf200:     	add	w10, w10, w12
1000bf204:     	scvtf	s1, w10
1000bf208:     	str	s0, [x8]
1000bf20c:     	ldr	s0, [x8, #32]
1000bf210:     	fadd	s0, s0, s1
1000bf214:     	str	s0, [x8, #32]
1000bf218:     	add	x11, x11, #4
1000bf21c:     	cmp	x11, #32
1000bf220:     	b.ne	0x1000bf0f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000bf224:     	add	x0, x0, #32
1000bf228:     	ldp	x8, x1, [sp, #8]
1000bf22c:     	add	x1, x1, #8
1000bf230:     	cmp	x1, x8
1000bf234:     	b.ne	0x1000bf0a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000bf238:     	ldp	q0, q1, [sp, #32]
1000bf23c:     	ldr	x8, [sp]
1000bf240:     	stp	q0, q1, [x8]
1000bf244:     	ldp	q0, q1, [sp, #64]
1000bf248:     	stp	q0, q1, [x8, #32]
1000bf24c:     	ldur	x8, [x29, #-88]
1000bf250:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000bf254:     	ldr	x9, [x9, #392]
1000bf258:     	ldr	x9, [x9]
1000bf25c:     	cmp	x9, x8
1000bf260:     	b.ne	0x1000bf284 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x234>
1000bf264:     	ldp	x29, x30, [sp, #192]
1000bf268:     	ldp	x20, x19, [sp, #176]
1000bf26c:     	ldp	x22, x21, [sp, #160]
1000bf270:     	ldp	x24, x23, [sp, #144]
1000bf274:     	ldp	x26, x25, [sp, #128]
1000bf278:     	ldp	x28, x27, [sp, #112]
1000bf27c:     	add	sp, sp, #208
1000bf280:     	ret
1000bf284:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000bf33c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bf33c:     	sub	sp, sp, #208
1000bf340:     	stp	x28, x27, [sp, #112]
1000bf344:     	stp	x26, x25, [sp, #128]
1000bf348:     	stp	x24, x23, [sp, #144]
1000bf34c:     	stp	x22, x21, [sp, #160]
1000bf350:     	stp	x20, x19, [sp, #176]
1000bf354:     	stp	x29, x30, [sp, #192]
1000bf358:     	add	x29, sp, #192
1000bf35c:     	str	x3, [sp]
1000bf360:     	adrp	x8, 0x100168000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x90>
1000bf364:     	ldr	x8, [x8, #392]
1000bf368:     	ldr	x8, [x8]
1000bf36c:     	stur	x8, [x29, #-88]
1000bf370:     	movi.2d	v0, #0000000000000000
1000bf374:     	stp	q0, q0, [sp, #64]
1000bf378:     	stp	q0, q0, [sp, #32]
1000bf37c:     	ands	x8, x2, #0xfffffffffffffffe
1000bf380:     	b.eq	0x1000bf524 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e8>
1000bf384:     	add	x8, x1, x8
1000bf388:     	str	x8, [sp, #8]
1000bf38c:     	adrp	x9, 0x100166000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xb4>
1000bf390:     	add	x9, x9, #988
1000bf394:     	mov	x11, #0
1000bf398:     	ldp	w4, w23, [x1]
1000bf39c:     	ubfx	x8, x4, #4, #4
1000bf3a0:     	stp	x1, x8, [sp, #16]
1000bf3a4:     	ubfx	x13, x4, #8, #4
1000bf3a8:     	and	x14, x4, #0xf
1000bf3ac:     	ubfx	x15, x4, #12, #4
1000bf3b0:     	ubfx	x16, x4, #16, #4
1000bf3b4:     	ubfx	x17, x4, #20, #4
1000bf3b8:     	ubfx	x2, x4, #24, #4
1000bf3bc:     	lsr	x4, x4, #28
1000bf3c0:     	and	x5, x23, #0xf
1000bf3c4:     	ubfx	x6, x23, #4, #4
1000bf3c8:     	ubfx	x7, x23, #8, #4
1000bf3cc:     	ubfx	x19, x23, #12, #4
1000bf3d0:     	ubfx	x20, x23, #16, #4
1000bf3d4:     	ubfx	x21, x23, #20, #4
1000bf3d8:     	ubfx	x22, x23, #24, #4
1000bf3dc:     	lsr	x23, x23, #28
1000bf3e0:     	ldr	w24, [x0, x11]
1000bf3e4:     	lsl	w25, w24, #4
1000bf3e8:     	and	x25, x25, #0xf0
1000bf3ec:     	orr	x26, x25, x14
1000bf3f0:     	ldrsb	w26, [x9, x26]
1000bf3f4:     	and	x27, x24, #0xf0
1000bf3f8:     	ldr	x8, [sp, #24]
1000bf3fc:     	orr	x28, x27, x8
1000bf400:     	ldrsb	w28, [x9, x28]
1000bf404:     	lsr	x30, x24, #4
1000bf408:     	and	x30, x30, #0xf0
1000bf40c:     	orr	x8, x30, x13
1000bf410:     	ldrsb	w8, [x9, x8]
1000bf414:     	add	w26, w26, w28
1000bf418:     	add	w8, w26, w8
1000bf41c:     	lsr	x26, x24, #8
1000bf420:     	and	x26, x26, #0xf0
1000bf424:     	orr	x28, x26, x15
1000bf428:     	ldrsb	w28, [x9, x28]
1000bf42c:     	lsr	x3, x24, #12
1000bf430:     	and	x3, x3, #0xf0
1000bf434:     	orr	x10, x3, x16
1000bf438:     	ldrsb	w10, [x9, x10]
1000bf43c:     	add	w8, w8, w28
1000bf440:     	add	w8, w8, w10
1000bf444:     	lsr	x10, x24, #16
1000bf448:     	and	x10, x10, #0xf0
1000bf44c:     	orr	x28, x10, x17
1000bf450:     	ldrsb	w28, [x9, x28]
1000bf454:     	lsr	x1, x24, #20
1000bf458:     	and	x1, x1, #0xf0
1000bf45c:     	orr	x12, x1, x2
1000bf460:     	ldrsb	w12, [x9, x12]
1000bf464:     	add	w8, w8, w28
1000bf468:     	add	x28, sp, #32
1000bf46c:     	add	w8, w8, w12
1000bf470:     	lsr	x12, x24, #24
1000bf474:     	and	x12, x12, #0xf0
1000bf478:     	orr	x24, x12, x4
1000bf47c:     	ldrsb	w24, [x9, x24]
1000bf480:     	add	w8, w8, w24
1000bf484:     	scvtf	s0, w8
1000bf488:     	add	x8, x28, x11
1000bf48c:     	ldr	s1, [x8]
1000bf490:     	fadd	s0, s1, s0
1000bf494:     	orr	x24, x25, x5
1000bf498:     	ldrsb	w24, [x9, x24]
1000bf49c:     	orr	x25, x27, x6
1000bf4a0:     	ldrsb	w25, [x9, x25]
1000bf4a4:     	orr	x27, x30, x7
1000bf4a8:     	ldrsb	w27, [x9, x27]
1000bf4ac:     	add	w24, w24, w25
1000bf4b0:     	add	w24, w24, w27
1000bf4b4:     	orr	x25, x26, x19
1000bf4b8:     	ldrsb	w25, [x9, x25]
1000bf4bc:     	orr	x3, x3, x20
1000bf4c0:     	ldrsb	w3, [x9, x3]
1000bf4c4:     	orr	x10, x10, x21
1000bf4c8:     	ldrsb	w10, [x9, x10]
1000bf4cc:     	add	w24, w24, w25
1000bf4d0:     	add	w3, w24, w3
1000bf4d4:     	orr	x1, x1, x22
1000bf4d8:     	ldrsb	w1, [x9, x1]
1000bf4dc:     	add	w10, w3, w10
1000bf4e0:     	add	w10, w10, w1
1000bf4e4:     	orr	x12, x12, x23
1000bf4e8:     	ldrsb	w12, [x9, x12]
1000bf4ec:     	add	w10, w10, w12
1000bf4f0:     	scvtf	s1, w10
1000bf4f4:     	str	s0, [x8]
1000bf4f8:     	ldr	s0, [x8, #32]
1000bf4fc:     	fadd	s0, s0, s1
1000bf500:     	str	s0, [x8, #32]
1000bf504:     	add	x11, x11, #4
1000bf508:     	cmp	x11, #32
1000bf50c:     	b.ne	0x1000bf3e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000bf510:     	add	x0, x0, #32
1000bf514:     	ldp	x8, x1, [sp, #8]
1000bf518:     	add	x1, x1, #8
1000bf51c:     	cmp	x1, x8
1000bf520:     	b.ne	0x1000bf394 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000bf524:     	ldp	q0, q1, [sp, #32]
1000bf528:     	ldr	x8, [sp]
1000bf52c:     	stp	q0, q1, [x8]
1000bf530:     	ldp	q0, q1, [sp, #64]
1000bf534:     	stp	q0, q1, [x8, #32]
1000bf538:     	ldur	x8, [x29, #-88]
1000bf53c:     	adrp	x9, 0x100168000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x26c>
1000bf540:     	ldr	x9, [x9, #392]
1000bf544:     	ldr	x9, [x9]
1000bf548:     	cmp	x9, x8
1000bf54c:     	b.ne	0x1000bf570 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x234>
1000bf550:     	ldp	x29, x30, [sp, #192]
1000bf554:     	ldp	x20, x19, [sp, #176]
1000bf558:     	ldp	x22, x21, [sp, #160]
1000bf55c:     	ldp	x24, x23, [sp, #144]
1000bf560:     	ldp	x26, x25, [sp, #128]
1000bf564:     	ldp	x28, x27, [sp, #112]
1000bf568:     	add	sp, sp, #208
1000bf56c:     	ret
1000bf570:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c0e70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c0e70:     	sub	sp, sp, #416
1000c0e74:     	stp	x28, x27, [sp, #320]
1000c0e78:     	stp	x26, x25, [sp, #336]
1000c0e7c:     	stp	x24, x23, [sp, #352]
1000c0e80:     	stp	x22, x21, [sp, #368]
1000c0e84:     	stp	x20, x19, [sp, #384]
1000c0e88:     	stp	x29, x30, [sp, #400]
1000c0e8c:     	add	x29, sp, #400
1000c0e90:     	str	x3, [sp]
1000c0e94:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c4>
1000c0e98:     	ldr	x8, [x8, #392]
1000c0e9c:     	ldr	x8, [x8]
1000c0ea0:     	stur	x8, [x29, #-96]
1000c0ea4:     	movi.2d	v0, #0000000000000000
1000c0ea8:     	stp	q0, q0, [sp, #272]
1000c0eac:     	lsl	x8, x2, #1
1000c0eb0:     	stp	q0, q0, [sp, #240]
1000c0eb4:     	stp	q0, q0, [sp, #208]
1000c0eb8:     	stp	q0, q0, [sp, #176]
1000c0ebc:     	ands	x8, x8, #0xfffffffffffffffc
1000c0ec0:     	b.eq	0x1000c11e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x378>
1000c0ec4:     	add	x8, x1, x8
1000c0ec8:     	str	x8, [sp, #8]
1000c0ecc:     	add	x8, sp, #176
1000c0ed0:     	add	x27, x8, #64
1000c0ed4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2fc>
1000c0ed8:     	add	x11, x11, #732
1000c0edc:     	mov	x12, #0
1000c0ee0:     	ldp	w8, w9, [x1]
1000c0ee4:     	ubfx	x10, x8, #4, #4
1000c0ee8:     	str	x10, [sp, #168]
1000c0eec:     	ubfx	x10, x8, #8, #4
1000c0ef0:     	str	x10, [sp, #160]
1000c0ef4:     	and	x10, x8, #0xf
1000c0ef8:     	str	x10, [sp, #152]
1000c0efc:     	ubfx	x10, x8, #12, #4
1000c0f00:     	str	x10, [sp, #144]
1000c0f04:     	ubfx	x10, x8, #16, #4
1000c0f08:     	str	x10, [sp, #136]
1000c0f0c:     	ubfx	x10, x8, #20, #4
1000c0f10:     	str	x10, [sp, #128]
1000c0f14:     	ubfx	x10, x8, #24, #4
1000c0f18:     	lsr	x8, x8, #28
1000c0f1c:     	stp	x8, x10, [sp, #112]
1000c0f20:     	and	x10, x9, #0xf
1000c0f24:     	ubfx	x8, x9, #4, #4
1000c0f28:     	stp	x8, x10, [sp, #96]
1000c0f2c:     	ubfx	x10, x9, #8, #4
1000c0f30:     	ubfx	x8, x9, #12, #4
1000c0f34:     	stp	x8, x10, [sp, #80]
1000c0f38:     	ubfx	x10, x9, #16, #4
1000c0f3c:     	ubfx	x8, x9, #20, #4
1000c0f40:     	stp	x8, x10, [sp, #64]
1000c0f44:     	ubfx	x10, x9, #24, #4
1000c0f48:     	lsr	x8, x9, #28
1000c0f4c:     	stp	x8, x10, [sp, #48]
1000c0f50:     	ldp	w9, w17, [x1, #8]
1000c0f54:     	and	x10, x9, #0xf
1000c0f58:     	ubfx	x8, x9, #4, #4
1000c0f5c:     	stp	x8, x10, [sp, #32]
1000c0f60:     	ubfx	x8, x9, #8, #4
1000c0f64:     	stp	x1, x8, [sp, #16]
1000c0f68:     	ubfx	x28, x9, #12, #4
1000c0f6c:     	ubfx	x30, x9, #16, #4
1000c0f70:     	ubfx	x8, x9, #20, #4
1000c0f74:     	ubfx	x3, x9, #24, #4
1000c0f78:     	lsr	x9, x9, #28
1000c0f7c:     	and	x1, x17, #0xf
1000c0f80:     	ubfx	x10, x17, #4, #4
1000c0f84:     	ubfx	x13, x17, #8, #4
1000c0f88:     	ubfx	x26, x17, #12, #4
1000c0f8c:     	ubfx	x14, x17, #16, #4
1000c0f90:     	ubfx	x15, x17, #20, #4
1000c0f94:     	ubfx	x16, x17, #24, #4
1000c0f98:     	lsr	x17, x17, #28
1000c0f9c:     	ldr	w21, [x0, x12]
1000c0fa0:     	lsl	w2, w21, #4
1000c0fa4:     	and	x2, x2, #0xf0
1000c0fa8:     	ldp	x4, x19, [sp, #152]
1000c0fac:     	orr	x4, x2, x4
1000c0fb0:     	ldrb	w6, [x11, x4]
1000c0fb4:     	and	x4, x21, #0xf0
1000c0fb8:     	ldr	x5, [sp, #168]
1000c0fbc:     	orr	x5, x4, x5
1000c0fc0:     	ldrb	w7, [x11, x5]
1000c0fc4:     	lsr	x5, x21, #4
1000c0fc8:     	and	x5, x5, #0xf0
1000c0fcc:     	orr	x19, x5, x19
1000c0fd0:     	ldrb	w19, [x11, x19]
1000c0fd4:     	add	w6, w6, w7
1000c0fd8:     	add	w19, w6, w19
1000c0fdc:     	lsr	x6, x21, #8
1000c0fe0:     	and	x6, x6, #0xf0
1000c0fe4:     	ldp	x22, x7, [sp, #136]
1000c0fe8:     	orr	x7, x6, x7
1000c0fec:     	ldrb	w20, [x11, x7]
1000c0ff0:     	lsr	x7, x21, #12
1000c0ff4:     	and	x7, x7, #0xf0
1000c0ff8:     	orr	x22, x7, x22
1000c0ffc:     	ldrb	w22, [x11, x22]
1000c1000:     	add	w19, w19, w20
1000c1004:     	add	w22, w19, w22
1000c1008:     	lsr	x19, x21, #16
1000c100c:     	and	x19, x19, #0xf0
1000c1010:     	ldp	x24, x20, [sp, #120]
1000c1014:     	orr	x20, x19, x20
1000c1018:     	ldrb	w23, [x11, x20]
1000c101c:     	lsr	x20, x21, #20
1000c1020:     	and	x20, x20, #0xf0
1000c1024:     	orr	x24, x20, x24
1000c1028:     	ldrb	w24, [x11, x24]
1000c102c:     	add	w22, w22, w23
1000c1030:     	add	w22, w22, w24
1000c1034:     	lsr	x21, x21, #24
1000c1038:     	and	x21, x21, #0xf0
1000c103c:     	ldr	x23, [sp, #112]
1000c1040:     	orr	x23, x21, x23
1000c1044:     	ldrb	w23, [x11, x23]
1000c1048:     	add	w22, w22, w23
1000c104c:     	scvtf	s0, w22
1000c1050:     	ldp	x23, x22, [sp, #96]
1000c1054:     	orr	x22, x2, x22
1000c1058:     	ldrb	w22, [x11, x22]
1000c105c:     	orr	x23, x4, x23
1000c1060:     	ldrb	w23, [x11, x23]
1000c1064:     	ldr	x24, [sp, #88]
1000c1068:     	orr	x24, x5, x24
1000c106c:     	ldrb	w24, [x11, x24]
1000c1070:     	add	w22, w22, w23
1000c1074:     	add	w22, w22, w24
1000c1078:     	ldp	x24, x23, [sp, #72]
1000c107c:     	orr	x23, x6, x23
1000c1080:     	ldrb	w23, [x11, x23]
1000c1084:     	orr	x24, x7, x24
1000c1088:     	ldrb	w24, [x11, x24]
1000c108c:     	ldr	x25, [sp, #64]
1000c1090:     	orr	x25, x19, x25
1000c1094:     	ldrb	w25, [x11, x25]
1000c1098:     	add	w22, w22, w23
1000c109c:     	add	w22, w22, w24
1000c10a0:     	ldr	x23, [sp, #56]
1000c10a4:     	orr	x23, x20, x23
1000c10a8:     	ldrb	w23, [x11, x23]
1000c10ac:     	add	w22, w22, w25
1000c10b0:     	add	w22, w22, w23
1000c10b4:     	ldr	x23, [sp, #48]
1000c10b8:     	orr	x23, x21, x23
1000c10bc:     	ldrb	w23, [x11, x23]
1000c10c0:     	add	w22, w22, w23
1000c10c4:     	scvtf	s1, w22
1000c10c8:     	ldp	x23, x22, [sp, #32]
1000c10cc:     	orr	x22, x2, x22
1000c10d0:     	ldrb	w22, [x11, x22]
1000c10d4:     	orr	x23, x4, x23
1000c10d8:     	ldrb	w23, [x11, x23]
1000c10dc:     	ldr	x24, [sp, #24]
1000c10e0:     	orr	x24, x5, x24
1000c10e4:     	ldrb	w24, [x11, x24]
1000c10e8:     	add	w22, w22, w23
1000c10ec:     	add	w22, w22, w24
1000c10f0:     	orr	x23, x6, x28
1000c10f4:     	ldrb	w23, [x11, x23]
1000c10f8:     	orr	x24, x7, x30
1000c10fc:     	ldrb	w24, [x11, x24]
1000c1100:     	orr	x25, x19, x8
1000c1104:     	ldrb	w25, [x11, x25]
1000c1108:     	add	w22, w22, w23
1000c110c:     	orr	x23, x20, x3
1000c1110:     	ldrb	w23, [x11, x23]
1000c1114:     	add	w22, w22, w24
1000c1118:     	add	w22, w22, w25
1000c111c:     	add	w22, w22, w23
1000c1120:     	orr	x23, x21, x9
1000c1124:     	ldrb	w23, [x11, x23]
1000c1128:     	add	w22, w22, w23
1000c112c:     	scvtf	s2, w22
1000c1130:     	orr	x2, x2, x1
1000c1134:     	ldrb	w2, [x11, x2]
1000c1138:     	orr	x4, x4, x10
1000c113c:     	ldrb	w4, [x11, x4]
1000c1140:     	orr	x5, x5, x13
1000c1144:     	ldrb	w5, [x11, x5]
1000c1148:     	add	w2, w2, w4
1000c114c:     	add	w2, w2, w5
1000c1150:     	orr	x4, x6, x26
1000c1154:     	ldrb	w4, [x11, x4]
1000c1158:     	orr	x5, x7, x14
1000c115c:     	ldrb	w5, [x11, x5]
1000c1160:     	add	w2, w2, w4
1000c1164:     	orr	x4, x19, x15
1000c1168:     	ldrb	w4, [x11, x4]
1000c116c:     	add	w2, w2, w5
1000c1170:     	orr	x5, x20, x16
1000c1174:     	ldrb	w5, [x11, x5]
1000c1178:     	add	w2, w2, w4
1000c117c:     	add	w2, w2, w5
1000c1180:     	orr	x4, x21, x17
1000c1184:     	ldrb	w4, [x11, x4]
1000c1188:     	add	w2, w2, w4
1000c118c:     	add	x4, sp, #176
1000c1190:     	scvtf	s3, w2
1000c1194:     	add	x2, x27, x12
1000c1198:     	ldur	s4, [x2, #-32]
1000c119c:     	fadd	s1, s4, s1
1000c11a0:     	stur	s1, [x2, #-32]
1000c11a4:     	ldr	s1, [x2]
1000c11a8:     	fadd	s1, s1, s2
1000c11ac:     	str	s1, [x2]
1000c11b0:     	ldr	s1, [x2, #32]
1000c11b4:     	fadd	s1, s1, s3
1000c11b8:     	ldr	s2, [x4, x12]
1000c11bc:     	str	s1, [x2, #32]
1000c11c0:     	fadd	s0, s2, s0
1000c11c4:     	str	s0, [x4, x12]
1000c11c8:     	add	x12, x12, #4
1000c11cc:     	cmp	x12, #32
1000c11d0:     	b.ne	0x1000c0f9c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x12c>
1000c11d4:     	add	x0, x0, #32
1000c11d8:     	ldp	x8, x1, [sp, #8]
1000c11dc:     	add	x1, x1, #16
1000c11e0:     	cmp	x1, x8
1000c11e4:     	b.ne	0x1000c0edc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c11e8:     	ldp	q0, q1, [sp, #240]
1000c11ec:     	ldr	x8, [sp]
1000c11f0:     	stp	q0, q1, [x8, #64]
1000c11f4:     	ldp	q0, q1, [sp, #272]
1000c11f8:     	stp	q0, q1, [x8, #96]
1000c11fc:     	ldp	q0, q1, [sp, #176]
1000c1200:     	stp	q0, q1, [x8]
1000c1204:     	ldp	q0, q1, [sp, #208]
1000c1208:     	stp	q0, q1, [x8, #32]
1000c120c:     	ldur	x8, [x29, #-96]
1000c1210:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x164>
1000c1214:     	ldr	x9, [x9, #392]
1000c1218:     	ldr	x9, [x9]
1000c121c:     	cmp	x9, x8
1000c1220:     	b.ne	0x1000c1244 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3d4>
1000c1224:     	ldp	x29, x30, [sp, #400]
1000c1228:     	ldp	x20, x19, [sp, #384]
1000c122c:     	ldp	x22, x21, [sp, #368]
1000c1230:     	ldp	x24, x23, [sp, #352]
1000c1234:     	ldp	x26, x25, [sp, #336]
1000c1238:     	ldp	x28, x27, [sp, #320]
1000c123c:     	add	sp, sp, #416
1000c1240:     	ret
1000c1244:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c1348 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c1348:     	sub	sp, sp, #416
1000c134c:     	stp	x28, x27, [sp, #320]
1000c1350:     	stp	x26, x25, [sp, #336]
1000c1354:     	stp	x24, x23, [sp, #352]
1000c1358:     	stp	x22, x21, [sp, #368]
1000c135c:     	stp	x20, x19, [sp, #384]
1000c1360:     	stp	x29, x30, [sp, #400]
1000c1364:     	add	x29, sp, #400
1000c1368:     	str	x3, [sp]
1000c136c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c1370:     	ldr	x8, [x8, #392]
1000c1374:     	ldr	x8, [x8]
1000c1378:     	stur	x8, [x29, #-96]
1000c137c:     	movi.2d	v0, #0000000000000000
1000c1380:     	stp	q0, q0, [sp, #272]
1000c1384:     	lsl	x8, x2, #1
1000c1388:     	stp	q0, q0, [sp, #240]
1000c138c:     	stp	q0, q0, [sp, #208]
1000c1390:     	stp	q0, q0, [sp, #176]
1000c1394:     	ands	x8, x8, #0xfffffffffffffffc
1000c1398:     	b.eq	0x1000c16c0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x378>
1000c139c:     	add	x8, x1, x8
1000c13a0:     	str	x8, [sp, #8]
1000c13a4:     	add	x8, sp, #176
1000c13a8:     	add	x27, x8, #64
1000c13ac:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f8>
1000c13b0:     	add	x11, x11, #988
1000c13b4:     	mov	x12, #0
1000c13b8:     	ldp	w8, w9, [x1]
1000c13bc:     	ubfx	x10, x8, #4, #4
1000c13c0:     	str	x10, [sp, #168]
1000c13c4:     	ubfx	x10, x8, #8, #4
1000c13c8:     	str	x10, [sp, #160]
1000c13cc:     	and	x10, x8, #0xf
1000c13d0:     	str	x10, [sp, #152]
1000c13d4:     	ubfx	x10, x8, #12, #4
1000c13d8:     	str	x10, [sp, #144]
1000c13dc:     	ubfx	x10, x8, #16, #4
1000c13e0:     	str	x10, [sp, #136]
1000c13e4:     	ubfx	x10, x8, #20, #4
1000c13e8:     	str	x10, [sp, #128]
1000c13ec:     	ubfx	x10, x8, #24, #4
1000c13f0:     	lsr	x8, x8, #28
1000c13f4:     	stp	x8, x10, [sp, #112]
1000c13f8:     	and	x10, x9, #0xf
1000c13fc:     	ubfx	x8, x9, #4, #4
1000c1400:     	stp	x8, x10, [sp, #96]
1000c1404:     	ubfx	x10, x9, #8, #4
1000c1408:     	ubfx	x8, x9, #12, #4
1000c140c:     	stp	x8, x10, [sp, #80]
1000c1410:     	ubfx	x10, x9, #16, #4
1000c1414:     	ubfx	x8, x9, #20, #4
1000c1418:     	stp	x8, x10, [sp, #64]
1000c141c:     	ubfx	x10, x9, #24, #4
1000c1420:     	lsr	x8, x9, #28
1000c1424:     	stp	x8, x10, [sp, #48]
1000c1428:     	ldp	w9, w17, [x1, #8]
1000c142c:     	and	x10, x9, #0xf
1000c1430:     	ubfx	x8, x9, #4, #4
1000c1434:     	stp	x8, x10, [sp, #32]
1000c1438:     	ubfx	x8, x9, #8, #4
1000c143c:     	stp	x1, x8, [sp, #16]
1000c1440:     	ubfx	x28, x9, #12, #4
1000c1444:     	ubfx	x30, x9, #16, #4
1000c1448:     	ubfx	x8, x9, #20, #4
1000c144c:     	ubfx	x3, x9, #24, #4
1000c1450:     	lsr	x9, x9, #28
1000c1454:     	and	x1, x17, #0xf
1000c1458:     	ubfx	x10, x17, #4, #4
1000c145c:     	ubfx	x13, x17, #8, #4
1000c1460:     	ubfx	x26, x17, #12, #4
1000c1464:     	ubfx	x14, x17, #16, #4
1000c1468:     	ubfx	x15, x17, #20, #4
1000c146c:     	ubfx	x16, x17, #24, #4
1000c1470:     	lsr	x17, x17, #28
1000c1474:     	ldr	w21, [x0, x12]
1000c1478:     	lsl	w2, w21, #4
1000c147c:     	and	x2, x2, #0xf0
1000c1480:     	ldp	x4, x19, [sp, #152]
1000c1484:     	orr	x4, x2, x4
1000c1488:     	ldrsb	w6, [x11, x4]
1000c148c:     	and	x4, x21, #0xf0
1000c1490:     	ldr	x5, [sp, #168]
1000c1494:     	orr	x5, x4, x5
1000c1498:     	ldrsb	w7, [x11, x5]
1000c149c:     	lsr	x5, x21, #4
1000c14a0:     	and	x5, x5, #0xf0
1000c14a4:     	orr	x19, x5, x19
1000c14a8:     	ldrsb	w19, [x11, x19]
1000c14ac:     	add	w6, w6, w7
1000c14b0:     	add	w19, w6, w19
1000c14b4:     	lsr	x6, x21, #8
1000c14b8:     	and	x6, x6, #0xf0
1000c14bc:     	ldp	x22, x7, [sp, #136]
1000c14c0:     	orr	x7, x6, x7
1000c14c4:     	ldrsb	w20, [x11, x7]
1000c14c8:     	lsr	x7, x21, #12
1000c14cc:     	and	x7, x7, #0xf0
1000c14d0:     	orr	x22, x7, x22
1000c14d4:     	ldrsb	w22, [x11, x22]
1000c14d8:     	add	w19, w19, w20
1000c14dc:     	add	w22, w19, w22
1000c14e0:     	lsr	x19, x21, #16
1000c14e4:     	and	x19, x19, #0xf0
1000c14e8:     	ldp	x24, x20, [sp, #120]
1000c14ec:     	orr	x20, x19, x20
1000c14f0:     	ldrsb	w23, [x11, x20]
1000c14f4:     	lsr	x20, x21, #20
1000c14f8:     	and	x20, x20, #0xf0
1000c14fc:     	orr	x24, x20, x24
1000c1500:     	ldrsb	w24, [x11, x24]
1000c1504:     	add	w22, w22, w23
1000c1508:     	add	w22, w22, w24
1000c150c:     	lsr	x21, x21, #24
1000c1510:     	and	x21, x21, #0xf0
1000c1514:     	ldr	x23, [sp, #112]
1000c1518:     	orr	x23, x21, x23
1000c151c:     	ldrsb	w23, [x11, x23]
1000c1520:     	add	w22, w22, w23
1000c1524:     	scvtf	s0, w22
1000c1528:     	ldp	x23, x22, [sp, #96]
1000c152c:     	orr	x22, x2, x22
1000c1530:     	ldrsb	w22, [x11, x22]
1000c1534:     	orr	x23, x4, x23
1000c1538:     	ldrsb	w23, [x11, x23]
1000c153c:     	ldr	x24, [sp, #88]
1000c1540:     	orr	x24, x5, x24
1000c1544:     	ldrsb	w24, [x11, x24]
1000c1548:     	add	w22, w22, w23
1000c154c:     	add	w22, w22, w24
1000c1550:     	ldp	x24, x23, [sp, #72]
1000c1554:     	orr	x23, x6, x23
1000c1558:     	ldrsb	w23, [x11, x23]
1000c155c:     	orr	x24, x7, x24
1000c1560:     	ldrsb	w24, [x11, x24]
1000c1564:     	ldr	x25, [sp, #64]
1000c1568:     	orr	x25, x19, x25
1000c156c:     	ldrsb	w25, [x11, x25]
1000c1570:     	add	w22, w22, w23
1000c1574:     	add	w22, w22, w24
1000c1578:     	ldr	x23, [sp, #56]
1000c157c:     	orr	x23, x20, x23
1000c1580:     	ldrsb	w23, [x11, x23]
1000c1584:     	add	w22, w22, w25
1000c1588:     	add	w22, w22, w23
1000c158c:     	ldr	x23, [sp, #48]
1000c1590:     	orr	x23, x21, x23
1000c1594:     	ldrsb	w23, [x11, x23]
1000c1598:     	add	w22, w22, w23
1000c159c:     	scvtf	s1, w22
1000c15a0:     	ldp	x23, x22, [sp, #32]
1000c15a4:     	orr	x22, x2, x22
1000c15a8:     	ldrsb	w22, [x11, x22]
1000c15ac:     	orr	x23, x4, x23
1000c15b0:     	ldrsb	w23, [x11, x23]
1000c15b4:     	ldr	x24, [sp, #24]
1000c15b8:     	orr	x24, x5, x24
1000c15bc:     	ldrsb	w24, [x11, x24]
1000c15c0:     	add	w22, w22, w23
1000c15c4:     	add	w22, w22, w24
1000c15c8:     	orr	x23, x6, x28
1000c15cc:     	ldrsb	w23, [x11, x23]
1000c15d0:     	orr	x24, x7, x30
1000c15d4:     	ldrsb	w24, [x11, x24]
1000c15d8:     	orr	x25, x19, x8
1000c15dc:     	ldrsb	w25, [x11, x25]
1000c15e0:     	add	w22, w22, w23
1000c15e4:     	orr	x23, x20, x3
1000c15e8:     	ldrsb	w23, [x11, x23]
1000c15ec:     	add	w22, w22, w24
1000c15f0:     	add	w22, w22, w25
1000c15f4:     	add	w22, w22, w23
1000c15f8:     	orr	x23, x21, x9
1000c15fc:     	ldrsb	w23, [x11, x23]
1000c1600:     	add	w22, w22, w23
1000c1604:     	scvtf	s2, w22
1000c1608:     	orr	x2, x2, x1
1000c160c:     	ldrsb	w2, [x11, x2]
1000c1610:     	orr	x4, x4, x10
1000c1614:     	ldrsb	w4, [x11, x4]
1000c1618:     	orr	x5, x5, x13
1000c161c:     	ldrsb	w5, [x11, x5]
1000c1620:     	add	w2, w2, w4
1000c1624:     	add	w2, w2, w5
1000c1628:     	orr	x4, x6, x26
1000c162c:     	ldrsb	w4, [x11, x4]
1000c1630:     	orr	x5, x7, x14
1000c1634:     	ldrsb	w5, [x11, x5]
1000c1638:     	add	w2, w2, w4
1000c163c:     	orr	x4, x19, x15
1000c1640:     	ldrsb	w4, [x11, x4]
1000c1644:     	add	w2, w2, w5
1000c1648:     	orr	x5, x20, x16
1000c164c:     	ldrsb	w5, [x11, x5]
1000c1650:     	add	w2, w2, w4
1000c1654:     	add	w2, w2, w5
1000c1658:     	orr	x4, x21, x17
1000c165c:     	ldrsb	w4, [x11, x4]
1000c1660:     	add	w2, w2, w4
1000c1664:     	add	x4, sp, #176
1000c1668:     	scvtf	s3, w2
1000c166c:     	add	x2, x27, x12
1000c1670:     	ldur	s4, [x2, #-32]
1000c1674:     	fadd	s1, s4, s1
1000c1678:     	stur	s1, [x2, #-32]
1000c167c:     	ldr	s1, [x2]
1000c1680:     	fadd	s1, s1, s2
1000c1684:     	str	s1, [x2]
1000c1688:     	ldr	s1, [x2, #32]
1000c168c:     	fadd	s1, s1, s3
1000c1690:     	ldr	s2, [x4, x12]
1000c1694:     	str	s1, [x2, #32]
1000c1698:     	fadd	s0, s2, s0
1000c169c:     	str	s0, [x4, x12]
1000c16a0:     	add	x12, x12, #4
1000c16a4:     	cmp	x12, #32
1000c16a8:     	b.ne	0x1000c1474 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x12c>
1000c16ac:     	add	x0, x0, #32
1000c16b0:     	ldp	x8, x1, [sp, #8]
1000c16b4:     	add	x1, x1, #16
1000c16b8:     	cmp	x1, x8
1000c16bc:     	b.ne	0x1000c13b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c16c0:     	ldp	q0, q1, [sp, #240]
1000c16c4:     	ldr	x8, [sp]
1000c16c8:     	stp	q0, q1, [x8, #64]
1000c16cc:     	ldp	q0, q1, [sp, #272]
1000c16d0:     	stp	q0, q1, [x8, #96]
1000c16d4:     	ldp	q0, q1, [sp, #176]
1000c16d8:     	stp	q0, q1, [x8]
1000c16dc:     	ldp	q0, q1, [sp, #208]
1000c16e0:     	stp	q0, q1, [x8, #32]
1000c16e4:     	ldur	x8, [x29, #-96]
1000c16e8:     	adrp	x9, 0x100168000 <void run<unsigned char, 8ul, 8ul, false>(char const*)+0x264>
1000c16ec:     	ldr	x9, [x9, #392]
1000c16f0:     	ldr	x9, [x9]
1000c16f4:     	cmp	x9, x8
1000c16f8:     	b.ne	0x1000c171c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3d4>
1000c16fc:     	ldp	x29, x30, [sp, #400]
1000c1700:     	ldp	x20, x19, [sp, #384]
1000c1704:     	ldp	x22, x21, [sp, #368]
1000c1708:     	ldp	x24, x23, [sp, #352]
1000c170c:     	ldp	x26, x25, [sp, #336]
1000c1710:     	ldp	x28, x27, [sp, #320]
1000c1714:     	add	sp, sp, #416
1000c1718:     	ret
1000c171c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c2cac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c2cac:     	sub	sp, sp, #320
1000c2cb0:     	stp	x22, x21, [sp, #272]
1000c2cb4:     	stp	x20, x19, [sp, #288]
1000c2cb8:     	stp	x29, x30, [sp, #304]
1000c2cbc:     	add	x29, sp, #304
1000c2cc0:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c2cc4:     	ldr	x8, [x8, #392]
1000c2cc8:     	ldr	x8, [x8]
1000c2ccc:     	stur	x8, [x29, #-40]
1000c2cd0:     	movi.2d	v0, #0000000000000000
1000c2cd4:     	stp	q0, q0, [sp, #224]
1000c2cd8:     	lsl	x8, x2, #2
1000c2cdc:     	stp	q0, q0, [sp, #192]
1000c2ce0:     	stp	q0, q0, [sp, #160]
1000c2ce4:     	stp	q0, q0, [sp, #128]
1000c2ce8:     	stp	q0, q0, [sp, #96]
1000c2cec:     	stp	q0, q0, [sp, #64]
1000c2cf0:     	stp	q0, q0, [sp, #32]
1000c2cf4:     	stp	q0, q0, [sp]
1000c2cf8:     	ands	x8, x8, #0xfffffffffffffff8
1000c2cfc:     	b.eq	0x1000c2e14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x168>
1000c2d00:     	add	x8, x1, x8
1000c2d04:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x10c>
1000c2d08:     	add	x9, x9, #732
1000c2d0c:     	mov	x10, #0
1000c2d10:     	mov	x11, sp
1000c2d14:     	mov	x12, #0
1000c2d18:     	ldr	w5, [x0, x10, lsl #2]
1000c2d1c:     	lsl	w13, w5, #4
1000c2d20:     	and	x13, x13, #0xf0
1000c2d24:     	and	x14, x5, #0xf0
1000c2d28:     	lsr	x15, x5, #4
1000c2d2c:     	and	x15, x15, #0xf0
1000c2d30:     	lsr	x16, x5, #8
1000c2d34:     	and	x16, x16, #0xf0
1000c2d38:     	lsr	x17, x5, #12
1000c2d3c:     	and	x17, x17, #0xf0
1000c2d40:     	lsr	x2, x5, #16
1000c2d44:     	and	x2, x2, #0xf0
1000c2d48:     	lsr	x4, x5, #20
1000c2d4c:     	and	x4, x4, #0xf0
1000c2d50:     	lsr	x5, x5, #24
1000c2d54:     	and	x5, x5, #0xf0
1000c2d58:     	mov	x6, x11
1000c2d5c:     	ldr	w7, [x1, x12]
1000c2d60:     	and	x19, x7, #0xf
1000c2d64:     	orr	x19, x13, x19
1000c2d68:     	ldrb	w19, [x9, x19]
1000c2d6c:     	ubfx	x20, x7, #4, #4
1000c2d70:     	orr	x20, x14, x20
1000c2d74:     	ldrb	w20, [x9, x20]
1000c2d78:     	ubfx	x21, x7, #8, #4
1000c2d7c:     	orr	x21, x15, x21
1000c2d80:     	ldrb	w21, [x9, x21]
1000c2d84:     	add	w19, w19, w20
1000c2d88:     	add	w19, w19, w21
1000c2d8c:     	ubfx	x20, x7, #12, #4
1000c2d90:     	orr	x20, x16, x20
1000c2d94:     	ldrb	w20, [x9, x20]
1000c2d98:     	ubfx	x21, x7, #16, #4
1000c2d9c:     	orr	x21, x17, x21
1000c2da0:     	ldrb	w21, [x9, x21]
1000c2da4:     	add	w19, w19, w20
1000c2da8:     	add	w19, w19, w21
1000c2dac:     	ubfx	x20, x7, #20, #4
1000c2db0:     	orr	x20, x2, x20
1000c2db4:     	ldrb	w20, [x9, x20]
1000c2db8:     	ubfx	x21, x7, #24, #4
1000c2dbc:     	orr	x21, x4, x21
1000c2dc0:     	ldrb	w21, [x9, x21]
1000c2dc4:     	add	w19, w19, w20
1000c2dc8:     	add	w19, w19, w21
1000c2dcc:     	orr	x7, x5, x7, lsr #28
1000c2dd0:     	ldrb	w7, [x9, x7]
1000c2dd4:     	add	w7, w19, w7
1000c2dd8:     	scvtf	s0, w7
1000c2ddc:     	ldr	s1, [x6]
1000c2de0:     	fadd	s0, s1, s0
1000c2de4:     	str	s0, [x6], #32
1000c2de8:     	add	x12, x12, #4
1000c2dec:     	cmp	x12, #32
1000c2df0:     	b.ne	0x1000c2d5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c2df4:     	add	x10, x10, #1
1000c2df8:     	add	x11, x11, #4
1000c2dfc:     	cmp	x10, #8
1000c2e00:     	b.ne	0x1000c2d14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x68>
1000c2e04:     	add	x0, x0, #32
1000c2e08:     	add	x1, x1, #32
1000c2e0c:     	cmp	x1, x8
1000c2e10:     	b.ne	0x1000c2d0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c2e14:     	ldp	q0, q1, [sp, #192]
1000c2e18:     	stp	q0, q1, [x3, #192]
1000c2e1c:     	ldp	q0, q1, [sp, #224]
1000c2e20:     	stp	q0, q1, [x3, #224]
1000c2e24:     	ldp	q0, q1, [sp, #128]
1000c2e28:     	stp	q0, q1, [x3, #128]
1000c2e2c:     	ldp	q0, q1, [sp, #160]
1000c2e30:     	stp	q0, q1, [x3, #160]
1000c2e34:     	ldp	q0, q1, [sp, #64]
1000c2e38:     	stp	q0, q1, [x3, #64]
1000c2e3c:     	ldp	q0, q1, [sp, #96]
1000c2e40:     	stp	q0, q1, [x3, #96]
1000c2e44:     	ldp	q0, q1, [sp]
1000c2e48:     	stp	q0, q1, [x3]
1000c2e4c:     	ldp	q0, q1, [sp, #32]
1000c2e50:     	stp	q0, q1, [x3, #32]
1000c2e54:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd8>
1000c2e58:     	ldr	x8, [x8, #392]
1000c2e5c:     	ldr	x8, [x8]
1000c2e60:     	ldur	x9, [x29, #-40]
1000c2e64:     	cmp	x8, x9
1000c2e68:     	b.ne	0x1000c2e80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d4>
1000c2e6c:     	ldp	x29, x30, [sp, #304]
1000c2e70:     	ldp	x20, x19, [sp, #288]
1000c2e74:     	ldp	x22, x21, [sp, #272]
1000c2e78:     	add	sp, sp, #320
1000c2e7c:     	ret
1000c2e80:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c3014 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c3014:     	sub	sp, sp, #320
1000c3018:     	stp	x22, x21, [sp, #272]
1000c301c:     	stp	x20, x19, [sp, #288]
1000c3020:     	stp	x29, x30, [sp, #304]
1000c3024:     	add	x29, sp, #304
1000c3028:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0xd0>
1000c302c:     	ldr	x8, [x8, #392]
1000c3030:     	ldr	x8, [x8]
1000c3034:     	stur	x8, [x29, #-40]
1000c3038:     	movi.2d	v0, #0000000000000000
1000c303c:     	stp	q0, q0, [sp, #224]
1000c3040:     	lsl	x8, x2, #2
1000c3044:     	stp	q0, q0, [sp, #192]
1000c3048:     	stp	q0, q0, [sp, #160]
1000c304c:     	stp	q0, q0, [sp, #128]
1000c3050:     	stp	q0, q0, [sp, #96]
1000c3054:     	stp	q0, q0, [sp, #64]
1000c3058:     	stp	q0, q0, [sp, #32]
1000c305c:     	stp	q0, q0, [sp]
1000c3060:     	ands	x8, x8, #0xfffffffffffffff8
1000c3064:     	b.eq	0x1000c317c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x168>
1000c3068:     	add	x8, x1, x8
1000c306c:     	adrp	x9, 0x100166000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x10c>
1000c3070:     	add	x9, x9, #988
1000c3074:     	mov	x10, #0
1000c3078:     	mov	x11, sp
1000c307c:     	mov	x12, #0
1000c3080:     	ldr	w5, [x0, x10, lsl #2]
1000c3084:     	lsl	w13, w5, #4
1000c3088:     	and	x13, x13, #0xf0
1000c308c:     	and	x14, x5, #0xf0
1000c3090:     	lsr	x15, x5, #4
1000c3094:     	and	x15, x15, #0xf0
1000c3098:     	lsr	x16, x5, #8
1000c309c:     	and	x16, x16, #0xf0
1000c30a0:     	lsr	x17, x5, #12
1000c30a4:     	and	x17, x17, #0xf0
1000c30a8:     	lsr	x2, x5, #16
1000c30ac:     	and	x2, x2, #0xf0
1000c30b0:     	lsr	x4, x5, #20
1000c30b4:     	and	x4, x4, #0xf0
1000c30b8:     	lsr	x5, x5, #24
1000c30bc:     	and	x5, x5, #0xf0
1000c30c0:     	mov	x6, x11
1000c30c4:     	ldr	w7, [x1, x12]
1000c30c8:     	and	x19, x7, #0xf
1000c30cc:     	orr	x19, x13, x19
1000c30d0:     	ldrsb	w19, [x9, x19]
1000c30d4:     	ubfx	x20, x7, #4, #4
1000c30d8:     	orr	x20, x14, x20
1000c30dc:     	ldrsb	w20, [x9, x20]
1000c30e0:     	ubfx	x21, x7, #8, #4
1000c30e4:     	orr	x21, x15, x21
1000c30e8:     	ldrsb	w21, [x9, x21]
1000c30ec:     	add	w19, w19, w20
1000c30f0:     	add	w19, w19, w21
1000c30f4:     	ubfx	x20, x7, #12, #4
1000c30f8:     	orr	x20, x16, x20
1000c30fc:     	ldrsb	w20, [x9, x20]
1000c3100:     	ubfx	x21, x7, #16, #4
1000c3104:     	orr	x21, x17, x21
1000c3108:     	ldrsb	w21, [x9, x21]
1000c310c:     	add	w19, w19, w20
1000c3110:     	add	w19, w19, w21
1000c3114:     	ubfx	x20, x7, #20, #4
1000c3118:     	orr	x20, x2, x20
1000c311c:     	ldrsb	w20, [x9, x20]
1000c3120:     	ubfx	x21, x7, #24, #4
1000c3124:     	orr	x21, x4, x21
1000c3128:     	ldrsb	w21, [x9, x21]
1000c312c:     	add	w19, w19, w20
1000c3130:     	add	w19, w19, w21
1000c3134:     	orr	x7, x5, x7, lsr #28
1000c3138:     	ldrsb	w7, [x9, x7]
1000c313c:     	add	w7, w19, w7
1000c3140:     	scvtf	s0, w7
1000c3144:     	ldr	s1, [x6]
1000c3148:     	fadd	s0, s1, s0
1000c314c:     	str	s0, [x6], #32
1000c3150:     	add	x12, x12, #4
1000c3154:     	cmp	x12, #32
1000c3158:     	b.ne	0x1000c30c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c315c:     	add	x10, x10, #1
1000c3160:     	add	x11, x11, #4
1000c3164:     	cmp	x10, #8
1000c3168:     	b.ne	0x1000c307c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x68>
1000c316c:     	add	x0, x0, #32
1000c3170:     	add	x1, x1, #32
1000c3174:     	cmp	x1, x8
1000c3178:     	b.ne	0x1000c3074 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c317c:     	ldp	q0, q1, [sp, #192]
1000c3180:     	stp	q0, q1, [x3, #192]
1000c3184:     	ldp	q0, q1, [sp, #224]
1000c3188:     	stp	q0, q1, [x3, #224]
1000c318c:     	ldp	q0, q1, [sp, #128]
1000c3190:     	stp	q0, q1, [x3, #128]
1000c3194:     	ldp	q0, q1, [sp, #160]
1000c3198:     	stp	q0, q1, [x3, #160]
1000c319c:     	ldp	q0, q1, [sp, #64]
1000c31a0:     	stp	q0, q1, [x3, #64]
1000c31a4:     	ldp	q0, q1, [sp, #96]
1000c31a8:     	stp	q0, q1, [x3, #96]
1000c31ac:     	ldp	q0, q1, [sp]
1000c31b0:     	stp	q0, q1, [x3]
1000c31b4:     	ldp	q0, q1, [sp, #32]
1000c31b8:     	stp	q0, q1, [x3, #32]
1000c31bc:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x264>
1000c31c0:     	ldr	x8, [x8, #392]
1000c31c4:     	ldr	x8, [x8]
1000c31c8:     	ldur	x9, [x29, #-40]
1000c31cc:     	cmp	x8, x9
1000c31d0:     	b.ne	0x1000c31e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d4>
1000c31d4:     	ldp	x29, x30, [sp, #304]
1000c31d8:     	ldp	x20, x19, [sp, #288]
1000c31dc:     	ldp	x22, x21, [sp, #272]
1000c31e0:     	add	sp, sp, #320
1000c31e4:     	ret
1000c31e8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c4124 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c4124:     	stp	x22, x21, [sp, #-32]!
1000c4128:     	stp	x20, x19, [sp, #16]
1000c412c:     	movi.2d	v0, #0000000000000000
1000c4130:     	stp	q0, q0, [x3, #32]
1000c4134:     	stp	q0, q0, [x3]
1000c4138:     	cmp	x2, #8
1000c413c:     	b.hs	0x1000c4148 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c4140:     	mov	x8, #0
1000c4144:     	b	0x1000c4258 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c4148:     	mov	x8, #0
1000c414c:     	mov	w14, #8
1000c4150:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b4>
1000c4154:     	add	x9, x9, #1244
1000c4158:     	mov	x10, x0
1000c415c:     	mov	x11, #0
1000c4160:     	lsr	x8, x8, #1
1000c4164:     	mul	x8, x8, x4
1000c4168:     	ldr	w6, [x1, x8]
1000c416c:     	ubfx	x12, x6, #4, #4
1000c4170:     	ubfx	x13, x6, #8, #4
1000c4174:     	mov	x8, x14
1000c4178:     	ubfx	x14, x6, #12, #4
1000c417c:     	and	x15, x6, #0xf
1000c4180:     	ubfx	x16, x6, #16, #4
1000c4184:     	ubfx	x17, x6, #20, #4
1000c4188:     	ubfx	x5, x6, #24, #4
1000c418c:     	lsr	x6, x6, #28
1000c4190:     	ldr	w7, [x10, x11]
1000c4194:     	lsl	w19, w7, #4
1000c4198:     	and	x19, x19, #0xf0
1000c419c:     	orr	x19, x19, x15
1000c41a0:     	ldrb	w19, [x9, x19]
1000c41a4:     	and	x20, x7, #0xf0
1000c41a8:     	orr	x20, x20, x12
1000c41ac:     	ldrb	w20, [x9, x20]
1000c41b0:     	lsr	x21, x7, #4
1000c41b4:     	and	x21, x21, #0xf0
1000c41b8:     	orr	x21, x21, x13
1000c41bc:     	ldrb	w21, [x9, x21]
1000c41c0:     	lsr	x22, x7, #8
1000c41c4:     	and	x22, x22, #0xf0
1000c41c8:     	orr	x22, x22, x14
1000c41cc:     	ldrb	w22, [x9, x22]
1000c41d0:     	add	w19, w19, w20
1000c41d4:     	add	w19, w19, w21
1000c41d8:     	lsr	x20, x7, #12
1000c41dc:     	and	x20, x20, #0xf0
1000c41e0:     	orr	x20, x20, x16
1000c41e4:     	ldrb	w20, [x9, x20]
1000c41e8:     	lsr	x21, x7, #16
1000c41ec:     	and	x21, x21, #0xf0
1000c41f0:     	orr	x21, x21, x17
1000c41f4:     	ldrb	w21, [x9, x21]
1000c41f8:     	add	w19, w19, w22
1000c41fc:     	add	w19, w19, w20
1000c4200:     	lsr	x20, x7, #20
1000c4204:     	and	x20, x20, #0xf0
1000c4208:     	orr	x20, x20, x5
1000c420c:     	ldrb	w20, [x9, x20]
1000c4210:     	lsr	x7, x7, #24
1000c4214:     	and	x7, x7, #0xf0
1000c4218:     	orr	x7, x7, x6
1000c421c:     	ldrb	w7, [x9, x7]
1000c4220:     	add	w19, w19, w21
1000c4224:     	add	w19, w19, w20
1000c4228:     	add	w7, w19, w7
1000c422c:     	scvtf	s0, w7
1000c4230:     	ldr	s1, [x3, x11]
1000c4234:     	fadd	s0, s1, s0
1000c4238:     	str	s0, [x3, x11]
1000c423c:     	add	x11, x11, #4
1000c4240:     	cmp	x11, #64
1000c4244:     	b.ne	0x1000c4190 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x6c>
1000c4248:     	add	x14, x8, #8
1000c424c:     	add	x10, x10, #64
1000c4250:     	cmp	x14, x2
1000c4254:     	b.ls	0x1000c415c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c4258:     	cmp	x8, x2
1000c425c:     	b.hs	0x1000c4554 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x430>
1000c4260:     	lsl	x9, x4, #2
1000c4264:     	lsl	w10, w8, #2
1000c4268:     	mov	w11, #-16
1000c426c:     	lsr	x13, x8, #3
1000c4270:     	mul	x12, x9, x13
1000c4274:     	ubfx	x14, x8, #1, #2
1000c4278:     	orr	x15, x12, x14
1000c427c:     	and	w12, w10, #0x4
1000c4280:     	ldrb	w15, [x1, x15]
1000c4284:     	lsr	w15, w15, w12
1000c4288:     	and	w16, w15, #0xf
1000c428c:     	cmp	w16, #8
1000c4290:     	csel	w16, wzr, w11, lo
1000c4294:     	bfi	x14, x13, #6, #58
1000c4298:     	bfxil	w16, w15, #0, #4
1000c429c:     	add	x13, x0, x14
1000c42a0:     	ldrb	w14, [x13]
1000c42a4:     	lsr	w14, w14, w12
1000c42a8:     	and	w15, w14, #0xf
1000c42ac:     	scvtf	s0, w16
1000c42b0:     	cmp	w15, #8
1000c42b4:     	csel	w15, wzr, w11, lo
1000c42b8:     	bfxil	w15, w14, #0, #4
1000c42bc:     	scvtf	s1, w15
1000c42c0:     	fsub	s1, s1, s0
1000c42c4:     	ldp	s2, s3, [x3]
1000c42c8:     	fmadd	s1, s1, s1, s2
1000c42cc:     	str	s1, [x3]
1000c42d0:     	ldrb	w14, [x13, #4]
1000c42d4:     	lsr	w14, w14, w12
1000c42d8:     	and	w15, w14, #0xf
1000c42dc:     	cmp	w15, #8
1000c42e0:     	csel	w15, wzr, w11, lo
1000c42e4:     	bfxil	w15, w14, #0, #4
1000c42e8:     	scvtf	s1, w15
1000c42ec:     	fsub	s1, s1, s0
1000c42f0:     	fmadd	s1, s1, s1, s3
1000c42f4:     	str	s1, [x3, #4]
1000c42f8:     	ldrb	w14, [x13, #8]
1000c42fc:     	lsr	w14, w14, w12
1000c4300:     	and	w15, w14, #0xf
1000c4304:     	cmp	w15, #8
1000c4308:     	csel	w15, wzr, w11, lo
1000c430c:     	bfxil	w15, w14, #0, #4
1000c4310:     	scvtf	s1, w15
1000c4314:     	fsub	s1, s1, s0
1000c4318:     	ldp	s2, s3, [x3, #8]
1000c431c:     	fmadd	s1, s1, s1, s2
1000c4320:     	str	s1, [x3, #8]
1000c4324:     	ldrb	w14, [x13, #12]
1000c4328:     	lsr	w14, w14, w12
1000c432c:     	and	w15, w14, #0xf
1000c4330:     	cmp	w15, #8
1000c4334:     	csel	w15, wzr, w11, lo
1000c4338:     	bfxil	w15, w14, #0, #4
1000c433c:     	scvtf	s1, w15
1000c4340:     	fsub	s1, s1, s0
1000c4344:     	fmadd	s1, s1, s1, s3
1000c4348:     	str	s1, [x3, #12]
1000c434c:     	ldrb	w14, [x13, #16]
1000c4350:     	lsr	w14, w14, w12
1000c4354:     	and	w15, w14, #0xf
1000c4358:     	cmp	w15, #8
1000c435c:     	csel	w15, wzr, w11, lo
1000c4360:     	bfxil	w15, w14, #0, #4
1000c4364:     	scvtf	s1, w15
1000c4368:     	fsub	s1, s1, s0
1000c436c:     	ldp	s2, s3, [x3, #16]
1000c4370:     	fmadd	s1, s1, s1, s2
1000c4374:     	str	s1, [x3, #16]
1000c4378:     	ldrb	w14, [x13, #20]
1000c437c:     	lsr	w14, w14, w12
1000c4380:     	and	w15, w14, #0xf
1000c4384:     	cmp	w15, #8
1000c4388:     	csel	w15, wzr, w11, lo
1000c438c:     	bfxil	w15, w14, #0, #4
1000c4390:     	scvtf	s1, w15
1000c4394:     	fsub	s1, s1, s0
1000c4398:     	fmadd	s1, s1, s1, s3
1000c439c:     	str	s1, [x3, #20]
1000c43a0:     	ldrb	w14, [x13, #24]
1000c43a4:     	lsr	w14, w14, w12
1000c43a8:     	and	w15, w14, #0xf
1000c43ac:     	cmp	w15, #8
1000c43b0:     	csel	w15, wzr, w11, lo
1000c43b4:     	bfxil	w15, w14, #0, #4
1000c43b8:     	scvtf	s1, w15
1000c43bc:     	fsub	s1, s1, s0
1000c43c0:     	ldp	s2, s3, [x3, #24]
1000c43c4:     	fmadd	s1, s1, s1, s2
1000c43c8:     	str	s1, [x3, #24]
1000c43cc:     	ldrb	w14, [x13, #28]
1000c43d0:     	lsr	w14, w14, w12
1000c43d4:     	and	w15, w14, #0xf
1000c43d8:     	cmp	w15, #8
1000c43dc:     	csel	w15, wzr, w11, lo
1000c43e0:     	bfxil	w15, w14, #0, #4
1000c43e4:     	scvtf	s1, w15
1000c43e8:     	fsub	s1, s1, s0
1000c43ec:     	fmadd	s1, s1, s1, s3
1000c43f0:     	str	s1, [x3, #28]
1000c43f4:     	ldrb	w14, [x13, #32]
1000c43f8:     	lsr	w14, w14, w12
1000c43fc:     	and	w15, w14, #0xf
1000c4400:     	cmp	w15, #8
1000c4404:     	csel	w15, wzr, w11, lo
1000c4408:     	bfxil	w15, w14, #0, #4
1000c440c:     	scvtf	s1, w15
1000c4410:     	fsub	s1, s1, s0
1000c4414:     	ldp	s2, s3, [x3, #32]
1000c4418:     	fmadd	s1, s1, s1, s2
1000c441c:     	str	s1, [x3, #32]
1000c4420:     	ldrb	w14, [x13, #36]
1000c4424:     	lsr	w14, w14, w12
1000c4428:     	and	w15, w14, #0xf
1000c442c:     	cmp	w15, #8
1000c4430:     	csel	w15, wzr, w11, lo
1000c4434:     	bfxil	w15, w14, #0, #4
1000c4438:     	scvtf	s1, w15
1000c443c:     	fsub	s1, s1, s0
1000c4440:     	fmadd	s1, s1, s1, s3
1000c4444:     	str	s1, [x3, #36]
1000c4448:     	ldrb	w14, [x13, #40]
1000c444c:     	lsr	w14, w14, w12
1000c4450:     	and	w15, w14, #0xf
1000c4454:     	cmp	w15, #8
1000c4458:     	csel	w15, wzr, w11, lo
1000c445c:     	bfxil	w15, w14, #0, #4
1000c4460:     	scvtf	s1, w15
1000c4464:     	fsub	s1, s1, s0
1000c4468:     	ldp	s2, s3, [x3, #40]
1000c446c:     	fmadd	s1, s1, s1, s2
1000c4470:     	str	s1, [x3, #40]
1000c4474:     	ldrb	w14, [x13, #44]
1000c4478:     	lsr	w14, w14, w12
1000c447c:     	and	w15, w14, #0xf
1000c4480:     	cmp	w15, #8
1000c4484:     	csel	w15, wzr, w11, lo
1000c4488:     	bfxil	w15, w14, #0, #4
1000c448c:     	scvtf	s1, w15
1000c4490:     	fsub	s1, s1, s0
1000c4494:     	fmadd	s1, s1, s1, s3
1000c4498:     	str	s1, [x3, #44]
1000c449c:     	ldrb	w14, [x13, #48]
1000c44a0:     	lsr	w14, w14, w12
1000c44a4:     	and	w15, w14, #0xf
1000c44a8:     	cmp	w15, #8
1000c44ac:     	csel	w15, wzr, w11, lo
1000c44b0:     	bfxil	w15, w14, #0, #4
1000c44b4:     	scvtf	s1, w15
1000c44b8:     	fsub	s1, s1, s0
1000c44bc:     	ldp	s2, s3, [x3, #48]
1000c44c0:     	fmadd	s1, s1, s1, s2
1000c44c4:     	str	s1, [x3, #48]
1000c44c8:     	ldrb	w14, [x13, #52]
1000c44cc:     	lsr	w14, w14, w12
1000c44d0:     	and	w15, w14, #0xf
1000c44d4:     	cmp	w15, #8
1000c44d8:     	csel	w15, wzr, w11, lo
1000c44dc:     	bfxil	w15, w14, #0, #4
1000c44e0:     	scvtf	s1, w15
1000c44e4:     	fsub	s1, s1, s0
1000c44e8:     	fmadd	s1, s1, s1, s3
1000c44ec:     	str	s1, [x3, #52]
1000c44f0:     	ldrb	w14, [x13, #56]
1000c44f4:     	lsr	w14, w14, w12
1000c44f8:     	and	w15, w14, #0xf
1000c44fc:     	cmp	w15, #8
1000c4500:     	csel	w15, wzr, w11, lo
1000c4504:     	bfxil	w15, w14, #0, #4
1000c4508:     	scvtf	s1, w15
1000c450c:     	fsub	s1, s1, s0
1000c4510:     	ldp	s2, s3, [x3, #56]
1000c4514:     	fmadd	s1, s1, s1, s2
1000c4518:     	str	s1, [x3, #56]
1000c451c:     	ldrb	w13, [x13, #60]
1000c4520:     	lsr	w12, w13, w12
1000c4524:     	and	w13, w12, #0xf
1000c4528:     	cmp	w13, #8
1000c452c:     	csel	w13, wzr, w11, lo
1000c4530:     	bfxil	w13, w12, #0, #4
1000c4534:     	scvtf	s1, w13
1000c4538:     	fsub	s0, s1, s0
1000c453c:     	fmadd	s0, s0, s0, s3
1000c4540:     	str	s0, [x3, #60]
1000c4544:     	add	x8, x8, #1
1000c4548:     	add	w10, w10, #4
1000c454c:     	cmp	x2, x8
1000c4550:     	b.ne	0x1000c426c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c4554:     	ldp	x20, x19, [sp, #16]
1000c4558:     	ldp	x22, x21, [sp], #32
1000c455c:     	ret

00000001000c4584 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c4584:     	stp	x22, x21, [sp, #-32]!
1000c4588:     	stp	x20, x19, [sp, #16]
1000c458c:     	movi.2d	v0, #0000000000000000
1000c4590:     	stp	q0, q0, [x3, #32]
1000c4594:     	stp	q0, q0, [x3]
1000c4598:     	cmp	x2, #8
1000c459c:     	b.hs	0x1000c45a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c45a0:     	mov	x8, #0
1000c45a4:     	b	0x1000c46b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c45a8:     	mov	x8, #0
1000c45ac:     	mov	w14, #8
1000c45b0:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b4>
1000c45b4:     	add	x9, x9, #1500
1000c45b8:     	mov	x10, x0
1000c45bc:     	mov	x11, #0
1000c45c0:     	lsr	x8, x8, #1
1000c45c4:     	mul	x8, x8, x4
1000c45c8:     	ldr	w6, [x1, x8]
1000c45cc:     	ubfx	x12, x6, #4, #4
1000c45d0:     	ubfx	x13, x6, #8, #4
1000c45d4:     	mov	x8, x14
1000c45d8:     	ubfx	x14, x6, #12, #4
1000c45dc:     	and	x15, x6, #0xf
1000c45e0:     	ubfx	x16, x6, #16, #4
1000c45e4:     	ubfx	x17, x6, #20, #4
1000c45e8:     	ubfx	x5, x6, #24, #4
1000c45ec:     	lsr	x6, x6, #28
1000c45f0:     	ldr	w7, [x10, x11]
1000c45f4:     	lsl	w19, w7, #4
1000c45f8:     	and	x19, x19, #0xf0
1000c45fc:     	orr	x19, x19, x15
1000c4600:     	ldrsb	w19, [x9, x19]
1000c4604:     	and	x20, x7, #0xf0
1000c4608:     	orr	x20, x20, x12
1000c460c:     	ldrsb	w20, [x9, x20]
1000c4610:     	lsr	x21, x7, #4
1000c4614:     	and	x21, x21, #0xf0
1000c4618:     	orr	x21, x21, x13
1000c461c:     	ldrsb	w21, [x9, x21]
1000c4620:     	lsr	x22, x7, #8
1000c4624:     	and	x22, x22, #0xf0
1000c4628:     	orr	x22, x22, x14
1000c462c:     	ldrsb	w22, [x9, x22]
1000c4630:     	add	w19, w19, w20
1000c4634:     	add	w19, w19, w21
1000c4638:     	lsr	x20, x7, #12
1000c463c:     	and	x20, x20, #0xf0
1000c4640:     	orr	x20, x20, x16
1000c4644:     	ldrsb	w20, [x9, x20]
1000c4648:     	lsr	x21, x7, #16
1000c464c:     	and	x21, x21, #0xf0
1000c4650:     	orr	x21, x21, x17
1000c4654:     	ldrsb	w21, [x9, x21]
1000c4658:     	add	w19, w19, w22
1000c465c:     	add	w19, w19, w20
1000c4660:     	lsr	x20, x7, #20
1000c4664:     	and	x20, x20, #0xf0
1000c4668:     	orr	x20, x20, x5
1000c466c:     	ldrsb	w20, [x9, x20]
1000c4670:     	lsr	x7, x7, #24
1000c4674:     	and	x7, x7, #0xf0
1000c4678:     	orr	x7, x7, x6
1000c467c:     	ldrsb	w7, [x9, x7]
1000c4680:     	add	w19, w19, w21
1000c4684:     	add	w19, w19, w20
1000c4688:     	add	w7, w19, w7
1000c468c:     	scvtf	s0, w7
1000c4690:     	ldr	s1, [x3, x11]
1000c4694:     	fadd	s0, s1, s0
1000c4698:     	str	s0, [x3, x11]
1000c469c:     	add	x11, x11, #4
1000c46a0:     	cmp	x11, #64
1000c46a4:     	b.ne	0x1000c45f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x6c>
1000c46a8:     	add	x14, x8, #8
1000c46ac:     	add	x10, x10, #64
1000c46b0:     	cmp	x14, x2
1000c46b4:     	b.ls	0x1000c45bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c46b8:     	cmp	x8, x2
1000c46bc:     	b.hs	0x1000c4974 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000c46c0:     	lsl	x9, x4, #2
1000c46c4:     	lsl	w10, w8, #2
1000c46c8:     	mov	w11, #-16
1000c46cc:     	lsr	x13, x8, #3
1000c46d0:     	mul	x12, x9, x13
1000c46d4:     	ubfx	x14, x8, #1, #2
1000c46d8:     	orr	x12, x12, x14
1000c46dc:     	ldrb	w15, [x1, x12]
1000c46e0:     	and	w12, w10, #0x4
1000c46e4:     	lsr	w15, w15, w12
1000c46e8:     	and	w16, w15, #0xf
1000c46ec:     	cmp	w16, #8
1000c46f0:     	csel	w16, wzr, w11, lo
1000c46f4:     	bfi	x14, x13, #6, #58
1000c46f8:     	add	x13, x0, x14
1000c46fc:     	ldrb	w14, [x13]
1000c4700:     	lsr	w14, w14, w12
1000c4704:     	bfxil	w16, w15, #0, #4
1000c4708:     	and	w15, w14, #0xf
1000c470c:     	cmp	w15, #8
1000c4710:     	csel	w15, wzr, w11, lo
1000c4714:     	bfxil	w15, w14, #0, #4
1000c4718:     	scvtf	s0, w16
1000c471c:     	scvtf	s1, w15
1000c4720:     	ldp	s2, s3, [x3]
1000c4724:     	fmsub	s1, s1, s0, s2
1000c4728:     	str	s1, [x3]
1000c472c:     	ldrb	w14, [x13, #4]
1000c4730:     	lsr	w14, w14, w12
1000c4734:     	and	w15, w14, #0xf
1000c4738:     	cmp	w15, #8
1000c473c:     	csel	w15, wzr, w11, lo
1000c4740:     	bfxil	w15, w14, #0, #4
1000c4744:     	scvtf	s1, w15
1000c4748:     	fmsub	s1, s1, s0, s3
1000c474c:     	str	s1, [x3, #4]
1000c4750:     	ldrb	w14, [x13, #8]
1000c4754:     	lsr	w14, w14, w12
1000c4758:     	and	w15, w14, #0xf
1000c475c:     	cmp	w15, #8
1000c4760:     	csel	w15, wzr, w11, lo
1000c4764:     	bfxil	w15, w14, #0, #4
1000c4768:     	scvtf	s1, w15
1000c476c:     	ldp	s2, s3, [x3, #8]
1000c4770:     	fmsub	s1, s1, s0, s2
1000c4774:     	str	s1, [x3, #8]
1000c4778:     	ldrb	w14, [x13, #12]
1000c477c:     	lsr	w14, w14, w12
1000c4780:     	and	w15, w14, #0xf
1000c4784:     	cmp	w15, #8
1000c4788:     	csel	w15, wzr, w11, lo
1000c478c:     	bfxil	w15, w14, #0, #4
1000c4790:     	scvtf	s1, w15
1000c4794:     	fmsub	s1, s1, s0, s3
1000c4798:     	str	s1, [x3, #12]
1000c479c:     	ldrb	w14, [x13, #16]
1000c47a0:     	lsr	w14, w14, w12
1000c47a4:     	and	w15, w14, #0xf
1000c47a8:     	cmp	w15, #8
1000c47ac:     	csel	w15, wzr, w11, lo
1000c47b0:     	bfxil	w15, w14, #0, #4
1000c47b4:     	scvtf	s1, w15
1000c47b8:     	ldp	s2, s3, [x3, #16]
1000c47bc:     	fmsub	s1, s1, s0, s2
1000c47c0:     	str	s1, [x3, #16]
1000c47c4:     	ldrb	w14, [x13, #20]
1000c47c8:     	lsr	w14, w14, w12
1000c47cc:     	and	w15, w14, #0xf
1000c47d0:     	cmp	w15, #8
1000c47d4:     	csel	w15, wzr, w11, lo
1000c47d8:     	bfxil	w15, w14, #0, #4
1000c47dc:     	scvtf	s1, w15
1000c47e0:     	fmsub	s1, s1, s0, s3
1000c47e4:     	str	s1, [x3, #20]
1000c47e8:     	ldrb	w14, [x13, #24]
1000c47ec:     	lsr	w14, w14, w12
1000c47f0:     	and	w15, w14, #0xf
1000c47f4:     	cmp	w15, #8
1000c47f8:     	csel	w15, wzr, w11, lo
1000c47fc:     	bfxil	w15, w14, #0, #4
1000c4800:     	scvtf	s1, w15
1000c4804:     	ldp	s2, s3, [x3, #24]
1000c4808:     	fmsub	s1, s1, s0, s2
1000c480c:     	str	s1, [x3, #24]
1000c4810:     	ldrb	w14, [x13, #28]
1000c4814:     	lsr	w14, w14, w12
1000c4818:     	and	w15, w14, #0xf
1000c481c:     	cmp	w15, #8
1000c4820:     	csel	w15, wzr, w11, lo
1000c4824:     	bfxil	w15, w14, #0, #4
1000c4828:     	scvtf	s1, w15
1000c482c:     	fmsub	s1, s1, s0, s3
1000c4830:     	str	s1, [x3, #28]
1000c4834:     	ldrb	w14, [x13, #32]
1000c4838:     	lsr	w14, w14, w12
1000c483c:     	and	w15, w14, #0xf
1000c4840:     	cmp	w15, #8
1000c4844:     	csel	w15, wzr, w11, lo
1000c4848:     	bfxil	w15, w14, #0, #4
1000c484c:     	scvtf	s1, w15
1000c4850:     	ldp	s2, s3, [x3, #32]
1000c4854:     	fmsub	s1, s1, s0, s2
1000c4858:     	str	s1, [x3, #32]
1000c485c:     	ldrb	w14, [x13, #36]
1000c4860:     	lsr	w14, w14, w12
1000c4864:     	and	w15, w14, #0xf
1000c4868:     	cmp	w15, #8
1000c486c:     	csel	w15, wzr, w11, lo
1000c4870:     	bfxil	w15, w14, #0, #4
1000c4874:     	scvtf	s1, w15
1000c4878:     	fmsub	s1, s1, s0, s3
1000c487c:     	str	s1, [x3, #36]
1000c4880:     	ldrb	w14, [x13, #40]
1000c4884:     	lsr	w14, w14, w12
1000c4888:     	and	w15, w14, #0xf
1000c488c:     	cmp	w15, #8
1000c4890:     	csel	w15, wzr, w11, lo
1000c4894:     	bfxil	w15, w14, #0, #4
1000c4898:     	scvtf	s1, w15
1000c489c:     	ldp	s2, s3, [x3, #40]
1000c48a0:     	fmsub	s1, s1, s0, s2
1000c48a4:     	str	s1, [x3, #40]
1000c48a8:     	ldrb	w14, [x13, #44]
1000c48ac:     	lsr	w14, w14, w12
1000c48b0:     	and	w15, w14, #0xf
1000c48b4:     	cmp	w15, #8
1000c48b8:     	csel	w15, wzr, w11, lo
1000c48bc:     	bfxil	w15, w14, #0, #4
1000c48c0:     	scvtf	s1, w15
1000c48c4:     	fmsub	s1, s1, s0, s3
1000c48c8:     	str	s1, [x3, #44]
1000c48cc:     	ldrb	w14, [x13, #48]
1000c48d0:     	lsr	w14, w14, w12
1000c48d4:     	and	w15, w14, #0xf
1000c48d8:     	cmp	w15, #8
1000c48dc:     	csel	w15, wzr, w11, lo
1000c48e0:     	bfxil	w15, w14, #0, #4
1000c48e4:     	scvtf	s1, w15
1000c48e8:     	ldp	s2, s3, [x3, #48]
1000c48ec:     	fmsub	s1, s1, s0, s2
1000c48f0:     	str	s1, [x3, #48]
1000c48f4:     	ldrb	w14, [x13, #52]
1000c48f8:     	lsr	w14, w14, w12
1000c48fc:     	and	w15, w14, #0xf
1000c4900:     	cmp	w15, #8
1000c4904:     	csel	w15, wzr, w11, lo
1000c4908:     	bfxil	w15, w14, #0, #4
1000c490c:     	scvtf	s1, w15
1000c4910:     	fmsub	s1, s1, s0, s3
1000c4914:     	str	s1, [x3, #52]
1000c4918:     	ldrb	w14, [x13, #56]
1000c491c:     	lsr	w14, w14, w12
1000c4920:     	and	w15, w14, #0xf
1000c4924:     	cmp	w15, #8
1000c4928:     	csel	w15, wzr, w11, lo
1000c492c:     	bfxil	w15, w14, #0, #4
1000c4930:     	scvtf	s1, w15
1000c4934:     	ldp	s2, s3, [x3, #56]
1000c4938:     	fmsub	s1, s1, s0, s2
1000c493c:     	str	s1, [x3, #56]
1000c4940:     	ldrb	w13, [x13, #60]
1000c4944:     	lsr	w12, w13, w12
1000c4948:     	and	w13, w12, #0xf
1000c494c:     	cmp	w13, #8
1000c4950:     	csel	w13, wzr, w11, lo
1000c4954:     	bfxil	w13, w12, #0, #4
1000c4958:     	scvtf	s1, w13
1000c495c:     	fmsub	s0, s1, s0, s3
1000c4960:     	str	s0, [x3, #60]
1000c4964:     	add	x8, x8, #1
1000c4968:     	add	w10, w10, #4
1000c496c:     	cmp	x2, x8
1000c4970:     	b.ne	0x1000c46cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c4974:     	ldp	x20, x19, [sp, #16]
1000c4978:     	ldp	x22, x21, [sp], #32
1000c497c:     	ret

00000001000c5d60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c5d60:     	sub	sp, sp, #272
1000c5d64:     	stp	x28, x27, [sp, #176]
1000c5d68:     	stp	x26, x25, [sp, #192]
1000c5d6c:     	stp	x24, x23, [sp, #208]
1000c5d70:     	stp	x22, x21, [sp, #224]
1000c5d74:     	stp	x20, x19, [sp, #240]
1000c5d78:     	stp	x29, x30, [sp, #256]
1000c5d7c:     	add	x29, sp, #256
1000c5d80:     	str	x3, [sp]
1000c5d84:     	adrp	x8, 0x100168000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c5d88:     	ldr	x8, [x8, #392]
1000c5d8c:     	ldr	x8, [x8]
1000c5d90:     	stur	x8, [x29, #-96]
1000c5d94:     	movi.2d	v0, #0000000000000000
1000c5d98:     	stp	q0, q0, [sp, #128]
1000c5d9c:     	stp	q0, q0, [sp, #96]
1000c5da0:     	stp	q0, q0, [sp, #64]
1000c5da4:     	stp	q0, q0, [sp, #32]
1000c5da8:     	ands	x8, x2, #0xfffffffffffffffe
1000c5dac:     	b.eq	0x1000c5f50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1f0>
1000c5db0:     	add	x8, x1, x8
1000c5db4:     	str	x8, [sp, #8]
1000c5db8:     	adrp	x9, 0x100166000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x8c>
1000c5dbc:     	add	x9, x9, #1244
1000c5dc0:     	mov	x11, #0
1000c5dc4:     	ldp	w4, w23, [x1]
1000c5dc8:     	ubfx	x8, x4, #4, #4
1000c5dcc:     	stp	x1, x8, [sp, #16]
1000c5dd0:     	ubfx	x13, x4, #8, #4
1000c5dd4:     	and	x14, x4, #0xf
1000c5dd8:     	ubfx	x15, x4, #12, #4
1000c5ddc:     	ubfx	x16, x4, #16, #4
1000c5de0:     	ubfx	x17, x4, #20, #4
1000c5de4:     	ubfx	x2, x4, #24, #4
1000c5de8:     	lsr	x4, x4, #28
1000c5dec:     	and	x5, x23, #0xf
1000c5df0:     	ubfx	x6, x23, #4, #4
1000c5df4:     	ubfx	x7, x23, #8, #4
1000c5df8:     	ubfx	x19, x23, #12, #4
1000c5dfc:     	ubfx	x20, x23, #16, #4
1000c5e00:     	ubfx	x21, x23, #20, #4
1000c5e04:     	ubfx	x22, x23, #24, #4
1000c5e08:     	lsr	x23, x23, #28
1000c5e0c:     	ldr	w24, [x0, x11]
1000c5e10:     	lsl	w25, w24, #4
1000c5e14:     	and	x25, x25, #0xf0
1000c5e18:     	orr	x26, x25, x14
1000c5e1c:     	ldrb	w26, [x9, x26]
1000c5e20:     	and	x27, x24, #0xf0
1000c5e24:     	ldr	x8, [sp, #24]
1000c5e28:     	orr	x28, x27, x8
1000c5e2c:     	ldrb	w28, [x9, x28]
1000c5e30:     	lsr	x30, x24, #4
1000c5e34:     	and	x30, x30, #0xf0
1000c5e38:     	orr	x8, x30, x13
1000c5e3c:     	ldrb	w8, [x9, x8]
1000c5e40:     	add	w26, w26, w28
1000c5e44:     	add	w8, w26, w8
1000c5e48:     	lsr	x26, x24, #8
1000c5e4c:     	and	x26, x26, #0xf0
1000c5e50:     	orr	x28, x26, x15
1000c5e54:     	ldrb	w28, [x9, x28]
1000c5e58:     	lsr	x3, x24, #12
1000c5e5c:     	and	x3, x3, #0xf0
1000c5e60:     	orr	x10, x3, x16
1000c5e64:     	ldrb	w10, [x9, x10]
1000c5e68:     	add	w8, w8, w28
1000c5e6c:     	add	w8, w8, w10
1000c5e70:     	lsr	x10, x24, #16
1000c5e74:     	and	x10, x10, #0xf0
1000c5e78:     	orr	x28, x10, x17
1000c5e7c:     	ldrb	w28, [x9, x28]
1000c5e80:     	lsr	x1, x24, #20
1000c5e84:     	and	x1, x1, #0xf0
1000c5e88:     	orr	x12, x1, x2
1000c5e8c:     	ldrb	w12, [x9, x12]
1000c5e90:     	add	w8, w8, w28
1000c5e94:     	add	x28, sp, #32
1000c5e98:     	add	w8, w8, w12
1000c5e9c:     	lsr	x12, x24, #24
1000c5ea0:     	and	x12, x12, #0xf0
1000c5ea4:     	orr	x24, x12, x4
1000c5ea8:     	ldrb	w24, [x9, x24]
1000c5eac:     	add	w8, w8, w24
1000c5eb0:     	scvtf	s0, w8
1000c5eb4:     	add	x8, x28, x11
1000c5eb8:     	ldr	s1, [x8]
1000c5ebc:     	fadd	s0, s1, s0
1000c5ec0:     	orr	x24, x25, x5
1000c5ec4:     	ldrb	w24, [x9, x24]
1000c5ec8:     	orr	x25, x27, x6
1000c5ecc:     	ldrb	w25, [x9, x25]
1000c5ed0:     	orr	x27, x30, x7
1000c5ed4:     	ldrb	w27, [x9, x27]
1000c5ed8:     	add	w24, w24, w25
1000c5edc:     	add	w24, w24, w27
1000c5ee0:     	orr	x25, x26, x19
1000c5ee4:     	ldrb	w25, [x9, x25]
1000c5ee8:     	orr	x3, x3, x20
1000c5eec:     	ldrb	w3, [x9, x3]
1000c5ef0:     	orr	x10, x10, x21
1000c5ef4:     	ldrb	w10, [x9, x10]
1000c5ef8:     	add	w24, w24, w25
1000c5efc:     	add	w3, w24, w3
1000c5f00:     	orr	x1, x1, x22
1000c5f04:     	ldrb	w1, [x9, x1]
1000c5f08:     	add	w10, w3, w10
1000c5f0c:     	add	w10, w10, w1
1000c5f10:     	orr	x12, x12, x23
1000c5f14:     	ldrb	w12, [x9, x12]
1000c5f18:     	add	w10, w10, w12
1000c5f1c:     	scvtf	s1, w10
1000c5f20:     	str	s0, [x8]
1000c5f24:     	ldr	s0, [x8, #64]
1000c5f28:     	fadd	s0, s0, s1
1000c5f2c:     	str	s0, [x8, #64]
1000c5f30:     	add	x11, x11, #4
1000c5f34:     	cmp	x11, #64
1000c5f38:     	b.ne	0x1000c5e0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c5f3c:     	add	x0, x0, #64
1000c5f40:     	ldp	x8, x1, [sp, #8]
1000c5f44:     	add	x1, x1, #8
1000c5f48:     	cmp	x1, x8
1000c5f4c:     	b.ne	0x1000c5dc0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c5f50:     	ldp	q0, q1, [sp, #96]
1000c5f54:     	ldr	x8, [sp]
1000c5f58:     	stp	q0, q1, [x8, #64]
1000c5f5c:     	ldp	q0, q1, [sp, #128]
1000c5f60:     	stp	q0, q1, [x8, #96]
1000c5f64:     	ldp	q0, q1, [sp, #32]
1000c5f68:     	stp	q0, q1, [x8]
1000c5f6c:     	ldp	q0, q1, [sp, #64]
1000c5f70:     	stp	q0, q1, [x8, #32]
1000c5f74:     	ldur	x8, [x29, #-96]
1000c5f78:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x198>
1000c5f7c:     	ldr	x9, [x9, #392]
1000c5f80:     	ldr	x9, [x9]
1000c5f84:     	cmp	x9, x8
1000c5f88:     	b.ne	0x1000c5fac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24c>
1000c5f8c:     	ldp	x29, x30, [sp, #256]
1000c5f90:     	ldp	x20, x19, [sp, #240]
1000c5f94:     	ldp	x22, x21, [sp, #224]
1000c5f98:     	ldp	x24, x23, [sp, #208]
1000c5f9c:     	ldp	x26, x25, [sp, #192]
1000c5fa0:     	ldp	x28, x27, [sp, #176]
1000c5fa4:     	add	sp, sp, #272
1000c5fa8:     	ret
1000c5fac:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c606c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c606c:     	sub	sp, sp, #272
1000c6070:     	stp	x28, x27, [sp, #176]
1000c6074:     	stp	x26, x25, [sp, #192]
1000c6078:     	stp	x24, x23, [sp, #208]
1000c607c:     	stp	x22, x21, [sp, #224]
1000c6080:     	stp	x20, x19, [sp, #240]
1000c6084:     	stp	x29, x30, [sp, #256]
1000c6088:     	add	x29, sp, #256
1000c608c:     	str	x3, [sp]
1000c6090:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x5c>
1000c6094:     	ldr	x8, [x8, #392]
1000c6098:     	ldr	x8, [x8]
1000c609c:     	stur	x8, [x29, #-96]
1000c60a0:     	movi.2d	v0, #0000000000000000
1000c60a4:     	stp	q0, q0, [sp, #128]
1000c60a8:     	stp	q0, q0, [sp, #96]
1000c60ac:     	stp	q0, q0, [sp, #64]
1000c60b0:     	stp	q0, q0, [sp, #32]
1000c60b4:     	ands	x8, x2, #0xfffffffffffffffe
1000c60b8:     	b.eq	0x1000c625c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1f0>
1000c60bc:     	add	x8, x1, x8
1000c60c0:     	str	x8, [sp, #8]
1000c60c4:     	adrp	x9, 0x100166000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x88>
1000c60c8:     	add	x9, x9, #1500
1000c60cc:     	mov	x11, #0
1000c60d0:     	ldp	w4, w23, [x1]
1000c60d4:     	ubfx	x8, x4, #4, #4
1000c60d8:     	stp	x1, x8, [sp, #16]
1000c60dc:     	ubfx	x13, x4, #8, #4
1000c60e0:     	and	x14, x4, #0xf
1000c60e4:     	ubfx	x15, x4, #12, #4
1000c60e8:     	ubfx	x16, x4, #16, #4
1000c60ec:     	ubfx	x17, x4, #20, #4
1000c60f0:     	ubfx	x2, x4, #24, #4
1000c60f4:     	lsr	x4, x4, #28
1000c60f8:     	and	x5, x23, #0xf
1000c60fc:     	ubfx	x6, x23, #4, #4
1000c6100:     	ubfx	x7, x23, #8, #4
1000c6104:     	ubfx	x19, x23, #12, #4
1000c6108:     	ubfx	x20, x23, #16, #4
1000c610c:     	ubfx	x21, x23, #20, #4
1000c6110:     	ubfx	x22, x23, #24, #4
1000c6114:     	lsr	x23, x23, #28
1000c6118:     	ldr	w24, [x0, x11]
1000c611c:     	lsl	w25, w24, #4
1000c6120:     	and	x25, x25, #0xf0
1000c6124:     	orr	x26, x25, x14
1000c6128:     	ldrsb	w26, [x9, x26]
1000c612c:     	and	x27, x24, #0xf0
1000c6130:     	ldr	x8, [sp, #24]
1000c6134:     	orr	x28, x27, x8
1000c6138:     	ldrsb	w28, [x9, x28]
1000c613c:     	lsr	x30, x24, #4
1000c6140:     	and	x30, x30, #0xf0
1000c6144:     	orr	x8, x30, x13
1000c6148:     	ldrsb	w8, [x9, x8]
1000c614c:     	add	w26, w26, w28
1000c6150:     	add	w8, w26, w8
1000c6154:     	lsr	x26, x24, #8
1000c6158:     	and	x26, x26, #0xf0
1000c615c:     	orr	x28, x26, x15
1000c6160:     	ldrsb	w28, [x9, x28]
1000c6164:     	lsr	x3, x24, #12
1000c6168:     	and	x3, x3, #0xf0
1000c616c:     	orr	x10, x3, x16
1000c6170:     	ldrsb	w10, [x9, x10]
1000c6174:     	add	w8, w8, w28
1000c6178:     	add	w8, w8, w10
1000c617c:     	lsr	x10, x24, #16
1000c6180:     	and	x10, x10, #0xf0
1000c6184:     	orr	x28, x10, x17
1000c6188:     	ldrsb	w28, [x9, x28]
1000c618c:     	lsr	x1, x24, #20
1000c6190:     	and	x1, x1, #0xf0
1000c6194:     	orr	x12, x1, x2
1000c6198:     	ldrsb	w12, [x9, x12]
1000c619c:     	add	w8, w8, w28
1000c61a0:     	add	x28, sp, #32
1000c61a4:     	add	w8, w8, w12
1000c61a8:     	lsr	x12, x24, #24
1000c61ac:     	and	x12, x12, #0xf0
1000c61b0:     	orr	x24, x12, x4
1000c61b4:     	ldrsb	w24, [x9, x24]
1000c61b8:     	add	w8, w8, w24
1000c61bc:     	scvtf	s0, w8
1000c61c0:     	add	x8, x28, x11
1000c61c4:     	ldr	s1, [x8]
1000c61c8:     	fadd	s0, s1, s0
1000c61cc:     	orr	x24, x25, x5
1000c61d0:     	ldrsb	w24, [x9, x24]
1000c61d4:     	orr	x25, x27, x6
1000c61d8:     	ldrsb	w25, [x9, x25]
1000c61dc:     	orr	x27, x30, x7
1000c61e0:     	ldrsb	w27, [x9, x27]
1000c61e4:     	add	w24, w24, w25
1000c61e8:     	add	w24, w24, w27
1000c61ec:     	orr	x25, x26, x19
1000c61f0:     	ldrsb	w25, [x9, x25]
1000c61f4:     	orr	x3, x3, x20
1000c61f8:     	ldrsb	w3, [x9, x3]
1000c61fc:     	orr	x10, x10, x21
1000c6200:     	ldrsb	w10, [x9, x10]
1000c6204:     	add	w24, w24, w25
1000c6208:     	add	w3, w24, w3
1000c620c:     	orr	x1, x1, x22
1000c6210:     	ldrsb	w1, [x9, x1]
1000c6214:     	add	w10, w3, w10
1000c6218:     	add	w10, w10, w1
1000c621c:     	orr	x12, x12, x23
1000c6220:     	ldrsb	w12, [x9, x12]
1000c6224:     	add	w10, w10, w12
1000c6228:     	scvtf	s1, w10
1000c622c:     	str	s0, [x8]
1000c6230:     	ldr	s0, [x8, #64]
1000c6234:     	fadd	s0, s0, s1
1000c6238:     	str	s0, [x8, #64]
1000c623c:     	add	x11, x11, #4
1000c6240:     	cmp	x11, #64
1000c6244:     	b.ne	0x1000c6118 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c6248:     	add	x0, x0, #64
1000c624c:     	ldp	x8, x1, [sp, #8]
1000c6250:     	add	x1, x1, #8
1000c6254:     	cmp	x1, x8
1000c6258:     	b.ne	0x1000c60cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c625c:     	ldp	q0, q1, [sp, #96]
1000c6260:     	ldr	x8, [sp]
1000c6264:     	stp	q0, q1, [x8, #64]
1000c6268:     	ldp	q0, q1, [sp, #128]
1000c626c:     	stp	q0, q1, [x8, #96]
1000c6270:     	ldp	q0, q1, [sp, #32]
1000c6274:     	stp	q0, q1, [x8]
1000c6278:     	ldp	q0, q1, [sp, #64]
1000c627c:     	stp	q0, q1, [x8, #32]
1000c6280:     	ldur	x8, [x29, #-96]
1000c6284:     	adrp	x9, 0x100168000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x250>
1000c6288:     	ldr	x9, [x9, #392]
1000c628c:     	ldr	x9, [x9]
1000c6290:     	cmp	x9, x8
1000c6294:     	b.ne	0x1000c62b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x24c>
1000c6298:     	ldp	x29, x30, [sp, #256]
1000c629c:     	ldp	x20, x19, [sp, #240]
1000c62a0:     	ldp	x22, x21, [sp, #224]
1000c62a4:     	ldp	x24, x23, [sp, #208]
1000c62a8:     	ldp	x26, x25, [sp, #192]
1000c62ac:     	ldp	x28, x27, [sp, #176]
1000c62b0:     	add	sp, sp, #272
1000c62b4:     	ret
1000c62b8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c7708 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c7708:     	stp	x28, x27, [sp, #-96]!
1000c770c:     	stp	x26, x25, [sp, #16]
1000c7710:     	stp	x24, x23, [sp, #32]
1000c7714:     	stp	x22, x21, [sp, #48]
1000c7718:     	stp	x20, x19, [sp, #64]
1000c771c:     	stp	x29, x30, [sp, #80]
1000c7720:     	add	x29, sp, #80
1000c7724:     	sub	sp, sp, #448
1000c7728:     	str	x3, [sp]
1000c772c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a8>
1000c7730:     	ldr	x8, [x8, #392]
1000c7734:     	ldr	x8, [x8]
1000c7738:     	stur	x8, [x29, #-96]
1000c773c:     	movi.2d	v0, #0000000000000000
1000c7740:     	stp	q0, q0, [sp, #400]
1000c7744:     	lsl	x8, x2, #1
1000c7748:     	stp	q0, q0, [sp, #368]
1000c774c:     	stp	q0, q0, [sp, #336]
1000c7750:     	stp	q0, q0, [sp, #304]
1000c7754:     	stp	q0, q0, [sp, #272]
1000c7758:     	stp	q0, q0, [sp, #240]
1000c775c:     	stp	q0, q0, [sp, #208]
1000c7760:     	stp	q0, q0, [sp, #176]
1000c7764:     	ands	x8, x8, #0xfffffffffffffffc
1000c7768:     	b.eq	0x1000c7a90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c776c:     	add	x8, x1, x8
1000c7770:     	str	x8, [sp, #8]
1000c7774:     	add	x8, sp, #176
1000c7778:     	add	x27, x8, #128
1000c777c:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000c7780:     	add	x11, x11, #1244
1000c7784:     	mov	x12, #0
1000c7788:     	ldp	w8, w9, [x1]
1000c778c:     	ubfx	x10, x8, #4, #4
1000c7790:     	str	x10, [sp, #168]
1000c7794:     	ubfx	x10, x8, #8, #4
1000c7798:     	str	x10, [sp, #160]
1000c779c:     	and	x10, x8, #0xf
1000c77a0:     	str	x10, [sp, #152]
1000c77a4:     	ubfx	x10, x8, #12, #4
1000c77a8:     	str	x10, [sp, #144]
1000c77ac:     	ubfx	x10, x8, #16, #4
1000c77b0:     	str	x10, [sp, #136]
1000c77b4:     	ubfx	x10, x8, #20, #4
1000c77b8:     	str	x10, [sp, #128]
1000c77bc:     	ubfx	x10, x8, #24, #4
1000c77c0:     	lsr	x8, x8, #28
1000c77c4:     	stp	x8, x10, [sp, #112]
1000c77c8:     	and	x10, x9, #0xf
1000c77cc:     	ubfx	x8, x9, #4, #4
1000c77d0:     	stp	x8, x10, [sp, #96]
1000c77d4:     	ubfx	x10, x9, #8, #4
1000c77d8:     	ubfx	x8, x9, #12, #4
1000c77dc:     	stp	x8, x10, [sp, #80]
1000c77e0:     	ubfx	x10, x9, #16, #4
1000c77e4:     	ubfx	x8, x9, #20, #4
1000c77e8:     	stp	x8, x10, [sp, #64]
1000c77ec:     	ubfx	x10, x9, #24, #4
1000c77f0:     	lsr	x8, x9, #28
1000c77f4:     	stp	x8, x10, [sp, #48]
1000c77f8:     	ldp	w9, w17, [x1, #8]
1000c77fc:     	and	x10, x9, #0xf
1000c7800:     	ubfx	x8, x9, #4, #4
1000c7804:     	stp	x8, x10, [sp, #32]
1000c7808:     	ubfx	x8, x9, #8, #4
1000c780c:     	stp	x1, x8, [sp, #16]
1000c7810:     	ubfx	x28, x9, #12, #4
1000c7814:     	ubfx	x30, x9, #16, #4
1000c7818:     	ubfx	x8, x9, #20, #4
1000c781c:     	ubfx	x3, x9, #24, #4
1000c7820:     	lsr	x9, x9, #28
1000c7824:     	and	x1, x17, #0xf
1000c7828:     	ubfx	x10, x17, #4, #4
1000c782c:     	ubfx	x13, x17, #8, #4
1000c7830:     	ubfx	x26, x17, #12, #4
1000c7834:     	ubfx	x14, x17, #16, #4
1000c7838:     	ubfx	x15, x17, #20, #4
1000c783c:     	ubfx	x16, x17, #24, #4
1000c7840:     	lsr	x17, x17, #28
1000c7844:     	ldr	w21, [x0, x12]
1000c7848:     	lsl	w2, w21, #4
1000c784c:     	and	x2, x2, #0xf0
1000c7850:     	ldp	x4, x19, [sp, #152]
1000c7854:     	orr	x4, x2, x4
1000c7858:     	ldrb	w6, [x11, x4]
1000c785c:     	and	x4, x21, #0xf0
1000c7860:     	ldr	x5, [sp, #168]
1000c7864:     	orr	x5, x4, x5
1000c7868:     	ldrb	w7, [x11, x5]
1000c786c:     	lsr	x5, x21, #4
1000c7870:     	and	x5, x5, #0xf0
1000c7874:     	orr	x19, x5, x19
1000c7878:     	ldrb	w19, [x11, x19]
1000c787c:     	add	w6, w6, w7
1000c7880:     	add	w19, w6, w19
1000c7884:     	lsr	x6, x21, #8
1000c7888:     	and	x6, x6, #0xf0
1000c788c:     	ldp	x22, x7, [sp, #136]
1000c7890:     	orr	x7, x6, x7
1000c7894:     	ldrb	w20, [x11, x7]
1000c7898:     	lsr	x7, x21, #12
1000c789c:     	and	x7, x7, #0xf0
1000c78a0:     	orr	x22, x7, x22
1000c78a4:     	ldrb	w22, [x11, x22]
1000c78a8:     	add	w19, w19, w20
1000c78ac:     	add	w22, w19, w22
1000c78b0:     	lsr	x19, x21, #16
1000c78b4:     	and	x19, x19, #0xf0
1000c78b8:     	ldp	x24, x20, [sp, #120]
1000c78bc:     	orr	x20, x19, x20
1000c78c0:     	ldrb	w23, [x11, x20]
1000c78c4:     	lsr	x20, x21, #20
1000c78c8:     	and	x20, x20, #0xf0
1000c78cc:     	orr	x24, x20, x24
1000c78d0:     	ldrb	w24, [x11, x24]
1000c78d4:     	add	w22, w22, w23
1000c78d8:     	add	w22, w22, w24
1000c78dc:     	lsr	x21, x21, #24
1000c78e0:     	and	x21, x21, #0xf0
1000c78e4:     	ldr	x23, [sp, #112]
1000c78e8:     	orr	x23, x21, x23
1000c78ec:     	ldrb	w23, [x11, x23]
1000c78f0:     	add	w22, w22, w23
1000c78f4:     	scvtf	s0, w22
1000c78f8:     	ldp	x23, x22, [sp, #96]
1000c78fc:     	orr	x22, x2, x22
1000c7900:     	ldrb	w22, [x11, x22]
1000c7904:     	orr	x23, x4, x23
1000c7908:     	ldrb	w23, [x11, x23]
1000c790c:     	ldr	x24, [sp, #88]
1000c7910:     	orr	x24, x5, x24
1000c7914:     	ldrb	w24, [x11, x24]
1000c7918:     	add	w22, w22, w23
1000c791c:     	add	w22, w22, w24
1000c7920:     	ldp	x24, x23, [sp, #72]
1000c7924:     	orr	x23, x6, x23
1000c7928:     	ldrb	w23, [x11, x23]
1000c792c:     	orr	x24, x7, x24
1000c7930:     	ldrb	w24, [x11, x24]
1000c7934:     	ldr	x25, [sp, #64]
1000c7938:     	orr	x25, x19, x25
1000c793c:     	ldrb	w25, [x11, x25]
1000c7940:     	add	w22, w22, w23
1000c7944:     	add	w22, w22, w24
1000c7948:     	ldr	x23, [sp, #56]
1000c794c:     	orr	x23, x20, x23
1000c7950:     	ldrb	w23, [x11, x23]
1000c7954:     	add	w22, w22, w25
1000c7958:     	add	w22, w22, w23
1000c795c:     	ldr	x23, [sp, #48]
1000c7960:     	orr	x23, x21, x23
1000c7964:     	ldrb	w23, [x11, x23]
1000c7968:     	add	w22, w22, w23
1000c796c:     	scvtf	s1, w22
1000c7970:     	ldp	x23, x22, [sp, #32]
1000c7974:     	orr	x22, x2, x22
1000c7978:     	ldrb	w22, [x11, x22]
1000c797c:     	orr	x23, x4, x23
1000c7980:     	ldrb	w23, [x11, x23]
1000c7984:     	ldr	x24, [sp, #24]
1000c7988:     	orr	x24, x5, x24
1000c798c:     	ldrb	w24, [x11, x24]
1000c7990:     	add	w22, w22, w23
1000c7994:     	add	w22, w22, w24
1000c7998:     	orr	x23, x6, x28
1000c799c:     	ldrb	w23, [x11, x23]
1000c79a0:     	orr	x24, x7, x30
1000c79a4:     	ldrb	w24, [x11, x24]
1000c79a8:     	orr	x25, x19, x8
1000c79ac:     	ldrb	w25, [x11, x25]
1000c79b0:     	add	w22, w22, w23
1000c79b4:     	orr	x23, x20, x3
1000c79b8:     	ldrb	w23, [x11, x23]
1000c79bc:     	add	w22, w22, w24
1000c79c0:     	add	w22, w22, w25
1000c79c4:     	add	w22, w22, w23
1000c79c8:     	orr	x23, x21, x9
1000c79cc:     	ldrb	w23, [x11, x23]
1000c79d0:     	add	w22, w22, w23
1000c79d4:     	scvtf	s2, w22
1000c79d8:     	orr	x2, x2, x1
1000c79dc:     	ldrb	w2, [x11, x2]
1000c79e0:     	orr	x4, x4, x10
1000c79e4:     	ldrb	w4, [x11, x4]
1000c79e8:     	orr	x5, x5, x13
1000c79ec:     	ldrb	w5, [x11, x5]
1000c79f0:     	add	w2, w2, w4
1000c79f4:     	add	w2, w2, w5
1000c79f8:     	orr	x4, x6, x26
1000c79fc:     	ldrb	w4, [x11, x4]
1000c7a00:     	orr	x5, x7, x14
1000c7a04:     	ldrb	w5, [x11, x5]
1000c7a08:     	add	w2, w2, w4
1000c7a0c:     	orr	x4, x19, x15
1000c7a10:     	ldrb	w4, [x11, x4]
1000c7a14:     	add	w2, w2, w5
1000c7a18:     	orr	x5, x20, x16
1000c7a1c:     	ldrb	w5, [x11, x5]
1000c7a20:     	add	w2, w2, w4
1000c7a24:     	add	w2, w2, w5
1000c7a28:     	orr	x4, x21, x17
1000c7a2c:     	ldrb	w4, [x11, x4]
1000c7a30:     	add	w2, w2, w4
1000c7a34:     	add	x4, sp, #176
1000c7a38:     	scvtf	s3, w2
1000c7a3c:     	add	x2, x27, x12
1000c7a40:     	ldur	s4, [x2, #-64]
1000c7a44:     	fadd	s1, s4, s1
1000c7a48:     	stur	s1, [x2, #-64]
1000c7a4c:     	ldr	s1, [x2]
1000c7a50:     	fadd	s1, s1, s2
1000c7a54:     	str	s1, [x2]
1000c7a58:     	ldr	s1, [x2, #64]
1000c7a5c:     	fadd	s1, s1, s3
1000c7a60:     	ldr	s2, [x4, x12]
1000c7a64:     	str	s1, [x2, #64]
1000c7a68:     	fadd	s0, s2, s0
1000c7a6c:     	str	s0, [x4, x12]
1000c7a70:     	add	x12, x12, #4
1000c7a74:     	cmp	x12, #64
1000c7a78:     	b.ne	0x1000c7844 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c7a7c:     	add	x0, x0, #64
1000c7a80:     	ldp	x8, x1, [sp, #8]
1000c7a84:     	add	x1, x1, #16
1000c7a88:     	cmp	x1, x8
1000c7a8c:     	b.ne	0x1000c7784 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c7a90:     	ldp	q0, q1, [sp, #368]
1000c7a94:     	ldr	x8, [sp]
1000c7a98:     	stp	q0, q1, [x8, #192]
1000c7a9c:     	ldp	q0, q1, [sp, #400]
1000c7aa0:     	stp	q0, q1, [x8, #224]
1000c7aa4:     	ldp	q0, q1, [sp, #304]
1000c7aa8:     	stp	q0, q1, [x8, #128]
1000c7aac:     	ldp	q0, q1, [sp, #336]
1000c7ab0:     	stp	q0, q1, [x8, #160]
1000c7ab4:     	ldp	q0, q1, [sp, #240]
1000c7ab8:     	stp	q0, q1, [x8, #64]
1000c7abc:     	ldp	q0, q1, [sp, #272]
1000c7ac0:     	stp	q0, q1, [x8, #96]
1000c7ac4:     	ldp	q0, q1, [sp, #176]
1000c7ac8:     	stp	q0, q1, [x8]
1000c7acc:     	ldp	q0, q1, [sp, #208]
1000c7ad0:     	stp	q0, q1, [x8, #32]
1000c7ad4:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x138>
1000c7ad8:     	ldr	x8, [x8, #392]
1000c7adc:     	ldr	x8, [x8]
1000c7ae0:     	ldur	x9, [x29, #-96]
1000c7ae4:     	cmp	x8, x9
1000c7ae8:     	b.ne	0x1000c7b0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x404>
1000c7aec:     	add	sp, sp, #448
1000c7af0:     	ldp	x29, x30, [sp, #80]
1000c7af4:     	ldp	x20, x19, [sp, #64]
1000c7af8:     	ldp	x22, x21, [sp, #48]
1000c7afc:     	ldp	x24, x23, [sp, #32]
1000c7b00:     	ldp	x26, x25, [sp, #16]
1000c7b04:     	ldp	x28, x27, [sp], #96
1000c7b08:     	ret
1000c7b0c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c7c20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c7c20:     	stp	x28, x27, [sp, #-96]!
1000c7c24:     	stp	x26, x25, [sp, #16]
1000c7c28:     	stp	x24, x23, [sp, #32]
1000c7c2c:     	stp	x22, x21, [sp, #48]
1000c7c30:     	stp	x20, x19, [sp, #64]
1000c7c34:     	stp	x29, x30, [sp, #80]
1000c7c38:     	add	x29, sp, #80
1000c7c3c:     	sub	sp, sp, #448
1000c7c40:     	str	x3, [sp]
1000c7c44:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a8>
1000c7c48:     	ldr	x8, [x8, #392]
1000c7c4c:     	ldr	x8, [x8]
1000c7c50:     	stur	x8, [x29, #-96]
1000c7c54:     	movi.2d	v0, #0000000000000000
1000c7c58:     	stp	q0, q0, [sp, #400]
1000c7c5c:     	lsl	x8, x2, #1
1000c7c60:     	stp	q0, q0, [sp, #368]
1000c7c64:     	stp	q0, q0, [sp, #336]
1000c7c68:     	stp	q0, q0, [sp, #304]
1000c7c6c:     	stp	q0, q0, [sp, #272]
1000c7c70:     	stp	q0, q0, [sp, #240]
1000c7c74:     	stp	q0, q0, [sp, #208]
1000c7c78:     	stp	q0, q0, [sp, #176]
1000c7c7c:     	ands	x8, x8, #0xfffffffffffffffc
1000c7c80:     	b.eq	0x1000c7fa8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c7c84:     	add	x8, x1, x8
1000c7c88:     	str	x8, [sp, #8]
1000c7c8c:     	add	x8, sp, #176
1000c7c90:     	add	x27, x8, #128
1000c7c94:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000c7c98:     	add	x11, x11, #1500
1000c7c9c:     	mov	x12, #0
1000c7ca0:     	ldp	w8, w9, [x1]
1000c7ca4:     	ubfx	x10, x8, #4, #4
1000c7ca8:     	str	x10, [sp, #168]
1000c7cac:     	ubfx	x10, x8, #8, #4
1000c7cb0:     	str	x10, [sp, #160]
1000c7cb4:     	and	x10, x8, #0xf
1000c7cb8:     	str	x10, [sp, #152]
1000c7cbc:     	ubfx	x10, x8, #12, #4
1000c7cc0:     	str	x10, [sp, #144]
1000c7cc4:     	ubfx	x10, x8, #16, #4
1000c7cc8:     	str	x10, [sp, #136]
1000c7ccc:     	ubfx	x10, x8, #20, #4
1000c7cd0:     	str	x10, [sp, #128]
1000c7cd4:     	ubfx	x10, x8, #24, #4
1000c7cd8:     	lsr	x8, x8, #28
1000c7cdc:     	stp	x8, x10, [sp, #112]
1000c7ce0:     	and	x10, x9, #0xf
1000c7ce4:     	ubfx	x8, x9, #4, #4
1000c7ce8:     	stp	x8, x10, [sp, #96]
1000c7cec:     	ubfx	x10, x9, #8, #4
1000c7cf0:     	ubfx	x8, x9, #12, #4
1000c7cf4:     	stp	x8, x10, [sp, #80]
1000c7cf8:     	ubfx	x10, x9, #16, #4
1000c7cfc:     	ubfx	x8, x9, #20, #4
1000c7d00:     	stp	x8, x10, [sp, #64]
1000c7d04:     	ubfx	x10, x9, #24, #4
1000c7d08:     	lsr	x8, x9, #28
1000c7d0c:     	stp	x8, x10, [sp, #48]
1000c7d10:     	ldp	w9, w17, [x1, #8]
1000c7d14:     	and	x10, x9, #0xf
1000c7d18:     	ubfx	x8, x9, #4, #4
1000c7d1c:     	stp	x8, x10, [sp, #32]
1000c7d20:     	ubfx	x8, x9, #8, #4
1000c7d24:     	stp	x1, x8, [sp, #16]
1000c7d28:     	ubfx	x28, x9, #12, #4
1000c7d2c:     	ubfx	x30, x9, #16, #4
1000c7d30:     	ubfx	x8, x9, #20, #4
1000c7d34:     	ubfx	x3, x9, #24, #4
1000c7d38:     	lsr	x9, x9, #28
1000c7d3c:     	and	x1, x17, #0xf
1000c7d40:     	ubfx	x10, x17, #4, #4
1000c7d44:     	ubfx	x13, x17, #8, #4
1000c7d48:     	ubfx	x26, x17, #12, #4
1000c7d4c:     	ubfx	x14, x17, #16, #4
1000c7d50:     	ubfx	x15, x17, #20, #4
1000c7d54:     	ubfx	x16, x17, #24, #4
1000c7d58:     	lsr	x17, x17, #28
1000c7d5c:     	ldr	w21, [x0, x12]
1000c7d60:     	lsl	w2, w21, #4
1000c7d64:     	and	x2, x2, #0xf0
1000c7d68:     	ldp	x4, x19, [sp, #152]
1000c7d6c:     	orr	x4, x2, x4
1000c7d70:     	ldrsb	w6, [x11, x4]
1000c7d74:     	and	x4, x21, #0xf0
1000c7d78:     	ldr	x5, [sp, #168]
1000c7d7c:     	orr	x5, x4, x5
1000c7d80:     	ldrsb	w7, [x11, x5]
1000c7d84:     	lsr	x5, x21, #4
1000c7d88:     	and	x5, x5, #0xf0
1000c7d8c:     	orr	x19, x5, x19
1000c7d90:     	ldrsb	w19, [x11, x19]
1000c7d94:     	add	w6, w6, w7
1000c7d98:     	add	w19, w6, w19
1000c7d9c:     	lsr	x6, x21, #8
1000c7da0:     	and	x6, x6, #0xf0
1000c7da4:     	ldp	x22, x7, [sp, #136]
1000c7da8:     	orr	x7, x6, x7
1000c7dac:     	ldrsb	w20, [x11, x7]
1000c7db0:     	lsr	x7, x21, #12
1000c7db4:     	and	x7, x7, #0xf0
1000c7db8:     	orr	x22, x7, x22
1000c7dbc:     	ldrsb	w22, [x11, x22]
1000c7dc0:     	add	w19, w19, w20
1000c7dc4:     	add	w22, w19, w22
1000c7dc8:     	lsr	x19, x21, #16
1000c7dcc:     	and	x19, x19, #0xf0
1000c7dd0:     	ldp	x24, x20, [sp, #120]
1000c7dd4:     	orr	x20, x19, x20
1000c7dd8:     	ldrsb	w23, [x11, x20]
1000c7ddc:     	lsr	x20, x21, #20
1000c7de0:     	and	x20, x20, #0xf0
1000c7de4:     	orr	x24, x20, x24
1000c7de8:     	ldrsb	w24, [x11, x24]
1000c7dec:     	add	w22, w22, w23
1000c7df0:     	add	w22, w22, w24
1000c7df4:     	lsr	x21, x21, #24
1000c7df8:     	and	x21, x21, #0xf0
1000c7dfc:     	ldr	x23, [sp, #112]
1000c7e00:     	orr	x23, x21, x23
1000c7e04:     	ldrsb	w23, [x11, x23]
1000c7e08:     	add	w22, w22, w23
1000c7e0c:     	scvtf	s0, w22
1000c7e10:     	ldp	x23, x22, [sp, #96]
1000c7e14:     	orr	x22, x2, x22
1000c7e18:     	ldrsb	w22, [x11, x22]
1000c7e1c:     	orr	x23, x4, x23
1000c7e20:     	ldrsb	w23, [x11, x23]
1000c7e24:     	ldr	x24, [sp, #88]
1000c7e28:     	orr	x24, x5, x24
1000c7e2c:     	ldrsb	w24, [x11, x24]
1000c7e30:     	add	w22, w22, w23
1000c7e34:     	add	w22, w22, w24
1000c7e38:     	ldp	x24, x23, [sp, #72]
1000c7e3c:     	orr	x23, x6, x23
1000c7e40:     	ldrsb	w23, [x11, x23]
1000c7e44:     	orr	x24, x7, x24
1000c7e48:     	ldrsb	w24, [x11, x24]
1000c7e4c:     	ldr	x25, [sp, #64]
1000c7e50:     	orr	x25, x19, x25
1000c7e54:     	ldrsb	w25, [x11, x25]
1000c7e58:     	add	w22, w22, w23
1000c7e5c:     	add	w22, w22, w24
1000c7e60:     	ldr	x23, [sp, #56]
1000c7e64:     	orr	x23, x20, x23
1000c7e68:     	ldrsb	w23, [x11, x23]
1000c7e6c:     	add	w22, w22, w25
1000c7e70:     	add	w22, w22, w23
1000c7e74:     	ldr	x23, [sp, #48]
1000c7e78:     	orr	x23, x21, x23
1000c7e7c:     	ldrsb	w23, [x11, x23]
1000c7e80:     	add	w22, w22, w23
1000c7e84:     	scvtf	s1, w22
1000c7e88:     	ldp	x23, x22, [sp, #32]
1000c7e8c:     	orr	x22, x2, x22
1000c7e90:     	ldrsb	w22, [x11, x22]
1000c7e94:     	orr	x23, x4, x23
1000c7e98:     	ldrsb	w23, [x11, x23]
1000c7e9c:     	ldr	x24, [sp, #24]
1000c7ea0:     	orr	x24, x5, x24
1000c7ea4:     	ldrsb	w24, [x11, x24]
1000c7ea8:     	add	w22, w22, w23
1000c7eac:     	add	w22, w22, w24
1000c7eb0:     	orr	x23, x6, x28
1000c7eb4:     	ldrsb	w23, [x11, x23]
1000c7eb8:     	orr	x24, x7, x30
1000c7ebc:     	ldrsb	w24, [x11, x24]
1000c7ec0:     	orr	x25, x19, x8
1000c7ec4:     	ldrsb	w25, [x11, x25]
1000c7ec8:     	add	w22, w22, w23
1000c7ecc:     	orr	x23, x20, x3
1000c7ed0:     	ldrsb	w23, [x11, x23]
1000c7ed4:     	add	w22, w22, w24
1000c7ed8:     	add	w22, w22, w25
1000c7edc:     	add	w22, w22, w23
1000c7ee0:     	orr	x23, x21, x9
1000c7ee4:     	ldrsb	w23, [x11, x23]
1000c7ee8:     	add	w22, w22, w23
1000c7eec:     	scvtf	s2, w22
1000c7ef0:     	orr	x2, x2, x1
1000c7ef4:     	ldrsb	w2, [x11, x2]
1000c7ef8:     	orr	x4, x4, x10
1000c7efc:     	ldrsb	w4, [x11, x4]
1000c7f00:     	orr	x5, x5, x13
1000c7f04:     	ldrsb	w5, [x11, x5]
1000c7f08:     	add	w2, w2, w4
1000c7f0c:     	add	w2, w2, w5
1000c7f10:     	orr	x4, x6, x26
1000c7f14:     	ldrsb	w4, [x11, x4]
1000c7f18:     	orr	x5, x7, x14
1000c7f1c:     	ldrsb	w5, [x11, x5]
1000c7f20:     	add	w2, w2, w4
1000c7f24:     	orr	x4, x19, x15
1000c7f28:     	ldrsb	w4, [x11, x4]
1000c7f2c:     	add	w2, w2, w5
1000c7f30:     	orr	x5, x20, x16
1000c7f34:     	ldrsb	w5, [x11, x5]
1000c7f38:     	add	w2, w2, w4
1000c7f3c:     	add	w2, w2, w5
1000c7f40:     	orr	x4, x21, x17
1000c7f44:     	ldrsb	w4, [x11, x4]
1000c7f48:     	add	w2, w2, w4
1000c7f4c:     	add	x4, sp, #176
1000c7f50:     	scvtf	s3, w2
1000c7f54:     	add	x2, x27, x12
1000c7f58:     	ldur	s4, [x2, #-64]
1000c7f5c:     	fadd	s1, s4, s1
1000c7f60:     	stur	s1, [x2, #-64]
1000c7f64:     	ldr	s1, [x2]
1000c7f68:     	fadd	s1, s1, s2
1000c7f6c:     	str	s1, [x2]
1000c7f70:     	ldr	s1, [x2, #64]
1000c7f74:     	fadd	s1, s1, s3
1000c7f78:     	ldr	s2, [x4, x12]
1000c7f7c:     	str	s1, [x2, #64]
1000c7f80:     	fadd	s0, s2, s0
1000c7f84:     	str	s0, [x4, x12]
1000c7f88:     	add	x12, x12, #4
1000c7f8c:     	cmp	x12, #64
1000c7f90:     	b.ne	0x1000c7d5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c7f94:     	add	x0, x0, #64
1000c7f98:     	ldp	x8, x1, [sp, #8]
1000c7f9c:     	add	x1, x1, #16
1000c7fa0:     	cmp	x1, x8
1000c7fa4:     	b.ne	0x1000c7c9c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c7fa8:     	ldp	q0, q1, [sp, #368]
1000c7fac:     	ldr	x8, [sp]
1000c7fb0:     	stp	q0, q1, [x8, #192]
1000c7fb4:     	ldp	q0, q1, [sp, #400]
1000c7fb8:     	stp	q0, q1, [x8, #224]
1000c7fbc:     	ldp	q0, q1, [sp, #304]
1000c7fc0:     	stp	q0, q1, [x8, #128]
1000c7fc4:     	ldp	q0, q1, [sp, #336]
1000c7fc8:     	stp	q0, q1, [x8, #160]
1000c7fcc:     	ldp	q0, q1, [sp, #240]
1000c7fd0:     	stp	q0, q1, [x8, #64]
1000c7fd4:     	ldp	q0, q1, [sp, #272]
1000c7fd8:     	stp	q0, q1, [x8, #96]
1000c7fdc:     	ldp	q0, q1, [sp, #176]
1000c7fe0:     	stp	q0, q1, [x8]
1000c7fe4:     	ldp	q0, q1, [sp, #208]
1000c7fe8:     	stp	q0, q1, [x8, #32]
1000c7fec:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 8ul, false>(char const*)+0x248>
1000c7ff0:     	ldr	x8, [x8, #392]
1000c7ff4:     	ldr	x8, [x8]
1000c7ff8:     	ldur	x9, [x29, #-96]
1000c7ffc:     	cmp	x8, x9
1000c8000:     	b.ne	0x1000c8024 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x404>
1000c8004:     	add	sp, sp, #448
1000c8008:     	ldp	x29, x30, [sp, #80]
1000c800c:     	ldp	x20, x19, [sp, #64]
1000c8010:     	ldp	x22, x21, [sp, #48]
1000c8014:     	ldp	x24, x23, [sp, #32]
1000c8018:     	ldp	x26, x25, [sp, #16]
1000c801c:     	ldp	x28, x27, [sp], #96
1000c8020:     	ret
1000c8024:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c997c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c997c:     	stp	x22, x21, [sp, #-48]!
1000c9980:     	stp	x20, x19, [sp, #16]
1000c9984:     	stp	x29, x30, [sp, #32]
1000c9988:     	add	x29, sp, #32
1000c998c:     	sub	sp, sp, #528
1000c9990:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xc4>
1000c9994:     	ldr	x8, [x8, #392]
1000c9998:     	ldr	x8, [x8]
1000c999c:     	stur	x8, [x29, #-40]
1000c99a0:     	movi.2d	v0, #0000000000000000
1000c99a4:     	stp	q0, q0, [sp, #480]
1000c99a8:     	lsl	x8, x2, #2
1000c99ac:     	stp	q0, q0, [sp, #448]
1000c99b0:     	stp	q0, q0, [sp, #416]
1000c99b4:     	stp	q0, q0, [sp, #384]
1000c99b8:     	stp	q0, q0, [sp, #352]
1000c99bc:     	stp	q0, q0, [sp, #320]
1000c99c0:     	stp	q0, q0, [sp, #288]
1000c99c4:     	stp	q0, q0, [sp, #256]
1000c99c8:     	stp	q0, q0, [sp, #224]
1000c99cc:     	stp	q0, q0, [sp, #192]
1000c99d0:     	stp	q0, q0, [sp, #160]
1000c99d4:     	stp	q0, q0, [sp, #128]
1000c99d8:     	stp	q0, q0, [sp, #96]
1000c99dc:     	stp	q0, q0, [sp, #64]
1000c99e0:     	stp	q0, q0, [sp, #32]
1000c99e4:     	stp	q0, q0, [sp]
1000c99e8:     	ands	x8, x8, #0xfffffffffffffff8
1000c99ec:     	b.eq	0x1000c9b04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x188>
1000c99f0:     	add	x8, x1, x8
1000c99f4:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x120>
1000c99f8:     	add	x9, x9, #1244
1000c99fc:     	mov	x10, #0
1000c9a00:     	mov	x11, sp
1000c9a04:     	mov	x12, #0
1000c9a08:     	ldr	w5, [x0, x10, lsl #2]
1000c9a0c:     	lsl	w13, w5, #4
1000c9a10:     	and	x13, x13, #0xf0
1000c9a14:     	and	x14, x5, #0xf0
1000c9a18:     	lsr	x15, x5, #4
1000c9a1c:     	and	x15, x15, #0xf0
1000c9a20:     	lsr	x16, x5, #8
1000c9a24:     	and	x16, x16, #0xf0
1000c9a28:     	lsr	x17, x5, #12
1000c9a2c:     	and	x17, x17, #0xf0
1000c9a30:     	lsr	x2, x5, #16
1000c9a34:     	and	x2, x2, #0xf0
1000c9a38:     	lsr	x4, x5, #20
1000c9a3c:     	and	x4, x4, #0xf0
1000c9a40:     	lsr	x5, x5, #24
1000c9a44:     	and	x5, x5, #0xf0
1000c9a48:     	mov	x6, x11
1000c9a4c:     	ldr	w7, [x1, x12]
1000c9a50:     	and	x19, x7, #0xf
1000c9a54:     	orr	x19, x13, x19
1000c9a58:     	ldrb	w19, [x9, x19]
1000c9a5c:     	ubfx	x20, x7, #4, #4
1000c9a60:     	orr	x20, x14, x20
1000c9a64:     	ldrb	w20, [x9, x20]
1000c9a68:     	ubfx	x21, x7, #8, #4
1000c9a6c:     	orr	x21, x15, x21
1000c9a70:     	ldrb	w21, [x9, x21]
1000c9a74:     	add	w19, w19, w20
1000c9a78:     	add	w19, w19, w21
1000c9a7c:     	ubfx	x20, x7, #12, #4
1000c9a80:     	orr	x20, x16, x20
1000c9a84:     	ldrb	w20, [x9, x20]
1000c9a88:     	ubfx	x21, x7, #16, #4
1000c9a8c:     	orr	x21, x17, x21
1000c9a90:     	ldrb	w21, [x9, x21]
1000c9a94:     	add	w19, w19, w20
1000c9a98:     	add	w19, w19, w21
1000c9a9c:     	ubfx	x20, x7, #20, #4
1000c9aa0:     	orr	x20, x2, x20
1000c9aa4:     	ldrb	w20, [x9, x20]
1000c9aa8:     	ubfx	x21, x7, #24, #4
1000c9aac:     	orr	x21, x4, x21
1000c9ab0:     	ldrb	w21, [x9, x21]
1000c9ab4:     	add	w19, w19, w20
1000c9ab8:     	add	w19, w19, w21
1000c9abc:     	orr	x7, x5, x7, lsr #28
1000c9ac0:     	ldrb	w7, [x9, x7]
1000c9ac4:     	add	w7, w19, w7
1000c9ac8:     	scvtf	s0, w7
1000c9acc:     	ldr	s1, [x6]
1000c9ad0:     	fadd	s0, s1, s0
1000c9ad4:     	str	s0, [x6], #64
1000c9ad8:     	add	x12, x12, #4
1000c9adc:     	cmp	x12, #32
1000c9ae0:     	b.ne	0x1000c9a4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c9ae4:     	add	x10, x10, #1
1000c9ae8:     	add	x11, x11, #4
1000c9aec:     	cmp	x10, #16
1000c9af0:     	b.ne	0x1000c9a04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x88>
1000c9af4:     	add	x0, x0, #64
1000c9af8:     	add	x1, x1, #32
1000c9afc:     	cmp	x1, x8
1000c9b00:     	b.ne	0x1000c99fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x80>
1000c9b04:     	mov	x1, sp
1000c9b08:     	mov	x0, x3
1000c9b0c:     	mov	w2, #512
1000c9b10:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000c9b14:     	ldur	x8, [x29, #-40]
1000c9b18:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000c9b1c:     	ldr	x9, [x9, #392]
1000c9b20:     	ldr	x9, [x9]
1000c9b24:     	cmp	x9, x8
1000c9b28:     	b.ne	0x1000c9b40 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c4>
1000c9b2c:     	add	sp, sp, #528
1000c9b30:     	ldp	x29, x30, [sp, #32]
1000c9b34:     	ldp	x20, x19, [sp, #16]
1000c9b38:     	ldp	x22, x21, [sp], #48
1000c9b3c:     	ret
1000c9b40:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000c9cf4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c9cf4:     	stp	x22, x21, [sp, #-48]!
1000c9cf8:     	stp	x20, x19, [sp, #16]
1000c9cfc:     	stp	x29, x30, [sp, #32]
1000c9d00:     	add	x29, sp, #32
1000c9d04:     	sub	sp, sp, #528
1000c9d08:     	adrp	x8, 0x100168000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0xc8>
1000c9d0c:     	ldr	x8, [x8, #392]
1000c9d10:     	ldr	x8, [x8]
1000c9d14:     	stur	x8, [x29, #-40]
1000c9d18:     	movi.2d	v0, #0000000000000000
1000c9d1c:     	stp	q0, q0, [sp, #480]
1000c9d20:     	lsl	x8, x2, #2
1000c9d24:     	stp	q0, q0, [sp, #448]
1000c9d28:     	stp	q0, q0, [sp, #416]
1000c9d2c:     	stp	q0, q0, [sp, #384]
1000c9d30:     	stp	q0, q0, [sp, #352]
1000c9d34:     	stp	q0, q0, [sp, #320]
1000c9d38:     	stp	q0, q0, [sp, #288]
1000c9d3c:     	stp	q0, q0, [sp, #256]
1000c9d40:     	stp	q0, q0, [sp, #224]
1000c9d44:     	stp	q0, q0, [sp, #192]
1000c9d48:     	stp	q0, q0, [sp, #160]
1000c9d4c:     	stp	q0, q0, [sp, #128]
1000c9d50:     	stp	q0, q0, [sp, #96]
1000c9d54:     	stp	q0, q0, [sp, #64]
1000c9d58:     	stp	q0, q0, [sp, #32]
1000c9d5c:     	stp	q0, q0, [sp]
1000c9d60:     	ands	x8, x8, #0xfffffffffffffff8
1000c9d64:     	b.eq	0x1000c9e7c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x188>
1000c9d68:     	add	x8, x1, x8
1000c9d6c:     	adrp	x9, 0x100166000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x124>
1000c9d70:     	add	x9, x9, #1500
1000c9d74:     	mov	x10, #0
1000c9d78:     	mov	x11, sp
1000c9d7c:     	mov	x12, #0
1000c9d80:     	ldr	w5, [x0, x10, lsl #2]
1000c9d84:     	lsl	w13, w5, #4
1000c9d88:     	and	x13, x13, #0xf0
1000c9d8c:     	and	x14, x5, #0xf0
1000c9d90:     	lsr	x15, x5, #4
1000c9d94:     	and	x15, x15, #0xf0
1000c9d98:     	lsr	x16, x5, #8
1000c9d9c:     	and	x16, x16, #0xf0
1000c9da0:     	lsr	x17, x5, #12
1000c9da4:     	and	x17, x17, #0xf0
1000c9da8:     	lsr	x2, x5, #16
1000c9dac:     	and	x2, x2, #0xf0
1000c9db0:     	lsr	x4, x5, #20
1000c9db4:     	and	x4, x4, #0xf0
1000c9db8:     	lsr	x5, x5, #24
1000c9dbc:     	and	x5, x5, #0xf0
1000c9dc0:     	mov	x6, x11
1000c9dc4:     	ldr	w7, [x1, x12]
1000c9dc8:     	and	x19, x7, #0xf
1000c9dcc:     	orr	x19, x13, x19
1000c9dd0:     	ldrsb	w19, [x9, x19]
1000c9dd4:     	ubfx	x20, x7, #4, #4
1000c9dd8:     	orr	x20, x14, x20
1000c9ddc:     	ldrsb	w20, [x9, x20]
1000c9de0:     	ubfx	x21, x7, #8, #4
1000c9de4:     	orr	x21, x15, x21
1000c9de8:     	ldrsb	w21, [x9, x21]
1000c9dec:     	add	w19, w19, w20
1000c9df0:     	add	w19, w19, w21
1000c9df4:     	ubfx	x20, x7, #12, #4
1000c9df8:     	orr	x20, x16, x20
1000c9dfc:     	ldrsb	w20, [x9, x20]
1000c9e00:     	ubfx	x21, x7, #16, #4
1000c9e04:     	orr	x21, x17, x21
1000c9e08:     	ldrsb	w21, [x9, x21]
1000c9e0c:     	add	w19, w19, w20
1000c9e10:     	add	w19, w19, w21
1000c9e14:     	ubfx	x20, x7, #20, #4
1000c9e18:     	orr	x20, x2, x20
1000c9e1c:     	ldrsb	w20, [x9, x20]
1000c9e20:     	ubfx	x21, x7, #24, #4
1000c9e24:     	orr	x21, x4, x21
1000c9e28:     	ldrsb	w21, [x9, x21]
1000c9e2c:     	add	w19, w19, w20
1000c9e30:     	add	w19, w19, w21
1000c9e34:     	orr	x7, x5, x7, lsr #28
1000c9e38:     	ldrsb	w7, [x9, x7]
1000c9e3c:     	add	w7, w19, w7
1000c9e40:     	scvtf	s0, w7
1000c9e44:     	ldr	s1, [x6]
1000c9e48:     	fadd	s0, s1, s0
1000c9e4c:     	str	s0, [x6], #64
1000c9e50:     	add	x12, x12, #4
1000c9e54:     	cmp	x12, #32
1000c9e58:     	b.ne	0x1000c9dc4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c9e5c:     	add	x10, x10, #1
1000c9e60:     	add	x11, x11, #4
1000c9e64:     	cmp	x10, #16
1000c9e68:     	b.ne	0x1000c9d7c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x88>
1000c9e6c:     	add	x0, x0, #64
1000c9e70:     	add	x1, x1, #32
1000c9e74:     	cmp	x1, x8
1000c9e78:     	b.ne	0x1000c9d74 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x80>
1000c9e7c:     	mov	x1, sp
1000c9e80:     	mov	x0, x3
1000c9e84:     	mov	w2, #512
1000c9e88:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000c9e8c:     	ldur	x8, [x29, #-40]
1000c9e90:     	adrp	x9, 0x100168000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x250>
1000c9e94:     	ldr	x9, [x9, #392]
1000c9e98:     	ldr	x9, [x9]
1000c9e9c:     	cmp	x9, x8
1000c9ea0:     	b.ne	0x1000c9eb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c4>
1000c9ea4:     	add	sp, sp, #528
1000c9ea8:     	ldp	x29, x30, [sp, #32]
1000c9eac:     	ldp	x20, x19, [sp, #16]
1000c9eb0:     	ldp	x22, x21, [sp], #48
1000c9eb4:     	ret
1000c9eb8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000cb138 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cb138:     	stp	x28, x27, [sp, #-64]!
1000cb13c:     	stp	x22, x21, [sp, #16]
1000cb140:     	stp	x20, x19, [sp, #32]
1000cb144:     	stp	x29, x30, [sp, #48]
1000cb148:     	add	x29, sp, #48
1000cb14c:     	sub	sp, sp, #1040
1000cb150:     	mov	x19, x3
1000cb154:     	mov	x20, x1
1000cb158:     	mov	x21, x0
1000cb15c:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf0>
1000cb160:     	ldr	x8, [x8, #392]
1000cb164:     	ldr	x8, [x8]
1000cb168:     	stur	x8, [x29, #-56]
1000cb16c:     	lsl	x8, x2, #3
1000cb170:     	and	x22, x8, #0xfffffffffffffff0
1000cb174:     	add	x0, sp, #8
1000cb178:     	mov	w1, #1024
1000cb17c:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000cb180:     	cbz	x22, 0x1000cb298 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000cb184:     	add	x8, x20, x22
1000cb188:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x114>
1000cb18c:     	add	x9, x9, #1244
1000cb190:     	mov	x10, #0
1000cb194:     	add	x11, sp, #8
1000cb198:     	mov	x12, #0
1000cb19c:     	ldr	w2, [x21, x10, lsl #2]
1000cb1a0:     	lsl	w13, w2, #4
1000cb1a4:     	and	x13, x13, #0xf0
1000cb1a8:     	and	x14, x2, #0xf0
1000cb1ac:     	lsr	x15, x2, #4
1000cb1b0:     	and	x15, x15, #0xf0
1000cb1b4:     	lsr	x16, x2, #8
1000cb1b8:     	and	x16, x16, #0xf0
1000cb1bc:     	lsr	x17, x2, #12
1000cb1c0:     	and	x17, x17, #0xf0
1000cb1c4:     	lsr	x0, x2, #16
1000cb1c8:     	and	x0, x0, #0xf0
1000cb1cc:     	lsr	x1, x2, #20
1000cb1d0:     	and	x1, x1, #0xf0
1000cb1d4:     	lsr	x2, x2, #24
1000cb1d8:     	and	x2, x2, #0xf0
1000cb1dc:     	mov	x3, x11
1000cb1e0:     	ldr	w4, [x20, x12]
1000cb1e4:     	and	x5, x4, #0xf
1000cb1e8:     	orr	x5, x13, x5
1000cb1ec:     	ldrb	w5, [x9, x5]
1000cb1f0:     	ubfx	x6, x4, #4, #4
1000cb1f4:     	orr	x6, x14, x6
1000cb1f8:     	ldrb	w6, [x9, x6]
1000cb1fc:     	ubfx	x7, x4, #8, #4
1000cb200:     	orr	x7, x15, x7
1000cb204:     	ldrb	w7, [x9, x7]
1000cb208:     	add	w5, w5, w6
1000cb20c:     	add	w5, w5, w7
1000cb210:     	ubfx	x6, x4, #12, #4
1000cb214:     	orr	x6, x16, x6
1000cb218:     	ldrb	w6, [x9, x6]
1000cb21c:     	ubfx	x7, x4, #16, #4
1000cb220:     	orr	x7, x17, x7
1000cb224:     	ldrb	w7, [x9, x7]
1000cb228:     	add	w5, w5, w6
1000cb22c:     	add	w5, w5, w7
1000cb230:     	ubfx	x6, x4, #20, #4
1000cb234:     	orr	x6, x0, x6
1000cb238:     	ldrb	w6, [x9, x6]
1000cb23c:     	ubfx	x7, x4, #24, #4
1000cb240:     	orr	x7, x1, x7
1000cb244:     	ldrb	w7, [x9, x7]
1000cb248:     	add	w5, w5, w6
1000cb24c:     	add	w5, w5, w7
1000cb250:     	orr	x4, x2, x4, lsr #28
1000cb254:     	ldrb	w4, [x9, x4]
1000cb258:     	add	w4, w5, w4
1000cb25c:     	scvtf	s0, w4
1000cb260:     	ldr	s1, [x3]
1000cb264:     	fadd	s0, s1, s0
1000cb268:     	str	s0, [x3], #64
1000cb26c:     	add	x12, x12, #4
1000cb270:     	cmp	x12, #64
1000cb274:     	b.ne	0x1000cb1e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000cb278:     	add	x10, x10, #1
1000cb27c:     	add	x11, x11, #4
1000cb280:     	cmp	x10, #16
1000cb284:     	b.ne	0x1000cb198 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000cb288:     	add	x21, x21, #64
1000cb28c:     	add	x20, x20, #64
1000cb290:     	cmp	x20, x8
1000cb294:     	b.ne	0x1000cb190 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000cb298:     	add	x1, sp, #8
1000cb29c:     	mov	x0, x19
1000cb2a0:     	mov	w2, #1024
1000cb2a4:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000cb2a8:     	ldur	x8, [x29, #-56]
1000cb2ac:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000cb2b0:     	ldr	x9, [x9, #392]
1000cb2b4:     	ldr	x9, [x9]
1000cb2b8:     	cmp	x9, x8
1000cb2bc:     	b.ne	0x1000cb2d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000cb2c0:     	add	sp, sp, #1040
1000cb2c4:     	ldp	x29, x30, [sp, #48]
1000cb2c8:     	ldp	x20, x19, [sp, #32]
1000cb2cc:     	ldp	x22, x21, [sp, #16]
1000cb2d0:     	ldp	x28, x27, [sp], #64
1000cb2d4:     	ret
1000cb2d8:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000cb550 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cb550:     	stp	x28, x27, [sp, #-64]!
1000cb554:     	stp	x22, x21, [sp, #16]
1000cb558:     	stp	x20, x19, [sp, #32]
1000cb55c:     	stp	x29, x30, [sp, #48]
1000cb560:     	add	x29, sp, #48
1000cb564:     	sub	sp, sp, #1040
1000cb568:     	mov	x19, x3
1000cb56c:     	mov	x20, x1
1000cb570:     	mov	x21, x0
1000cb574:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0xf4>
1000cb578:     	ldr	x8, [x8, #392]
1000cb57c:     	ldr	x8, [x8]
1000cb580:     	stur	x8, [x29, #-56]
1000cb584:     	lsl	x8, x2, #3
1000cb588:     	and	x22, x8, #0xfffffffffffffff0
1000cb58c:     	add	x0, sp, #8
1000cb590:     	mov	w1, #1024
1000cb594:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000cb598:     	cbz	x22, 0x1000cb6b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000cb59c:     	add	x8, x20, x22
1000cb5a0:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x118>
1000cb5a4:     	add	x9, x9, #1500
1000cb5a8:     	mov	x10, #0
1000cb5ac:     	add	x11, sp, #8
1000cb5b0:     	mov	x12, #0
1000cb5b4:     	ldr	w2, [x21, x10, lsl #2]
1000cb5b8:     	lsl	w13, w2, #4
1000cb5bc:     	and	x13, x13, #0xf0
1000cb5c0:     	and	x14, x2, #0xf0
1000cb5c4:     	lsr	x15, x2, #4
1000cb5c8:     	and	x15, x15, #0xf0
1000cb5cc:     	lsr	x16, x2, #8
1000cb5d0:     	and	x16, x16, #0xf0
1000cb5d4:     	lsr	x17, x2, #12
1000cb5d8:     	and	x17, x17, #0xf0
1000cb5dc:     	lsr	x0, x2, #16
1000cb5e0:     	and	x0, x0, #0xf0
1000cb5e4:     	lsr	x1, x2, #20
1000cb5e8:     	and	x1, x1, #0xf0
1000cb5ec:     	lsr	x2, x2, #24
1000cb5f0:     	and	x2, x2, #0xf0
1000cb5f4:     	mov	x3, x11
1000cb5f8:     	ldr	w4, [x20, x12]
1000cb5fc:     	and	x5, x4, #0xf
1000cb600:     	orr	x5, x13, x5
1000cb604:     	ldrsb	w5, [x9, x5]
1000cb608:     	ubfx	x6, x4, #4, #4
1000cb60c:     	orr	x6, x14, x6
1000cb610:     	ldrsb	w6, [x9, x6]
1000cb614:     	ubfx	x7, x4, #8, #4
1000cb618:     	orr	x7, x15, x7
1000cb61c:     	ldrsb	w7, [x9, x7]
1000cb620:     	add	w5, w5, w6
1000cb624:     	add	w5, w5, w7
1000cb628:     	ubfx	x6, x4, #12, #4
1000cb62c:     	orr	x6, x16, x6
1000cb630:     	ldrsb	w6, [x9, x6]
1000cb634:     	ubfx	x7, x4, #16, #4
1000cb638:     	orr	x7, x17, x7
1000cb63c:     	ldrsb	w7, [x9, x7]
1000cb640:     	add	w5, w5, w6
1000cb644:     	add	w5, w5, w7
1000cb648:     	ubfx	x6, x4, #20, #4
1000cb64c:     	orr	x6, x0, x6
1000cb650:     	ldrsb	w6, [x9, x6]
1000cb654:     	ubfx	x7, x4, #24, #4
1000cb658:     	orr	x7, x1, x7
1000cb65c:     	ldrsb	w7, [x9, x7]
1000cb660:     	add	w5, w5, w6
1000cb664:     	add	w5, w5, w7
1000cb668:     	orr	x4, x2, x4, lsr #28
1000cb66c:     	ldrsb	w4, [x9, x4]
1000cb670:     	add	w4, w5, w4
1000cb674:     	scvtf	s0, w4
1000cb678:     	ldr	s1, [x3]
1000cb67c:     	fadd	s0, s1, s0
1000cb680:     	str	s0, [x3], #64
1000cb684:     	add	x12, x12, #4
1000cb688:     	cmp	x12, #64
1000cb68c:     	b.ne	0x1000cb5f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000cb690:     	add	x10, x10, #1
1000cb694:     	add	x11, x11, #4
1000cb698:     	cmp	x10, #16
1000cb69c:     	b.ne	0x1000cb5b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000cb6a0:     	add	x21, x21, #64
1000cb6a4:     	add	x20, x20, #64
1000cb6a8:     	cmp	x20, x8
1000cb6ac:     	b.ne	0x1000cb5a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000cb6b0:     	add	x1, sp, #8
1000cb6b4:     	mov	x0, x19
1000cb6b8:     	mov	w2, #1024
1000cb6bc:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000cb6c0:     	ldur	x8, [x29, #-56]
1000cb6c4:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x244>
1000cb6c8:     	ldr	x9, [x9, #392]
1000cb6cc:     	ldr	x9, [x9]
1000cb6d0:     	cmp	x9, x8
1000cb6d4:     	b.ne	0x1000cb6f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000cb6d8:     	add	sp, sp, #1040
1000cb6dc:     	ldp	x29, x30, [sp, #48]
1000cb6e0:     	ldp	x20, x19, [sp, #32]
1000cb6e4:     	ldp	x22, x21, [sp, #16]
1000cb6e8:     	ldp	x28, x27, [sp], #64
1000cb6ec:     	ret
1000cb6f0:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000cc93c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000cc93c:     	stp	x22, x21, [sp, #-32]!
1000cc940:     	stp	x20, x19, [sp, #16]
1000cc944:     	movi.2d	v0, #0000000000000000
1000cc948:     	stp	q0, q0, [x3, #96]
1000cc94c:     	stp	q0, q0, [x3, #64]
1000cc950:     	stp	q0, q0, [x3, #32]
1000cc954:     	stp	q0, q0, [x3]
1000cc958:     	cmp	x2, #8
1000cc95c:     	b.hs	0x1000cc968 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000cc960:     	mov	x8, #0
1000cc964:     	b	0x1000cca78 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000cc968:     	mov	x8, #0
1000cc96c:     	mov	w14, #8
1000cc970:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x94>
1000cc974:     	add	x9, x9, #1756
1000cc978:     	mov	x10, x0
1000cc97c:     	mov	x11, #0
1000cc980:     	lsr	x8, x8, #1
1000cc984:     	mul	x8, x8, x4
1000cc988:     	ldr	w6, [x1, x8]
1000cc98c:     	ubfx	x12, x6, #4, #4
1000cc990:     	ubfx	x13, x6, #8, #4
1000cc994:     	mov	x8, x14
1000cc998:     	ubfx	x14, x6, #12, #4
1000cc99c:     	and	x15, x6, #0xf
1000cc9a0:     	ubfx	x16, x6, #16, #4
1000cc9a4:     	ubfx	x17, x6, #20, #4
1000cc9a8:     	ubfx	x5, x6, #24, #4
1000cc9ac:     	lsr	x6, x6, #28
1000cc9b0:     	ldr	w7, [x10, x11]
1000cc9b4:     	lsl	w19, w7, #4
1000cc9b8:     	and	x19, x19, #0xf0
1000cc9bc:     	orr	x19, x19, x15
1000cc9c0:     	ldrb	w19, [x9, x19]
1000cc9c4:     	and	x20, x7, #0xf0
1000cc9c8:     	orr	x20, x20, x12
1000cc9cc:     	ldrb	w20, [x9, x20]
1000cc9d0:     	lsr	x21, x7, #4
1000cc9d4:     	and	x21, x21, #0xf0
1000cc9d8:     	orr	x21, x21, x13
1000cc9dc:     	ldrb	w21, [x9, x21]
1000cc9e0:     	lsr	x22, x7, #8
1000cc9e4:     	and	x22, x22, #0xf0
1000cc9e8:     	orr	x22, x22, x14
1000cc9ec:     	ldrb	w22, [x9, x22]
1000cc9f0:     	add	w19, w19, w20
1000cc9f4:     	add	w19, w19, w21
1000cc9f8:     	lsr	x20, x7, #12
1000cc9fc:     	and	x20, x20, #0xf0
1000cca00:     	orr	x20, x20, x16
1000cca04:     	ldrb	w20, [x9, x20]
1000cca08:     	lsr	x21, x7, #16
1000cca0c:     	and	x21, x21, #0xf0
1000cca10:     	orr	x21, x21, x17
1000cca14:     	ldrb	w21, [x9, x21]
1000cca18:     	add	w19, w19, w22
1000cca1c:     	add	w19, w19, w20
1000cca20:     	lsr	x20, x7, #20
1000cca24:     	and	x20, x20, #0xf0
1000cca28:     	orr	x20, x20, x5
1000cca2c:     	ldrb	w20, [x9, x20]
1000cca30:     	lsr	x7, x7, #24
1000cca34:     	and	x7, x7, #0xf0
1000cca38:     	orr	x7, x7, x6
1000cca3c:     	ldrb	w7, [x9, x7]
1000cca40:     	add	w19, w19, w21
1000cca44:     	add	w19, w19, w20
1000cca48:     	add	w7, w19, w7
1000cca4c:     	scvtf	s0, w7
1000cca50:     	ldr	s1, [x3, x11]
1000cca54:     	fadd	s0, s1, s0
1000cca58:     	str	s0, [x3, x11]
1000cca5c:     	add	x11, x11, #4
1000cca60:     	cmp	x11, #128
1000cca64:     	b.ne	0x1000cc9b0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x74>
1000cca68:     	add	x14, x8, #8
1000cca6c:     	add	x10, x10, #128
1000cca70:     	cmp	x14, x2
1000cca74:     	b.ls	0x1000cc97c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000cca78:     	cmp	x8, x2
1000cca7c:     	b.hs	0x1000ccb0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1d0>
1000cca80:     	lsl	x9, x4, #2
1000cca84:     	mov	w10, #-16
1000cca88:     	mov	x11, #0
1000cca8c:     	lsr	x13, x8, #3
1000cca90:     	lsl	x12, x13, #7
1000cca94:     	mul	x14, x9, x13
1000cca98:     	ubfx	x13, x8, #1, #2
1000cca9c:     	orr	x14, x14, x13
1000ccaa0:     	ldrb	w15, [x1, x14]
1000ccaa4:     	ubfiz	w14, w8, #2, #1
1000ccaa8:     	lsr	w15, w15, w14
1000ccaac:     	and	w16, w15, #0xf
1000ccab0:     	cmp	w16, #8
1000ccab4:     	csel	w16, wzr, w10, lo
1000ccab8:     	bfxil	w16, w15, #0, #4
1000ccabc:     	scvtf	s0, w16
1000ccac0:     	add	x15, x12, x11
1000ccac4:     	orr	x15, x15, x13
1000ccac8:     	ldrb	w15, [x0, x15]
1000ccacc:     	lsr	w15, w15, w14
1000ccad0:     	and	w16, w15, #0xf
1000ccad4:     	cmp	w16, #8
1000ccad8:     	csel	w16, wzr, w10, lo
1000ccadc:     	bfxil	w16, w15, #0, #4
1000ccae0:     	scvtf	s1, w16
1000ccae4:     	ldr	s2, [x3, x11]
1000ccae8:     	fsub	s1, s1, s0
1000ccaec:     	fmadd	s1, s1, s1, s2
1000ccaf0:     	str	s1, [x3, x11]
1000ccaf4:     	add	x11, x11, #4
1000ccaf8:     	cmp	x11, #128
1000ccafc:     	b.ne	0x1000ccac0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000ccb00:     	add	x8, x8, #1
1000ccb04:     	cmp	x8, x2
1000ccb08:     	b.ne	0x1000cca88 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000ccb0c:     	ldp	x20, x19, [sp, #16]
1000ccb10:     	ldp	x22, x21, [sp], #32
1000ccb14:     	ret

00000001000ccb44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000ccb44:     	stp	x22, x21, [sp, #-32]!
1000ccb48:     	stp	x20, x19, [sp, #16]
1000ccb4c:     	movi.2d	v0, #0000000000000000
1000ccb50:     	stp	q0, q0, [x3, #96]
1000ccb54:     	stp	q0, q0, [x3, #64]
1000ccb58:     	stp	q0, q0, [x3, #32]
1000ccb5c:     	stp	q0, q0, [x3]
1000ccb60:     	cmp	x2, #8
1000ccb64:     	b.hs	0x1000ccb70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000ccb68:     	mov	x8, #0
1000ccb6c:     	b	0x1000ccc80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000ccb70:     	mov	x8, #0
1000ccb74:     	mov	w14, #8
1000ccb78:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 2ul, false>(char const*)+0xc4>
1000ccb7c:     	add	x9, x9, #2012
1000ccb80:     	mov	x10, x0
1000ccb84:     	mov	x11, #0
1000ccb88:     	lsr	x8, x8, #1
1000ccb8c:     	mul	x8, x8, x4
1000ccb90:     	ldr	w6, [x1, x8]
1000ccb94:     	ubfx	x12, x6, #4, #4
1000ccb98:     	ubfx	x13, x6, #8, #4
1000ccb9c:     	mov	x8, x14
1000ccba0:     	ubfx	x14, x6, #12, #4
1000ccba4:     	and	x15, x6, #0xf
1000ccba8:     	ubfx	x16, x6, #16, #4
1000ccbac:     	ubfx	x17, x6, #20, #4
1000ccbb0:     	ubfx	x5, x6, #24, #4
1000ccbb4:     	lsr	x6, x6, #28
1000ccbb8:     	ldr	w7, [x10, x11]
1000ccbbc:     	lsl	w19, w7, #4
1000ccbc0:     	and	x19, x19, #0xf0
1000ccbc4:     	orr	x19, x19, x15
1000ccbc8:     	ldrsb	w19, [x9, x19]
1000ccbcc:     	and	x20, x7, #0xf0
1000ccbd0:     	orr	x20, x20, x12
1000ccbd4:     	ldrsb	w20, [x9, x20]
1000ccbd8:     	lsr	x21, x7, #4
1000ccbdc:     	and	x21, x21, #0xf0
1000ccbe0:     	orr	x21, x21, x13
1000ccbe4:     	ldrsb	w21, [x9, x21]
1000ccbe8:     	lsr	x22, x7, #8
1000ccbec:     	and	x22, x22, #0xf0
1000ccbf0:     	orr	x22, x22, x14
1000ccbf4:     	ldrsb	w22, [x9, x22]
1000ccbf8:     	add	w19, w19, w20
1000ccbfc:     	add	w19, w19, w21
1000ccc00:     	lsr	x20, x7, #12
1000ccc04:     	and	x20, x20, #0xf0
1000ccc08:     	orr	x20, x20, x16
1000ccc0c:     	ldrsb	w20, [x9, x20]
1000ccc10:     	lsr	x21, x7, #16
1000ccc14:     	and	x21, x21, #0xf0
1000ccc18:     	orr	x21, x21, x17
1000ccc1c:     	ldrsb	w21, [x9, x21]
1000ccc20:     	add	w19, w19, w22
1000ccc24:     	add	w19, w19, w20
1000ccc28:     	lsr	x20, x7, #20
1000ccc2c:     	and	x20, x20, #0xf0
1000ccc30:     	orr	x20, x20, x5
1000ccc34:     	ldrsb	w20, [x9, x20]
1000ccc38:     	lsr	x7, x7, #24
1000ccc3c:     	and	x7, x7, #0xf0
1000ccc40:     	orr	x7, x7, x6
1000ccc44:     	ldrsb	w7, [x9, x7]
1000ccc48:     	add	w19, w19, w21
1000ccc4c:     	add	w19, w19, w20
1000ccc50:     	add	w7, w19, w7
1000ccc54:     	scvtf	s0, w7
1000ccc58:     	ldr	s1, [x3, x11]
1000ccc5c:     	fadd	s0, s1, s0
1000ccc60:     	str	s0, [x3, x11]
1000ccc64:     	add	x11, x11, #4
1000ccc68:     	cmp	x11, #128
1000ccc6c:     	b.ne	0x1000ccbb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x74>
1000ccc70:     	add	x14, x8, #8
1000ccc74:     	add	x10, x10, #128
1000ccc78:     	cmp	x14, x2
1000ccc7c:     	b.ls	0x1000ccb84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000ccc80:     	cmp	x8, x2
1000ccc84:     	b.hs	0x1000ccd10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1cc>
1000ccc88:     	lsl	x9, x4, #2
1000ccc8c:     	mov	w10, #-16
1000ccc90:     	mov	x11, #0
1000ccc94:     	lsr	x13, x8, #3
1000ccc98:     	lsl	x12, x13, #7
1000ccc9c:     	mul	x14, x9, x13
1000ccca0:     	ubfx	x13, x8, #1, #2
1000ccca4:     	orr	x14, x14, x13
1000ccca8:     	ldrb	w15, [x1, x14]
1000cccac:     	ubfiz	w14, w8, #2, #1
1000cccb0:     	lsr	w15, w15, w14
1000cccb4:     	and	w16, w15, #0xf
1000cccb8:     	cmp	w16, #8
1000cccbc:     	csel	w16, wzr, w10, lo
1000cccc0:     	bfxil	w16, w15, #0, #4
1000cccc4:     	scvtf	s0, w16
1000cccc8:     	add	x15, x12, x11
1000ccccc:     	orr	x15, x15, x13
1000cccd0:     	ldrb	w15, [x0, x15]
1000cccd4:     	lsr	w15, w15, w14
1000cccd8:     	and	w16, w15, #0xf
1000cccdc:     	cmp	w16, #8
1000ccce0:     	csel	w16, wzr, w10, lo
1000ccce4:     	bfxil	w16, w15, #0, #4
1000ccce8:     	scvtf	s1, w16
1000cccec:     	ldr	s2, [x3, x11]
1000cccf0:     	fmsub	s1, s1, s0, s2
1000cccf4:     	str	s1, [x3, x11]
1000cccf8:     	add	x11, x11, #4
1000cccfc:     	cmp	x11, #128
1000ccd00:     	b.ne	0x1000cccc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000ccd04:     	add	x8, x8, #1
1000ccd08:     	cmp	x8, x2
1000ccd0c:     	b.ne	0x1000ccc90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000ccd10:     	ldp	x20, x19, [sp, #16]
1000ccd14:     	ldp	x22, x21, [sp], #32
1000ccd18:     	ret

00000001000ce2c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce2c4:     	sub	sp, sp, #400
1000ce2c8:     	stp	x28, x27, [sp, #304]
1000ce2cc:     	stp	x26, x25, [sp, #320]
1000ce2d0:     	stp	x24, x23, [sp, #336]
1000ce2d4:     	stp	x22, x21, [sp, #352]
1000ce2d8:     	stp	x20, x19, [sp, #368]
1000ce2dc:     	stp	x29, x30, [sp, #384]
1000ce2e0:     	add	x29, sp, #384
1000ce2e4:     	str	x3, [sp]
1000ce2e8:     	adrp	x8, 0x100168000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xc>
1000ce2ec:     	ldr	x8, [x8, #392]
1000ce2f0:     	ldr	x8, [x8]
1000ce2f4:     	stur	x8, [x29, #-96]
1000ce2f8:     	movi.2d	v0, #0000000000000000
1000ce2fc:     	stp	q0, q0, [sp, #256]
1000ce300:     	stp	q0, q0, [sp, #224]
1000ce304:     	stp	q0, q0, [sp, #192]
1000ce308:     	stp	q0, q0, [sp, #160]
1000ce30c:     	stp	q0, q0, [sp, #128]
1000ce310:     	stp	q0, q0, [sp, #96]
1000ce314:     	stp	q0, q0, [sp, #64]
1000ce318:     	stp	q0, q0, [sp, #32]
1000ce31c:     	ands	x8, x2, #0xfffffffffffffffe
1000ce320:     	b.eq	0x1000ce4c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x200>
1000ce324:     	add	x8, x1, x8
1000ce328:     	str	x8, [sp, #8]
1000ce32c:     	adrp	x9, 0x100166000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x48>
1000ce330:     	add	x9, x9, #1756
1000ce334:     	mov	x11, #0
1000ce338:     	ldp	w4, w23, [x1]
1000ce33c:     	ubfx	x8, x4, #4, #4
1000ce340:     	stp	x1, x8, [sp, #16]
1000ce344:     	ubfx	x13, x4, #8, #4
1000ce348:     	and	x14, x4, #0xf
1000ce34c:     	ubfx	x15, x4, #12, #4
1000ce350:     	ubfx	x16, x4, #16, #4
1000ce354:     	ubfx	x17, x4, #20, #4
1000ce358:     	ubfx	x2, x4, #24, #4
1000ce35c:     	lsr	x4, x4, #28
1000ce360:     	and	x5, x23, #0xf
1000ce364:     	ubfx	x6, x23, #4, #4
1000ce368:     	ubfx	x7, x23, #8, #4
1000ce36c:     	ubfx	x19, x23, #12, #4
1000ce370:     	ubfx	x20, x23, #16, #4
1000ce374:     	ubfx	x21, x23, #20, #4
1000ce378:     	ubfx	x22, x23, #24, #4
1000ce37c:     	lsr	x23, x23, #28
1000ce380:     	ldr	w24, [x0, x11]
1000ce384:     	lsl	w25, w24, #4
1000ce388:     	and	x25, x25, #0xf0
1000ce38c:     	orr	x26, x25, x14
1000ce390:     	ldrb	w26, [x9, x26]
1000ce394:     	and	x27, x24, #0xf0
1000ce398:     	ldr	x8, [sp, #24]
1000ce39c:     	orr	x28, x27, x8
1000ce3a0:     	ldrb	w28, [x9, x28]
1000ce3a4:     	lsr	x30, x24, #4
1000ce3a8:     	and	x30, x30, #0xf0
1000ce3ac:     	orr	x8, x30, x13
1000ce3b0:     	ldrb	w8, [x9, x8]
1000ce3b4:     	add	w26, w26, w28
1000ce3b8:     	add	w8, w26, w8
1000ce3bc:     	lsr	x26, x24, #8
1000ce3c0:     	and	x26, x26, #0xf0
1000ce3c4:     	orr	x28, x26, x15
1000ce3c8:     	ldrb	w28, [x9, x28]
1000ce3cc:     	lsr	x3, x24, #12
1000ce3d0:     	and	x3, x3, #0xf0
1000ce3d4:     	orr	x10, x3, x16
1000ce3d8:     	ldrb	w10, [x9, x10]
1000ce3dc:     	add	w8, w8, w28
1000ce3e0:     	add	w8, w8, w10
1000ce3e4:     	lsr	x10, x24, #16
1000ce3e8:     	and	x10, x10, #0xf0
1000ce3ec:     	orr	x28, x10, x17
1000ce3f0:     	ldrb	w28, [x9, x28]
1000ce3f4:     	lsr	x1, x24, #20
1000ce3f8:     	and	x1, x1, #0xf0
1000ce3fc:     	orr	x12, x1, x2
1000ce400:     	ldrb	w12, [x9, x12]
1000ce404:     	add	w8, w8, w28
1000ce408:     	add	x28, sp, #32
1000ce40c:     	add	w8, w8, w12
1000ce410:     	lsr	x12, x24, #24
1000ce414:     	and	x12, x12, #0xf0
1000ce418:     	orr	x24, x12, x4
1000ce41c:     	ldrb	w24, [x9, x24]
1000ce420:     	add	w8, w8, w24
1000ce424:     	scvtf	s0, w8
1000ce428:     	add	x8, x28, x11
1000ce42c:     	ldr	s1, [x8]
1000ce430:     	fadd	s0, s1, s0
1000ce434:     	orr	x24, x25, x5
1000ce438:     	ldrb	w24, [x9, x24]
1000ce43c:     	orr	x25, x27, x6
1000ce440:     	ldrb	w25, [x9, x25]
1000ce444:     	orr	x27, x30, x7
1000ce448:     	ldrb	w27, [x9, x27]
1000ce44c:     	add	w24, w24, w25
1000ce450:     	add	w24, w24, w27
1000ce454:     	orr	x25, x26, x19
1000ce458:     	ldrb	w25, [x9, x25]
1000ce45c:     	orr	x3, x3, x20
1000ce460:     	ldrb	w3, [x9, x3]
1000ce464:     	orr	x10, x10, x21
1000ce468:     	ldrb	w10, [x9, x10]
1000ce46c:     	add	w24, w24, w25
1000ce470:     	add	w3, w24, w3
1000ce474:     	orr	x1, x1, x22
1000ce478:     	ldrb	w1, [x9, x1]
1000ce47c:     	add	w10, w3, w10
1000ce480:     	add	w10, w10, w1
1000ce484:     	orr	x12, x12, x23
1000ce488:     	ldrb	w12, [x9, x12]
1000ce48c:     	add	w10, w10, w12
1000ce490:     	scvtf	s1, w10
1000ce494:     	str	s0, [x8]
1000ce498:     	ldr	s0, [x8, #128]
1000ce49c:     	fadd	s0, s0, s1
1000ce4a0:     	str	s0, [x8, #128]
1000ce4a4:     	add	x11, x11, #4
1000ce4a8:     	cmp	x11, #128
1000ce4ac:     	b.ne	0x1000ce380 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000ce4b0:     	add	x0, x0, #128
1000ce4b4:     	ldp	x8, x1, [sp, #8]
1000ce4b8:     	add	x1, x1, #8
1000ce4bc:     	cmp	x1, x8
1000ce4c0:     	b.ne	0x1000ce334 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000ce4c4:     	ldp	q0, q1, [sp, #224]
1000ce4c8:     	ldr	x8, [sp]
1000ce4cc:     	stp	q0, q1, [x8, #192]
1000ce4d0:     	ldp	q0, q1, [sp, #256]
1000ce4d4:     	stp	q0, q1, [x8, #224]
1000ce4d8:     	ldp	q0, q1, [sp, #160]
1000ce4dc:     	stp	q0, q1, [x8, #128]
1000ce4e0:     	ldp	q0, q1, [sp, #192]
1000ce4e4:     	stp	q0, q1, [x8, #160]
1000ce4e8:     	ldp	q0, q1, [sp, #96]
1000ce4ec:     	stp	q0, q1, [x8, #64]
1000ce4f0:     	ldp	q0, q1, [sp, #128]
1000ce4f4:     	stp	q0, q1, [x8, #96]
1000ce4f8:     	ldp	q0, q1, [sp, #32]
1000ce4fc:     	stp	q0, q1, [x8]
1000ce500:     	ldp	q0, q1, [sp, #64]
1000ce504:     	stp	q0, q1, [x8, #32]
1000ce508:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000ce50c:     	ldr	x8, [x8, #392]
1000ce510:     	ldr	x8, [x8]
1000ce514:     	ldur	x9, [x29, #-96]
1000ce518:     	cmp	x8, x9
1000ce51c:     	b.ne	0x1000ce540 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x27c>
1000ce520:     	ldp	x29, x30, [sp, #384]
1000ce524:     	ldp	x20, x19, [sp, #368]
1000ce528:     	ldp	x22, x21, [sp, #352]
1000ce52c:     	ldp	x24, x23, [sp, #336]
1000ce530:     	ldp	x26, x25, [sp, #320]
1000ce534:     	ldp	x28, x27, [sp, #304]
1000ce538:     	add	sp, sp, #400
1000ce53c:     	ret
1000ce540:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000ce610 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce610:     	sub	sp, sp, #400
1000ce614:     	stp	x28, x27, [sp, #304]
1000ce618:     	stp	x26, x25, [sp, #320]
1000ce61c:     	stp	x24, x23, [sp, #336]
1000ce620:     	stp	x22, x21, [sp, #352]
1000ce624:     	stp	x20, x19, [sp, #368]
1000ce628:     	stp	x29, x30, [sp, #384]
1000ce62c:     	add	x29, sp, #384
1000ce630:     	str	x3, [sp]
1000ce634:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0xc>
1000ce638:     	ldr	x8, [x8, #392]
1000ce63c:     	ldr	x8, [x8]
1000ce640:     	stur	x8, [x29, #-96]
1000ce644:     	movi.2d	v0, #0000000000000000
1000ce648:     	stp	q0, q0, [sp, #256]
1000ce64c:     	stp	q0, q0, [sp, #224]
1000ce650:     	stp	q0, q0, [sp, #192]
1000ce654:     	stp	q0, q0, [sp, #160]
1000ce658:     	stp	q0, q0, [sp, #128]
1000ce65c:     	stp	q0, q0, [sp, #96]
1000ce660:     	stp	q0, q0, [sp, #64]
1000ce664:     	stp	q0, q0, [sp, #32]
1000ce668:     	ands	x8, x2, #0xfffffffffffffffe
1000ce66c:     	b.eq	0x1000ce810 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x200>
1000ce670:     	add	x8, x1, x8
1000ce674:     	str	x8, [sp, #8]
1000ce678:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x48>
1000ce67c:     	add	x9, x9, #2012
1000ce680:     	mov	x11, #0
1000ce684:     	ldp	w4, w23, [x1]
1000ce688:     	ubfx	x8, x4, #4, #4
1000ce68c:     	stp	x1, x8, [sp, #16]
1000ce690:     	ubfx	x13, x4, #8, #4
1000ce694:     	and	x14, x4, #0xf
1000ce698:     	ubfx	x15, x4, #12, #4
1000ce69c:     	ubfx	x16, x4, #16, #4
1000ce6a0:     	ubfx	x17, x4, #20, #4
1000ce6a4:     	ubfx	x2, x4, #24, #4
1000ce6a8:     	lsr	x4, x4, #28
1000ce6ac:     	and	x5, x23, #0xf
1000ce6b0:     	ubfx	x6, x23, #4, #4
1000ce6b4:     	ubfx	x7, x23, #8, #4
1000ce6b8:     	ubfx	x19, x23, #12, #4
1000ce6bc:     	ubfx	x20, x23, #16, #4
1000ce6c0:     	ubfx	x21, x23, #20, #4
1000ce6c4:     	ubfx	x22, x23, #24, #4
1000ce6c8:     	lsr	x23, x23, #28
1000ce6cc:     	ldr	w24, [x0, x11]
1000ce6d0:     	lsl	w25, w24, #4
1000ce6d4:     	and	x25, x25, #0xf0
1000ce6d8:     	orr	x26, x25, x14
1000ce6dc:     	ldrsb	w26, [x9, x26]
1000ce6e0:     	and	x27, x24, #0xf0
1000ce6e4:     	ldr	x8, [sp, #24]
1000ce6e8:     	orr	x28, x27, x8
1000ce6ec:     	ldrsb	w28, [x9, x28]
1000ce6f0:     	lsr	x30, x24, #4
1000ce6f4:     	and	x30, x30, #0xf0
1000ce6f8:     	orr	x8, x30, x13
1000ce6fc:     	ldrsb	w8, [x9, x8]
1000ce700:     	add	w26, w26, w28
1000ce704:     	add	w8, w26, w8
1000ce708:     	lsr	x26, x24, #8
1000ce70c:     	and	x26, x26, #0xf0
1000ce710:     	orr	x28, x26, x15
1000ce714:     	ldrsb	w28, [x9, x28]
1000ce718:     	lsr	x3, x24, #12
1000ce71c:     	and	x3, x3, #0xf0
1000ce720:     	orr	x10, x3, x16
1000ce724:     	ldrsb	w10, [x9, x10]
1000ce728:     	add	w8, w8, w28
1000ce72c:     	add	w8, w8, w10
1000ce730:     	lsr	x10, x24, #16
1000ce734:     	and	x10, x10, #0xf0
1000ce738:     	orr	x28, x10, x17
1000ce73c:     	ldrsb	w28, [x9, x28]
1000ce740:     	lsr	x1, x24, #20
1000ce744:     	and	x1, x1, #0xf0
1000ce748:     	orr	x12, x1, x2
1000ce74c:     	ldrsb	w12, [x9, x12]
1000ce750:     	add	w8, w8, w28
1000ce754:     	add	x28, sp, #32
1000ce758:     	add	w8, w8, w12
1000ce75c:     	lsr	x12, x24, #24
1000ce760:     	and	x12, x12, #0xf0
1000ce764:     	orr	x24, x12, x4
1000ce768:     	ldrsb	w24, [x9, x24]
1000ce76c:     	add	w8, w8, w24
1000ce770:     	scvtf	s0, w8
1000ce774:     	add	x8, x28, x11
1000ce778:     	ldr	s1, [x8]
1000ce77c:     	fadd	s0, s1, s0
1000ce780:     	orr	x24, x25, x5
1000ce784:     	ldrsb	w24, [x9, x24]
1000ce788:     	orr	x25, x27, x6
1000ce78c:     	ldrsb	w25, [x9, x25]
1000ce790:     	orr	x27, x30, x7
1000ce794:     	ldrsb	w27, [x9, x27]
1000ce798:     	add	w24, w24, w25
1000ce79c:     	add	w24, w24, w27
1000ce7a0:     	orr	x25, x26, x19
1000ce7a4:     	ldrsb	w25, [x9, x25]
1000ce7a8:     	orr	x3, x3, x20
1000ce7ac:     	ldrsb	w3, [x9, x3]
1000ce7b0:     	orr	x10, x10, x21
1000ce7b4:     	ldrsb	w10, [x9, x10]
1000ce7b8:     	add	w24, w24, w25
1000ce7bc:     	add	w3, w24, w3
1000ce7c0:     	orr	x1, x1, x22
1000ce7c4:     	ldrsb	w1, [x9, x1]
1000ce7c8:     	add	w10, w3, w10
1000ce7cc:     	add	w10, w10, w1
1000ce7d0:     	orr	x12, x12, x23
1000ce7d4:     	ldrsb	w12, [x9, x12]
1000ce7d8:     	add	w10, w10, w12
1000ce7dc:     	scvtf	s1, w10
1000ce7e0:     	str	s0, [x8]
1000ce7e4:     	ldr	s0, [x8, #128]
1000ce7e8:     	fadd	s0, s0, s1
1000ce7ec:     	str	s0, [x8, #128]
1000ce7f0:     	add	x11, x11, #4
1000ce7f4:     	cmp	x11, #128
1000ce7f8:     	b.ne	0x1000ce6cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000ce7fc:     	add	x0, x0, #128
1000ce800:     	ldp	x8, x1, [sp, #8]
1000ce804:     	add	x1, x1, #8
1000ce808:     	cmp	x1, x8
1000ce80c:     	b.ne	0x1000ce680 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000ce810:     	ldp	q0, q1, [sp, #224]
1000ce814:     	ldr	x8, [sp]
1000ce818:     	stp	q0, q1, [x8, #192]
1000ce81c:     	ldp	q0, q1, [sp, #256]
1000ce820:     	stp	q0, q1, [x8, #224]
1000ce824:     	ldp	q0, q1, [sp, #160]
1000ce828:     	stp	q0, q1, [x8, #128]
1000ce82c:     	ldp	q0, q1, [sp, #192]
1000ce830:     	stp	q0, q1, [x8, #160]
1000ce834:     	ldp	q0, q1, [sp, #96]
1000ce838:     	stp	q0, q1, [x8, #64]
1000ce83c:     	ldp	q0, q1, [sp, #128]
1000ce840:     	stp	q0, q1, [x8, #96]
1000ce844:     	ldp	q0, q1, [sp, #32]
1000ce848:     	stp	q0, q1, [x8]
1000ce84c:     	ldp	q0, q1, [sp, #64]
1000ce850:     	stp	q0, q1, [x8, #32]
1000ce854:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x22c>
1000ce858:     	ldr	x8, [x8, #392]
1000ce85c:     	ldr	x8, [x8]
1000ce860:     	ldur	x9, [x29, #-96]
1000ce864:     	cmp	x8, x9
1000ce868:     	b.ne	0x1000ce88c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x27c>
1000ce86c:     	ldp	x29, x30, [sp, #384]
1000ce870:     	ldp	x20, x19, [sp, #368]
1000ce874:     	ldp	x22, x21, [sp, #352]
1000ce878:     	ldp	x24, x23, [sp, #336]
1000ce87c:     	ldp	x26, x25, [sp, #320]
1000ce880:     	ldp	x28, x27, [sp, #304]
1000ce884:     	add	sp, sp, #400
1000ce888:     	ret
1000ce88c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d00fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d00fc:     	stp	x28, x27, [sp, #-96]!
1000d0100:     	stp	x26, x25, [sp, #16]
1000d0104:     	stp	x24, x23, [sp, #32]
1000d0108:     	stp	x22, x21, [sp, #48]
1000d010c:     	stp	x20, x19, [sp, #64]
1000d0110:     	stp	x29, x30, [sp, #80]
1000d0114:     	add	x29, sp, #80
1000d0118:     	sub	sp, sp, #704
1000d011c:     	str	x3, [sp]
1000d0120:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x284>
1000d0124:     	ldr	x8, [x8, #392]
1000d0128:     	ldr	x8, [x8]
1000d012c:     	stur	x8, [x29, #-96]
1000d0130:     	movi.2d	v0, #0000000000000000
1000d0134:     	stp	q0, q0, [sp, #656]
1000d0138:     	lsl	x8, x2, #1
1000d013c:     	stp	q0, q0, [sp, #624]
1000d0140:     	stp	q0, q0, [sp, #592]
1000d0144:     	stp	q0, q0, [sp, #560]
1000d0148:     	stp	q0, q0, [sp, #528]
1000d014c:     	stp	q0, q0, [sp, #496]
1000d0150:     	stp	q0, q0, [sp, #464]
1000d0154:     	stp	q0, q0, [sp, #432]
1000d0158:     	stp	q0, q0, [sp, #400]
1000d015c:     	stp	q0, q0, [sp, #368]
1000d0160:     	stp	q0, q0, [sp, #336]
1000d0164:     	stp	q0, q0, [sp, #304]
1000d0168:     	stp	q0, q0, [sp, #272]
1000d016c:     	stp	q0, q0, [sp, #240]
1000d0170:     	stp	q0, q0, [sp, #208]
1000d0174:     	stp	q0, q0, [sp, #176]
1000d0178:     	ands	x8, x8, #0xfffffffffffffffc
1000d017c:     	b.eq	0x1000d04a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a8>
1000d0180:     	add	x8, x1, x8
1000d0184:     	str	x8, [sp, #8]
1000d0188:     	add	x8, sp, #176
1000d018c:     	add	x27, x8, #256
1000d0190:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ec>
1000d0194:     	add	x11, x11, #1756
1000d0198:     	mov	x12, #0
1000d019c:     	ldp	w8, w9, [x1]
1000d01a0:     	ubfx	x10, x8, #4, #4
1000d01a4:     	str	x10, [sp, #168]
1000d01a8:     	ubfx	x10, x8, #8, #4
1000d01ac:     	str	x10, [sp, #160]
1000d01b0:     	and	x10, x8, #0xf
1000d01b4:     	str	x10, [sp, #152]
1000d01b8:     	ubfx	x10, x8, #12, #4
1000d01bc:     	str	x10, [sp, #144]
1000d01c0:     	ubfx	x10, x8, #16, #4
1000d01c4:     	str	x10, [sp, #136]
1000d01c8:     	ubfx	x10, x8, #20, #4
1000d01cc:     	str	x10, [sp, #128]
1000d01d0:     	ubfx	x10, x8, #24, #4
1000d01d4:     	lsr	x8, x8, #28
1000d01d8:     	stp	x8, x10, [sp, #112]
1000d01dc:     	and	x10, x9, #0xf
1000d01e0:     	ubfx	x8, x9, #4, #4
1000d01e4:     	stp	x8, x10, [sp, #96]
1000d01e8:     	ubfx	x10, x9, #8, #4
1000d01ec:     	ubfx	x8, x9, #12, #4
1000d01f0:     	stp	x8, x10, [sp, #80]
1000d01f4:     	ubfx	x10, x9, #16, #4
1000d01f8:     	ubfx	x8, x9, #20, #4
1000d01fc:     	stp	x8, x10, [sp, #64]
1000d0200:     	ubfx	x10, x9, #24, #4
1000d0204:     	lsr	x8, x9, #28
1000d0208:     	stp	x8, x10, [sp, #48]
1000d020c:     	ldp	w9, w17, [x1, #8]
1000d0210:     	and	x10, x9, #0xf
1000d0214:     	ubfx	x8, x9, #4, #4
1000d0218:     	stp	x8, x10, [sp, #32]
1000d021c:     	ubfx	x8, x9, #8, #4
1000d0220:     	stp	x1, x8, [sp, #16]
1000d0224:     	ubfx	x28, x9, #12, #4
1000d0228:     	ubfx	x30, x9, #16, #4
1000d022c:     	ubfx	x3, x9, #20, #4
1000d0230:     	ubfx	x8, x9, #24, #4
1000d0234:     	lsr	x9, x9, #28
1000d0238:     	and	x1, x17, #0xf
1000d023c:     	ubfx	x10, x17, #4, #4
1000d0240:     	ubfx	x13, x17, #8, #4
1000d0244:     	ubfx	x26, x17, #12, #4
1000d0248:     	ubfx	x14, x17, #16, #4
1000d024c:     	ubfx	x15, x17, #20, #4
1000d0250:     	ubfx	x16, x17, #24, #4
1000d0254:     	lsr	x17, x17, #28
1000d0258:     	ldr	w21, [x0, x12]
1000d025c:     	lsl	w2, w21, #4
1000d0260:     	and	x2, x2, #0xf0
1000d0264:     	ldp	x4, x19, [sp, #152]
1000d0268:     	orr	x4, x2, x4
1000d026c:     	ldrb	w6, [x11, x4]
1000d0270:     	and	x4, x21, #0xf0
1000d0274:     	ldr	x5, [sp, #168]
1000d0278:     	orr	x5, x4, x5
1000d027c:     	ldrb	w7, [x11, x5]
1000d0280:     	lsr	x5, x21, #4
1000d0284:     	and	x5, x5, #0xf0
1000d0288:     	orr	x19, x5, x19
1000d028c:     	ldrb	w19, [x11, x19]
1000d0290:     	add	w6, w6, w7
1000d0294:     	add	w19, w6, w19
1000d0298:     	lsr	x6, x21, #8
1000d029c:     	and	x6, x6, #0xf0
1000d02a0:     	ldp	x22, x7, [sp, #136]
1000d02a4:     	orr	x7, x6, x7
1000d02a8:     	ldrb	w20, [x11, x7]
1000d02ac:     	lsr	x7, x21, #12
1000d02b0:     	and	x7, x7, #0xf0
1000d02b4:     	orr	x22, x7, x22
1000d02b8:     	ldrb	w22, [x11, x22]
1000d02bc:     	add	w19, w19, w20
1000d02c0:     	add	w22, w19, w22
1000d02c4:     	lsr	x19, x21, #16
1000d02c8:     	and	x19, x19, #0xf0
1000d02cc:     	ldp	x24, x20, [sp, #120]
1000d02d0:     	orr	x20, x19, x20
1000d02d4:     	ldrb	w23, [x11, x20]
1000d02d8:     	lsr	x20, x21, #20
1000d02dc:     	and	x20, x20, #0xf0
1000d02e0:     	orr	x24, x20, x24
1000d02e4:     	ldrb	w24, [x11, x24]
1000d02e8:     	add	w22, w22, w23
1000d02ec:     	add	w22, w22, w24
1000d02f0:     	lsr	x21, x21, #24
1000d02f4:     	and	x21, x21, #0xf0
1000d02f8:     	ldr	x23, [sp, #112]
1000d02fc:     	orr	x23, x21, x23
1000d0300:     	ldrb	w23, [x11, x23]
1000d0304:     	add	w22, w22, w23
1000d0308:     	scvtf	s0, w22
1000d030c:     	ldp	x23, x22, [sp, #96]
1000d0310:     	orr	x22, x2, x22
1000d0314:     	ldrb	w22, [x11, x22]
1000d0318:     	orr	x23, x4, x23
1000d031c:     	ldrb	w23, [x11, x23]
1000d0320:     	ldr	x24, [sp, #88]
1000d0324:     	orr	x24, x5, x24
1000d0328:     	ldrb	w24, [x11, x24]
1000d032c:     	add	w22, w22, w23
1000d0330:     	add	w22, w22, w24
1000d0334:     	ldp	x24, x23, [sp, #72]
1000d0338:     	orr	x23, x6, x23
1000d033c:     	ldrb	w23, [x11, x23]
1000d0340:     	orr	x24, x7, x24
1000d0344:     	ldrb	w24, [x11, x24]
1000d0348:     	ldr	x25, [sp, #64]
1000d034c:     	orr	x25, x19, x25
1000d0350:     	ldrb	w25, [x11, x25]
1000d0354:     	add	w22, w22, w23
1000d0358:     	add	w22, w22, w24
1000d035c:     	ldr	x23, [sp, #56]
1000d0360:     	orr	x23, x20, x23
1000d0364:     	ldrb	w23, [x11, x23]
1000d0368:     	add	w22, w22, w25
1000d036c:     	add	w22, w22, w23
1000d0370:     	ldr	x23, [sp, #48]
1000d0374:     	orr	x23, x21, x23
1000d0378:     	ldrb	w23, [x11, x23]
1000d037c:     	add	w22, w22, w23
1000d0380:     	scvtf	s1, w22
1000d0384:     	ldp	x23, x22, [sp, #32]
1000d0388:     	orr	x22, x2, x22
1000d038c:     	ldrb	w22, [x11, x22]
1000d0390:     	orr	x23, x4, x23
1000d0394:     	ldrb	w23, [x11, x23]
1000d0398:     	ldr	x24, [sp, #24]
1000d039c:     	orr	x24, x5, x24
1000d03a0:     	ldrb	w24, [x11, x24]
1000d03a4:     	add	w22, w22, w23
1000d03a8:     	add	w22, w22, w24
1000d03ac:     	orr	x23, x6, x28
1000d03b0:     	ldrb	w23, [x11, x23]
1000d03b4:     	orr	x24, x7, x30
1000d03b8:     	ldrb	w24, [x11, x24]
1000d03bc:     	orr	x25, x19, x3
1000d03c0:     	ldrb	w25, [x11, x25]
1000d03c4:     	add	w22, w22, w23
1000d03c8:     	orr	x23, x20, x8
1000d03cc:     	ldrb	w23, [x11, x23]
1000d03d0:     	add	w22, w22, w24
1000d03d4:     	add	w22, w22, w25
1000d03d8:     	add	w22, w22, w23
1000d03dc:     	orr	x23, x21, x9
1000d03e0:     	ldrb	w23, [x11, x23]
1000d03e4:     	add	w22, w22, w23
1000d03e8:     	scvtf	s2, w22
1000d03ec:     	orr	x2, x2, x1
1000d03f0:     	ldrb	w2, [x11, x2]
1000d03f4:     	orr	x4, x4, x10
1000d03f8:     	ldrb	w4, [x11, x4]
1000d03fc:     	orr	x5, x5, x13
1000d0400:     	ldrb	w5, [x11, x5]
1000d0404:     	add	w2, w2, w4
1000d0408:     	add	w2, w2, w5
1000d040c:     	orr	x4, x6, x26
1000d0410:     	ldrb	w4, [x11, x4]
1000d0414:     	orr	x5, x7, x14
1000d0418:     	ldrb	w5, [x11, x5]
1000d041c:     	add	w2, w2, w4
1000d0420:     	orr	x4, x19, x15
1000d0424:     	ldrb	w4, [x11, x4]
1000d0428:     	add	w2, w2, w5
1000d042c:     	orr	x5, x20, x16
1000d0430:     	ldrb	w5, [x11, x5]
1000d0434:     	add	w2, w2, w4
1000d0438:     	add	w2, w2, w5
1000d043c:     	orr	x4, x21, x17
1000d0440:     	ldrb	w4, [x11, x4]
1000d0444:     	add	w2, w2, w4
1000d0448:     	add	x4, sp, #176
1000d044c:     	scvtf	s3, w2
1000d0450:     	add	x2, x27, x12
1000d0454:     	ldur	s4, [x2, #-128]
1000d0458:     	fadd	s1, s4, s1
1000d045c:     	stur	s1, [x2, #-128]
1000d0460:     	ldr	s1, [x2]
1000d0464:     	fadd	s1, s1, s2
1000d0468:     	str	s1, [x2]
1000d046c:     	ldr	s1, [x2, #128]
1000d0470:     	fadd	s1, s1, s3
1000d0474:     	ldr	s2, [x4, x12]
1000d0478:     	str	s1, [x2, #128]
1000d047c:     	fadd	s0, s2, s0
1000d0480:     	str	s0, [x4, x12]
1000d0484:     	add	x12, x12, #4
1000d0488:     	cmp	x12, #128
1000d048c:     	b.ne	0x1000d0258 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x15c>
1000d0490:     	add	x0, x0, #128
1000d0494:     	ldp	x8, x1, [sp, #8]
1000d0498:     	add	x1, x1, #16
1000d049c:     	cmp	x1, x8
1000d04a0:     	b.ne	0x1000d0198 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d04a4:     	add	x1, sp, #176
1000d04a8:     	ldr	x0, [sp]
1000d04ac:     	mov	w2, #512
1000d04b0:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d04b4:     	ldur	x8, [x29, #-96]
1000d04b8:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf8>
1000d04bc:     	ldr	x9, [x9, #392]
1000d04c0:     	ldr	x9, [x9]
1000d04c4:     	cmp	x9, x8
1000d04c8:     	b.ne	0x1000d04ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3f0>
1000d04cc:     	add	sp, sp, #704
1000d04d0:     	ldp	x29, x30, [sp, #80]
1000d04d4:     	ldp	x20, x19, [sp, #64]
1000d04d8:     	ldp	x22, x21, [sp, #48]
1000d04dc:     	ldp	x24, x23, [sp, #32]
1000d04e0:     	ldp	x26, x25, [sp, #16]
1000d04e4:     	ldp	x28, x27, [sp], #96
1000d04e8:     	ret
1000d04ec:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d0620 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d0620:     	stp	x28, x27, [sp, #-96]!
1000d0624:     	stp	x26, x25, [sp, #16]
1000d0628:     	stp	x24, x23, [sp, #32]
1000d062c:     	stp	x22, x21, [sp, #48]
1000d0630:     	stp	x20, x19, [sp, #64]
1000d0634:     	stp	x29, x30, [sp, #80]
1000d0638:     	add	x29, sp, #80
1000d063c:     	sub	sp, sp, #704
1000d0640:     	str	x3, [sp]
1000d0644:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x284>
1000d0648:     	ldr	x8, [x8, #392]
1000d064c:     	ldr	x8, [x8]
1000d0650:     	stur	x8, [x29, #-96]
1000d0654:     	movi.2d	v0, #0000000000000000
1000d0658:     	stp	q0, q0, [sp, #656]
1000d065c:     	lsl	x8, x2, #1
1000d0660:     	stp	q0, q0, [sp, #624]
1000d0664:     	stp	q0, q0, [sp, #592]
1000d0668:     	stp	q0, q0, [sp, #560]
1000d066c:     	stp	q0, q0, [sp, #528]
1000d0670:     	stp	q0, q0, [sp, #496]
1000d0674:     	stp	q0, q0, [sp, #464]
1000d0678:     	stp	q0, q0, [sp, #432]
1000d067c:     	stp	q0, q0, [sp, #400]
1000d0680:     	stp	q0, q0, [sp, #368]
1000d0684:     	stp	q0, q0, [sp, #336]
1000d0688:     	stp	q0, q0, [sp, #304]
1000d068c:     	stp	q0, q0, [sp, #272]
1000d0690:     	stp	q0, q0, [sp, #240]
1000d0694:     	stp	q0, q0, [sp, #208]
1000d0698:     	stp	q0, q0, [sp, #176]
1000d069c:     	ands	x8, x8, #0xfffffffffffffffc
1000d06a0:     	b.eq	0x1000d09c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a8>
1000d06a4:     	add	x8, x1, x8
1000d06a8:     	str	x8, [sp, #8]
1000d06ac:     	add	x8, sp, #176
1000d06b0:     	add	x27, x8, #256
1000d06b4:     	adrp	x11, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ec>
1000d06b8:     	add	x11, x11, #2012
1000d06bc:     	mov	x12, #0
1000d06c0:     	ldp	w8, w9, [x1]
1000d06c4:     	ubfx	x10, x8, #4, #4
1000d06c8:     	str	x10, [sp, #168]
1000d06cc:     	ubfx	x10, x8, #8, #4
1000d06d0:     	str	x10, [sp, #160]
1000d06d4:     	and	x10, x8, #0xf
1000d06d8:     	str	x10, [sp, #152]
1000d06dc:     	ubfx	x10, x8, #12, #4
1000d06e0:     	str	x10, [sp, #144]
1000d06e4:     	ubfx	x10, x8, #16, #4
1000d06e8:     	str	x10, [sp, #136]
1000d06ec:     	ubfx	x10, x8, #20, #4
1000d06f0:     	str	x10, [sp, #128]
1000d06f4:     	ubfx	x10, x8, #24, #4
1000d06f8:     	lsr	x8, x8, #28
1000d06fc:     	stp	x8, x10, [sp, #112]
1000d0700:     	and	x10, x9, #0xf
1000d0704:     	ubfx	x8, x9, #4, #4
1000d0708:     	stp	x8, x10, [sp, #96]
1000d070c:     	ubfx	x10, x9, #8, #4
1000d0710:     	ubfx	x8, x9, #12, #4
1000d0714:     	stp	x8, x10, [sp, #80]
1000d0718:     	ubfx	x10, x9, #16, #4
1000d071c:     	ubfx	x8, x9, #20, #4
1000d0720:     	stp	x8, x10, [sp, #64]
1000d0724:     	ubfx	x10, x9, #24, #4
1000d0728:     	lsr	x8, x9, #28
1000d072c:     	stp	x8, x10, [sp, #48]
1000d0730:     	ldp	w9, w17, [x1, #8]
1000d0734:     	and	x10, x9, #0xf
1000d0738:     	ubfx	x8, x9, #4, #4
1000d073c:     	stp	x8, x10, [sp, #32]
1000d0740:     	ubfx	x8, x9, #8, #4
1000d0744:     	stp	x1, x8, [sp, #16]
1000d0748:     	ubfx	x28, x9, #12, #4
1000d074c:     	ubfx	x30, x9, #16, #4
1000d0750:     	ubfx	x3, x9, #20, #4
1000d0754:     	ubfx	x8, x9, #24, #4
1000d0758:     	lsr	x9, x9, #28
1000d075c:     	and	x1, x17, #0xf
1000d0760:     	ubfx	x10, x17, #4, #4
1000d0764:     	ubfx	x13, x17, #8, #4
1000d0768:     	ubfx	x26, x17, #12, #4
1000d076c:     	ubfx	x14, x17, #16, #4
1000d0770:     	ubfx	x15, x17, #20, #4
1000d0774:     	ubfx	x16, x17, #24, #4
1000d0778:     	lsr	x17, x17, #28
1000d077c:     	ldr	w21, [x0, x12]
1000d0780:     	lsl	w2, w21, #4
1000d0784:     	and	x2, x2, #0xf0
1000d0788:     	ldp	x4, x19, [sp, #152]
1000d078c:     	orr	x4, x2, x4
1000d0790:     	ldrsb	w6, [x11, x4]
1000d0794:     	and	x4, x21, #0xf0
1000d0798:     	ldr	x5, [sp, #168]
1000d079c:     	orr	x5, x4, x5
1000d07a0:     	ldrsb	w7, [x11, x5]
1000d07a4:     	lsr	x5, x21, #4
1000d07a8:     	and	x5, x5, #0xf0
1000d07ac:     	orr	x19, x5, x19
1000d07b0:     	ldrsb	w19, [x11, x19]
1000d07b4:     	add	w6, w6, w7
1000d07b8:     	add	w19, w6, w19
1000d07bc:     	lsr	x6, x21, #8
1000d07c0:     	and	x6, x6, #0xf0
1000d07c4:     	ldp	x22, x7, [sp, #136]
1000d07c8:     	orr	x7, x6, x7
1000d07cc:     	ldrsb	w20, [x11, x7]
1000d07d0:     	lsr	x7, x21, #12
1000d07d4:     	and	x7, x7, #0xf0
1000d07d8:     	orr	x22, x7, x22
1000d07dc:     	ldrsb	w22, [x11, x22]
1000d07e0:     	add	w19, w19, w20
1000d07e4:     	add	w22, w19, w22
1000d07e8:     	lsr	x19, x21, #16
1000d07ec:     	and	x19, x19, #0xf0
1000d07f0:     	ldp	x24, x20, [sp, #120]
1000d07f4:     	orr	x20, x19, x20
1000d07f8:     	ldrsb	w23, [x11, x20]
1000d07fc:     	lsr	x20, x21, #20
1000d0800:     	and	x20, x20, #0xf0
1000d0804:     	orr	x24, x20, x24
1000d0808:     	ldrsb	w24, [x11, x24]
1000d080c:     	add	w22, w22, w23
1000d0810:     	add	w22, w22, w24
1000d0814:     	lsr	x21, x21, #24
1000d0818:     	and	x21, x21, #0xf0
1000d081c:     	ldr	x23, [sp, #112]
1000d0820:     	orr	x23, x21, x23
1000d0824:     	ldrsb	w23, [x11, x23]
1000d0828:     	add	w22, w22, w23
1000d082c:     	scvtf	s0, w22
1000d0830:     	ldp	x23, x22, [sp, #96]
1000d0834:     	orr	x22, x2, x22
1000d0838:     	ldrsb	w22, [x11, x22]
1000d083c:     	orr	x23, x4, x23
1000d0840:     	ldrsb	w23, [x11, x23]
1000d0844:     	ldr	x24, [sp, #88]
1000d0848:     	orr	x24, x5, x24
1000d084c:     	ldrsb	w24, [x11, x24]
1000d0850:     	add	w22, w22, w23
1000d0854:     	add	w22, w22, w24
1000d0858:     	ldp	x24, x23, [sp, #72]
1000d085c:     	orr	x23, x6, x23
1000d0860:     	ldrsb	w23, [x11, x23]
1000d0864:     	orr	x24, x7, x24
1000d0868:     	ldrsb	w24, [x11, x24]
1000d086c:     	ldr	x25, [sp, #64]
1000d0870:     	orr	x25, x19, x25
1000d0874:     	ldrsb	w25, [x11, x25]
1000d0878:     	add	w22, w22, w23
1000d087c:     	add	w22, w22, w24
1000d0880:     	ldr	x23, [sp, #56]
1000d0884:     	orr	x23, x20, x23
1000d0888:     	ldrsb	w23, [x11, x23]
1000d088c:     	add	w22, w22, w25
1000d0890:     	add	w22, w22, w23
1000d0894:     	ldr	x23, [sp, #48]
1000d0898:     	orr	x23, x21, x23
1000d089c:     	ldrsb	w23, [x11, x23]
1000d08a0:     	add	w22, w22, w23
1000d08a4:     	scvtf	s1, w22
1000d08a8:     	ldp	x23, x22, [sp, #32]
1000d08ac:     	orr	x22, x2, x22
1000d08b0:     	ldrsb	w22, [x11, x22]
1000d08b4:     	orr	x23, x4, x23
1000d08b8:     	ldrsb	w23, [x11, x23]
1000d08bc:     	ldr	x24, [sp, #24]
1000d08c0:     	orr	x24, x5, x24
1000d08c4:     	ldrsb	w24, [x11, x24]
1000d08c8:     	add	w22, w22, w23
1000d08cc:     	add	w22, w22, w24
1000d08d0:     	orr	x23, x6, x28
1000d08d4:     	ldrsb	w23, [x11, x23]
1000d08d8:     	orr	x24, x7, x30
1000d08dc:     	ldrsb	w24, [x11, x24]
1000d08e0:     	orr	x25, x19, x3
1000d08e4:     	ldrsb	w25, [x11, x25]
1000d08e8:     	add	w22, w22, w23
1000d08ec:     	orr	x23, x20, x8
1000d08f0:     	ldrsb	w23, [x11, x23]
1000d08f4:     	add	w22, w22, w24
1000d08f8:     	add	w22, w22, w25
1000d08fc:     	add	w22, w22, w23
1000d0900:     	orr	x23, x21, x9
1000d0904:     	ldrsb	w23, [x11, x23]
1000d0908:     	add	w22, w22, w23
1000d090c:     	scvtf	s2, w22
1000d0910:     	orr	x2, x2, x1
1000d0914:     	ldrsb	w2, [x11, x2]
1000d0918:     	orr	x4, x4, x10
1000d091c:     	ldrsb	w4, [x11, x4]
1000d0920:     	orr	x5, x5, x13
1000d0924:     	ldrsb	w5, [x11, x5]
1000d0928:     	add	w2, w2, w4
1000d092c:     	add	w2, w2, w5
1000d0930:     	orr	x4, x6, x26
1000d0934:     	ldrsb	w4, [x11, x4]
1000d0938:     	orr	x5, x7, x14
1000d093c:     	ldrsb	w5, [x11, x5]
1000d0940:     	add	w2, w2, w4
1000d0944:     	orr	x4, x19, x15
1000d0948:     	ldrsb	w4, [x11, x4]
1000d094c:     	add	w2, w2, w5
1000d0950:     	orr	x5, x20, x16
1000d0954:     	ldrsb	w5, [x11, x5]
1000d0958:     	add	w2, w2, w4
1000d095c:     	add	w2, w2, w5
1000d0960:     	orr	x4, x21, x17
1000d0964:     	ldrsb	w4, [x11, x4]
1000d0968:     	add	w2, w2, w4
1000d096c:     	add	x4, sp, #176
1000d0970:     	scvtf	s3, w2
1000d0974:     	add	x2, x27, x12
1000d0978:     	ldur	s4, [x2, #-128]
1000d097c:     	fadd	s1, s4, s1
1000d0980:     	stur	s1, [x2, #-128]
1000d0984:     	ldr	s1, [x2]
1000d0988:     	fadd	s1, s1, s2
1000d098c:     	str	s1, [x2]
1000d0990:     	ldr	s1, [x2, #128]
1000d0994:     	fadd	s1, s1, s3
1000d0998:     	ldr	s2, [x4, x12]
1000d099c:     	str	s1, [x2, #128]
1000d09a0:     	fadd	s0, s2, s0
1000d09a4:     	str	s0, [x4, x12]
1000d09a8:     	add	x12, x12, #4
1000d09ac:     	cmp	x12, #128
1000d09b0:     	b.ne	0x1000d077c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x15c>
1000d09b4:     	add	x0, x0, #128
1000d09b8:     	ldp	x8, x1, [sp, #8]
1000d09bc:     	add	x1, x1, #16
1000d09c0:     	cmp	x1, x8
1000d09c4:     	b.ne	0x1000d06bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d09c8:     	add	x1, sp, #176
1000d09cc:     	ldr	x0, [sp]
1000d09d0:     	mov	w2, #512
1000d09d4:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d09d8:     	ldur	x8, [x29, #-96]
1000d09dc:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 8ul, false>(char const*)+0x228>
1000d09e0:     	ldr	x9, [x9, #392]
1000d09e4:     	ldr	x9, [x9]
1000d09e8:     	cmp	x9, x8
1000d09ec:     	b.ne	0x1000d0a10 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3f0>
1000d09f0:     	add	sp, sp, #704
1000d09f4:     	ldp	x29, x30, [sp, #80]
1000d09f8:     	ldp	x20, x19, [sp, #64]
1000d09fc:     	ldp	x22, x21, [sp, #48]
1000d0a00:     	ldp	x24, x23, [sp, #32]
1000d0a04:     	ldp	x26, x25, [sp, #16]
1000d0a08:     	ldp	x28, x27, [sp], #96
1000d0a0c:     	ret
1000d0a10:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d2674 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d2674:     	stp	x28, x27, [sp, #-64]!
1000d2678:     	stp	x22, x21, [sp, #16]
1000d267c:     	stp	x20, x19, [sp, #32]
1000d2680:     	stp	x29, x30, [sp, #48]
1000d2684:     	add	x29, sp, #48
1000d2688:     	sub	sp, sp, #1040
1000d268c:     	mov	x19, x3
1000d2690:     	mov	x20, x1
1000d2694:     	mov	x21, x0
1000d2698:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd4>
1000d269c:     	ldr	x8, [x8, #392]
1000d26a0:     	ldr	x8, [x8]
1000d26a4:     	stur	x8, [x29, #-56]
1000d26a8:     	lsl	x8, x2, #2
1000d26ac:     	and	x22, x8, #0xfffffffffffffff8
1000d26b0:     	add	x0, sp, #8
1000d26b4:     	mov	w1, #1024
1000d26b8:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d26bc:     	cbz	x22, 0x1000d27d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d26c0:     	add	x8, x20, x22
1000d26c4:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf8>
1000d26c8:     	add	x9, x9, #1756
1000d26cc:     	mov	x10, #0
1000d26d0:     	add	x11, sp, #8
1000d26d4:     	mov	x12, #0
1000d26d8:     	ldr	w2, [x21, x10, lsl #2]
1000d26dc:     	lsl	w13, w2, #4
1000d26e0:     	and	x13, x13, #0xf0
1000d26e4:     	and	x14, x2, #0xf0
1000d26e8:     	lsr	x15, x2, #4
1000d26ec:     	and	x15, x15, #0xf0
1000d26f0:     	lsr	x16, x2, #8
1000d26f4:     	and	x16, x16, #0xf0
1000d26f8:     	lsr	x17, x2, #12
1000d26fc:     	and	x17, x17, #0xf0
1000d2700:     	lsr	x0, x2, #16
1000d2704:     	and	x0, x0, #0xf0
1000d2708:     	lsr	x1, x2, #20
1000d270c:     	and	x1, x1, #0xf0
1000d2710:     	lsr	x2, x2, #24
1000d2714:     	and	x2, x2, #0xf0
1000d2718:     	mov	x3, x11
1000d271c:     	ldr	w4, [x20, x12]
1000d2720:     	and	x5, x4, #0xf
1000d2724:     	orr	x5, x13, x5
1000d2728:     	ldrb	w5, [x9, x5]
1000d272c:     	ubfx	x6, x4, #4, #4
1000d2730:     	orr	x6, x14, x6
1000d2734:     	ldrb	w6, [x9, x6]
1000d2738:     	ubfx	x7, x4, #8, #4
1000d273c:     	orr	x7, x15, x7
1000d2740:     	ldrb	w7, [x9, x7]
1000d2744:     	add	w5, w5, w6
1000d2748:     	add	w5, w5, w7
1000d274c:     	ubfx	x6, x4, #12, #4
1000d2750:     	orr	x6, x16, x6
1000d2754:     	ldrb	w6, [x9, x6]
1000d2758:     	ubfx	x7, x4, #16, #4
1000d275c:     	orr	x7, x17, x7
1000d2760:     	ldrb	w7, [x9, x7]
1000d2764:     	add	w5, w5, w6
1000d2768:     	add	w5, w5, w7
1000d276c:     	ubfx	x6, x4, #20, #4
1000d2770:     	orr	x6, x0, x6
1000d2774:     	ldrb	w6, [x9, x6]
1000d2778:     	ubfx	x7, x4, #24, #4
1000d277c:     	orr	x7, x1, x7
1000d2780:     	ldrb	w7, [x9, x7]
1000d2784:     	add	w5, w5, w6
1000d2788:     	add	w5, w5, w7
1000d278c:     	orr	x4, x2, x4, lsr #28
1000d2790:     	ldrb	w4, [x9, x4]
1000d2794:     	add	w4, w5, w4
1000d2798:     	scvtf	s0, w4
1000d279c:     	ldr	s1, [x3]
1000d27a0:     	fadd	s0, s1, s0
1000d27a4:     	str	s0, [x3], #128
1000d27a8:     	add	x12, x12, #4
1000d27ac:     	cmp	x12, #32
1000d27b0:     	b.ne	0x1000d271c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d27b4:     	add	x10, x10, #1
1000d27b8:     	add	x11, x11, #4
1000d27bc:     	cmp	x10, #32
1000d27c0:     	b.ne	0x1000d26d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d27c4:     	add	x21, x21, #128
1000d27c8:     	add	x20, x20, #32
1000d27cc:     	cmp	x20, x8
1000d27d0:     	b.ne	0x1000d26cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d27d4:     	add	x1, sp, #8
1000d27d8:     	mov	x0, x19
1000d27dc:     	mov	w2, #1024
1000d27e0:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d27e4:     	ldur	x8, [x29, #-56]
1000d27e8:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb4>
1000d27ec:     	ldr	x9, [x9, #392]
1000d27f0:     	ldr	x9, [x9]
1000d27f4:     	cmp	x9, x8
1000d27f8:     	b.ne	0x1000d2814 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d27fc:     	add	sp, sp, #1040
1000d2800:     	ldp	x29, x30, [sp, #48]
1000d2804:     	ldp	x20, x19, [sp, #32]
1000d2808:     	ldp	x22, x21, [sp, #16]
1000d280c:     	ldp	x28, x27, [sp], #64
1000d2810:     	ret
1000d2814:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d298c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d298c:     	stp	x28, x27, [sp, #-64]!
1000d2990:     	stp	x22, x21, [sp, #16]
1000d2994:     	stp	x20, x19, [sp, #32]
1000d2998:     	stp	x29, x30, [sp, #48]
1000d299c:     	add	x29, sp, #48
1000d29a0:     	sub	sp, sp, #1040
1000d29a4:     	mov	x19, x3
1000d29a8:     	mov	x20, x1
1000d29ac:     	mov	x21, x0
1000d29b0:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0xd8>
1000d29b4:     	ldr	x8, [x8, #392]
1000d29b8:     	ldr	x8, [x8]
1000d29bc:     	stur	x8, [x29, #-56]
1000d29c0:     	lsl	x8, x2, #2
1000d29c4:     	and	x22, x8, #0xfffffffffffffff8
1000d29c8:     	add	x0, sp, #8
1000d29cc:     	mov	w1, #1024
1000d29d0:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d29d4:     	cbz	x22, 0x1000d2aec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d29d8:     	add	x8, x20, x22
1000d29dc:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0xfc>
1000d29e0:     	add	x9, x9, #2012
1000d29e4:     	mov	x10, #0
1000d29e8:     	add	x11, sp, #8
1000d29ec:     	mov	x12, #0
1000d29f0:     	ldr	w2, [x21, x10, lsl #2]
1000d29f4:     	lsl	w13, w2, #4
1000d29f8:     	and	x13, x13, #0xf0
1000d29fc:     	and	x14, x2, #0xf0
1000d2a00:     	lsr	x15, x2, #4
1000d2a04:     	and	x15, x15, #0xf0
1000d2a08:     	lsr	x16, x2, #8
1000d2a0c:     	and	x16, x16, #0xf0
1000d2a10:     	lsr	x17, x2, #12
1000d2a14:     	and	x17, x17, #0xf0
1000d2a18:     	lsr	x0, x2, #16
1000d2a1c:     	and	x0, x0, #0xf0
1000d2a20:     	lsr	x1, x2, #20
1000d2a24:     	and	x1, x1, #0xf0
1000d2a28:     	lsr	x2, x2, #24
1000d2a2c:     	and	x2, x2, #0xf0
1000d2a30:     	mov	x3, x11
1000d2a34:     	ldr	w4, [x20, x12]
1000d2a38:     	and	x5, x4, #0xf
1000d2a3c:     	orr	x5, x13, x5
1000d2a40:     	ldrsb	w5, [x9, x5]
1000d2a44:     	ubfx	x6, x4, #4, #4
1000d2a48:     	orr	x6, x14, x6
1000d2a4c:     	ldrsb	w6, [x9, x6]
1000d2a50:     	ubfx	x7, x4, #8, #4
1000d2a54:     	orr	x7, x15, x7
1000d2a58:     	ldrsb	w7, [x9, x7]
1000d2a5c:     	add	w5, w5, w6
1000d2a60:     	add	w5, w5, w7
1000d2a64:     	ubfx	x6, x4, #12, #4
1000d2a68:     	orr	x6, x16, x6
1000d2a6c:     	ldrsb	w6, [x9, x6]
1000d2a70:     	ubfx	x7, x4, #16, #4
1000d2a74:     	orr	x7, x17, x7
1000d2a78:     	ldrsb	w7, [x9, x7]
1000d2a7c:     	add	w5, w5, w6
1000d2a80:     	add	w5, w5, w7
1000d2a84:     	ubfx	x6, x4, #20, #4
1000d2a88:     	orr	x6, x0, x6
1000d2a8c:     	ldrsb	w6, [x9, x6]
1000d2a90:     	ubfx	x7, x4, #24, #4
1000d2a94:     	orr	x7, x1, x7
1000d2a98:     	ldrsb	w7, [x9, x7]
1000d2a9c:     	add	w5, w5, w6
1000d2aa0:     	add	w5, w5, w7
1000d2aa4:     	orr	x4, x2, x4, lsr #28
1000d2aa8:     	ldrsb	w4, [x9, x4]
1000d2aac:     	add	w4, w5, w4
1000d2ab0:     	scvtf	s0, w4
1000d2ab4:     	ldr	s1, [x3]
1000d2ab8:     	fadd	s0, s1, s0
1000d2abc:     	str	s0, [x3], #128
1000d2ac0:     	add	x12, x12, #4
1000d2ac4:     	cmp	x12, #32
1000d2ac8:     	b.ne	0x1000d2a34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d2acc:     	add	x10, x10, #1
1000d2ad0:     	add	x11, x11, #4
1000d2ad4:     	cmp	x10, #32
1000d2ad8:     	b.ne	0x1000d29ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d2adc:     	add	x21, x21, #128
1000d2ae0:     	add	x20, x20, #32
1000d2ae4:     	cmp	x20, x8
1000d2ae8:     	b.ne	0x1000d29e4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d2aec:     	add	x1, sp, #8
1000d2af0:     	mov	x0, x19
1000d2af4:     	mov	w2, #1024
1000d2af8:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d2afc:     	ldur	x8, [x29, #-56]
1000d2b00:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0x228>
1000d2b04:     	ldr	x9, [x9, #392]
1000d2b08:     	ldr	x9, [x9]
1000d2b0c:     	cmp	x9, x8
1000d2b10:     	b.ne	0x1000d2b2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d2b14:     	add	sp, sp, #1040
1000d2b18:     	ldp	x29, x30, [sp, #48]
1000d2b1c:     	ldp	x20, x19, [sp, #32]
1000d2b20:     	ldp	x22, x21, [sp, #16]
1000d2b24:     	ldp	x28, x27, [sp], #64
1000d2b28:     	ret
1000d2b2c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d41bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d41bc:     	stp	x28, x27, [sp, #-64]!
1000d41c0:     	stp	x22, x21, [sp, #16]
1000d41c4:     	stp	x20, x19, [sp, #32]
1000d41c8:     	stp	x29, x30, [sp, #48]
1000d41cc:     	add	x29, sp, #48
1000d41d0:     	sub	sp, sp, #2064
1000d41d4:     	mov	x19, x3
1000d41d8:     	mov	x20, x1
1000d41dc:     	mov	x21, x0
1000d41e0:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xcc>
1000d41e4:     	ldr	x8, [x8, #392]
1000d41e8:     	ldr	x8, [x8]
1000d41ec:     	stur	x8, [x29, #-56]
1000d41f0:     	lsl	x8, x2, #3
1000d41f4:     	and	x22, x8, #0xfffffffffffffff0
1000d41f8:     	add	x0, sp, #8
1000d41fc:     	mov	w1, #2048
1000d4200:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d4204:     	cbz	x22, 0x1000d431c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d4208:     	add	x8, x20, x22
1000d420c:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf0>
1000d4210:     	add	x9, x9, #1756
1000d4214:     	mov	x10, #0
1000d4218:     	add	x11, sp, #8
1000d421c:     	mov	x12, #0
1000d4220:     	ldr	w2, [x21, x10, lsl #2]
1000d4224:     	lsl	w13, w2, #4
1000d4228:     	and	x13, x13, #0xf0
1000d422c:     	and	x14, x2, #0xf0
1000d4230:     	lsr	x15, x2, #4
1000d4234:     	and	x15, x15, #0xf0
1000d4238:     	lsr	x16, x2, #8
1000d423c:     	and	x16, x16, #0xf0
1000d4240:     	lsr	x17, x2, #12
1000d4244:     	and	x17, x17, #0xf0
1000d4248:     	lsr	x0, x2, #16
1000d424c:     	and	x0, x0, #0xf0
1000d4250:     	lsr	x1, x2, #20
1000d4254:     	and	x1, x1, #0xf0
1000d4258:     	lsr	x2, x2, #24
1000d425c:     	and	x2, x2, #0xf0
1000d4260:     	mov	x3, x11
1000d4264:     	ldr	w4, [x20, x12]
1000d4268:     	and	x5, x4, #0xf
1000d426c:     	orr	x5, x13, x5
1000d4270:     	ldrb	w5, [x9, x5]
1000d4274:     	ubfx	x6, x4, #4, #4
1000d4278:     	orr	x6, x14, x6
1000d427c:     	ldrb	w6, [x9, x6]
1000d4280:     	ubfx	x7, x4, #8, #4
1000d4284:     	orr	x7, x15, x7
1000d4288:     	ldrb	w7, [x9, x7]
1000d428c:     	add	w5, w5, w6
1000d4290:     	add	w5, w5, w7
1000d4294:     	ubfx	x6, x4, #12, #4
1000d4298:     	orr	x6, x16, x6
1000d429c:     	ldrb	w6, [x9, x6]
1000d42a0:     	ubfx	x7, x4, #16, #4
1000d42a4:     	orr	x7, x17, x7
1000d42a8:     	ldrb	w7, [x9, x7]
1000d42ac:     	add	w5, w5, w6
1000d42b0:     	add	w5, w5, w7
1000d42b4:     	ubfx	x6, x4, #20, #4
1000d42b8:     	orr	x6, x0, x6
1000d42bc:     	ldrb	w6, [x9, x6]
1000d42c0:     	ubfx	x7, x4, #24, #4
1000d42c4:     	orr	x7, x1, x7
1000d42c8:     	ldrb	w7, [x9, x7]
1000d42cc:     	add	w5, w5, w6
1000d42d0:     	add	w5, w5, w7
1000d42d4:     	orr	x4, x2, x4, lsr #28
1000d42d8:     	ldrb	w4, [x9, x4]
1000d42dc:     	add	w4, w5, w4
1000d42e0:     	scvtf	s0, w4
1000d42e4:     	ldr	s1, [x3]
1000d42e8:     	fadd	s0, s1, s0
1000d42ec:     	str	s0, [x3], #128
1000d42f0:     	add	x12, x12, #4
1000d42f4:     	cmp	x12, #64
1000d42f8:     	b.ne	0x1000d4264 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d42fc:     	add	x10, x10, #1
1000d4300:     	add	x11, x11, #4
1000d4304:     	cmp	x10, #32
1000d4308:     	b.ne	0x1000d421c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d430c:     	add	x21, x21, #128
1000d4310:     	add	x20, x20, #64
1000d4314:     	cmp	x20, x8
1000d4318:     	b.ne	0x1000d4214 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d431c:     	add	x1, sp, #8
1000d4320:     	mov	x0, x19
1000d4324:     	mov	w2, #2048
1000d4328:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d432c:     	ldur	x8, [x29, #-56]
1000d4330:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x21c>
1000d4334:     	ldr	x9, [x9, #392]
1000d4338:     	ldr	x9, [x9]
1000d433c:     	cmp	x9, x8
1000d4340:     	b.ne	0x1000d435c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d4344:     	add	sp, sp, #2064
1000d4348:     	ldp	x29, x30, [sp, #48]
1000d434c:     	ldp	x20, x19, [sp, #32]
1000d4350:     	ldp	x22, x21, [sp, #16]
1000d4354:     	ldp	x28, x27, [sp], #64
1000d4358:     	ret
1000d435c:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d45d4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d45d4:     	stp	x28, x27, [sp, #-64]!
1000d45d8:     	stp	x22, x21, [sp, #16]
1000d45dc:     	stp	x20, x19, [sp, #32]
1000d45e0:     	stp	x29, x30, [sp, #48]
1000d45e4:     	add	x29, sp, #48
1000d45e8:     	sub	sp, sp, #2064
1000d45ec:     	mov	x19, x3
1000d45f0:     	mov	x20, x1
1000d45f4:     	mov	x21, x0
1000d45f8:     	adrp	x8, 0x100168000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xd0>
1000d45fc:     	ldr	x8, [x8, #392]
1000d4600:     	ldr	x8, [x8]
1000d4604:     	stur	x8, [x29, #-56]
1000d4608:     	lsl	x8, x2, #3
1000d460c:     	and	x22, x8, #0xfffffffffffffff0
1000d4610:     	add	x0, sp, #8
1000d4614:     	mov	w1, #2048
1000d4618:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d461c:     	cbz	x22, 0x1000d4734 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d4620:     	add	x8, x20, x22
1000d4624:     	adrp	x9, 0x100166000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xf4>
1000d4628:     	add	x9, x9, #2012
1000d462c:     	mov	x10, #0
1000d4630:     	add	x11, sp, #8
1000d4634:     	mov	x12, #0
1000d4638:     	ldr	w2, [x21, x10, lsl #2]
1000d463c:     	lsl	w13, w2, #4
1000d4640:     	and	x13, x13, #0xf0
1000d4644:     	and	x14, x2, #0xf0
1000d4648:     	lsr	x15, x2, #4
1000d464c:     	and	x15, x15, #0xf0
1000d4650:     	lsr	x16, x2, #8
1000d4654:     	and	x16, x16, #0xf0
1000d4658:     	lsr	x17, x2, #12
1000d465c:     	and	x17, x17, #0xf0
1000d4660:     	lsr	x0, x2, #16
1000d4664:     	and	x0, x0, #0xf0
1000d4668:     	lsr	x1, x2, #20
1000d466c:     	and	x1, x1, #0xf0
1000d4670:     	lsr	x2, x2, #24
1000d4674:     	and	x2, x2, #0xf0
1000d4678:     	mov	x3, x11
1000d467c:     	ldr	w4, [x20, x12]
1000d4680:     	and	x5, x4, #0xf
1000d4684:     	orr	x5, x13, x5
1000d4688:     	ldrsb	w5, [x9, x5]
1000d468c:     	ubfx	x6, x4, #4, #4
1000d4690:     	orr	x6, x14, x6
1000d4694:     	ldrsb	w6, [x9, x6]
1000d4698:     	ubfx	x7, x4, #8, #4
1000d469c:     	orr	x7, x15, x7
1000d46a0:     	ldrsb	w7, [x9, x7]
1000d46a4:     	add	w5, w5, w6
1000d46a8:     	add	w5, w5, w7
1000d46ac:     	ubfx	x6, x4, #12, #4
1000d46b0:     	orr	x6, x16, x6
1000d46b4:     	ldrsb	w6, [x9, x6]
1000d46b8:     	ubfx	x7, x4, #16, #4
1000d46bc:     	orr	x7, x17, x7
1000d46c0:     	ldrsb	w7, [x9, x7]
1000d46c4:     	add	w5, w5, w6
1000d46c8:     	add	w5, w5, w7
1000d46cc:     	ubfx	x6, x4, #20, #4
1000d46d0:     	orr	x6, x0, x6
1000d46d4:     	ldrsb	w6, [x9, x6]
1000d46d8:     	ubfx	x7, x4, #24, #4
1000d46dc:     	orr	x7, x1, x7
1000d46e0:     	ldrsb	w7, [x9, x7]
1000d46e4:     	add	w5, w5, w6
1000d46e8:     	add	w5, w5, w7
1000d46ec:     	orr	x4, x2, x4, lsr #28
1000d46f0:     	ldrsb	w4, [x9, x4]
1000d46f4:     	add	w4, w5, w4
1000d46f8:     	scvtf	s0, w4
1000d46fc:     	ldr	s1, [x3]
1000d4700:     	fadd	s0, s1, s0
1000d4704:     	str	s0, [x3], #128
1000d4708:     	add	x12, x12, #4
1000d470c:     	cmp	x12, #64
1000d4710:     	b.ne	0x1000d467c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d4714:     	add	x10, x10, #1
1000d4718:     	add	x11, x11, #4
1000d471c:     	cmp	x10, #32
1000d4720:     	b.ne	0x1000d4634 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d4724:     	add	x21, x21, #128
1000d4728:     	add	x20, x20, #64
1000d472c:     	cmp	x20, x8
1000d4730:     	b.ne	0x1000d462c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d4734:     	add	x1, sp, #8
1000d4738:     	mov	x0, x19
1000d473c:     	mov	w2, #2048
1000d4740:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d4744:     	ldur	x8, [x29, #-56]
1000d4748:     	adrp	x9, 0x100168000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x220>
1000d474c:     	ldr	x9, [x9, #392]
1000d4750:     	ldr	x9, [x9]
1000d4754:     	cmp	x9, x8
1000d4758:     	b.ne	0x1000d4774 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d475c:     	add	sp, sp, #2064
1000d4760:     	ldp	x29, x30, [sp, #48]
1000d4764:     	ldp	x20, x19, [sp, #32]
1000d4768:     	ldp	x22, x21, [sp, #16]
1000d476c:     	ldp	x28, x27, [sp], #64
1000d4770:     	ret
1000d4774:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d5be8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5be8:     	stp	x28, x27, [sp, #-64]!
1000d5bec:     	stp	x22, x21, [sp, #16]
1000d5bf0:     	stp	x20, x19, [sp, #32]
1000d5bf4:     	stp	x29, x30, [sp, #48]
1000d5bf8:     	add	x29, sp, #48
1000d5bfc:     	mov	w9, #4112
1000d5c00:     	adrp	x16, 0x100168000 <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d5c04:     	ldr	x16, [x16, #304]
1000d5c08:     	blr	x16
1000d5c0c:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d5c10:     	sub	sp, sp, #16
1000d5c14:     	mov	x19, x3
1000d5c18:     	mov	x20, x1
1000d5c1c:     	mov	x21, x0
1000d5c20:     	adrp	x8, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x10>
1000d5c24:     	ldr	x8, [x8, #392]
1000d5c28:     	ldr	x8, [x8]
1000d5c2c:     	stur	x8, [x29, #-56]
1000d5c30:     	lsl	x8, x2, #4
1000d5c34:     	and	x22, x8, #0xffffffffffffffe0
1000d5c38:     	add	x0, sp, #8
1000d5c3c:     	mov	w1, #4096
1000d5c40:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d5c44:     	cbz	x22, 0x1000d5d5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d5c48:     	add	x8, x20, x22
1000d5c4c:     	adrp	x9, 0x100166000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x34>
1000d5c50:     	add	x9, x9, #1756
1000d5c54:     	mov	x10, #0
1000d5c58:     	add	x11, sp, #8
1000d5c5c:     	mov	x12, #0
1000d5c60:     	ldr	w2, [x21, x10, lsl #2]
1000d5c64:     	lsl	w13, w2, #4
1000d5c68:     	and	x13, x13, #0xf0
1000d5c6c:     	and	x14, x2, #0xf0
1000d5c70:     	lsr	x15, x2, #4
1000d5c74:     	and	x15, x15, #0xf0
1000d5c78:     	lsr	x16, x2, #8
1000d5c7c:     	and	x16, x16, #0xf0
1000d5c80:     	lsr	x17, x2, #12
1000d5c84:     	and	x17, x17, #0xf0
1000d5c88:     	lsr	x0, x2, #16
1000d5c8c:     	and	x0, x0, #0xf0
1000d5c90:     	lsr	x1, x2, #20
1000d5c94:     	and	x1, x1, #0xf0
1000d5c98:     	lsr	x2, x2, #24
1000d5c9c:     	and	x2, x2, #0xf0
1000d5ca0:     	mov	x3, x11
1000d5ca4:     	ldr	w4, [x20, x12]
1000d5ca8:     	and	x5, x4, #0xf
1000d5cac:     	orr	x5, x13, x5
1000d5cb0:     	ldrb	w5, [x9, x5]
1000d5cb4:     	ubfx	x6, x4, #4, #4
1000d5cb8:     	orr	x6, x14, x6
1000d5cbc:     	ldrb	w6, [x9, x6]
1000d5cc0:     	ubfx	x7, x4, #8, #4
1000d5cc4:     	orr	x7, x15, x7
1000d5cc8:     	ldrb	w7, [x9, x7]
1000d5ccc:     	add	w5, w5, w6
1000d5cd0:     	add	w5, w5, w7
1000d5cd4:     	ubfx	x6, x4, #12, #4
1000d5cd8:     	orr	x6, x16, x6
1000d5cdc:     	ldrb	w6, [x9, x6]
1000d5ce0:     	ubfx	x7, x4, #16, #4
1000d5ce4:     	orr	x7, x17, x7
1000d5ce8:     	ldrb	w7, [x9, x7]
1000d5cec:     	add	w5, w5, w6
1000d5cf0:     	add	w5, w5, w7
1000d5cf4:     	ubfx	x6, x4, #20, #4
1000d5cf8:     	orr	x6, x0, x6
1000d5cfc:     	ldrb	w6, [x9, x6]
1000d5d00:     	ubfx	x7, x4, #24, #4
1000d5d04:     	orr	x7, x1, x7
1000d5d08:     	ldrb	w7, [x9, x7]
1000d5d0c:     	add	w5, w5, w6
1000d5d10:     	add	w5, w5, w7
1000d5d14:     	orr	x4, x2, x4, lsr #28
1000d5d18:     	ldrb	w4, [x9, x4]
1000d5d1c:     	add	w4, w5, w4
1000d5d20:     	scvtf	s0, w4
1000d5d24:     	ldr	s1, [x3]
1000d5d28:     	fadd	s0, s1, s0
1000d5d2c:     	str	s0, [x3], #128
1000d5d30:     	add	x12, x12, #4
1000d5d34:     	cmp	x12, #128
1000d5d38:     	b.ne	0x1000d5ca4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d5d3c:     	add	x10, x10, #1
1000d5d40:     	add	x11, x11, #4
1000d5d44:     	cmp	x10, #32
1000d5d48:     	b.ne	0x1000d5c5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d5d4c:     	add	x21, x21, #128
1000d5d50:     	add	x20, x20, #128
1000d5d54:     	cmp	x20, x8
1000d5d58:     	b.ne	0x1000d5c54 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d5d5c:     	add	x1, sp, #8
1000d5d60:     	mov	x0, x19
1000d5d64:     	mov	w2, #4096
1000d5d68:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d5d6c:     	ldur	x8, [x29, #-56]
1000d5d70:     	adrp	x9, 0x100168000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d5d74:     	ldr	x9, [x9, #392]
1000d5d78:     	ldr	x9, [x9]
1000d5d7c:     	cmp	x9, x8
1000d5d80:     	b.ne	0x1000d5da0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d5d84:     	add	sp, sp, #1, lsl #12     ; =4096
1000d5d88:     	add	sp, sp, #16
1000d5d8c:     	ldp	x29, x30, [sp, #48]
1000d5d90:     	ldp	x20, x19, [sp, #32]
1000d5d94:     	ldp	x22, x21, [sp, #16]
1000d5d98:     	ldp	x28, x27, [sp], #64
1000d5d9c:     	ret
1000d5da0:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001000d5e5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5e5c:     	stp	x28, x27, [sp, #-64]!
1000d5e60:     	stp	x22, x21, [sp, #16]
1000d5e64:     	stp	x20, x19, [sp, #32]
1000d5e68:     	stp	x29, x30, [sp, #48]
1000d5e6c:     	add	x29, sp, #48
1000d5e70:     	mov	w9, #4112
1000d5e74:     	adrp	x16, 0x100168000 <void run<double, 1ul, 1ul, false>(char const*)+0x34>
1000d5e78:     	ldr	x16, [x16, #304]
1000d5e7c:     	blr	x16
1000d5e80:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d5e84:     	sub	sp, sp, #16
1000d5e88:     	mov	x19, x3
1000d5e8c:     	mov	x20, x1
1000d5e90:     	mov	x21, x0
1000d5e94:     	adrp	x8, 0x100168000 <void run<double, 1ul, 1ul, false>(char const*)+0x54>
1000d5e98:     	ldr	x8, [x8, #392]
1000d5e9c:     	ldr	x8, [x8]
1000d5ea0:     	stur	x8, [x29, #-56]
1000d5ea4:     	lsl	x8, x2, #4
1000d5ea8:     	and	x22, x8, #0xffffffffffffffe0
1000d5eac:     	add	x0, sp, #8
1000d5eb0:     	mov	w1, #4096
1000d5eb4:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d5eb8:     	cbz	x22, 0x1000d5fd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d5ebc:     	add	x8, x20, x22
1000d5ec0:     	adrp	x9, 0x100166000 <void run<double, 1ul, 1ul, false>(char const*)+0x78>
1000d5ec4:     	add	x9, x9, #2012
1000d5ec8:     	mov	x10, #0
1000d5ecc:     	add	x11, sp, #8
1000d5ed0:     	mov	x12, #0
1000d5ed4:     	ldr	w2, [x21, x10, lsl #2]
1000d5ed8:     	lsl	w13, w2, #4
1000d5edc:     	and	x13, x13, #0xf0
1000d5ee0:     	and	x14, x2, #0xf0
1000d5ee4:     	lsr	x15, x2, #4
1000d5ee8:     	and	x15, x15, #0xf0
1000d5eec:     	lsr	x16, x2, #8
1000d5ef0:     	and	x16, x16, #0xf0
1000d5ef4:     	lsr	x17, x2, #12
1000d5ef8:     	and	x17, x17, #0xf0
1000d5efc:     	lsr	x0, x2, #16
1000d5f00:     	and	x0, x0, #0xf0
1000d5f04:     	lsr	x1, x2, #20
1000d5f08:     	and	x1, x1, #0xf0
1000d5f0c:     	lsr	x2, x2, #24
1000d5f10:     	and	x2, x2, #0xf0
1000d5f14:     	mov	x3, x11
1000d5f18:     	ldr	w4, [x20, x12]
1000d5f1c:     	and	x5, x4, #0xf
1000d5f20:     	orr	x5, x13, x5
1000d5f24:     	ldrsb	w5, [x9, x5]
1000d5f28:     	ubfx	x6, x4, #4, #4
1000d5f2c:     	orr	x6, x14, x6
1000d5f30:     	ldrsb	w6, [x9, x6]
1000d5f34:     	ubfx	x7, x4, #8, #4
1000d5f38:     	orr	x7, x15, x7
1000d5f3c:     	ldrsb	w7, [x9, x7]
1000d5f40:     	add	w5, w5, w6
1000d5f44:     	add	w5, w5, w7
1000d5f48:     	ubfx	x6, x4, #12, #4
1000d5f4c:     	orr	x6, x16, x6
1000d5f50:     	ldrsb	w6, [x9, x6]
1000d5f54:     	ubfx	x7, x4, #16, #4
1000d5f58:     	orr	x7, x17, x7
1000d5f5c:     	ldrsb	w7, [x9, x7]
1000d5f60:     	add	w5, w5, w6
1000d5f64:     	add	w5, w5, w7
1000d5f68:     	ubfx	x6, x4, #20, #4
1000d5f6c:     	orr	x6, x0, x6
1000d5f70:     	ldrsb	w6, [x9, x6]
1000d5f74:     	ubfx	x7, x4, #24, #4
1000d5f78:     	orr	x7, x1, x7
1000d5f7c:     	ldrsb	w7, [x9, x7]
1000d5f80:     	add	w5, w5, w6
1000d5f84:     	add	w5, w5, w7
1000d5f88:     	orr	x4, x2, x4, lsr #28
1000d5f8c:     	ldrsb	w4, [x9, x4]
1000d5f90:     	add	w4, w5, w4
1000d5f94:     	scvtf	s0, w4
1000d5f98:     	ldr	s1, [x3]
1000d5f9c:     	fadd	s0, s1, s0
1000d5fa0:     	str	s0, [x3], #128
1000d5fa4:     	add	x12, x12, #4
1000d5fa8:     	cmp	x12, #128
1000d5fac:     	b.ne	0x1000d5f18 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d5fb0:     	add	x10, x10, #1
1000d5fb4:     	add	x11, x11, #4
1000d5fb8:     	cmp	x10, #32
1000d5fbc:     	b.ne	0x1000d5ed0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d5fc0:     	add	x21, x21, #128
1000d5fc4:     	add	x20, x20, #128
1000d5fc8:     	cmp	x20, x8
1000d5fcc:     	b.ne	0x1000d5ec8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d5fd0:     	add	x1, sp, #8
1000d5fd4:     	mov	x0, x19
1000d5fd8:     	mov	w2, #4096
1000d5fdc:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d5fe0:     	ldur	x8, [x29, #-56]
1000d5fe4:     	adrp	x9, 0x100168000 <void run<double, 1ul, 1ul, false>(char const*)+0x1a4>
1000d5fe8:     	ldr	x9, [x9, #392]
1000d5fec:     	ldr	x9, [x9]
1000d5ff0:     	cmp	x9, x8
1000d5ff4:     	b.ne	0x1000d6014 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d5ff8:     	add	sp, sp, #1, lsl #12     ; =4096
1000d5ffc:     	add	sp, sp, #16
1000d6000:     	ldp	x29, x30, [sp, #48]
1000d6004:     	ldp	x20, x19, [sp, #32]
1000d6008:     	ldp	x22, x21, [sp, #16]
1000d600c:     	ldp	x28, x27, [sp], #64
1000d6010:     	ret
1000d6014:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

00000001001115cc <void kernel<short, 1ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
1001115cc:     	b	0x1001115d0 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(short const*, short const*, unsigned long, float*)>

00000001001116c0 <void kernel<short, 1ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001116c0:     	b	0x1001116c4 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(short const*, short const*, unsigned long, float*)>

0000000100112bd8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100112bd8:     	stp	d9, d8, [sp, #-16]!
100112bdc:     	cbz	x2, 0x100112bf8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x20>
100112be0:     	cmp	x2, #32
100112be4:     	b.hs	0x100112c04 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x2c>
100112be8:     	mov	x8, #0
100112bec:     	movi	d1, #0000000000000000
100112bf0:     	movi	d0, #0000000000000000
100112bf4:     	b	0x100112f58 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x380>
100112bf8:     	str	xzr, [x3]
100112bfc:     	ldp	d9, d8, [sp], #16
100112c00:     	ret
100112c04:     	and	x8, x2, #0xffffffffffffffe0
100112c08:     	add	x9, x1, #32
100112c0c:     	add	x10, x0, #64
100112c10:     	movi	d1, #0000000000000000
100112c14:     	mov	x11, x8
100112c18:     	movi	d0, #0000000000000000
100112c1c:     	ldp	q3, q2, [x9, #-32]
100112c20:     	sub	x12, x10, #64
100112c24:     	ld2.8h	{ v27, v28 }, [x12]
100112c28:     	ldp	q5, q4, [x9]
100112c2c:     	sub	x12, x10, #32
100112c30:     	ld2.8h	{ v23, v24 }, [x12]
100112c34:     	mov	x12, x10
100112c38:     	ld2.8h	{ v20, v21 }, [x12], #32
100112c3c:     	ld2.8h	{ v18, v19 }, [x12]
100112c40:     	sshll2.4s	v17, v27, #0
100112c44:     	sshll.4s	v26, v27, #0
100112c48:     	sshll2.4s	v16, v23, #0
100112c4c:     	sshll.4s	v25, v23, #0
100112c50:     	sshll2.4s	v7, v20, #0
100112c54:     	sshll.4s	v22, v20, #0
100112c58:     	sshll2.4s	v6, v18, #0
100112c5c:     	sshll2.4s	v29, v28, #0
100112c60:     	sshll.4s	v30, v18, #0
100112c64:     	sshll.4s	v27, v28, #0
100112c68:     	sshll2.4s	v28, v24, #0
100112c6c:     	sshll.4s	v23, v24, #0
100112c70:     	sshll2.4s	v24, v21, #0
100112c74:     	sshll.4s	v21, v21, #0
100112c78:     	sshll2.4s	v31, v19, #0
100112c7c:     	sshll.4s	v8, v19, #0
100112c80:     	sshll.4s	v18, v3, #0
100112c84:     	scvtf.4s	v18, v18
100112c88:     	scvtf.4s	v19, v26
100112c8c:     	scvtf.4s	v26, v27
100112c90:     	fsub.4s	v20, v19, v18
100112c94:     	fsub.4s	v26, v26, v18
100112c98:     	sshll2.4s	v3, v3, #0
100112c9c:     	scvtf.4s	v3, v3
100112ca0:     	scvtf.4s	v17, v17
100112ca4:     	scvtf.4s	v18, v29
100112ca8:     	fsub.4s	v19, v17, v3
100112cac:     	fsub.4s	v27, v18, v3
100112cb0:     	sshll.4s	v3, v2, #0
100112cb4:     	scvtf.4s	v3, v3
100112cb8:     	scvtf.4s	v17, v25
100112cbc:     	scvtf.4s	v23, v23
100112cc0:     	fsub.4s	v18, v17, v3
100112cc4:     	fsub.4s	v23, v23, v3
100112cc8:     	sshll2.4s	v2, v2, #0
100112ccc:     	scvtf.4s	v2, v2
100112cd0:     	scvtf.4s	v3, v16
100112cd4:     	scvtf.4s	v16, v28
100112cd8:     	fsub.4s	v17, v3, v2
100112cdc:     	fsub.4s	v25, v16, v2
100112ce0:     	sshll.4s	v2, v5, #0
100112ce4:     	scvtf.4s	v2, v2
100112ce8:     	scvtf.4s	v3, v22
100112cec:     	scvtf.4s	v21, v21
100112cf0:     	fsub.4s	v16, v3, v2
100112cf4:     	fsub.4s	v21, v21, v2
100112cf8:     	sshll2.4s	v2, v5, #0
100112cfc:     	scvtf.4s	v2, v2
100112d00:     	scvtf.4s	v3, v7
100112d04:     	scvtf.4s	v7, v24
100112d08:     	fsub.4s	v5, v3, v2
100112d0c:     	fsub.4s	v7, v7, v2
100112d10:     	sshll.4s	v2, v4, #0
100112d14:     	scvtf.4s	v2, v2
100112d18:     	scvtf.4s	v3, v30
100112d1c:     	scvtf.4s	v22, v8
100112d20:     	fsub.4s	v3, v3, v2
100112d24:     	fsub.4s	v22, v22, v2
100112d28:     	sshll2.4s	v2, v4, #0
100112d2c:     	scvtf.4s	v4, v2
100112d30:     	scvtf.4s	v2, v6
100112d34:     	scvtf.4s	v6, v31
100112d38:     	fsub.4s	v2, v2, v4
100112d3c:     	fsub.4s	v4, v6, v4
100112d40:     	fmul.4s	v6, v26, v26
100112d44:     	mov	s24, v6[1]
100112d48:     	fadd	s1, s1, s6
100112d4c:     	fadd	s1, s1, s24
100112d50:     	mov	s24, v6[2]
100112d54:     	fadd	s1, s1, s24
100112d58:     	fmul.4s	v24, v27, v27
100112d5c:     	mov	s6, v6[3]
100112d60:     	fadd	s1, s1, s6
100112d64:     	mov	s6, v24[1]
100112d68:     	fadd	s1, s1, s24
100112d6c:     	fadd	s1, s1, s6
100112d70:     	mov	s6, v24[2]
100112d74:     	fadd	s1, s1, s6
100112d78:     	mov	s6, v24[3]
100112d7c:     	fmul.4s	v23, v23, v23
100112d80:     	fadd	s1, s1, s6
100112d84:     	mov	s6, v23[1]
100112d88:     	fadd	s1, s1, s23
100112d8c:     	fadd	s1, s1, s6
100112d90:     	mov	s6, v23[2]
100112d94:     	fadd	s1, s1, s6
100112d98:     	fmul.4s	v6, v25, v25
100112d9c:     	mov	s23, v23[3]
100112da0:     	fadd	s1, s1, s23
100112da4:     	mov	s23, v6[1]
100112da8:     	fadd	s1, s1, s6
100112dac:     	fadd	s1, s1, s23
100112db0:     	mov	s23, v6[2]
100112db4:     	fadd	s1, s1, s23
100112db8:     	mov	s6, v6[3]
100112dbc:     	fmul.4s	v21, v21, v21
100112dc0:     	fadd	s1, s1, s6
100112dc4:     	mov	s6, v21[1]
100112dc8:     	fadd	s1, s1, s21
100112dcc:     	fadd	s1, s1, s6
100112dd0:     	mov	s6, v21[2]
100112dd4:     	fadd	s1, s1, s6
100112dd8:     	fmul.4s	v6, v7, v7
100112ddc:     	mov	s7, v21[3]
100112de0:     	fadd	s1, s1, s7
100112de4:     	mov	s7, v6[1]
100112de8:     	fadd	s1, s1, s6
100112dec:     	fadd	s1, s1, s7
100112df0:     	mov	s7, v6[2]
100112df4:     	fadd	s1, s1, s7
100112df8:     	fmul.4s	v7, v20, v20
100112dfc:     	mov	s6, v6[3]
100112e00:     	fmul.4s	v20, v22, v22
100112e04:     	fadd	s1, s1, s6
100112e08:     	mov	s6, v20[1]
100112e0c:     	fadd	s1, s1, s20
100112e10:     	fadd	s1, s1, s6
100112e14:     	mov	s6, v20[2]
100112e18:     	fadd	s1, s1, s6
100112e1c:     	mov	s6, v7[1]
100112e20:     	fadd	s0, s0, s7
100112e24:     	fadd	s0, s0, s6
100112e28:     	mov	s6, v7[2]
100112e2c:     	fadd	s0, s0, s6
100112e30:     	mov	s6, v7[3]
100112e34:     	fadd	s0, s0, s6
100112e38:     	fmul.4s	v6, v19, v19
100112e3c:     	mov	s7, v20[3]
100112e40:     	fadd	s1, s1, s7
100112e44:     	mov	s7, v6[1]
100112e48:     	fadd	s0, s0, s6
100112e4c:     	fadd	s0, s0, s7
100112e50:     	mov	s7, v6[2]
100112e54:     	fadd	s0, s0, s7
100112e58:     	mov	s6, v6[3]
100112e5c:     	fmul.4s	v7, v18, v18
100112e60:     	fmul.4s	v4, v4, v4
100112e64:     	fadd	s0, s0, s6
100112e68:     	mov	s6, v4[1]
100112e6c:     	fadd	s1, s1, s4
100112e70:     	fadd	s1, s1, s6
100112e74:     	mov	s6, v7[1]
100112e78:     	fadd	s0, s0, s7
100112e7c:     	fadd	s0, s0, s6
100112e80:     	mov	s6, v7[2]
100112e84:     	fadd	s0, s0, s6
100112e88:     	fmul.4s	v6, v17, v17
100112e8c:     	mov	s7, v7[3]
100112e90:     	fadd	s0, s0, s7
100112e94:     	mov	s7, v6[1]
100112e98:     	fadd	s0, s0, s6
100112e9c:     	fadd	s0, s0, s7
100112ea0:     	mov	s7, v6[2]
100112ea4:     	fadd	s0, s0, s7
100112ea8:     	mov	s6, v6[3]
100112eac:     	fmul.4s	v7, v16, v16
100112eb0:     	fadd	s0, s0, s6
100112eb4:     	mov	s6, v4[2]
100112eb8:     	fadd	s1, s1, s6
100112ebc:     	mov	s6, v7[1]
100112ec0:     	fadd	s0, s0, s7
100112ec4:     	fadd	s0, s0, s6
100112ec8:     	mov	s6, v7[2]
100112ecc:     	fadd	s0, s0, s6
100112ed0:     	fmul.4s	v5, v5, v5
100112ed4:     	mov	s6, v7[3]
100112ed8:     	fadd	s0, s0, s6
100112edc:     	mov	s6, v5[1]
100112ee0:     	fadd	s0, s0, s5
100112ee4:     	fadd	s0, s0, s6
100112ee8:     	mov	s6, v5[2]
100112eec:     	fadd	s0, s0, s6
100112ef0:     	mov	s5, v5[3]
100112ef4:     	fadd	s0, s0, s5
100112ef8:     	fmul.4s	v3, v3, v3
100112efc:     	mov	s4, v4[3]
100112f00:     	fadd	s1, s1, s4
100112f04:     	mov	s4, v3[1]
100112f08:     	fadd	s0, s0, s3
100112f0c:     	fadd	s0, s0, s4
100112f10:     	mov	s4, v3[2]
100112f14:     	fadd	s0, s0, s4
100112f18:     	fmul.4s	v2, v2, v2
100112f1c:     	mov	s3, v3[3]
100112f20:     	fadd	s0, s0, s3
100112f24:     	mov	s3, v2[1]
100112f28:     	fadd	s0, s0, s2
100112f2c:     	fadd	s0, s0, s3
100112f30:     	mov	s3, v2[2]
100112f34:     	fadd	s0, s0, s3
100112f38:     	mov	s2, v2[3]
100112f3c:     	fadd	s0, s0, s2
100112f40:     	add	x9, x9, #64
100112f44:     	add	x10, x10, #128
100112f48:     	subs	x11, x11, #32
100112f4c:     	b.ne	0x100112c1c <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x44>
100112f50:     	cmp	x8, x2
100112f54:     	b.eq	0x100112fa4 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
100112f58:     	sub	x9, x2, x8
100112f5c:     	add	x10, x0, x8, lsl #2
100112f60:     	add	x10, x10, #2
100112f64:     	add	x8, x1, x8, lsl #1
100112f68:     	ldrsh	w11, [x8], #2
100112f6c:     	scvtf	s2, w11
100112f70:     	ldur	h3, [x10, #-2]
100112f74:     	sshll.4s	v3, v3, #0
100112f78:     	scvtf	s3, s3
100112f7c:     	fsub	s3, s3, s2
100112f80:     	fmadd	s0, s3, s3, s0
100112f84:     	ldr	h3, [x10]
100112f88:     	sshll.4s	v3, v3, #0
100112f8c:     	scvtf	s3, s3
100112f90:     	fsub	s2, s3, s2
100112f94:     	fmadd	s1, s2, s2, s1
100112f98:     	add	x10, x10, #4
100112f9c:     	subs	x9, x9, #1
100112fa0:     	b.ne	0x100112f68 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
100112fa4:     	stp	s0, s1, [x3]
100112fa8:     	ldp	d9, d8, [sp], #16
100112fac:     	ret

0000000100112fb0 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100112fb0:     	cbz	x2, 0x100112fcc <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x1c>
100112fb4:     	cmp	x2, #32
100112fb8:     	b.hs	0x100112fd4 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x24>
100112fbc:     	mov	x8, #0
100112fc0:     	movi	d1, #0000000000000000
100112fc4:     	movi	d0, #0000000000000000
100112fc8:     	b	0x100113328 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x378>
100112fcc:     	str	xzr, [x3]
100112fd0:     	ret
100112fd4:     	and	x8, x2, #0xffffffffffffffe0
100112fd8:     	add	x9, x1, #32
100112fdc:     	add	x10, x0, #64
100112fe0:     	movi	d1, #0000000000000000
100112fe4:     	mov	x11, x8
100112fe8:     	movi	d0, #0000000000000000
100112fec:     	ldp	q4, q2, [x9, #-32]
100112ff0:     	sub	x12, x10, #64
100112ff4:     	ld2.8h	{ v27, v28 }, [x12]
100112ff8:     	ldp	q5, q3, [x9]
100112ffc:     	sub	x12, x10, #32
100113000:     	ld2.8h	{ v25, v26 }, [x12]
100113004:     	mov	x12, x10
100113008:     	ld2.8h	{ v22, v23 }, [x12], #32
10011300c:     	ld2.8h	{ v20, v21 }, [x12]
100113010:     	sshll2.4s	v24, v27, #0
100113014:     	sshll.4s	v19, v27, #0
100113018:     	sshll2.4s	v18, v25, #0
10011301c:     	sshll.4s	v17, v25, #0
100113020:     	sshll2.4s	v16, v22, #0
100113024:     	sshll.4s	v7, v22, #0
100113028:     	sshll2.4s	v6, v20, #0
10011302c:     	sshll2.4s	v30, v28, #0
100113030:     	sshll.4s	v29, v20, #0
100113034:     	sshll.4s	v27, v28, #0
100113038:     	sshll2.4s	v28, v26, #0
10011303c:     	sshll.4s	v25, v26, #0
100113040:     	sshll2.4s	v26, v23, #0
100113044:     	sshll.4s	v22, v23, #0
100113048:     	sshll2.4s	v23, v21, #0
10011304c:     	sshll.4s	v21, v21, #0
100113050:     	sshll2.4s	v20, v4, #0
100113054:     	scvtf.4s	v31, v20
100113058:     	scvtf.4s	v20, v24
10011305c:     	fneg.4s	v20, v20
100113060:     	fmul.4s	v20, v20, v31
100113064:     	scvtf.4s	v24, v30
100113068:     	fneg.4s	v24, v24
10011306c:     	fmul.4s	v24, v24, v31
100113070:     	sshll.4s	v4, v4, #0
100113074:     	scvtf.4s	v4, v4
100113078:     	scvtf.4s	v19, v19
10011307c:     	fneg.4s	v19, v19
100113080:     	fmul.4s	v19, v19, v4
100113084:     	scvtf.4s	v27, v27
100113088:     	fneg.4s	v27, v27
10011308c:     	fmul.4s	v27, v27, v4
100113090:     	sshll2.4s	v4, v2, #0
100113094:     	scvtf.4s	v30, v4
100113098:     	scvtf.4s	v4, v18
10011309c:     	fneg.4s	v4, v4
1001130a0:     	scvtf.4s	v18, v28
1001130a4:     	fneg.4s	v18, v18
1001130a8:     	fmul.4s	v4, v4, v30
1001130ac:     	fmul.4s	v18, v18, v30
1001130b0:     	sshll.4s	v2, v2, #0
1001130b4:     	scvtf.4s	v2, v2
1001130b8:     	scvtf.4s	v17, v17
1001130bc:     	fneg.4s	v17, v17
1001130c0:     	fmul.4s	v17, v17, v2
1001130c4:     	scvtf.4s	v25, v25
1001130c8:     	fneg.4s	v25, v25
1001130cc:     	fmul.4s	v25, v25, v2
1001130d0:     	sshll2.4s	v2, v5, #0
1001130d4:     	scvtf.4s	v16, v16
1001130d8:     	scvtf.4s	v28, v2
1001130dc:     	fneg.4s	v2, v16
1001130e0:     	fmul.4s	v2, v2, v28
1001130e4:     	scvtf.4s	v16, v26
1001130e8:     	fneg.4s	v16, v16
1001130ec:     	fmul.4s	v16, v16, v28
1001130f0:     	sshll.4s	v5, v5, #0
1001130f4:     	scvtf.4s	v5, v5
1001130f8:     	scvtf.4s	v7, v7
1001130fc:     	fneg.4s	v7, v7
100113100:     	scvtf.4s	v22, v22
100113104:     	fneg.4s	v22, v22
100113108:     	fmul.4s	v7, v7, v5
10011310c:     	fmul.4s	v22, v22, v5
100113110:     	sshll2.4s	v5, v3, #0
100113114:     	scvtf.4s	v26, v5
100113118:     	scvtf.4s	v5, v6
10011311c:     	fneg.4s	v5, v5
100113120:     	fmul.4s	v5, v5, v26
100113124:     	scvtf.4s	v6, v23
100113128:     	fneg.4s	v6, v6
10011312c:     	fmul.4s	v6, v6, v26
100113130:     	sshll.4s	v3, v3, #0
100113134:     	scvtf.4s	v3, v3
100113138:     	scvtf.4s	v23, v29
10011313c:     	fneg.4s	v23, v23
100113140:     	fmul.4s	v23, v23, v3
100113144:     	scvtf.4s	v21, v21
100113148:     	fneg.4s	v21, v21
10011314c:     	fmul.4s	v3, v21, v3
100113150:     	mov	s21, v27[1]
100113154:     	fadd	s1, s1, s27
100113158:     	fadd	s1, s1, s21
10011315c:     	mov	s21, v27[2]
100113160:     	fadd	s1, s1, s21
100113164:     	mov	s21, v27[3]
100113168:     	fadd	s1, s1, s21
10011316c:     	mov	s21, v24[1]
100113170:     	fadd	s1, s1, s24
100113174:     	fadd	s1, s1, s21
100113178:     	mov	s21, v24[2]
10011317c:     	fadd	s1, s1, s21
100113180:     	mov	s21, v24[3]
100113184:     	fadd	s1, s1, s21
100113188:     	mov	s21, v25[1]
10011318c:     	fadd	s1, s1, s25
100113190:     	fadd	s1, s1, s21
100113194:     	mov	s21, v25[2]
100113198:     	fadd	s1, s1, s21
10011319c:     	mov	s21, v25[3]
1001131a0:     	fadd	s1, s1, s21
1001131a4:     	mov	s21, v18[1]
1001131a8:     	fadd	s1, s1, s18
1001131ac:     	fadd	s1, s1, s21
1001131b0:     	mov	s21, v18[2]
1001131b4:     	fadd	s1, s1, s21
1001131b8:     	mov	s18, v18[3]
1001131bc:     	fadd	s1, s1, s18
1001131c0:     	mov	s18, v22[1]
1001131c4:     	fadd	s1, s1, s22
1001131c8:     	fadd	s1, s1, s18
1001131cc:     	mov	s18, v22[2]
1001131d0:     	fadd	s1, s1, s18
1001131d4:     	mov	s18, v22[3]
1001131d8:     	fadd	s1, s1, s18
1001131dc:     	mov	s18, v16[1]
1001131e0:     	fadd	s1, s1, s16
1001131e4:     	fadd	s1, s1, s18
1001131e8:     	mov	s18, v16[2]
1001131ec:     	fadd	s1, s1, s18
1001131f0:     	mov	s16, v16[3]
1001131f4:     	fadd	s1, s1, s16
1001131f8:     	mov	s16, v3[1]
1001131fc:     	fadd	s1, s1, s3
100113200:     	fadd	s1, s1, s16
100113204:     	mov	s16, v3[2]
100113208:     	fadd	s1, s1, s16
10011320c:     	fadd	s0, s0, s19
100113210:     	mov	s16, v19[1]
100113214:     	fadd	s0, s0, s16
100113218:     	mov	s16, v19[2]
10011321c:     	fadd	s0, s0, s16
100113220:     	mov	s16, v19[3]
100113224:     	fadd	s0, s0, s16
100113228:     	mov	s16, v20[1]
10011322c:     	fadd	s0, s0, s20
100113230:     	fadd	s0, s0, s16
100113234:     	mov	s16, v20[2]
100113238:     	fadd	s0, s0, s16
10011323c:     	mov	s3, v3[3]
100113240:     	fadd	s1, s1, s3
100113244:     	mov	s3, v20[3]
100113248:     	fadd	s0, s0, s3
10011324c:     	mov	s3, v17[1]
100113250:     	fadd	s0, s0, s17
100113254:     	fadd	s0, s0, s3
100113258:     	mov	s3, v17[2]
10011325c:     	fadd	s0, s0, s3
100113260:     	mov	s3, v17[3]
100113264:     	fadd	s0, s0, s3
100113268:     	mov	s3, v6[1]
10011326c:     	fadd	s1, s1, s6
100113270:     	fadd	s1, s1, s3
100113274:     	mov	s3, v4[1]
100113278:     	fadd	s0, s0, s4
10011327c:     	fadd	s0, s0, s3
100113280:     	mov	s3, v4[2]
100113284:     	fadd	s0, s0, s3
100113288:     	mov	s3, v4[3]
10011328c:     	fadd	s0, s0, s3
100113290:     	mov	s3, v7[1]
100113294:     	fadd	s0, s0, s7
100113298:     	fadd	s0, s0, s3
10011329c:     	mov	s3, v6[2]
1001132a0:     	fadd	s1, s1, s3
1001132a4:     	mov	s3, v7[2]
1001132a8:     	fadd	s0, s0, s3
1001132ac:     	mov	s3, v7[3]
1001132b0:     	fadd	s0, s0, s3
1001132b4:     	fadd	s0, s0, s2
1001132b8:     	mov	s3, v2[1]
1001132bc:     	fadd	s0, s0, s3
1001132c0:     	mov	s3, v2[2]
1001132c4:     	fadd	s0, s0, s3
1001132c8:     	mov	s2, v2[3]
1001132cc:     	fadd	s0, s0, s2
1001132d0:     	mov	s2, v23[1]
1001132d4:     	fadd	s0, s0, s23
1001132d8:     	fadd	s0, s0, s2
1001132dc:     	mov	s2, v23[2]
1001132e0:     	fadd	s0, s0, s2
1001132e4:     	mov	s2, v6[3]
1001132e8:     	fadd	s1, s1, s2
1001132ec:     	mov	s2, v23[3]
1001132f0:     	fadd	s0, s0, s2
1001132f4:     	mov	s2, v5[1]
1001132f8:     	fadd	s0, s0, s5
1001132fc:     	fadd	s0, s0, s2
100113300:     	mov	s2, v5[2]
100113304:     	fadd	s0, s0, s2
100113308:     	mov	s2, v5[3]
10011330c:     	fadd	s0, s0, s2
100113310:     	add	x9, x9, #64
100113314:     	add	x10, x10, #128
100113318:     	subs	x11, x11, #32
10011331c:     	b.ne	0x100112fec <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3c>
100113320:     	cmp	x8, x2
100113324:     	b.eq	0x10011336c <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3bc>
100113328:     	sub	x9, x2, x8
10011332c:     	add	x10, x0, x8, lsl #2
100113330:     	add	x10, x10, #2
100113334:     	add	x8, x1, x8, lsl #1
100113338:     	ldrsh	w11, [x8], #2
10011333c:     	scvtf	s2, w11
100113340:     	ldur	h3, [x10, #-2]
100113344:     	sshll.4s	v3, v3, #0
100113348:     	scvtf	s3, s3
10011334c:     	fmsub	s0, s3, s2, s0
100113350:     	ldr	h3, [x10]
100113354:     	sshll.4s	v3, v3, #0
100113358:     	scvtf	s3, s3
10011335c:     	fmsub	s1, s3, s2, s1
100113360:     	add	x10, x10, #4
100113364:     	subs	x9, x9, #1
100113368:     	b.ne	0x100113338 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x388>
10011336c:     	stp	s0, s1, [x3]
100113370:     	ret

0000000100114ed8 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
100114ed8:     	cbz	x2, 0x100114f38 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x60>
100114edc:     	ldrsh	w8, [x1]
100114ee0:     	fmov	s0, w8
100114ee4:     	ldrsh	w8, [x1, #2]
100114ee8:     	mov.s	v0[1], w8
100114eec:     	scvtf.2s	v0, v0
100114ef0:     	zip1.4s	v0, v0, v0
100114ef4:     	ldrsh	w8, [x0]
100114ef8:     	fmov	s1, w8
100114efc:     	ldrsh	w8, [x0, #2]
100114f00:     	mov.s	v1[1], w8
100114f04:     	scvtf.2s	v1, v1
100114f08:     	mov.d	v1[1], v1[0]
100114f0c:     	fsub.4s	v0, v1, v0
100114f10:     	fmul.4s	v0, v0, v0
100114f14:     	str	q0, [x3]
100114f18:     	subs	x11, x2, #1
100114f1c:     	b.eq	0x10011514c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x274>
100114f20:     	cmp	x2, #9
100114f24:     	b.hs	0x100114f40 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x68>
100114f28:     	mov	w8, #1
100114f2c:     	mov	x9, x1
100114f30:     	mov	x10, x0
100114f34:     	b	0x1001150f0 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x218>
100114f38:     	stp	xzr, xzr, [x3]
100114f3c:     	ret
100114f40:     	and	x12, x11, #0xfffffffffffffff8
100114f44:     	lsl	x8, x12, #2
100114f48:     	add	x9, x1, x8
100114f4c:     	add	x10, x0, x8
100114f50:     	orr	x8, x12, #0x1
100114f54:     	mov	s3, v0[1]
100114f58:     	mov	s2, v0[2]
100114f5c:     	mov	s1, v0[3]
100114f60:     	add	x13, x0, #4
100114f64:     	add	x14, x1, #4
100114f68:     	mov	x15, x12
100114f6c:     	ld2.8h	{ v4, v5 }, [x13], #32
100114f70:     	sshll2.4s	v6, v4, #0
100114f74:     	scvtf.4s	v6, v6
100114f78:     	sshll.4s	v7, v4, #0
100114f7c:     	scvtf.4s	v7, v7
100114f80:     	ld2.8h	{ v16, v17 }, [x14], #32
100114f84:     	sshll2.4s	v18, v16, #0
100114f88:     	scvtf.4s	v18, v18
100114f8c:     	sshll.4s	v19, v16, #0
100114f90:     	scvtf.4s	v19, v19
100114f94:     	sshll2.4s	v20, v17, #0
100114f98:     	sshll.4s	v16, v17, #0
100114f9c:     	sshll2.4s	v17, v5, #0
100114fa0:     	sshll.4s	v4, v5, #0
100114fa4:     	fsub.4s	v5, v7, v19
100114fa8:     	scvtf.4s	v16, v16
100114fac:     	fsub.4s	v7, v7, v16
100114fb0:     	scvtf.4s	v4, v4
100114fb4:     	fsub.4s	v19, v4, v19
100114fb8:     	fsub.4s	v4, v4, v16
100114fbc:     	fsub.4s	v16, v6, v18
100114fc0:     	scvtf.4s	v20, v20
100114fc4:     	fsub.4s	v6, v6, v20
100114fc8:     	scvtf.4s	v17, v17
100114fcc:     	fsub.4s	v18, v17, v18
100114fd0:     	fsub.4s	v17, v17, v20
100114fd4:     	fmul.4s	v4, v4, v4
100114fd8:     	mov	s20, v4[1]
100114fdc:     	fadd	s1, s1, s4
100114fe0:     	fadd	s1, s1, s20
100114fe4:     	mov	s20, v4[2]
100114fe8:     	fadd	s1, s1, s20
100114fec:     	fmul.4s	v17, v17, v17
100114ff0:     	mov	s4, v4[3]
100114ff4:     	fadd	s1, s1, s4
100114ff8:     	mov	s4, v17[1]
100114ffc:     	fadd	s1, s1, s17
100115000:     	fadd	s1, s1, s4
100115004:     	mov	s4, v17[2]
100115008:     	fadd	s1, s1, s4
10011500c:     	fmul.4s	v4, v19, v19
100115010:     	mov	s17, v17[3]
100115014:     	fadd	s1, s1, s17
100115018:     	mov	s17, v4[1]
10011501c:     	fadd	s3, s3, s4
100115020:     	fadd	s3, s3, s17
100115024:     	mov	s17, v4[2]
100115028:     	fadd	s3, s3, s17
10011502c:     	fmul.4s	v17, v18, v18
100115030:     	mov	s4, v4[3]
100115034:     	fadd	s3, s3, s4
100115038:     	mov	s4, v17[1]
10011503c:     	fadd	s3, s3, s17
100115040:     	fadd	s3, s3, s4
100115044:     	mov	s4, v17[2]
100115048:     	fadd	s3, s3, s4
10011504c:     	fmul.4s	v4, v7, v7
100115050:     	mov	s7, v17[3]
100115054:     	fadd	s3, s3, s7
100115058:     	mov	s7, v4[1]
10011505c:     	fadd	s2, s2, s4
100115060:     	fadd	s2, s2, s7
100115064:     	mov	s7, v4[2]
100115068:     	fadd	s2, s2, s7
10011506c:     	fmul.4s	v6, v6, v6
100115070:     	mov	s4, v4[3]
100115074:     	fadd	s2, s2, s4
100115078:     	mov	s4, v6[1]
10011507c:     	fadd	s2, s2, s6
100115080:     	fadd	s2, s2, s4
100115084:     	mov	s4, v6[2]
100115088:     	fadd	s2, s2, s4
10011508c:     	fmul.4s	v4, v5, v5
100115090:     	mov	s5, v6[3]
100115094:     	fadd	s2, s2, s5
100115098:     	mov	s5, v4[1]
10011509c:     	fadd	s0, s0, s4
1001150a0:     	fadd	s0, s0, s5
1001150a4:     	mov	s5, v4[2]
1001150a8:     	fadd	s0, s0, s5
1001150ac:     	fmul.4s	v5, v16, v16
1001150b0:     	mov	s4, v4[3]
1001150b4:     	fadd	s0, s0, s4
1001150b8:     	mov	s4, v5[1]
1001150bc:     	fadd	s0, s0, s5
1001150c0:     	fadd	s0, s0, s4
1001150c4:     	mov	s4, v5[3]
1001150c8:     	mov	s5, v5[2]
1001150cc:     	fadd	s0, s0, s5
1001150d0:     	fadd	s0, s0, s4
1001150d4:     	subs	x15, x15, #8
1001150d8:     	b.ne	0x100114f6c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x94>
1001150dc:     	mov.s	v0[1], v3[0]
1001150e0:     	mov.s	v0[2], v2[0]
1001150e4:     	mov.s	v0[3], v1[0]
1001150e8:     	cmp	x11, x12
1001150ec:     	b.eq	0x100115148 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x270>
1001150f0:     	add	x9, x9, #4
1001150f4:     	add	x10, x10, #4
1001150f8:     	sub	x8, x2, x8
1001150fc:     	ldrsh	w11, [x9]
100115100:     	fmov	s1, w11
100115104:     	ldrsh	w11, [x9, #2]
100115108:     	mov.s	v1[1], w11
10011510c:     	scvtf.2s	v1, v1
100115110:     	zip1.4s	v1, v1, v1
100115114:     	ldrsh	w11, [x10]
100115118:     	fmov	s2, w11
10011511c:     	ldrsh	w11, [x10, #2]
100115120:     	mov.s	v2[1], w11
100115124:     	scvtf.2s	v2, v2
100115128:     	mov.d	v2[1], v2[0]
10011512c:     	fsub.4s	v1, v2, v1
100115130:     	fmul.4s	v1, v1, v1
100115134:     	fadd.4s	v0, v0, v1
100115138:     	add	x9, x9, #4
10011513c:     	add	x10, x10, #4
100115140:     	subs	x8, x8, #1
100115144:     	b.ne	0x1001150fc <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x224>
100115148:     	str	q0, [x3]
10011514c:     	ret

0000000100115150 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100115150:     	cbz	x2, 0x1001151f0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0xa0>
100115154:     	ldrsh	w8, [x1, #2]
100115158:     	ldrsh	w9, [x1]
10011515c:     	fmov	s0, w9
100115160:     	mov.s	v0[1], w8
100115164:     	ldrsh	w8, [x0, #2]
100115168:     	ldrsh	w9, [x0]
10011516c:     	fmov	s1, w9
100115170:     	mov.s	v1[1], w8
100115174:     	mov.s	v1[2], w9
100115178:     	mov.s	v1[3], w8
10011517c:     	zip1.4s	v0, v0, v0
100115180:     	mul.4s	v0, v1, v0
100115184:     	scvtf.4s	v0, v0
100115188:     	fneg.4s	v0, v0
10011518c:     	str	q0, [x3]
100115190:     	subs	x8, x2, #1
100115194:     	b.eq	0x1001151ec <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x9c>
100115198:     	add	x9, x0, #4
10011519c:     	add	x10, x1, #4
1001151a0:     	ldrsh	w11, [x10, #2]
1001151a4:     	ldrsh	w12, [x10]
1001151a8:     	fmov	s1, w12
1001151ac:     	mov.s	v1[1], w11
1001151b0:     	zip1.4s	v1, v1, v1
1001151b4:     	ldrsh	w11, [x9, #2]
1001151b8:     	ldrsh	w12, [x9]
1001151bc:     	fmov	s2, w12
1001151c0:     	mov.s	v2[1], w11
1001151c4:     	mov.s	v2[2], w12
1001151c8:     	mov.s	v2[3], w11
1001151cc:     	mul.4s	v1, v2, v1
1001151d0:     	scvtf.4s	v1, v1
1001151d4:     	fsub.4s	v0, v0, v1
1001151d8:     	add	x9, x9, #4
1001151dc:     	add	x10, x10, #4
1001151e0:     	subs	x8, x8, #1
1001151e4:     	b.ne	0x1001151a0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x50>
1001151e8:     	str	q0, [x3]
1001151ec:     	ret
1001151f0:     	stp	xzr, xzr, [x3]
1001151f4:     	ret

0000000100116a94 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100116a94:     	cbz	x2, 0x100116adc <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x48>
100116a98:     	ldr	h0, [x1]
100116a9c:     	sshll.4s	v0, v0, #0
100116aa0:     	scvtf	s0, s0
100116aa4:     	ldr	d1, [x0]
100116aa8:     	sshll.4s	v1, v1, #0
100116aac:     	scvtf.4s	v1, v1
100116ab0:     	dup.4s	v0, v0[0]
100116ab4:     	fsub.4s	v0, v1, v0
100116ab8:     	fmul.4s	v0, v0, v0
100116abc:     	str	q0, [x3]
100116ac0:     	subs	x10, x2, #1
100116ac4:     	b.eq	0x100116e60 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
100116ac8:     	cmp	x2, #17
100116acc:     	b.hs	0x100116ae4 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x50>
100116ad0:     	mov	w8, #1
100116ad4:     	mov	x9, x1
100116ad8:     	b	0x100116e24 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
100116adc:     	stp	xzr, xzr, [x3]
100116ae0:     	ret
100116ae4:     	and	x11, x10, #0xfffffffffffffff0
100116ae8:     	add	x9, x1, x11, lsl #1
100116aec:     	orr	x8, x11, #0x1
100116af0:     	mov	s1, v0[1]
100116af4:     	mov	s2, v0[2]
100116af8:     	mov	s3, v0[3]
100116afc:     	add	x12, x0, #72
100116b00:     	add	x13, x1, #18
100116b04:     	mov	x14, x11
100116b08:     	add	x0, x0, x11, lsl #3
100116b0c:     	sub	x15, x12, #64
100116b10:     	ld4.8h	{ v16, v17, v18, v19 }, [x15]
100116b14:     	ld4.8h	{ v20, v21, v22, v23 }, [x12]
100116b18:     	sshll2.4s	v5, v16, #0
100116b1c:     	sshll2.4s	v4, v20, #0
100116b20:     	sshll.4s	v7, v16, #0
100116b24:     	sshll.4s	v6, v20, #0
100116b28:     	sshll2.4s	v25, v17, #0
100116b2c:     	sshll.4s	v27, v17, #0
100116b30:     	sshll2.4s	v24, v21, #0
100116b34:     	sshll.4s	v26, v21, #0
100116b38:     	sshll2.4s	v28, v18, #0
100116b3c:     	sshll.4s	v29, v18, #0
100116b40:     	sshll2.4s	v30, v19, #0
100116b44:     	sshll.4s	v16, v19, #0
100116b48:     	sshll2.4s	v17, v22, #0
100116b4c:     	sshll.4s	v18, v22, #0
100116b50:     	sshll2.4s	v19, v23, #0
100116b54:     	sshll.4s	v20, v23, #0
100116b58:     	ldur	q21, [x13, #-16]
100116b5c:     	sshll.4s	v22, v21, #0
100116b60:     	scvtf.4s	v22, v22
100116b64:     	scvtf.4s	v7, v7
100116b68:     	fsub.4s	v7, v7, v22
100116b6c:     	scvtf.4s	v23, v27
100116b70:     	fsub.4s	v23, v23, v22
100116b74:     	scvtf.4s	v27, v29
100116b78:     	fsub.4s	v27, v27, v22
100116b7c:     	scvtf.4s	v16, v16
100116b80:     	fsub.4s	v22, v16, v22
100116b84:     	ldr	q29, [x13]
100116b88:     	sshll2.4s	v16, v21, #0
100116b8c:     	scvtf.4s	v21, v16
100116b90:     	scvtf.4s	v5, v5
100116b94:     	scvtf.4s	v25, v25
100116b98:     	fsub.4s	v16, v5, v21
100116b9c:     	fsub.4s	v25, v25, v21
100116ba0:     	scvtf.4s	v5, v28
100116ba4:     	fsub.4s	v28, v5, v21
100116ba8:     	scvtf.4s	v5, v30
100116bac:     	fsub.4s	v21, v5, v21
100116bb0:     	sshll.4s	v5, v29, #0
100116bb4:     	scvtf.4s	v30, v5
100116bb8:     	scvtf.4s	v5, v6
100116bbc:     	fsub.4s	v5, v5, v30
100116bc0:     	scvtf.4s	v6, v26
100116bc4:     	scvtf.4s	v18, v18
100116bc8:     	fsub.4s	v6, v6, v30
100116bcc:     	fsub.4s	v18, v18, v30
100116bd0:     	scvtf.4s	v20, v20
100116bd4:     	fsub.4s	v20, v20, v30
100116bd8:     	sshll2.4s	v26, v29, #0
100116bdc:     	scvtf.4s	v26, v26
100116be0:     	scvtf.4s	v4, v4
100116be4:     	fsub.4s	v4, v4, v26
100116be8:     	scvtf.4s	v24, v24
100116bec:     	fsub.4s	v24, v24, v26
100116bf0:     	scvtf.4s	v17, v17
100116bf4:     	scvtf.4s	v19, v19
100116bf8:     	fsub.4s	v17, v17, v26
100116bfc:     	fsub.4s	v19, v19, v26
100116c00:     	fmul.4s	v22, v22, v22
100116c04:     	mov	s26, v22[1]
100116c08:     	fadd	s3, s3, s22
100116c0c:     	fadd	s3, s3, s26
100116c10:     	mov	s26, v22[2]
100116c14:     	fadd	s3, s3, s26
100116c18:     	fmul.4s	v21, v21, v21
100116c1c:     	mov	s22, v22[3]
100116c20:     	fadd	s3, s3, s22
100116c24:     	mov	s22, v21[1]
100116c28:     	fadd	s3, s3, s21
100116c2c:     	fadd	s3, s3, s22
100116c30:     	mov	s22, v21[2]
100116c34:     	fadd	s3, s3, s22
100116c38:     	mov	s21, v21[3]
100116c3c:     	fmul.4s	v20, v20, v20
100116c40:     	fadd	s3, s3, s21
100116c44:     	mov	s21, v20[1]
100116c48:     	fadd	s3, s3, s20
100116c4c:     	fadd	s3, s3, s21
100116c50:     	mov	s21, v20[2]
100116c54:     	fadd	s3, s3, s21
100116c58:     	fmul.4s	v21, v27, v27
100116c5c:     	fmul.4s	v19, v19, v19
100116c60:     	mov	s20, v20[3]
100116c64:     	fadd	s3, s3, s20
100116c68:     	mov	s20, v19[1]
100116c6c:     	fadd	s3, s3, s19
100116c70:     	fadd	s3, s3, s20
100116c74:     	mov	s20, v21[1]
100116c78:     	fadd	s2, s2, s21
100116c7c:     	fadd	s2, s2, s20
100116c80:     	mov	s20, v21[2]
100116c84:     	fadd	s2, s2, s20
100116c88:     	fmul.4s	v20, v28, v28
100116c8c:     	mov	s21, v21[3]
100116c90:     	fadd	s2, s2, s21
100116c94:     	mov	s21, v20[1]
100116c98:     	fadd	s2, s2, s20
100116c9c:     	fadd	s2, s2, s21
100116ca0:     	mov	s21, v20[2]
100116ca4:     	fadd	s2, s2, s21
100116ca8:     	mov	s20, v20[3]
100116cac:     	fmul.4s	v18, v18, v18
100116cb0:     	fadd	s2, s2, s20
100116cb4:     	mov	s20, v18[1]
100116cb8:     	fadd	s2, s2, s18
100116cbc:     	fadd	s2, s2, s20
100116cc0:     	mov	s20, v18[2]
100116cc4:     	fadd	s2, s2, s20
100116cc8:     	fmul.4s	v20, v23, v23
100116ccc:     	fmul.4s	v17, v17, v17
100116cd0:     	mov	s18, v18[3]
100116cd4:     	fadd	s2, s2, s18
100116cd8:     	mov	s18, v17[1]
100116cdc:     	fadd	s2, s2, s17
100116ce0:     	fadd	s2, s2, s18
100116ce4:     	mov	s18, v19[2]
100116ce8:     	fadd	s3, s3, s18
100116cec:     	mov	s18, v17[2]
100116cf0:     	fadd	s2, s2, s18
100116cf4:     	mov	s18, v20[1]
100116cf8:     	fadd	s1, s1, s20
100116cfc:     	fadd	s1, s1, s18
100116d00:     	mov	s18, v20[2]
100116d04:     	fadd	s1, s1, s18
100116d08:     	mov	s18, v20[3]
100116d0c:     	fadd	s1, s1, s18
100116d10:     	fmul.4s	v18, v25, v25
100116d14:     	mov	s19, v19[3]
100116d18:     	fadd	s3, s3, s19
100116d1c:     	mov	s19, v18[1]
100116d20:     	fadd	s1, s1, s18
100116d24:     	fadd	s1, s1, s19
100116d28:     	mov	s19, v18[2]
100116d2c:     	fadd	s1, s1, s19
100116d30:     	mov	s18, v18[3]
100116d34:     	fmul.4s	v6, v6, v6
100116d38:     	fadd	s1, s1, s18
100116d3c:     	mov	s18, v6[1]
100116d40:     	fadd	s1, s1, s6
100116d44:     	fadd	s1, s1, s18
100116d48:     	mov	s18, v6[2]
100116d4c:     	fadd	s1, s1, s18
100116d50:     	fmul.4s	v18, v24, v24
100116d54:     	mov	s6, v6[3]
100116d58:     	fadd	s1, s1, s6
100116d5c:     	mov	s6, v18[1]
100116d60:     	fadd	s1, s1, s18
100116d64:     	fadd	s1, s1, s6
100116d68:     	mov	s6, v18[2]
100116d6c:     	fadd	s1, s1, s6
100116d70:     	fmul.4s	v6, v7, v7
100116d74:     	mov	s7, v17[3]
100116d78:     	fadd	s2, s2, s7
100116d7c:     	mov	s7, v6[1]
100116d80:     	fadd	s0, s0, s6
100116d84:     	fadd	s0, s0, s7
100116d88:     	mov	s7, v6[2]
100116d8c:     	fadd	s0, s0, s7
100116d90:     	fmul.4s	v7, v16, v16
100116d94:     	mov	s6, v6[3]
100116d98:     	fadd	s0, s0, s6
100116d9c:     	mov	s6, v7[1]
100116da0:     	fadd	s0, s0, s7
100116da4:     	fadd	s0, s0, s6
100116da8:     	mov	s6, v7[2]
100116dac:     	fadd	s0, s0, s6
100116db0:     	mov	s6, v7[3]
100116db4:     	fadd	s0, s0, s6
100116db8:     	fmul.4s	v5, v5, v5
100116dbc:     	mov	s6, v18[3]
100116dc0:     	fadd	s1, s1, s6
100116dc4:     	mov	s6, v5[1]
100116dc8:     	fadd	s0, s0, s5
100116dcc:     	fadd	s0, s0, s6
100116dd0:     	mov	s6, v5[2]
100116dd4:     	fadd	s0, s0, s6
100116dd8:     	fmul.4s	v4, v4, v4
100116ddc:     	mov	s5, v5[3]
100116de0:     	fadd	s0, s0, s5
100116de4:     	mov	s5, v4[1]
100116de8:     	fadd	s0, s0, s4
100116dec:     	fadd	s0, s0, s5
100116df0:     	mov	s5, v4[2]
100116df4:     	fadd	s0, s0, s5
100116df8:     	mov	s4, v4[3]
100116dfc:     	fadd	s0, s0, s4
100116e00:     	add	x12, x12, #128
100116e04:     	add	x13, x13, #32
100116e08:     	subs	x14, x14, #16
100116e0c:     	b.ne	0x100116b0c <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x78>
100116e10:     	mov.s	v0[1], v1[0]
100116e14:     	mov.s	v0[2], v2[0]
100116e18:     	mov.s	v0[3], v3[0]
100116e1c:     	cmp	x10, x11
100116e20:     	b.eq	0x100116e5c <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3c8>
100116e24:     	add	x9, x9, #2
100116e28:     	add	x10, x0, #8
100116e2c:     	sub	x8, x2, x8
100116e30:     	ldrsh	w11, [x9], #2
100116e34:     	scvtf	s1, w11
100116e38:     	ldr	d2, [x10], #8
100116e3c:     	sshll.4s	v2, v2, #0
100116e40:     	scvtf.4s	v2, v2
100116e44:     	dup.4s	v1, v1[0]
100116e48:     	fsub.4s	v1, v2, v1
100116e4c:     	fmul.4s	v1, v1, v1
100116e50:     	fadd.4s	v0, v0, v1
100116e54:     	subs	x8, x8, #1
100116e58:     	b.ne	0x100116e30 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x39c>
100116e5c:     	str	q0, [x3]
100116e60:     	ret

0000000100116e64 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100116e64:     	cbz	x2, 0x100116ebc <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x58>
100116e68:     	ld1r.4h	{ v0 }, [x1]
100116e6c:     	ldr	d1, [x0]
100116e70:     	smull.4s	v0, v0, v1
100116e74:     	scvtf.4s	v0, v0
100116e78:     	fneg.4s	v0, v0
100116e7c:     	str	q0, [x3]
100116e80:     	cmp	x2, #1
100116e84:     	b.eq	0x100116eb8 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x54>
100116e88:     	add	x8, x1, #2
100116e8c:     	add	x9, x0, #8
100116e90:     	lsl	x10, x2, #1
100116e94:     	sub	x10, x10, #2
100116e98:     	ldr	d1, [x9], #8
100116e9c:     	ld1r.4h	{ v2 }, [x8], #2
100116ea0:     	smull.4s	v1, v2, v1
100116ea4:     	scvtf.4s	v1, v1
100116ea8:     	fsub.4s	v0, v0, v1
100116eac:     	subs	x10, x10, #2
100116eb0:     	b.ne	0x100116e98 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x34>
100116eb4:     	str	q0, [x3]
100116eb8:     	ret
100116ebc:     	stp	xzr, xzr, [x3]
100116ec0:     	ret

00000001001190e4 <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
1001190e4:     	cbz	x2, 0x1001190ec <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001190e8:     	b	0x1001190f8 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
1001190ec:     	movi.2d	v0, #0000000000000000
1001190f0:     	stp	q0, q0, [x3]
1001190f4:     	ret

00000001001194cc <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
1001194cc:     	cbz	x2, 0x1001194d4 <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001194d0:     	b	0x1001194e0 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
1001194d4:     	movi.2d	v0, #0000000000000000
1001194d8:     	stp	q0, q0, [x3]
1001194dc:     	ret

000000010011b18c <void kernel<short, 4ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10011b18c:     	b	0x10011b190 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010011b28c <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10011b28c:     	cbz	x2, 0x10011b294 <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011b290:     	b	0x10011b2a4 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
10011b294:     	movi.2d	v0, #0000000000000000
10011b298:     	stp	q0, q0, [x3, #32]
10011b29c:     	stp	q0, q0, [x3]
10011b2a0:     	ret

000000010011d528 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
10011d528:     	cbz	x2, 0x10011d530 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10011d52c:     	b	0x10011d53c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
10011d530:     	movi.2d	v0, #0000000000000000
10011d534:     	stp	q0, q0, [x3]
10011d538:     	ret

000000010011d5d4 <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
10011d5d4:     	cbz	x2, 0x10011d5dc <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011d5d8:     	b	0x10011d5e8 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
10011d5dc:     	movi.2d	v0, #0000000000000000
10011d5e0:     	stp	q0, q0, [x3]
10011d5e4:     	ret

000000010011f814 <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10011f814:     	cbz	x2, 0x10011f81c <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10011f818:     	b	0x10011f82c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011f81c:     	movi.2d	v0, #0000000000000000
10011f820:     	stp	q0, q0, [x3, #32]
10011f824:     	stp	q0, q0, [x3]
10011f828:     	ret

000000010011f96c <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10011f96c:     	cbz	x2, 0x10011f974 <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011f970:     	b	0x10011f984 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011f974:     	movi.2d	v0, #0000000000000000
10011f978:     	stp	q0, q0, [x3, #32]
10011f97c:     	stp	q0, q0, [x3]
10011f980:     	ret

00000001001221d0 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
1001221d0:     	cbz	x2, 0x1001221d8 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001221d4:     	b	0x1001221f0 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001221d8:     	movi.2d	v0, #0000000000000000
1001221dc:     	stp	q0, q0, [x3, #96]
1001221e0:     	stp	q0, q0, [x3, #64]
1001221e4:     	stp	q0, q0, [x3, #32]
1001221e8:     	stp	q0, q0, [x3]
1001221ec:     	ret

00000001001223e0 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
1001223e0:     	cbz	x2, 0x1001223e8 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001223e4:     	b	0x100122400 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001223e8:     	movi.2d	v0, #0000000000000000
1001223ec:     	stp	q0, q0, [x3, #96]
1001223f0:     	stp	q0, q0, [x3, #64]
1001223f4:     	stp	q0, q0, [x3, #32]
1001223f8:     	stp	q0, q0, [x3]
1001223fc:     	ret

0000000100124e1c <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100124e1c:     	cbz	x2, 0x100124e24 <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)+0x8>
100124e20:     	b	0x100124e4c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(short const*, short const*, unsigned long, float*)>
100124e24:     	movi.2d	v0, #0000000000000000
100124e28:     	stp	q0, q0, [x3, #224]
100124e2c:     	stp	q0, q0, [x3, #192]
100124e30:     	stp	q0, q0, [x3, #160]
100124e34:     	stp	q0, q0, [x3, #128]
100124e38:     	stp	q0, q0, [x3, #96]
100124e3c:     	stp	q0, q0, [x3, #64]
100124e40:     	stp	q0, q0, [x3, #32]
100124e44:     	stp	q0, q0, [x3]
100124e48:     	ret

0000000100125268 <void kernel<short, 8ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100125268:     	b	0x10012526c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100127694 <void kernel<short, 16ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100127694:     	b	0x100127698 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

0000000100127728 <void kernel<short, 16ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100127728:     	b	0x10012772c <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010012a1c4 <void kernel<short, 16ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10012a1c4:     	b	0x10012a1c8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010012a2e4 <void kernel<short, 16ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10012a2e4:     	b	0x10012a2e8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010012d0f0 <void kernel<short, 16ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10012d0f0:     	b	0x10012d0f4 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010012d320 <void kernel<short, 16ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10012d320:     	b	0x10012d324 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

0000000100130b74 <void kernel<short, 16ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100130b74:     	b	0x100130b78 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100130c64 <void kernel<short, 16ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100130c64:     	b	0x100130c68 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

00000001001345d8 <void kernel<short, 16ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
1001345d8:     	b	0x1001345dc <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010013468c <void kernel<short, 16ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10013468c:     	b	0x100134690 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

0000000100135628 <void kernel<short, 32ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100135628:     	b	0x10013562c <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

00000001001357dc <void kernel<short, 32ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001357dc:     	b	0x1001357e0 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

00000001001371e0 <void kernel<short, 32ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
1001371e0:     	b	0x1001371e4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

0000000100137540 <void kernel<short, 32ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100137540:     	b	0x100137544 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

0000000100139544 <void kernel<short, 32ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
100139544:     	b	0x100139548 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010013974c <void kernel<short, 32ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10013974c:     	b	0x100139750 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010013c1e8 <void kernel<short, 32ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
10013c1e8:     	b	0x10013c1ec <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

000000010013c3b4 <void kernel<short, 32ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
10013c3b4:     	b	0x10013c3b8 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

000000010013eed0 <void kernel<short, 32ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
10013eed0:     	b	0x10013eed4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010013f09c <void kernel<short, 32ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10013f09c:     	b	0x10013f0a0 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

00000001001408e8 <void kernel<short, 32ul, 32ul, false>(short const*, short const*, unsigned long, float*)>:
1001408e8:     	b	0x1001408ec <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100140ab4 <void kernel<short, 32ul, 32ul, true>(short const*, short const*, unsigned long, float*)>:
100140ab4:     	b	0x100140ab8 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100142fec <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>:
100142fec:     	add	x8, x0, x2, lsl #1
100142ff0:     	ands	x9, x2, #0xfffffffffffffff8
100142ff4:     	b.eq	0x10014308c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xa0>
100142ff8:     	add	x11, x0, x9, lsl #1
100142ffc:     	lsl	x9, x2, #1
100143000:     	and	x9, x9, #0xfffffffffffffff0
100143004:     	movi.2d	v0, #0000000000000000
100143008:     	mov	x10, x0
10014300c:     	movi.2d	v1, #0000000000000000
100143010:     	ldr	q2, [x10], #16
100143014:     	ldr	q3, [x1], #16
100143018:     	fcvtl	v4.4s, v2.4h
10014301c:     	fcvtl	v5.4s, v3.4h
100143020:     	fmla.4s	v0, v5, v4
100143024:     	fcvtl2	v2.4s, v2.8h
100143028:     	fcvtl2	v3.4s, v3.8h
10014302c:     	fmla.4s	v1, v3, v2
100143030:     	subs	x9, x9, #16
100143034:     	b.ne	0x100143010 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x24>
100143038:     	sub	x9, x8, x11
10014303c:     	cmp	x9, #7
100143040:     	b.lt	0x100143058 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100143044:     	ldr	d2, [x11], #8
100143048:     	fcvtl	v2.4s, v2.4h
10014304c:     	ldr	d3, [x1], #8
100143050:     	fcvtl	v3.4s, v3.4h
100143054:     	fmla.4s	v0, v3, v2
100143058:     	fadd.4s	v0, v1, v0
10014305c:     	faddp.4s	v0, v0, v0
100143060:     	faddp.2s	s0, v0
100143064:     	cmp	x11, x8
100143068:     	b.eq	0x1001431a8 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014306c:     	add	x9, x0, x2, lsl #1
100143070:     	sub	x9, x9, x11
100143074:     	sub	x9, x9, #2
100143078:     	cmp	x9, #30
10014307c:     	b.hs	0x1001430a8 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xbc>
100143080:     	mov	x9, x11
100143084:     	mov	x10, x1
100143088:     	b	0x10014318c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
10014308c:     	movi.2d	v1, #0000000000000000
100143090:     	movi.2d	v0, #0000000000000000
100143094:     	mov	x11, x0
100143098:     	sub	x9, x8, x0
10014309c:     	cmp	x9, #7
1001430a0:     	b.ge	0x100143044 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x58>
1001430a4:     	b	0x100143058 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
1001430a8:     	lsr	x9, x9, #1
1001430ac:     	add	x12, x9, #1
1001430b0:     	and	x13, x12, #0xfffffffffffffff0
1001430b4:     	lsl	x10, x13, #1
1001430b8:     	add	x9, x11, x10
1001430bc:     	add	x10, x1, x10
1001430c0:     	add	x14, x1, #16
1001430c4:     	add	x11, x11, #16
1001430c8:     	mov	x15, x13
1001430cc:     	ldp	q1, q2, [x11, #-16]
1001430d0:     	fcvtl	v3.4s, v1.4h
1001430d4:     	fcvtl2	v1.4s, v1.8h
1001430d8:     	fcvtl	v4.4s, v2.4h
1001430dc:     	fcvtl2	v2.4s, v2.8h
1001430e0:     	ldp	q5, q6, [x14, #-16]
1001430e4:     	fcvtl	v7.4s, v5.4h
1001430e8:     	fcvtl2	v5.4s, v5.8h
1001430ec:     	fcvtl	v16.4s, v6.4h
1001430f0:     	fcvtl2	v6.4s, v6.8h
1001430f4:     	fmul.4s	v1, v1, v5
1001430f8:     	mov	s5, v1[3]
1001430fc:     	mov	s17, v1[2]
100143100:     	mov	s18, v1[1]
100143104:     	fmul.4s	v3, v3, v7
100143108:     	mov	s7, v3[3]
10014310c:     	mov	s19, v3[2]
100143110:     	mov	s20, v3[1]
100143114:     	fmul.4s	v2, v2, v6
100143118:     	mov	s6, v2[3]
10014311c:     	mov	s21, v2[2]
100143120:     	mov	s22, v2[1]
100143124:     	fmul.4s	v4, v4, v16
100143128:     	mov	s16, v4[3]
10014312c:     	mov	s23, v4[2]
100143130:     	mov	s24, v4[1]
100143134:     	fadd	s0, s0, s3
100143138:     	fadd	s0, s0, s20
10014313c:     	fadd	s0, s0, s19
100143140:     	fadd	s0, s0, s7
100143144:     	fadd	s0, s0, s1
100143148:     	fadd	s0, s0, s18
10014314c:     	fadd	s0, s0, s17
100143150:     	fadd	s0, s0, s5
100143154:     	fadd	s0, s0, s4
100143158:     	fadd	s0, s0, s24
10014315c:     	fadd	s0, s0, s23
100143160:     	fadd	s0, s0, s16
100143164:     	fadd	s0, s0, s2
100143168:     	fadd	s0, s0, s22
10014316c:     	fadd	s0, s0, s21
100143170:     	fadd	s0, s0, s6
100143174:     	add	x14, x14, #32
100143178:     	add	x11, x11, #32
10014317c:     	subs	x15, x15, #16
100143180:     	b.ne	0x1001430cc <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xe0>
100143184:     	cmp	x12, x13
100143188:     	b.eq	0x1001431a8 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014318c:     	ldr	h1, [x9], #2
100143190:     	fcvt	s1, h1
100143194:     	ldr	h2, [x10], #2
100143198:     	fcvt	s2, h2
10014319c:     	fmadd	s0, s1, s2, s0
1001431a0:     	cmp	x9, x8
1001431a4:     	b.ne	0x10014318c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
1001431a8:     	fneg	s0, s0
1001431ac:     	str	s0, [x3]
1001431b0:     	ret
