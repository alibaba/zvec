00000001000c71c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c71c4:     	stp	x22, x21, [sp, #-32]!
1000c71c8:     	stp	x20, x19, [sp, #16]
1000c71cc:     	movi.2d	v0, #0000000000000000
1000c71d0:     	stp	q0, q0, [x3, #32]
1000c71d4:     	stp	q0, q0, [x3]
1000c71d8:     	cmp	x2, #8
1000c71dc:     	b.hs	0x1000c71e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c71e0:     	mov	x8, #0
1000c71e4:     	b	0x1000c72f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c71e8:     	mov	x8, #0
1000c71ec:     	mov	w12, #8
1000c71f0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b8>
1000c71f4:     	add	x9, x9, #1212
1000c71f8:     	mov	x10, x0
1000c71fc:     	mov	x11, #0
1000c7200:     	lsr	x8, x8, #1
1000c7204:     	mul	x8, x8, x4
1000c7208:     	ldr	w6, [x1, x8]
1000c720c:     	mov	x8, x12
1000c7210:     	lsl	w12, w6, #4
1000c7214:     	and	x12, x12, #0xf0
1000c7218:     	add	x12, x9, x12
1000c721c:     	and	x13, x6, #0xf0
1000c7220:     	add	x13, x9, x13
1000c7224:     	lsr	x14, x6, #4
1000c7228:     	and	x14, x14, #0xf0
1000c722c:     	add	x14, x9, x14
1000c7230:     	lsr	x15, x6, #8
1000c7234:     	and	x15, x15, #0xf0
1000c7238:     	add	x15, x9, x15
1000c723c:     	lsr	x16, x6, #12
1000c7240:     	and	x16, x16, #0xf0
1000c7244:     	add	x16, x9, x16
1000c7248:     	lsr	x17, x6, #16
1000c724c:     	and	x17, x17, #0xf0
1000c7250:     	add	x17, x9, x17
1000c7254:     	lsr	x5, x6, #20
1000c7258:     	and	x5, x5, #0xf0
1000c725c:     	add	x5, x9, x5
1000c7260:     	lsr	x6, x6, #24
1000c7264:     	and	x6, x6, #0xf0
1000c7268:     	add	x6, x9, x6
1000c726c:     	ldr	w7, [x10, x11]
1000c7270:     	and	x19, x7, #0xf
1000c7274:     	ldrb	w19, [x12, x19]
1000c7278:     	ubfx	x20, x7, #4, #4
1000c727c:     	ldrb	w20, [x13, x20]
1000c7280:     	ubfx	x21, x7, #8, #4
1000c7284:     	ldrb	w21, [x14, x21]
1000c7288:     	add	w19, w19, w20
1000c728c:     	add	w19, w19, w21
1000c7290:     	ubfx	x20, x7, #12, #4
1000c7294:     	ldrb	w20, [x15, x20]
1000c7298:     	ubfx	x21, x7, #16, #4
1000c729c:     	ldrb	w21, [x16, x21]
1000c72a0:     	add	w19, w19, w20
1000c72a4:     	add	w19, w19, w21
1000c72a8:     	ubfx	x20, x7, #20, #4
1000c72ac:     	ldrb	w20, [x17, x20]
1000c72b0:     	ubfx	x21, x7, #24, #4
1000c72b4:     	ldrb	w21, [x5, x21]
1000c72b8:     	lsr	x7, x7, #28
1000c72bc:     	ldrb	w7, [x6, x7]
1000c72c0:     	add	w19, w19, w20
1000c72c4:     	add	w19, w19, w21
1000c72c8:     	add	w7, w19, w7
1000c72cc:     	scvtf	s0, w7
1000c72d0:     	ldr	s1, [x3, x11]
1000c72d4:     	fadd	s0, s1, s0
1000c72d8:     	str	s0, [x3, x11]
1000c72dc:     	add	x11, x11, #4
1000c72e0:     	cmp	x11, #64
1000c72e4:     	b.ne	0x1000c726c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c72e8:     	add	x12, x8, #8
1000c72ec:     	add	x10, x10, #64
1000c72f0:     	cmp	x12, x2
1000c72f4:     	b.ls	0x1000c71fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c72f8:     	cmp	x8, x2
1000c72fc:     	b.hs	0x1000c75f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x430>
1000c7300:     	lsl	x9, x4, #2
1000c7304:     	lsl	w10, w8, #2
1000c7308:     	mov	w11, #-16
1000c730c:     	lsr	x13, x8, #3
1000c7310:     	mul	x12, x9, x13
1000c7314:     	ubfx	x14, x8, #1, #2
1000c7318:     	orr	x15, x12, x14
1000c731c:     	and	w12, w10, #0x4
1000c7320:     	ldrb	w15, [x1, x15]
1000c7324:     	lsr	w15, w15, w12
1000c7328:     	and	w16, w15, #0xf
1000c732c:     	cmp	w16, #8
1000c7330:     	csel	w16, wzr, w11, lo
1000c7334:     	bfi	x14, x13, #6, #58
1000c7338:     	bfxil	w16, w15, #0, #4
1000c733c:     	add	x13, x0, x14
1000c7340:     	ldrb	w14, [x13]
1000c7344:     	lsr	w14, w14, w12
1000c7348:     	and	w15, w14, #0xf
1000c734c:     	scvtf	s0, w16
1000c7350:     	cmp	w15, #8
1000c7354:     	csel	w15, wzr, w11, lo
1000c7358:     	bfxil	w15, w14, #0, #4
1000c735c:     	scvtf	s1, w15
1000c7360:     	fsub	s1, s1, s0
1000c7364:     	ldp	s2, s3, [x3]
1000c7368:     	fmadd	s1, s1, s1, s2
1000c736c:     	str	s1, [x3]
1000c7370:     	ldrb	w14, [x13, #4]
1000c7374:     	lsr	w14, w14, w12
1000c7378:     	and	w15, w14, #0xf
1000c737c:     	cmp	w15, #8
1000c7380:     	csel	w15, wzr, w11, lo
1000c7384:     	bfxil	w15, w14, #0, #4
1000c7388:     	scvtf	s1, w15
1000c738c:     	fsub	s1, s1, s0
1000c7390:     	fmadd	s1, s1, s1, s3
1000c7394:     	str	s1, [x3, #4]
1000c7398:     	ldrb	w14, [x13, #8]
1000c739c:     	lsr	w14, w14, w12
1000c73a0:     	and	w15, w14, #0xf
1000c73a4:     	cmp	w15, #8
1000c73a8:     	csel	w15, wzr, w11, lo
1000c73ac:     	bfxil	w15, w14, #0, #4
1000c73b0:     	scvtf	s1, w15
1000c73b4:     	fsub	s1, s1, s0
1000c73b8:     	ldp	s2, s3, [x3, #8]
1000c73bc:     	fmadd	s1, s1, s1, s2
1000c73c0:     	str	s1, [x3, #8]
1000c73c4:     	ldrb	w14, [x13, #12]
1000c73c8:     	lsr	w14, w14, w12
1000c73cc:     	and	w15, w14, #0xf
1000c73d0:     	cmp	w15, #8
1000c73d4:     	csel	w15, wzr, w11, lo
1000c73d8:     	bfxil	w15, w14, #0, #4
1000c73dc:     	scvtf	s1, w15
1000c73e0:     	fsub	s1, s1, s0
1000c73e4:     	fmadd	s1, s1, s1, s3
1000c73e8:     	str	s1, [x3, #12]
1000c73ec:     	ldrb	w14, [x13, #16]
1000c73f0:     	lsr	w14, w14, w12
1000c73f4:     	and	w15, w14, #0xf
1000c73f8:     	cmp	w15, #8
1000c73fc:     	csel	w15, wzr, w11, lo
1000c7400:     	bfxil	w15, w14, #0, #4
1000c7404:     	scvtf	s1, w15
1000c7408:     	fsub	s1, s1, s0
1000c740c:     	ldp	s2, s3, [x3, #16]
1000c7410:     	fmadd	s1, s1, s1, s2
1000c7414:     	str	s1, [x3, #16]
1000c7418:     	ldrb	w14, [x13, #20]
1000c741c:     	lsr	w14, w14, w12
1000c7420:     	and	w15, w14, #0xf
1000c7424:     	cmp	w15, #8
1000c7428:     	csel	w15, wzr, w11, lo
1000c742c:     	bfxil	w15, w14, #0, #4
1000c7430:     	scvtf	s1, w15
1000c7434:     	fsub	s1, s1, s0
1000c7438:     	fmadd	s1, s1, s1, s3
1000c743c:     	str	s1, [x3, #20]
1000c7440:     	ldrb	w14, [x13, #24]
1000c7444:     	lsr	w14, w14, w12
1000c7448:     	and	w15, w14, #0xf
1000c744c:     	cmp	w15, #8
1000c7450:     	csel	w15, wzr, w11, lo
1000c7454:     	bfxil	w15, w14, #0, #4
1000c7458:     	scvtf	s1, w15
1000c745c:     	fsub	s1, s1, s0
1000c7460:     	ldp	s2, s3, [x3, #24]
1000c7464:     	fmadd	s1, s1, s1, s2
1000c7468:     	str	s1, [x3, #24]
1000c746c:     	ldrb	w14, [x13, #28]
1000c7470:     	lsr	w14, w14, w12
1000c7474:     	and	w15, w14, #0xf
1000c7478:     	cmp	w15, #8
1000c747c:     	csel	w15, wzr, w11, lo
1000c7480:     	bfxil	w15, w14, #0, #4
1000c7484:     	scvtf	s1, w15
1000c7488:     	fsub	s1, s1, s0
1000c748c:     	fmadd	s1, s1, s1, s3
1000c7490:     	str	s1, [x3, #28]
1000c7494:     	ldrb	w14, [x13, #32]
1000c7498:     	lsr	w14, w14, w12
1000c749c:     	and	w15, w14, #0xf
1000c74a0:     	cmp	w15, #8
1000c74a4:     	csel	w15, wzr, w11, lo
1000c74a8:     	bfxil	w15, w14, #0, #4
1000c74ac:     	scvtf	s1, w15
1000c74b0:     	fsub	s1, s1, s0
1000c74b4:     	ldp	s2, s3, [x3, #32]
1000c74b8:     	fmadd	s1, s1, s1, s2
1000c74bc:     	str	s1, [x3, #32]
1000c74c0:     	ldrb	w14, [x13, #36]
1000c74c4:     	lsr	w14, w14, w12
1000c74c8:     	and	w15, w14, #0xf
1000c74cc:     	cmp	w15, #8
1000c74d0:     	csel	w15, wzr, w11, lo
1000c74d4:     	bfxil	w15, w14, #0, #4
1000c74d8:     	scvtf	s1, w15
1000c74dc:     	fsub	s1, s1, s0
1000c74e0:     	fmadd	s1, s1, s1, s3
1000c74e4:     	str	s1, [x3, #36]
1000c74e8:     	ldrb	w14, [x13, #40]
1000c74ec:     	lsr	w14, w14, w12
1000c74f0:     	and	w15, w14, #0xf
1000c74f4:     	cmp	w15, #8
1000c74f8:     	csel	w15, wzr, w11, lo
1000c74fc:     	bfxil	w15, w14, #0, #4
1000c7500:     	scvtf	s1, w15
1000c7504:     	fsub	s1, s1, s0
1000c7508:     	ldp	s2, s3, [x3, #40]
1000c750c:     	fmadd	s1, s1, s1, s2
1000c7510:     	str	s1, [x3, #40]
1000c7514:     	ldrb	w14, [x13, #44]
1000c7518:     	lsr	w14, w14, w12
1000c751c:     	and	w15, w14, #0xf
1000c7520:     	cmp	w15, #8
1000c7524:     	csel	w15, wzr, w11, lo
1000c7528:     	bfxil	w15, w14, #0, #4
1000c752c:     	scvtf	s1, w15
1000c7530:     	fsub	s1, s1, s0
1000c7534:     	fmadd	s1, s1, s1, s3
1000c7538:     	str	s1, [x3, #44]
1000c753c:     	ldrb	w14, [x13, #48]
1000c7540:     	lsr	w14, w14, w12
1000c7544:     	and	w15, w14, #0xf
1000c7548:     	cmp	w15, #8
1000c754c:     	csel	w15, wzr, w11, lo
1000c7550:     	bfxil	w15, w14, #0, #4
1000c7554:     	scvtf	s1, w15
1000c7558:     	fsub	s1, s1, s0
1000c755c:     	ldp	s2, s3, [x3, #48]
1000c7560:     	fmadd	s1, s1, s1, s2
1000c7564:     	str	s1, [x3, #48]
1000c7568:     	ldrb	w14, [x13, #52]
1000c756c:     	lsr	w14, w14, w12
1000c7570:     	and	w15, w14, #0xf
1000c7574:     	cmp	w15, #8
1000c7578:     	csel	w15, wzr, w11, lo
1000c757c:     	bfxil	w15, w14, #0, #4
1000c7580:     	scvtf	s1, w15
1000c7584:     	fsub	s1, s1, s0
1000c7588:     	fmadd	s1, s1, s1, s3
1000c758c:     	str	s1, [x3, #52]
1000c7590:     	ldrb	w14, [x13, #56]
1000c7594:     	lsr	w14, w14, w12
1000c7598:     	and	w15, w14, #0xf
1000c759c:     	cmp	w15, #8
1000c75a0:     	csel	w15, wzr, w11, lo
1000c75a4:     	bfxil	w15, w14, #0, #4
1000c75a8:     	scvtf	s1, w15
1000c75ac:     	fsub	s1, s1, s0
1000c75b0:     	ldp	s2, s3, [x3, #56]
1000c75b4:     	fmadd	s1, s1, s1, s2
1000c75b8:     	str	s1, [x3, #56]
1000c75bc:     	ldrb	w13, [x13, #60]
1000c75c0:     	lsr	w12, w13, w12
1000c75c4:     	and	w13, w12, #0xf
1000c75c8:     	cmp	w13, #8
1000c75cc:     	csel	w13, wzr, w11, lo
1000c75d0:     	bfxil	w13, w12, #0, #4
1000c75d4:     	scvtf	s1, w13
1000c75d8:     	fsub	s0, s1, s0
1000c75dc:     	fmadd	s0, s0, s0, s3
1000c75e0:     	str	s0, [x3, #60]
1000c75e4:     	add	x8, x8, #1
1000c75e8:     	add	w10, w10, #4
1000c75ec:     	cmp	x2, x8
1000c75f0:     	b.ne	0x1000c730c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c75f4:     	ldp	x20, x19, [sp, #16]
1000c75f8:     	ldp	x22, x21, [sp], #32
1000c75fc:     	ret

