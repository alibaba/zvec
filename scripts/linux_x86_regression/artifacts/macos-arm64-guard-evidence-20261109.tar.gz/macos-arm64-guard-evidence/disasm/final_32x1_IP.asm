00000001000d03b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000d03b4:     	stp	x22, x21, [sp, #-32]!
1000d03b8:     	stp	x20, x19, [sp, #16]
1000d03bc:     	movi.2d	v0, #0000000000000000
1000d03c0:     	stp	q0, q0, [x3, #96]
1000d03c4:     	stp	q0, q0, [x3, #64]
1000d03c8:     	stp	q0, q0, [x3, #32]
1000d03cc:     	stp	q0, q0, [x3]
1000d03d0:     	cmp	x2, #8
1000d03d4:     	b.hs	0x1000d03e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000d03d8:     	mov	x8, #0
1000d03dc:     	b	0x1000d04f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000d03e0:     	mov	x8, #0
1000d03e4:     	mov	w12, #8
1000d03e8:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 2ul, false>(char const*)+0xc4>
1000d03ec:     	add	x9, x9, #1980
1000d03f0:     	mov	x10, x0
1000d03f4:     	mov	x11, #0
1000d03f8:     	lsr	x8, x8, #1
1000d03fc:     	mul	x8, x8, x4
1000d0400:     	ldr	w6, [x1, x8]
1000d0404:     	mov	x8, x12
1000d0408:     	lsl	w12, w6, #4
1000d040c:     	and	x12, x12, #0xf0
1000d0410:     	add	x12, x9, x12
1000d0414:     	and	x13, x6, #0xf0
1000d0418:     	add	x13, x9, x13
1000d041c:     	lsr	x14, x6, #4
1000d0420:     	and	x14, x14, #0xf0
1000d0424:     	add	x14, x9, x14
1000d0428:     	lsr	x15, x6, #8
1000d042c:     	and	x15, x15, #0xf0
1000d0430:     	add	x15, x9, x15
1000d0434:     	lsr	x16, x6, #12
1000d0438:     	and	x16, x16, #0xf0
1000d043c:     	add	x16, x9, x16
1000d0440:     	lsr	x17, x6, #16
1000d0444:     	and	x17, x17, #0xf0
1000d0448:     	add	x17, x9, x17
1000d044c:     	lsr	x5, x6, #20
1000d0450:     	and	x5, x5, #0xf0
1000d0454:     	add	x5, x9, x5
1000d0458:     	lsr	x6, x6, #24
1000d045c:     	and	x6, x6, #0xf0
1000d0460:     	add	x6, x9, x6
1000d0464:     	ldr	w7, [x10, x11]
1000d0468:     	and	x19, x7, #0xf
1000d046c:     	ldrsb	w19, [x12, x19]
1000d0470:     	ubfx	x20, x7, #4, #4
1000d0474:     	ldrsb	w20, [x13, x20]
1000d0478:     	ubfx	x21, x7, #8, #4
1000d047c:     	ldrsb	w21, [x14, x21]
1000d0480:     	add	w19, w19, w20
1000d0484:     	add	w19, w19, w21
1000d0488:     	ubfx	x20, x7, #12, #4
1000d048c:     	ldrsb	w20, [x15, x20]
1000d0490:     	ubfx	x21, x7, #16, #4
1000d0494:     	ldrsb	w21, [x16, x21]
1000d0498:     	add	w19, w19, w20
1000d049c:     	add	w19, w19, w21
1000d04a0:     	ubfx	x20, x7, #20, #4
1000d04a4:     	ldrsb	w20, [x17, x20]
1000d04a8:     	ubfx	x21, x7, #24, #4
1000d04ac:     	ldrsb	w21, [x5, x21]
1000d04b0:     	lsr	x7, x7, #28
1000d04b4:     	ldrsb	w7, [x6, x7]
1000d04b8:     	add	w19, w19, w20
1000d04bc:     	add	w19, w19, w21
1000d04c0:     	add	w7, w19, w7
1000d04c4:     	scvtf	s0, w7
1000d04c8:     	ldr	s1, [x3, x11]
1000d04cc:     	fadd	s0, s1, s0
1000d04d0:     	str	s0, [x3, x11]
1000d04d4:     	add	x11, x11, #4
1000d04d8:     	cmp	x11, #128
1000d04dc:     	b.ne	0x1000d0464 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000d04e0:     	add	x12, x8, #8
1000d04e4:     	add	x10, x10, #128
1000d04e8:     	cmp	x12, x2
1000d04ec:     	b.ls	0x1000d03f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000d04f0:     	cmp	x8, x2
1000d04f4:     	b.hs	0x1000d0580 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1cc>
1000d04f8:     	lsl	x9, x4, #2
1000d04fc:     	mov	w10, #-16
1000d0500:     	mov	x11, #0
1000d0504:     	lsr	x13, x8, #3
1000d0508:     	lsl	x12, x13, #7
1000d050c:     	mul	x14, x9, x13
1000d0510:     	ubfx	x13, x8, #1, #2
1000d0514:     	orr	x14, x14, x13
1000d0518:     	ldrb	w15, [x1, x14]
1000d051c:     	ubfiz	w14, w8, #2, #1
1000d0520:     	lsr	w15, w15, w14
1000d0524:     	and	w16, w15, #0xf
1000d0528:     	cmp	w16, #8
1000d052c:     	csel	w16, wzr, w10, lo
1000d0530:     	bfxil	w16, w15, #0, #4
1000d0534:     	scvtf	s0, w16
1000d0538:     	add	x15, x12, x11
1000d053c:     	orr	x15, x15, x13
1000d0540:     	ldrb	w15, [x0, x15]
1000d0544:     	lsr	w15, w15, w14
1000d0548:     	and	w16, w15, #0xf
1000d054c:     	cmp	w16, #8
1000d0550:     	csel	w16, wzr, w10, lo
1000d0554:     	bfxil	w16, w15, #0, #4
1000d0558:     	scvtf	s1, w16
1000d055c:     	ldr	s2, [x3, x11]
1000d0560:     	fmsub	s1, s1, s0, s2
1000d0564:     	str	s1, [x3, x11]
1000d0568:     	add	x11, x11, #4
1000d056c:     	cmp	x11, #128
1000d0570:     	b.ne	0x1000d0538 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000d0574:     	add	x8, x8, #1
1000d0578:     	cmp	x8, x2
1000d057c:     	b.ne	0x1000d0500 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000d0580:     	ldp	x20, x19, [sp, #16]
1000d0584:     	ldp	x22, x21, [sp], #32
1000d0588:     	ret

