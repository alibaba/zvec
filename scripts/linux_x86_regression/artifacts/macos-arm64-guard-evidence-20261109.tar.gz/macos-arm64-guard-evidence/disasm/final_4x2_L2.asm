00000001000bc09c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bc09c:     	sub	sp, sp, #176
1000bc0a0:     	stp	x28, x27, [sp, #80]
1000bc0a4:     	stp	x26, x25, [sp, #96]
1000bc0a8:     	stp	x24, x23, [sp, #112]
1000bc0ac:     	stp	x22, x21, [sp, #128]
1000bc0b0:     	stp	x20, x19, [sp, #144]
1000bc0b4:     	stp	x29, x30, [sp, #160]
1000bc0b8:     	add	x29, sp, #160
1000bc0bc:     	str	x3, [sp]
1000bc0c0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x8>
1000bc0c4:     	ldr	x8, [x8, #392]
1000bc0c8:     	ldr	x8, [x8]
1000bc0cc:     	str	x8, [sp, #72]
1000bc0d0:     	movi.2d	v0, #0000000000000000
1000bc0d4:     	stp	q0, q0, [sp, #32]
1000bc0d8:     	ands	x8, x2, #0xfffffffffffffffe
1000bc0dc:     	b.eq	0x1000bc280 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bc0e0:     	add	x8, x1, x8
1000bc0e4:     	str	x8, [sp, #8]
1000bc0e8:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x28>
1000bc0ec:     	add	x9, x9, #188
1000bc0f0:     	mov	x11, #0
1000bc0f4:     	ldp	w4, w23, [x1]
1000bc0f8:     	ubfx	x8, x4, #4, #4
1000bc0fc:     	stp	x1, x8, [sp, #16]
1000bc100:     	ubfx	x13, x4, #8, #4
1000bc104:     	and	x14, x4, #0xf
1000bc108:     	ubfx	x15, x4, #12, #4
1000bc10c:     	ubfx	x16, x4, #16, #4
1000bc110:     	ubfx	x17, x4, #20, #4
1000bc114:     	ubfx	x2, x4, #24, #4
1000bc118:     	lsr	x4, x4, #28
1000bc11c:     	and	x5, x23, #0xf
1000bc120:     	ubfx	x6, x23, #4, #4
1000bc124:     	ubfx	x7, x23, #8, #4
1000bc128:     	ubfx	x19, x23, #12, #4
1000bc12c:     	ubfx	x20, x23, #16, #4
1000bc130:     	ubfx	x21, x23, #20, #4
1000bc134:     	ubfx	x22, x23, #24, #4
1000bc138:     	lsr	x23, x23, #28
1000bc13c:     	ldr	w24, [x0, x11]
1000bc140:     	lsl	w25, w24, #4
1000bc144:     	and	x25, x25, #0xf0
1000bc148:     	orr	x26, x25, x14
1000bc14c:     	ldrb	w26, [x9, x26]
1000bc150:     	and	x27, x24, #0xf0
1000bc154:     	ldr	x8, [sp, #24]
1000bc158:     	orr	x28, x27, x8
1000bc15c:     	ldrb	w28, [x9, x28]
1000bc160:     	lsr	x30, x24, #4
1000bc164:     	and	x30, x30, #0xf0
1000bc168:     	orr	x8, x30, x13
1000bc16c:     	ldrb	w8, [x9, x8]
1000bc170:     	add	w26, w26, w28
1000bc174:     	add	w8, w26, w8
1000bc178:     	lsr	x26, x24, #8
1000bc17c:     	and	x26, x26, #0xf0
1000bc180:     	orr	x28, x26, x15
1000bc184:     	ldrb	w28, [x9, x28]
1000bc188:     	lsr	x3, x24, #12
1000bc18c:     	and	x3, x3, #0xf0
1000bc190:     	orr	x10, x3, x16
1000bc194:     	ldrb	w10, [x9, x10]
1000bc198:     	add	w8, w8, w28
1000bc19c:     	add	w8, w8, w10
1000bc1a0:     	lsr	x10, x24, #16
1000bc1a4:     	and	x10, x10, #0xf0
1000bc1a8:     	orr	x28, x10, x17
1000bc1ac:     	ldrb	w28, [x9, x28]
1000bc1b0:     	lsr	x1, x24, #20
1000bc1b4:     	and	x1, x1, #0xf0
1000bc1b8:     	orr	x12, x1, x2
1000bc1bc:     	ldrb	w12, [x9, x12]
1000bc1c0:     	add	w8, w8, w28
1000bc1c4:     	add	x28, sp, #32
1000bc1c8:     	add	w8, w8, w12
1000bc1cc:     	lsr	x12, x24, #24
1000bc1d0:     	and	x12, x12, #0xf0
1000bc1d4:     	orr	x24, x12, x4
1000bc1d8:     	ldrb	w24, [x9, x24]
1000bc1dc:     	add	w8, w8, w24
1000bc1e0:     	scvtf	s0, w8
1000bc1e4:     	add	x8, x28, x11
1000bc1e8:     	ldr	s1, [x8]
1000bc1ec:     	fadd	s0, s1, s0
1000bc1f0:     	orr	x24, x25, x5
1000bc1f4:     	ldrb	w24, [x9, x24]
1000bc1f8:     	orr	x25, x27, x6
1000bc1fc:     	ldrb	w25, [x9, x25]
1000bc200:     	orr	x27, x30, x7
1000bc204:     	ldrb	w27, [x9, x27]
1000bc208:     	add	w24, w24, w25
1000bc20c:     	add	w24, w24, w27
1000bc210:     	orr	x25, x26, x19
1000bc214:     	ldrb	w25, [x9, x25]
1000bc218:     	orr	x3, x3, x20
1000bc21c:     	ldrb	w3, [x9, x3]
1000bc220:     	orr	x10, x10, x21
1000bc224:     	ldrb	w10, [x9, x10]
1000bc228:     	add	w24, w24, w25
1000bc22c:     	add	w3, w24, w3
1000bc230:     	orr	x1, x1, x22
1000bc234:     	ldrb	w1, [x9, x1]
1000bc238:     	add	w10, w3, w10
1000bc23c:     	add	w10, w10, w1
1000bc240:     	orr	x12, x12, x23
1000bc244:     	ldrb	w12, [x9, x12]
1000bc248:     	add	w10, w10, w12
1000bc24c:     	scvtf	s1, w10
1000bc250:     	str	s0, [x8]
1000bc254:     	ldr	s0, [x8, #16]
1000bc258:     	fadd	s0, s0, s1
1000bc25c:     	str	s0, [x8, #16]
1000bc260:     	add	x11, x11, #4
1000bc264:     	cmp	x11, #16
1000bc268:     	b.ne	0x1000bc13c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bc26c:     	add	x0, x0, #16
1000bc270:     	ldp	x8, x1, [sp, #8]
1000bc274:     	add	x1, x1, #8
1000bc278:     	cmp	x1, x8
1000bc27c:     	b.ne	0x1000bc0f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bc280:     	ldp	q0, q1, [sp, #32]
1000bc284:     	ldr	x8, [sp]
1000bc288:     	stp	q0, q1, [x8]
1000bc28c:     	ldr	x8, [sp, #72]
1000bc290:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d8>
1000bc294:     	ldr	x9, [x9, #392]
1000bc298:     	ldr	x9, [x9]
1000bc29c:     	cmp	x9, x8
1000bc2a0:     	b.ne	0x1000bc2c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bc2a4:     	ldp	x29, x30, [sp, #160]
1000bc2a8:     	ldp	x20, x19, [sp, #144]
1000bc2ac:     	ldp	x22, x21, [sp, #128]
1000bc2b0:     	ldp	x24, x23, [sp, #112]
1000bc2b4:     	ldp	x26, x25, [sp, #96]
1000bc2b8:     	ldp	x28, x27, [sp, #80]
1000bc2bc:     	add	sp, sp, #176
1000bc2c0:     	ret
1000bc2c4:     	bl	0x100163694 <_strcmp+0x100163694>

