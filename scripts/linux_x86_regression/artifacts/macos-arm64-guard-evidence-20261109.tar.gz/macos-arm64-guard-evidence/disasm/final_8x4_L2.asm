00000001000c3700 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c3700:     	sub	sp, sp, #416
1000c3704:     	stp	x28, x27, [sp, #320]
1000c3708:     	stp	x26, x25, [sp, #336]
1000c370c:     	stp	x24, x23, [sp, #352]
1000c3710:     	stp	x22, x21, [sp, #368]
1000c3714:     	stp	x20, x19, [sp, #384]
1000c3718:     	stp	x29, x30, [sp, #400]
1000c371c:     	add	x29, sp, #400
1000c3720:     	str	x3, [sp]
1000c3724:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
1000c3728:     	ldr	x8, [x8, #392]
1000c372c:     	ldr	x8, [x8]
1000c3730:     	stur	x8, [x29, #-96]
1000c3734:     	movi.2d	v0, #0000000000000000
1000c3738:     	stp	q0, q0, [sp, #272]
1000c373c:     	lsl	x8, x2, #1
1000c3740:     	stp	q0, q0, [sp, #240]
1000c3744:     	stp	q0, q0, [sp, #208]
1000c3748:     	stp	q0, q0, [sp, #176]
1000c374c:     	ands	x8, x8, #0xfffffffffffffffc
1000c3750:     	b.eq	0x1000c3a2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c3754:     	add	x8, x1, x8
1000c3758:     	str	x8, [sp, #8]
1000c375c:     	add	x8, sp, #176
1000c3760:     	add	x27, x8, #64
1000c3764:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x300>
1000c3768:     	add	x11, x11, #700
1000c376c:     	mov	x12, #0
1000c3770:     	ldp	w8, w9, [x1]
1000c3774:     	ubfx	x10, x8, #8, #4
1000c3778:     	str	x10, [sp, #168]
1000c377c:     	ubfx	x10, x8, #16, #4
1000c3780:     	str	x10, [sp, #160]
1000c3784:     	ubfx	x10, x8, #24, #4
1000c3788:     	str	x10, [sp, #152]
1000c378c:     	ldp	w10, w17, [x1, #8]
1000c3790:     	str	x1, [sp, #16]
1000c3794:     	and	x14, x8, #0xf
1000c3798:     	ubfx	x13, x8, #4, #4
1000c379c:     	stp	x13, x14, [sp, #136]
1000c37a0:     	ubfx	x14, x8, #12, #4
1000c37a4:     	ubfx	x13, x8, #20, #4
1000c37a8:     	stp	x13, x14, [sp, #120]
1000c37ac:     	lsr	x8, x8, #28
1000c37b0:     	str	x8, [sp, #112]
1000c37b4:     	and	x8, x9, #0xf
1000c37b8:     	str	x8, [sp, #104]
1000c37bc:     	ubfx	x8, x9, #8, #4
1000c37c0:     	str	x8, [sp, #96]
1000c37c4:     	ubfx	x8, x9, #16, #4
1000c37c8:     	str	x8, [sp, #88]
1000c37cc:     	ubfx	x8, x9, #24, #4
1000c37d0:     	str	x8, [sp, #80]
1000c37d4:     	ubfx	x8, x9, #4, #4
1000c37d8:     	str	x8, [sp, #72]
1000c37dc:     	ubfx	x8, x9, #12, #4
1000c37e0:     	str	x8, [sp, #64]
1000c37e4:     	ubfx	x8, x9, #20, #4
1000c37e8:     	str	x8, [sp, #56]
1000c37ec:     	lsr	x8, x9, #28
1000c37f0:     	str	x8, [sp, #48]
1000c37f4:     	and	x9, x10, #0xf
1000c37f8:     	ubfx	x8, x10, #8, #4
1000c37fc:     	stp	x8, x9, [sp, #32]
1000c3800:     	ubfx	x8, x10, #16, #4
1000c3804:     	str	x8, [sp, #24]
1000c3808:     	ubfx	x28, x10, #24, #4
1000c380c:     	ubfx	x30, x10, #4, #4
1000c3810:     	ubfx	x8, x10, #12, #4
1000c3814:     	ubfx	x3, x10, #20, #4
1000c3818:     	lsr	x9, x10, #28
1000c381c:     	and	x1, x17, #0xf
1000c3820:     	ubfx	x10, x17, #8, #4
1000c3824:     	ubfx	x13, x17, #16, #4
1000c3828:     	ubfx	x26, x17, #24, #4
1000c382c:     	ubfx	x14, x17, #4, #4
1000c3830:     	ubfx	x15, x17, #12, #4
1000c3834:     	ubfx	x16, x17, #20, #4
1000c3838:     	lsr	x17, x17, #28
1000c383c:     	ldr	w20, [x0, x12]
1000c3840:     	lsl	w2, w20, #4
1000c3844:     	and	x2, x2, #0xf0
1000c3848:     	add	x5, x11, x2
1000c384c:     	and	x2, x20, #0xf0
1000c3850:     	add	x2, x11, x2
1000c3854:     	lsr	x4, x20, #4
1000c3858:     	and	x4, x4, #0xf0
1000c385c:     	add	x7, x11, x4
1000c3860:     	lsr	x4, x20, #8
1000c3864:     	and	x4, x4, #0xf0
1000c3868:     	add	x4, x11, x4
1000c386c:     	lsr	x6, x20, #12
1000c3870:     	and	x6, x6, #0xf0
1000c3874:     	add	x19, x11, x6
1000c3878:     	lsr	x6, x20, #16
1000c387c:     	and	x6, x6, #0xf0
1000c3880:     	add	x6, x11, x6
1000c3884:     	lsr	x21, x20, #20
1000c3888:     	and	x21, x21, #0xf0
1000c388c:     	add	x21, x11, x21
1000c3890:     	lsr	x20, x20, #24
1000c3894:     	and	x20, x20, #0xf0
1000c3898:     	ldr	x22, [sp, #144]
1000c389c:     	ldrb	w22, [x5, x22]
1000c38a0:     	add	x20, x11, x20
1000c38a4:     	ldp	x24, x23, [sp, #160]
1000c38a8:     	ldrb	w23, [x7, x23]
1000c38ac:     	ldrb	w24, [x19, x24]
1000c38b0:     	add	w22, w22, w23
1000c38b4:     	add	w22, w22, w24
1000c38b8:     	ldr	x23, [sp, #152]
1000c38bc:     	ldrb	w23, [x21, x23]
1000c38c0:     	ldr	x24, [sp, #136]
1000c38c4:     	ldrb	w24, [x2, x24]
1000c38c8:     	add	w22, w22, w23
1000c38cc:     	add	w22, w22, w24
1000c38d0:     	ldp	x24, x23, [sp, #120]
1000c38d4:     	ldrb	w23, [x4, x23]
1000c38d8:     	ldrb	w24, [x6, x24]
1000c38dc:     	add	w22, w22, w23
1000c38e0:     	add	w22, w22, w24
1000c38e4:     	ldr	x23, [sp, #112]
1000c38e8:     	ldrb	w23, [x20, x23]
1000c38ec:     	add	w22, w22, w23
1000c38f0:     	scvtf	s0, w22
1000c38f4:     	ldp	x23, x22, [sp, #96]
1000c38f8:     	ldrb	w22, [x5, x22]
1000c38fc:     	ldrb	w23, [x7, x23]
1000c3900:     	ldp	x25, x24, [sp, #80]
1000c3904:     	ldrb	w24, [x19, x24]
1000c3908:     	ldrb	w25, [x21, x25]
1000c390c:     	add	w22, w22, w23
1000c3910:     	ldr	x23, [sp, #72]
1000c3914:     	ldrb	w23, [x2, x23]
1000c3918:     	add	w22, w22, w24
1000c391c:     	ldr	x24, [sp, #64]
1000c3920:     	ldrb	w24, [x4, x24]
1000c3924:     	add	w22, w22, w25
1000c3928:     	ldr	x25, [sp, #56]
1000c392c:     	ldrb	w25, [x6, x25]
1000c3930:     	add	w22, w22, w23
1000c3934:     	add	w22, w22, w24
1000c3938:     	add	w22, w22, w25
1000c393c:     	ldr	x23, [sp, #48]
1000c3940:     	ldrb	w23, [x20, x23]
1000c3944:     	add	w22, w22, w23
1000c3948:     	scvtf	s1, w22
1000c394c:     	ldp	x23, x22, [sp, #32]
1000c3950:     	ldrb	w22, [x5, x22]
1000c3954:     	ldrb	w23, [x7, x23]
1000c3958:     	ldr	x24, [sp, #24]
1000c395c:     	ldrb	w24, [x19, x24]
1000c3960:     	add	w22, w22, w23
1000c3964:     	ldrb	w23, [x21, x28]
1000c3968:     	add	w22, w22, w24
1000c396c:     	ldrb	w24, [x2, x30]
1000c3970:     	add	w22, w22, w23
1000c3974:     	ldrb	w23, [x4, x8]
1000c3978:     	add	w22, w22, w24
1000c397c:     	ldrb	w24, [x6, x3]
1000c3980:     	add	w22, w22, w23
1000c3984:     	ldrb	w23, [x20, x9]
1000c3988:     	add	w22, w22, w24
1000c398c:     	add	w22, w22, w23
1000c3990:     	scvtf	s2, w22
1000c3994:     	ldrb	w5, [x5, x1]
1000c3998:     	ldrb	w7, [x7, x10]
1000c399c:     	ldrb	w19, [x19, x13]
1000c39a0:     	add	w5, w5, w7
1000c39a4:     	add	w5, w5, w19
1000c39a8:     	ldrb	w7, [x21, x26]
1000c39ac:     	ldrb	w2, [x2, x14]
1000c39b0:     	add	w5, w5, w7
1000c39b4:     	add	w2, w5, w2
1000c39b8:     	ldrb	w4, [x4, x15]
1000c39bc:     	ldrb	w5, [x6, x16]
1000c39c0:     	add	w2, w2, w4
1000c39c4:     	add	w2, w2, w5
1000c39c8:     	ldrb	w4, [x20, x17]
1000c39cc:     	add	w2, w2, w4
1000c39d0:     	add	x4, sp, #176
1000c39d4:     	scvtf	s3, w2
1000c39d8:     	add	x2, x27, x12
1000c39dc:     	ldur	s4, [x2, #-32]
1000c39e0:     	fadd	s1, s4, s1
1000c39e4:     	stur	s1, [x2, #-32]
1000c39e8:     	ldr	s1, [x2]
1000c39ec:     	fadd	s1, s1, s2
1000c39f0:     	str	s1, [x2]
1000c39f4:     	ldr	s1, [x2, #32]
1000c39f8:     	fadd	s1, s1, s3
1000c39fc:     	ldr	s2, [x4, x12]
1000c3a00:     	str	s1, [x2, #32]
1000c3a04:     	fadd	s0, s2, s0
1000c3a08:     	str	s0, [x4, x12]
1000c3a0c:     	add	x12, x12, #4
1000c3a10:     	cmp	x12, #32
1000c3a14:     	b.ne	0x1000c383c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3a18:     	add	x0, x0, #32
1000c3a1c:     	ldp	x8, x1, [sp, #8]
1000c3a20:     	add	x1, x1, #16
1000c3a24:     	cmp	x1, x8
1000c3a28:     	b.ne	0x1000c376c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c3a2c:     	ldp	q0, q1, [sp, #240]
1000c3a30:     	ldr	x8, [sp]
1000c3a34:     	stp	q0, q1, [x8, #64]
1000c3a38:     	ldp	q0, q1, [sp, #272]
1000c3a3c:     	stp	q0, q1, [x8, #96]
1000c3a40:     	ldp	q0, q1, [sp, #176]
1000c3a44:     	stp	q0, q1, [x8]
1000c3a48:     	ldp	q0, q1, [sp, #208]
1000c3a4c:     	stp	q0, q1, [x8, #32]
1000c3a50:     	ldur	x8, [x29, #-96]
1000c3a54:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000c3a58:     	ldr	x9, [x9, #392]
1000c3a5c:     	ldr	x9, [x9]
1000c3a60:     	cmp	x9, x8
1000c3a64:     	b.ne	0x1000c3a88 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c3a68:     	ldp	x29, x30, [sp, #400]
1000c3a6c:     	ldp	x20, x19, [sp, #384]
1000c3a70:     	ldp	x22, x21, [sp, #368]
1000c3a74:     	ldp	x24, x23, [sp, #352]
1000c3a78:     	ldp	x26, x25, [sp, #336]
1000c3a7c:     	ldp	x28, x27, [sp, #320]
1000c3a80:     	add	sp, sp, #416
1000c3a84:     	ret
1000c3a88:     	bl	0x100163694 <_strcmp+0x100163694>

