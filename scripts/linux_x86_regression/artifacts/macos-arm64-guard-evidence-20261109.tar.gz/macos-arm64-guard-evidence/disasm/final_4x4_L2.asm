00000001000bd828 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bd828:     	sub	sp, sp, #352
1000bd82c:     	stp	x28, x27, [sp, #256]
1000bd830:     	stp	x26, x25, [sp, #272]
1000bd834:     	stp	x24, x23, [sp, #288]
1000bd838:     	stp	x22, x21, [sp, #304]
1000bd83c:     	stp	x20, x19, [sp, #320]
1000bd840:     	stp	x29, x30, [sp, #336]
1000bd844:     	add	x29, sp, #336
1000bd848:     	str	x3, [sp]
1000bd84c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bd850:     	ldr	x8, [x8, #392]
1000bd854:     	ldr	x8, [x8]
1000bd858:     	stur	x8, [x29, #-96]
1000bd85c:     	movi.2d	v0, #0000000000000000
1000bd860:     	stp	q0, q0, [x29, #-128]
1000bd864:     	lsl	x8, x2, #1
1000bd868:     	stp	q0, q0, [x29, #-160]
1000bd86c:     	ands	x8, x8, #0xfffffffffffffffc
1000bd870:     	b.eq	0x1000bdb98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bd874:     	add	x8, x1, x8
1000bd878:     	str	x8, [sp, #8]
1000bd87c:     	sub	x8, x29, #160
1000bd880:     	add	x27, x8, #32
1000bd884:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bd888:     	add	x11, x11, #188
1000bd88c:     	mov	x12, #0
1000bd890:     	ldp	w8, w9, [x1]
1000bd894:     	ubfx	x10, x8, #4, #4
1000bd898:     	str	x10, [sp, #168]
1000bd89c:     	ubfx	x10, x8, #8, #4
1000bd8a0:     	str	x10, [sp, #160]
1000bd8a4:     	and	x10, x8, #0xf
1000bd8a8:     	str	x10, [sp, #152]
1000bd8ac:     	ubfx	x10, x8, #12, #4
1000bd8b0:     	str	x10, [sp, #144]
1000bd8b4:     	ubfx	x10, x8, #16, #4
1000bd8b8:     	str	x10, [sp, #136]
1000bd8bc:     	ubfx	x10, x8, #20, #4
1000bd8c0:     	str	x10, [sp, #128]
1000bd8c4:     	ubfx	x10, x8, #24, #4
1000bd8c8:     	lsr	x8, x8, #28
1000bd8cc:     	stp	x8, x10, [sp, #112]
1000bd8d0:     	and	x10, x9, #0xf
1000bd8d4:     	ubfx	x8, x9, #4, #4
1000bd8d8:     	stp	x8, x10, [sp, #96]
1000bd8dc:     	ubfx	x10, x9, #8, #4
1000bd8e0:     	ubfx	x8, x9, #12, #4
1000bd8e4:     	stp	x8, x10, [sp, #80]
1000bd8e8:     	ubfx	x10, x9, #16, #4
1000bd8ec:     	ubfx	x8, x9, #20, #4
1000bd8f0:     	stp	x8, x10, [sp, #64]
1000bd8f4:     	ubfx	x10, x9, #24, #4
1000bd8f8:     	lsr	x8, x9, #28
1000bd8fc:     	stp	x8, x10, [sp, #48]
1000bd900:     	ldp	w9, w17, [x1, #8]
1000bd904:     	and	x10, x9, #0xf
1000bd908:     	ubfx	x8, x9, #4, #4
1000bd90c:     	stp	x8, x10, [sp, #32]
1000bd910:     	ubfx	x8, x9, #8, #4
1000bd914:     	stp	x1, x8, [sp, #16]
1000bd918:     	ubfx	x28, x9, #12, #4
1000bd91c:     	ubfx	x30, x9, #16, #4
1000bd920:     	ubfx	x8, x9, #20, #4
1000bd924:     	ubfx	x3, x9, #24, #4
1000bd928:     	lsr	x9, x9, #28
1000bd92c:     	and	x1, x17, #0xf
1000bd930:     	ubfx	x10, x17, #4, #4
1000bd934:     	ubfx	x13, x17, #8, #4
1000bd938:     	ubfx	x26, x17, #12, #4
1000bd93c:     	ubfx	x14, x17, #16, #4
1000bd940:     	ubfx	x15, x17, #20, #4
1000bd944:     	ubfx	x16, x17, #24, #4
1000bd948:     	lsr	x17, x17, #28
1000bd94c:     	ldr	w21, [x0, x12]
1000bd950:     	lsl	w2, w21, #4
1000bd954:     	and	x2, x2, #0xf0
1000bd958:     	ldp	x4, x19, [sp, #152]
1000bd95c:     	orr	x4, x2, x4
1000bd960:     	ldrb	w6, [x11, x4]
1000bd964:     	and	x4, x21, #0xf0
1000bd968:     	ldr	x5, [sp, #168]
1000bd96c:     	orr	x5, x4, x5
1000bd970:     	ldrb	w7, [x11, x5]
1000bd974:     	lsr	x5, x21, #4
1000bd978:     	and	x5, x5, #0xf0
1000bd97c:     	orr	x19, x5, x19
1000bd980:     	ldrb	w19, [x11, x19]
1000bd984:     	add	w6, w6, w7
1000bd988:     	add	w19, w6, w19
1000bd98c:     	lsr	x6, x21, #8
1000bd990:     	and	x6, x6, #0xf0
1000bd994:     	ldp	x22, x7, [sp, #136]
1000bd998:     	orr	x7, x6, x7
1000bd99c:     	ldrb	w20, [x11, x7]
1000bd9a0:     	lsr	x7, x21, #12
1000bd9a4:     	and	x7, x7, #0xf0
1000bd9a8:     	orr	x22, x7, x22
1000bd9ac:     	ldrb	w22, [x11, x22]
1000bd9b0:     	add	w19, w19, w20
1000bd9b4:     	add	w22, w19, w22
1000bd9b8:     	lsr	x19, x21, #16
1000bd9bc:     	and	x19, x19, #0xf0
1000bd9c0:     	ldp	x24, x20, [sp, #120]
1000bd9c4:     	orr	x20, x19, x20
1000bd9c8:     	ldrb	w23, [x11, x20]
1000bd9cc:     	lsr	x20, x21, #20
1000bd9d0:     	and	x20, x20, #0xf0
1000bd9d4:     	orr	x24, x20, x24
1000bd9d8:     	ldrb	w24, [x11, x24]
1000bd9dc:     	add	w22, w22, w23
1000bd9e0:     	add	w22, w22, w24
1000bd9e4:     	lsr	x21, x21, #24
1000bd9e8:     	and	x21, x21, #0xf0
1000bd9ec:     	ldr	x23, [sp, #112]
1000bd9f0:     	orr	x23, x21, x23
1000bd9f4:     	ldrb	w23, [x11, x23]
1000bd9f8:     	add	w22, w22, w23
1000bd9fc:     	scvtf	s0, w22
1000bda00:     	ldp	x23, x22, [sp, #96]
1000bda04:     	orr	x22, x2, x22
1000bda08:     	ldrb	w22, [x11, x22]
1000bda0c:     	orr	x23, x4, x23
1000bda10:     	ldrb	w23, [x11, x23]
1000bda14:     	ldr	x24, [sp, #88]
1000bda18:     	orr	x24, x5, x24
1000bda1c:     	ldrb	w24, [x11, x24]
1000bda20:     	add	w22, w22, w23
1000bda24:     	add	w22, w22, w24
1000bda28:     	ldp	x24, x23, [sp, #72]
1000bda2c:     	orr	x23, x6, x23
1000bda30:     	ldrb	w23, [x11, x23]
1000bda34:     	orr	x24, x7, x24
1000bda38:     	ldrb	w24, [x11, x24]
1000bda3c:     	ldr	x25, [sp, #64]
1000bda40:     	orr	x25, x19, x25
1000bda44:     	ldrb	w25, [x11, x25]
1000bda48:     	add	w22, w22, w23
1000bda4c:     	add	w22, w22, w24
1000bda50:     	ldr	x23, [sp, #56]
1000bda54:     	orr	x23, x20, x23
1000bda58:     	ldrb	w23, [x11, x23]
1000bda5c:     	add	w22, w22, w25
1000bda60:     	add	w22, w22, w23
1000bda64:     	ldr	x23, [sp, #48]
1000bda68:     	orr	x23, x21, x23
1000bda6c:     	ldrb	w23, [x11, x23]
1000bda70:     	add	w22, w22, w23
1000bda74:     	scvtf	s1, w22
1000bda78:     	ldp	x23, x22, [sp, #32]
1000bda7c:     	orr	x22, x2, x22
1000bda80:     	ldrb	w22, [x11, x22]
1000bda84:     	orr	x23, x4, x23
1000bda88:     	ldrb	w23, [x11, x23]
1000bda8c:     	ldr	x24, [sp, #24]
1000bda90:     	orr	x24, x5, x24
1000bda94:     	ldrb	w24, [x11, x24]
1000bda98:     	add	w22, w22, w23
1000bda9c:     	add	w22, w22, w24
1000bdaa0:     	orr	x23, x6, x28
1000bdaa4:     	ldrb	w23, [x11, x23]
1000bdaa8:     	orr	x24, x7, x30
1000bdaac:     	ldrb	w24, [x11, x24]
1000bdab0:     	orr	x25, x19, x8
1000bdab4:     	ldrb	w25, [x11, x25]
1000bdab8:     	add	w22, w22, w23
1000bdabc:     	orr	x23, x20, x3
1000bdac0:     	ldrb	w23, [x11, x23]
1000bdac4:     	add	w22, w22, w24
1000bdac8:     	add	w22, w22, w25
1000bdacc:     	add	w22, w22, w23
1000bdad0:     	orr	x23, x21, x9
1000bdad4:     	ldrb	w23, [x11, x23]
1000bdad8:     	add	w22, w22, w23
1000bdadc:     	scvtf	s2, w22
1000bdae0:     	orr	x2, x2, x1
1000bdae4:     	ldrb	w2, [x11, x2]
1000bdae8:     	orr	x4, x4, x10
1000bdaec:     	ldrb	w4, [x11, x4]
1000bdaf0:     	orr	x5, x5, x13
1000bdaf4:     	ldrb	w5, [x11, x5]
1000bdaf8:     	add	w2, w2, w4
1000bdafc:     	add	w2, w2, w5
1000bdb00:     	orr	x4, x6, x26
1000bdb04:     	ldrb	w4, [x11, x4]
1000bdb08:     	orr	x5, x7, x14
1000bdb0c:     	ldrb	w5, [x11, x5]
1000bdb10:     	add	w2, w2, w4
1000bdb14:     	orr	x4, x19, x15
1000bdb18:     	ldrb	w4, [x11, x4]
1000bdb1c:     	add	w2, w2, w5
1000bdb20:     	orr	x5, x20, x16
1000bdb24:     	ldrb	w5, [x11, x5]
1000bdb28:     	add	w2, w2, w4
1000bdb2c:     	add	w2, w2, w5
1000bdb30:     	orr	x4, x21, x17
1000bdb34:     	ldrb	w4, [x11, x4]
1000bdb38:     	add	w2, w2, w4
1000bdb3c:     	sub	x4, x29, #160
1000bdb40:     	scvtf	s3, w2
1000bdb44:     	add	x2, x27, x12
1000bdb48:     	ldur	s4, [x2, #-16]
1000bdb4c:     	fadd	s1, s4, s1
1000bdb50:     	stur	s1, [x2, #-16]
1000bdb54:     	ldr	s1, [x2]
1000bdb58:     	fadd	s1, s1, s2
1000bdb5c:     	str	s1, [x2]
1000bdb60:     	ldr	s1, [x2, #16]
1000bdb64:     	fadd	s1, s1, s3
1000bdb68:     	ldr	s2, [x4, x12]
1000bdb6c:     	str	s1, [x2, #16]
1000bdb70:     	fadd	s0, s2, s0
1000bdb74:     	str	s0, [x4, x12]
1000bdb78:     	add	x12, x12, #4
1000bdb7c:     	cmp	x12, #16
1000bdb80:     	b.ne	0x1000bd94c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bdb84:     	add	x0, x0, #16
1000bdb88:     	ldp	x8, x1, [sp, #8]
1000bdb8c:     	add	x1, x1, #16
1000bdb90:     	cmp	x1, x8
1000bdb94:     	b.ne	0x1000bd88c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bdb98:     	ldp	q0, q1, [x29, #-160]
1000bdb9c:     	ldr	x8, [sp]
1000bdba0:     	stp	q0, q1, [x8]
1000bdba4:     	ldp	q0, q1, [x29, #-128]
1000bdba8:     	stp	q0, q1, [x8, #32]
1000bdbac:     	ldur	x8, [x29, #-96]
1000bdbb0:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18c>
1000bdbb4:     	ldr	x9, [x9, #392]
1000bdbb8:     	ldr	x9, [x9]
1000bdbbc:     	cmp	x9, x8
1000bdbc0:     	b.ne	0x1000bdbe4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bdbc4:     	ldp	x29, x30, [sp, #336]
1000bdbc8:     	ldp	x20, x19, [sp, #320]
1000bdbcc:     	ldp	x22, x21, [sp, #304]
1000bdbd0:     	ldp	x24, x23, [sp, #288]
1000bdbd4:     	ldp	x26, x25, [sp, #272]
1000bdbd8:     	ldp	x28, x27, [sp, #256]
1000bdbdc:     	add	sp, sp, #352
1000bdbe0:     	ret
1000bdbe4:     	bl	0x100163694 <_strcmp+0x100163694>

