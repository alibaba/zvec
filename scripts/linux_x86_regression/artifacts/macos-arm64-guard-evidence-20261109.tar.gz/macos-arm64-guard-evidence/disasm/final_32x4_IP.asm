00000001000d3e04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d3e04:     	stp	x28, x27, [sp, #-96]!
1000d3e08:     	stp	x26, x25, [sp, #16]
1000d3e0c:     	stp	x24, x23, [sp, #32]
1000d3e10:     	stp	x22, x21, [sp, #48]
1000d3e14:     	stp	x20, x19, [sp, #64]
1000d3e18:     	stp	x29, x30, [sp, #80]
1000d3e1c:     	add	x29, sp, #80
1000d3e20:     	sub	sp, sp, #704
1000d3e24:     	str	x3, [sp]
1000d3e28:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d3e2c:     	ldr	x8, [x8, #392]
1000d3e30:     	ldr	x8, [x8]
1000d3e34:     	stur	x8, [x29, #-96]
1000d3e38:     	movi.2d	v0, #0000000000000000
1000d3e3c:     	stp	q0, q0, [sp, #656]
1000d3e40:     	lsl	x8, x2, #1
1000d3e44:     	stp	q0, q0, [sp, #624]
1000d3e48:     	stp	q0, q0, [sp, #592]
1000d3e4c:     	stp	q0, q0, [sp, #560]
1000d3e50:     	stp	q0, q0, [sp, #528]
1000d3e54:     	stp	q0, q0, [sp, #496]
1000d3e58:     	stp	q0, q0, [sp, #464]
1000d3e5c:     	stp	q0, q0, [sp, #432]
1000d3e60:     	stp	q0, q0, [sp, #400]
1000d3e64:     	stp	q0, q0, [sp, #368]
1000d3e68:     	stp	q0, q0, [sp, #336]
1000d3e6c:     	stp	q0, q0, [sp, #304]
1000d3e70:     	stp	q0, q0, [sp, #272]
1000d3e74:     	stp	q0, q0, [sp, #240]
1000d3e78:     	stp	q0, q0, [sp, #208]
1000d3e7c:     	stp	q0, q0, [sp, #176]
1000d3e80:     	ands	x8, x8, #0xfffffffffffffffc
1000d3e84:     	b.eq	0x1000d4160 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d3e88:     	add	x8, x1, x8
1000d3e8c:     	str	x8, [sp, #8]
1000d3e90:     	add	x8, sp, #176
1000d3e94:     	add	x27, x8, #256
1000d3e98:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d3e9c:     	add	x11, x11, #1980
1000d3ea0:     	mov	x12, #0
1000d3ea4:     	ldp	w8, w9, [x1]
1000d3ea8:     	ubfx	x10, x8, #8, #4
1000d3eac:     	str	x10, [sp, #168]
1000d3eb0:     	ubfx	x10, x8, #16, #4
1000d3eb4:     	str	x10, [sp, #160]
1000d3eb8:     	ubfx	x10, x8, #24, #4
1000d3ebc:     	str	x10, [sp, #152]
1000d3ec0:     	ldp	w10, w17, [x1, #8]
1000d3ec4:     	str	x1, [sp, #16]
1000d3ec8:     	and	x14, x8, #0xf
1000d3ecc:     	ubfx	x13, x8, #4, #4
1000d3ed0:     	stp	x13, x14, [sp, #136]
1000d3ed4:     	ubfx	x14, x8, #12, #4
1000d3ed8:     	ubfx	x13, x8, #20, #4
1000d3edc:     	stp	x13, x14, [sp, #120]
1000d3ee0:     	lsr	x8, x8, #28
1000d3ee4:     	str	x8, [sp, #112]
1000d3ee8:     	and	x8, x9, #0xf
1000d3eec:     	str	x8, [sp, #104]
1000d3ef0:     	ubfx	x8, x9, #8, #4
1000d3ef4:     	str	x8, [sp, #96]
1000d3ef8:     	ubfx	x8, x9, #16, #4
1000d3efc:     	str	x8, [sp, #88]
1000d3f00:     	ubfx	x8, x9, #24, #4
1000d3f04:     	str	x8, [sp, #80]
1000d3f08:     	ubfx	x8, x9, #4, #4
1000d3f0c:     	str	x8, [sp, #72]
1000d3f10:     	ubfx	x8, x9, #12, #4
1000d3f14:     	str	x8, [sp, #64]
1000d3f18:     	ubfx	x8, x9, #20, #4
1000d3f1c:     	str	x8, [sp, #56]
1000d3f20:     	lsr	x8, x9, #28
1000d3f24:     	str	x8, [sp, #48]
1000d3f28:     	and	x9, x10, #0xf
1000d3f2c:     	ubfx	x8, x10, #8, #4
1000d3f30:     	stp	x8, x9, [sp, #32]
1000d3f34:     	ubfx	x8, x10, #16, #4
1000d3f38:     	str	x8, [sp, #24]
1000d3f3c:     	ubfx	x28, x10, #24, #4
1000d3f40:     	ubfx	x30, x10, #4, #4
1000d3f44:     	ubfx	x3, x10, #12, #4
1000d3f48:     	ubfx	x8, x10, #20, #4
1000d3f4c:     	lsr	x9, x10, #28
1000d3f50:     	and	x1, x17, #0xf
1000d3f54:     	ubfx	x10, x17, #8, #4
1000d3f58:     	ubfx	x13, x17, #16, #4
1000d3f5c:     	ubfx	x26, x17, #24, #4
1000d3f60:     	ubfx	x14, x17, #4, #4
1000d3f64:     	ubfx	x15, x17, #12, #4
1000d3f68:     	ubfx	x16, x17, #20, #4
1000d3f6c:     	lsr	x17, x17, #28
1000d3f70:     	ldr	w20, [x0, x12]
1000d3f74:     	lsl	w2, w20, #4
1000d3f78:     	and	x2, x2, #0xf0
1000d3f7c:     	add	x5, x11, x2
1000d3f80:     	and	x2, x20, #0xf0
1000d3f84:     	add	x2, x11, x2
1000d3f88:     	lsr	x4, x20, #4
1000d3f8c:     	and	x4, x4, #0xf0
1000d3f90:     	add	x7, x11, x4
1000d3f94:     	lsr	x4, x20, #8
1000d3f98:     	and	x4, x4, #0xf0
1000d3f9c:     	add	x4, x11, x4
1000d3fa0:     	lsr	x6, x20, #12
1000d3fa4:     	and	x6, x6, #0xf0
1000d3fa8:     	add	x19, x11, x6
1000d3fac:     	lsr	x6, x20, #16
1000d3fb0:     	and	x6, x6, #0xf0
1000d3fb4:     	add	x6, x11, x6
1000d3fb8:     	lsr	x21, x20, #20
1000d3fbc:     	and	x21, x21, #0xf0
1000d3fc0:     	add	x21, x11, x21
1000d3fc4:     	lsr	x20, x20, #24
1000d3fc8:     	and	x20, x20, #0xf0
1000d3fcc:     	ldr	x22, [sp, #144]
1000d3fd0:     	ldrsb	w22, [x5, x22]
1000d3fd4:     	add	x20, x11, x20
1000d3fd8:     	ldp	x24, x23, [sp, #160]
1000d3fdc:     	ldrsb	w23, [x7, x23]
1000d3fe0:     	ldrsb	w24, [x19, x24]
1000d3fe4:     	add	w22, w22, w23
1000d3fe8:     	add	w22, w22, w24
1000d3fec:     	ldr	x23, [sp, #152]
1000d3ff0:     	ldrsb	w23, [x21, x23]
1000d3ff4:     	ldr	x24, [sp, #136]
1000d3ff8:     	ldrsb	w24, [x2, x24]
1000d3ffc:     	add	w22, w22, w23
1000d4000:     	add	w22, w22, w24
1000d4004:     	ldp	x24, x23, [sp, #120]
1000d4008:     	ldrsb	w23, [x4, x23]
1000d400c:     	ldrsb	w24, [x6, x24]
1000d4010:     	add	w22, w22, w23
1000d4014:     	add	w22, w22, w24
1000d4018:     	ldr	x23, [sp, #112]
1000d401c:     	ldrsb	w23, [x20, x23]
1000d4020:     	add	w22, w22, w23
1000d4024:     	scvtf	s0, w22
1000d4028:     	ldp	x23, x22, [sp, #96]
1000d402c:     	ldrsb	w22, [x5, x22]
1000d4030:     	ldrsb	w23, [x7, x23]
1000d4034:     	ldp	x25, x24, [sp, #80]
1000d4038:     	ldrsb	w24, [x19, x24]
1000d403c:     	ldrsb	w25, [x21, x25]
1000d4040:     	add	w22, w22, w23
1000d4044:     	ldr	x23, [sp, #72]
1000d4048:     	ldrsb	w23, [x2, x23]
1000d404c:     	add	w22, w22, w24
1000d4050:     	ldr	x24, [sp, #64]
1000d4054:     	ldrsb	w24, [x4, x24]
1000d4058:     	add	w22, w22, w25
1000d405c:     	ldr	x25, [sp, #56]
1000d4060:     	ldrsb	w25, [x6, x25]
1000d4064:     	add	w22, w22, w23
1000d4068:     	add	w22, w22, w24
1000d406c:     	add	w22, w22, w25
1000d4070:     	ldr	x23, [sp, #48]
1000d4074:     	ldrsb	w23, [x20, x23]
1000d4078:     	add	w22, w22, w23
1000d407c:     	scvtf	s1, w22
1000d4080:     	ldp	x23, x22, [sp, #32]
1000d4084:     	ldrsb	w22, [x5, x22]
1000d4088:     	ldrsb	w23, [x7, x23]
1000d408c:     	ldr	x24, [sp, #24]
1000d4090:     	ldrsb	w24, [x19, x24]
1000d4094:     	add	w22, w22, w23
1000d4098:     	ldrsb	w23, [x21, x28]
1000d409c:     	add	w22, w22, w24
1000d40a0:     	ldrsb	w24, [x2, x30]
1000d40a4:     	add	w22, w22, w23
1000d40a8:     	ldrsb	w23, [x4, x3]
1000d40ac:     	add	w22, w22, w24
1000d40b0:     	ldrsb	w24, [x6, x8]
1000d40b4:     	add	w22, w22, w23
1000d40b8:     	ldrsb	w23, [x20, x9]
1000d40bc:     	add	w22, w22, w24
1000d40c0:     	add	w22, w22, w23
1000d40c4:     	scvtf	s2, w22
1000d40c8:     	ldrsb	w5, [x5, x1]
1000d40cc:     	ldrsb	w7, [x7, x10]
1000d40d0:     	ldrsb	w19, [x19, x13]
1000d40d4:     	add	w5, w5, w7
1000d40d8:     	add	w5, w5, w19
1000d40dc:     	ldrsb	w7, [x21, x26]
1000d40e0:     	ldrsb	w2, [x2, x14]
1000d40e4:     	add	w5, w5, w7
1000d40e8:     	add	w2, w5, w2
1000d40ec:     	ldrsb	w4, [x4, x15]
1000d40f0:     	ldrsb	w5, [x6, x16]
1000d40f4:     	add	w2, w2, w4
1000d40f8:     	add	w2, w2, w5
1000d40fc:     	ldrsb	w4, [x20, x17]
1000d4100:     	add	w2, w2, w4
1000d4104:     	add	x4, sp, #176
1000d4108:     	scvtf	s3, w2
1000d410c:     	add	x2, x27, x12
1000d4110:     	ldur	s4, [x2, #-128]
1000d4114:     	fadd	s1, s4, s1
1000d4118:     	stur	s1, [x2, #-128]
1000d411c:     	ldr	s1, [x2]
1000d4120:     	fadd	s1, s1, s2
1000d4124:     	str	s1, [x2]
1000d4128:     	ldr	s1, [x2, #128]
1000d412c:     	fadd	s1, s1, s3
1000d4130:     	ldr	s2, [x4, x12]
1000d4134:     	str	s1, [x2, #128]
1000d4138:     	fadd	s0, s2, s0
1000d413c:     	str	s0, [x4, x12]
1000d4140:     	add	x12, x12, #4
1000d4144:     	cmp	x12, #128
1000d4148:     	b.ne	0x1000d3f70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d414c:     	add	x0, x0, #128
1000d4150:     	ldp	x8, x1, [sp, #8]
1000d4154:     	add	x1, x1, #16
1000d4158:     	cmp	x1, x8
1000d415c:     	b.ne	0x1000d3ea0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d4160:     	add	x1, sp, #176
1000d4164:     	ldr	x0, [sp]
1000d4168:     	mov	w2, #512
1000d416c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d4170:     	ldur	x8, [x29, #-96]
1000d4174:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 8ul, false>(char const*)+0x228>
1000d4178:     	ldr	x9, [x9, #392]
1000d417c:     	ldr	x9, [x9]
1000d4180:     	cmp	x9, x8
1000d4184:     	b.ne	0x1000d41a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d4188:     	add	sp, sp, #704
1000d418c:     	ldp	x29, x30, [sp, #80]
1000d4190:     	ldp	x20, x19, [sp, #64]
1000d4194:     	ldp	x22, x21, [sp, #48]
1000d4198:     	ldp	x24, x23, [sp, #32]
1000d419c:     	ldp	x26, x25, [sp, #16]
1000d41a0:     	ldp	x28, x27, [sp], #96
1000d41a4:     	ret
1000d41a8:     	bl	0x100163694 <_strcmp+0x100163694>

