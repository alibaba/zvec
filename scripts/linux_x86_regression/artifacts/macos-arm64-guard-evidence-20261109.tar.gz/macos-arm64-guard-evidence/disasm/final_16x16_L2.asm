00000001000ce9a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce9a8:     	stp	x28, x27, [sp, #-64]!
1000ce9ac:     	stp	x22, x21, [sp, #16]
1000ce9b0:     	stp	x20, x19, [sp, #32]
1000ce9b4:     	stp	x29, x30, [sp, #48]
1000ce9b8:     	add	x29, sp, #48
1000ce9bc:     	sub	sp, sp, #1040
1000ce9c0:     	mov	x19, x3
1000ce9c4:     	mov	x20, x1
1000ce9c8:     	mov	x21, x0
1000ce9cc:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf4>
1000ce9d0:     	ldr	x8, [x8, #392]
1000ce9d4:     	ldr	x8, [x8]
1000ce9d8:     	stur	x8, [x29, #-56]
1000ce9dc:     	lsl	x8, x2, #3
1000ce9e0:     	and	x22, x8, #0xfffffffffffffff0
1000ce9e4:     	add	x0, sp, #8
1000ce9e8:     	mov	w1, #1024
1000ce9ec:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000ce9f0:     	cbz	x22, 0x1000ceb08 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000ce9f4:     	add	x8, x20, x22
1000ce9f8:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x118>
1000ce9fc:     	add	x9, x9, #1212
1000cea00:     	mov	x10, #0
1000cea04:     	add	x11, sp, #8
1000cea08:     	mov	x12, #0
1000cea0c:     	ldr	w2, [x21, x10, lsl #2]
1000cea10:     	lsl	w13, w2, #4
1000cea14:     	and	x13, x13, #0xf0
1000cea18:     	and	x14, x2, #0xf0
1000cea1c:     	lsr	x15, x2, #4
1000cea20:     	and	x15, x15, #0xf0
1000cea24:     	lsr	x16, x2, #8
1000cea28:     	and	x16, x16, #0xf0
1000cea2c:     	lsr	x17, x2, #12
1000cea30:     	and	x17, x17, #0xf0
1000cea34:     	lsr	x0, x2, #16
1000cea38:     	and	x0, x0, #0xf0
1000cea3c:     	lsr	x1, x2, #20
1000cea40:     	and	x1, x1, #0xf0
1000cea44:     	lsr	x2, x2, #24
1000cea48:     	and	x2, x2, #0xf0
1000cea4c:     	mov	x3, x11
1000cea50:     	ldr	w4, [x20, x12]
1000cea54:     	and	x5, x4, #0xf
1000cea58:     	orr	x5, x13, x5
1000cea5c:     	ldrb	w5, [x9, x5]
1000cea60:     	ubfx	x6, x4, #4, #4
1000cea64:     	orr	x6, x14, x6
1000cea68:     	ldrb	w6, [x9, x6]
1000cea6c:     	ubfx	x7, x4, #8, #4
1000cea70:     	orr	x7, x15, x7
1000cea74:     	ldrb	w7, [x9, x7]
1000cea78:     	add	w5, w5, w6
1000cea7c:     	add	w5, w5, w7
1000cea80:     	ubfx	x6, x4, #12, #4
1000cea84:     	orr	x6, x16, x6
1000cea88:     	ldrb	w6, [x9, x6]
1000cea8c:     	ubfx	x7, x4, #16, #4
1000cea90:     	orr	x7, x17, x7
1000cea94:     	ldrb	w7, [x9, x7]
1000cea98:     	add	w5, w5, w6
1000cea9c:     	add	w5, w5, w7
1000ceaa0:     	ubfx	x6, x4, #20, #4
1000ceaa4:     	orr	x6, x0, x6
1000ceaa8:     	ldrb	w6, [x9, x6]
1000ceaac:     	ubfx	x7, x4, #24, #4
1000ceab0:     	orr	x7, x1, x7
1000ceab4:     	ldrb	w7, [x9, x7]
1000ceab8:     	add	w5, w5, w6
1000ceabc:     	add	w5, w5, w7
1000ceac0:     	orr	x4, x2, x4, lsr #28
1000ceac4:     	ldrb	w4, [x9, x4]
1000ceac8:     	add	w4, w5, w4
1000ceacc:     	scvtf	s0, w4
1000cead0:     	ldr	s1, [x3]
1000cead4:     	fadd	s0, s1, s0
1000cead8:     	str	s0, [x3], #64
1000ceadc:     	add	x12, x12, #4
1000ceae0:     	cmp	x12, #64
1000ceae4:     	b.ne	0x1000cea50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000ceae8:     	add	x10, x10, #1
1000ceaec:     	add	x11, x11, #4
1000ceaf0:     	cmp	x10, #16
1000ceaf4:     	b.ne	0x1000cea08 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000ceaf8:     	add	x21, x21, #64
1000ceafc:     	add	x20, x20, #64
1000ceb00:     	cmp	x20, x8
1000ceb04:     	b.ne	0x1000cea00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000ceb08:     	add	x1, sp, #8
1000ceb0c:     	mov	x0, x19
1000ceb10:     	mov	w2, #1024
1000ceb14:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ceb18:     	ldur	x8, [x29, #-56]
1000ceb1c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000ceb20:     	ldr	x9, [x9, #392]
1000ceb24:     	ldr	x9, [x9]
1000ceb28:     	cmp	x9, x8
1000ceb2c:     	b.ne	0x1000ceb48 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000ceb30:     	add	sp, sp, #1040
1000ceb34:     	ldp	x29, x30, [sp, #48]
1000ceb38:     	ldp	x20, x19, [sp, #32]
1000ceb3c:     	ldp	x22, x21, [sp, #16]
1000ceb40:     	ldp	x28, x27, [sp], #64
1000ceb44:     	ret
1000ceb48:     	bl	0x100163694 <_strcmp+0x100163694>

