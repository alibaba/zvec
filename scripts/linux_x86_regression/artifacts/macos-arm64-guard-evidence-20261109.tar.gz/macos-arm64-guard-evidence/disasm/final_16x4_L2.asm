00000001000ca768 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ca768:     	stp	x28, x27, [sp, #-96]!
1000ca76c:     	stp	x26, x25, [sp, #16]
1000ca770:     	stp	x24, x23, [sp, #32]
1000ca774:     	stp	x22, x21, [sp, #48]
1000ca778:     	stp	x20, x19, [sp, #64]
1000ca77c:     	stp	x29, x30, [sp, #80]
1000ca780:     	add	x29, sp, #80
1000ca784:     	sub	sp, sp, #448
1000ca788:     	str	x3, [sp]
1000ca78c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000ca790:     	ldr	x8, [x8, #392]
1000ca794:     	ldr	x8, [x8]
1000ca798:     	stur	x8, [x29, #-96]
1000ca79c:     	movi.2d	v0, #0000000000000000
1000ca7a0:     	stp	q0, q0, [sp, #400]
1000ca7a4:     	lsl	x8, x2, #1
1000ca7a8:     	stp	q0, q0, [sp, #368]
1000ca7ac:     	stp	q0, q0, [sp, #336]
1000ca7b0:     	stp	q0, q0, [sp, #304]
1000ca7b4:     	stp	q0, q0, [sp, #272]
1000ca7b8:     	stp	q0, q0, [sp, #240]
1000ca7bc:     	stp	q0, q0, [sp, #208]
1000ca7c0:     	stp	q0, q0, [sp, #176]
1000ca7c4:     	ands	x8, x8, #0xfffffffffffffffc
1000ca7c8:     	b.eq	0x1000caaa4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000ca7cc:     	add	x8, x1, x8
1000ca7d0:     	str	x8, [sp, #8]
1000ca7d4:     	add	x8, sp, #176
1000ca7d8:     	add	x27, x8, #128
1000ca7dc:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000ca7e0:     	add	x11, x11, #1212
1000ca7e4:     	mov	x12, #0
1000ca7e8:     	ldp	w8, w9, [x1]
1000ca7ec:     	ubfx	x10, x8, #8, #4
1000ca7f0:     	str	x10, [sp, #168]
1000ca7f4:     	ubfx	x10, x8, #16, #4
1000ca7f8:     	str	x10, [sp, #160]
1000ca7fc:     	ubfx	x10, x8, #24, #4
1000ca800:     	str	x10, [sp, #152]
1000ca804:     	ldp	w10, w17, [x1, #8]
1000ca808:     	str	x1, [sp, #16]
1000ca80c:     	and	x14, x8, #0xf
1000ca810:     	ubfx	x13, x8, #4, #4
1000ca814:     	stp	x13, x14, [sp, #136]
1000ca818:     	ubfx	x14, x8, #12, #4
1000ca81c:     	ubfx	x13, x8, #20, #4
1000ca820:     	stp	x13, x14, [sp, #120]
1000ca824:     	lsr	x8, x8, #28
1000ca828:     	str	x8, [sp, #112]
1000ca82c:     	and	x8, x9, #0xf
1000ca830:     	str	x8, [sp, #104]
1000ca834:     	ubfx	x8, x9, #8, #4
1000ca838:     	str	x8, [sp, #96]
1000ca83c:     	ubfx	x8, x9, #16, #4
1000ca840:     	str	x8, [sp, #88]
1000ca844:     	ubfx	x8, x9, #24, #4
1000ca848:     	str	x8, [sp, #80]
1000ca84c:     	ubfx	x8, x9, #4, #4
1000ca850:     	str	x8, [sp, #72]
1000ca854:     	ubfx	x8, x9, #12, #4
1000ca858:     	str	x8, [sp, #64]
1000ca85c:     	ubfx	x8, x9, #20, #4
1000ca860:     	str	x8, [sp, #56]
1000ca864:     	lsr	x8, x9, #28
1000ca868:     	str	x8, [sp, #48]
1000ca86c:     	and	x9, x10, #0xf
1000ca870:     	ubfx	x8, x10, #8, #4
1000ca874:     	stp	x8, x9, [sp, #32]
1000ca878:     	ubfx	x8, x10, #16, #4
1000ca87c:     	str	x8, [sp, #24]
1000ca880:     	ubfx	x28, x10, #24, #4
1000ca884:     	ubfx	x30, x10, #4, #4
1000ca888:     	ubfx	x8, x10, #12, #4
1000ca88c:     	ubfx	x3, x10, #20, #4
1000ca890:     	lsr	x9, x10, #28
1000ca894:     	and	x1, x17, #0xf
1000ca898:     	ubfx	x10, x17, #8, #4
1000ca89c:     	ubfx	x13, x17, #16, #4
1000ca8a0:     	ubfx	x26, x17, #24, #4
1000ca8a4:     	ubfx	x14, x17, #4, #4
1000ca8a8:     	ubfx	x15, x17, #12, #4
1000ca8ac:     	ubfx	x16, x17, #20, #4
1000ca8b0:     	lsr	x17, x17, #28
1000ca8b4:     	ldr	w20, [x0, x12]
1000ca8b8:     	lsl	w2, w20, #4
1000ca8bc:     	and	x2, x2, #0xf0
1000ca8c0:     	add	x5, x11, x2
1000ca8c4:     	and	x2, x20, #0xf0
1000ca8c8:     	add	x2, x11, x2
1000ca8cc:     	lsr	x4, x20, #4
1000ca8d0:     	and	x4, x4, #0xf0
1000ca8d4:     	add	x7, x11, x4
1000ca8d8:     	lsr	x4, x20, #8
1000ca8dc:     	and	x4, x4, #0xf0
1000ca8e0:     	add	x4, x11, x4
1000ca8e4:     	lsr	x6, x20, #12
1000ca8e8:     	and	x6, x6, #0xf0
1000ca8ec:     	add	x19, x11, x6
1000ca8f0:     	lsr	x6, x20, #16
1000ca8f4:     	and	x6, x6, #0xf0
1000ca8f8:     	add	x6, x11, x6
1000ca8fc:     	lsr	x21, x20, #20
1000ca900:     	and	x21, x21, #0xf0
1000ca904:     	add	x21, x11, x21
1000ca908:     	lsr	x20, x20, #24
1000ca90c:     	and	x20, x20, #0xf0
1000ca910:     	ldr	x22, [sp, #144]
1000ca914:     	ldrb	w22, [x5, x22]
1000ca918:     	add	x20, x11, x20
1000ca91c:     	ldp	x24, x23, [sp, #160]
1000ca920:     	ldrb	w23, [x7, x23]
1000ca924:     	ldrb	w24, [x19, x24]
1000ca928:     	add	w22, w22, w23
1000ca92c:     	add	w22, w22, w24
1000ca930:     	ldr	x23, [sp, #152]
1000ca934:     	ldrb	w23, [x21, x23]
1000ca938:     	ldr	x24, [sp, #136]
1000ca93c:     	ldrb	w24, [x2, x24]
1000ca940:     	add	w22, w22, w23
1000ca944:     	add	w22, w22, w24
1000ca948:     	ldp	x24, x23, [sp, #120]
1000ca94c:     	ldrb	w23, [x4, x23]
1000ca950:     	ldrb	w24, [x6, x24]
1000ca954:     	add	w22, w22, w23
1000ca958:     	add	w22, w22, w24
1000ca95c:     	ldr	x23, [sp, #112]
1000ca960:     	ldrb	w23, [x20, x23]
1000ca964:     	add	w22, w22, w23
1000ca968:     	scvtf	s0, w22
1000ca96c:     	ldp	x23, x22, [sp, #96]
1000ca970:     	ldrb	w22, [x5, x22]
1000ca974:     	ldrb	w23, [x7, x23]
1000ca978:     	ldp	x25, x24, [sp, #80]
1000ca97c:     	ldrb	w24, [x19, x24]
1000ca980:     	ldrb	w25, [x21, x25]
1000ca984:     	add	w22, w22, w23
1000ca988:     	ldr	x23, [sp, #72]
1000ca98c:     	ldrb	w23, [x2, x23]
1000ca990:     	add	w22, w22, w24
1000ca994:     	ldr	x24, [sp, #64]
1000ca998:     	ldrb	w24, [x4, x24]
1000ca99c:     	add	w22, w22, w25
1000ca9a0:     	ldr	x25, [sp, #56]
1000ca9a4:     	ldrb	w25, [x6, x25]
1000ca9a8:     	add	w22, w22, w23
1000ca9ac:     	add	w22, w22, w24
1000ca9b0:     	add	w22, w22, w25
1000ca9b4:     	ldr	x23, [sp, #48]
1000ca9b8:     	ldrb	w23, [x20, x23]
1000ca9bc:     	add	w22, w22, w23
1000ca9c0:     	scvtf	s1, w22
1000ca9c4:     	ldp	x23, x22, [sp, #32]
1000ca9c8:     	ldrb	w22, [x5, x22]
1000ca9cc:     	ldrb	w23, [x7, x23]
1000ca9d0:     	ldr	x24, [sp, #24]
1000ca9d4:     	ldrb	w24, [x19, x24]
1000ca9d8:     	add	w22, w22, w23
1000ca9dc:     	ldrb	w23, [x21, x28]
1000ca9e0:     	add	w22, w22, w24
1000ca9e4:     	ldrb	w24, [x2, x30]
1000ca9e8:     	add	w22, w22, w23
1000ca9ec:     	ldrb	w23, [x4, x8]
1000ca9f0:     	add	w22, w22, w24
1000ca9f4:     	ldrb	w24, [x6, x3]
1000ca9f8:     	add	w22, w22, w23
1000ca9fc:     	ldrb	w23, [x20, x9]
1000caa00:     	add	w22, w22, w24
1000caa04:     	add	w22, w22, w23
1000caa08:     	scvtf	s2, w22
1000caa0c:     	ldrb	w5, [x5, x1]
1000caa10:     	ldrb	w7, [x7, x10]
1000caa14:     	ldrb	w19, [x19, x13]
1000caa18:     	add	w5, w5, w7
1000caa1c:     	add	w5, w5, w19
1000caa20:     	ldrb	w7, [x21, x26]
1000caa24:     	ldrb	w2, [x2, x14]
1000caa28:     	add	w5, w5, w7
1000caa2c:     	add	w2, w5, w2
1000caa30:     	ldrb	w4, [x4, x15]
1000caa34:     	ldrb	w5, [x6, x16]
1000caa38:     	add	w2, w2, w4
1000caa3c:     	add	w2, w2, w5
1000caa40:     	ldrb	w4, [x20, x17]
1000caa44:     	add	w2, w2, w4
1000caa48:     	add	x4, sp, #176
1000caa4c:     	scvtf	s3, w2
1000caa50:     	add	x2, x27, x12
1000caa54:     	ldur	s4, [x2, #-64]
1000caa58:     	fadd	s1, s4, s1
1000caa5c:     	stur	s1, [x2, #-64]
1000caa60:     	ldr	s1, [x2]
1000caa64:     	fadd	s1, s1, s2
1000caa68:     	str	s1, [x2]
1000caa6c:     	ldr	s1, [x2, #64]
1000caa70:     	fadd	s1, s1, s3
1000caa74:     	ldr	s2, [x4, x12]
1000caa78:     	str	s1, [x2, #64]
1000caa7c:     	fadd	s0, s2, s0
1000caa80:     	str	s0, [x4, x12]
1000caa84:     	add	x12, x12, #4
1000caa88:     	cmp	x12, #64
1000caa8c:     	b.ne	0x1000ca8b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000caa90:     	add	x0, x0, #64
1000caa94:     	ldp	x8, x1, [sp, #8]
1000caa98:     	add	x1, x1, #16
1000caa9c:     	cmp	x1, x8
1000caaa0:     	b.ne	0x1000ca7e4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000caaa4:     	ldp	q0, q1, [sp, #368]
1000caaa8:     	ldr	x8, [sp]
1000caaac:     	stp	q0, q1, [x8, #192]
1000caab0:     	ldp	q0, q1, [sp, #400]
1000caab4:     	stp	q0, q1, [x8, #224]
1000caab8:     	ldp	q0, q1, [sp, #304]
1000caabc:     	stp	q0, q1, [x8, #128]
1000caac0:     	ldp	q0, q1, [sp, #336]
1000caac4:     	stp	q0, q1, [x8, #160]
1000caac8:     	ldp	q0, q1, [sp, #240]
1000caacc:     	stp	q0, q1, [x8, #64]
1000caad0:     	ldp	q0, q1, [sp, #272]
1000caad4:     	stp	q0, q1, [x8, #96]
1000caad8:     	ldp	q0, q1, [sp, #176]
1000caadc:     	stp	q0, q1, [x8]
1000caae0:     	ldp	q0, q1, [sp, #208]
1000caae4:     	stp	q0, q1, [x8, #32]
1000caae8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000caaec:     	ldr	x8, [x8, #392]
1000caaf0:     	ldr	x8, [x8]
1000caaf4:     	ldur	x9, [x29, #-96]
1000caaf8:     	cmp	x8, x9
1000caafc:     	b.ne	0x1000cab20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000cab00:     	add	sp, sp, #448
1000cab04:     	ldp	x29, x30, [sp, #80]
1000cab08:     	ldp	x20, x19, [sp, #64]
1000cab0c:     	ldp	x22, x21, [sp, #48]
1000cab10:     	ldp	x24, x23, [sp, #32]
1000cab14:     	ldp	x26, x25, [sp, #16]
1000cab18:     	ldp	x28, x27, [sp], #96
1000cab1c:     	ret
1000cab20:     	bl	0x100163694 <_strcmp+0x100163694>

