00000001000d5e0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5e0c:     	stp	x28, x27, [sp, #-96]!
1000d5e10:     	stp	x26, x25, [sp, #16]
1000d5e14:     	stp	x24, x23, [sp, #32]
1000d5e18:     	stp	x22, x21, [sp, #48]
1000d5e1c:     	stp	x20, x19, [sp, #64]
1000d5e20:     	stp	x29, x30, [sp, #80]
1000d5e24:     	add	x29, sp, #80
1000d5e28:     	sub	sp, sp, #1488
1000d5e2c:     	str	x3, [sp]
1000d5e30:     	mov	x20, x1
1000d5e34:     	mov	x22, x0
1000d5e38:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d5e3c:     	ldr	x8, [x8, #392]
1000d5e40:     	ldr	x8, [x8]
1000d5e44:     	stur	x8, [x29, #-96]
1000d5e48:     	lsl	x8, x2, #2
1000d5e4c:     	and	x19, x8, #0xfffffffffffffff8
1000d5e50:     	add	x0, sp, #448
1000d5e54:     	mov	w1, #1024
1000d5e58:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d5e5c:     	cbz	x19, 0x1000d6388 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d5e60:     	add	x8, x20, x19
1000d5e64:     	str	x8, [sp, #8]
1000d5e68:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d5e6c:     	add	x9, x9, #1724
1000d5e70:     	mov	x10, #0
1000d5e74:     	ldp	w8, w11, [x20]
1000d5e78:     	ubfx	x13, x8, #8, #4
1000d5e7c:     	ubfx	x12, x8, #16, #4
1000d5e80:     	stp	x12, x13, [sp, #432]
1000d5e84:     	ubfx	x15, x8, #24, #4
1000d5e88:     	ldp	w12, w13, [x20, #8]
1000d5e8c:     	and	x14, x8, #0xf
1000d5e90:     	stp	x14, x15, [sp, #416]
1000d5e94:     	ubfx	x15, x8, #4, #4
1000d5e98:     	ubfx	x14, x8, #12, #4
1000d5e9c:     	stp	x14, x15, [sp, #400]
1000d5ea0:     	ubfx	x14, x8, #20, #4
1000d5ea4:     	lsr	x8, x8, #28
1000d5ea8:     	stp	x8, x14, [sp, #384]
1000d5eac:     	and	x8, x11, #0xf
1000d5eb0:     	str	x8, [sp, #376]
1000d5eb4:     	ubfx	x8, x11, #8, #4
1000d5eb8:     	str	x8, [sp, #368]
1000d5ebc:     	ubfx	x8, x11, #16, #4
1000d5ec0:     	str	x8, [sp, #360]
1000d5ec4:     	ubfx	x8, x11, #24, #4
1000d5ec8:     	str	x8, [sp, #352]
1000d5ecc:     	ubfx	x8, x11, #4, #4
1000d5ed0:     	str	x8, [sp, #344]
1000d5ed4:     	ubfx	x8, x11, #12, #4
1000d5ed8:     	str	x8, [sp, #336]
1000d5edc:     	ubfx	x8, x11, #20, #4
1000d5ee0:     	str	x8, [sp, #328]
1000d5ee4:     	lsr	x8, x11, #28
1000d5ee8:     	str	x8, [sp, #320]
1000d5eec:     	and	x11, x12, #0xf
1000d5ef0:     	ubfx	x8, x12, #8, #4
1000d5ef4:     	stp	x8, x11, [sp, #304]
1000d5ef8:     	ubfx	x11, x12, #16, #4
1000d5efc:     	ubfx	x8, x12, #24, #4
1000d5f00:     	stp	x8, x11, [sp, #288]
1000d5f04:     	ubfx	x11, x12, #4, #4
1000d5f08:     	ubfx	x8, x12, #12, #4
1000d5f0c:     	stp	x8, x11, [sp, #272]
1000d5f10:     	ubfx	x11, x12, #20, #4
1000d5f14:     	lsr	x8, x12, #28
1000d5f18:     	stp	x8, x11, [sp, #256]
1000d5f1c:     	and	x11, x13, #0xf
1000d5f20:     	ubfx	x8, x13, #8, #4
1000d5f24:     	stp	x8, x11, [sp, #240]
1000d5f28:     	ubfx	x11, x13, #16, #4
1000d5f2c:     	ubfx	x8, x13, #24, #4
1000d5f30:     	stp	x8, x11, [sp, #224]
1000d5f34:     	ubfx	x11, x13, #4, #4
1000d5f38:     	ubfx	x8, x13, #12, #4
1000d5f3c:     	stp	x8, x11, [sp, #208]
1000d5f40:     	ubfx	x11, x13, #20, #4
1000d5f44:     	lsr	x8, x13, #28
1000d5f48:     	stp	x8, x11, [sp, #192]
1000d5f4c:     	ldp	w8, w11, [x20, #16]
1000d5f50:     	and	x13, x8, #0xf
1000d5f54:     	ubfx	x12, x8, #8, #4
1000d5f58:     	stp	x12, x13, [sp, #176]
1000d5f5c:     	ubfx	x13, x8, #16, #4
1000d5f60:     	ubfx	x12, x8, #24, #4
1000d5f64:     	stp	x12, x13, [sp, #160]
1000d5f68:     	ubfx	x13, x8, #4, #4
1000d5f6c:     	ubfx	x12, x8, #12, #4
1000d5f70:     	stp	x12, x13, [sp, #144]
1000d5f74:     	ubfx	x12, x8, #20, #4
1000d5f78:     	lsr	x8, x8, #28
1000d5f7c:     	stp	x8, x12, [sp, #128]
1000d5f80:     	and	x8, x11, #0xf
1000d5f84:     	str	x8, [sp, #120]
1000d5f88:     	ubfx	x8, x11, #8, #4
1000d5f8c:     	str	x8, [sp, #112]
1000d5f90:     	ubfx	x8, x11, #16, #4
1000d5f94:     	str	x8, [sp, #104]
1000d5f98:     	ubfx	x8, x11, #24, #4
1000d5f9c:     	str	x8, [sp, #96]
1000d5fa0:     	ubfx	x8, x11, #4, #4
1000d5fa4:     	str	x8, [sp, #88]
1000d5fa8:     	ubfx	x8, x11, #12, #4
1000d5fac:     	str	x8, [sp, #80]
1000d5fb0:     	ubfx	x8, x11, #20, #4
1000d5fb4:     	str	x8, [sp, #72]
1000d5fb8:     	lsr	x8, x11, #28
1000d5fbc:     	str	x8, [sp, #64]
1000d5fc0:     	ldp	w13, w2, [x20, #24]
1000d5fc4:     	and	x11, x13, #0xf
1000d5fc8:     	ubfx	x8, x13, #8, #4
1000d5fcc:     	stp	x8, x11, [sp, #48]
1000d5fd0:     	ubfx	x11, x13, #16, #4
1000d5fd4:     	ubfx	x8, x13, #24, #4
1000d5fd8:     	stp	x8, x11, [sp, #32]
1000d5fdc:     	ubfx	x8, x13, #4, #4
1000d5fe0:     	stp	x20, x8, [sp, #16]
1000d5fe4:     	ubfx	x11, x13, #12, #4
1000d5fe8:     	ubfx	x12, x13, #20, #4
1000d5fec:     	lsr	x13, x13, #28
1000d5ff0:     	and	x14, x2, #0xf
1000d5ff4:     	ubfx	x21, x2, #8, #4
1000d5ff8:     	ubfx	x15, x2, #16, #4
1000d5ffc:     	ubfx	x16, x2, #24, #4
1000d6000:     	ubfx	x17, x2, #4, #4
1000d6004:     	ubfx	x0, x2, #12, #4
1000d6008:     	ubfx	x1, x2, #20, #4
1000d600c:     	lsr	x2, x2, #28
1000d6010:     	ldr	w25, [x22, x10]
1000d6014:     	lsl	w3, w25, #4
1000d6018:     	and	x3, x3, #0xf0
1000d601c:     	add	x3, x9, x3
1000d6020:     	ldr	x8, [sp, #416]
1000d6024:     	ldrb	w26, [x3, x8]
1000d6028:     	lsr	x4, x25, #4
1000d602c:     	and	x4, x4, #0xf0
1000d6030:     	add	x4, x9, x4
1000d6034:     	ldr	x8, [sp, #440]
1000d6038:     	ldrb	w27, [x4, x8]
1000d603c:     	lsr	x5, x25, #12
1000d6040:     	and	x5, x5, #0xf0
1000d6044:     	add	x5, x9, x5
1000d6048:     	ldr	x8, [sp, #432]
1000d604c:     	ldrb	w28, [x5, x8]
1000d6050:     	lsr	x6, x25, #20
1000d6054:     	and	x6, x6, #0xf0
1000d6058:     	add	x7, x9, x6
1000d605c:     	ldr	x8, [sp, #424]
1000d6060:     	ldrb	w30, [x7, x8]
1000d6064:     	and	x6, x25, #0xf0
1000d6068:     	add	x6, x9, x6
1000d606c:     	ldr	x8, [sp, #408]
1000d6070:     	ldrb	w19, [x6, x8]
1000d6074:     	lsr	x23, x25, #8
1000d6078:     	and	x23, x23, #0xf0
1000d607c:     	add	x23, x9, x23
1000d6080:     	ldp	x20, x8, [sp, #392]
1000d6084:     	ldrb	w8, [x23, x8]
1000d6088:     	lsr	x24, x25, #16
1000d608c:     	and	x24, x24, #0xf0
1000d6090:     	add	x24, x9, x24
1000d6094:     	ldrb	w20, [x24, x20]
1000d6098:     	lsr	x25, x25, #24
1000d609c:     	and	x25, x25, #0xf0
1000d60a0:     	add	x25, x9, x25
1000d60a4:     	add	w26, w26, w27
1000d60a8:     	ldr	x27, [sp, #384]
1000d60ac:     	ldrb	w27, [x25, x27]
1000d60b0:     	add	w26, w26, w28
1000d60b4:     	add	w26, w26, w30
1000d60b8:     	add	w19, w26, w19
1000d60bc:     	add	w8, w19, w8
1000d60c0:     	add	w8, w8, w20
1000d60c4:     	add	w8, w8, w27
1000d60c8:     	scvtf	s0, w8
1000d60cc:     	ldp	x19, x8, [sp, #368]
1000d60d0:     	ldrb	w8, [x3, x8]
1000d60d4:     	ldrb	w19, [x4, x19]
1000d60d8:     	ldp	x26, x20, [sp, #352]
1000d60dc:     	ldrb	w20, [x5, x20]
1000d60e0:     	ldrb	w26, [x7, x26]
1000d60e4:     	ldp	x28, x27, [sp, #336]
1000d60e8:     	ldrb	w27, [x6, x27]
1000d60ec:     	ldrb	w28, [x23, x28]
1000d60f0:     	add	w8, w8, w19
1000d60f4:     	ldr	x19, [sp, #328]
1000d60f8:     	ldrb	w19, [x24, x19]
1000d60fc:     	add	w8, w8, w20
1000d6100:     	add	w8, w8, w26
1000d6104:     	ldr	x20, [sp, #320]
1000d6108:     	ldrb	w20, [x25, x20]
1000d610c:     	add	w8, w8, w27
1000d6110:     	add	w8, w8, w28
1000d6114:     	add	w8, w8, w19
1000d6118:     	add	w8, w8, w20
1000d611c:     	scvtf	s1, w8
1000d6120:     	ldp	x19, x8, [sp, #304]
1000d6124:     	ldrb	w8, [x3, x8]
1000d6128:     	ldrb	w19, [x4, x19]
1000d612c:     	ldp	x26, x20, [sp, #288]
1000d6130:     	ldrb	w20, [x5, x20]
1000d6134:     	ldrb	w26, [x7, x26]
1000d6138:     	ldr	x27, [sp, #280]
1000d613c:     	ldrb	w27, [x6, x27]
1000d6140:     	add	w8, w8, w19
1000d6144:     	ldr	x19, [sp, #272]
1000d6148:     	ldrb	w19, [x23, x19]
1000d614c:     	add	w8, w8, w20
1000d6150:     	ldr	x20, [sp, #264]
1000d6154:     	ldrb	w20, [x24, x20]
1000d6158:     	add	w8, w8, w26
1000d615c:     	ldr	x26, [sp, #256]
1000d6160:     	ldrb	w26, [x25, x26]
1000d6164:     	add	w8, w8, w27
1000d6168:     	add	w8, w8, w19
1000d616c:     	add	w8, w8, w20
1000d6170:     	add	w8, w8, w26
1000d6174:     	scvtf	s2, w8
1000d6178:     	ldp	x19, x8, [sp, #240]
1000d617c:     	ldrb	w8, [x3, x8]
1000d6180:     	ldrb	w19, [x4, x19]
1000d6184:     	ldp	x26, x20, [sp, #224]
1000d6188:     	ldrb	w20, [x5, x20]
1000d618c:     	ldrb	w26, [x7, x26]
1000d6190:     	add	w8, w8, w19
1000d6194:     	ldr	x19, [sp, #216]
1000d6198:     	ldrb	w19, [x6, x19]
1000d619c:     	add	w8, w8, w20
1000d61a0:     	ldr	x20, [sp, #208]
1000d61a4:     	ldrb	w20, [x23, x20]
1000d61a8:     	add	w8, w8, w26
1000d61ac:     	ldr	x26, [sp, #200]
1000d61b0:     	ldrb	w26, [x24, x26]
1000d61b4:     	add	w8, w8, w19
1000d61b8:     	ldr	x19, [sp, #192]
1000d61bc:     	ldrb	w19, [x25, x19]
1000d61c0:     	add	w8, w8, w20
1000d61c4:     	add	w8, w8, w26
1000d61c8:     	add	w8, w8, w19
1000d61cc:     	scvtf	s3, w8
1000d61d0:     	ldp	x19, x8, [sp, #176]
1000d61d4:     	ldrb	w8, [x3, x8]
1000d61d8:     	ldrb	w19, [x4, x19]
1000d61dc:     	ldp	x26, x20, [sp, #160]
1000d61e0:     	ldrb	w20, [x5, x20]
1000d61e4:     	ldrb	w26, [x7, x26]
1000d61e8:     	add	w8, w8, w19
1000d61ec:     	add	w8, w8, w20
1000d61f0:     	ldp	x20, x19, [sp, #144]
1000d61f4:     	ldrb	w19, [x6, x19]
1000d61f8:     	ldrb	w20, [x23, x20]
1000d61fc:     	add	w8, w8, w26
1000d6200:     	add	w8, w8, w19
1000d6204:     	ldp	x26, x19, [sp, #128]
1000d6208:     	ldrb	w19, [x24, x19]
1000d620c:     	ldrb	w26, [x25, x26]
1000d6210:     	add	w8, w8, w20
1000d6214:     	add	w8, w8, w19
1000d6218:     	add	w8, w8, w26
1000d621c:     	scvtf	s4, w8
1000d6220:     	ldp	x19, x8, [sp, #112]
1000d6224:     	ldrb	w8, [x3, x8]
1000d6228:     	ldrb	w19, [x4, x19]
1000d622c:     	ldr	x20, [sp, #104]
1000d6230:     	ldrb	w20, [x5, x20]
1000d6234:     	add	w8, w8, w19
1000d6238:     	add	w8, w8, w20
1000d623c:     	ldp	x20, x19, [sp, #88]
1000d6240:     	ldrb	w19, [x7, x19]
1000d6244:     	ldrb	w20, [x6, x20]
1000d6248:     	add	w8, w8, w19
1000d624c:     	add	w8, w8, w20
1000d6250:     	ldp	x20, x19, [sp, #72]
1000d6254:     	ldrb	w19, [x23, x19]
1000d6258:     	ldrb	w20, [x24, x20]
1000d625c:     	add	w8, w8, w19
1000d6260:     	add	w8, w8, w20
1000d6264:     	ldr	x19, [sp, #64]
1000d6268:     	ldrb	w19, [x25, x19]
1000d626c:     	add	w8, w8, w19
1000d6270:     	scvtf	s5, w8
1000d6274:     	ldp	x19, x8, [sp, #48]
1000d6278:     	ldrb	w8, [x3, x8]
1000d627c:     	ldrb	w19, [x4, x19]
1000d6280:     	ldp	x26, x20, [sp, #32]
1000d6284:     	ldrb	w20, [x5, x20]
1000d6288:     	ldrb	w26, [x7, x26]
1000d628c:     	add	w8, w8, w19
1000d6290:     	ldr	x19, [sp, #24]
1000d6294:     	ldrb	w19, [x6, x19]
1000d6298:     	add	w8, w8, w20
1000d629c:     	ldrb	w20, [x23, x11]
1000d62a0:     	add	w8, w8, w26
1000d62a4:     	ldrb	w26, [x24, x12]
1000d62a8:     	add	w8, w8, w19
1000d62ac:     	add	w8, w8, w20
1000d62b0:     	add	w8, w8, w26
1000d62b4:     	ldrb	w19, [x25, x13]
1000d62b8:     	add	w8, w8, w19
1000d62bc:     	scvtf	s6, w8
1000d62c0:     	ldrb	w8, [x3, x14]
1000d62c4:     	ldrb	w3, [x4, x21]
1000d62c8:     	ldrb	w4, [x5, x15]
1000d62cc:     	add	w8, w8, w3
1000d62d0:     	add	w8, w8, w4
1000d62d4:     	ldrb	w3, [x7, x16]
1000d62d8:     	ldrb	w4, [x6, x17]
1000d62dc:     	add	w8, w8, w3
1000d62e0:     	add	w8, w8, w4
1000d62e4:     	ldrb	w3, [x23, x0]
1000d62e8:     	add	x5, sp, #448
1000d62ec:     	ldrb	w4, [x24, x1]
1000d62f0:     	add	w8, w8, w3
1000d62f4:     	add	w8, w8, w4
1000d62f8:     	ldrb	w3, [x25, x2]
1000d62fc:     	add	w8, w8, w3
1000d6300:     	scvtf	s7, w8
1000d6304:     	add	x8, x5, x10
1000d6308:     	ldr	s16, [x8]
1000d630c:     	fadd	s0, s16, s0
1000d6310:     	str	s0, [x8]
1000d6314:     	ldr	s0, [x8, #128]
1000d6318:     	fadd	s0, s0, s1
1000d631c:     	str	s0, [x8, #128]
1000d6320:     	ldr	s0, [x8, #256]
1000d6324:     	fadd	s0, s0, s2
1000d6328:     	str	s0, [x8, #256]
1000d632c:     	ldr	s0, [x8, #384]
1000d6330:     	fadd	s0, s0, s3
1000d6334:     	str	s0, [x8, #384]
1000d6338:     	ldr	s0, [x8, #512]
1000d633c:     	fadd	s0, s0, s4
1000d6340:     	str	s0, [x8, #512]
1000d6344:     	ldr	s0, [x8, #640]
1000d6348:     	fadd	s0, s0, s5
1000d634c:     	str	s0, [x8, #640]
1000d6350:     	ldr	s0, [x8, #768]
1000d6354:     	fadd	s0, s0, s6
1000d6358:     	ldr	s1, [x8, #896]
1000d635c:     	fadd	s1, s1, s7
1000d6360:     	str	s0, [x8, #768]
1000d6364:     	str	s1, [x8, #896]
1000d6368:     	add	x10, x10, #4
1000d636c:     	cmp	x10, #128
1000d6370:     	b.ne	0x1000d6010 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d6374:     	add	x22, x22, #128
1000d6378:     	ldp	x8, x20, [sp, #8]
1000d637c:     	add	x20, x20, #32
1000d6380:     	cmp	x20, x8
1000d6384:     	b.ne	0x1000d5e70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d6388:     	add	x1, sp, #448
1000d638c:     	ldr	x0, [sp]
1000d6390:     	mov	w2, #1024
1000d6394:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d6398:     	ldur	x8, [x29, #-96]
1000d639c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000d63a0:     	ldr	x9, [x9, #392]
1000d63a4:     	ldr	x9, [x9]
1000d63a8:     	cmp	x9, x8
1000d63ac:     	b.ne	0x1000d63d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d63b0:     	add	sp, sp, #1488
1000d63b4:     	ldp	x29, x30, [sp, #80]
1000d63b8:     	ldp	x20, x19, [sp, #64]
1000d63bc:     	ldp	x22, x21, [sp, #48]
1000d63c0:     	ldp	x24, x23, [sp, #32]
1000d63c4:     	ldp	x26, x25, [sp, #16]
1000d63c8:     	ldp	x28, x27, [sp], #96
1000d63cc:     	ret
1000d63d0:     	bl	0x100163694 <_strcmp+0x100163694>

