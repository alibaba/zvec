00000001000d9e3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9e3c:     	stp	x28, x27, [sp, #-64]!
1000d9e40:     	stp	x22, x21, [sp, #16]
1000d9e44:     	stp	x20, x19, [sp, #32]
1000d9e48:     	stp	x29, x30, [sp, #48]
1000d9e4c:     	add	x29, sp, #48
1000d9e50:     	mov	w9, #4112
1000d9e54:     	adrp	x16, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x34>
1000d9e58:     	ldr	x16, [x16, #304]
1000d9e5c:     	blr	x16
1000d9e60:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9e64:     	sub	sp, sp, #16
1000d9e68:     	mov	x19, x3
1000d9e6c:     	mov	x20, x1
1000d9e70:     	mov	x21, x0
1000d9e74:     	adrp	x8, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x54>
1000d9e78:     	ldr	x8, [x8, #392]
1000d9e7c:     	ldr	x8, [x8]
1000d9e80:     	stur	x8, [x29, #-56]
1000d9e84:     	lsl	x8, x2, #4
1000d9e88:     	and	x22, x8, #0xffffffffffffffe0
1000d9e8c:     	add	x0, sp, #8
1000d9e90:     	mov	w1, #4096
1000d9e94:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9e98:     	cbz	x22, 0x1000d9fb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d9e9c:     	add	x8, x20, x22
1000d9ea0:     	adrp	x9, 0x10016a000 <void run<double, 1ul, 1ul, false>(char const*)+0x78>
1000d9ea4:     	add	x9, x9, #1980
1000d9ea8:     	mov	x10, #0
1000d9eac:     	add	x11, sp, #8
1000d9eb0:     	mov	x12, #0
1000d9eb4:     	ldr	w2, [x21, x10, lsl #2]
1000d9eb8:     	lsl	w13, w2, #4
1000d9ebc:     	and	x13, x13, #0xf0
1000d9ec0:     	and	x14, x2, #0xf0
1000d9ec4:     	lsr	x15, x2, #4
1000d9ec8:     	and	x15, x15, #0xf0
1000d9ecc:     	lsr	x16, x2, #8
1000d9ed0:     	and	x16, x16, #0xf0
1000d9ed4:     	lsr	x17, x2, #12
1000d9ed8:     	and	x17, x17, #0xf0
1000d9edc:     	lsr	x0, x2, #16
1000d9ee0:     	and	x0, x0, #0xf0
1000d9ee4:     	lsr	x1, x2, #20
1000d9ee8:     	and	x1, x1, #0xf0
1000d9eec:     	lsr	x2, x2, #24
1000d9ef0:     	and	x2, x2, #0xf0
1000d9ef4:     	mov	x3, x11
1000d9ef8:     	ldr	w4, [x20, x12]
1000d9efc:     	and	x5, x4, #0xf
1000d9f00:     	orr	x5, x13, x5
1000d9f04:     	ldrsb	w5, [x9, x5]
1000d9f08:     	ubfx	x6, x4, #4, #4
1000d9f0c:     	orr	x6, x14, x6
1000d9f10:     	ldrsb	w6, [x9, x6]
1000d9f14:     	ubfx	x7, x4, #8, #4
1000d9f18:     	orr	x7, x15, x7
1000d9f1c:     	ldrsb	w7, [x9, x7]
1000d9f20:     	add	w5, w5, w6
1000d9f24:     	add	w5, w5, w7
1000d9f28:     	ubfx	x6, x4, #12, #4
1000d9f2c:     	orr	x6, x16, x6
1000d9f30:     	ldrsb	w6, [x9, x6]
1000d9f34:     	ubfx	x7, x4, #16, #4
1000d9f38:     	orr	x7, x17, x7
1000d9f3c:     	ldrsb	w7, [x9, x7]
1000d9f40:     	add	w5, w5, w6
1000d9f44:     	add	w5, w5, w7
1000d9f48:     	ubfx	x6, x4, #20, #4
1000d9f4c:     	orr	x6, x0, x6
1000d9f50:     	ldrsb	w6, [x9, x6]
1000d9f54:     	ubfx	x7, x4, #24, #4
1000d9f58:     	orr	x7, x1, x7
1000d9f5c:     	ldrsb	w7, [x9, x7]
1000d9f60:     	add	w5, w5, w6
1000d9f64:     	add	w5, w5, w7
1000d9f68:     	orr	x4, x2, x4, lsr #28
1000d9f6c:     	ldrsb	w4, [x9, x4]
1000d9f70:     	add	w4, w5, w4
1000d9f74:     	scvtf	s0, w4
1000d9f78:     	ldr	s1, [x3]
1000d9f7c:     	fadd	s0, s1, s0
1000d9f80:     	str	s0, [x3], #128
1000d9f84:     	add	x12, x12, #4
1000d9f88:     	cmp	x12, #128
1000d9f8c:     	b.ne	0x1000d9ef8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d9f90:     	add	x10, x10, #1
1000d9f94:     	add	x11, x11, #4
1000d9f98:     	cmp	x10, #32
1000d9f9c:     	b.ne	0x1000d9eb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d9fa0:     	add	x21, x21, #128
1000d9fa4:     	add	x20, x20, #128
1000d9fa8:     	cmp	x20, x8
1000d9fac:     	b.ne	0x1000d9ea8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d9fb0:     	add	x1, sp, #8
1000d9fb4:     	mov	x0, x19
1000d9fb8:     	mov	w2, #4096
1000d9fbc:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9fc0:     	ldur	x8, [x29, #-56]
1000d9fc4:     	adrp	x9, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x1a4>
1000d9fc8:     	ldr	x9, [x9, #392]
1000d9fcc:     	ldr	x9, [x9]
1000d9fd0:     	cmp	x9, x8
1000d9fd4:     	b.ne	0x1000d9ff4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d9fd8:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9fdc:     	add	sp, sp, #16
1000d9fe0:     	ldp	x29, x30, [sp, #48]
1000d9fe4:     	ldp	x20, x19, [sp, #32]
1000d9fe8:     	ldp	x22, x21, [sp, #16]
1000d9fec:     	ldp	x28, x27, [sp], #64
1000d9ff0:     	ret
1000d9ff4:     	bl	0x100163694 <_strcmp+0x100163694>

