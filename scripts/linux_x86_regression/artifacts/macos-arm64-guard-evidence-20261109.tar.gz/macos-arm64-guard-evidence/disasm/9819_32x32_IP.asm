00000001000d5e5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5e5c:     	stp	x28, x27, [sp, #-64]!
1000d5e60:     	stp	x22, x21, [sp, #16]
1000d5e64:     	stp	x20, x19, [sp, #32]
1000d5e68:     	stp	x29, x30, [sp, #48]
1000d5e6c:     	add	x29, sp, #48
1000d5e70:     	mov	w9, #4112
1000d5e74:     	adrp	x16, 0x100168000 <void run<double, 1ul, 1ul, false>(char const*)+0x34>
1000d5e78:     	ldr	x16, [x16, #304]
1000d5e7c:     	blr	x16
1000d5e80:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d5e84:     	sub	sp, sp, #16
1000d5e88:     	mov	x19, x3
1000d5e8c:     	mov	x20, x1
1000d5e90:     	mov	x21, x0
1000d5e94:     	adrp	x8, 0x100168000 <void run<double, 1ul, 1ul, false>(char const*)+0x54>
1000d5e98:     	ldr	x8, [x8, #392]
1000d5e9c:     	ldr	x8, [x8]
1000d5ea0:     	stur	x8, [x29, #-56]
1000d5ea4:     	lsl	x8, x2, #4
1000d5ea8:     	and	x22, x8, #0xffffffffffffffe0
1000d5eac:     	add	x0, sp, #8
1000d5eb0:     	mov	w1, #4096
1000d5eb4:     	bl	0x10015f6cc <_strcmp+0x10015f6cc>
1000d5eb8:     	cbz	x22, 0x1000d5fd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d5ebc:     	add	x8, x20, x22
1000d5ec0:     	adrp	x9, 0x100166000 <void run<double, 1ul, 1ul, false>(char const*)+0x78>
1000d5ec4:     	add	x9, x9, #2012
1000d5ec8:     	mov	x10, #0
1000d5ecc:     	add	x11, sp, #8
1000d5ed0:     	mov	x12, #0
1000d5ed4:     	ldr	w2, [x21, x10, lsl #2]
1000d5ed8:     	lsl	w13, w2, #4
1000d5edc:     	and	x13, x13, #0xf0
1000d5ee0:     	and	x14, x2, #0xf0
1000d5ee4:     	lsr	x15, x2, #4
1000d5ee8:     	and	x15, x15, #0xf0
1000d5eec:     	lsr	x16, x2, #8
1000d5ef0:     	and	x16, x16, #0xf0
1000d5ef4:     	lsr	x17, x2, #12
1000d5ef8:     	and	x17, x17, #0xf0
1000d5efc:     	lsr	x0, x2, #16
1000d5f00:     	and	x0, x0, #0xf0
1000d5f04:     	lsr	x1, x2, #20
1000d5f08:     	and	x1, x1, #0xf0
1000d5f0c:     	lsr	x2, x2, #24
1000d5f10:     	and	x2, x2, #0xf0
1000d5f14:     	mov	x3, x11
1000d5f18:     	ldr	w4, [x20, x12]
1000d5f1c:     	and	x5, x4, #0xf
1000d5f20:     	orr	x5, x13, x5
1000d5f24:     	ldrsb	w5, [x9, x5]
1000d5f28:     	ubfx	x6, x4, #4, #4
1000d5f2c:     	orr	x6, x14, x6
1000d5f30:     	ldrsb	w6, [x9, x6]
1000d5f34:     	ubfx	x7, x4, #8, #4
1000d5f38:     	orr	x7, x15, x7
1000d5f3c:     	ldrsb	w7, [x9, x7]
1000d5f40:     	add	w5, w5, w6
1000d5f44:     	add	w5, w5, w7
1000d5f48:     	ubfx	x6, x4, #12, #4
1000d5f4c:     	orr	x6, x16, x6
1000d5f50:     	ldrsb	w6, [x9, x6]
1000d5f54:     	ubfx	x7, x4, #16, #4
1000d5f58:     	orr	x7, x17, x7
1000d5f5c:     	ldrsb	w7, [x9, x7]
1000d5f60:     	add	w5, w5, w6
1000d5f64:     	add	w5, w5, w7
1000d5f68:     	ubfx	x6, x4, #20, #4
1000d5f6c:     	orr	x6, x0, x6
1000d5f70:     	ldrsb	w6, [x9, x6]
1000d5f74:     	ubfx	x7, x4, #24, #4
1000d5f78:     	orr	x7, x1, x7
1000d5f7c:     	ldrsb	w7, [x9, x7]
1000d5f80:     	add	w5, w5, w6
1000d5f84:     	add	w5, w5, w7
1000d5f88:     	orr	x4, x2, x4, lsr #28
1000d5f8c:     	ldrsb	w4, [x9, x4]
1000d5f90:     	add	w4, w5, w4
1000d5f94:     	scvtf	s0, w4
1000d5f98:     	ldr	s1, [x3]
1000d5f9c:     	fadd	s0, s1, s0
1000d5fa0:     	str	s0, [x3], #128
1000d5fa4:     	add	x12, x12, #4
1000d5fa8:     	cmp	x12, #128
1000d5fac:     	b.ne	0x1000d5f18 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d5fb0:     	add	x10, x10, #1
1000d5fb4:     	add	x11, x11, #4
1000d5fb8:     	cmp	x10, #32
1000d5fbc:     	b.ne	0x1000d5ed0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d5fc0:     	add	x21, x21, #128
1000d5fc4:     	add	x20, x20, #128
1000d5fc8:     	cmp	x20, x8
1000d5fcc:     	b.ne	0x1000d5ec8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d5fd0:     	add	x1, sp, #8
1000d5fd4:     	mov	x0, x19
1000d5fd8:     	mov	w2, #4096
1000d5fdc:     	bl	0x10015f6fc <_strcmp+0x10015f6fc>
1000d5fe0:     	ldur	x8, [x29, #-56]
1000d5fe4:     	adrp	x9, 0x100168000 <void run<double, 1ul, 1ul, false>(char const*)+0x1a4>
1000d5fe8:     	ldr	x9, [x9, #392]
1000d5fec:     	ldr	x9, [x9]
1000d5ff0:     	cmp	x9, x8
1000d5ff4:     	b.ne	0x1000d6014 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d5ff8:     	add	sp, sp, #1, lsl #12     ; =4096
1000d5ffc:     	add	sp, sp, #16
1000d6000:     	ldp	x29, x30, [sp, #48]
1000d6004:     	ldp	x20, x19, [sp, #32]
1000d6008:     	ldp	x22, x21, [sp, #16]
1000d600c:     	ldp	x28, x27, [sp], #64
1000d6010:     	ret
1000d6014:     	bl	0x10015f6b4 <_strcmp+0x10015f6b4>

