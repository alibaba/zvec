00000001000b9e84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b9e84:     	stp	x24, x23, [sp, #-48]!
1000b9e88:     	stp	x22, x21, [sp, #16]
1000b9e8c:     	stp	x20, x19, [sp, #32]
1000b9e90:     	stp	xzr, xzr, [x3]
1000b9e94:     	lsl	x8, x4, #2
1000b9e98:     	cmp	x2, #8
1000b9e9c:     	b.hs	0x1000b9eb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b9ea0:     	mov	x13, #0
1000b9ea4:     	movi	d1, #0000000000000000
1000b9ea8:     	movi	d0, #0000000000000000
1000b9eac:     	b	0x1000ba0f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000b9eb0:     	mov	x10, #0
1000b9eb4:     	add	x9, x0, #8
1000b9eb8:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f8>
1000b9ebc:     	add	x11, x11, #188
1000b9ec0:     	mov	x12, x1
1000b9ec4:     	ldr	w5, [x12]
1000b9ec8:     	lsl	w13, w5, #4
1000b9ecc:     	and	x14, x13, #0xf0
1000b9ed0:     	and	x13, x5, #0xf0
1000b9ed4:     	add	x13, x11, x13
1000b9ed8:     	add	x14, x11, x14
1000b9edc:     	lsr	x15, x5, #4
1000b9ee0:     	and	x15, x15, #0xf0
1000b9ee4:     	add	x15, x11, x15
1000b9ee8:     	lsr	x16, x5, #8
1000b9eec:     	and	x16, x16, #0xf0
1000b9ef0:     	add	x16, x11, x16
1000b9ef4:     	lsr	x17, x5, #12
1000b9ef8:     	and	x17, x17, #0xf0
1000b9efc:     	add	x17, x11, x17
1000b9f00:     	lsr	x4, x5, #16
1000b9f04:     	and	x4, x4, #0xf0
1000b9f08:     	add	x4, x11, x4
1000b9f0c:     	lsr	x6, x5, #20
1000b9f10:     	and	x6, x6, #0xf0
1000b9f14:     	lsr	x5, x5, #24
1000b9f18:     	and	x7, x5, #0xf0
1000b9f1c:     	ldur	w19, [x9, #-8]
1000b9f20:     	add	x5, x11, x6
1000b9f24:     	and	x6, x19, #0xf
1000b9f28:     	ubfx	x20, x19, #4, #4
1000b9f2c:     	ldrb	w20, [x13, x20]
1000b9f30:     	ldrb	w21, [x14, x6]
1000b9f34:     	ubfx	x6, x19, #8, #4
1000b9f38:     	ldrb	w22, [x15, x6]
1000b9f3c:     	ubfx	x6, x19, #12, #4
1000b9f40:     	ldrb	w23, [x16, x6]
1000b9f44:     	add	x6, x11, x7
1000b9f48:     	ubfx	x7, x19, #16, #4
1000b9f4c:     	ldrb	w7, [x17, x7]
1000b9f50:     	add	w20, w21, w20
1000b9f54:     	add	w20, w20, w22
1000b9f58:     	ubfx	x21, x19, #20, #4
1000b9f5c:     	ldrb	w21, [x4, x21]
1000b9f60:     	ubfx	x22, x19, #24, #4
1000b9f64:     	add	w20, w20, w23
1000b9f68:     	add	w7, w20, w7
1000b9f6c:     	ldrb	w20, [x5, x22]
1000b9f70:     	lsr	x19, x19, #28
1000b9f74:     	ldrb	w19, [x6, x19]
1000b9f78:     	add	w7, w7, w21
1000b9f7c:     	add	w7, w7, w20
1000b9f80:     	add	w7, w7, w19
1000b9f84:     	scvtf	s0, w7
1000b9f88:     	ldp	s1, s2, [x3]
1000b9f8c:     	fadd	s0, s1, s0
1000b9f90:     	str	s0, [x3]
1000b9f94:     	ldur	w7, [x9, #-4]
1000b9f98:     	and	x19, x7, #0xf
1000b9f9c:     	ldrb	w19, [x14, x19]
1000b9fa0:     	ubfx	x20, x7, #4, #4
1000b9fa4:     	ldrb	w20, [x13, x20]
1000b9fa8:     	ubfx	x21, x7, #8, #4
1000b9fac:     	ldrb	w21, [x15, x21]
1000b9fb0:     	ubfx	x22, x7, #12, #4
1000b9fb4:     	ldrb	w22, [x16, x22]
1000b9fb8:     	ubfx	x23, x7, #16, #4
1000b9fbc:     	add	w19, w19, w20
1000b9fc0:     	add	w19, w19, w21
1000b9fc4:     	ldrb	w20, [x17, x23]
1000b9fc8:     	ubfx	x21, x7, #20, #4
1000b9fcc:     	ldrb	w21, [x4, x21]
1000b9fd0:     	add	w19, w19, w22
1000b9fd4:     	add	w19, w19, w20
1000b9fd8:     	ubfx	x20, x7, #24, #4
1000b9fdc:     	ldrb	w20, [x5, x20]
1000b9fe0:     	add	w19, w19, w21
1000b9fe4:     	add	w19, w19, w20
1000b9fe8:     	lsr	x7, x7, #28
1000b9fec:     	ldrb	w7, [x6, x7]
1000b9ff0:     	add	w7, w19, w7
1000b9ff4:     	scvtf	s0, w7
1000b9ff8:     	fadd	s0, s2, s0
1000b9ffc:     	str	s0, [x3, #4]
1000ba000:     	ldr	w7, [x9]
1000ba004:     	and	x19, x7, #0xf
1000ba008:     	ldrb	w19, [x14, x19]
1000ba00c:     	ubfx	x20, x7, #4, #4
1000ba010:     	ldrb	w20, [x13, x20]
1000ba014:     	ubfx	x21, x7, #8, #4
1000ba018:     	ldrb	w21, [x15, x21]
1000ba01c:     	ubfx	x22, x7, #12, #4
1000ba020:     	ldrb	w22, [x16, x22]
1000ba024:     	ubfx	x23, x7, #16, #4
1000ba028:     	add	w19, w19, w20
1000ba02c:     	add	w19, w19, w21
1000ba030:     	ldrb	w20, [x17, x23]
1000ba034:     	ubfx	x21, x7, #20, #4
1000ba038:     	ldrb	w21, [x4, x21]
1000ba03c:     	add	w19, w19, w22
1000ba040:     	add	w19, w19, w20
1000ba044:     	ubfx	x20, x7, #24, #4
1000ba048:     	ldrb	w20, [x5, x20]
1000ba04c:     	add	w19, w19, w21
1000ba050:     	add	w19, w19, w20
1000ba054:     	lsr	x7, x7, #28
1000ba058:     	ldrb	w7, [x6, x7]
1000ba05c:     	add	w7, w19, w7
1000ba060:     	scvtf	s0, w7
1000ba064:     	ldp	s1, s2, [x3, #8]
1000ba068:     	fadd	s0, s1, s0
1000ba06c:     	str	s0, [x3, #8]
1000ba070:     	ldr	w7, [x9, #4]
1000ba074:     	and	x19, x7, #0xf
1000ba078:     	ldrb	w14, [x14, x19]
1000ba07c:     	ubfx	x19, x7, #4, #4
1000ba080:     	ldrb	w13, [x13, x19]
1000ba084:     	ubfx	x19, x7, #8, #4
1000ba088:     	ldrb	w15, [x15, x19]
1000ba08c:     	ubfx	x19, x7, #12, #4
1000ba090:     	ldrb	w16, [x16, x19]
1000ba094:     	ubfx	x19, x7, #16, #4
1000ba098:     	ldrb	w17, [x17, x19]
1000ba09c:     	add	w13, w14, w13
1000ba0a0:     	add	w13, w13, w15
1000ba0a4:     	ubfx	x14, x7, #20, #4
1000ba0a8:     	ldrb	w14, [x4, x14]
1000ba0ac:     	ubfx	x15, x7, #24, #4
1000ba0b0:     	add	w13, w13, w16
1000ba0b4:     	add	w13, w13, w17
1000ba0b8:     	ldrb	w15, [x5, x15]
1000ba0bc:     	lsr	x16, x7, #28
1000ba0c0:     	ldrb	w16, [x6, x16]
1000ba0c4:     	add	w13, w13, w14
1000ba0c8:     	add	w13, w13, w15
1000ba0cc:     	add	w13, w13, w16
1000ba0d0:     	scvtf	s1, w13
1000ba0d4:     	fadd	s1, s2, s1
1000ba0d8:     	str	s1, [x3, #12]
1000ba0dc:     	add	x13, x10, #8
1000ba0e0:     	add	x12, x12, x8
1000ba0e4:     	add	x9, x9, #16
1000ba0e8:     	add	x14, x10, #16
1000ba0ec:     	mov	x10, x13
1000ba0f0:     	cmp	x14, x2
1000ba0f4:     	b.ls	0x1000b9ec4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000ba0f8:     	cmp	x13, x2
1000ba0fc:     	b.hs	0x1000ba1f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x370>
1000ba100:     	ldp	s2, s3, [x3]
1000ba104:     	lsl	w9, w13, #2
1000ba108:     	mov	w10, #-16
1000ba10c:     	lsr	x11, x13, #3
1000ba110:     	mul	x12, x8, x11
1000ba114:     	ubfx	x14, x13, #1, #2
1000ba118:     	orr	x12, x12, x14
1000ba11c:     	ldrb	w12, [x1, x12]
1000ba120:     	and	w15, w9, #0x4
1000ba124:     	lsr	w12, w12, w15
1000ba128:     	and	w16, w12, #0xf
1000ba12c:     	cmp	w16, #8
1000ba130:     	csel	w16, wzr, w10, lo
1000ba134:     	bfxil	w16, w12, #0, #4
1000ba138:     	bfi	x14, x11, #4, #60
1000ba13c:     	add	x11, x0, x14
1000ba140:     	ldrb	w12, [x11]
1000ba144:     	lsr	w12, w12, w15
1000ba148:     	scvtf	s4, w16
1000ba14c:     	and	w14, w12, #0xf
1000ba150:     	cmp	w14, #8
1000ba154:     	csel	w14, wzr, w10, lo
1000ba158:     	bfxil	w14, w12, #0, #4
1000ba15c:     	scvtf	s5, w14
1000ba160:     	fsub	s5, s5, s4
1000ba164:     	fmadd	s2, s5, s5, s2
1000ba168:     	str	s2, [x3]
1000ba16c:     	ldrb	w12, [x11, #4]
1000ba170:     	lsr	w12, w12, w15
1000ba174:     	and	w14, w12, #0xf
1000ba178:     	cmp	w14, #8
1000ba17c:     	csel	w14, wzr, w10, lo
1000ba180:     	bfxil	w14, w12, #0, #4
1000ba184:     	scvtf	s5, w14
1000ba188:     	fsub	s5, s5, s4
1000ba18c:     	fmadd	s3, s5, s5, s3
1000ba190:     	str	s3, [x3, #4]
1000ba194:     	ldrb	w12, [x11, #8]
1000ba198:     	lsr	w12, w12, w15
1000ba19c:     	and	w14, w12, #0xf
1000ba1a0:     	cmp	w14, #8
1000ba1a4:     	csel	w14, wzr, w10, lo
1000ba1a8:     	bfxil	w14, w12, #0, #4
1000ba1ac:     	scvtf	s5, w14
1000ba1b0:     	fsub	s5, s5, s4
1000ba1b4:     	fmadd	s0, s5, s5, s0
1000ba1b8:     	str	s0, [x3, #8]
1000ba1bc:     	ldrb	w11, [x11, #12]
1000ba1c0:     	lsr	w11, w11, w15
1000ba1c4:     	and	w12, w11, #0xf
1000ba1c8:     	cmp	w12, #8
1000ba1cc:     	csel	w12, wzr, w10, lo
1000ba1d0:     	bfxil	w12, w11, #0, #4
1000ba1d4:     	scvtf	s5, w12
1000ba1d8:     	fsub	s4, s5, s4
1000ba1dc:     	fmadd	s1, s4, s4, s1
1000ba1e0:     	str	s1, [x3, #12]
1000ba1e4:     	add	x13, x13, #1
1000ba1e8:     	add	w9, w9, #4
1000ba1ec:     	cmp	x2, x13
1000ba1f0:     	b.ne	0x1000ba10c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000ba1f4:     	ldp	x20, x19, [sp, #32]
1000ba1f8:     	ldp	x22, x21, [sp, #16]
1000ba1fc:     	ldp	x24, x23, [sp], #48
1000ba200:     	ret

