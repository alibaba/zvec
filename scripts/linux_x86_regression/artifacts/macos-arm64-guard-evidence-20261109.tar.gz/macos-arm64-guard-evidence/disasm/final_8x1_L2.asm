00000001000bf7a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bf7a0:     	stp	x24, x23, [sp, #-48]!
1000bf7a4:     	stp	x22, x21, [sp, #16]
1000bf7a8:     	stp	x20, x19, [sp, #32]
1000bf7ac:     	movi.2d	v0, #0000000000000000
1000bf7b0:     	stp	q0, q0, [x3]
1000bf7b4:     	lsl	x8, x4, #2
1000bf7b8:     	cmp	x2, #8
1000bf7bc:     	b.hs	0x1000bf7c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bf7c0:     	mov	x13, #0
1000bf7c4:     	b	0x1000bfbc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bf7c8:     	mov	x10, #0
1000bf7cc:     	add	x9, x0, #16
1000bf7d0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bf7d4:     	add	x11, x11, #700
1000bf7d8:     	mov	x12, x1
1000bf7dc:     	ldr	w5, [x12]
1000bf7e0:     	lsr	x13, x5, #24
1000bf7e4:     	and	x13, x13, #0xf0
1000bf7e8:     	lsr	x14, x5, #20
1000bf7ec:     	and	x14, x14, #0xf0
1000bf7f0:     	add	x13, x11, x13
1000bf7f4:     	add	x14, x11, x14
1000bf7f8:     	lsr	x15, x5, #16
1000bf7fc:     	and	x15, x15, #0xf0
1000bf800:     	lsr	x16, x5, #12
1000bf804:     	and	x6, x16, #0xf0
1000bf808:     	add	x15, x11, x15
1000bf80c:     	lsr	x16, x5, #8
1000bf810:     	and	x16, x16, #0xf0
1000bf814:     	add	x16, x11, x16
1000bf818:     	lsr	x17, x5, #4
1000bf81c:     	and	x17, x17, #0xf0
1000bf820:     	add	x17, x11, x17
1000bf824:     	and	x4, x5, #0xf0
1000bf828:     	add	x4, x11, x4
1000bf82c:     	lsl	w5, w5, #4
1000bf830:     	and	x5, x5, #0xf0
1000bf834:     	ldur	w7, [x9, #-16]
1000bf838:     	add	x5, x11, x5
1000bf83c:     	and	x19, x7, #0xf
1000bf840:     	ubfx	x20, x7, #4, #4
1000bf844:     	ldrb	w20, [x4, x20]
1000bf848:     	ldrb	w19, [x5, x19]
1000bf84c:     	ubfx	x21, x7, #8, #4
1000bf850:     	ldrb	w21, [x17, x21]
1000bf854:     	ubfx	x22, x7, #12, #4
1000bf858:     	ldrb	w22, [x16, x22]
1000bf85c:     	add	x6, x11, x6
1000bf860:     	ubfx	x23, x7, #16, #4
1000bf864:     	ldrb	w23, [x6, x23]
1000bf868:     	add	w19, w19, w20
1000bf86c:     	add	w19, w19, w21
1000bf870:     	ubfx	x20, x7, #20, #4
1000bf874:     	ldrb	w20, [x15, x20]
1000bf878:     	ubfx	x21, x7, #24, #4
1000bf87c:     	add	w19, w19, w22
1000bf880:     	add	w19, w19, w23
1000bf884:     	ldrb	w21, [x14, x21]
1000bf888:     	lsr	x7, x7, #28
1000bf88c:     	ldrb	w7, [x13, x7]
1000bf890:     	add	w19, w19, w20
1000bf894:     	add	w19, w19, w21
1000bf898:     	add	w7, w19, w7
1000bf89c:     	scvtf	s0, w7
1000bf8a0:     	ldp	s1, s2, [x3]
1000bf8a4:     	fadd	s0, s1, s0
1000bf8a8:     	str	s0, [x3]
1000bf8ac:     	ldur	w7, [x9, #-12]
1000bf8b0:     	and	x19, x7, #0xf
1000bf8b4:     	ldrb	w19, [x5, x19]
1000bf8b8:     	ubfx	x20, x7, #4, #4
1000bf8bc:     	ldrb	w20, [x4, x20]
1000bf8c0:     	ubfx	x21, x7, #8, #4
1000bf8c4:     	ldrb	w21, [x17, x21]
1000bf8c8:     	ubfx	x22, x7, #12, #4
1000bf8cc:     	ldrb	w22, [x16, x22]
1000bf8d0:     	ubfx	x23, x7, #16, #4
1000bf8d4:     	add	w19, w19, w20
1000bf8d8:     	add	w19, w19, w21
1000bf8dc:     	ldrb	w20, [x6, x23]
1000bf8e0:     	ubfx	x21, x7, #20, #4
1000bf8e4:     	ldrb	w21, [x15, x21]
1000bf8e8:     	add	w19, w19, w22
1000bf8ec:     	add	w19, w19, w20
1000bf8f0:     	ubfx	x20, x7, #24, #4
1000bf8f4:     	ldrb	w20, [x14, x20]
1000bf8f8:     	add	w19, w19, w21
1000bf8fc:     	add	w19, w19, w20
1000bf900:     	lsr	x7, x7, #28
1000bf904:     	ldrb	w7, [x13, x7]
1000bf908:     	add	w7, w19, w7
1000bf90c:     	scvtf	s0, w7
1000bf910:     	fadd	s0, s2, s0
1000bf914:     	str	s0, [x3, #4]
1000bf918:     	ldur	w7, [x9, #-8]
1000bf91c:     	and	x19, x7, #0xf
1000bf920:     	ldrb	w19, [x5, x19]
1000bf924:     	ubfx	x20, x7, #4, #4
1000bf928:     	ldrb	w20, [x4, x20]
1000bf92c:     	ubfx	x21, x7, #8, #4
1000bf930:     	ldrb	w21, [x17, x21]
1000bf934:     	ubfx	x22, x7, #12, #4
1000bf938:     	ldrb	w22, [x16, x22]
1000bf93c:     	ubfx	x23, x7, #16, #4
1000bf940:     	add	w19, w19, w20
1000bf944:     	add	w19, w19, w21
1000bf948:     	ldrb	w20, [x6, x23]
1000bf94c:     	ubfx	x21, x7, #20, #4
1000bf950:     	ldrb	w21, [x15, x21]
1000bf954:     	add	w19, w19, w22
1000bf958:     	add	w19, w19, w20
1000bf95c:     	ubfx	x20, x7, #24, #4
1000bf960:     	ldrb	w20, [x14, x20]
1000bf964:     	add	w19, w19, w21
1000bf968:     	add	w19, w19, w20
1000bf96c:     	lsr	x7, x7, #28
1000bf970:     	ldrb	w7, [x13, x7]
1000bf974:     	add	w7, w19, w7
1000bf978:     	scvtf	s0, w7
1000bf97c:     	ldp	s1, s2, [x3, #8]
1000bf980:     	fadd	s0, s1, s0
1000bf984:     	str	s0, [x3, #8]
1000bf988:     	ldur	w7, [x9, #-4]
1000bf98c:     	and	x19, x7, #0xf
1000bf990:     	ldrb	w19, [x5, x19]
1000bf994:     	ubfx	x20, x7, #4, #4
1000bf998:     	ldrb	w20, [x4, x20]
1000bf99c:     	ubfx	x21, x7, #8, #4
1000bf9a0:     	ldrb	w21, [x17, x21]
1000bf9a4:     	ubfx	x22, x7, #12, #4
1000bf9a8:     	ldrb	w22, [x16, x22]
1000bf9ac:     	ubfx	x23, x7, #16, #4
1000bf9b0:     	ldrb	w23, [x6, x23]
1000bf9b4:     	ubfx	x24, x7, #20, #4
1000bf9b8:     	add	w19, w19, w20
1000bf9bc:     	add	w19, w19, w21
1000bf9c0:     	ldrb	w20, [x15, x24]
1000bf9c4:     	ubfx	x21, x7, #24, #4
1000bf9c8:     	ldrb	w21, [x14, x21]
1000bf9cc:     	add	w19, w19, w22
1000bf9d0:     	add	w19, w19, w23
1000bf9d4:     	lsr	x7, x7, #28
1000bf9d8:     	ldrb	w7, [x13, x7]
1000bf9dc:     	add	w19, w19, w20
1000bf9e0:     	add	w19, w19, w21
1000bf9e4:     	add	w7, w19, w7
1000bf9e8:     	scvtf	s0, w7
1000bf9ec:     	fadd	s0, s2, s0
1000bf9f0:     	str	s0, [x3, #12]
1000bf9f4:     	ldr	w7, [x9]
1000bf9f8:     	and	x19, x7, #0xf
1000bf9fc:     	ldrb	w19, [x5, x19]
1000bfa00:     	ubfx	x20, x7, #4, #4
1000bfa04:     	ldrb	w20, [x4, x20]
1000bfa08:     	ubfx	x21, x7, #8, #4
1000bfa0c:     	ldrb	w21, [x17, x21]
1000bfa10:     	ubfx	x22, x7, #12, #4
1000bfa14:     	ldrb	w22, [x16, x22]
1000bfa18:     	ubfx	x23, x7, #16, #4
1000bfa1c:     	ldrb	w23, [x6, x23]
1000bfa20:     	add	w19, w19, w20
1000bfa24:     	add	w19, w19, w21
1000bfa28:     	ubfx	x20, x7, #20, #4
1000bfa2c:     	ldrb	w20, [x15, x20]
1000bfa30:     	ubfx	x21, x7, #24, #4
1000bfa34:     	add	w19, w19, w22
1000bfa38:     	add	w19, w19, w23
1000bfa3c:     	ldrb	w21, [x14, x21]
1000bfa40:     	lsr	x7, x7, #28
1000bfa44:     	ldrb	w7, [x13, x7]
1000bfa48:     	add	w19, w19, w20
1000bfa4c:     	add	w19, w19, w21
1000bfa50:     	add	w7, w19, w7
1000bfa54:     	scvtf	s0, w7
1000bfa58:     	ldp	s1, s2, [x3, #16]
1000bfa5c:     	fadd	s0, s1, s0
1000bfa60:     	str	s0, [x3, #16]
1000bfa64:     	ldr	w7, [x9, #4]
1000bfa68:     	and	x19, x7, #0xf
1000bfa6c:     	ldrb	w19, [x5, x19]
1000bfa70:     	ubfx	x20, x7, #4, #4
1000bfa74:     	ldrb	w20, [x4, x20]
1000bfa78:     	ubfx	x21, x7, #8, #4
1000bfa7c:     	ldrb	w21, [x17, x21]
1000bfa80:     	ubfx	x22, x7, #12, #4
1000bfa84:     	ldrb	w22, [x16, x22]
1000bfa88:     	ubfx	x23, x7, #16, #4
1000bfa8c:     	add	w19, w19, w20
1000bfa90:     	add	w19, w19, w21
1000bfa94:     	ldrb	w20, [x6, x23]
1000bfa98:     	ubfx	x21, x7, #20, #4
1000bfa9c:     	ldrb	w21, [x15, x21]
1000bfaa0:     	add	w19, w19, w22
1000bfaa4:     	add	w19, w19, w20
1000bfaa8:     	ubfx	x20, x7, #24, #4
1000bfaac:     	ldrb	w20, [x14, x20]
1000bfab0:     	add	w19, w19, w21
1000bfab4:     	add	w19, w19, w20
1000bfab8:     	lsr	x7, x7, #28
1000bfabc:     	ldrb	w7, [x13, x7]
1000bfac0:     	add	w7, w19, w7
1000bfac4:     	scvtf	s0, w7
1000bfac8:     	fadd	s0, s2, s0
1000bfacc:     	str	s0, [x3, #20]
1000bfad0:     	ldr	w7, [x9, #8]
1000bfad4:     	and	x19, x7, #0xf
1000bfad8:     	ldrb	w19, [x5, x19]
1000bfadc:     	ubfx	x20, x7, #4, #4
1000bfae0:     	ldrb	w20, [x4, x20]
1000bfae4:     	ubfx	x21, x7, #8, #4
1000bfae8:     	ldrb	w21, [x17, x21]
1000bfaec:     	ubfx	x22, x7, #12, #4
1000bfaf0:     	ldrb	w22, [x16, x22]
1000bfaf4:     	ubfx	x23, x7, #16, #4
1000bfaf8:     	add	w19, w19, w20
1000bfafc:     	add	w19, w19, w21
1000bfb00:     	ldrb	w20, [x6, x23]
1000bfb04:     	ubfx	x21, x7, #20, #4
1000bfb08:     	ldrb	w21, [x15, x21]
1000bfb0c:     	add	w19, w19, w22
1000bfb10:     	add	w19, w19, w20
1000bfb14:     	ubfx	x20, x7, #24, #4
1000bfb18:     	ldrb	w20, [x14, x20]
1000bfb1c:     	add	w19, w19, w21
1000bfb20:     	add	w19, w19, w20
1000bfb24:     	lsr	x7, x7, #28
1000bfb28:     	ldrb	w7, [x13, x7]
1000bfb2c:     	add	w7, w19, w7
1000bfb30:     	scvtf	s0, w7
1000bfb34:     	ldp	s1, s2, [x3, #24]
1000bfb38:     	fadd	s0, s1, s0
1000bfb3c:     	str	s0, [x3, #24]
1000bfb40:     	ldr	w7, [x9, #12]
1000bfb44:     	and	x19, x7, #0xf
1000bfb48:     	ldrb	w5, [x5, x19]
1000bfb4c:     	ubfx	x19, x7, #4, #4
1000bfb50:     	ldrb	w4, [x4, x19]
1000bfb54:     	ubfx	x19, x7, #8, #4
1000bfb58:     	ldrb	w17, [x17, x19]
1000bfb5c:     	ubfx	x19, x7, #12, #4
1000bfb60:     	ldrb	w16, [x16, x19]
1000bfb64:     	ubfx	x19, x7, #16, #4
1000bfb68:     	ldrb	w6, [x6, x19]
1000bfb6c:     	add	w4, w5, w4
1000bfb70:     	add	w17, w4, w17
1000bfb74:     	ubfx	x4, x7, #20, #4
1000bfb78:     	ldrb	w15, [x15, x4]
1000bfb7c:     	ubfx	x4, x7, #24, #4
1000bfb80:     	add	w16, w17, w16
1000bfb84:     	add	w16, w16, w6
1000bfb88:     	ldrb	w14, [x14, x4]
1000bfb8c:     	lsr	x17, x7, #28
1000bfb90:     	ldrb	w13, [x13, x17]
1000bfb94:     	add	w15, w16, w15
1000bfb98:     	add	w14, w15, w14
1000bfb9c:     	add	w13, w14, w13
1000bfba0:     	scvtf	s0, w13
1000bfba4:     	fadd	s0, s2, s0
1000bfba8:     	str	s0, [x3, #28]
1000bfbac:     	add	x13, x10, #8
1000bfbb0:     	add	x12, x12, x8
1000bfbb4:     	add	x14, x10, #16
1000bfbb8:     	add	x9, x9, #32
1000bfbbc:     	mov	x10, x13
1000bfbc0:     	cmp	x14, x2
1000bfbc4:     	b.ls	0x1000bf7dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000bfbc8:     	cmp	x13, x2
1000bfbcc:     	b.hs	0x1000bfd80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5e0>
1000bfbd0:     	ldp	s0, s1, [x3, #8]
1000bfbd4:     	lsl	x9, x13, #2
1000bfbd8:     	mov	w10, #-16
1000bfbdc:     	ldr	s2, [x3, #16]
1000bfbe0:     	lsr	x11, x13, #3
1000bfbe4:     	mul	x12, x8, x11
1000bfbe8:     	ubfx	x11, x13, #1, #2
1000bfbec:     	orr	x12, x12, x11
1000bfbf0:     	ldrb	w14, [x1, x12]
1000bfbf4:     	and	w12, w9, #0x4
1000bfbf8:     	lsr	w14, w14, w12
1000bfbfc:     	and	w15, w14, #0xf
1000bfc00:     	cmp	w15, #8
1000bfc04:     	csel	w15, wzr, w10, lo
1000bfc08:     	and	x16, x9, #0xffffffffffffffe0
1000bfc0c:     	bfxil	x16, x13, #1, #2
1000bfc10:     	bfxil	w15, w14, #0, #4
1000bfc14:     	add	x14, x0, x16
1000bfc18:     	ldrb	w16, [x14]
1000bfc1c:     	lsr	w16, w16, w12
1000bfc20:     	and	w17, w16, #0xf
1000bfc24:     	scvtf	s3, w15
1000bfc28:     	cmp	w17, #8
1000bfc2c:     	csel	w15, wzr, w10, lo
1000bfc30:     	bfxil	w15, w16, #0, #4
1000bfc34:     	scvtf	s4, w15
1000bfc38:     	fsub	s4, s4, s3
1000bfc3c:     	ldp	s5, s6, [x3]
1000bfc40:     	fmadd	s4, s4, s4, s5
1000bfc44:     	str	s4, [x3]
1000bfc48:     	ldrb	w15, [x14, #4]
1000bfc4c:     	lsr	w15, w15, w12
1000bfc50:     	and	w16, w15, #0xf
1000bfc54:     	cmp	w16, #8
1000bfc58:     	csel	w16, wzr, w10, lo
1000bfc5c:     	bfxil	w16, w15, #0, #4
1000bfc60:     	scvtf	s4, w16
1000bfc64:     	fsub	s4, s4, s3
1000bfc68:     	fmadd	s4, s4, s4, s6
1000bfc6c:     	str	s4, [x3, #4]
1000bfc70:     	ldrb	w15, [x14, #8]
1000bfc74:     	lsr	w15, w15, w12
1000bfc78:     	and	w16, w15, #0xf
1000bfc7c:     	cmp	w16, #8
1000bfc80:     	csel	w16, wzr, w10, lo
1000bfc84:     	bfxil	w16, w15, #0, #4
1000bfc88:     	scvtf	s4, w16
1000bfc8c:     	fsub	s4, s4, s3
1000bfc90:     	fmadd	s0, s4, s4, s0
1000bfc94:     	str	s0, [x3, #8]
1000bfc98:     	ldrb	w15, [x14, #12]
1000bfc9c:     	lsr	w15, w15, w12
1000bfca0:     	and	w16, w15, #0xf
1000bfca4:     	cmp	w16, #8
1000bfca8:     	csel	w16, wzr, w10, lo
1000bfcac:     	bfxil	w16, w15, #0, #4
1000bfcb0:     	scvtf	s4, w16
1000bfcb4:     	fsub	s4, s4, s3
1000bfcb8:     	fmadd	s1, s4, s4, s1
1000bfcbc:     	str	s1, [x3, #12]
1000bfcc0:     	ldrb	w15, [x14, #16]
1000bfcc4:     	lsr	w15, w15, w12
1000bfcc8:     	and	w16, w15, #0xf
1000bfccc:     	cmp	w16, #8
1000bfcd0:     	csel	w16, wzr, w10, lo
1000bfcd4:     	bfxil	w16, w15, #0, #4
1000bfcd8:     	scvtf	s4, w16
1000bfcdc:     	fsub	s4, s4, s3
1000bfce0:     	fmadd	s2, s4, s4, s2
1000bfce4:     	str	s2, [x3, #16]
1000bfce8:     	ldrb	w15, [x14, #20]
1000bfcec:     	lsr	w15, w15, w12
1000bfcf0:     	and	w16, w15, #0xf
1000bfcf4:     	cmp	w16, #8
1000bfcf8:     	csel	w16, wzr, w10, lo
1000bfcfc:     	bfxil	w16, w15, #0, #4
1000bfd00:     	scvtf	s4, w16
1000bfd04:     	fsub	s4, s4, s3
1000bfd08:     	ldp	s5, s6, [x3, #20]
1000bfd0c:     	fmadd	s4, s4, s4, s5
1000bfd10:     	str	s4, [x3, #20]
1000bfd14:     	ldrb	w14, [x14, #24]
1000bfd18:     	lsr	w14, w14, w12
1000bfd1c:     	and	w15, w14, #0xf
1000bfd20:     	cmp	w15, #8
1000bfd24:     	csel	w15, wzr, w10, lo
1000bfd28:     	bfxil	w15, w14, #0, #4
1000bfd2c:     	scvtf	s4, w15
1000bfd30:     	fsub	s4, s4, s3
1000bfd34:     	fmadd	s4, s4, s4, s6
1000bfd38:     	str	s4, [x3, #24]
1000bfd3c:     	orr	x11, x9, x11
1000bfd40:     	orr	x11, x11, #0x1c
1000bfd44:     	ldrb	w11, [x0, x11]
1000bfd48:     	lsr	w11, w11, w12
1000bfd4c:     	and	w12, w11, #0xf
1000bfd50:     	cmp	w12, #8
1000bfd54:     	csel	w12, wzr, w10, lo
1000bfd58:     	bfxil	w12, w11, #0, #4
1000bfd5c:     	scvtf	s4, w12
1000bfd60:     	fsub	s3, s4, s3
1000bfd64:     	ldr	s4, [x3, #28]
1000bfd68:     	fmadd	s3, s3, s3, s4
1000bfd6c:     	str	s3, [x3, #28]
1000bfd70:     	add	x13, x13, #1
1000bfd74:     	add	x9, x9, #4
1000bfd78:     	cmp	x2, x13
1000bfd7c:     	b.ne	0x1000bfbe0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000bfd80:     	ldp	x20, x19, [sp, #32]
1000bfd84:     	ldp	x22, x21, [sp, #16]
1000bfd88:     	ldp	x24, x23, [sp], #48
1000bfd8c:     	ret

