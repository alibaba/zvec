00000001000d1b34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d1b34:     	sub	sp, sp, #400
1000d1b38:     	stp	x28, x27, [sp, #304]
1000d1b3c:     	stp	x26, x25, [sp, #320]
1000d1b40:     	stp	x24, x23, [sp, #336]
1000d1b44:     	stp	x22, x21, [sp, #352]
1000d1b48:     	stp	x20, x19, [sp, #368]
1000d1b4c:     	stp	x29, x30, [sp, #384]
1000d1b50:     	add	x29, sp, #384
1000d1b54:     	str	x3, [sp]
1000d1b58:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30>
1000d1b5c:     	ldr	x8, [x8, #392]
1000d1b60:     	ldr	x8, [x8]
1000d1b64:     	stur	x8, [x29, #-96]
1000d1b68:     	movi.2d	v0, #0000000000000000
1000d1b6c:     	stp	q0, q0, [sp, #256]
1000d1b70:     	stp	q0, q0, [sp, #224]
1000d1b74:     	stp	q0, q0, [sp, #192]
1000d1b78:     	stp	q0, q0, [sp, #160]
1000d1b7c:     	stp	q0, q0, [sp, #128]
1000d1b80:     	stp	q0, q0, [sp, #96]
1000d1b84:     	stp	q0, q0, [sp, #64]
1000d1b88:     	stp	q0, q0, [sp, #32]
1000d1b8c:     	ands	x8, x2, #0xfffffffffffffffe
1000d1b90:     	b.eq	0x1000d1d14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d1b94:     	add	x8, x1, x8
1000d1b98:     	str	x8, [sp, #8]
1000d1b9c:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d1ba0:     	add	x9, x9, #1724
1000d1ba4:     	mov	x11, #0
1000d1ba8:     	ldp	w4, w23, [x1]
1000d1bac:     	ubfx	x8, x4, #8, #4
1000d1bb0:     	stp	x1, x8, [sp, #16]
1000d1bb4:     	ubfx	x13, x4, #16, #4
1000d1bb8:     	and	x14, x4, #0xf
1000d1bbc:     	ubfx	x15, x4, #24, #4
1000d1bc0:     	ubfx	x16, x4, #4, #4
1000d1bc4:     	ubfx	x17, x4, #12, #4
1000d1bc8:     	ubfx	x2, x4, #20, #4
1000d1bcc:     	lsr	x4, x4, #28
1000d1bd0:     	and	x5, x23, #0xf
1000d1bd4:     	ubfx	x6, x23, #8, #4
1000d1bd8:     	ubfx	x7, x23, #16, #4
1000d1bdc:     	ubfx	x19, x23, #24, #4
1000d1be0:     	ubfx	x20, x23, #4, #4
1000d1be4:     	ubfx	x21, x23, #12, #4
1000d1be8:     	ubfx	x22, x23, #20, #4
1000d1bec:     	lsr	x23, x23, #28
1000d1bf0:     	ldr	w24, [x0, x11]
1000d1bf4:     	lsl	w25, w24, #4
1000d1bf8:     	and	x25, x25, #0xf0
1000d1bfc:     	add	x25, x9, x25
1000d1c00:     	and	x26, x24, #0xf0
1000d1c04:     	add	x26, x9, x26
1000d1c08:     	lsr	x27, x24, #4
1000d1c0c:     	and	x27, x27, #0xf0
1000d1c10:     	add	x27, x9, x27
1000d1c14:     	lsr	x28, x24, #8
1000d1c18:     	and	x28, x28, #0xf0
1000d1c1c:     	add	x28, x9, x28
1000d1c20:     	lsr	x30, x24, #12
1000d1c24:     	and	x30, x30, #0xf0
1000d1c28:     	add	x30, x9, x30
1000d1c2c:     	lsr	x8, x24, #16
1000d1c30:     	and	x8, x8, #0xf0
1000d1c34:     	add	x8, x9, x8
1000d1c38:     	lsr	x3, x24, #20
1000d1c3c:     	and	x3, x3, #0xf0
1000d1c40:     	add	x3, x9, x3
1000d1c44:     	lsr	x24, x24, #24
1000d1c48:     	and	x24, x24, #0xf0
1000d1c4c:     	ldrb	w10, [x25, x14]
1000d1c50:     	ldr	x12, [sp, #24]
1000d1c54:     	ldrb	w1, [x27, x12]
1000d1c58:     	ldrb	w12, [x30, x13]
1000d1c5c:     	add	w10, w10, w1
1000d1c60:     	add	w10, w10, w12
1000d1c64:     	ldrb	w12, [x3, x15]
1000d1c68:     	ldrb	w1, [x26, x16]
1000d1c6c:     	add	w10, w10, w12
1000d1c70:     	add	w10, w10, w1
1000d1c74:     	ldrb	w12, [x28, x17]
1000d1c78:     	ldrb	w1, [x8, x2]
1000d1c7c:     	add	x24, x9, x24
1000d1c80:     	add	w10, w10, w12
1000d1c84:     	add	w10, w10, w1
1000d1c88:     	ldrb	w12, [x24, x4]
1000d1c8c:     	add	w10, w10, w12
1000d1c90:     	scvtf	s0, w10
1000d1c94:     	add	x10, sp, #32
1000d1c98:     	add	x10, x10, x11
1000d1c9c:     	ldr	s1, [x10]
1000d1ca0:     	ldrb	w12, [x25, x5]
1000d1ca4:     	fadd	s0, s1, s0
1000d1ca8:     	ldrb	w1, [x27, x6]
1000d1cac:     	ldrb	w25, [x30, x7]
1000d1cb0:     	add	w12, w12, w1
1000d1cb4:     	add	w12, w12, w25
1000d1cb8:     	ldrb	w1, [x3, x19]
1000d1cbc:     	ldrb	w3, [x26, x20]
1000d1cc0:     	add	w12, w12, w1
1000d1cc4:     	add	w12, w12, w3
1000d1cc8:     	ldrb	w1, [x28, x21]
1000d1ccc:     	ldrb	w8, [x8, x22]
1000d1cd0:     	add	w12, w12, w1
1000d1cd4:     	add	w8, w12, w8
1000d1cd8:     	ldrb	w12, [x24, x23]
1000d1cdc:     	add	w8, w8, w12
1000d1ce0:     	scvtf	s1, w8
1000d1ce4:     	str	s0, [x10]
1000d1ce8:     	ldr	s0, [x10, #128]
1000d1cec:     	fadd	s0, s0, s1
1000d1cf0:     	str	s0, [x10, #128]
1000d1cf4:     	add	x11, x11, #4
1000d1cf8:     	cmp	x11, #128
1000d1cfc:     	b.ne	0x1000d1bf0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d1d00:     	add	x0, x0, #128
1000d1d04:     	ldp	x8, x1, [sp, #8]
1000d1d08:     	add	x1, x1, #8
1000d1d0c:     	cmp	x1, x8
1000d1d10:     	b.ne	0x1000d1ba4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d1d14:     	ldp	q0, q1, [sp, #224]
1000d1d18:     	ldr	x8, [sp]
1000d1d1c:     	stp	q0, q1, [x8, #192]
1000d1d20:     	ldp	q0, q1, [sp, #256]
1000d1d24:     	stp	q0, q1, [x8, #224]
1000d1d28:     	ldp	q0, q1, [sp, #160]
1000d1d2c:     	stp	q0, q1, [x8, #128]
1000d1d30:     	ldp	q0, q1, [sp, #192]
1000d1d34:     	stp	q0, q1, [x8, #160]
1000d1d38:     	ldp	q0, q1, [sp, #96]
1000d1d3c:     	stp	q0, q1, [x8, #64]
1000d1d40:     	ldp	q0, q1, [sp, #128]
1000d1d44:     	stp	q0, q1, [x8, #96]
1000d1d48:     	ldp	q0, q1, [sp, #32]
1000d1d4c:     	stp	q0, q1, [x8]
1000d1d50:     	ldp	q0, q1, [sp, #64]
1000d1d54:     	stp	q0, q1, [x8, #32]
1000d1d58:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x164>
1000d1d5c:     	ldr	x8, [x8, #392]
1000d1d60:     	ldr	x8, [x8]
1000d1d64:     	ldur	x9, [x29, #-96]
1000d1d68:     	cmp	x8, x9
1000d1d6c:     	b.ne	0x1000d1d90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d1d70:     	ldp	x29, x30, [sp, #384]
1000d1d74:     	ldp	x20, x19, [sp, #368]
1000d1d78:     	ldp	x22, x21, [sp, #352]
1000d1d7c:     	ldp	x24, x23, [sp, #336]
1000d1d80:     	ldp	x26, x25, [sp, #320]
1000d1d84:     	ldp	x28, x27, [sp, #304]
1000d1d88:     	add	sp, sp, #400
1000d1d8c:     	ret
1000d1d90:     	bl	0x100163694 <_strcmp+0x100163694>

