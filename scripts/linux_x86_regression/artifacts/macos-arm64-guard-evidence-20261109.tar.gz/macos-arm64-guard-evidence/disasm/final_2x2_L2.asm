00000001000b858c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b858c:     	stp	x22, x21, [sp, #-32]!
1000b8590:     	stp	x20, x19, [sp, #16]
1000b8594:     	ands	x8, x2, #0xfffffffffffffffe
1000b8598:     	b.eq	0x1000b881c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b859c:     	add	x8, x1, x8
1000b85a0:     	movi	d0, #0000000000000000
1000b85a4:     	adrp	x9, 0x100169000 <void kernel<unsigned char, 2ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x20>
1000b85a8:     	add	x9, x9, #3772
1000b85ac:     	movi	d1, #0000000000000000
1000b85b0:     	movi	d2, #0000000000000000
1000b85b4:     	movi	d3, #0000000000000000
1000b85b8:     	ldp	w10, w11, [x0]
1000b85bc:     	lsl	w12, w10, #4
1000b85c0:     	and	x14, x12, #0xf0
1000b85c4:     	mov	x15, x14
1000b85c8:     	ldp	w12, w13, [x1]
1000b85cc:     	bfxil	x15, x12, #0, #4
1000b85d0:     	ldrb	w15, [x9, x15]
1000b85d4:     	and	x16, x10, #0xf0
1000b85d8:     	mov	x17, x16
1000b85dc:     	bfxil	x17, x12, #4, #4
1000b85e0:     	ldrb	w17, [x9, x17]
1000b85e4:     	lsr	x2, x10, #4
1000b85e8:     	and	x2, x2, #0xf0
1000b85ec:     	mov	x4, x2
1000b85f0:     	bfxil	x4, x12, #8, #4
1000b85f4:     	ldrb	w4, [x9, x4]
1000b85f8:     	lsr	x5, x10, #8
1000b85fc:     	and	x5, x5, #0xf0
1000b8600:     	mov	x6, x5
1000b8604:     	bfxil	x6, x12, #12, #4
1000b8608:     	ldrb	w6, [x9, x6]
1000b860c:     	lsr	x7, x10, #12
1000b8610:     	and	x7, x7, #0xf0
1000b8614:     	mov	x19, x7
1000b8618:     	bfxil	x19, x12, #16, #4
1000b861c:     	ldrb	w19, [x9, x19]
1000b8620:     	add	w15, w15, w17
1000b8624:     	add	w15, w15, w4
1000b8628:     	lsr	x17, x10, #16
1000b862c:     	and	x17, x17, #0xf0
1000b8630:     	mov	x4, x17
1000b8634:     	bfxil	x4, x12, #20, #4
1000b8638:     	add	w15, w15, w6
1000b863c:     	add	w15, w15, w19
1000b8640:     	ldrb	w4, [x9, x4]
1000b8644:     	lsr	x6, x10, #20
1000b8648:     	and	x6, x6, #0xf0
1000b864c:     	mov	x19, x6
1000b8650:     	bfxil	x19, x12, #24, #4
1000b8654:     	ldrb	w19, [x9, x19]
1000b8658:     	add	w15, w15, w4
1000b865c:     	add	w15, w15, w19
1000b8660:     	lsr	x10, x10, #24
1000b8664:     	and	x4, x10, #0xf0
1000b8668:     	lsr	x10, x12, #28
1000b866c:     	orr	x19, x4, x10
1000b8670:     	ldrb	w19, [x9, x19]
1000b8674:     	add	w15, w15, w19
1000b8678:     	scvtf	s4, w15
1000b867c:     	fadd	s0, s0, s4
1000b8680:     	bfxil	x14, x13, #0, #4
1000b8684:     	ldrb	w14, [x9, x14]
1000b8688:     	and	x15, x13, #0xf
1000b868c:     	ubfx	x19, x13, #4, #4
1000b8690:     	bfxil	x16, x13, #4, #4
1000b8694:     	ldrb	w16, [x9, x16]
1000b8698:     	ubfx	x20, x13, #8, #4
1000b869c:     	bfxil	x2, x13, #8, #4
1000b86a0:     	ldrb	w2, [x9, x2]
1000b86a4:     	add	w14, w14, w16
1000b86a8:     	add	w14, w14, w2
1000b86ac:     	ubfx	x16, x13, #12, #4
1000b86b0:     	bfxil	x5, x13, #12, #4
1000b86b4:     	ldrb	w2, [x9, x5]
1000b86b8:     	bfxil	x7, x13, #16, #4
1000b86bc:     	ldrb	w5, [x9, x7]
1000b86c0:     	ubfx	x7, x13, #16, #4
1000b86c4:     	add	w14, w14, w2
1000b86c8:     	add	w14, w14, w5
1000b86cc:     	bfxil	x17, x13, #20, #4
1000b86d0:     	ldrb	w17, [x9, x17]
1000b86d4:     	bfxil	x6, x13, #24, #4
1000b86d8:     	ldrb	w2, [x9, x6]
1000b86dc:     	add	w14, w14, w17
1000b86e0:     	add	w17, w14, w2
1000b86e4:     	lsr	x14, x13, #28
1000b86e8:     	orr	x2, x4, x14
1000b86ec:     	ldrb	w2, [x9, x2]
1000b86f0:     	add	w17, w17, w2
1000b86f4:     	scvtf	s4, w17
1000b86f8:     	ubfx	x17, x13, #20, #4
1000b86fc:     	fadd	s2, s2, s4
1000b8700:     	lsl	w2, w11, #4
1000b8704:     	and	x2, x2, #0xf0
1000b8708:     	orr	w15, w2, w15
1000b870c:     	bfxil	x2, x12, #0, #4
1000b8710:     	ldrb	w2, [x9, x2]
1000b8714:     	and	x4, x11, #0xf0
1000b8718:     	orr	w5, w4, w19
1000b871c:     	bfxil	x4, x12, #4, #4
1000b8720:     	ldrb	w4, [x9, x4]
1000b8724:     	lsr	x6, x11, #4
1000b8728:     	and	x6, x6, #0xf0
1000b872c:     	orr	w19, w6, w20
1000b8730:     	bfxil	x6, x12, #8, #4
1000b8734:     	ldrb	w6, [x9, x6]
1000b8738:     	add	w2, w2, w4
1000b873c:     	add	w2, w2, w6
1000b8740:     	lsr	x4, x11, #8
1000b8744:     	and	x4, x4, #0xf0
1000b8748:     	orr	w16, w4, w16
1000b874c:     	lsr	x6, x11, #12
1000b8750:     	and	x6, x6, #0xf0
1000b8754:     	orr	w7, w6, w7
1000b8758:     	lsr	x20, x11, #16
1000b875c:     	and	x20, x20, #0xf0
1000b8760:     	orr	w17, w20, w17
1000b8764:     	lsr	x21, x11, #20
1000b8768:     	and	x21, x21, #0xf0
1000b876c:     	ubfx	x13, x13, #24, #4
1000b8770:     	orr	w13, w21, w13
1000b8774:     	bfxil	x4, x12, #12, #4
1000b8778:     	ldrb	w4, [x9, x4]
1000b877c:     	bfxil	x6, x12, #16, #4
1000b8780:     	ldrb	w6, [x9, x6]
1000b8784:     	bfxil	x20, x12, #20, #4
1000b8788:     	ldrb	w20, [x9, x20]
1000b878c:     	bfxil	x21, x12, #24, #4
1000b8790:     	ldrb	w12, [x9, x21]
1000b8794:     	add	w2, w2, w4
1000b8798:     	add	w2, w2, w6
1000b879c:     	add	w2, w2, w20
1000b87a0:     	add	w12, w2, w12
1000b87a4:     	lsr	x11, x11, #24
1000b87a8:     	and	x11, x11, #0xf0
1000b87ac:     	orr	x10, x11, x10
1000b87b0:     	ldrb	w10, [x9, x10]
1000b87b4:     	add	w10, w12, w10
1000b87b8:     	scvtf	s4, w10
1000b87bc:     	fadd	s1, s1, s4
1000b87c0:     	ldrb	w10, [x9, w15, uxtw]
1000b87c4:     	ldrb	w12, [x9, w5, uxtw]
1000b87c8:     	ldrb	w15, [x9, w19, uxtw]
1000b87cc:     	add	w10, w10, w12
1000b87d0:     	add	w10, w10, w15
1000b87d4:     	ldrb	w12, [x9, w16, uxtw]
1000b87d8:     	ldrb	w15, [x9, w7, uxtw]
1000b87dc:     	add	w10, w10, w12
1000b87e0:     	add	w10, w10, w15
1000b87e4:     	ldrb	w12, [x9, w17, uxtw]
1000b87e8:     	ldrb	w13, [x9, w13, uxtw]
1000b87ec:     	add	w10, w10, w12
1000b87f0:     	add	w10, w10, w13
1000b87f4:     	orr	w11, w11, w14
1000b87f8:     	ldrb	w11, [x9, w11, uxtw]
1000b87fc:     	add	w10, w10, w11
1000b8800:     	scvtf	s4, w10
1000b8804:     	fadd	s3, s3, s4
1000b8808:     	add	x0, x0, #8
1000b880c:     	add	x1, x1, #8
1000b8810:     	cmp	x1, x8
1000b8814:     	b.ne	0x1000b85b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8818:     	b	0x1000b882c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b881c:     	movi	d0, #0000000000000000
1000b8820:     	movi	d1, #0000000000000000
1000b8824:     	movi	d2, #0000000000000000
1000b8828:     	movi	d3, #0000000000000000
1000b882c:     	str	s0, [x3]
1000b8830:     	str	s1, [x3, #4]
1000b8834:     	str	s2, [x3, #8]
1000b8838:     	str	s3, [x3, #12]
1000b883c:     	ldp	x20, x19, [sp, #16]
1000b8840:     	ldp	x22, x21, [sp], #32
1000b8844:     	ret

