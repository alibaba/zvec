00000001000d819c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d819c:     	stp	x28, x27, [sp, #-64]!
1000d81a0:     	stp	x22, x21, [sp, #16]
1000d81a4:     	stp	x20, x19, [sp, #32]
1000d81a8:     	stp	x29, x30, [sp, #48]
1000d81ac:     	add	x29, sp, #48
1000d81b0:     	sub	sp, sp, #2064
1000d81b4:     	mov	x19, x3
1000d81b8:     	mov	x20, x1
1000d81bc:     	mov	x21, x0
1000d81c0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xcc>
1000d81c4:     	ldr	x8, [x8, #392]
1000d81c8:     	ldr	x8, [x8]
1000d81cc:     	stur	x8, [x29, #-56]
1000d81d0:     	lsl	x8, x2, #3
1000d81d4:     	and	x22, x8, #0xfffffffffffffff0
1000d81d8:     	add	x0, sp, #8
1000d81dc:     	mov	w1, #2048
1000d81e0:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d81e4:     	cbz	x22, 0x1000d82fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d81e8:     	add	x8, x20, x22
1000d81ec:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf0>
1000d81f0:     	add	x9, x9, #1724
1000d81f4:     	mov	x10, #0
1000d81f8:     	add	x11, sp, #8
1000d81fc:     	mov	x12, #0
1000d8200:     	ldr	w2, [x21, x10, lsl #2]
1000d8204:     	lsl	w13, w2, #4
1000d8208:     	and	x13, x13, #0xf0
1000d820c:     	and	x14, x2, #0xf0
1000d8210:     	lsr	x15, x2, #4
1000d8214:     	and	x15, x15, #0xf0
1000d8218:     	lsr	x16, x2, #8
1000d821c:     	and	x16, x16, #0xf0
1000d8220:     	lsr	x17, x2, #12
1000d8224:     	and	x17, x17, #0xf0
1000d8228:     	lsr	x0, x2, #16
1000d822c:     	and	x0, x0, #0xf0
1000d8230:     	lsr	x1, x2, #20
1000d8234:     	and	x1, x1, #0xf0
1000d8238:     	lsr	x2, x2, #24
1000d823c:     	and	x2, x2, #0xf0
1000d8240:     	mov	x3, x11
1000d8244:     	ldr	w4, [x20, x12]
1000d8248:     	and	x5, x4, #0xf
1000d824c:     	orr	x5, x13, x5
1000d8250:     	ldrb	w5, [x9, x5]
1000d8254:     	ubfx	x6, x4, #4, #4
1000d8258:     	orr	x6, x14, x6
1000d825c:     	ldrb	w6, [x9, x6]
1000d8260:     	ubfx	x7, x4, #8, #4
1000d8264:     	orr	x7, x15, x7
1000d8268:     	ldrb	w7, [x9, x7]
1000d826c:     	add	w5, w5, w6
1000d8270:     	add	w5, w5, w7
1000d8274:     	ubfx	x6, x4, #12, #4
1000d8278:     	orr	x6, x16, x6
1000d827c:     	ldrb	w6, [x9, x6]
1000d8280:     	ubfx	x7, x4, #16, #4
1000d8284:     	orr	x7, x17, x7
1000d8288:     	ldrb	w7, [x9, x7]
1000d828c:     	add	w5, w5, w6
1000d8290:     	add	w5, w5, w7
1000d8294:     	ubfx	x6, x4, #20, #4
1000d8298:     	orr	x6, x0, x6
1000d829c:     	ldrb	w6, [x9, x6]
1000d82a0:     	ubfx	x7, x4, #24, #4
1000d82a4:     	orr	x7, x1, x7
1000d82a8:     	ldrb	w7, [x9, x7]
1000d82ac:     	add	w5, w5, w6
1000d82b0:     	add	w5, w5, w7
1000d82b4:     	orr	x4, x2, x4, lsr #28
1000d82b8:     	ldrb	w4, [x9, x4]
1000d82bc:     	add	w4, w5, w4
1000d82c0:     	scvtf	s0, w4
1000d82c4:     	ldr	s1, [x3]
1000d82c8:     	fadd	s0, s1, s0
1000d82cc:     	str	s0, [x3], #128
1000d82d0:     	add	x12, x12, #4
1000d82d4:     	cmp	x12, #64
1000d82d8:     	b.ne	0x1000d8244 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d82dc:     	add	x10, x10, #1
1000d82e0:     	add	x11, x11, #4
1000d82e4:     	cmp	x10, #32
1000d82e8:     	b.ne	0x1000d81fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d82ec:     	add	x21, x21, #128
1000d82f0:     	add	x20, x20, #64
1000d82f4:     	cmp	x20, x8
1000d82f8:     	b.ne	0x1000d81f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d82fc:     	add	x1, sp, #8
1000d8300:     	mov	x0, x19
1000d8304:     	mov	w2, #2048
1000d8308:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d830c:     	ldur	x8, [x29, #-56]
1000d8310:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x21c>
1000d8314:     	ldr	x9, [x9, #392]
1000d8318:     	ldr	x9, [x9]
1000d831c:     	cmp	x9, x8
1000d8320:     	b.ne	0x1000d833c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d8324:     	add	sp, sp, #2064
1000d8328:     	ldp	x29, x30, [sp, #48]
1000d832c:     	ldp	x20, x19, [sp, #32]
1000d8330:     	ldp	x22, x21, [sp, #16]
1000d8334:     	ldp	x28, x27, [sp], #64
1000d8338:     	ret
1000d833c:     	bl	0x100163694 <_strcmp+0x100163694>

