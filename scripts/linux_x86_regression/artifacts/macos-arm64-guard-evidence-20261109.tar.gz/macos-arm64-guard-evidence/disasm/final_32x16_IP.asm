00000001000d85b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d85b4:     	stp	x28, x27, [sp, #-64]!
1000d85b8:     	stp	x22, x21, [sp, #16]
1000d85bc:     	stp	x20, x19, [sp, #32]
1000d85c0:     	stp	x29, x30, [sp, #48]
1000d85c4:     	add	x29, sp, #48
1000d85c8:     	sub	sp, sp, #2064
1000d85cc:     	mov	x19, x3
1000d85d0:     	mov	x20, x1
1000d85d4:     	mov	x21, x0
1000d85d8:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xd0>
1000d85dc:     	ldr	x8, [x8, #392]
1000d85e0:     	ldr	x8, [x8]
1000d85e4:     	stur	x8, [x29, #-56]
1000d85e8:     	lsl	x8, x2, #3
1000d85ec:     	and	x22, x8, #0xfffffffffffffff0
1000d85f0:     	add	x0, sp, #8
1000d85f4:     	mov	w1, #2048
1000d85f8:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d85fc:     	cbz	x22, 0x1000d8714 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d8600:     	add	x8, x20, x22
1000d8604:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xf4>
1000d8608:     	add	x9, x9, #1980
1000d860c:     	mov	x10, #0
1000d8610:     	add	x11, sp, #8
1000d8614:     	mov	x12, #0
1000d8618:     	ldr	w2, [x21, x10, lsl #2]
1000d861c:     	lsl	w13, w2, #4
1000d8620:     	and	x13, x13, #0xf0
1000d8624:     	and	x14, x2, #0xf0
1000d8628:     	lsr	x15, x2, #4
1000d862c:     	and	x15, x15, #0xf0
1000d8630:     	lsr	x16, x2, #8
1000d8634:     	and	x16, x16, #0xf0
1000d8638:     	lsr	x17, x2, #12
1000d863c:     	and	x17, x17, #0xf0
1000d8640:     	lsr	x0, x2, #16
1000d8644:     	and	x0, x0, #0xf0
1000d8648:     	lsr	x1, x2, #20
1000d864c:     	and	x1, x1, #0xf0
1000d8650:     	lsr	x2, x2, #24
1000d8654:     	and	x2, x2, #0xf0
1000d8658:     	mov	x3, x11
1000d865c:     	ldr	w4, [x20, x12]
1000d8660:     	and	x5, x4, #0xf
1000d8664:     	orr	x5, x13, x5
1000d8668:     	ldrsb	w5, [x9, x5]
1000d866c:     	ubfx	x6, x4, #4, #4
1000d8670:     	orr	x6, x14, x6
1000d8674:     	ldrsb	w6, [x9, x6]
1000d8678:     	ubfx	x7, x4, #8, #4
1000d867c:     	orr	x7, x15, x7
1000d8680:     	ldrsb	w7, [x9, x7]
1000d8684:     	add	w5, w5, w6
1000d8688:     	add	w5, w5, w7
1000d868c:     	ubfx	x6, x4, #12, #4
1000d8690:     	orr	x6, x16, x6
1000d8694:     	ldrsb	w6, [x9, x6]
1000d8698:     	ubfx	x7, x4, #16, #4
1000d869c:     	orr	x7, x17, x7
1000d86a0:     	ldrsb	w7, [x9, x7]
1000d86a4:     	add	w5, w5, w6
1000d86a8:     	add	w5, w5, w7
1000d86ac:     	ubfx	x6, x4, #20, #4
1000d86b0:     	orr	x6, x0, x6
1000d86b4:     	ldrsb	w6, [x9, x6]
1000d86b8:     	ubfx	x7, x4, #24, #4
1000d86bc:     	orr	x7, x1, x7
1000d86c0:     	ldrsb	w7, [x9, x7]
1000d86c4:     	add	w5, w5, w6
1000d86c8:     	add	w5, w5, w7
1000d86cc:     	orr	x4, x2, x4, lsr #28
1000d86d0:     	ldrsb	w4, [x9, x4]
1000d86d4:     	add	w4, w5, w4
1000d86d8:     	scvtf	s0, w4
1000d86dc:     	ldr	s1, [x3]
1000d86e0:     	fadd	s0, s1, s0
1000d86e4:     	str	s0, [x3], #128
1000d86e8:     	add	x12, x12, #4
1000d86ec:     	cmp	x12, #64
1000d86f0:     	b.ne	0x1000d865c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d86f4:     	add	x10, x10, #1
1000d86f8:     	add	x11, x11, #4
1000d86fc:     	cmp	x10, #32
1000d8700:     	b.ne	0x1000d8614 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d8704:     	add	x21, x21, #128
1000d8708:     	add	x20, x20, #64
1000d870c:     	cmp	x20, x8
1000d8710:     	b.ne	0x1000d860c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d8714:     	add	x1, sp, #8
1000d8718:     	mov	x0, x19
1000d871c:     	mov	w2, #2048
1000d8720:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d8724:     	ldur	x8, [x29, #-56]
1000d8728:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x220>
1000d872c:     	ldr	x9, [x9, #392]
1000d8730:     	ldr	x9, [x9]
1000d8734:     	cmp	x9, x8
1000d8738:     	b.ne	0x1000d8754 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d873c:     	add	sp, sp, #2064
1000d8740:     	ldp	x29, x30, [sp, #48]
1000d8744:     	ldp	x20, x19, [sp, #32]
1000d8748:     	ldp	x22, x21, [sp, #16]
1000d874c:     	ldp	x28, x27, [sp], #64
1000d8750:     	ret
1000d8754:     	bl	0x100163694 <_strcmp+0x100163694>

