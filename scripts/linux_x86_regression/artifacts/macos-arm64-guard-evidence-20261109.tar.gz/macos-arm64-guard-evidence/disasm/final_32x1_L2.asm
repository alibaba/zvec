00000001000d01ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000d01ac:     	stp	x22, x21, [sp, #-32]!
1000d01b0:     	stp	x20, x19, [sp, #16]
1000d01b4:     	movi.2d	v0, #0000000000000000
1000d01b8:     	stp	q0, q0, [x3, #96]
1000d01bc:     	stp	q0, q0, [x3, #64]
1000d01c0:     	stp	q0, q0, [x3, #32]
1000d01c4:     	stp	q0, q0, [x3]
1000d01c8:     	cmp	x2, #8
1000d01cc:     	b.hs	0x1000d01d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000d01d0:     	mov	x8, #0
1000d01d4:     	b	0x1000d02e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000d01d8:     	mov	x8, #0
1000d01dc:     	mov	w12, #8
1000d01e0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x94>
1000d01e4:     	add	x9, x9, #1724
1000d01e8:     	mov	x10, x0
1000d01ec:     	mov	x11, #0
1000d01f0:     	lsr	x8, x8, #1
1000d01f4:     	mul	x8, x8, x4
1000d01f8:     	ldr	w6, [x1, x8]
1000d01fc:     	mov	x8, x12
1000d0200:     	lsl	w12, w6, #4
1000d0204:     	and	x12, x12, #0xf0
1000d0208:     	add	x12, x9, x12
1000d020c:     	and	x13, x6, #0xf0
1000d0210:     	add	x13, x9, x13
1000d0214:     	lsr	x14, x6, #4
1000d0218:     	and	x14, x14, #0xf0
1000d021c:     	add	x14, x9, x14
1000d0220:     	lsr	x15, x6, #8
1000d0224:     	and	x15, x15, #0xf0
1000d0228:     	add	x15, x9, x15
1000d022c:     	lsr	x16, x6, #12
1000d0230:     	and	x16, x16, #0xf0
1000d0234:     	add	x16, x9, x16
1000d0238:     	lsr	x17, x6, #16
1000d023c:     	and	x17, x17, #0xf0
1000d0240:     	add	x17, x9, x17
1000d0244:     	lsr	x5, x6, #20
1000d0248:     	and	x5, x5, #0xf0
1000d024c:     	add	x5, x9, x5
1000d0250:     	lsr	x6, x6, #24
1000d0254:     	and	x6, x6, #0xf0
1000d0258:     	add	x6, x9, x6
1000d025c:     	ldr	w7, [x10, x11]
1000d0260:     	and	x19, x7, #0xf
1000d0264:     	ldrb	w19, [x12, x19]
1000d0268:     	ubfx	x20, x7, #4, #4
1000d026c:     	ldrb	w20, [x13, x20]
1000d0270:     	ubfx	x21, x7, #8, #4
1000d0274:     	ldrb	w21, [x14, x21]
1000d0278:     	add	w19, w19, w20
1000d027c:     	add	w19, w19, w21
1000d0280:     	ubfx	x20, x7, #12, #4
1000d0284:     	ldrb	w20, [x15, x20]
1000d0288:     	ubfx	x21, x7, #16, #4
1000d028c:     	ldrb	w21, [x16, x21]
1000d0290:     	add	w19, w19, w20
1000d0294:     	add	w19, w19, w21
1000d0298:     	ubfx	x20, x7, #20, #4
1000d029c:     	ldrb	w20, [x17, x20]
1000d02a0:     	ubfx	x21, x7, #24, #4
1000d02a4:     	ldrb	w21, [x5, x21]
1000d02a8:     	lsr	x7, x7, #28
1000d02ac:     	ldrb	w7, [x6, x7]
1000d02b0:     	add	w19, w19, w20
1000d02b4:     	add	w19, w19, w21
1000d02b8:     	add	w7, w19, w7
1000d02bc:     	scvtf	s0, w7
1000d02c0:     	ldr	s1, [x3, x11]
1000d02c4:     	fadd	s0, s1, s0
1000d02c8:     	str	s0, [x3, x11]
1000d02cc:     	add	x11, x11, #4
1000d02d0:     	cmp	x11, #128
1000d02d4:     	b.ne	0x1000d025c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000d02d8:     	add	x12, x8, #8
1000d02dc:     	add	x10, x10, #128
1000d02e0:     	cmp	x12, x2
1000d02e4:     	b.ls	0x1000d01ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000d02e8:     	cmp	x8, x2
1000d02ec:     	b.hs	0x1000d037c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1d0>
1000d02f0:     	lsl	x9, x4, #2
1000d02f4:     	mov	w10, #-16
1000d02f8:     	mov	x11, #0
1000d02fc:     	lsr	x13, x8, #3
1000d0300:     	lsl	x12, x13, #7
1000d0304:     	mul	x14, x9, x13
1000d0308:     	ubfx	x13, x8, #1, #2
1000d030c:     	orr	x14, x14, x13
1000d0310:     	ldrb	w15, [x1, x14]
1000d0314:     	ubfiz	w14, w8, #2, #1
1000d0318:     	lsr	w15, w15, w14
1000d031c:     	and	w16, w15, #0xf
1000d0320:     	cmp	w16, #8
1000d0324:     	csel	w16, wzr, w10, lo
1000d0328:     	bfxil	w16, w15, #0, #4
1000d032c:     	scvtf	s0, w16
1000d0330:     	add	x15, x12, x11
1000d0334:     	orr	x15, x15, x13
1000d0338:     	ldrb	w15, [x0, x15]
1000d033c:     	lsr	w15, w15, w14
1000d0340:     	and	w16, w15, #0xf
1000d0344:     	cmp	w16, #8
1000d0348:     	csel	w16, wzr, w10, lo
1000d034c:     	bfxil	w16, w15, #0, #4
1000d0350:     	scvtf	s1, w16
1000d0354:     	ldr	s2, [x3, x11]
1000d0358:     	fsub	s1, s1, s0
1000d035c:     	fmadd	s1, s1, s1, s2
1000d0360:     	str	s1, [x3, x11]
1000d0364:     	add	x11, x11, #4
1000d0368:     	cmp	x11, #128
1000d036c:     	b.ne	0x1000d0330 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000d0370:     	add	x8, x8, #1
1000d0374:     	cmp	x8, x2
1000d0378:     	b.ne	0x1000d02f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000d037c:     	ldp	x20, x19, [sp, #16]
1000d0380:     	ldp	x22, x21, [sp], #32
1000d0384:     	ret

