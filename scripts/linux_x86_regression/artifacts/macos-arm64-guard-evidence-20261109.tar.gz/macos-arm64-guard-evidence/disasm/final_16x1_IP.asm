00000001000c7624 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c7624:     	stp	x22, x21, [sp, #-32]!
1000c7628:     	stp	x20, x19, [sp, #16]
1000c762c:     	movi.2d	v0, #0000000000000000
1000c7630:     	stp	q0, q0, [x3, #32]
1000c7634:     	stp	q0, q0, [x3]
1000c7638:     	cmp	x2, #8
1000c763c:     	b.hs	0x1000c7648 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c7640:     	mov	x8, #0
1000c7644:     	b	0x1000c7758 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c7648:     	mov	x8, #0
1000c764c:     	mov	w12, #8
1000c7650:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b8>
1000c7654:     	add	x9, x9, #1468
1000c7658:     	mov	x10, x0
1000c765c:     	mov	x11, #0
1000c7660:     	lsr	x8, x8, #1
1000c7664:     	mul	x8, x8, x4
1000c7668:     	ldr	w6, [x1, x8]
1000c766c:     	mov	x8, x12
1000c7670:     	lsl	w12, w6, #4
1000c7674:     	and	x12, x12, #0xf0
1000c7678:     	add	x12, x9, x12
1000c767c:     	and	x13, x6, #0xf0
1000c7680:     	add	x13, x9, x13
1000c7684:     	lsr	x14, x6, #4
1000c7688:     	and	x14, x14, #0xf0
1000c768c:     	add	x14, x9, x14
1000c7690:     	lsr	x15, x6, #8
1000c7694:     	and	x15, x15, #0xf0
1000c7698:     	add	x15, x9, x15
1000c769c:     	lsr	x16, x6, #12
1000c76a0:     	and	x16, x16, #0xf0
1000c76a4:     	add	x16, x9, x16
1000c76a8:     	lsr	x17, x6, #16
1000c76ac:     	and	x17, x17, #0xf0
1000c76b0:     	add	x17, x9, x17
1000c76b4:     	lsr	x5, x6, #20
1000c76b8:     	and	x5, x5, #0xf0
1000c76bc:     	add	x5, x9, x5
1000c76c0:     	lsr	x6, x6, #24
1000c76c4:     	and	x6, x6, #0xf0
1000c76c8:     	add	x6, x9, x6
1000c76cc:     	ldr	w7, [x10, x11]
1000c76d0:     	and	x19, x7, #0xf
1000c76d4:     	ldrsb	w19, [x12, x19]
1000c76d8:     	ubfx	x20, x7, #4, #4
1000c76dc:     	ldrsb	w20, [x13, x20]
1000c76e0:     	ubfx	x21, x7, #8, #4
1000c76e4:     	ldrsb	w21, [x14, x21]
1000c76e8:     	add	w19, w19, w20
1000c76ec:     	add	w19, w19, w21
1000c76f0:     	ubfx	x20, x7, #12, #4
1000c76f4:     	ldrsb	w20, [x15, x20]
1000c76f8:     	ubfx	x21, x7, #16, #4
1000c76fc:     	ldrsb	w21, [x16, x21]
1000c7700:     	add	w19, w19, w20
1000c7704:     	add	w19, w19, w21
1000c7708:     	ubfx	x20, x7, #20, #4
1000c770c:     	ldrsb	w20, [x17, x20]
1000c7710:     	ubfx	x21, x7, #24, #4
1000c7714:     	ldrsb	w21, [x5, x21]
1000c7718:     	lsr	x7, x7, #28
1000c771c:     	ldrsb	w7, [x6, x7]
1000c7720:     	add	w19, w19, w20
1000c7724:     	add	w19, w19, w21
1000c7728:     	add	w7, w19, w7
1000c772c:     	scvtf	s0, w7
1000c7730:     	ldr	s1, [x3, x11]
1000c7734:     	fadd	s0, s1, s0
1000c7738:     	str	s0, [x3, x11]
1000c773c:     	add	x11, x11, #4
1000c7740:     	cmp	x11, #64
1000c7744:     	b.ne	0x1000c76cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c7748:     	add	x12, x8, #8
1000c774c:     	add	x10, x10, #64
1000c7750:     	cmp	x12, x2
1000c7754:     	b.ls	0x1000c765c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c7758:     	cmp	x8, x2
1000c775c:     	b.hs	0x1000c7a14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000c7760:     	lsl	x9, x4, #2
1000c7764:     	lsl	w10, w8, #2
1000c7768:     	mov	w11, #-16
1000c776c:     	lsr	x13, x8, #3
1000c7770:     	mul	x12, x9, x13
1000c7774:     	ubfx	x14, x8, #1, #2
1000c7778:     	orr	x12, x12, x14
1000c777c:     	ldrb	w15, [x1, x12]
1000c7780:     	and	w12, w10, #0x4
1000c7784:     	lsr	w15, w15, w12
1000c7788:     	and	w16, w15, #0xf
1000c778c:     	cmp	w16, #8
1000c7790:     	csel	w16, wzr, w11, lo
1000c7794:     	bfi	x14, x13, #6, #58
1000c7798:     	add	x13, x0, x14
1000c779c:     	ldrb	w14, [x13]
1000c77a0:     	lsr	w14, w14, w12
1000c77a4:     	bfxil	w16, w15, #0, #4
1000c77a8:     	and	w15, w14, #0xf
1000c77ac:     	cmp	w15, #8
1000c77b0:     	csel	w15, wzr, w11, lo
1000c77b4:     	bfxil	w15, w14, #0, #4
1000c77b8:     	scvtf	s0, w16
1000c77bc:     	scvtf	s1, w15
1000c77c0:     	ldp	s2, s3, [x3]
1000c77c4:     	fmsub	s1, s1, s0, s2
1000c77c8:     	str	s1, [x3]
1000c77cc:     	ldrb	w14, [x13, #4]
1000c77d0:     	lsr	w14, w14, w12
1000c77d4:     	and	w15, w14, #0xf
1000c77d8:     	cmp	w15, #8
1000c77dc:     	csel	w15, wzr, w11, lo
1000c77e0:     	bfxil	w15, w14, #0, #4
1000c77e4:     	scvtf	s1, w15
1000c77e8:     	fmsub	s1, s1, s0, s3
1000c77ec:     	str	s1, [x3, #4]
1000c77f0:     	ldrb	w14, [x13, #8]
1000c77f4:     	lsr	w14, w14, w12
1000c77f8:     	and	w15, w14, #0xf
1000c77fc:     	cmp	w15, #8
1000c7800:     	csel	w15, wzr, w11, lo
1000c7804:     	bfxil	w15, w14, #0, #4
1000c7808:     	scvtf	s1, w15
1000c780c:     	ldp	s2, s3, [x3, #8]
1000c7810:     	fmsub	s1, s1, s0, s2
1000c7814:     	str	s1, [x3, #8]
1000c7818:     	ldrb	w14, [x13, #12]
1000c781c:     	lsr	w14, w14, w12
1000c7820:     	and	w15, w14, #0xf
1000c7824:     	cmp	w15, #8
1000c7828:     	csel	w15, wzr, w11, lo
1000c782c:     	bfxil	w15, w14, #0, #4
1000c7830:     	scvtf	s1, w15
1000c7834:     	fmsub	s1, s1, s0, s3
1000c7838:     	str	s1, [x3, #12]
1000c783c:     	ldrb	w14, [x13, #16]
1000c7840:     	lsr	w14, w14, w12
1000c7844:     	and	w15, w14, #0xf
1000c7848:     	cmp	w15, #8
1000c784c:     	csel	w15, wzr, w11, lo
1000c7850:     	bfxil	w15, w14, #0, #4
1000c7854:     	scvtf	s1, w15
1000c7858:     	ldp	s2, s3, [x3, #16]
1000c785c:     	fmsub	s1, s1, s0, s2
1000c7860:     	str	s1, [x3, #16]
1000c7864:     	ldrb	w14, [x13, #20]
1000c7868:     	lsr	w14, w14, w12
1000c786c:     	and	w15, w14, #0xf
1000c7870:     	cmp	w15, #8
1000c7874:     	csel	w15, wzr, w11, lo
1000c7878:     	bfxil	w15, w14, #0, #4
1000c787c:     	scvtf	s1, w15
1000c7880:     	fmsub	s1, s1, s0, s3
1000c7884:     	str	s1, [x3, #20]
1000c7888:     	ldrb	w14, [x13, #24]
1000c788c:     	lsr	w14, w14, w12
1000c7890:     	and	w15, w14, #0xf
1000c7894:     	cmp	w15, #8
1000c7898:     	csel	w15, wzr, w11, lo
1000c789c:     	bfxil	w15, w14, #0, #4
1000c78a0:     	scvtf	s1, w15
1000c78a4:     	ldp	s2, s3, [x3, #24]
1000c78a8:     	fmsub	s1, s1, s0, s2
1000c78ac:     	str	s1, [x3, #24]
1000c78b0:     	ldrb	w14, [x13, #28]
1000c78b4:     	lsr	w14, w14, w12
1000c78b8:     	and	w15, w14, #0xf
1000c78bc:     	cmp	w15, #8
1000c78c0:     	csel	w15, wzr, w11, lo
1000c78c4:     	bfxil	w15, w14, #0, #4
1000c78c8:     	scvtf	s1, w15
1000c78cc:     	fmsub	s1, s1, s0, s3
1000c78d0:     	str	s1, [x3, #28]
1000c78d4:     	ldrb	w14, [x13, #32]
1000c78d8:     	lsr	w14, w14, w12
1000c78dc:     	and	w15, w14, #0xf
1000c78e0:     	cmp	w15, #8
1000c78e4:     	csel	w15, wzr, w11, lo
1000c78e8:     	bfxil	w15, w14, #0, #4
1000c78ec:     	scvtf	s1, w15
1000c78f0:     	ldp	s2, s3, [x3, #32]
1000c78f4:     	fmsub	s1, s1, s0, s2
1000c78f8:     	str	s1, [x3, #32]
1000c78fc:     	ldrb	w14, [x13, #36]
1000c7900:     	lsr	w14, w14, w12
1000c7904:     	and	w15, w14, #0xf
1000c7908:     	cmp	w15, #8
1000c790c:     	csel	w15, wzr, w11, lo
1000c7910:     	bfxil	w15, w14, #0, #4
1000c7914:     	scvtf	s1, w15
1000c7918:     	fmsub	s1, s1, s0, s3
1000c791c:     	str	s1, [x3, #36]
1000c7920:     	ldrb	w14, [x13, #40]
1000c7924:     	lsr	w14, w14, w12
1000c7928:     	and	w15, w14, #0xf
1000c792c:     	cmp	w15, #8
1000c7930:     	csel	w15, wzr, w11, lo
1000c7934:     	bfxil	w15, w14, #0, #4
1000c7938:     	scvtf	s1, w15
1000c793c:     	ldp	s2, s3, [x3, #40]
1000c7940:     	fmsub	s1, s1, s0, s2
1000c7944:     	str	s1, [x3, #40]
1000c7948:     	ldrb	w14, [x13, #44]
1000c794c:     	lsr	w14, w14, w12
1000c7950:     	and	w15, w14, #0xf
1000c7954:     	cmp	w15, #8
1000c7958:     	csel	w15, wzr, w11, lo
1000c795c:     	bfxil	w15, w14, #0, #4
1000c7960:     	scvtf	s1, w15
1000c7964:     	fmsub	s1, s1, s0, s3
1000c7968:     	str	s1, [x3, #44]
1000c796c:     	ldrb	w14, [x13, #48]
1000c7970:     	lsr	w14, w14, w12
1000c7974:     	and	w15, w14, #0xf
1000c7978:     	cmp	w15, #8
1000c797c:     	csel	w15, wzr, w11, lo
1000c7980:     	bfxil	w15, w14, #0, #4
1000c7984:     	scvtf	s1, w15
1000c7988:     	ldp	s2, s3, [x3, #48]
1000c798c:     	fmsub	s1, s1, s0, s2
1000c7990:     	str	s1, [x3, #48]
1000c7994:     	ldrb	w14, [x13, #52]
1000c7998:     	lsr	w14, w14, w12
1000c799c:     	and	w15, w14, #0xf
1000c79a0:     	cmp	w15, #8
1000c79a4:     	csel	w15, wzr, w11, lo
1000c79a8:     	bfxil	w15, w14, #0, #4
1000c79ac:     	scvtf	s1, w15
1000c79b0:     	fmsub	s1, s1, s0, s3
1000c79b4:     	str	s1, [x3, #52]
1000c79b8:     	ldrb	w14, [x13, #56]
1000c79bc:     	lsr	w14, w14, w12
1000c79c0:     	and	w15, w14, #0xf
1000c79c4:     	cmp	w15, #8
1000c79c8:     	csel	w15, wzr, w11, lo
1000c79cc:     	bfxil	w15, w14, #0, #4
1000c79d0:     	scvtf	s1, w15
1000c79d4:     	ldp	s2, s3, [x3, #56]
1000c79d8:     	fmsub	s1, s1, s0, s2
1000c79dc:     	str	s1, [x3, #56]
1000c79e0:     	ldrb	w13, [x13, #60]
1000c79e4:     	lsr	w12, w13, w12
1000c79e8:     	and	w13, w12, #0xf
1000c79ec:     	cmp	w13, #8
1000c79f0:     	csel	w13, wzr, w11, lo
1000c79f4:     	bfxil	w13, w12, #0, #4
1000c79f8:     	scvtf	s1, w13
1000c79fc:     	fmsub	s0, s1, s0, s3
1000c7a00:     	str	s0, [x3, #60]
1000c7a04:     	add	x8, x8, #1
1000c7a08:     	add	w10, w10, #4
1000c7a0c:     	cmp	x2, x8
1000c7a10:     	b.ne	0x1000c776c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c7a14:     	ldp	x20, x19, [sp, #16]
1000c7a18:     	ldp	x22, x21, [sp], #32
1000c7a1c:     	ret

