00000001000cc944 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cc944:     	stp	x28, x27, [sp, #-96]!
1000cc948:     	stp	x26, x25, [sp, #16]
1000cc94c:     	stp	x24, x23, [sp, #32]
1000cc950:     	stp	x22, x21, [sp, #48]
1000cc954:     	stp	x20, x19, [sp, #64]
1000cc958:     	stp	x29, x30, [sp, #80]
1000cc95c:     	add	x29, sp, #80
1000cc960:     	sub	sp, sp, #976
1000cc964:     	str	x3, [sp, #8]
1000cc968:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a4>
1000cc96c:     	ldr	x8, [x8, #392]
1000cc970:     	ldr	x8, [x8]
1000cc974:     	stur	x8, [x29, #-96]
1000cc978:     	movi.2d	v0, #0000000000000000
1000cc97c:     	stp	q0, q0, [sp, #928]
1000cc980:     	lsl	x8, x2, #2
1000cc984:     	stp	q0, q0, [sp, #896]
1000cc988:     	stp	q0, q0, [sp, #864]
1000cc98c:     	stp	q0, q0, [sp, #832]
1000cc990:     	stp	q0, q0, [sp, #800]
1000cc994:     	stp	q0, q0, [sp, #768]
1000cc998:     	stp	q0, q0, [sp, #736]
1000cc99c:     	stp	q0, q0, [sp, #704]
1000cc9a0:     	stp	q0, q0, [sp, #672]
1000cc9a4:     	stp	q0, q0, [sp, #640]
1000cc9a8:     	stp	q0, q0, [sp, #608]
1000cc9ac:     	stp	q0, q0, [sp, #576]
1000cc9b0:     	stp	q0, q0, [sp, #544]
1000cc9b4:     	stp	q0, q0, [sp, #512]
1000cc9b8:     	stp	q0, q0, [sp, #480]
1000cc9bc:     	stp	q0, q0, [sp, #448]
1000cc9c0:     	ands	x8, x8, #0xfffffffffffffff8
1000cc9c4:     	b.eq	0x1000ccf14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cc9c8:     	add	x8, x1, x8
1000cc9cc:     	str	x8, [sp, #16]
1000cc9d0:     	add	x8, sp, #448
1000cc9d4:     	add	x19, x8, #256
1000cc9d8:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000cc9dc:     	add	x11, x11, #1212
1000cc9e0:     	mov	x12, #0
1000cc9e4:     	ldp	w8, w9, [x1]
1000cc9e8:     	ubfx	x10, x8, #8, #4
1000cc9ec:     	str	x10, [sp, #440]
1000cc9f0:     	ubfx	x10, x8, #16, #4
1000cc9f4:     	str	x10, [sp, #432]
1000cc9f8:     	ubfx	x10, x8, #24, #4
1000cc9fc:     	str	x10, [sp, #424]
1000cca00:     	ldp	w10, w13, [x1, #8]
1000cca04:     	and	x15, x8, #0xf
1000cca08:     	ubfx	x14, x8, #4, #4
1000cca0c:     	stp	x14, x15, [sp, #408]
1000cca10:     	ubfx	x15, x8, #12, #4
1000cca14:     	ubfx	x14, x8, #20, #4
1000cca18:     	stp	x14, x15, [sp, #392]
1000cca1c:     	lsr	x8, x8, #28
1000cca20:     	str	x8, [sp, #384]
1000cca24:     	and	x8, x9, #0xf
1000cca28:     	str	x8, [sp, #376]
1000cca2c:     	ubfx	x8, x9, #8, #4
1000cca30:     	str	x8, [sp, #368]
1000cca34:     	ubfx	x8, x9, #16, #4
1000cca38:     	str	x8, [sp, #360]
1000cca3c:     	ubfx	x8, x9, #24, #4
1000cca40:     	str	x8, [sp, #352]
1000cca44:     	ubfx	x8, x9, #4, #4
1000cca48:     	str	x8, [sp, #344]
1000cca4c:     	ubfx	x8, x9, #12, #4
1000cca50:     	str	x8, [sp, #336]
1000cca54:     	ubfx	x8, x9, #20, #4
1000cca58:     	str	x8, [sp, #328]
1000cca5c:     	lsr	x8, x9, #28
1000cca60:     	str	x8, [sp, #320]
1000cca64:     	and	x9, x10, #0xf
1000cca68:     	ubfx	x8, x10, #8, #4
1000cca6c:     	stp	x8, x9, [sp, #304]
1000cca70:     	ubfx	x9, x10, #16, #4
1000cca74:     	ubfx	x8, x10, #24, #4
1000cca78:     	stp	x8, x9, [sp, #288]
1000cca7c:     	ubfx	x9, x10, #4, #4
1000cca80:     	ubfx	x8, x10, #12, #4
1000cca84:     	stp	x8, x9, [sp, #272]
1000cca88:     	ubfx	x9, x10, #20, #4
1000cca8c:     	lsr	x8, x10, #28
1000cca90:     	stp	x8, x9, [sp, #256]
1000cca94:     	and	x9, x13, #0xf
1000cca98:     	ubfx	x8, x13, #8, #4
1000cca9c:     	stp	x8, x9, [sp, #240]
1000ccaa0:     	ubfx	x9, x13, #16, #4
1000ccaa4:     	ubfx	x8, x13, #24, #4
1000ccaa8:     	stp	x8, x9, [sp, #224]
1000ccaac:     	ubfx	x9, x13, #4, #4
1000ccab0:     	ubfx	x8, x13, #12, #4
1000ccab4:     	stp	x8, x9, [sp, #208]
1000ccab8:     	ubfx	x9, x13, #20, #4
1000ccabc:     	lsr	x8, x13, #28
1000ccac0:     	stp	x8, x9, [sp, #192]
1000ccac4:     	ldp	w8, w9, [x1, #16]
1000ccac8:     	and	x10, x8, #0xf
1000ccacc:     	str	x10, [sp, #184]
1000ccad0:     	ubfx	x10, x8, #8, #4
1000ccad4:     	str	x10, [sp, #176]
1000ccad8:     	ubfx	x10, x8, #16, #4
1000ccadc:     	str	x10, [sp, #168]
1000ccae0:     	ubfx	x10, x8, #24, #4
1000ccae4:     	str	x10, [sp, #160]
1000ccae8:     	ubfx	x10, x8, #4, #4
1000ccaec:     	str	x10, [sp, #152]
1000ccaf0:     	ubfx	x10, x8, #12, #4
1000ccaf4:     	str	x10, [sp, #144]
1000ccaf8:     	ubfx	x10, x8, #20, #4
1000ccafc:     	lsr	x8, x8, #28
1000ccb00:     	stp	x8, x10, [sp, #128]
1000ccb04:     	and	x10, x9, #0xf
1000ccb08:     	ubfx	x8, x9, #8, #4
1000ccb0c:     	stp	x8, x10, [sp, #112]
1000ccb10:     	ubfx	x10, x9, #16, #4
1000ccb14:     	ubfx	x8, x9, #24, #4
1000ccb18:     	stp	x8, x10, [sp, #96]
1000ccb1c:     	ubfx	x10, x9, #4, #4
1000ccb20:     	ubfx	x8, x9, #12, #4
1000ccb24:     	stp	x8, x10, [sp, #80]
1000ccb28:     	ubfx	x10, x9, #20, #4
1000ccb2c:     	lsr	x8, x9, #28
1000ccb30:     	stp	x8, x10, [sp, #64]
1000ccb34:     	ldp	w14, w7, [x1, #24]
1000ccb38:     	and	x9, x14, #0xf
1000ccb3c:     	ubfx	x8, x14, #8, #4
1000ccb40:     	stp	x8, x9, [sp, #48]
1000ccb44:     	ubfx	x8, x14, #16, #4
1000ccb48:     	str	x8, [sp, #40]
1000ccb4c:     	ubfx	x8, x14, #24, #4
1000ccb50:     	stp	x1, x8, [sp, #24]
1000ccb54:     	ubfx	x10, x14, #4, #4
1000ccb58:     	ubfx	x13, x14, #12, #4
1000ccb5c:     	ubfx	x9, x14, #20, #4
1000ccb60:     	lsr	x14, x14, #28
1000ccb64:     	and	x15, x7, #0xf
1000ccb68:     	ubfx	x16, x7, #8, #4
1000ccb6c:     	ubfx	x17, x7, #16, #4
1000ccb70:     	ubfx	x2, x7, #24, #4
1000ccb74:     	ubfx	x4, x7, #4, #4
1000ccb78:     	ubfx	x5, x7, #12, #4
1000ccb7c:     	ubfx	x6, x7, #20, #4
1000ccb80:     	lsr	x7, x7, #28
1000ccb84:     	ldr	w26, [x0, x12]
1000ccb88:     	mov	x1, x19
1000ccb8c:     	lsl	w19, w26, #4
1000ccb90:     	and	x19, x19, #0xf0
1000ccb94:     	add	x19, x11, x19
1000ccb98:     	ldr	x8, [sp, #416]
1000ccb9c:     	ldrb	w25, [x19, x8]
1000ccba0:     	lsr	x20, x26, #4
1000ccba4:     	and	x20, x20, #0xf0
1000ccba8:     	add	x20, x11, x20
1000ccbac:     	ldr	x8, [sp, #440]
1000ccbb0:     	ldrb	w27, [x20, x8]
1000ccbb4:     	lsr	x21, x26, #12
1000ccbb8:     	and	x21, x21, #0xf0
1000ccbbc:     	add	x21, x11, x21
1000ccbc0:     	ldr	x8, [sp, #432]
1000ccbc4:     	ldrb	w28, [x21, x8]
1000ccbc8:     	lsr	x22, x26, #20
1000ccbcc:     	and	x22, x22, #0xf0
1000ccbd0:     	add	x23, x11, x22
1000ccbd4:     	ldr	x8, [sp, #424]
1000ccbd8:     	ldrb	w30, [x23, x8]
1000ccbdc:     	and	x22, x26, #0xf0
1000ccbe0:     	add	x22, x11, x22
1000ccbe4:     	ldr	x8, [sp, #408]
1000ccbe8:     	ldrb	w3, [x22, x8]
1000ccbec:     	lsr	x24, x26, #8
1000ccbf0:     	and	x24, x24, #0xf0
1000ccbf4:     	add	x24, x11, x24
1000ccbf8:     	ldr	x8, [sp, #400]
1000ccbfc:     	ldrb	w8, [x24, x8]
1000ccc00:     	add	w27, w25, w27
1000ccc04:     	lsr	x25, x26, #16
1000ccc08:     	and	x25, x25, #0xf0
1000ccc0c:     	add	x25, x11, x25
1000ccc10:     	add	w27, w27, w28
1000ccc14:     	ldr	x28, [sp, #392]
1000ccc18:     	ldrb	w28, [x25, x28]
1000ccc1c:     	lsr	x26, x26, #24
1000ccc20:     	and	x26, x26, #0xf0
1000ccc24:     	add	x26, x11, x26
1000ccc28:     	add	w27, w27, w30
1000ccc2c:     	ldr	x30, [sp, #384]
1000ccc30:     	ldrb	w30, [x26, x30]
1000ccc34:     	add	w3, w27, w3
1000ccc38:     	add	w8, w3, w8
1000ccc3c:     	add	w8, w8, w28
1000ccc40:     	add	w8, w8, w30
1000ccc44:     	scvtf	s0, w8
1000ccc48:     	ldp	x3, x8, [sp, #368]
1000ccc4c:     	ldrb	w8, [x19, x8]
1000ccc50:     	ldrb	w3, [x20, x3]
1000ccc54:     	ldp	x28, x27, [sp, #352]
1000ccc58:     	ldrb	w27, [x21, x27]
1000ccc5c:     	ldrb	w28, [x23, x28]
1000ccc60:     	ldr	x30, [sp, #344]
1000ccc64:     	ldrb	w30, [x22, x30]
1000ccc68:     	add	w8, w8, w3
1000ccc6c:     	ldr	x3, [sp, #336]
1000ccc70:     	ldrb	w3, [x24, x3]
1000ccc74:     	add	w8, w8, w27
1000ccc78:     	ldr	x27, [sp, #328]
1000ccc7c:     	ldrb	w27, [x25, x27]
1000ccc80:     	add	w8, w8, w28
1000ccc84:     	ldr	x28, [sp, #320]
1000ccc88:     	ldrb	w28, [x26, x28]
1000ccc8c:     	add	w8, w8, w30
1000ccc90:     	add	w8, w8, w3
1000ccc94:     	add	w8, w8, w27
1000ccc98:     	add	w8, w8, w28
1000ccc9c:     	scvtf	s1, w8
1000ccca0:     	ldp	x3, x8, [sp, #304]
1000ccca4:     	ldrb	w8, [x19, x8]
1000ccca8:     	ldrb	w3, [x20, x3]
1000cccac:     	ldp	x28, x27, [sp, #288]
1000cccb0:     	ldrb	w27, [x21, x27]
1000cccb4:     	ldrb	w28, [x23, x28]
1000cccb8:     	add	w8, w8, w3
1000cccbc:     	ldr	x3, [sp, #280]
1000cccc0:     	ldrb	w3, [x22, x3]
1000cccc4:     	add	w8, w8, w27
1000cccc8:     	ldr	x27, [sp, #272]
1000ccccc:     	ldrb	w27, [x24, x27]
1000cccd0:     	add	w8, w8, w28
1000cccd4:     	ldr	x28, [sp, #264]
1000cccd8:     	ldrb	w28, [x25, x28]
1000cccdc:     	add	w8, w8, w3
1000ccce0:     	ldr	x3, [sp, #256]
1000ccce4:     	ldrb	w3, [x26, x3]
1000ccce8:     	add	w8, w8, w27
1000cccec:     	add	w8, w8, w28
1000cccf0:     	add	w8, w8, w3
1000cccf4:     	scvtf	s2, w8
1000cccf8:     	ldp	x3, x8, [sp, #240]
1000cccfc:     	ldrb	w8, [x19, x8]
1000ccd00:     	ldrb	w3, [x20, x3]
1000ccd04:     	ldp	x28, x27, [sp, #224]
1000ccd08:     	ldrb	w27, [x21, x27]
1000ccd0c:     	ldrb	w28, [x23, x28]
1000ccd10:     	add	w8, w8, w3
1000ccd14:     	ldr	x3, [sp, #216]
1000ccd18:     	ldrb	w3, [x22, x3]
1000ccd1c:     	add	w8, w8, w27
1000ccd20:     	ldr	x27, [sp, #208]
1000ccd24:     	ldrb	w27, [x24, x27]
1000ccd28:     	add	w8, w8, w28
1000ccd2c:     	ldr	x28, [sp, #200]
1000ccd30:     	ldrb	w28, [x25, x28]
1000ccd34:     	add	w8, w8, w3
1000ccd38:     	ldr	x3, [sp, #192]
1000ccd3c:     	ldrb	w3, [x26, x3]
1000ccd40:     	add	w8, w8, w27
1000ccd44:     	add	w8, w8, w28
1000ccd48:     	add	w8, w8, w3
1000ccd4c:     	scvtf	s3, w8
1000ccd50:     	ldp	x3, x8, [sp, #176]
1000ccd54:     	ldrb	w8, [x19, x8]
1000ccd58:     	ldrb	w3, [x20, x3]
1000ccd5c:     	ldp	x28, x27, [sp, #160]
1000ccd60:     	ldrb	w27, [x21, x27]
1000ccd64:     	ldrb	w28, [x23, x28]
1000ccd68:     	add	w8, w8, w3
1000ccd6c:     	add	w8, w8, w27
1000ccd70:     	ldr	x3, [sp, #152]
1000ccd74:     	ldrb	w3, [x22, x3]
1000ccd78:     	add	w8, w8, w28
1000ccd7c:     	add	w8, w8, w3
1000ccd80:     	ldp	x27, x3, [sp, #136]
1000ccd84:     	ldrb	w3, [x24, x3]
1000ccd88:     	ldrb	w27, [x25, x27]
1000ccd8c:     	add	w8, w8, w3
1000ccd90:     	add	w8, w8, w27
1000ccd94:     	ldr	x3, [sp, #128]
1000ccd98:     	ldrb	w3, [x26, x3]
1000ccd9c:     	add	w8, w8, w3
1000ccda0:     	scvtf	s4, w8
1000ccda4:     	ldp	x3, x8, [sp, #112]
1000ccda8:     	ldrb	w8, [x19, x8]
1000ccdac:     	ldrb	w3, [x20, x3]
1000ccdb0:     	ldp	x28, x27, [sp, #96]
1000ccdb4:     	ldrb	w27, [x21, x27]
1000ccdb8:     	ldrb	w28, [x23, x28]
1000ccdbc:     	add	w8, w8, w3
1000ccdc0:     	ldr	x3, [sp, #88]
1000ccdc4:     	ldrb	w3, [x22, x3]
1000ccdc8:     	add	w8, w8, w27
1000ccdcc:     	ldr	x27, [sp, #80]
1000ccdd0:     	ldrb	w27, [x24, x27]
1000ccdd4:     	add	w8, w8, w28
1000ccdd8:     	ldr	x28, [sp, #72]
1000ccddc:     	ldrb	w28, [x25, x28]
1000ccde0:     	add	w8, w8, w3
1000ccde4:     	add	w8, w8, w27
1000ccde8:     	add	w8, w8, w28
1000ccdec:     	ldr	x3, [sp, #64]
1000ccdf0:     	ldrb	w3, [x26, x3]
1000ccdf4:     	add	w8, w8, w3
1000ccdf8:     	scvtf	s5, w8
1000ccdfc:     	ldp	x3, x8, [sp, #48]
1000cce00:     	ldrb	w8, [x19, x8]
1000cce04:     	ldrb	w3, [x20, x3]
1000cce08:     	ldr	x27, [sp, #40]
1000cce0c:     	ldrb	w27, [x21, x27]
1000cce10:     	add	w8, w8, w3
1000cce14:     	ldr	x3, [sp, #32]
1000cce18:     	ldrb	w3, [x23, x3]
1000cce1c:     	add	w8, w8, w27
1000cce20:     	ldrb	w27, [x22, x10]
1000cce24:     	add	w8, w8, w3
1000cce28:     	ldrb	w3, [x24, x13]
1000cce2c:     	add	w8, w8, w27
1000cce30:     	ldrb	w27, [x25, x9]
1000cce34:     	add	w8, w8, w3
1000cce38:     	ldrb	w3, [x26, x14]
1000cce3c:     	add	w8, w8, w27
1000cce40:     	add	w8, w8, w3
1000cce44:     	scvtf	s6, w8
1000cce48:     	ldrb	w8, [x19, x15]
1000cce4c:     	ldrb	w3, [x20, x16]
1000cce50:     	ldrb	w19, [x21, x17]
1000cce54:     	add	w8, w8, w3
1000cce58:     	add	w8, w8, w19
1000cce5c:     	ldrb	w3, [x23, x2]
1000cce60:     	ldrb	w19, [x22, x4]
1000cce64:     	add	w8, w8, w3
1000cce68:     	add	w8, w8, w19
1000cce6c:     	ldrb	w3, [x24, x5]
1000cce70:     	ldrb	w19, [x25, x6]
1000cce74:     	add	w8, w8, w3
1000cce78:     	add	w8, w8, w19
1000cce7c:     	mov	x19, x1
1000cce80:     	ldrb	w3, [x26, x7]
1000cce84:     	add	w8, w8, w3
1000cce88:     	add	x3, sp, #448
1000cce8c:     	scvtf	s7, w8
1000cce90:     	add	x8, x1, x12
1000cce94:     	ldur	s16, [x8, #-192]
1000cce98:     	fadd	s1, s16, s1
1000cce9c:     	stur	s1, [x8, #-192]
1000ccea0:     	ldur	s1, [x8, #-128]
1000ccea4:     	fadd	s1, s1, s2
1000ccea8:     	stur	s1, [x8, #-128]
1000cceac:     	ldur	s1, [x8, #-64]
1000cceb0:     	fadd	s1, s1, s3
1000cceb4:     	stur	s1, [x8, #-64]
1000cceb8:     	ldr	s1, [x8]
1000ccebc:     	fadd	s1, s1, s4
1000ccec0:     	str	s1, [x8]
1000ccec4:     	ldr	s1, [x8, #64]
1000ccec8:     	fadd	s1, s1, s5
1000ccecc:     	str	s1, [x8, #64]
1000cced0:     	ldr	s1, [x8, #128]
1000cced4:     	fadd	s1, s1, s6
1000cced8:     	str	s1, [x8, #128]
1000ccedc:     	ldr	s1, [x8, #192]
1000ccee0:     	fadd	s1, s1, s7
1000ccee4:     	ldr	s2, [x3, x12]
1000ccee8:     	str	s1, [x8, #192]
1000cceec:     	fadd	s0, s2, s0
1000ccef0:     	str	s0, [x3, x12]
1000ccef4:     	add	x12, x12, #4
1000ccef8:     	cmp	x12, #64
1000ccefc:     	b.ne	0x1000ccb84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000ccf00:     	add	x0, x0, #64
1000ccf04:     	ldp	x8, x1, [sp, #16]
1000ccf08:     	add	x1, x1, #32
1000ccf0c:     	cmp	x1, x8
1000ccf10:     	b.ne	0x1000cc9e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000ccf14:     	add	x1, sp, #448
1000ccf18:     	ldr	x0, [sp, #8]
1000ccf1c:     	mov	w2, #512
1000ccf20:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ccf24:     	ldur	x8, [x29, #-96]
1000ccf28:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x98>
1000ccf2c:     	ldr	x9, [x9, #392]
1000ccf30:     	ldr	x9, [x9]
1000ccf34:     	cmp	x9, x8
1000ccf38:     	b.ne	0x1000ccf5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000ccf3c:     	add	sp, sp, #976
1000ccf40:     	ldp	x29, x30, [sp, #80]
1000ccf44:     	ldp	x20, x19, [sp, #64]
1000ccf48:     	ldp	x22, x21, [sp, #48]
1000ccf4c:     	ldp	x24, x23, [sp, #32]
1000ccf50:     	ldp	x26, x25, [sp, #16]
1000ccf54:     	ldp	x28, x27, [sp], #96
1000ccf58:     	ret
1000ccf5c:     	bl	0x100163694 <_strcmp+0x100163694>

