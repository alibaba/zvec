00000001000c5c60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c5c60:     	stp	x28, x27, [sp, #-96]!
1000c5c64:     	stp	x26, x25, [sp, #16]
1000c5c68:     	stp	x24, x23, [sp, #32]
1000c5c6c:     	stp	x22, x21, [sp, #48]
1000c5c70:     	stp	x20, x19, [sp, #64]
1000c5c74:     	stp	x29, x30, [sp, #80]
1000c5c78:     	add	x29, sp, #80
1000c5c7c:     	sub	sp, sp, #720
1000c5c80:     	str	x3, [sp, #8]
1000c5c84:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c5c88:     	ldr	x8, [x8, #392]
1000c5c8c:     	ldr	x8, [x8]
1000c5c90:     	stur	x8, [x29, #-96]
1000c5c94:     	movi.2d	v0, #0000000000000000
1000c5c98:     	stp	q0, q0, [sp, #672]
1000c5c9c:     	lsl	x8, x2, #2
1000c5ca0:     	stp	q0, q0, [sp, #640]
1000c5ca4:     	stp	q0, q0, [sp, #608]
1000c5ca8:     	stp	q0, q0, [sp, #576]
1000c5cac:     	stp	q0, q0, [sp, #544]
1000c5cb0:     	stp	q0, q0, [sp, #512]
1000c5cb4:     	stp	q0, q0, [sp, #480]
1000c5cb8:     	stp	q0, q0, [sp, #448]
1000c5cbc:     	ands	x8, x8, #0xfffffffffffffff8
1000c5cc0:     	b.eq	0x1000c620c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c5cc4:     	add	x8, x1, x8
1000c5cc8:     	str	x8, [sp, #16]
1000c5ccc:     	add	x8, sp, #448
1000c5cd0:     	add	x19, x8, #128
1000c5cd4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000c5cd8:     	add	x11, x11, #956
1000c5cdc:     	mov	x12, #0
1000c5ce0:     	ldp	w8, w9, [x1]
1000c5ce4:     	ubfx	x10, x8, #8, #4
1000c5ce8:     	str	x10, [sp, #440]
1000c5cec:     	ubfx	x10, x8, #16, #4
1000c5cf0:     	str	x10, [sp, #432]
1000c5cf4:     	ubfx	x10, x8, #24, #4
1000c5cf8:     	str	x10, [sp, #424]
1000c5cfc:     	ldp	w10, w13, [x1, #8]
1000c5d00:     	and	x15, x8, #0xf
1000c5d04:     	ubfx	x14, x8, #4, #4
1000c5d08:     	stp	x14, x15, [sp, #408]
1000c5d0c:     	ubfx	x15, x8, #12, #4
1000c5d10:     	ubfx	x14, x8, #20, #4
1000c5d14:     	stp	x14, x15, [sp, #392]
1000c5d18:     	lsr	x8, x8, #28
1000c5d1c:     	str	x8, [sp, #384]
1000c5d20:     	and	x8, x9, #0xf
1000c5d24:     	str	x8, [sp, #376]
1000c5d28:     	ubfx	x8, x9, #8, #4
1000c5d2c:     	str	x8, [sp, #368]
1000c5d30:     	ubfx	x8, x9, #16, #4
1000c5d34:     	str	x8, [sp, #360]
1000c5d38:     	ubfx	x8, x9, #24, #4
1000c5d3c:     	str	x8, [sp, #352]
1000c5d40:     	ubfx	x8, x9, #4, #4
1000c5d44:     	str	x8, [sp, #344]
1000c5d48:     	ubfx	x8, x9, #12, #4
1000c5d4c:     	str	x8, [sp, #336]
1000c5d50:     	ubfx	x8, x9, #20, #4
1000c5d54:     	str	x8, [sp, #328]
1000c5d58:     	lsr	x8, x9, #28
1000c5d5c:     	str	x8, [sp, #320]
1000c5d60:     	and	x9, x10, #0xf
1000c5d64:     	ubfx	x8, x10, #8, #4
1000c5d68:     	stp	x8, x9, [sp, #304]
1000c5d6c:     	ubfx	x9, x10, #16, #4
1000c5d70:     	ubfx	x8, x10, #24, #4
1000c5d74:     	stp	x8, x9, [sp, #288]
1000c5d78:     	ubfx	x9, x10, #4, #4
1000c5d7c:     	ubfx	x8, x10, #12, #4
1000c5d80:     	stp	x8, x9, [sp, #272]
1000c5d84:     	ubfx	x9, x10, #20, #4
1000c5d88:     	lsr	x8, x10, #28
1000c5d8c:     	stp	x8, x9, [sp, #256]
1000c5d90:     	and	x9, x13, #0xf
1000c5d94:     	ubfx	x8, x13, #8, #4
1000c5d98:     	stp	x8, x9, [sp, #240]
1000c5d9c:     	ubfx	x9, x13, #16, #4
1000c5da0:     	ubfx	x8, x13, #24, #4
1000c5da4:     	stp	x8, x9, [sp, #224]
1000c5da8:     	ubfx	x9, x13, #4, #4
1000c5dac:     	ubfx	x8, x13, #12, #4
1000c5db0:     	stp	x8, x9, [sp, #208]
1000c5db4:     	ubfx	x9, x13, #20, #4
1000c5db8:     	lsr	x8, x13, #28
1000c5dbc:     	stp	x8, x9, [sp, #192]
1000c5dc0:     	ldp	w8, w9, [x1, #16]
1000c5dc4:     	and	x10, x8, #0xf
1000c5dc8:     	str	x10, [sp, #184]
1000c5dcc:     	ubfx	x10, x8, #8, #4
1000c5dd0:     	str	x10, [sp, #176]
1000c5dd4:     	ubfx	x10, x8, #16, #4
1000c5dd8:     	str	x10, [sp, #168]
1000c5ddc:     	ubfx	x10, x8, #24, #4
1000c5de0:     	str	x10, [sp, #160]
1000c5de4:     	ubfx	x10, x8, #4, #4
1000c5de8:     	str	x10, [sp, #152]
1000c5dec:     	ubfx	x10, x8, #12, #4
1000c5df0:     	str	x10, [sp, #144]
1000c5df4:     	ubfx	x10, x8, #20, #4
1000c5df8:     	lsr	x8, x8, #28
1000c5dfc:     	stp	x8, x10, [sp, #128]
1000c5e00:     	and	x10, x9, #0xf
1000c5e04:     	ubfx	x8, x9, #8, #4
1000c5e08:     	stp	x8, x10, [sp, #112]
1000c5e0c:     	ubfx	x10, x9, #16, #4
1000c5e10:     	ubfx	x8, x9, #24, #4
1000c5e14:     	stp	x8, x10, [sp, #96]
1000c5e18:     	ubfx	x10, x9, #4, #4
1000c5e1c:     	ubfx	x8, x9, #12, #4
1000c5e20:     	stp	x8, x10, [sp, #80]
1000c5e24:     	ubfx	x10, x9, #20, #4
1000c5e28:     	lsr	x8, x9, #28
1000c5e2c:     	stp	x8, x10, [sp, #64]
1000c5e30:     	ldp	w14, w7, [x1, #24]
1000c5e34:     	and	x9, x14, #0xf
1000c5e38:     	ubfx	x8, x14, #8, #4
1000c5e3c:     	stp	x8, x9, [sp, #48]
1000c5e40:     	ubfx	x8, x14, #16, #4
1000c5e44:     	str	x8, [sp, #40]
1000c5e48:     	ubfx	x8, x14, #24, #4
1000c5e4c:     	stp	x1, x8, [sp, #24]
1000c5e50:     	ubfx	x10, x14, #4, #4
1000c5e54:     	ubfx	x13, x14, #12, #4
1000c5e58:     	ubfx	x9, x14, #20, #4
1000c5e5c:     	lsr	x14, x14, #28
1000c5e60:     	and	x15, x7, #0xf
1000c5e64:     	ubfx	x16, x7, #8, #4
1000c5e68:     	ubfx	x17, x7, #16, #4
1000c5e6c:     	ubfx	x2, x7, #24, #4
1000c5e70:     	ubfx	x4, x7, #4, #4
1000c5e74:     	ubfx	x5, x7, #12, #4
1000c5e78:     	ubfx	x6, x7, #20, #4
1000c5e7c:     	lsr	x7, x7, #28
1000c5e80:     	ldr	w26, [x0, x12]
1000c5e84:     	mov	x1, x19
1000c5e88:     	lsl	w19, w26, #4
1000c5e8c:     	and	x19, x19, #0xf0
1000c5e90:     	add	x19, x11, x19
1000c5e94:     	ldr	x8, [sp, #416]
1000c5e98:     	ldrsb	w25, [x19, x8]
1000c5e9c:     	lsr	x20, x26, #4
1000c5ea0:     	and	x20, x20, #0xf0
1000c5ea4:     	add	x20, x11, x20
1000c5ea8:     	ldr	x8, [sp, #440]
1000c5eac:     	ldrsb	w27, [x20, x8]
1000c5eb0:     	lsr	x21, x26, #12
1000c5eb4:     	and	x21, x21, #0xf0
1000c5eb8:     	add	x21, x11, x21
1000c5ebc:     	ldr	x8, [sp, #432]
1000c5ec0:     	ldrsb	w28, [x21, x8]
1000c5ec4:     	lsr	x22, x26, #20
1000c5ec8:     	and	x22, x22, #0xf0
1000c5ecc:     	add	x23, x11, x22
1000c5ed0:     	ldr	x8, [sp, #424]
1000c5ed4:     	ldrsb	w30, [x23, x8]
1000c5ed8:     	and	x22, x26, #0xf0
1000c5edc:     	add	x22, x11, x22
1000c5ee0:     	ldp	x3, x8, [sp, #400]
1000c5ee4:     	ldrsb	w8, [x22, x8]
1000c5ee8:     	lsr	x24, x26, #8
1000c5eec:     	and	x24, x24, #0xf0
1000c5ef0:     	add	x24, x11, x24
1000c5ef4:     	ldrsb	w3, [x24, x3]
1000c5ef8:     	add	w27, w25, w27
1000c5efc:     	lsr	x25, x26, #16
1000c5f00:     	and	x25, x25, #0xf0
1000c5f04:     	add	x25, x11, x25
1000c5f08:     	add	w27, w27, w28
1000c5f0c:     	ldr	x28, [sp, #392]
1000c5f10:     	ldrsb	w28, [x25, x28]
1000c5f14:     	lsr	x26, x26, #24
1000c5f18:     	and	x26, x26, #0xf0
1000c5f1c:     	add	x26, x11, x26
1000c5f20:     	add	w27, w27, w30
1000c5f24:     	ldr	x30, [sp, #384]
1000c5f28:     	ldrsb	w30, [x26, x30]
1000c5f2c:     	add	w8, w27, w8
1000c5f30:     	add	w8, w8, w3
1000c5f34:     	add	w8, w8, w28
1000c5f38:     	add	w8, w8, w30
1000c5f3c:     	scvtf	s0, w8
1000c5f40:     	ldp	x3, x8, [sp, #368]
1000c5f44:     	ldrsb	w8, [x19, x8]
1000c5f48:     	ldrsb	w3, [x20, x3]
1000c5f4c:     	ldp	x28, x27, [sp, #352]
1000c5f50:     	ldrsb	w27, [x21, x27]
1000c5f54:     	ldrsb	w28, [x23, x28]
1000c5f58:     	ldr	x30, [sp, #344]
1000c5f5c:     	ldrsb	w30, [x22, x30]
1000c5f60:     	add	w8, w8, w3
1000c5f64:     	ldr	x3, [sp, #336]
1000c5f68:     	ldrsb	w3, [x24, x3]
1000c5f6c:     	add	w8, w8, w27
1000c5f70:     	ldr	x27, [sp, #328]
1000c5f74:     	ldrsb	w27, [x25, x27]
1000c5f78:     	add	w8, w8, w28
1000c5f7c:     	ldr	x28, [sp, #320]
1000c5f80:     	ldrsb	w28, [x26, x28]
1000c5f84:     	add	w8, w8, w30
1000c5f88:     	add	w8, w8, w3
1000c5f8c:     	add	w8, w8, w27
1000c5f90:     	add	w8, w8, w28
1000c5f94:     	scvtf	s1, w8
1000c5f98:     	ldp	x3, x8, [sp, #304]
1000c5f9c:     	ldrsb	w8, [x19, x8]
1000c5fa0:     	ldrsb	w3, [x20, x3]
1000c5fa4:     	ldp	x28, x27, [sp, #288]
1000c5fa8:     	ldrsb	w27, [x21, x27]
1000c5fac:     	ldrsb	w28, [x23, x28]
1000c5fb0:     	add	w8, w8, w3
1000c5fb4:     	ldr	x3, [sp, #280]
1000c5fb8:     	ldrsb	w3, [x22, x3]
1000c5fbc:     	add	w8, w8, w27
1000c5fc0:     	ldr	x27, [sp, #272]
1000c5fc4:     	ldrsb	w27, [x24, x27]
1000c5fc8:     	add	w8, w8, w28
1000c5fcc:     	ldr	x28, [sp, #264]
1000c5fd0:     	ldrsb	w28, [x25, x28]
1000c5fd4:     	add	w8, w8, w3
1000c5fd8:     	ldr	x3, [sp, #256]
1000c5fdc:     	ldrsb	w3, [x26, x3]
1000c5fe0:     	add	w8, w8, w27
1000c5fe4:     	add	w8, w8, w28
1000c5fe8:     	add	w8, w8, w3
1000c5fec:     	scvtf	s2, w8
1000c5ff0:     	ldp	x3, x8, [sp, #240]
1000c5ff4:     	ldrsb	w8, [x19, x8]
1000c5ff8:     	ldrsb	w3, [x20, x3]
1000c5ffc:     	ldp	x28, x27, [sp, #224]
1000c6000:     	ldrsb	w27, [x21, x27]
1000c6004:     	ldrsb	w28, [x23, x28]
1000c6008:     	add	w8, w8, w3
1000c600c:     	ldr	x3, [sp, #216]
1000c6010:     	ldrsb	w3, [x22, x3]
1000c6014:     	add	w8, w8, w27
1000c6018:     	ldr	x27, [sp, #208]
1000c601c:     	ldrsb	w27, [x24, x27]
1000c6020:     	add	w8, w8, w28
1000c6024:     	ldr	x28, [sp, #200]
1000c6028:     	ldrsb	w28, [x25, x28]
1000c602c:     	add	w8, w8, w3
1000c6030:     	ldr	x3, [sp, #192]
1000c6034:     	ldrsb	w3, [x26, x3]
1000c6038:     	add	w8, w8, w27
1000c603c:     	add	w8, w8, w28
1000c6040:     	add	w8, w8, w3
1000c6044:     	scvtf	s3, w8
1000c6048:     	ldp	x3, x8, [sp, #176]
1000c604c:     	ldrsb	w8, [x19, x8]
1000c6050:     	ldrsb	w3, [x20, x3]
1000c6054:     	ldp	x28, x27, [sp, #160]
1000c6058:     	ldrsb	w27, [x21, x27]
1000c605c:     	ldrsb	w28, [x23, x28]
1000c6060:     	add	w8, w8, w3
1000c6064:     	add	w8, w8, w27
1000c6068:     	ldr	x3, [sp, #152]
1000c606c:     	ldrsb	w3, [x22, x3]
1000c6070:     	add	w8, w8, w28
1000c6074:     	add	w8, w8, w3
1000c6078:     	ldp	x27, x3, [sp, #136]
1000c607c:     	ldrsb	w3, [x24, x3]
1000c6080:     	ldrsb	w27, [x25, x27]
1000c6084:     	add	w8, w8, w3
1000c6088:     	add	w8, w8, w27
1000c608c:     	ldr	x3, [sp, #128]
1000c6090:     	ldrsb	w3, [x26, x3]
1000c6094:     	add	w8, w8, w3
1000c6098:     	scvtf	s4, w8
1000c609c:     	ldp	x3, x8, [sp, #112]
1000c60a0:     	ldrsb	w8, [x19, x8]
1000c60a4:     	ldrsb	w3, [x20, x3]
1000c60a8:     	ldp	x28, x27, [sp, #96]
1000c60ac:     	ldrsb	w27, [x21, x27]
1000c60b0:     	ldrsb	w28, [x23, x28]
1000c60b4:     	add	w8, w8, w3
1000c60b8:     	ldr	x3, [sp, #88]
1000c60bc:     	ldrsb	w3, [x22, x3]
1000c60c0:     	add	w8, w8, w27
1000c60c4:     	ldr	x27, [sp, #80]
1000c60c8:     	ldrsb	w27, [x24, x27]
1000c60cc:     	add	w8, w8, w28
1000c60d0:     	ldr	x28, [sp, #72]
1000c60d4:     	ldrsb	w28, [x25, x28]
1000c60d8:     	add	w8, w8, w3
1000c60dc:     	add	w8, w8, w27
1000c60e0:     	add	w8, w8, w28
1000c60e4:     	ldr	x3, [sp, #64]
1000c60e8:     	ldrsb	w3, [x26, x3]
1000c60ec:     	add	w8, w8, w3
1000c60f0:     	scvtf	s5, w8
1000c60f4:     	ldp	x3, x8, [sp, #48]
1000c60f8:     	ldrsb	w8, [x19, x8]
1000c60fc:     	ldrsb	w3, [x20, x3]
1000c6100:     	ldr	x27, [sp, #40]
1000c6104:     	ldrsb	w27, [x21, x27]
1000c6108:     	add	w8, w8, w3
1000c610c:     	ldr	x3, [sp, #32]
1000c6110:     	ldrsb	w3, [x23, x3]
1000c6114:     	add	w8, w8, w27
1000c6118:     	ldrsb	w27, [x22, x10]
1000c611c:     	add	w8, w8, w3
1000c6120:     	ldrsb	w3, [x24, x13]
1000c6124:     	add	w8, w8, w27
1000c6128:     	ldrsb	w27, [x25, x9]
1000c612c:     	add	w8, w8, w3
1000c6130:     	ldrsb	w3, [x26, x14]
1000c6134:     	add	w8, w8, w27
1000c6138:     	add	w8, w8, w3
1000c613c:     	scvtf	s6, w8
1000c6140:     	ldrsb	w8, [x19, x15]
1000c6144:     	ldrsb	w3, [x20, x16]
1000c6148:     	ldrsb	w19, [x21, x17]
1000c614c:     	add	w8, w8, w3
1000c6150:     	add	w8, w8, w19
1000c6154:     	ldrsb	w3, [x23, x2]
1000c6158:     	ldrsb	w19, [x22, x4]
1000c615c:     	add	w8, w8, w3
1000c6160:     	add	w8, w8, w19
1000c6164:     	ldrsb	w3, [x24, x5]
1000c6168:     	ldrsb	w19, [x25, x6]
1000c616c:     	add	w8, w8, w3
1000c6170:     	add	w8, w8, w19
1000c6174:     	mov	x19, x1
1000c6178:     	ldrsb	w3, [x26, x7]
1000c617c:     	add	w8, w8, w3
1000c6180:     	add	x3, sp, #448
1000c6184:     	scvtf	s7, w8
1000c6188:     	add	x8, x1, x12
1000c618c:     	ldur	s16, [x8, #-96]
1000c6190:     	fadd	s1, s16, s1
1000c6194:     	stur	s1, [x8, #-96]
1000c6198:     	ldur	s1, [x8, #-64]
1000c619c:     	fadd	s1, s1, s2
1000c61a0:     	stur	s1, [x8, #-64]
1000c61a4:     	ldur	s1, [x8, #-32]
1000c61a8:     	fadd	s1, s1, s3
1000c61ac:     	stur	s1, [x8, #-32]
1000c61b0:     	ldr	s1, [x8]
1000c61b4:     	fadd	s1, s1, s4
1000c61b8:     	str	s1, [x8]
1000c61bc:     	ldr	s1, [x8, #32]
1000c61c0:     	fadd	s1, s1, s5
1000c61c4:     	str	s1, [x8, #32]
1000c61c8:     	ldr	s1, [x8, #64]
1000c61cc:     	fadd	s1, s1, s6
1000c61d0:     	str	s1, [x8, #64]
1000c61d4:     	ldr	s1, [x8, #96]
1000c61d8:     	fadd	s1, s1, s7
1000c61dc:     	ldr	s2, [x3, x12]
1000c61e0:     	str	s1, [x8, #96]
1000c61e4:     	fadd	s0, s2, s0
1000c61e8:     	str	s0, [x3, x12]
1000c61ec:     	add	x12, x12, #4
1000c61f0:     	cmp	x12, #32
1000c61f4:     	b.ne	0x1000c5e80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c61f8:     	add	x0, x0, #32
1000c61fc:     	ldp	x8, x1, [sp, #16]
1000c6200:     	add	x1, x1, #32
1000c6204:     	cmp	x1, x8
1000c6208:     	b.ne	0x1000c5cdc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c620c:     	ldp	q0, q1, [sp, #640]
1000c6210:     	ldr	x8, [sp, #8]
1000c6214:     	stp	q0, q1, [x8, #192]
1000c6218:     	ldp	q0, q1, [sp, #672]
1000c621c:     	stp	q0, q1, [x8, #224]
1000c6220:     	ldp	q0, q1, [sp, #576]
1000c6224:     	stp	q0, q1, [x8, #128]
1000c6228:     	ldp	q0, q1, [sp, #608]
1000c622c:     	stp	q0, q1, [x8, #160]
1000c6230:     	ldp	q0, q1, [sp, #512]
1000c6234:     	stp	q0, q1, [x8, #64]
1000c6238:     	ldp	q0, q1, [sp, #544]
1000c623c:     	stp	q0, q1, [x8, #96]
1000c6240:     	ldp	q0, q1, [sp, #448]
1000c6244:     	stp	q0, q1, [x8]
1000c6248:     	ldp	q0, q1, [sp, #480]
1000c624c:     	stp	q0, q1, [x8, #32]
1000c6250:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x25c>
1000c6254:     	ldr	x8, [x8, #392]
1000c6258:     	ldr	x8, [x8]
1000c625c:     	ldur	x9, [x29, #-96]
1000c6260:     	cmp	x8, x9
1000c6264:     	b.ne	0x1000c6288 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c6268:     	add	sp, sp, #720
1000c626c:     	ldp	x29, x30, [sp, #80]
1000c6270:     	ldp	x20, x19, [sp, #64]
1000c6274:     	ldp	x22, x21, [sp, #48]
1000c6278:     	ldp	x24, x23, [sp, #32]
1000c627c:     	ldp	x26, x25, [sp, #16]
1000c6280:     	ldp	x28, x27, [sp], #96
1000c6284:     	ret
1000c6288:     	bl	0x100163694 <_strcmp+0x100163694>

