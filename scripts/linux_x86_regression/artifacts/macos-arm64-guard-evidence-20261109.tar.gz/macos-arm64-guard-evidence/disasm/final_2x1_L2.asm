00000001000b6a20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b6a20:     	stp	x24, x23, [sp, #-48]!
1000b6a24:     	stp	x22, x21, [sp, #16]
1000b6a28:     	stp	x20, x19, [sp, #32]
1000b6a2c:     	str	xzr, [x3]
1000b6a30:     	lsl	x8, x4, #2
1000b6a34:     	cmp	x2, #8
1000b6a38:     	b.hs	0x1000b6a4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b6a3c:     	mov	x12, #0
1000b6a40:     	movi	d1, #0000000000000000
1000b6a44:     	movi	d0, #0000000000000000
1000b6a48:     	b	0x1000b6bb4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b6a4c:     	mov	x10, #0
1000b6a50:     	adrp	x9, 0x100169000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x90>
1000b6a54:     	add	x9, x9, #3772
1000b6a58:     	mov	x11, x1
1000b6a5c:     	ldr	w4, [x11]
1000b6a60:     	lsl	w12, w4, #4
1000b6a64:     	and	x13, x12, #0xf0
1000b6a68:     	and	x12, x4, #0xf0
1000b6a6c:     	add	x12, x9, x12
1000b6a70:     	lsr	x14, x4, #4
1000b6a74:     	and	x15, x14, #0xf0
1000b6a78:     	add	x14, x9, x13
1000b6a7c:     	add	x13, x9, x15
1000b6a80:     	lsr	x15, x4, #8
1000b6a84:     	and	x15, x15, #0xf0
1000b6a88:     	lsr	x16, x4, #12
1000b6a8c:     	and	x17, x16, #0xf0
1000b6a90:     	add	x16, x9, x15
1000b6a94:     	add	x15, x9, x17
1000b6a98:     	lsr	x17, x4, #16
1000b6a9c:     	and	x17, x17, #0xf0
1000b6aa0:     	lsr	x5, x4, #20
1000b6aa4:     	and	x5, x5, #0xf0
1000b6aa8:     	add	x17, x9, x17
1000b6aac:     	lsr	x4, x4, #24
1000b6ab0:     	and	x6, x4, #0xf0
1000b6ab4:     	add	x7, x0, x10
1000b6ab8:     	ldr	w19, [x7]
1000b6abc:     	and	x20, x19, #0xf
1000b6ac0:     	add	x4, x9, x5
1000b6ac4:     	ldrb	w5, [x14, x20]
1000b6ac8:     	ubfx	x20, x19, #4, #4
1000b6acc:     	ubfx	x21, x19, #8, #4
1000b6ad0:     	ldrb	w20, [x12, x20]
1000b6ad4:     	ldrb	w21, [x13, x21]
1000b6ad8:     	ubfx	x22, x19, #12, #4
1000b6adc:     	ubfx	x23, x19, #16, #4
1000b6ae0:     	ldrb	w22, [x16, x22]
1000b6ae4:     	ldrb	w23, [x15, x23]
1000b6ae8:     	ubfx	x24, x19, #20, #4
1000b6aec:     	ldrb	w24, [x17, x24]
1000b6af0:     	add	w5, w5, w20
1000b6af4:     	add	w5, w5, w21
1000b6af8:     	ubfx	x20, x19, #24, #4
1000b6afc:     	ldrb	w20, [x4, x20]
1000b6b00:     	add	w5, w5, w22
1000b6b04:     	add	w5, w5, w23
1000b6b08:     	add	x6, x9, x6
1000b6b0c:     	lsr	x19, x19, #28
1000b6b10:     	ldrb	w19, [x6, x19]
1000b6b14:     	add	w5, w5, w24
1000b6b18:     	add	w5, w5, w20
1000b6b1c:     	add	w5, w5, w19
1000b6b20:     	scvtf	s0, w5
1000b6b24:     	ldp	s1, s2, [x3]
1000b6b28:     	fadd	s0, s1, s0
1000b6b2c:     	str	s0, [x3]
1000b6b30:     	ldr	w5, [x7, #4]
1000b6b34:     	and	x7, x5, #0xf
1000b6b38:     	ubfx	x19, x5, #4, #4
1000b6b3c:     	ldrb	w14, [x14, x7]
1000b6b40:     	ldrb	w12, [x12, x19]
1000b6b44:     	ubfx	x7, x5, #8, #4
1000b6b48:     	ubfx	x19, x5, #12, #4
1000b6b4c:     	ldrb	w13, [x13, x7]
1000b6b50:     	ldrb	w16, [x16, x19]
1000b6b54:     	ubfx	x7, x5, #16, #4
1000b6b58:     	ldrb	w15, [x15, x7]
1000b6b5c:     	add	w12, w14, w12
1000b6b60:     	add	w12, w12, w13
1000b6b64:     	ubfx	x13, x5, #20, #4
1000b6b68:     	ldrb	w13, [x17, x13]
1000b6b6c:     	add	w12, w12, w16
1000b6b70:     	add	w12, w12, w15
1000b6b74:     	ubfx	x14, x5, #24, #4
1000b6b78:     	ldrb	w14, [x4, x14]
1000b6b7c:     	lsr	x15, x5, #28
1000b6b80:     	add	w12, w12, w13
1000b6b84:     	add	w12, w12, w14
1000b6b88:     	ldrb	w13, [x6, x15]
1000b6b8c:     	add	w12, w12, w13
1000b6b90:     	scvtf	s1, w12
1000b6b94:     	fadd	s1, s2, s1
1000b6b98:     	str	s1, [x3, #4]
1000b6b9c:     	add	x12, x10, #8
1000b6ba0:     	add	x11, x11, x8
1000b6ba4:     	add	x13, x10, #16
1000b6ba8:     	mov	x10, x12
1000b6bac:     	cmp	x13, x2
1000b6bb0:     	b.ls	0x1000b6a5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b6bb4:     	cmp	x12, x2
1000b6bb8:     	b.hs	0x1000b6c60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x240>
1000b6bbc:     	lsl	w9, w12, #2
1000b6bc0:     	mov	w10, #-16
1000b6bc4:     	lsr	x11, x12, #3
1000b6bc8:     	mul	x11, x8, x11
1000b6bcc:     	ubfx	x13, x12, #1, #2
1000b6bd0:     	orr	x11, x11, x13
1000b6bd4:     	and	w13, w9, #0x4
1000b6bd8:     	ldrb	w11, [x1, x11]
1000b6bdc:     	lsr	w11, w11, w13
1000b6be0:     	and	w14, w11, #0xf
1000b6be4:     	cmp	w14, #8
1000b6be8:     	csel	w14, wzr, w10, lo
1000b6bec:     	and	x15, x12, #0xfffffffffffffff8
1000b6bf0:     	bfxil	w14, w11, #0, #4
1000b6bf4:     	bfxil	x15, x12, #1, #2
1000b6bf8:     	add	x11, x0, x15
1000b6bfc:     	ldrb	w15, [x11]
1000b6c00:     	lsr	w15, w15, w13
1000b6c04:     	scvtf	s2, w14
1000b6c08:     	and	w14, w15, #0xf
1000b6c0c:     	cmp	w14, #8
1000b6c10:     	csel	w14, wzr, w10, lo
1000b6c14:     	bfxil	w14, w15, #0, #4
1000b6c18:     	scvtf	s3, w14
1000b6c1c:     	fsub	s3, s3, s2
1000b6c20:     	fmadd	s0, s3, s3, s0
1000b6c24:     	str	s0, [x3]
1000b6c28:     	ldrb	w11, [x11, #4]
1000b6c2c:     	lsr	w11, w11, w13
1000b6c30:     	and	w13, w11, #0xf
1000b6c34:     	cmp	w13, #8
1000b6c38:     	csel	w13, wzr, w10, lo
1000b6c3c:     	bfxil	w13, w11, #0, #4
1000b6c40:     	scvtf	s3, w13
1000b6c44:     	fsub	s2, s3, s2
1000b6c48:     	fmadd	s1, s2, s2, s1
1000b6c4c:     	str	s1, [x3, #4]
1000b6c50:     	add	x12, x12, #1
1000b6c54:     	add	w9, w9, #4
1000b6c58:     	cmp	x2, x12
1000b6c5c:     	b.ne	0x1000b6bc4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b6c60:     	ldp	x20, x19, [sp, #32]
1000b6c64:     	ldp	x22, x21, [sp, #16]
1000b6c68:     	ldp	x24, x23, [sp], #48
1000b6c6c:     	ret

