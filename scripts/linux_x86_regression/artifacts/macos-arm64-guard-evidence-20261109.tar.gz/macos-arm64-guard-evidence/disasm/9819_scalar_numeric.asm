
bin/9819_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010015dc70 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)>:
10015dc70:     	cbz	x2, 0x10015dc88 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0x18>
10015dc74:     	cmp	x2, #8
10015dc78:     	b.hs	0x10015dc94 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0x24>
10015dc7c:     	mov	x8, #0
10015dc80:     	movi	d0, #0000000000000000
10015dc84:     	b	0x10015dd28 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0xb8>
10015dc88:     	movi	d0, #0000000000000000
10015dc8c:     	str	s0, [x3]
10015dc90:     	ret
10015dc94:     	and	x8, x2, #0xfffffffffffffff8
10015dc98:     	add	x9, x0, #32
10015dc9c:     	add	x10, x1, #32
10015dca0:     	movi	d0, #0000000000000000
10015dca4:     	mov	x11, x8
10015dca8:     	ldp	q1, q2, [x9, #-32]
10015dcac:     	ldp	q3, q4, [x9], #64
10015dcb0:     	ldp	q5, q6, [x10, #-32]
10015dcb4:     	ldp	q7, q16, [x10], #64
10015dcb8:     	fsub.2d	v1, v1, v5
10015dcbc:     	fsub.2d	v2, v2, v6
10015dcc0:     	fsub.2d	v3, v3, v7
10015dcc4:     	fsub.2d	v4, v4, v16
10015dcc8:     	fmul.2d	v1, v1, v1
10015dccc:     	fmul.2d	v2, v2, v2
10015dcd0:     	fmul.2d	v3, v3, v3
10015dcd4:     	fmul.2d	v4, v4, v4
10015dcd8:     	fcvtn	v1.2s, v1.2d
10015dcdc:     	mov	s5, v1[1]
10015dce0:     	fcvtn	v2.2s, v2.2d
10015dce4:     	mov	s6, v2[1]
10015dce8:     	fcvtn	v3.2s, v3.2d
10015dcec:     	mov	s7, v3[1]
10015dcf0:     	fcvtn	v4.2s, v4.2d
10015dcf4:     	mov	s16, v4[1]
10015dcf8:     	fadd	s0, s0, s1
10015dcfc:     	fadd	s0, s0, s5
10015dd00:     	fadd	s0, s0, s2
10015dd04:     	fadd	s0, s0, s6
10015dd08:     	fadd	s0, s0, s3
10015dd0c:     	fadd	s0, s0, s7
10015dd10:     	fadd	s0, s0, s4
10015dd14:     	fadd	s0, s0, s16
10015dd18:     	subs	x11, x11, #8
10015dd1c:     	b.ne	0x10015dca8 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0x38>
10015dd20:     	cmp	x8, x2
10015dd24:     	b.eq	0x10015dd58 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0xe8>
10015dd28:     	sub	x9, x2, x8
10015dd2c:     	lsl	x10, x8, #3
10015dd30:     	add	x8, x1, x10
10015dd34:     	add	x10, x0, x10
10015dd38:     	ldr	d1, [x10], #8
10015dd3c:     	ldr	d2, [x8], #8
10015dd40:     	fsub	d1, d1, d2
10015dd44:     	fmul	d1, d1, d1
10015dd48:     	fcvt	s1, d1
10015dd4c:     	fadd	s0, s0, s1
10015dd50:     	subs	x9, x9, #1
10015dd54:     	b.ne	0x10015dd38 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0xc8>
10015dd58:     	str	s0, [x3]
10015dd5c:     	ret

000000010015df6c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)>:
10015df6c:     	cbz	x2, 0x10015df84 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0x18>
10015df70:     	cmp	x2, #8
10015df74:     	b.hs	0x10015df8c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0x20>
10015df78:     	mov	x8, #0
10015df7c:     	movi	d0, #0000000000000000
10015df80:     	b	0x10015e010 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xa4>
10015df84:     	movi	d0, #0000000000000000
10015df88:     	b	0x10015e03c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xd0>
10015df8c:     	and	x8, x2, #0xfffffffffffffff8
10015df90:     	add	x9, x0, #32
10015df94:     	add	x10, x1, #32
10015df98:     	movi	d0, #0000000000000000
10015df9c:     	mov	x11, x8
10015dfa0:     	ldp	q1, q2, [x9, #-32]
10015dfa4:     	ldp	q3, q4, [x9], #64
10015dfa8:     	ldp	q5, q6, [x10, #-32]
10015dfac:     	ldp	q7, q16, [x10], #64
10015dfb0:     	fmul.2d	v1, v1, v5
10015dfb4:     	fmul.2d	v2, v2, v6
10015dfb8:     	fmul.2d	v3, v3, v7
10015dfbc:     	fmul.2d	v4, v4, v16
10015dfc0:     	fcvtn	v1.2s, v1.2d
10015dfc4:     	mov	s5, v1[1]
10015dfc8:     	fcvtn	v2.2s, v2.2d
10015dfcc:     	mov	s6, v2[1]
10015dfd0:     	fcvtn	v3.2s, v3.2d
10015dfd4:     	mov	s7, v3[1]
10015dfd8:     	fcvtn	v4.2s, v4.2d
10015dfdc:     	mov	s16, v4[1]
10015dfe0:     	fadd	s0, s0, s1
10015dfe4:     	fadd	s0, s0, s5
10015dfe8:     	fadd	s0, s0, s2
10015dfec:     	fadd	s0, s0, s6
10015dff0:     	fadd	s0, s0, s3
10015dff4:     	fadd	s0, s0, s7
10015dff8:     	fadd	s0, s0, s4
10015dffc:     	fadd	s0, s0, s16
10015e000:     	subs	x11, x11, #8
10015e004:     	b.ne	0x10015dfa0 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0x34>
10015e008:     	cmp	x8, x2
10015e00c:     	b.eq	0x10015e03c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xd0>
10015e010:     	sub	x9, x2, x8
10015e014:     	lsl	x10, x8, #3
10015e018:     	add	x8, x1, x10
10015e01c:     	add	x10, x0, x10
10015e020:     	ldr	d1, [x10], #8
10015e024:     	ldr	d2, [x8], #8
10015e028:     	fmul	d1, d1, d2
10015e02c:     	fcvt	s1, d1
10015e030:     	fadd	s0, s0, s1
10015e034:     	subs	x9, x9, #1
10015e038:     	b.ne	0x10015e020 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xb4>
10015e03c:     	fneg	s0, s0
10015e040:     	str	s0, [x3]
10015e044:     	ret

000000010015e234 <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)>:
10015e234:     	cbz	x2, 0x10015e24c <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x18>
10015e238:     	cmp	x2, #16
10015e23c:     	b.hs	0x10015e258 <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x24>
10015e240:     	mov	x8, #0
10015e244:     	movi	d0, #0000000000000000
10015e248:     	b	0x10015e3ec <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x1b8>
10015e24c:     	movi	d0, #0000000000000000
10015e250:     	str	s0, [x3]
10015e254:     	ret
10015e258:     	and	x8, x2, #0xfffffffffffffff0
10015e25c:     	add	x9, x0, #16
10015e260:     	add	x10, x1, #16
10015e264:     	movi	d0, #0000000000000000
10015e268:     	mov	x11, x8
10015e26c:     	ldp	q1, q2, [x9, #-16]
10015e270:     	sshll.4s	v3, v1, #0
10015e274:     	sshll.2d	v4, v3, #0
10015e278:     	scvtf.2d	v4, v4
10015e27c:     	sshll2.2d	v3, v3, #0
10015e280:     	scvtf.2d	v3, v3
10015e284:     	sshll2.4s	v1, v1, #0
10015e288:     	sshll.2d	v5, v1, #0
10015e28c:     	scvtf.2d	v5, v5
10015e290:     	sshll2.2d	v1, v1, #0
10015e294:     	scvtf.2d	v1, v1
10015e298:     	sshll.4s	v6, v2, #0
10015e29c:     	sshll.2d	v7, v6, #0
10015e2a0:     	scvtf.2d	v7, v7
10015e2a4:     	sshll2.2d	v6, v6, #0
10015e2a8:     	scvtf.2d	v6, v6
10015e2ac:     	sshll2.4s	v2, v2, #0
10015e2b0:     	sshll.2d	v16, v2, #0
10015e2b4:     	scvtf.2d	v16, v16
10015e2b8:     	sshll2.2d	v2, v2, #0
10015e2bc:     	scvtf.2d	v2, v2
10015e2c0:     	ldp	q17, q18, [x10, #-16]
10015e2c4:     	sshll.4s	v19, v17, #0
10015e2c8:     	sshll.2d	v20, v19, #0
10015e2cc:     	scvtf.2d	v20, v20
10015e2d0:     	sshll2.2d	v19, v19, #0
10015e2d4:     	scvtf.2d	v19, v19
10015e2d8:     	sshll2.4s	v17, v17, #0
10015e2dc:     	sshll.2d	v21, v17, #0
10015e2e0:     	scvtf.2d	v21, v21
10015e2e4:     	sshll2.2d	v17, v17, #0
10015e2e8:     	scvtf.2d	v17, v17
10015e2ec:     	sshll.4s	v22, v18, #0
10015e2f0:     	sshll.2d	v23, v22, #0
10015e2f4:     	scvtf.2d	v23, v23
10015e2f8:     	sshll2.2d	v22, v22, #0
10015e2fc:     	scvtf.2d	v22, v22
10015e300:     	sshll2.4s	v18, v18, #0
10015e304:     	sshll.2d	v24, v18, #0
10015e308:     	scvtf.2d	v24, v24
10015e30c:     	sshll2.2d	v18, v18, #0
10015e310:     	scvtf.2d	v18, v18
10015e314:     	fsub.2d	v1, v1, v17
10015e318:     	fsub.2d	v5, v5, v21
10015e31c:     	fsub.2d	v3, v3, v19
10015e320:     	fsub.2d	v4, v4, v20
10015e324:     	fsub.2d	v2, v2, v18
10015e328:     	fsub.2d	v16, v16, v24
10015e32c:     	fsub.2d	v6, v6, v22
10015e330:     	fsub.2d	v7, v7, v23
10015e334:     	fmul.2d	v4, v4, v4
10015e338:     	fmul.2d	v3, v3, v3
10015e33c:     	fmul.2d	v5, v5, v5
10015e340:     	fmul.2d	v1, v1, v1
10015e344:     	fmul.2d	v7, v7, v7
10015e348:     	fmul.2d	v6, v6, v6
10015e34c:     	fmul.2d	v16, v16, v16
10015e350:     	fmul.2d	v2, v2, v2
10015e354:     	fcvtn	v1.2s, v1.2d
10015e358:     	mov	s17, v1[1]
10015e35c:     	fcvtn	v5.2s, v5.2d
10015e360:     	mov	s18, v5[1]
10015e364:     	fcvtn	v3.2s, v3.2d
10015e368:     	mov	s19, v3[1]
10015e36c:     	fcvtn	v4.2s, v4.2d
10015e370:     	mov	s20, v4[1]
10015e374:     	fcvtn	v2.2s, v2.2d
10015e378:     	mov	s21, v2[1]
10015e37c:     	fcvtn	v16.2s, v16.2d
10015e380:     	mov	s22, v16[1]
10015e384:     	fcvtn	v6.2s, v6.2d
10015e388:     	mov	s23, v6[1]
10015e38c:     	fcvtn	v7.2s, v7.2d
10015e390:     	mov	s24, v7[1]
10015e394:     	fadd	s0, s0, s4
10015e398:     	fadd	s0, s0, s20
10015e39c:     	fadd	s0, s0, s3
10015e3a0:     	fadd	s0, s0, s19
10015e3a4:     	fadd	s0, s0, s5
10015e3a8:     	fadd	s0, s0, s18
10015e3ac:     	fadd	s0, s0, s1
10015e3b0:     	fadd	s0, s0, s17
10015e3b4:     	fadd	s0, s0, s7
10015e3b8:     	fadd	s0, s0, s24
10015e3bc:     	fadd	s0, s0, s6
10015e3c0:     	fadd	s0, s0, s23
10015e3c4:     	fadd	s0, s0, s16
10015e3c8:     	fadd	s0, s0, s22
10015e3cc:     	fadd	s0, s0, s2
10015e3d0:     	fadd	s0, s0, s21
10015e3d4:     	add	x9, x9, #32
10015e3d8:     	add	x10, x10, #32
10015e3dc:     	subs	x11, x11, #16
10015e3e0:     	b.ne	0x10015e26c <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x38>
10015e3e4:     	cmp	x8, x2
10015e3e8:     	b.eq	0x10015e424 <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x1f0>
10015e3ec:     	sub	x9, x2, x8
10015e3f0:     	lsl	x10, x8, #1
10015e3f4:     	add	x8, x1, x10
10015e3f8:     	add	x10, x0, x10
10015e3fc:     	ldrsh	w11, [x10], #2
10015e400:     	scvtf	d1, w11
10015e404:     	ldrsh	w11, [x8], #2
10015e408:     	scvtf	d2, w11
10015e40c:     	fsub	d1, d1, d2
10015e410:     	fmul	d1, d1, d1
10015e414:     	fcvt	s1, d1
10015e418:     	fadd	s0, s0, s1
10015e41c:     	subs	x9, x9, #1
10015e420:     	b.ne	0x10015e3fc <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x1c8>
10015e424:     	str	s0, [x3]
10015e428:     	ret

000000010015e694 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)>:
10015e694:     	cbz	x2, 0x10015e6ac <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x18>
10015e698:     	cmp	x2, #32
10015e69c:     	b.hs	0x10015e6b4 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x20>
10015e6a0:     	mov	x8, #0
10015e6a4:     	movi	d0, #0000000000000000
10015e6a8:     	b	0x10015e808 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x174>
10015e6ac:     	movi	d0, #0000000000000000
10015e6b0:     	b	0x10015e834 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x1a0>
10015e6b4:     	and	x8, x2, #0xffffffffffffffe0
10015e6b8:     	add	x9, x0, #32
10015e6bc:     	add	x10, x1, #32
10015e6c0:     	movi	d0, #0000000000000000
10015e6c4:     	mov	x11, x8
10015e6c8:     	ldp	q1, q2, [x9, #-32]
10015e6cc:     	ldp	q3, q4, [x9], #64
10015e6d0:     	ldp	q5, q6, [x10, #-32]
10015e6d4:     	ldp	q7, q16, [x10], #64
10015e6d8:     	smull.4s	v17, v5, v1
10015e6dc:     	smull2.4s	v5, v5, v1
10015e6e0:     	smull.4s	v18, v6, v2
10015e6e4:     	smull2.4s	v2, v6, v2
10015e6e8:     	smull.4s	v6, v7, v3
10015e6ec:     	smull2.4s	v3, v7, v3
10015e6f0:     	smull.4s	v7, v16, v4
10015e6f4:     	smull2.4s	v1, v16, v4
10015e6f8:     	scvtf.4s	v4, v17
10015e6fc:     	mov	s16, v4[1]
10015e700:     	fadd	s0, s0, s4
10015e704:     	fadd	s0, s0, s16
10015e708:     	mov	s16, v4[2]
10015e70c:     	fadd	s0, s0, s16
10015e710:     	scvtf.4s	v5, v5
10015e714:     	mov	s4, v4[3]
10015e718:     	fadd	s0, s0, s4
10015e71c:     	mov	s4, v5[1]
10015e720:     	fadd	s0, s0, s5
10015e724:     	fadd	s0, s0, s4
10015e728:     	mov	s4, v5[2]
10015e72c:     	fadd	s0, s0, s4
10015e730:     	mov	s4, v5[3]
10015e734:     	scvtf.4s	v5, v18
10015e738:     	fadd	s0, s0, s4
10015e73c:     	mov	s4, v5[1]
10015e740:     	fadd	s0, s0, s5
10015e744:     	fadd	s0, s0, s4
10015e748:     	mov	s4, v5[2]
10015e74c:     	fadd	s0, s0, s4
10015e750:     	scvtf.4s	v2, v2
10015e754:     	mov	s4, v5[3]
10015e758:     	fadd	s0, s0, s4
10015e75c:     	mov	s4, v2[1]
10015e760:     	fadd	s0, s0, s2
10015e764:     	fadd	s0, s0, s4
10015e768:     	mov	s4, v2[2]
10015e76c:     	fadd	s0, s0, s4
10015e770:     	mov	s2, v2[3]
10015e774:     	scvtf.4s	v4, v6
10015e778:     	fadd	s0, s0, s2
10015e77c:     	mov	s2, v4[1]
10015e780:     	fadd	s0, s0, s4
10015e784:     	fadd	s0, s0, s2
10015e788:     	mov	s2, v4[2]
10015e78c:     	fadd	s0, s0, s2
10015e790:     	scvtf.4s	v2, v3
10015e794:     	mov	s3, v4[3]
10015e798:     	fadd	s0, s0, s3
10015e79c:     	mov	s3, v2[1]
10015e7a0:     	fadd	s0, s0, s2
10015e7a4:     	fadd	s0, s0, s3
10015e7a8:     	mov	s3, v2[2]
10015e7ac:     	fadd	s0, s0, s3
10015e7b0:     	mov	s2, v2[3]
10015e7b4:     	scvtf.4s	v3, v7
10015e7b8:     	fadd	s0, s0, s2
10015e7bc:     	mov	s2, v3[1]
10015e7c0:     	fadd	s0, s0, s3
10015e7c4:     	fadd	s0, s0, s2
10015e7c8:     	mov	s2, v3[2]
10015e7cc:     	fadd	s0, s0, s2
10015e7d0:     	scvtf.4s	v1, v1
10015e7d4:     	mov	s2, v3[3]
10015e7d8:     	fadd	s0, s0, s2
10015e7dc:     	mov	s2, v1[1]
10015e7e0:     	fadd	s0, s0, s1
10015e7e4:     	fadd	s0, s0, s2
10015e7e8:     	mov	s2, v1[2]
10015e7ec:     	fadd	s0, s0, s2
10015e7f0:     	mov	s1, v1[3]
10015e7f4:     	fadd	s0, s0, s1
10015e7f8:     	subs	x11, x11, #32
10015e7fc:     	b.ne	0x10015e6c8 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x34>
10015e800:     	cmp	x8, x2
10015e804:     	b.eq	0x10015e834 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x1a0>
10015e808:     	sub	x9, x2, x8
10015e80c:     	lsl	x10, x8, #1
10015e810:     	add	x8, x1, x10
10015e814:     	add	x10, x0, x10
10015e818:     	ldrsh	w11, [x10], #2
10015e81c:     	ldrsh	w12, [x8], #2
10015e820:     	mul	w11, w12, w11
10015e824:     	scvtf	s1, w11
10015e828:     	fadd	s0, s0, s1
10015e82c:     	subs	x9, x9, #1
10015e830:     	b.ne	0x10015e818 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x184>
10015e834:     	fneg	s0, s0
10015e838:     	str	s0, [x3]
10015e83c:     	ret
