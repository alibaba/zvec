00000001000c1920 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c1920:     	sub	sp, sp, #208
1000c1924:     	stp	x28, x27, [sp, #112]
1000c1928:     	stp	x26, x25, [sp, #128]
1000c192c:     	stp	x24, x23, [sp, #144]
1000c1930:     	stp	x22, x21, [sp, #160]
1000c1934:     	stp	x20, x19, [sp, #176]
1000c1938:     	stp	x29, x30, [sp, #192]
1000c193c:     	add	x29, sp, #192
1000c1940:     	str	x3, [sp]
1000c1944:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000c1948:     	ldr	x8, [x8, #392]
1000c194c:     	ldr	x8, [x8]
1000c1950:     	stur	x8, [x29, #-88]
1000c1954:     	movi.2d	v0, #0000000000000000
1000c1958:     	stp	q0, q0, [sp, #64]
1000c195c:     	stp	q0, q0, [sp, #32]
1000c1960:     	ands	x8, x2, #0xfffffffffffffffe
1000c1964:     	b.eq	0x1000c1ae8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c1968:     	add	x8, x1, x8
1000c196c:     	str	x8, [sp, #8]
1000c1970:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x28>
1000c1974:     	add	x9, x9, #700
1000c1978:     	mov	x11, #0
1000c197c:     	ldp	w4, w23, [x1]
1000c1980:     	ubfx	x8, x4, #8, #4
1000c1984:     	stp	x1, x8, [sp, #16]
1000c1988:     	ubfx	x13, x4, #16, #4
1000c198c:     	and	x14, x4, #0xf
1000c1990:     	ubfx	x15, x4, #24, #4
1000c1994:     	ubfx	x16, x4, #4, #4
1000c1998:     	ubfx	x17, x4, #12, #4
1000c199c:     	ubfx	x2, x4, #20, #4
1000c19a0:     	lsr	x4, x4, #28
1000c19a4:     	and	x5, x23, #0xf
1000c19a8:     	ubfx	x6, x23, #8, #4
1000c19ac:     	ubfx	x7, x23, #16, #4
1000c19b0:     	ubfx	x19, x23, #24, #4
1000c19b4:     	ubfx	x20, x23, #4, #4
1000c19b8:     	ubfx	x21, x23, #12, #4
1000c19bc:     	ubfx	x22, x23, #20, #4
1000c19c0:     	lsr	x23, x23, #28
1000c19c4:     	ldr	w24, [x0, x11]
1000c19c8:     	lsl	w25, w24, #4
1000c19cc:     	and	x25, x25, #0xf0
1000c19d0:     	add	x25, x9, x25
1000c19d4:     	and	x26, x24, #0xf0
1000c19d8:     	add	x26, x9, x26
1000c19dc:     	lsr	x27, x24, #4
1000c19e0:     	and	x27, x27, #0xf0
1000c19e4:     	add	x27, x9, x27
1000c19e8:     	lsr	x28, x24, #8
1000c19ec:     	and	x28, x28, #0xf0
1000c19f0:     	add	x28, x9, x28
1000c19f4:     	lsr	x30, x24, #12
1000c19f8:     	and	x30, x30, #0xf0
1000c19fc:     	add	x30, x9, x30
1000c1a00:     	lsr	x8, x24, #16
1000c1a04:     	and	x8, x8, #0xf0
1000c1a08:     	add	x8, x9, x8
1000c1a0c:     	lsr	x3, x24, #20
1000c1a10:     	and	x3, x3, #0xf0
1000c1a14:     	add	x3, x9, x3
1000c1a18:     	lsr	x24, x24, #24
1000c1a1c:     	and	x24, x24, #0xf0
1000c1a20:     	ldrb	w10, [x25, x14]
1000c1a24:     	ldr	x12, [sp, #24]
1000c1a28:     	ldrb	w1, [x27, x12]
1000c1a2c:     	ldrb	w12, [x30, x13]
1000c1a30:     	add	w10, w10, w1
1000c1a34:     	add	w10, w10, w12
1000c1a38:     	ldrb	w12, [x3, x15]
1000c1a3c:     	ldrb	w1, [x26, x16]
1000c1a40:     	add	w10, w10, w12
1000c1a44:     	add	w10, w10, w1
1000c1a48:     	ldrb	w12, [x28, x17]
1000c1a4c:     	ldrb	w1, [x8, x2]
1000c1a50:     	add	x24, x9, x24
1000c1a54:     	add	w10, w10, w12
1000c1a58:     	add	w10, w10, w1
1000c1a5c:     	ldrb	w12, [x24, x4]
1000c1a60:     	add	w10, w10, w12
1000c1a64:     	scvtf	s0, w10
1000c1a68:     	add	x10, sp, #32
1000c1a6c:     	add	x10, x10, x11
1000c1a70:     	ldr	s1, [x10]
1000c1a74:     	ldrb	w12, [x25, x5]
1000c1a78:     	fadd	s0, s1, s0
1000c1a7c:     	ldrb	w1, [x27, x6]
1000c1a80:     	ldrb	w25, [x30, x7]
1000c1a84:     	add	w12, w12, w1
1000c1a88:     	add	w12, w12, w25
1000c1a8c:     	ldrb	w1, [x3, x19]
1000c1a90:     	ldrb	w3, [x26, x20]
1000c1a94:     	add	w12, w12, w1
1000c1a98:     	add	w12, w12, w3
1000c1a9c:     	ldrb	w1, [x28, x21]
1000c1aa0:     	ldrb	w8, [x8, x22]
1000c1aa4:     	add	w12, w12, w1
1000c1aa8:     	add	w8, w12, w8
1000c1aac:     	ldrb	w12, [x24, x23]
1000c1ab0:     	add	w8, w8, w12
1000c1ab4:     	scvtf	s1, w8
1000c1ab8:     	str	s0, [x10]
1000c1abc:     	ldr	s0, [x10, #32]
1000c1ac0:     	fadd	s0, s0, s1
1000c1ac4:     	str	s0, [x10, #32]
1000c1ac8:     	add	x11, x11, #4
1000c1acc:     	cmp	x11, #32
1000c1ad0:     	b.ne	0x1000c19c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1ad4:     	add	x0, x0, #32
1000c1ad8:     	ldp	x8, x1, [sp, #8]
1000c1adc:     	add	x1, x1, #8
1000c1ae0:     	cmp	x1, x8
1000c1ae4:     	b.ne	0x1000c1978 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1ae8:     	ldp	q0, q1, [sp, #32]
1000c1aec:     	ldr	x8, [sp]
1000c1af0:     	stp	q0, q1, [x8]
1000c1af4:     	ldp	q0, q1, [sp, #64]
1000c1af8:     	stp	q0, q1, [x8, #32]
1000c1afc:     	ldur	x8, [x29, #-88]
1000c1b00:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c0>
1000c1b04:     	ldr	x9, [x9, #392]
1000c1b08:     	ldr	x9, [x9]
1000c1b0c:     	cmp	x9, x8
1000c1b10:     	b.ne	0x1000c1b34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1b14:     	ldp	x29, x30, [sp, #192]
1000c1b18:     	ldp	x20, x19, [sp, #176]
1000c1b1c:     	ldp	x22, x21, [sp, #160]
1000c1b20:     	ldp	x24, x23, [sp, #144]
1000c1b24:     	ldp	x26, x25, [sp, #128]
1000c1b28:     	ldp	x28, x27, [sp, #112]
1000c1b2c:     	add	sp, sp, #208
1000c1b30:     	ret
1000c1b34:     	bl	0x100163694 <_strcmp+0x100163694>

