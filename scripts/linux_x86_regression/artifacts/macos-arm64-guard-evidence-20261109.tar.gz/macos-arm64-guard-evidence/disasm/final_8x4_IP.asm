00000001000c3b8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c3b8c:     	sub	sp, sp, #416
1000c3b90:     	stp	x28, x27, [sp, #320]
1000c3b94:     	stp	x26, x25, [sp, #336]
1000c3b98:     	stp	x24, x23, [sp, #352]
1000c3b9c:     	stp	x22, x21, [sp, #368]
1000c3ba0:     	stp	x20, x19, [sp, #384]
1000c3ba4:     	stp	x29, x30, [sp, #400]
1000c3ba8:     	add	x29, sp, #400
1000c3bac:     	str	x3, [sp]
1000c3bb0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
1000c3bb4:     	ldr	x8, [x8, #392]
1000c3bb8:     	ldr	x8, [x8]
1000c3bbc:     	stur	x8, [x29, #-96]
1000c3bc0:     	movi.2d	v0, #0000000000000000
1000c3bc4:     	stp	q0, q0, [sp, #272]
1000c3bc8:     	lsl	x8, x2, #1
1000c3bcc:     	stp	q0, q0, [sp, #240]
1000c3bd0:     	stp	q0, q0, [sp, #208]
1000c3bd4:     	stp	q0, q0, [sp, #176]
1000c3bd8:     	ands	x8, x8, #0xfffffffffffffffc
1000c3bdc:     	b.eq	0x1000c3eb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c3be0:     	add	x8, x1, x8
1000c3be4:     	str	x8, [sp, #8]
1000c3be8:     	add	x8, sp, #176
1000c3bec:     	add	x27, x8, #64
1000c3bf0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x300>
1000c3bf4:     	add	x11, x11, #956
1000c3bf8:     	mov	x12, #0
1000c3bfc:     	ldp	w8, w9, [x1]
1000c3c00:     	ubfx	x10, x8, #8, #4
1000c3c04:     	str	x10, [sp, #168]
1000c3c08:     	ubfx	x10, x8, #16, #4
1000c3c0c:     	str	x10, [sp, #160]
1000c3c10:     	ubfx	x10, x8, #24, #4
1000c3c14:     	str	x10, [sp, #152]
1000c3c18:     	ldp	w10, w17, [x1, #8]
1000c3c1c:     	str	x1, [sp, #16]
1000c3c20:     	and	x14, x8, #0xf
1000c3c24:     	ubfx	x13, x8, #4, #4
1000c3c28:     	stp	x13, x14, [sp, #136]
1000c3c2c:     	ubfx	x14, x8, #12, #4
1000c3c30:     	ubfx	x13, x8, #20, #4
1000c3c34:     	stp	x13, x14, [sp, #120]
1000c3c38:     	lsr	x8, x8, #28
1000c3c3c:     	str	x8, [sp, #112]
1000c3c40:     	and	x8, x9, #0xf
1000c3c44:     	str	x8, [sp, #104]
1000c3c48:     	ubfx	x8, x9, #8, #4
1000c3c4c:     	str	x8, [sp, #96]
1000c3c50:     	ubfx	x8, x9, #16, #4
1000c3c54:     	str	x8, [sp, #88]
1000c3c58:     	ubfx	x8, x9, #24, #4
1000c3c5c:     	str	x8, [sp, #80]
1000c3c60:     	ubfx	x8, x9, #4, #4
1000c3c64:     	str	x8, [sp, #72]
1000c3c68:     	ubfx	x8, x9, #12, #4
1000c3c6c:     	str	x8, [sp, #64]
1000c3c70:     	ubfx	x8, x9, #20, #4
1000c3c74:     	str	x8, [sp, #56]
1000c3c78:     	lsr	x8, x9, #28
1000c3c7c:     	str	x8, [sp, #48]
1000c3c80:     	and	x9, x10, #0xf
1000c3c84:     	ubfx	x8, x10, #8, #4
1000c3c88:     	stp	x8, x9, [sp, #32]
1000c3c8c:     	ubfx	x8, x10, #16, #4
1000c3c90:     	str	x8, [sp, #24]
1000c3c94:     	ubfx	x28, x10, #24, #4
1000c3c98:     	ubfx	x30, x10, #4, #4
1000c3c9c:     	ubfx	x8, x10, #12, #4
1000c3ca0:     	ubfx	x3, x10, #20, #4
1000c3ca4:     	lsr	x9, x10, #28
1000c3ca8:     	and	x1, x17, #0xf
1000c3cac:     	ubfx	x10, x17, #8, #4
1000c3cb0:     	ubfx	x13, x17, #16, #4
1000c3cb4:     	ubfx	x26, x17, #24, #4
1000c3cb8:     	ubfx	x14, x17, #4, #4
1000c3cbc:     	ubfx	x15, x17, #12, #4
1000c3cc0:     	ubfx	x16, x17, #20, #4
1000c3cc4:     	lsr	x17, x17, #28
1000c3cc8:     	ldr	w20, [x0, x12]
1000c3ccc:     	lsl	w2, w20, #4
1000c3cd0:     	and	x2, x2, #0xf0
1000c3cd4:     	add	x5, x11, x2
1000c3cd8:     	and	x2, x20, #0xf0
1000c3cdc:     	add	x2, x11, x2
1000c3ce0:     	lsr	x4, x20, #4
1000c3ce4:     	and	x4, x4, #0xf0
1000c3ce8:     	add	x7, x11, x4
1000c3cec:     	lsr	x4, x20, #8
1000c3cf0:     	and	x4, x4, #0xf0
1000c3cf4:     	add	x4, x11, x4
1000c3cf8:     	lsr	x6, x20, #12
1000c3cfc:     	and	x6, x6, #0xf0
1000c3d00:     	add	x19, x11, x6
1000c3d04:     	lsr	x6, x20, #16
1000c3d08:     	and	x6, x6, #0xf0
1000c3d0c:     	add	x6, x11, x6
1000c3d10:     	lsr	x21, x20, #20
1000c3d14:     	and	x21, x21, #0xf0
1000c3d18:     	add	x21, x11, x21
1000c3d1c:     	lsr	x20, x20, #24
1000c3d20:     	and	x20, x20, #0xf0
1000c3d24:     	ldr	x22, [sp, #144]
1000c3d28:     	ldrsb	w22, [x5, x22]
1000c3d2c:     	add	x20, x11, x20
1000c3d30:     	ldp	x24, x23, [sp, #160]
1000c3d34:     	ldrsb	w23, [x7, x23]
1000c3d38:     	ldrsb	w24, [x19, x24]
1000c3d3c:     	add	w22, w22, w23
1000c3d40:     	add	w22, w22, w24
1000c3d44:     	ldr	x23, [sp, #152]
1000c3d48:     	ldrsb	w23, [x21, x23]
1000c3d4c:     	ldr	x24, [sp, #136]
1000c3d50:     	ldrsb	w24, [x2, x24]
1000c3d54:     	add	w22, w22, w23
1000c3d58:     	add	w22, w22, w24
1000c3d5c:     	ldp	x24, x23, [sp, #120]
1000c3d60:     	ldrsb	w23, [x4, x23]
1000c3d64:     	ldrsb	w24, [x6, x24]
1000c3d68:     	add	w22, w22, w23
1000c3d6c:     	add	w22, w22, w24
1000c3d70:     	ldr	x23, [sp, #112]
1000c3d74:     	ldrsb	w23, [x20, x23]
1000c3d78:     	add	w22, w22, w23
1000c3d7c:     	scvtf	s0, w22
1000c3d80:     	ldp	x23, x22, [sp, #96]
1000c3d84:     	ldrsb	w22, [x5, x22]
1000c3d88:     	ldrsb	w23, [x7, x23]
1000c3d8c:     	ldp	x25, x24, [sp, #80]
1000c3d90:     	ldrsb	w24, [x19, x24]
1000c3d94:     	ldrsb	w25, [x21, x25]
1000c3d98:     	add	w22, w22, w23
1000c3d9c:     	ldr	x23, [sp, #72]
1000c3da0:     	ldrsb	w23, [x2, x23]
1000c3da4:     	add	w22, w22, w24
1000c3da8:     	ldr	x24, [sp, #64]
1000c3dac:     	ldrsb	w24, [x4, x24]
1000c3db0:     	add	w22, w22, w25
1000c3db4:     	ldr	x25, [sp, #56]
1000c3db8:     	ldrsb	w25, [x6, x25]
1000c3dbc:     	add	w22, w22, w23
1000c3dc0:     	add	w22, w22, w24
1000c3dc4:     	add	w22, w22, w25
1000c3dc8:     	ldr	x23, [sp, #48]
1000c3dcc:     	ldrsb	w23, [x20, x23]
1000c3dd0:     	add	w22, w22, w23
1000c3dd4:     	scvtf	s1, w22
1000c3dd8:     	ldp	x23, x22, [sp, #32]
1000c3ddc:     	ldrsb	w22, [x5, x22]
1000c3de0:     	ldrsb	w23, [x7, x23]
1000c3de4:     	ldr	x24, [sp, #24]
1000c3de8:     	ldrsb	w24, [x19, x24]
1000c3dec:     	add	w22, w22, w23
1000c3df0:     	ldrsb	w23, [x21, x28]
1000c3df4:     	add	w22, w22, w24
1000c3df8:     	ldrsb	w24, [x2, x30]
1000c3dfc:     	add	w22, w22, w23
1000c3e00:     	ldrsb	w23, [x4, x8]
1000c3e04:     	add	w22, w22, w24
1000c3e08:     	ldrsb	w24, [x6, x3]
1000c3e0c:     	add	w22, w22, w23
1000c3e10:     	ldrsb	w23, [x20, x9]
1000c3e14:     	add	w22, w22, w24
1000c3e18:     	add	w22, w22, w23
1000c3e1c:     	scvtf	s2, w22
1000c3e20:     	ldrsb	w5, [x5, x1]
1000c3e24:     	ldrsb	w7, [x7, x10]
1000c3e28:     	ldrsb	w19, [x19, x13]
1000c3e2c:     	add	w5, w5, w7
1000c3e30:     	add	w5, w5, w19
1000c3e34:     	ldrsb	w7, [x21, x26]
1000c3e38:     	ldrsb	w2, [x2, x14]
1000c3e3c:     	add	w5, w5, w7
1000c3e40:     	add	w2, w5, w2
1000c3e44:     	ldrsb	w4, [x4, x15]
1000c3e48:     	ldrsb	w5, [x6, x16]
1000c3e4c:     	add	w2, w2, w4
1000c3e50:     	add	w2, w2, w5
1000c3e54:     	ldrsb	w4, [x20, x17]
1000c3e58:     	add	w2, w2, w4
1000c3e5c:     	add	x4, sp, #176
1000c3e60:     	scvtf	s3, w2
1000c3e64:     	add	x2, x27, x12
1000c3e68:     	ldur	s4, [x2, #-32]
1000c3e6c:     	fadd	s1, s4, s1
1000c3e70:     	stur	s1, [x2, #-32]
1000c3e74:     	ldr	s1, [x2]
1000c3e78:     	fadd	s1, s1, s2
1000c3e7c:     	str	s1, [x2]
1000c3e80:     	ldr	s1, [x2, #32]
1000c3e84:     	fadd	s1, s1, s3
1000c3e88:     	ldr	s2, [x4, x12]
1000c3e8c:     	str	s1, [x2, #32]
1000c3e90:     	fadd	s0, s2, s0
1000c3e94:     	str	s0, [x4, x12]
1000c3e98:     	add	x12, x12, #4
1000c3e9c:     	cmp	x12, #32
1000c3ea0:     	b.ne	0x1000c3cc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3ea4:     	add	x0, x0, #32
1000c3ea8:     	ldp	x8, x1, [sp, #8]
1000c3eac:     	add	x1, x1, #16
1000c3eb0:     	cmp	x1, x8
1000c3eb4:     	b.ne	0x1000c3bf8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c3eb8:     	ldp	q0, q1, [sp, #240]
1000c3ebc:     	ldr	x8, [sp]
1000c3ec0:     	stp	q0, q1, [x8, #64]
1000c3ec4:     	ldp	q0, q1, [sp, #272]
1000c3ec8:     	stp	q0, q1, [x8, #96]
1000c3ecc:     	ldp	q0, q1, [sp, #176]
1000c3ed0:     	stp	q0, q1, [x8]
1000c3ed4:     	ldp	q0, q1, [sp, #208]
1000c3ed8:     	stp	q0, q1, [x8, #32]
1000c3edc:     	ldur	x8, [x29, #-96]
1000c3ee0:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 8ul, false>(char const*)+0x26c>
1000c3ee4:     	ldr	x9, [x9, #392]
1000c3ee8:     	ldr	x9, [x9]
1000c3eec:     	cmp	x9, x8
1000c3ef0:     	b.ne	0x1000c3f14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c3ef4:     	ldp	x29, x30, [sp, #400]
1000c3ef8:     	ldp	x20, x19, [sp, #384]
1000c3efc:     	ldp	x22, x21, [sp, #368]
1000c3f00:     	ldp	x24, x23, [sp, #352]
1000c3f04:     	ldp	x26, x25, [sp, #336]
1000c3f08:     	ldp	x28, x27, [sp, #320]
1000c3f0c:     	add	sp, sp, #416
1000c3f10:     	ret
1000c3f14:     	bl	0x100163694 <_strcmp+0x100163694>

