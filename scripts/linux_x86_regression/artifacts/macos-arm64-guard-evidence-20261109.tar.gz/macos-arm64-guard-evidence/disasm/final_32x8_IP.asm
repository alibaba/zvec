00000001000d6548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d6548:     	stp	x28, x27, [sp, #-96]!
1000d654c:     	stp	x26, x25, [sp, #16]
1000d6550:     	stp	x24, x23, [sp, #32]
1000d6554:     	stp	x22, x21, [sp, #48]
1000d6558:     	stp	x20, x19, [sp, #64]
1000d655c:     	stp	x29, x30, [sp, #80]
1000d6560:     	add	x29, sp, #80
1000d6564:     	sub	sp, sp, #1488
1000d6568:     	str	x3, [sp]
1000d656c:     	mov	x20, x1
1000d6570:     	mov	x22, x0
1000d6574:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x284>
1000d6578:     	ldr	x8, [x8, #392]
1000d657c:     	ldr	x8, [x8]
1000d6580:     	stur	x8, [x29, #-96]
1000d6584:     	lsl	x8, x2, #2
1000d6588:     	and	x19, x8, #0xfffffffffffffff8
1000d658c:     	add	x0, sp, #448
1000d6590:     	mov	w1, #1024
1000d6594:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d6598:     	cbz	x19, 0x1000d6ac4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d659c:     	add	x8, x20, x19
1000d65a0:     	str	x8, [sp, #8]
1000d65a4:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d65a8:     	add	x9, x9, #1980
1000d65ac:     	mov	x10, #0
1000d65b0:     	ldp	w8, w11, [x20]
1000d65b4:     	ubfx	x13, x8, #8, #4
1000d65b8:     	ubfx	x12, x8, #16, #4
1000d65bc:     	stp	x12, x13, [sp, #432]
1000d65c0:     	ubfx	x15, x8, #24, #4
1000d65c4:     	ldp	w12, w13, [x20, #8]
1000d65c8:     	and	x14, x8, #0xf
1000d65cc:     	stp	x14, x15, [sp, #416]
1000d65d0:     	ubfx	x15, x8, #4, #4
1000d65d4:     	ubfx	x14, x8, #12, #4
1000d65d8:     	stp	x14, x15, [sp, #400]
1000d65dc:     	ubfx	x14, x8, #20, #4
1000d65e0:     	lsr	x8, x8, #28
1000d65e4:     	stp	x8, x14, [sp, #384]
1000d65e8:     	and	x8, x11, #0xf
1000d65ec:     	str	x8, [sp, #376]
1000d65f0:     	ubfx	x8, x11, #8, #4
1000d65f4:     	str	x8, [sp, #368]
1000d65f8:     	ubfx	x8, x11, #16, #4
1000d65fc:     	str	x8, [sp, #360]
1000d6600:     	ubfx	x8, x11, #24, #4
1000d6604:     	str	x8, [sp, #352]
1000d6608:     	ubfx	x8, x11, #4, #4
1000d660c:     	str	x8, [sp, #344]
1000d6610:     	ubfx	x8, x11, #12, #4
1000d6614:     	str	x8, [sp, #336]
1000d6618:     	ubfx	x8, x11, #20, #4
1000d661c:     	str	x8, [sp, #328]
1000d6620:     	lsr	x8, x11, #28
1000d6624:     	str	x8, [sp, #320]
1000d6628:     	and	x11, x12, #0xf
1000d662c:     	ubfx	x8, x12, #8, #4
1000d6630:     	stp	x8, x11, [sp, #304]
1000d6634:     	ubfx	x11, x12, #16, #4
1000d6638:     	ubfx	x8, x12, #24, #4
1000d663c:     	stp	x8, x11, [sp, #288]
1000d6640:     	ubfx	x11, x12, #4, #4
1000d6644:     	ubfx	x8, x12, #12, #4
1000d6648:     	stp	x8, x11, [sp, #272]
1000d664c:     	ubfx	x11, x12, #20, #4
1000d6650:     	lsr	x8, x12, #28
1000d6654:     	stp	x8, x11, [sp, #256]
1000d6658:     	and	x11, x13, #0xf
1000d665c:     	ubfx	x8, x13, #8, #4
1000d6660:     	stp	x8, x11, [sp, #240]
1000d6664:     	ubfx	x11, x13, #16, #4
1000d6668:     	ubfx	x8, x13, #24, #4
1000d666c:     	stp	x8, x11, [sp, #224]
1000d6670:     	ubfx	x11, x13, #4, #4
1000d6674:     	ubfx	x8, x13, #12, #4
1000d6678:     	stp	x8, x11, [sp, #208]
1000d667c:     	ubfx	x11, x13, #20, #4
1000d6680:     	lsr	x8, x13, #28
1000d6684:     	stp	x8, x11, [sp, #192]
1000d6688:     	ldp	w8, w11, [x20, #16]
1000d668c:     	and	x13, x8, #0xf
1000d6690:     	ubfx	x12, x8, #8, #4
1000d6694:     	stp	x12, x13, [sp, #176]
1000d6698:     	ubfx	x13, x8, #16, #4
1000d669c:     	ubfx	x12, x8, #24, #4
1000d66a0:     	stp	x12, x13, [sp, #160]
1000d66a4:     	ubfx	x13, x8, #4, #4
1000d66a8:     	ubfx	x12, x8, #12, #4
1000d66ac:     	stp	x12, x13, [sp, #144]
1000d66b0:     	ubfx	x12, x8, #20, #4
1000d66b4:     	lsr	x8, x8, #28
1000d66b8:     	stp	x8, x12, [sp, #128]
1000d66bc:     	and	x8, x11, #0xf
1000d66c0:     	str	x8, [sp, #120]
1000d66c4:     	ubfx	x8, x11, #8, #4
1000d66c8:     	str	x8, [sp, #112]
1000d66cc:     	ubfx	x8, x11, #16, #4
1000d66d0:     	str	x8, [sp, #104]
1000d66d4:     	ubfx	x8, x11, #24, #4
1000d66d8:     	str	x8, [sp, #96]
1000d66dc:     	ubfx	x8, x11, #4, #4
1000d66e0:     	str	x8, [sp, #88]
1000d66e4:     	ubfx	x8, x11, #12, #4
1000d66e8:     	str	x8, [sp, #80]
1000d66ec:     	ubfx	x8, x11, #20, #4
1000d66f0:     	str	x8, [sp, #72]
1000d66f4:     	lsr	x8, x11, #28
1000d66f8:     	str	x8, [sp, #64]
1000d66fc:     	ldp	w13, w2, [x20, #24]
1000d6700:     	and	x11, x13, #0xf
1000d6704:     	ubfx	x8, x13, #8, #4
1000d6708:     	stp	x8, x11, [sp, #48]
1000d670c:     	ubfx	x11, x13, #16, #4
1000d6710:     	ubfx	x8, x13, #24, #4
1000d6714:     	stp	x8, x11, [sp, #32]
1000d6718:     	ubfx	x8, x13, #4, #4
1000d671c:     	stp	x20, x8, [sp, #16]
1000d6720:     	ubfx	x11, x13, #12, #4
1000d6724:     	ubfx	x12, x13, #20, #4
1000d6728:     	lsr	x13, x13, #28
1000d672c:     	and	x14, x2, #0xf
1000d6730:     	ubfx	x21, x2, #8, #4
1000d6734:     	ubfx	x15, x2, #16, #4
1000d6738:     	ubfx	x16, x2, #24, #4
1000d673c:     	ubfx	x17, x2, #4, #4
1000d6740:     	ubfx	x0, x2, #12, #4
1000d6744:     	ubfx	x1, x2, #20, #4
1000d6748:     	lsr	x2, x2, #28
1000d674c:     	ldr	w25, [x22, x10]
1000d6750:     	lsl	w3, w25, #4
1000d6754:     	and	x3, x3, #0xf0
1000d6758:     	add	x3, x9, x3
1000d675c:     	ldr	x8, [sp, #416]
1000d6760:     	ldrsb	w26, [x3, x8]
1000d6764:     	lsr	x4, x25, #4
1000d6768:     	and	x4, x4, #0xf0
1000d676c:     	add	x4, x9, x4
1000d6770:     	ldr	x8, [sp, #440]
1000d6774:     	ldrsb	w27, [x4, x8]
1000d6778:     	lsr	x5, x25, #12
1000d677c:     	and	x5, x5, #0xf0
1000d6780:     	add	x5, x9, x5
1000d6784:     	ldr	x8, [sp, #432]
1000d6788:     	ldrsb	w28, [x5, x8]
1000d678c:     	lsr	x6, x25, #20
1000d6790:     	and	x6, x6, #0xf0
1000d6794:     	add	x7, x9, x6
1000d6798:     	ldr	x8, [sp, #424]
1000d679c:     	ldrsb	w30, [x7, x8]
1000d67a0:     	and	x6, x25, #0xf0
1000d67a4:     	add	x6, x9, x6
1000d67a8:     	ldr	x8, [sp, #408]
1000d67ac:     	ldrsb	w19, [x6, x8]
1000d67b0:     	lsr	x23, x25, #8
1000d67b4:     	and	x23, x23, #0xf0
1000d67b8:     	add	x23, x9, x23
1000d67bc:     	ldp	x20, x8, [sp, #392]
1000d67c0:     	ldrsb	w8, [x23, x8]
1000d67c4:     	lsr	x24, x25, #16
1000d67c8:     	and	x24, x24, #0xf0
1000d67cc:     	add	x24, x9, x24
1000d67d0:     	ldrsb	w20, [x24, x20]
1000d67d4:     	lsr	x25, x25, #24
1000d67d8:     	and	x25, x25, #0xf0
1000d67dc:     	add	x25, x9, x25
1000d67e0:     	add	w26, w26, w27
1000d67e4:     	ldr	x27, [sp, #384]
1000d67e8:     	ldrsb	w27, [x25, x27]
1000d67ec:     	add	w26, w26, w28
1000d67f0:     	add	w26, w26, w30
1000d67f4:     	add	w19, w26, w19
1000d67f8:     	add	w8, w19, w8
1000d67fc:     	add	w8, w8, w20
1000d6800:     	add	w8, w8, w27
1000d6804:     	scvtf	s0, w8
1000d6808:     	ldp	x19, x8, [sp, #368]
1000d680c:     	ldrsb	w8, [x3, x8]
1000d6810:     	ldrsb	w19, [x4, x19]
1000d6814:     	ldp	x26, x20, [sp, #352]
1000d6818:     	ldrsb	w20, [x5, x20]
1000d681c:     	ldrsb	w26, [x7, x26]
1000d6820:     	ldp	x28, x27, [sp, #336]
1000d6824:     	ldrsb	w27, [x6, x27]
1000d6828:     	ldrsb	w28, [x23, x28]
1000d682c:     	add	w8, w8, w19
1000d6830:     	ldr	x19, [sp, #328]
1000d6834:     	ldrsb	w19, [x24, x19]
1000d6838:     	add	w8, w8, w20
1000d683c:     	add	w8, w8, w26
1000d6840:     	ldr	x20, [sp, #320]
1000d6844:     	ldrsb	w20, [x25, x20]
1000d6848:     	add	w8, w8, w27
1000d684c:     	add	w8, w8, w28
1000d6850:     	add	w8, w8, w19
1000d6854:     	add	w8, w8, w20
1000d6858:     	scvtf	s1, w8
1000d685c:     	ldp	x19, x8, [sp, #304]
1000d6860:     	ldrsb	w8, [x3, x8]
1000d6864:     	ldrsb	w19, [x4, x19]
1000d6868:     	ldp	x26, x20, [sp, #288]
1000d686c:     	ldrsb	w20, [x5, x20]
1000d6870:     	ldrsb	w26, [x7, x26]
1000d6874:     	ldr	x27, [sp, #280]
1000d6878:     	ldrsb	w27, [x6, x27]
1000d687c:     	add	w8, w8, w19
1000d6880:     	ldr	x19, [sp, #272]
1000d6884:     	ldrsb	w19, [x23, x19]
1000d6888:     	add	w8, w8, w20
1000d688c:     	ldr	x20, [sp, #264]
1000d6890:     	ldrsb	w20, [x24, x20]
1000d6894:     	add	w8, w8, w26
1000d6898:     	ldr	x26, [sp, #256]
1000d689c:     	ldrsb	w26, [x25, x26]
1000d68a0:     	add	w8, w8, w27
1000d68a4:     	add	w8, w8, w19
1000d68a8:     	add	w8, w8, w20
1000d68ac:     	add	w8, w8, w26
1000d68b0:     	scvtf	s2, w8
1000d68b4:     	ldp	x19, x8, [sp, #240]
1000d68b8:     	ldrsb	w8, [x3, x8]
1000d68bc:     	ldrsb	w19, [x4, x19]
1000d68c0:     	ldp	x26, x20, [sp, #224]
1000d68c4:     	ldrsb	w20, [x5, x20]
1000d68c8:     	ldrsb	w26, [x7, x26]
1000d68cc:     	add	w8, w8, w19
1000d68d0:     	ldr	x19, [sp, #216]
1000d68d4:     	ldrsb	w19, [x6, x19]
1000d68d8:     	add	w8, w8, w20
1000d68dc:     	ldr	x20, [sp, #208]
1000d68e0:     	ldrsb	w20, [x23, x20]
1000d68e4:     	add	w8, w8, w26
1000d68e8:     	ldr	x26, [sp, #200]
1000d68ec:     	ldrsb	w26, [x24, x26]
1000d68f0:     	add	w8, w8, w19
1000d68f4:     	ldr	x19, [sp, #192]
1000d68f8:     	ldrsb	w19, [x25, x19]
1000d68fc:     	add	w8, w8, w20
1000d6900:     	add	w8, w8, w26
1000d6904:     	add	w8, w8, w19
1000d6908:     	scvtf	s3, w8
1000d690c:     	ldp	x19, x8, [sp, #176]
1000d6910:     	ldrsb	w8, [x3, x8]
1000d6914:     	ldrsb	w19, [x4, x19]
1000d6918:     	ldp	x26, x20, [sp, #160]
1000d691c:     	ldrsb	w20, [x5, x20]
1000d6920:     	ldrsb	w26, [x7, x26]
1000d6924:     	add	w8, w8, w19
1000d6928:     	add	w8, w8, w20
1000d692c:     	ldp	x20, x19, [sp, #144]
1000d6930:     	ldrsb	w19, [x6, x19]
1000d6934:     	ldrsb	w20, [x23, x20]
1000d6938:     	add	w8, w8, w26
1000d693c:     	add	w8, w8, w19
1000d6940:     	ldp	x26, x19, [sp, #128]
1000d6944:     	ldrsb	w19, [x24, x19]
1000d6948:     	ldrsb	w26, [x25, x26]
1000d694c:     	add	w8, w8, w20
1000d6950:     	add	w8, w8, w19
1000d6954:     	add	w8, w8, w26
1000d6958:     	scvtf	s4, w8
1000d695c:     	ldp	x19, x8, [sp, #112]
1000d6960:     	ldrsb	w8, [x3, x8]
1000d6964:     	ldrsb	w19, [x4, x19]
1000d6968:     	ldr	x20, [sp, #104]
1000d696c:     	ldrsb	w20, [x5, x20]
1000d6970:     	add	w8, w8, w19
1000d6974:     	add	w8, w8, w20
1000d6978:     	ldp	x20, x19, [sp, #88]
1000d697c:     	ldrsb	w19, [x7, x19]
1000d6980:     	ldrsb	w20, [x6, x20]
1000d6984:     	add	w8, w8, w19
1000d6988:     	add	w8, w8, w20
1000d698c:     	ldp	x20, x19, [sp, #72]
1000d6990:     	ldrsb	w19, [x23, x19]
1000d6994:     	ldrsb	w20, [x24, x20]
1000d6998:     	add	w8, w8, w19
1000d699c:     	add	w8, w8, w20
1000d69a0:     	ldr	x19, [sp, #64]
1000d69a4:     	ldrsb	w19, [x25, x19]
1000d69a8:     	add	w8, w8, w19
1000d69ac:     	scvtf	s5, w8
1000d69b0:     	ldp	x19, x8, [sp, #48]
1000d69b4:     	ldrsb	w8, [x3, x8]
1000d69b8:     	ldrsb	w19, [x4, x19]
1000d69bc:     	ldp	x26, x20, [sp, #32]
1000d69c0:     	ldrsb	w20, [x5, x20]
1000d69c4:     	ldrsb	w26, [x7, x26]
1000d69c8:     	add	w8, w8, w19
1000d69cc:     	ldr	x19, [sp, #24]
1000d69d0:     	ldrsb	w19, [x6, x19]
1000d69d4:     	add	w8, w8, w20
1000d69d8:     	ldrsb	w20, [x23, x11]
1000d69dc:     	add	w8, w8, w26
1000d69e0:     	ldrsb	w26, [x24, x12]
1000d69e4:     	add	w8, w8, w19
1000d69e8:     	add	w8, w8, w20
1000d69ec:     	add	w8, w8, w26
1000d69f0:     	ldrsb	w19, [x25, x13]
1000d69f4:     	add	w8, w8, w19
1000d69f8:     	scvtf	s6, w8
1000d69fc:     	ldrsb	w8, [x3, x14]
1000d6a00:     	ldrsb	w3, [x4, x21]
1000d6a04:     	ldrsb	w4, [x5, x15]
1000d6a08:     	add	w8, w8, w3
1000d6a0c:     	add	w8, w8, w4
1000d6a10:     	ldrsb	w3, [x7, x16]
1000d6a14:     	ldrsb	w4, [x6, x17]
1000d6a18:     	add	w8, w8, w3
1000d6a1c:     	add	w8, w8, w4
1000d6a20:     	ldrsb	w3, [x23, x0]
1000d6a24:     	add	x5, sp, #448
1000d6a28:     	ldrsb	w4, [x24, x1]
1000d6a2c:     	add	w8, w8, w3
1000d6a30:     	add	w8, w8, w4
1000d6a34:     	ldrsb	w3, [x25, x2]
1000d6a38:     	add	w8, w8, w3
1000d6a3c:     	scvtf	s7, w8
1000d6a40:     	add	x8, x5, x10
1000d6a44:     	ldr	s16, [x8]
1000d6a48:     	fadd	s0, s16, s0
1000d6a4c:     	str	s0, [x8]
1000d6a50:     	ldr	s0, [x8, #128]
1000d6a54:     	fadd	s0, s0, s1
1000d6a58:     	str	s0, [x8, #128]
1000d6a5c:     	ldr	s0, [x8, #256]
1000d6a60:     	fadd	s0, s0, s2
1000d6a64:     	str	s0, [x8, #256]
1000d6a68:     	ldr	s0, [x8, #384]
1000d6a6c:     	fadd	s0, s0, s3
1000d6a70:     	str	s0, [x8, #384]
1000d6a74:     	ldr	s0, [x8, #512]
1000d6a78:     	fadd	s0, s0, s4
1000d6a7c:     	str	s0, [x8, #512]
1000d6a80:     	ldr	s0, [x8, #640]
1000d6a84:     	fadd	s0, s0, s5
1000d6a88:     	str	s0, [x8, #640]
1000d6a8c:     	ldr	s0, [x8, #768]
1000d6a90:     	fadd	s0, s0, s6
1000d6a94:     	ldr	s1, [x8, #896]
1000d6a98:     	fadd	s1, s1, s7
1000d6a9c:     	str	s0, [x8, #768]
1000d6aa0:     	str	s1, [x8, #896]
1000d6aa4:     	add	x10, x10, #4
1000d6aa8:     	cmp	x10, #128
1000d6aac:     	b.ne	0x1000d674c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d6ab0:     	add	x22, x22, #128
1000d6ab4:     	ldp	x8, x20, [sp, #8]
1000d6ab8:     	add	x20, x20, #32
1000d6abc:     	cmp	x20, x8
1000d6ac0:     	b.ne	0x1000d65ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d6ac4:     	add	x1, sp, #448
1000d6ac8:     	ldr	x0, [sp]
1000d6acc:     	mov	w2, #1024
1000d6ad0:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d6ad4:     	ldur	x8, [x29, #-96]
1000d6ad8:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0x220>
1000d6adc:     	ldr	x9, [x9, #392]
1000d6ae0:     	ldr	x9, [x9]
1000d6ae4:     	cmp	x9, x8
1000d6ae8:     	b.ne	0x1000d6b0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d6aec:     	add	sp, sp, #1488
1000d6af0:     	ldp	x29, x30, [sp, #80]
1000d6af4:     	ldp	x20, x19, [sp, #64]
1000d6af8:     	ldp	x22, x21, [sp, #48]
1000d6afc:     	ldp	x24, x23, [sp, #32]
1000d6b00:     	ldp	x26, x25, [sp, #16]
1000d6b04:     	ldp	x28, x27, [sp], #96
1000d6b08:     	ret
1000d6b0c:     	bl	0x100163694 <_strcmp+0x100163694>

