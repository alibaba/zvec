
bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100005a28 <void kernel<float, 1ul, 1ul, false>(float const*, float const*, unsigned long, float*)>:
100005a28:     	b	0x100005ac8 <zvec::turbo::DistanceMatrix<float, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(float const*, float const*, unsigned long, float*)>

0000000100005c64 <void kernel<float, 1ul, 1ul, true>(float const*, float const*, unsigned long, float*)>:
100005c64:     	b	0x100005c68 <zvec::turbo::DistanceMatrix<float, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(float const*, float const*, unsigned long, float*)>

00000001000db420 <void kernel<double, 1ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000db420:     	b	0x1000db424 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)>

00000001000db424 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)>:
1000db424:     	sub	sp, sp, #80
1000db428:     	stp	x22, x21, [sp, #32]
1000db42c:     	stp	x20, x19, [sp, #48]
1000db430:     	stp	x29, x30, [sp, #64]
1000db434:     	add	x29, sp, #64
1000db438:     	mov	x19, x3
1000db43c:     	mov	x20, x2
1000db440:     	mov	x21, x1
1000db444:     	mov	x22, x0
1000db448:     	adrp	x8, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x84>
1000db44c:     	ldr	x8, [x8, #48]
1000db450:     	ldaprb	w8, [x8]
1000db454:     	tbz	w8, #0, 0x1000db4a0 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0x7c>
1000db458:     	stp	x21, x22, [sp, #16]
1000db45c:     	stp	x19, x20, [sp]
1000db460:     	adrp	x8, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x9c>
1000db464:     	ldr	x8, [x8, #224]
1000db468:     	ldr	x0, [x8, #24]
1000db46c:     	cbz	x0, 0x1000db4f8 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0xd4>
1000db470:     	ldr	x8, [x0]
1000db474:     	ldr	x8, [x8, #48]
1000db478:     	add	x1, sp, #24
1000db47c:     	add	x2, sp, #16
1000db480:     	add	x3, sp, #8
1000db484:     	mov	x4, sp
1000db488:     	blr	x8
1000db48c:     	ldp	x29, x30, [sp, #64]
1000db490:     	ldp	x20, x19, [sp, #48]
1000db494:     	ldp	x22, x21, [sp, #32]
1000db498:     	add	sp, sp, #80
1000db49c:     	ret
1000db4a0:     	adrp	x0, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0xdc>
1000db4a4:     	ldr	x0, [x0, #48]
1000db4a8:     	bl	0x100163670 <_strcmp+0x100163670>
1000db4ac:     	cbz	w0, 0x1000db458 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000db4b0:     	adrp	x8, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0xec>
1000db4b4:     	ldr	x8, [x8, #224]
1000db4b8:     	mov	w0, #0
1000db4bc:     	mov	w1, #8
1000db4c0:     	mov	w2, #8
1000db4c4:     	mov	w3, #0
1000db4c8:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
1000db4cc:     	adrp	x0, 0x100005000 <void run<double, 1ul, 1ul, true>(char const*)+0x730>
1000db4d0:     	add	x0, x0, #3000
1000db4d4:     	adrp	x1, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x110>
1000db4d8:     	ldr	x1, [x1, #224]
1000db4dc:     	adrp	x2, 0x100000000 <void run<double, 1ul, 1ul, true>(char const*)+0x72c>
1000db4e0:     	add	x2, x2, #0
1000db4e4:     	bl	0x100163640 <_strcmp+0x100163640>
1000db4e8:     	adrp	x0, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x124>
1000db4ec:     	ldr	x0, [x0, #48]
1000db4f0:     	bl	0x10016367c <_strcmp+0x10016367c>
1000db4f4:     	b	0x1000db458 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000db4f8:     	bl	0x100005c04 <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000db4fc:     	mov	x19, x0
1000db500:     	adrp	x0, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x13c>
1000db504:     	ldr	x0, [x0, #48]
1000db508:     	bl	0x100163664 <_strcmp+0x100163664>
1000db50c:     	mov	x0, x19
1000db510:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

00000001000db514 <void kernel<double, 1ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000db514:     	b	0x1000db518 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)>

00000001000db518 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)>:
1000db518:     	sub	sp, sp, #80
1000db51c:     	stp	x22, x21, [sp, #32]
1000db520:     	stp	x20, x19, [sp, #48]
1000db524:     	stp	x29, x30, [sp, #64]
1000db528:     	add	x29, sp, #64
1000db52c:     	mov	x19, x3
1000db530:     	mov	x20, x2
1000db534:     	mov	x21, x1
1000db538:     	mov	x22, x0
1000db53c:     	adrp	x8, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x178>
1000db540:     	ldr	x8, [x8, #56]
1000db544:     	ldaprb	w8, [x8]
1000db548:     	tbz	w8, #0, 0x1000db594 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0x7c>
1000db54c:     	stp	x21, x22, [sp, #16]
1000db550:     	stp	x19, x20, [sp]
1000db554:     	adrp	x8, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x190>
1000db558:     	ldr	x8, [x8, #232]
1000db55c:     	ldr	x0, [x8, #24]
1000db560:     	cbz	x0, 0x1000db5ec <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0xd4>
1000db564:     	ldr	x8, [x0]
1000db568:     	ldr	x8, [x8, #48]
1000db56c:     	add	x1, sp, #24
1000db570:     	add	x2, sp, #16
1000db574:     	add	x3, sp, #8
1000db578:     	mov	x4, sp
1000db57c:     	blr	x8
1000db580:     	ldp	x29, x30, [sp, #64]
1000db584:     	ldp	x20, x19, [sp, #48]
1000db588:     	ldp	x22, x21, [sp, #32]
1000db58c:     	add	sp, sp, #80
1000db590:     	ret
1000db594:     	adrp	x0, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x1d0>
1000db598:     	ldr	x0, [x0, #56]
1000db59c:     	bl	0x100163670 <_strcmp+0x100163670>
1000db5a0:     	cbz	w0, 0x1000db54c <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000db5a4:     	adrp	x8, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x1e0>
1000db5a8:     	ldr	x8, [x8, #232]
1000db5ac:     	mov	w0, #2
1000db5b0:     	mov	w1, #8
1000db5b4:     	mov	w2, #8
1000db5b8:     	mov	w3, #0
1000db5bc:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
1000db5c0:     	adrp	x0, 0x100005000 <void run<double, 1ul, 1ul, true>(char const*)+0x824>
1000db5c4:     	add	x0, x0, #3000
1000db5c8:     	adrp	x1, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x204>
1000db5cc:     	ldr	x1, [x1, #232]
1000db5d0:     	adrp	x2, 0x100000000 <void run<double, 1ul, 1ul, true>(char const*)+0x820>
1000db5d4:     	add	x2, x2, #0
1000db5d8:     	bl	0x100163640 <_strcmp+0x100163640>
1000db5dc:     	adrp	x0, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x218>
1000db5e0:     	ldr	x0, [x0, #56]
1000db5e4:     	bl	0x10016367c <_strcmp+0x10016367c>
1000db5e8:     	b	0x1000db54c <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000db5ec:     	bl	0x100005c04 <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000db5f0:     	mov	x19, x0
1000db5f4:     	adrp	x0, 0x10016c000 <void run<double, 2ul, 1ul, false>(char const*)+0x230>
1000db5f8:     	ldr	x0, [x0, #56]
1000db5fc:     	bl	0x100163664 <_strcmp+0x100163664>
1000db600:     	mov	x0, x19
1000db604:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

00000001000dd0fc <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000dd0fc:     	cbz	x2, 0x1000dd134 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x38>
1000dd100:     	ld1r.2d	{ v0 }, [x1]
1000dd104:     	ldr	q1, [x0]
1000dd108:     	fsub.2d	v0, v1, v0
1000dd10c:     	fmul.2d	v0, v0, v0
1000dd110:     	fcvtn	v0.2s, v0.2d
1000dd114:     	str	d0, [x3]
1000dd118:     	subs	x10, x2, #1
1000dd11c:     	b.eq	0x1000dd288 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x18c>
1000dd120:     	cmp	x2, #9
1000dd124:     	b.hs	0x1000dd13c <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x40>
1000dd128:     	mov	w8, #1
1000dd12c:     	mov	x9, x1
1000dd130:     	b	0x1000dd258 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x15c>
1000dd134:     	str	xzr, [x3]
1000dd138:     	ret
1000dd13c:     	and	x11, x10, #0xfffffffffffffff8
1000dd140:     	add	x9, x1, x11, lsl #3
1000dd144:     	orr	x8, x11, #0x1
1000dd148:     	mov	s1, v0[1]
1000dd14c:     	add	x12, x0, #80
1000dd150:     	add	x13, x1, #40
1000dd154:     	mov	x14, x11
1000dd158:     	add	x0, x0, x11, lsl #4
1000dd15c:     	sub	x15, x12, #64
1000dd160:     	sub	x16, x12, #32
1000dd164:     	ldp	q2, q3, [x13, #-32]
1000dd168:     	ld2.2d	{ v4, v5 }, [x15]
1000dd16c:     	ldp	q6, q7, [x13], #64
1000dd170:     	ld2.2d	{ v16, v17 }, [x16]
1000dd174:     	mov	x15, x12
1000dd178:     	ld2.2d	{ v18, v19 }, [x15], #32
1000dd17c:     	ld2.2d	{ v20, v21 }, [x15]
1000dd180:     	fsub.2d	v22, v4, v2
1000dd184:     	fsub.2d	v23, v16, v3
1000dd188:     	fsub.2d	v24, v18, v6
1000dd18c:     	fsub.2d	v25, v20, v7
1000dd190:     	fmul.2d	v22, v22, v22
1000dd194:     	fmul.2d	v23, v23, v23
1000dd198:     	fmul.2d	v24, v24, v24
1000dd19c:     	fmul.2d	v25, v25, v25
1000dd1a0:     	fcvtn	v22.2s, v22.2d
1000dd1a4:     	mov	s26, v22[1]
1000dd1a8:     	fcvtn	v23.2s, v23.2d
1000dd1ac:     	mov	s27, v23[1]
1000dd1b0:     	fcvtn	v24.2s, v24.2d
1000dd1b4:     	mov	s28, v24[1]
1000dd1b8:     	fcvtn	v25.2s, v25.2d
1000dd1bc:     	mov	s29, v25[1]
1000dd1c0:     	fsub.2d	v2, v5, v2
1000dd1c4:     	fsub.2d	v3, v17, v3
1000dd1c8:     	fsub.2d	v4, v19, v6
1000dd1cc:     	fsub.2d	v5, v21, v7
1000dd1d0:     	fmul.2d	v2, v2, v2
1000dd1d4:     	fmul.2d	v3, v3, v3
1000dd1d8:     	fmul.2d	v4, v4, v4
1000dd1dc:     	fmul.2d	v5, v5, v5
1000dd1e0:     	fcvtn	v2.2s, v2.2d
1000dd1e4:     	mov	s6, v2[1]
1000dd1e8:     	fcvtn	v3.2s, v3.2d
1000dd1ec:     	mov	s7, v3[1]
1000dd1f0:     	fcvtn	v4.2s, v4.2d
1000dd1f4:     	mov	s16, v4[1]
1000dd1f8:     	fcvtn	v5.2s, v5.2d
1000dd1fc:     	mov	s17, v5[1]
1000dd200:     	fadd	s1, s1, s2
1000dd204:     	fadd	s1, s1, s6
1000dd208:     	fadd	s1, s1, s3
1000dd20c:     	fadd	s1, s1, s7
1000dd210:     	fadd	s1, s1, s4
1000dd214:     	fadd	s1, s1, s16
1000dd218:     	fadd	s1, s1, s5
1000dd21c:     	fadd	s1, s1, s17
1000dd220:     	fadd	s0, s0, s22
1000dd224:     	fadd	s0, s0, s26
1000dd228:     	fadd	s0, s0, s23
1000dd22c:     	fadd	s0, s0, s27
1000dd230:     	fadd	s0, s0, s24
1000dd234:     	fadd	s0, s0, s28
1000dd238:     	fadd	s0, s0, s25
1000dd23c:     	fadd	s0, s0, s29
1000dd240:     	add	x12, x12, #128
1000dd244:     	subs	x14, x14, #8
1000dd248:     	b.ne	0x1000dd15c <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x60>
1000dd24c:     	mov.s	v0[1], v1[0]
1000dd250:     	cmp	x10, x11
1000dd254:     	b.eq	0x1000dd284 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x188>
1000dd258:     	add	x9, x9, #8
1000dd25c:     	add	x10, x0, #16
1000dd260:     	sub	x8, x2, x8
1000dd264:     	ldr	q1, [x10], #16
1000dd268:     	ld1r.2d	{ v2 }, [x9], #8
1000dd26c:     	fsub.2d	v1, v1, v2
1000dd270:     	fmul.2d	v1, v1, v1
1000dd274:     	fcvtn	v1.2s, v1.2d
1000dd278:     	fadd.2s	v0, v0, v1
1000dd27c:     	subs	x8, x8, #1
1000dd280:     	b.ne	0x1000dd264 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x168>
1000dd284:     	str	d0, [x3]
1000dd288:     	ret

00000001000dd28c <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000dd28c:     	cbz	x2, 0x1000dd2e4 <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x58>
1000dd290:     	ldr	d0, [x1]
1000dd294:     	ldr	q1, [x0]
1000dd298:     	fmul.2d	v0, v1, v0[0]
1000dd29c:     	fcvtn	v0.2s, v0.2d
1000dd2a0:     	fneg.2s	v0, v0
1000dd2a4:     	str	d0, [x3]
1000dd2a8:     	cmp	x2, #1
1000dd2ac:     	b.eq	0x1000dd2e0 <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x54>
1000dd2b0:     	add	x8, x1, #8
1000dd2b4:     	add	x9, x0, #16
1000dd2b8:     	lsl	x10, x2, #3
1000dd2bc:     	sub	x10, x10, #8
1000dd2c0:     	fcvtl	v0.2d, v0.2s
1000dd2c4:     	ldr	q1, [x9], #16
1000dd2c8:     	ld1r.2d	{ v2 }, [x8], #8
1000dd2cc:     	fmls.2d	v0, v2, v1
1000dd2d0:     	fcvtn	v0.2s, v0.2d
1000dd2d4:     	subs	x10, x10, #8
1000dd2d8:     	b.ne	0x1000dd2c0 <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x34>
1000dd2dc:     	str	d0, [x3]
1000dd2e0:     	ret
1000dd2e4:     	str	xzr, [x3]
1000dd2e8:     	ret

00000001000df558 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000df558:     	cbz	x2, 0x1000df5a8 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x50>
1000df55c:     	ldr	q0, [x1]
1000df560:     	dup.2d	v1, v0[1]
1000df564:     	dup.2d	v0, v0[0]
1000df568:     	ldr	q2, [x0]
1000df56c:     	fsub.2d	v0, v2, v0
1000df570:     	fsub.2d	v1, v2, v1
1000df574:     	fmul.2d	v1, v1, v1
1000df578:     	fmul.2d	v0, v0, v0
1000df57c:     	fcvtn	v0.2s, v0.2d
1000df580:     	fcvtn2	v0.4s, v1.2d
1000df584:     	str	q0, [x3]
1000df588:     	subs	x11, x2, #1
1000df58c:     	b.eq	0x1000df7fc <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x2a4>
1000df590:     	cmp	x2, #9
1000df594:     	b.hs	0x1000df5b0 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x58>
1000df598:     	mov	w8, #1
1000df59c:     	mov	x9, x1
1000df5a0:     	mov	x10, x0
1000df5a4:     	b	0x1000df7b8 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x260>
1000df5a8:     	stp	xzr, xzr, [x3]
1000df5ac:     	ret
1000df5b0:     	and	x12, x11, #0xfffffffffffffff8
1000df5b4:     	lsl	x8, x12, #4
1000df5b8:     	add	x9, x1, x8
1000df5bc:     	add	x10, x0, x8
1000df5c0:     	orr	x8, x12, #0x1
1000df5c4:     	mov	s1, v0[1]
1000df5c8:     	mov	s2, v0[2]
1000df5cc:     	mov	s3, v0[3]
1000df5d0:     	add	x13, x0, #80
1000df5d4:     	add	x14, x1, #80
1000df5d8:     	mov	x15, x12
1000df5dc:     	sub	x16, x13, #64
1000df5e0:     	ld2.2d	{ v6, v7 }, [x16]
1000df5e4:     	sub	x16, x13, #32
1000df5e8:     	ld2.2d	{ v16, v17 }, [x16]
1000df5ec:     	mov	x17, x13
1000df5f0:     	ld2.2d	{ v18, v19 }, [x17], #32
1000df5f4:     	sub	x16, x14, #64
1000df5f8:     	ld2.2d	{ v22, v23 }, [x16]
1000df5fc:     	sub	x16, x14, #32
1000df600:     	ld2.2d	{ v26, v27 }, [x16]
1000df604:     	mov	x16, x14
1000df608:     	ld2.2d	{ v24, v25 }, [x17]
1000df60c:     	ld2.2d	{ v28, v29 }, [x16], #32
1000df610:     	fsub.2d	v5, v6, v22
1000df614:     	fsub.2d	v4, v16, v26
1000df618:     	fsub.2d	v21, v6, v23
1000df61c:     	fsub.2d	v20, v16, v27
1000df620:     	fsub.2d	v30, v7, v22
1000df624:     	fsub.2d	v6, v7, v23
1000df628:     	fsub.2d	v7, v18, v28
1000df62c:     	fsub.2d	v22, v17, v26
1000df630:     	fsub.2d	v16, v17, v27
1000df634:     	ld2.2d	{ v26, v27 }, [x16]
1000df638:     	fsub.2d	v17, v18, v29
1000df63c:     	fsub.2d	v23, v19, v28
1000df640:     	fsub.2d	v18, v19, v29
1000df644:     	fsub.2d	v19, v24, v26
1000df648:     	fsub.2d	v28, v24, v27
1000df64c:     	fsub.2d	v29, v25, v26
1000df650:     	fsub.2d	v24, v25, v27
1000df654:     	fmul.2d	v6, v6, v6
1000df658:     	fcvtn	v6.2s, v6.2d
1000df65c:     	fadd	s3, s3, s6
1000df660:     	mov	s6, v6[1]
1000df664:     	fadd	s3, s3, s6
1000df668:     	fmul.2d	v6, v16, v16
1000df66c:     	fcvtn	v6.2s, v6.2d
1000df670:     	fadd	s3, s3, s6
1000df674:     	mov	s6, v6[1]
1000df678:     	fadd	s3, s3, s6
1000df67c:     	fmul.2d	v6, v18, v18
1000df680:     	fcvtn	v6.2s, v6.2d
1000df684:     	fadd	s3, s3, s6
1000df688:     	mov	s6, v6[1]
1000df68c:     	fadd	s3, s3, s6
1000df690:     	fmul.2d	v6, v30, v30
1000df694:     	fcvtn	v6.2s, v6.2d
1000df698:     	fadd	s1, s1, s6
1000df69c:     	mov	s6, v6[1]
1000df6a0:     	fadd	s1, s1, s6
1000df6a4:     	fmul.2d	v6, v22, v22
1000df6a8:     	fcvtn	v6.2s, v6.2d
1000df6ac:     	fadd	s1, s1, s6
1000df6b0:     	mov	s6, v6[1]
1000df6b4:     	fadd	s1, s1, s6
1000df6b8:     	fmul.2d	v6, v23, v23
1000df6bc:     	fcvtn	v6.2s, v6.2d
1000df6c0:     	fadd	s1, s1, s6
1000df6c4:     	mov	s6, v6[1]
1000df6c8:     	fadd	s1, s1, s6
1000df6cc:     	fmul.2d	v6, v24, v24
1000df6d0:     	fcvtn	v6.2s, v6.2d
1000df6d4:     	fadd	s3, s3, s6
1000df6d8:     	mov	s6, v6[1]
1000df6dc:     	fadd	s3, s3, s6
1000df6e0:     	fmul.2d	v6, v29, v29
1000df6e4:     	fcvtn	v6.2s, v6.2d
1000df6e8:     	fadd	s1, s1, s6
1000df6ec:     	mov	s6, v6[1]
1000df6f0:     	fadd	s1, s1, s6
1000df6f4:     	fmul.2d	v6, v21, v21
1000df6f8:     	fcvtn	v6.2s, v6.2d
1000df6fc:     	fadd	s2, s2, s6
1000df700:     	mov	s6, v6[1]
1000df704:     	fadd	s2, s2, s6
1000df708:     	fmul.2d	v6, v20, v20
1000df70c:     	fcvtn	v6.2s, v6.2d
1000df710:     	fadd	s2, s2, s6
1000df714:     	mov	s6, v6[1]
1000df718:     	fadd	s2, s2, s6
1000df71c:     	fmul.2d	v6, v17, v17
1000df720:     	fcvtn	v6.2s, v6.2d
1000df724:     	fadd	s2, s2, s6
1000df728:     	mov	s6, v6[1]
1000df72c:     	fadd	s2, s2, s6
1000df730:     	fmul.2d	v5, v5, v5
1000df734:     	fcvtn	v5.2s, v5.2d
1000df738:     	fadd	s0, s0, s5
1000df73c:     	mov	s5, v5[1]
1000df740:     	fadd	s0, s0, s5
1000df744:     	fmul.2d	v5, v28, v28
1000df748:     	fcvtn	v5.2s, v5.2d
1000df74c:     	fadd	s2, s2, s5
1000df750:     	mov	s5, v5[1]
1000df754:     	fadd	s2, s2, s5
1000df758:     	fmul.2d	v4, v4, v4
1000df75c:     	fcvtn	v4.2s, v4.2d
1000df760:     	fadd	s0, s0, s4
1000df764:     	mov	s4, v4[1]
1000df768:     	fadd	s0, s0, s4
1000df76c:     	fmul.2d	v4, v7, v7
1000df770:     	fcvtn	v4.2s, v4.2d
1000df774:     	fadd	s0, s0, s4
1000df778:     	mov	s4, v4[1]
1000df77c:     	fadd	s0, s0, s4
1000df780:     	fmul.2d	v4, v19, v19
1000df784:     	fcvtn	v4.2s, v4.2d
1000df788:     	fadd	s0, s0, s4
1000df78c:     	mov	s4, v4[1]
1000df790:     	fadd	s0, s0, s4
1000df794:     	add	x13, x13, #128
1000df798:     	add	x14, x14, #128
1000df79c:     	subs	x15, x15, #8
1000df7a0:     	b.ne	0x1000df5dc <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x84>
1000df7a4:     	mov.s	v0[1], v1[0]
1000df7a8:     	mov.s	v0[2], v2[0]
1000df7ac:     	mov.s	v0[3], v3[0]
1000df7b0:     	cmp	x11, x12
1000df7b4:     	b.eq	0x1000df7f8 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x2a0>
1000df7b8:     	add	x9, x9, #16
1000df7bc:     	add	x10, x10, #16
1000df7c0:     	sub	x8, x2, x8
1000df7c4:     	ldr	q1, [x9], #16
1000df7c8:     	dup.2d	v2, v1[1]
1000df7cc:     	dup.2d	v1, v1[0]
1000df7d0:     	ldr	q3, [x10], #16
1000df7d4:     	fsub.2d	v1, v3, v1
1000df7d8:     	fsub.2d	v2, v3, v2
1000df7dc:     	fmul.2d	v2, v2, v2
1000df7e0:     	fmul.2d	v1, v1, v1
1000df7e4:     	fcvtn	v1.2s, v1.2d
1000df7e8:     	fcvtn2	v1.4s, v2.2d
1000df7ec:     	fadd.4s	v0, v0, v1
1000df7f0:     	subs	x8, x8, #1
1000df7f4:     	b.ne	0x1000df7c4 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x26c>
1000df7f8:     	str	q0, [x3]
1000df7fc:     	ret

00000001000df800 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000df800:     	cbz	x2, 0x1000df864 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x64>
1000df804:     	ldr	q0, [x1]
1000df808:     	ldr	q1, [x0]
1000df80c:     	fmul.2d	v2, v1, v0[1]
1000df810:     	fmul.2d	v0, v1, v0[0]
1000df814:     	fcvtn	v0.2s, v0.2d
1000df818:     	fcvtn2	v0.4s, v2.2d
1000df81c:     	fneg.4s	v0, v0
1000df820:     	str	q0, [x3]
1000df824:     	subs	x8, x2, #1
1000df828:     	b.eq	0x1000df860 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x60>
1000df82c:     	add	x9, x0, #16
1000df830:     	add	x10, x1, #16
1000df834:     	fcvtl	v1.2d, v0.2s
1000df838:     	ldr	q2, [x10], #16
1000df83c:     	ldr	q3, [x9], #16
1000df840:     	fcvtl2	v4.2d, v0.4s
1000df844:     	fmls.2d	v4, v3, v2[1]
1000df848:     	fmls.2d	v1, v3, v2[0]
1000df84c:     	fcvtn	v0.2s, v1.2d
1000df850:     	fcvtn2	v0.4s, v4.2d
1000df854:     	subs	x8, x8, #1
1000df858:     	b.ne	0x1000df834 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x34>
1000df85c:     	str	q0, [x3]
1000df860:     	ret
1000df864:     	stp	xzr, xzr, [x3]
1000df868:     	ret

00000001000e2060 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000e2060:     	stp	d9, d8, [sp, #-16]!
1000e2064:     	cbz	x2, 0x1000e20a8 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x48>
1000e2068:     	ldp	q1, q0, [x0]
1000e206c:     	ld1r.2d	{ v2 }, [x1]
1000e2070:     	fsub.2d	v1, v1, v2
1000e2074:     	fsub.2d	v0, v0, v2
1000e2078:     	fmul.2d	v2, v0, v0
1000e207c:     	fmul.2d	v0, v1, v1
1000e2080:     	fcvtn	v0.2s, v0.2d
1000e2084:     	fcvtn2	v0.4s, v2.2d
1000e2088:     	str	q0, [x3]
1000e208c:     	subs	x10, x2, #1
1000e2090:     	b.eq	0x1000e22e0 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x280>
1000e2094:     	cmp	x2, #9
1000e2098:     	b.hs	0x1000e20b4 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x54>
1000e209c:     	mov	w8, #1
1000e20a0:     	mov	x9, x1
1000e20a4:     	b	0x1000e22a4 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x244>
1000e20a8:     	stp	xzr, xzr, [x3]
1000e20ac:     	ldp	d9, d8, [sp], #16
1000e20b0:     	ret
1000e20b4:     	and	x11, x10, #0xfffffffffffffff8
1000e20b8:     	add	x9, x1, x11, lsl #3
1000e20bc:     	orr	x8, x11, #0x1
1000e20c0:     	mov	s3, v0[1]
1000e20c4:     	mov	s1, v0[2]
1000e20c8:     	mov	s2, v0[3]
1000e20cc:     	add	x12, x0, #160
1000e20d0:     	add	x13, x1, #40
1000e20d4:     	mov	x14, x11
1000e20d8:     	add	x0, x0, x11, lsl #5
1000e20dc:     	sub	x15, x12, #128
1000e20e0:     	ld4.2d	{ v16, v17, v18, v19 }, [x15]
1000e20e4:     	sub	x15, x12, #64
1000e20e8:     	ld4.2d	{ v22, v23, v24, v25 }, [x15]
1000e20ec:     	ldp	q27, q26, [x13, #-32]
1000e20f0:     	ldp	q21, q7, [x13]
1000e20f4:     	mov	x15, x12
1000e20f8:     	ld4.2d	{ v28, v29, v30, v31 }, [x15], #64
1000e20fc:     	fsub.2d	v6, v16, v27
1000e2100:     	fsub.2d	v4, v28, v21
1000e2104:     	fsub.2d	v5, v22, v26
1000e2108:     	fsub.2d	v20, v17, v27
1000e210c:     	fsub.2d	v8, v18, v27
1000e2110:     	fsub.2d	v16, v19, v27
1000e2114:     	fsub.2d	v17, v23, v26
1000e2118:     	fsub.2d	v18, v24, v26
1000e211c:     	fsub.2d	v19, v25, v26
1000e2120:     	ld4.2d	{ v22, v23, v24, v25 }, [x15]
1000e2124:     	fsub.2d	v26, v29, v21
1000e2128:     	fsub.2d	v27, v30, v21
1000e212c:     	fsub.2d	v21, v31, v21
1000e2130:     	fsub.2d	v28, v22, v7
1000e2134:     	fsub.2d	v29, v23, v7
1000e2138:     	fsub.2d	v30, v24, v7
1000e213c:     	fsub.2d	v7, v25, v7
1000e2140:     	fmul.2d	v16, v16, v16
1000e2144:     	fcvtn	v16.2s, v16.2d
1000e2148:     	fadd	s2, s2, s16
1000e214c:     	mov	s16, v16[1]
1000e2150:     	fadd	s2, s2, s16
1000e2154:     	fmul.2d	v16, v19, v19
1000e2158:     	fcvtn	v16.2s, v16.2d
1000e215c:     	fadd	s2, s2, s16
1000e2160:     	mov	s16, v16[1]
1000e2164:     	fadd	s2, s2, s16
1000e2168:     	fmul.2d	v16, v21, v21
1000e216c:     	fcvtn	v16.2s, v16.2d
1000e2170:     	fadd	s2, s2, s16
1000e2174:     	mov	s16, v16[1]
1000e2178:     	fadd	s2, s2, s16
1000e217c:     	fmul.2d	v16, v8, v8
1000e2180:     	fcvtn	v16.2s, v16.2d
1000e2184:     	fadd	s1, s1, s16
1000e2188:     	mov	s16, v16[1]
1000e218c:     	fadd	s1, s1, s16
1000e2190:     	fmul.2d	v16, v18, v18
1000e2194:     	fcvtn	v16.2s, v16.2d
1000e2198:     	fadd	s1, s1, s16
1000e219c:     	mov	s16, v16[1]
1000e21a0:     	fadd	s1, s1, s16
1000e21a4:     	fmul.2d	v16, v27, v27
1000e21a8:     	fcvtn	v16.2s, v16.2d
1000e21ac:     	fadd	s1, s1, s16
1000e21b0:     	mov	s16, v16[1]
1000e21b4:     	fadd	s1, s1, s16
1000e21b8:     	fmul.2d	v7, v7, v7
1000e21bc:     	fcvtn	v7.2s, v7.2d
1000e21c0:     	fadd	s2, s2, s7
1000e21c4:     	mov	s7, v7[1]
1000e21c8:     	fadd	s2, s2, s7
1000e21cc:     	fmul.2d	v7, v30, v30
1000e21d0:     	fcvtn	v7.2s, v7.2d
1000e21d4:     	fadd	s1, s1, s7
1000e21d8:     	mov	s7, v7[1]
1000e21dc:     	fadd	s1, s1, s7
1000e21e0:     	fmul.2d	v7, v20, v20
1000e21e4:     	fcvtn	v7.2s, v7.2d
1000e21e8:     	fadd	s3, s3, s7
1000e21ec:     	mov	s7, v7[1]
1000e21f0:     	fadd	s3, s3, s7
1000e21f4:     	fmul.2d	v7, v17, v17
1000e21f8:     	fcvtn	v7.2s, v7.2d
1000e21fc:     	fadd	s3, s3, s7
1000e2200:     	mov	s7, v7[1]
1000e2204:     	fadd	s3, s3, s7
1000e2208:     	fmul.2d	v7, v26, v26
1000e220c:     	fcvtn	v7.2s, v7.2d
1000e2210:     	fadd	s3, s3, s7
1000e2214:     	mov	s7, v7[1]
1000e2218:     	fadd	s3, s3, s7
1000e221c:     	fmul.2d	v6, v6, v6
1000e2220:     	fcvtn	v6.2s, v6.2d
1000e2224:     	fadd	s0, s0, s6
1000e2228:     	mov	s6, v6[1]
1000e222c:     	fadd	s0, s0, s6
1000e2230:     	fmul.2d	v6, v29, v29
1000e2234:     	fcvtn	v6.2s, v6.2d
1000e2238:     	fadd	s3, s3, s6
1000e223c:     	mov	s6, v6[1]
1000e2240:     	fadd	s3, s3, s6
1000e2244:     	fmul.2d	v5, v5, v5
1000e2248:     	fcvtn	v5.2s, v5.2d
1000e224c:     	fadd	s0, s0, s5
1000e2250:     	mov	s5, v5[1]
1000e2254:     	fadd	s0, s0, s5
1000e2258:     	fmul.2d	v4, v4, v4
1000e225c:     	fcvtn	v4.2s, v4.2d
1000e2260:     	fadd	s0, s0, s4
1000e2264:     	mov	s4, v4[1]
1000e2268:     	fadd	s0, s0, s4
1000e226c:     	fmul.2d	v4, v28, v28
1000e2270:     	fcvtn	v4.2s, v4.2d
1000e2274:     	fadd	s0, s0, s4
1000e2278:     	mov	s4, v4[1]
1000e227c:     	fadd	s0, s0, s4
1000e2280:     	add	x12, x12, #256
1000e2284:     	add	x13, x13, #64
1000e2288:     	subs	x14, x14, #8
1000e228c:     	b.ne	0x1000e20dc <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x7c>
1000e2290:     	mov.s	v0[1], v3[0]
1000e2294:     	mov.s	v0[2], v1[0]
1000e2298:     	mov.s	v0[3], v2[0]
1000e229c:     	cmp	x10, x11
1000e22a0:     	b.eq	0x1000e22dc <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x27c>
1000e22a4:     	add	x9, x9, #8
1000e22a8:     	add	x10, x0, #32
1000e22ac:     	sub	x8, x2, x8
1000e22b0:     	ldp	q2, q1, [x10], #32
1000e22b4:     	ld1r.2d	{ v3 }, [x9], #8
1000e22b8:     	fsub.2d	v2, v2, v3
1000e22bc:     	fsub.2d	v1, v1, v3
1000e22c0:     	fmul.2d	v1, v1, v1
1000e22c4:     	fmul.2d	v2, v2, v2
1000e22c8:     	fcvtn	v2.2s, v2.2d
1000e22cc:     	fcvtn2	v2.4s, v1.2d
1000e22d0:     	fadd.4s	v0, v0, v2
1000e22d4:     	subs	x8, x8, #1
1000e22d8:     	b.ne	0x1000e22b0 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x250>
1000e22dc:     	str	q0, [x3]
1000e22e0:     	ldp	d9, d8, [sp], #16
1000e22e4:     	ret

00000001000e22e8 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000e22e8:     	cbz	x2, 0x1000e2354 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x6c>
1000e22ec:     	ldr	d0, [x1]
1000e22f0:     	ldp	q1, q2, [x0]
1000e22f4:     	fmul.2d	v2, v2, v0[0]
1000e22f8:     	fmul.2d	v0, v1, v0[0]
1000e22fc:     	fcvtn	v0.2s, v0.2d
1000e2300:     	fcvtn2	v0.4s, v2.2d
1000e2304:     	fneg.4s	v0, v0
1000e2308:     	str	q0, [x3]
1000e230c:     	cmp	x2, #1
1000e2310:     	b.eq	0x1000e2350 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x68>
1000e2314:     	add	x8, x1, #8
1000e2318:     	add	x9, x0, #32
1000e231c:     	lsl	x10, x2, #3
1000e2320:     	sub	x10, x10, #8
1000e2324:     	fcvtl	v1.2d, v0.2s
1000e2328:     	fcvtl2	v2.2d, v0.4s
1000e232c:     	ldp	q0, q3, [x9], #32
1000e2330:     	ld1r.2d	{ v4 }, [x8], #8
1000e2334:     	fmls.2d	v2, v4, v3
1000e2338:     	fmls.2d	v1, v4, v0
1000e233c:     	fcvtn	v0.2s, v1.2d
1000e2340:     	fcvtn2	v0.4s, v2.2d
1000e2344:     	subs	x10, x10, #8
1000e2348:     	b.ne	0x1000e2324 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x3c>
1000e234c:     	str	q0, [x3]
1000e2350:     	ret
1000e2354:     	stp	xzr, xzr, [x3]
1000e2358:     	ret

00000001000e4bb0 <void kernel<double, 4ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000e4bb0:     	cbz	x2, 0x1000e4bb8 <void kernel<double, 4ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000e4bb4:     	b	0x1000e4bc4 <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000e4bb8:     	movi.2d	v0, #0000000000000000
1000e4bbc:     	stp	q0, q0, [x3]
1000e4bc0:     	ret

00000001000e4eb8 <void kernel<double, 4ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000e4eb8:     	cbz	x2, 0x1000e4ec0 <void kernel<double, 4ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000e4ebc:     	b	0x1000e4ecc <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000e4ec0:     	movi.2d	v0, #0000000000000000
1000e4ec4:     	stp	q0, q0, [x3]
1000e4ec8:     	ret

00000001000e7c64 <void kernel<double, 4ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
1000e7c64:     	cbz	x2, 0x1000e7c6c <void kernel<double, 4ul, 4ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000e7c68:     	b	0x1000e7c7c <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000e7c6c:     	movi.2d	v0, #0000000000000000
1000e7c70:     	stp	q0, q0, [x3, #32]
1000e7c74:     	stp	q0, q0, [x3]
1000e7c78:     	ret

00000001000e8098 <void kernel<double, 4ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
1000e8098:     	cbz	x2, 0x1000e80a0 <void kernel<double, 4ul, 4ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000e809c:     	b	0x1000e80b0 <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000e80a0:     	movi.2d	v0, #0000000000000000
1000e80a4:     	stp	q0, q0, [x3, #32]
1000e80a8:     	stp	q0, q0, [x3]
1000e80ac:     	ret

00000001000ea284 <void kernel<double, 8ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000ea284:     	cbz	x2, 0x1000ea28c <void kernel<double, 8ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000ea288:     	b	0x1000ea298 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000ea28c:     	movi.2d	v0, #0000000000000000
1000ea290:     	stp	q0, q0, [x3]
1000ea294:     	ret

00000001000ea340 <void kernel<double, 8ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000ea340:     	cbz	x2, 0x1000ea348 <void kernel<double, 8ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000ea344:     	b	0x1000ea354 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000ea348:     	movi.2d	v0, #0000000000000000
1000ea34c:     	stp	q0, q0, [x3]
1000ea350:     	ret

00000001000ef040 <void kernel<double, 8ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000ef040:     	cbz	x2, 0x1000ef048 <void kernel<double, 8ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000ef044:     	b	0x1000ef058 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000ef048:     	movi.2d	v0, #0000000000000000
1000ef04c:     	stp	q0, q0, [x3, #32]
1000ef050:     	stp	q0, q0, [x3]
1000ef054:     	ret

00000001000ef1c8 <void kernel<double, 8ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000ef1c8:     	cbz	x2, 0x1000ef1d0 <void kernel<double, 8ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000ef1cc:     	b	0x1000ef1e0 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000ef1d0:     	movi.2d	v0, #0000000000000000
1000ef1d4:     	stp	q0, q0, [x3, #32]
1000ef1d8:     	stp	q0, q0, [x3]
1000ef1dc:     	ret

00000001000f513c <void kernel<double, 8ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
1000f513c:     	cbz	x2, 0x1000f5144 <void kernel<double, 8ul, 4ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000f5140:     	b	0x1000f515c <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000f5144:     	movi.2d	v0, #0000000000000000
1000f5148:     	stp	q0, q0, [x3, #96]
1000f514c:     	stp	q0, q0, [x3, #64]
1000f5150:     	stp	q0, q0, [x3, #32]
1000f5154:     	stp	q0, q0, [x3]
1000f5158:     	ret

00000001000f53a8 <void kernel<double, 8ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
1000f53a8:     	cbz	x2, 0x1000f53b0 <void kernel<double, 8ul, 4ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000f53ac:     	b	0x1000f53c8 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000f53b0:     	movi.2d	v0, #0000000000000000
1000f53b4:     	stp	q0, q0, [x3, #96]
1000f53b8:     	stp	q0, q0, [x3, #64]
1000f53bc:     	stp	q0, q0, [x3, #32]
1000f53c0:     	stp	q0, q0, [x3]
1000f53c4:     	ret

00000001000f9dbc <void kernel<double, 8ul, 8ul, false>(double const*, double const*, unsigned long, float*)>:
1000f9dbc:     	cbz	x2, 0x1000f9dc4 <void kernel<double, 8ul, 8ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000f9dc0:     	b	0x1000f9dec <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1000f9dc4:     	movi.2d	v0, #0000000000000000
1000f9dc8:     	stp	q0, q0, [x3, #224]
1000f9dcc:     	stp	q0, q0, [x3, #192]
1000f9dd0:     	stp	q0, q0, [x3, #160]
1000f9dd4:     	stp	q0, q0, [x3, #128]
1000f9dd8:     	stp	q0, q0, [x3, #96]
1000f9ddc:     	stp	q0, q0, [x3, #64]
1000f9de0:     	stp	q0, q0, [x3, #32]
1000f9de4:     	stp	q0, q0, [x3]
1000f9de8:     	ret

00000001000fa26c <void kernel<double, 8ul, 8ul, true>(double const*, double const*, unsigned long, float*)>:
1000fa26c:     	cbz	x2, 0x1000fa274 <void kernel<double, 8ul, 8ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000fa270:     	b	0x1000fa29c <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1000fa274:     	movi.2d	v0, #0000000000000000
1000fa278:     	stp	q0, q0, [x3, #224]
1000fa27c:     	stp	q0, q0, [x3, #192]
1000fa280:     	stp	q0, q0, [x3, #160]
1000fa284:     	stp	q0, q0, [x3, #128]
1000fa288:     	stp	q0, q0, [x3, #96]
1000fa28c:     	stp	q0, q0, [x3, #64]
1000fa290:     	stp	q0, q0, [x3, #32]
1000fa294:     	stp	q0, q0, [x3]
1000fa298:     	ret

00000001000fbbb4 <void kernel<double, 16ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000fbbb4:     	cbz	x2, 0x1000fbbbc <void kernel<double, 16ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000fbbb8:     	b	0x1000fbbcc <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000fbbbc:     	movi.2d	v0, #0000000000000000
1000fbbc0:     	stp	q0, q0, [x3, #32]
1000fbbc4:     	stp	q0, q0, [x3]
1000fbbc8:     	ret

00000001000fbd18 <void kernel<double, 16ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000fbd18:     	cbz	x2, 0x1000fbd20 <void kernel<double, 16ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000fbd1c:     	b	0x1000fbd30 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000fbd20:     	movi.2d	v0, #0000000000000000
1000fbd24:     	stp	q0, q0, [x3, #32]
1000fbd28:     	stp	q0, q0, [x3]
1000fbd2c:     	ret

00000001000fdaa0 <void kernel<double, 16ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000fdaa0:     	cbz	x2, 0x1000fdaa8 <void kernel<double, 16ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000fdaa4:     	b	0x1000fdac0 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000fdaa8:     	movi.2d	v0, #0000000000000000
1000fdaac:     	stp	q0, q0, [x3, #96]
1000fdab0:     	stp	q0, q0, [x3, #64]
1000fdab4:     	stp	q0, q0, [x3, #32]
1000fdab8:     	stp	q0, q0, [x3]
1000fdabc:     	ret

00000001000fdcfc <void kernel<double, 16ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000fdcfc:     	cbz	x2, 0x1000fdd04 <void kernel<double, 16ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000fdd00:     	b	0x1000fdd1c <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000fdd04:     	movi.2d	v0, #0000000000000000
1000fdd08:     	stp	q0, q0, [x3, #96]
1000fdd0c:     	stp	q0, q0, [x3, #64]
1000fdd10:     	stp	q0, q0, [x3, #32]
1000fdd14:     	stp	q0, q0, [x3]
1000fdd18:     	ret

0000000100100608 <void kernel<double, 16ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
100100608:     	cbz	x2, 0x100100610 <void kernel<double, 16ul, 4ul, false>(double const*, double const*, unsigned long, float*)+0x8>
10010060c:     	b	0x100100638 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
100100610:     	movi.2d	v0, #0000000000000000
100100614:     	stp	q0, q0, [x3, #224]
100100618:     	stp	q0, q0, [x3, #192]
10010061c:     	stp	q0, q0, [x3, #160]
100100620:     	stp	q0, q0, [x3, #128]
100100624:     	stp	q0, q0, [x3, #96]
100100628:     	stp	q0, q0, [x3, #64]
10010062c:     	stp	q0, q0, [x3, #32]
100100630:     	stp	q0, q0, [x3]
100100634:     	ret

0000000100100a54 <void kernel<double, 16ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
100100a54:     	cbz	x2, 0x100100a5c <void kernel<double, 16ul, 4ul, true>(double const*, double const*, unsigned long, float*)+0x8>
100100a58:     	b	0x100100a84 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
100100a5c:     	movi.2d	v0, #0000000000000000
100100a60:     	stp	q0, q0, [x3, #224]
100100a64:     	stp	q0, q0, [x3, #192]
100100a68:     	stp	q0, q0, [x3, #160]
100100a6c:     	stp	q0, q0, [x3, #128]
100100a70:     	stp	q0, q0, [x3, #96]
100100a74:     	stp	q0, q0, [x3, #64]
100100a78:     	stp	q0, q0, [x3, #32]
100100a7c:     	stp	q0, q0, [x3]
100100a80:     	ret

0000000100103880 <void kernel<double, 16ul, 8ul, false>(double const*, double const*, unsigned long, float*)>:
100103880:     	cbz	x2, 0x100103888 <void kernel<double, 16ul, 8ul, false>(double const*, double const*, unsigned long, float*)+0x8>
100103884:     	b	0x1001038d0 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
100103888:     	movi.2d	v0, #0000000000000000
10010388c:     	stp	q0, q0, [x3, #480]
100103890:     	stp	q0, q0, [x3, #448]
100103894:     	stp	q0, q0, [x3, #416]
100103898:     	stp	q0, q0, [x3, #384]
10010389c:     	stp	q0, q0, [x3, #352]
1001038a0:     	stp	q0, q0, [x3, #320]
1001038a4:     	stp	q0, q0, [x3, #288]
1001038a8:     	stp	q0, q0, [x3, #256]
1001038ac:     	stp	q0, q0, [x3, #224]
1001038b0:     	stp	q0, q0, [x3, #192]
1001038b4:     	stp	q0, q0, [x3, #160]
1001038b8:     	stp	q0, q0, [x3, #128]
1001038bc:     	stp	q0, q0, [x3, #96]
1001038c0:     	stp	q0, q0, [x3, #64]
1001038c4:     	stp	q0, q0, [x3, #32]
1001038c8:     	stp	q0, q0, [x3]
1001038cc:     	ret

000000010010419c <void kernel<double, 16ul, 8ul, true>(double const*, double const*, unsigned long, float*)>:
10010419c:     	cbz	x2, 0x1001041a4 <void kernel<double, 16ul, 8ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1001041a0:     	b	0x1001041ec <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1001041a4:     	movi.2d	v0, #0000000000000000
1001041a8:     	stp	q0, q0, [x3, #480]
1001041ac:     	stp	q0, q0, [x3, #448]
1001041b0:     	stp	q0, q0, [x3, #416]
1001041b4:     	stp	q0, q0, [x3, #384]
1001041b8:     	stp	q0, q0, [x3, #352]
1001041bc:     	stp	q0, q0, [x3, #320]
1001041c0:     	stp	q0, q0, [x3, #288]
1001041c4:     	stp	q0, q0, [x3, #256]
1001041c8:     	stp	q0, q0, [x3, #224]
1001041cc:     	stp	q0, q0, [x3, #192]
1001041d0:     	stp	q0, q0, [x3, #160]
1001041d4:     	stp	q0, q0, [x3, #128]
1001041d8:     	stp	q0, q0, [x3, #96]
1001041dc:     	stp	q0, q0, [x3, #64]
1001041e0:     	stp	q0, q0, [x3, #32]
1001041e4:     	stp	q0, q0, [x3]
1001041e8:     	ret

00000001001063b8 <void kernel<double, 16ul, 16ul, false>(double const*, double const*, unsigned long, float*)>:
1001063b8:     	b	0x1001063bc <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

00000001001064a4 <void kernel<double, 16ul, 16ul, true>(double const*, double const*, unsigned long, float*)>:
1001064a4:     	b	0x1001064a8 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

0000000100107994 <void kernel<double, 32ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
100107994:     	b	0x100107998 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<1ul>(double const*, double const*, unsigned long, float*)>

0000000100107af8 <void kernel<double, 32ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
100107af8:     	b	0x100107afc <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<1ul>(double const*, double const*, unsigned long, float*)>

0000000100109aac <void kernel<double, 32ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
100109aac:     	b	0x100109ab0 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(double const*, double const*, unsigned long, float*)>

0000000100109d7c <void kernel<double, 32ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
100109d7c:     	b	0x100109d80 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(double const*, double const*, unsigned long, float*)>

000000010010cae0 <void kernel<double, 32ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
10010cae0:     	b	0x10010cae4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(double const*, double const*, unsigned long, float*)>

000000010010cca0 <void kernel<double, 32ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
10010cca0:     	b	0x10010cca4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(double const*, double const*, unsigned long, float*)>

000000010010faa0 <void kernel<double, 32ul, 8ul, false>(double const*, double const*, unsigned long, float*)>:
10010faa0:     	b	0x10010faa4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(double const*, double const*, unsigned long, float*)>

000000010010fc24 <void kernel<double, 32ul, 8ul, true>(double const*, double const*, unsigned long, float*)>:
10010fc24:     	b	0x10010fc28 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(double const*, double const*, unsigned long, float*)>

0000000100111dc0 <void kernel<double, 32ul, 16ul, false>(double const*, double const*, unsigned long, float*)>:
100111dc0:     	b	0x100111dc4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

0000000100111f44 <void kernel<double, 32ul, 16ul, true>(double const*, double const*, unsigned long, float*)>:
100111f44:     	b	0x100111f48 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

00000001001140c0 <void kernel<double, 32ul, 32ul, false>(double const*, double const*, unsigned long, float*)>:
1001140c0:     	b	0x1001140c4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(double const*, double const*, unsigned long, float*)>

0000000100114244 <void kernel<double, 32ul, 32ul, true>(double const*, double const*, unsigned long, float*)>:
100114244:     	b	0x100114248 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(double const*, double const*, unsigned long, float*)>
