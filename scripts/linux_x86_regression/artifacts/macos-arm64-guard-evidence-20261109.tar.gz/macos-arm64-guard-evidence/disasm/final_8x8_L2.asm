00000001000c54a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c54a4:     	stp	x28, x27, [sp, #-96]!
1000c54a8:     	stp	x26, x25, [sp, #16]
1000c54ac:     	stp	x24, x23, [sp, #32]
1000c54b0:     	stp	x22, x21, [sp, #48]
1000c54b4:     	stp	x20, x19, [sp, #64]
1000c54b8:     	stp	x29, x30, [sp, #80]
1000c54bc:     	add	x29, sp, #80
1000c54c0:     	sub	sp, sp, #720
1000c54c4:     	str	x3, [sp, #8]
1000c54c8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c54cc:     	ldr	x8, [x8, #392]
1000c54d0:     	ldr	x8, [x8]
1000c54d4:     	stur	x8, [x29, #-96]
1000c54d8:     	movi.2d	v0, #0000000000000000
1000c54dc:     	stp	q0, q0, [sp, #672]
1000c54e0:     	lsl	x8, x2, #2
1000c54e4:     	stp	q0, q0, [sp, #640]
1000c54e8:     	stp	q0, q0, [sp, #608]
1000c54ec:     	stp	q0, q0, [sp, #576]
1000c54f0:     	stp	q0, q0, [sp, #544]
1000c54f4:     	stp	q0, q0, [sp, #512]
1000c54f8:     	stp	q0, q0, [sp, #480]
1000c54fc:     	stp	q0, q0, [sp, #448]
1000c5500:     	ands	x8, x8, #0xfffffffffffffff8
1000c5504:     	b.eq	0x1000c5a50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c5508:     	add	x8, x1, x8
1000c550c:     	str	x8, [sp, #16]
1000c5510:     	add	x8, sp, #448
1000c5514:     	add	x19, x8, #128
1000c5518:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000c551c:     	add	x11, x11, #700
1000c5520:     	mov	x12, #0
1000c5524:     	ldp	w8, w9, [x1]
1000c5528:     	ubfx	x10, x8, #8, #4
1000c552c:     	str	x10, [sp, #440]
1000c5530:     	ubfx	x10, x8, #16, #4
1000c5534:     	str	x10, [sp, #432]
1000c5538:     	ubfx	x10, x8, #24, #4
1000c553c:     	str	x10, [sp, #424]
1000c5540:     	ldp	w10, w13, [x1, #8]
1000c5544:     	and	x15, x8, #0xf
1000c5548:     	ubfx	x14, x8, #4, #4
1000c554c:     	stp	x14, x15, [sp, #408]
1000c5550:     	ubfx	x15, x8, #12, #4
1000c5554:     	ubfx	x14, x8, #20, #4
1000c5558:     	stp	x14, x15, [sp, #392]
1000c555c:     	lsr	x8, x8, #28
1000c5560:     	str	x8, [sp, #384]
1000c5564:     	and	x8, x9, #0xf
1000c5568:     	str	x8, [sp, #376]
1000c556c:     	ubfx	x8, x9, #8, #4
1000c5570:     	str	x8, [sp, #368]
1000c5574:     	ubfx	x8, x9, #16, #4
1000c5578:     	str	x8, [sp, #360]
1000c557c:     	ubfx	x8, x9, #24, #4
1000c5580:     	str	x8, [sp, #352]
1000c5584:     	ubfx	x8, x9, #4, #4
1000c5588:     	str	x8, [sp, #344]
1000c558c:     	ubfx	x8, x9, #12, #4
1000c5590:     	str	x8, [sp, #336]
1000c5594:     	ubfx	x8, x9, #20, #4
1000c5598:     	str	x8, [sp, #328]
1000c559c:     	lsr	x8, x9, #28
1000c55a0:     	str	x8, [sp, #320]
1000c55a4:     	and	x9, x10, #0xf
1000c55a8:     	ubfx	x8, x10, #8, #4
1000c55ac:     	stp	x8, x9, [sp, #304]
1000c55b0:     	ubfx	x9, x10, #16, #4
1000c55b4:     	ubfx	x8, x10, #24, #4
1000c55b8:     	stp	x8, x9, [sp, #288]
1000c55bc:     	ubfx	x9, x10, #4, #4
1000c55c0:     	ubfx	x8, x10, #12, #4
1000c55c4:     	stp	x8, x9, [sp, #272]
1000c55c8:     	ubfx	x9, x10, #20, #4
1000c55cc:     	lsr	x8, x10, #28
1000c55d0:     	stp	x8, x9, [sp, #256]
1000c55d4:     	and	x9, x13, #0xf
1000c55d8:     	ubfx	x8, x13, #8, #4
1000c55dc:     	stp	x8, x9, [sp, #240]
1000c55e0:     	ubfx	x9, x13, #16, #4
1000c55e4:     	ubfx	x8, x13, #24, #4
1000c55e8:     	stp	x8, x9, [sp, #224]
1000c55ec:     	ubfx	x9, x13, #4, #4
1000c55f0:     	ubfx	x8, x13, #12, #4
1000c55f4:     	stp	x8, x9, [sp, #208]
1000c55f8:     	ubfx	x9, x13, #20, #4
1000c55fc:     	lsr	x8, x13, #28
1000c5600:     	stp	x8, x9, [sp, #192]
1000c5604:     	ldp	w8, w9, [x1, #16]
1000c5608:     	and	x10, x8, #0xf
1000c560c:     	str	x10, [sp, #184]
1000c5610:     	ubfx	x10, x8, #8, #4
1000c5614:     	str	x10, [sp, #176]
1000c5618:     	ubfx	x10, x8, #16, #4
1000c561c:     	str	x10, [sp, #168]
1000c5620:     	ubfx	x10, x8, #24, #4
1000c5624:     	str	x10, [sp, #160]
1000c5628:     	ubfx	x10, x8, #4, #4
1000c562c:     	str	x10, [sp, #152]
1000c5630:     	ubfx	x10, x8, #12, #4
1000c5634:     	str	x10, [sp, #144]
1000c5638:     	ubfx	x10, x8, #20, #4
1000c563c:     	lsr	x8, x8, #28
1000c5640:     	stp	x8, x10, [sp, #128]
1000c5644:     	and	x10, x9, #0xf
1000c5648:     	ubfx	x8, x9, #8, #4
1000c564c:     	stp	x8, x10, [sp, #112]
1000c5650:     	ubfx	x10, x9, #16, #4
1000c5654:     	ubfx	x8, x9, #24, #4
1000c5658:     	stp	x8, x10, [sp, #96]
1000c565c:     	ubfx	x10, x9, #4, #4
1000c5660:     	ubfx	x8, x9, #12, #4
1000c5664:     	stp	x8, x10, [sp, #80]
1000c5668:     	ubfx	x10, x9, #20, #4
1000c566c:     	lsr	x8, x9, #28
1000c5670:     	stp	x8, x10, [sp, #64]
1000c5674:     	ldp	w14, w7, [x1, #24]
1000c5678:     	and	x9, x14, #0xf
1000c567c:     	ubfx	x8, x14, #8, #4
1000c5680:     	stp	x8, x9, [sp, #48]
1000c5684:     	ubfx	x8, x14, #16, #4
1000c5688:     	str	x8, [sp, #40]
1000c568c:     	ubfx	x8, x14, #24, #4
1000c5690:     	stp	x1, x8, [sp, #24]
1000c5694:     	ubfx	x10, x14, #4, #4
1000c5698:     	ubfx	x13, x14, #12, #4
1000c569c:     	ubfx	x9, x14, #20, #4
1000c56a0:     	lsr	x14, x14, #28
1000c56a4:     	and	x15, x7, #0xf
1000c56a8:     	ubfx	x16, x7, #8, #4
1000c56ac:     	ubfx	x17, x7, #16, #4
1000c56b0:     	ubfx	x2, x7, #24, #4
1000c56b4:     	ubfx	x4, x7, #4, #4
1000c56b8:     	ubfx	x5, x7, #12, #4
1000c56bc:     	ubfx	x6, x7, #20, #4
1000c56c0:     	lsr	x7, x7, #28
1000c56c4:     	ldr	w26, [x0, x12]
1000c56c8:     	mov	x1, x19
1000c56cc:     	lsl	w19, w26, #4
1000c56d0:     	and	x19, x19, #0xf0
1000c56d4:     	add	x19, x11, x19
1000c56d8:     	ldr	x8, [sp, #416]
1000c56dc:     	ldrb	w25, [x19, x8]
1000c56e0:     	lsr	x20, x26, #4
1000c56e4:     	and	x20, x20, #0xf0
1000c56e8:     	add	x20, x11, x20
1000c56ec:     	ldr	x8, [sp, #440]
1000c56f0:     	ldrb	w27, [x20, x8]
1000c56f4:     	lsr	x21, x26, #12
1000c56f8:     	and	x21, x21, #0xf0
1000c56fc:     	add	x21, x11, x21
1000c5700:     	ldr	x8, [sp, #432]
1000c5704:     	ldrb	w28, [x21, x8]
1000c5708:     	lsr	x22, x26, #20
1000c570c:     	and	x22, x22, #0xf0
1000c5710:     	add	x23, x11, x22
1000c5714:     	ldr	x8, [sp, #424]
1000c5718:     	ldrb	w30, [x23, x8]
1000c571c:     	and	x22, x26, #0xf0
1000c5720:     	add	x22, x11, x22
1000c5724:     	ldp	x3, x8, [sp, #400]
1000c5728:     	ldrb	w8, [x22, x8]
1000c572c:     	lsr	x24, x26, #8
1000c5730:     	and	x24, x24, #0xf0
1000c5734:     	add	x24, x11, x24
1000c5738:     	ldrb	w3, [x24, x3]
1000c573c:     	add	w27, w25, w27
1000c5740:     	lsr	x25, x26, #16
1000c5744:     	and	x25, x25, #0xf0
1000c5748:     	add	x25, x11, x25
1000c574c:     	add	w27, w27, w28
1000c5750:     	ldr	x28, [sp, #392]
1000c5754:     	ldrb	w28, [x25, x28]
1000c5758:     	lsr	x26, x26, #24
1000c575c:     	and	x26, x26, #0xf0
1000c5760:     	add	x26, x11, x26
1000c5764:     	add	w27, w27, w30
1000c5768:     	ldr	x30, [sp, #384]
1000c576c:     	ldrb	w30, [x26, x30]
1000c5770:     	add	w8, w27, w8
1000c5774:     	add	w8, w8, w3
1000c5778:     	add	w8, w8, w28
1000c577c:     	add	w8, w8, w30
1000c5780:     	scvtf	s0, w8
1000c5784:     	ldp	x3, x8, [sp, #368]
1000c5788:     	ldrb	w8, [x19, x8]
1000c578c:     	ldrb	w3, [x20, x3]
1000c5790:     	ldp	x28, x27, [sp, #352]
1000c5794:     	ldrb	w27, [x21, x27]
1000c5798:     	ldrb	w28, [x23, x28]
1000c579c:     	ldr	x30, [sp, #344]
1000c57a0:     	ldrb	w30, [x22, x30]
1000c57a4:     	add	w8, w8, w3
1000c57a8:     	ldr	x3, [sp, #336]
1000c57ac:     	ldrb	w3, [x24, x3]
1000c57b0:     	add	w8, w8, w27
1000c57b4:     	ldr	x27, [sp, #328]
1000c57b8:     	ldrb	w27, [x25, x27]
1000c57bc:     	add	w8, w8, w28
1000c57c0:     	ldr	x28, [sp, #320]
1000c57c4:     	ldrb	w28, [x26, x28]
1000c57c8:     	add	w8, w8, w30
1000c57cc:     	add	w8, w8, w3
1000c57d0:     	add	w8, w8, w27
1000c57d4:     	add	w8, w8, w28
1000c57d8:     	scvtf	s1, w8
1000c57dc:     	ldp	x3, x8, [sp, #304]
1000c57e0:     	ldrb	w8, [x19, x8]
1000c57e4:     	ldrb	w3, [x20, x3]
1000c57e8:     	ldp	x28, x27, [sp, #288]
1000c57ec:     	ldrb	w27, [x21, x27]
1000c57f0:     	ldrb	w28, [x23, x28]
1000c57f4:     	add	w8, w8, w3
1000c57f8:     	ldr	x3, [sp, #280]
1000c57fc:     	ldrb	w3, [x22, x3]
1000c5800:     	add	w8, w8, w27
1000c5804:     	ldr	x27, [sp, #272]
1000c5808:     	ldrb	w27, [x24, x27]
1000c580c:     	add	w8, w8, w28
1000c5810:     	ldr	x28, [sp, #264]
1000c5814:     	ldrb	w28, [x25, x28]
1000c5818:     	add	w8, w8, w3
1000c581c:     	ldr	x3, [sp, #256]
1000c5820:     	ldrb	w3, [x26, x3]
1000c5824:     	add	w8, w8, w27
1000c5828:     	add	w8, w8, w28
1000c582c:     	add	w8, w8, w3
1000c5830:     	scvtf	s2, w8
1000c5834:     	ldp	x3, x8, [sp, #240]
1000c5838:     	ldrb	w8, [x19, x8]
1000c583c:     	ldrb	w3, [x20, x3]
1000c5840:     	ldp	x28, x27, [sp, #224]
1000c5844:     	ldrb	w27, [x21, x27]
1000c5848:     	ldrb	w28, [x23, x28]
1000c584c:     	add	w8, w8, w3
1000c5850:     	ldr	x3, [sp, #216]
1000c5854:     	ldrb	w3, [x22, x3]
1000c5858:     	add	w8, w8, w27
1000c585c:     	ldr	x27, [sp, #208]
1000c5860:     	ldrb	w27, [x24, x27]
1000c5864:     	add	w8, w8, w28
1000c5868:     	ldr	x28, [sp, #200]
1000c586c:     	ldrb	w28, [x25, x28]
1000c5870:     	add	w8, w8, w3
1000c5874:     	ldr	x3, [sp, #192]
1000c5878:     	ldrb	w3, [x26, x3]
1000c587c:     	add	w8, w8, w27
1000c5880:     	add	w8, w8, w28
1000c5884:     	add	w8, w8, w3
1000c5888:     	scvtf	s3, w8
1000c588c:     	ldp	x3, x8, [sp, #176]
1000c5890:     	ldrb	w8, [x19, x8]
1000c5894:     	ldrb	w3, [x20, x3]
1000c5898:     	ldp	x28, x27, [sp, #160]
1000c589c:     	ldrb	w27, [x21, x27]
1000c58a0:     	ldrb	w28, [x23, x28]
1000c58a4:     	add	w8, w8, w3
1000c58a8:     	add	w8, w8, w27
1000c58ac:     	ldr	x3, [sp, #152]
1000c58b0:     	ldrb	w3, [x22, x3]
1000c58b4:     	add	w8, w8, w28
1000c58b8:     	add	w8, w8, w3
1000c58bc:     	ldp	x27, x3, [sp, #136]
1000c58c0:     	ldrb	w3, [x24, x3]
1000c58c4:     	ldrb	w27, [x25, x27]
1000c58c8:     	add	w8, w8, w3
1000c58cc:     	add	w8, w8, w27
1000c58d0:     	ldr	x3, [sp, #128]
1000c58d4:     	ldrb	w3, [x26, x3]
1000c58d8:     	add	w8, w8, w3
1000c58dc:     	scvtf	s4, w8
1000c58e0:     	ldp	x3, x8, [sp, #112]
1000c58e4:     	ldrb	w8, [x19, x8]
1000c58e8:     	ldrb	w3, [x20, x3]
1000c58ec:     	ldp	x28, x27, [sp, #96]
1000c58f0:     	ldrb	w27, [x21, x27]
1000c58f4:     	ldrb	w28, [x23, x28]
1000c58f8:     	add	w8, w8, w3
1000c58fc:     	ldr	x3, [sp, #88]
1000c5900:     	ldrb	w3, [x22, x3]
1000c5904:     	add	w8, w8, w27
1000c5908:     	ldr	x27, [sp, #80]
1000c590c:     	ldrb	w27, [x24, x27]
1000c5910:     	add	w8, w8, w28
1000c5914:     	ldr	x28, [sp, #72]
1000c5918:     	ldrb	w28, [x25, x28]
1000c591c:     	add	w8, w8, w3
1000c5920:     	add	w8, w8, w27
1000c5924:     	add	w8, w8, w28
1000c5928:     	ldr	x3, [sp, #64]
1000c592c:     	ldrb	w3, [x26, x3]
1000c5930:     	add	w8, w8, w3
1000c5934:     	scvtf	s5, w8
1000c5938:     	ldp	x3, x8, [sp, #48]
1000c593c:     	ldrb	w8, [x19, x8]
1000c5940:     	ldrb	w3, [x20, x3]
1000c5944:     	ldr	x27, [sp, #40]
1000c5948:     	ldrb	w27, [x21, x27]
1000c594c:     	add	w8, w8, w3
1000c5950:     	ldr	x3, [sp, #32]
1000c5954:     	ldrb	w3, [x23, x3]
1000c5958:     	add	w8, w8, w27
1000c595c:     	ldrb	w27, [x22, x10]
1000c5960:     	add	w8, w8, w3
1000c5964:     	ldrb	w3, [x24, x13]
1000c5968:     	add	w8, w8, w27
1000c596c:     	ldrb	w27, [x25, x9]
1000c5970:     	add	w8, w8, w3
1000c5974:     	ldrb	w3, [x26, x14]
1000c5978:     	add	w8, w8, w27
1000c597c:     	add	w8, w8, w3
1000c5980:     	scvtf	s6, w8
1000c5984:     	ldrb	w8, [x19, x15]
1000c5988:     	ldrb	w3, [x20, x16]
1000c598c:     	ldrb	w19, [x21, x17]
1000c5990:     	add	w8, w8, w3
1000c5994:     	add	w8, w8, w19
1000c5998:     	ldrb	w3, [x23, x2]
1000c599c:     	ldrb	w19, [x22, x4]
1000c59a0:     	add	w8, w8, w3
1000c59a4:     	add	w8, w8, w19
1000c59a8:     	ldrb	w3, [x24, x5]
1000c59ac:     	ldrb	w19, [x25, x6]
1000c59b0:     	add	w8, w8, w3
1000c59b4:     	add	w8, w8, w19
1000c59b8:     	mov	x19, x1
1000c59bc:     	ldrb	w3, [x26, x7]
1000c59c0:     	add	w8, w8, w3
1000c59c4:     	add	x3, sp, #448
1000c59c8:     	scvtf	s7, w8
1000c59cc:     	add	x8, x1, x12
1000c59d0:     	ldur	s16, [x8, #-96]
1000c59d4:     	fadd	s1, s16, s1
1000c59d8:     	stur	s1, [x8, #-96]
1000c59dc:     	ldur	s1, [x8, #-64]
1000c59e0:     	fadd	s1, s1, s2
1000c59e4:     	stur	s1, [x8, #-64]
1000c59e8:     	ldur	s1, [x8, #-32]
1000c59ec:     	fadd	s1, s1, s3
1000c59f0:     	stur	s1, [x8, #-32]
1000c59f4:     	ldr	s1, [x8]
1000c59f8:     	fadd	s1, s1, s4
1000c59fc:     	str	s1, [x8]
1000c5a00:     	ldr	s1, [x8, #32]
1000c5a04:     	fadd	s1, s1, s5
1000c5a08:     	str	s1, [x8, #32]
1000c5a0c:     	ldr	s1, [x8, #64]
1000c5a10:     	fadd	s1, s1, s6
1000c5a14:     	str	s1, [x8, #64]
1000c5a18:     	ldr	s1, [x8, #96]
1000c5a1c:     	fadd	s1, s1, s7
1000c5a20:     	ldr	s2, [x3, x12]
1000c5a24:     	str	s1, [x8, #96]
1000c5a28:     	fadd	s0, s2, s0
1000c5a2c:     	str	s0, [x3, x12]
1000c5a30:     	add	x12, x12, #4
1000c5a34:     	cmp	x12, #32
1000c5a38:     	b.ne	0x1000c56c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c5a3c:     	add	x0, x0, #32
1000c5a40:     	ldp	x8, x1, [sp, #16]
1000c5a44:     	add	x1, x1, #32
1000c5a48:     	cmp	x1, x8
1000c5a4c:     	b.ne	0x1000c5520 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c5a50:     	ldp	q0, q1, [sp, #640]
1000c5a54:     	ldr	x8, [sp, #8]
1000c5a58:     	stp	q0, q1, [x8, #192]
1000c5a5c:     	ldp	q0, q1, [sp, #672]
1000c5a60:     	stp	q0, q1, [x8, #224]
1000c5a64:     	ldp	q0, q1, [sp, #576]
1000c5a68:     	stp	q0, q1, [x8, #128]
1000c5a6c:     	ldp	q0, q1, [sp, #608]
1000c5a70:     	stp	q0, q1, [x8, #160]
1000c5a74:     	ldp	q0, q1, [sp, #512]
1000c5a78:     	stp	q0, q1, [x8, #64]
1000c5a7c:     	ldp	q0, q1, [sp, #544]
1000c5a80:     	stp	q0, q1, [x8, #96]
1000c5a84:     	ldp	q0, q1, [sp, #448]
1000c5a88:     	stp	q0, q1, [x8]
1000c5a8c:     	ldp	q0, q1, [sp, #480]
1000c5a90:     	stp	q0, q1, [x8, #32]
1000c5a94:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c5a98:     	ldr	x8, [x8, #392]
1000c5a9c:     	ldr	x8, [x8]
1000c5aa0:     	ldur	x9, [x29, #-96]
1000c5aa4:     	cmp	x8, x9
1000c5aa8:     	b.ne	0x1000c5acc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c5aac:     	add	sp, sp, #720
1000c5ab0:     	ldp	x29, x30, [sp, #80]
1000c5ab4:     	ldp	x20, x19, [sp, #64]
1000c5ab8:     	ldp	x22, x21, [sp, #48]
1000c5abc:     	ldp	x24, x23, [sp, #32]
1000c5ac0:     	ldp	x26, x25, [sp, #16]
1000c5ac4:     	ldp	x28, x27, [sp], #96
1000c5ac8:     	ret
1000c5acc:     	bl	0x100163694 <_strcmp+0x100163694>

