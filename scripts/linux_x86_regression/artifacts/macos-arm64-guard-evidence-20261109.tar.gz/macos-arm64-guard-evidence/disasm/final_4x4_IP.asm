00000001000bdce0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bdce0:     	sub	sp, sp, #352
1000bdce4:     	stp	x28, x27, [sp, #256]
1000bdce8:     	stp	x26, x25, [sp, #272]
1000bdcec:     	stp	x24, x23, [sp, #288]
1000bdcf0:     	stp	x22, x21, [sp, #304]
1000bdcf4:     	stp	x20, x19, [sp, #320]
1000bdcf8:     	stp	x29, x30, [sp, #336]
1000bdcfc:     	add	x29, sp, #336
1000bdd00:     	str	x3, [sp]
1000bdd04:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bdd08:     	ldr	x8, [x8, #392]
1000bdd0c:     	ldr	x8, [x8]
1000bdd10:     	stur	x8, [x29, #-96]
1000bdd14:     	movi.2d	v0, #0000000000000000
1000bdd18:     	stp	q0, q0, [x29, #-128]
1000bdd1c:     	lsl	x8, x2, #1
1000bdd20:     	stp	q0, q0, [x29, #-160]
1000bdd24:     	ands	x8, x8, #0xfffffffffffffffc
1000bdd28:     	b.eq	0x1000be050 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bdd2c:     	add	x8, x1, x8
1000bdd30:     	str	x8, [sp, #8]
1000bdd34:     	sub	x8, x29, #160
1000bdd38:     	add	x27, x8, #32
1000bdd3c:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bdd40:     	add	x11, x11, #444
1000bdd44:     	mov	x12, #0
1000bdd48:     	ldp	w8, w9, [x1]
1000bdd4c:     	ubfx	x10, x8, #4, #4
1000bdd50:     	str	x10, [sp, #168]
1000bdd54:     	ubfx	x10, x8, #8, #4
1000bdd58:     	str	x10, [sp, #160]
1000bdd5c:     	and	x10, x8, #0xf
1000bdd60:     	str	x10, [sp, #152]
1000bdd64:     	ubfx	x10, x8, #12, #4
1000bdd68:     	str	x10, [sp, #144]
1000bdd6c:     	ubfx	x10, x8, #16, #4
1000bdd70:     	str	x10, [sp, #136]
1000bdd74:     	ubfx	x10, x8, #20, #4
1000bdd78:     	str	x10, [sp, #128]
1000bdd7c:     	ubfx	x10, x8, #24, #4
1000bdd80:     	lsr	x8, x8, #28
1000bdd84:     	stp	x8, x10, [sp, #112]
1000bdd88:     	and	x10, x9, #0xf
1000bdd8c:     	ubfx	x8, x9, #4, #4
1000bdd90:     	stp	x8, x10, [sp, #96]
1000bdd94:     	ubfx	x10, x9, #8, #4
1000bdd98:     	ubfx	x8, x9, #12, #4
1000bdd9c:     	stp	x8, x10, [sp, #80]
1000bdda0:     	ubfx	x10, x9, #16, #4
1000bdda4:     	ubfx	x8, x9, #20, #4
1000bdda8:     	stp	x8, x10, [sp, #64]
1000bddac:     	ubfx	x10, x9, #24, #4
1000bddb0:     	lsr	x8, x9, #28
1000bddb4:     	stp	x8, x10, [sp, #48]
1000bddb8:     	ldp	w9, w17, [x1, #8]
1000bddbc:     	and	x10, x9, #0xf
1000bddc0:     	ubfx	x8, x9, #4, #4
1000bddc4:     	stp	x8, x10, [sp, #32]
1000bddc8:     	ubfx	x8, x9, #8, #4
1000bddcc:     	stp	x1, x8, [sp, #16]
1000bddd0:     	ubfx	x28, x9, #12, #4
1000bddd4:     	ubfx	x30, x9, #16, #4
1000bddd8:     	ubfx	x8, x9, #20, #4
1000bdddc:     	ubfx	x3, x9, #24, #4
1000bdde0:     	lsr	x9, x9, #28
1000bdde4:     	and	x1, x17, #0xf
1000bdde8:     	ubfx	x10, x17, #4, #4
1000bddec:     	ubfx	x13, x17, #8, #4
1000bddf0:     	ubfx	x26, x17, #12, #4
1000bddf4:     	ubfx	x14, x17, #16, #4
1000bddf8:     	ubfx	x15, x17, #20, #4
1000bddfc:     	ubfx	x16, x17, #24, #4
1000bde00:     	lsr	x17, x17, #28
1000bde04:     	ldr	w21, [x0, x12]
1000bde08:     	lsl	w2, w21, #4
1000bde0c:     	and	x2, x2, #0xf0
1000bde10:     	ldp	x4, x19, [sp, #152]
1000bde14:     	orr	x4, x2, x4
1000bde18:     	ldrsb	w6, [x11, x4]
1000bde1c:     	and	x4, x21, #0xf0
1000bde20:     	ldr	x5, [sp, #168]
1000bde24:     	orr	x5, x4, x5
1000bde28:     	ldrsb	w7, [x11, x5]
1000bde2c:     	lsr	x5, x21, #4
1000bde30:     	and	x5, x5, #0xf0
1000bde34:     	orr	x19, x5, x19
1000bde38:     	ldrsb	w19, [x11, x19]
1000bde3c:     	add	w6, w6, w7
1000bde40:     	add	w19, w6, w19
1000bde44:     	lsr	x6, x21, #8
1000bde48:     	and	x6, x6, #0xf0
1000bde4c:     	ldp	x22, x7, [sp, #136]
1000bde50:     	orr	x7, x6, x7
1000bde54:     	ldrsb	w20, [x11, x7]
1000bde58:     	lsr	x7, x21, #12
1000bde5c:     	and	x7, x7, #0xf0
1000bde60:     	orr	x22, x7, x22
1000bde64:     	ldrsb	w22, [x11, x22]
1000bde68:     	add	w19, w19, w20
1000bde6c:     	add	w22, w19, w22
1000bde70:     	lsr	x19, x21, #16
1000bde74:     	and	x19, x19, #0xf0
1000bde78:     	ldp	x24, x20, [sp, #120]
1000bde7c:     	orr	x20, x19, x20
1000bde80:     	ldrsb	w23, [x11, x20]
1000bde84:     	lsr	x20, x21, #20
1000bde88:     	and	x20, x20, #0xf0
1000bde8c:     	orr	x24, x20, x24
1000bde90:     	ldrsb	w24, [x11, x24]
1000bde94:     	add	w22, w22, w23
1000bde98:     	add	w22, w22, w24
1000bde9c:     	lsr	x21, x21, #24
1000bdea0:     	and	x21, x21, #0xf0
1000bdea4:     	ldr	x23, [sp, #112]
1000bdea8:     	orr	x23, x21, x23
1000bdeac:     	ldrsb	w23, [x11, x23]
1000bdeb0:     	add	w22, w22, w23
1000bdeb4:     	scvtf	s0, w22
1000bdeb8:     	ldp	x23, x22, [sp, #96]
1000bdebc:     	orr	x22, x2, x22
1000bdec0:     	ldrsb	w22, [x11, x22]
1000bdec4:     	orr	x23, x4, x23
1000bdec8:     	ldrsb	w23, [x11, x23]
1000bdecc:     	ldr	x24, [sp, #88]
1000bded0:     	orr	x24, x5, x24
1000bded4:     	ldrsb	w24, [x11, x24]
1000bded8:     	add	w22, w22, w23
1000bdedc:     	add	w22, w22, w24
1000bdee0:     	ldp	x24, x23, [sp, #72]
1000bdee4:     	orr	x23, x6, x23
1000bdee8:     	ldrsb	w23, [x11, x23]
1000bdeec:     	orr	x24, x7, x24
1000bdef0:     	ldrsb	w24, [x11, x24]
1000bdef4:     	ldr	x25, [sp, #64]
1000bdef8:     	orr	x25, x19, x25
1000bdefc:     	ldrsb	w25, [x11, x25]
1000bdf00:     	add	w22, w22, w23
1000bdf04:     	add	w22, w22, w24
1000bdf08:     	ldr	x23, [sp, #56]
1000bdf0c:     	orr	x23, x20, x23
1000bdf10:     	ldrsb	w23, [x11, x23]
1000bdf14:     	add	w22, w22, w25
1000bdf18:     	add	w22, w22, w23
1000bdf1c:     	ldr	x23, [sp, #48]
1000bdf20:     	orr	x23, x21, x23
1000bdf24:     	ldrsb	w23, [x11, x23]
1000bdf28:     	add	w22, w22, w23
1000bdf2c:     	scvtf	s1, w22
1000bdf30:     	ldp	x23, x22, [sp, #32]
1000bdf34:     	orr	x22, x2, x22
1000bdf38:     	ldrsb	w22, [x11, x22]
1000bdf3c:     	orr	x23, x4, x23
1000bdf40:     	ldrsb	w23, [x11, x23]
1000bdf44:     	ldr	x24, [sp, #24]
1000bdf48:     	orr	x24, x5, x24
1000bdf4c:     	ldrsb	w24, [x11, x24]
1000bdf50:     	add	w22, w22, w23
1000bdf54:     	add	w22, w22, w24
1000bdf58:     	orr	x23, x6, x28
1000bdf5c:     	ldrsb	w23, [x11, x23]
1000bdf60:     	orr	x24, x7, x30
1000bdf64:     	ldrsb	w24, [x11, x24]
1000bdf68:     	orr	x25, x19, x8
1000bdf6c:     	ldrsb	w25, [x11, x25]
1000bdf70:     	add	w22, w22, w23
1000bdf74:     	orr	x23, x20, x3
1000bdf78:     	ldrsb	w23, [x11, x23]
1000bdf7c:     	add	w22, w22, w24
1000bdf80:     	add	w22, w22, w25
1000bdf84:     	add	w22, w22, w23
1000bdf88:     	orr	x23, x21, x9
1000bdf8c:     	ldrsb	w23, [x11, x23]
1000bdf90:     	add	w22, w22, w23
1000bdf94:     	scvtf	s2, w22
1000bdf98:     	orr	x2, x2, x1
1000bdf9c:     	ldrsb	w2, [x11, x2]
1000bdfa0:     	orr	x4, x4, x10
1000bdfa4:     	ldrsb	w4, [x11, x4]
1000bdfa8:     	orr	x5, x5, x13
1000bdfac:     	ldrsb	w5, [x11, x5]
1000bdfb0:     	add	w2, w2, w4
1000bdfb4:     	add	w2, w2, w5
1000bdfb8:     	orr	x4, x6, x26
1000bdfbc:     	ldrsb	w4, [x11, x4]
1000bdfc0:     	orr	x5, x7, x14
1000bdfc4:     	ldrsb	w5, [x11, x5]
1000bdfc8:     	add	w2, w2, w4
1000bdfcc:     	orr	x4, x19, x15
1000bdfd0:     	ldrsb	w4, [x11, x4]
1000bdfd4:     	add	w2, w2, w5
1000bdfd8:     	orr	x5, x20, x16
1000bdfdc:     	ldrsb	w5, [x11, x5]
1000bdfe0:     	add	w2, w2, w4
1000bdfe4:     	add	w2, w2, w5
1000bdfe8:     	orr	x4, x21, x17
1000bdfec:     	ldrsb	w4, [x11, x4]
1000bdff0:     	add	w2, w2, w4
1000bdff4:     	sub	x4, x29, #160
1000bdff8:     	scvtf	s3, w2
1000bdffc:     	add	x2, x27, x12
1000be000:     	ldur	s4, [x2, #-16]
1000be004:     	fadd	s1, s4, s1
1000be008:     	stur	s1, [x2, #-16]
1000be00c:     	ldr	s1, [x2]
1000be010:     	fadd	s1, s1, s2
1000be014:     	str	s1, [x2]
1000be018:     	ldr	s1, [x2, #16]
1000be01c:     	fadd	s1, s1, s3
1000be020:     	ldr	s2, [x4, x12]
1000be024:     	str	s1, [x2, #16]
1000be028:     	fadd	s0, s2, s0
1000be02c:     	str	s0, [x4, x12]
1000be030:     	add	x12, x12, #4
1000be034:     	cmp	x12, #16
1000be038:     	b.ne	0x1000bde04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000be03c:     	add	x0, x0, #16
1000be040:     	ldp	x8, x1, [sp, #8]
1000be044:     	add	x1, x1, #16
1000be048:     	cmp	x1, x8
1000be04c:     	b.ne	0x1000bdd44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000be050:     	ldp	q0, q1, [x29, #-160]
1000be054:     	ldr	x8, [sp]
1000be058:     	stp	q0, q1, [x8]
1000be05c:     	ldp	q0, q1, [x29, #-128]
1000be060:     	stp	q0, q1, [x8, #32]
1000be064:     	ldur	x8, [x29, #-96]
1000be068:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 1ul, false>(char const*)+0x280>
1000be06c:     	ldr	x9, [x9, #392]
1000be070:     	ldr	x9, [x9]
1000be074:     	cmp	x9, x8
1000be078:     	b.ne	0x1000be09c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000be07c:     	ldp	x29, x30, [sp, #336]
1000be080:     	ldp	x20, x19, [sp, #320]
1000be084:     	ldp	x22, x21, [sp, #304]
1000be088:     	ldp	x24, x23, [sp, #288]
1000be08c:     	ldp	x26, x25, [sp, #272]
1000be090:     	ldp	x28, x27, [sp, #256]
1000be094:     	add	sp, sp, #352
1000be098:     	ret
1000be09c:     	bl	0x100163694 <_strcmp+0x100163694>

