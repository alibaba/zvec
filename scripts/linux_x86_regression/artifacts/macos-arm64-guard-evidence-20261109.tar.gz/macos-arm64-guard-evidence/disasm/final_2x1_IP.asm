00000001000b6c8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b6c8c:     	stp	x24, x23, [sp, #-48]!
1000b6c90:     	stp	x22, x21, [sp, #16]
1000b6c94:     	stp	x20, x19, [sp, #32]
1000b6c98:     	str	xzr, [x3]
1000b6c9c:     	lsl	x8, x4, #2
1000b6ca0:     	cmp	x2, #8
1000b6ca4:     	b.hs	0x1000b6cb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b6ca8:     	mov	x12, #0
1000b6cac:     	movi	d1, #0000000000000000
1000b6cb0:     	movi	d0, #0000000000000000
1000b6cb4:     	b	0x1000b6e20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b6cb8:     	mov	x10, #0
1000b6cbc:     	adrp	x9, 0x100169000 <void run<unsigned char, 2ul, 2ul, false>(char const*)+0xb4>
1000b6cc0:     	add	x9, x9, #4028
1000b6cc4:     	mov	x11, x1
1000b6cc8:     	ldr	w4, [x11]
1000b6ccc:     	lsl	w12, w4, #4
1000b6cd0:     	and	x13, x12, #0xf0
1000b6cd4:     	and	x12, x4, #0xf0
1000b6cd8:     	add	x12, x9, x12
1000b6cdc:     	lsr	x14, x4, #4
1000b6ce0:     	and	x15, x14, #0xf0
1000b6ce4:     	add	x14, x9, x13
1000b6ce8:     	add	x13, x9, x15
1000b6cec:     	lsr	x15, x4, #8
1000b6cf0:     	and	x15, x15, #0xf0
1000b6cf4:     	lsr	x16, x4, #12
1000b6cf8:     	and	x17, x16, #0xf0
1000b6cfc:     	add	x16, x9, x15
1000b6d00:     	add	x15, x9, x17
1000b6d04:     	lsr	x17, x4, #16
1000b6d08:     	and	x17, x17, #0xf0
1000b6d0c:     	lsr	x5, x4, #20
1000b6d10:     	and	x5, x5, #0xf0
1000b6d14:     	add	x17, x9, x17
1000b6d18:     	lsr	x4, x4, #24
1000b6d1c:     	and	x6, x4, #0xf0
1000b6d20:     	add	x7, x0, x10
1000b6d24:     	ldr	w19, [x7]
1000b6d28:     	and	x20, x19, #0xf
1000b6d2c:     	add	x4, x9, x5
1000b6d30:     	ldrsb	w5, [x14, x20]
1000b6d34:     	ubfx	x20, x19, #4, #4
1000b6d38:     	ubfx	x21, x19, #8, #4
1000b6d3c:     	ldrsb	w20, [x12, x20]
1000b6d40:     	ldrsb	w21, [x13, x21]
1000b6d44:     	ubfx	x22, x19, #12, #4
1000b6d48:     	ubfx	x23, x19, #16, #4
1000b6d4c:     	ldrsb	w22, [x16, x22]
1000b6d50:     	ldrsb	w23, [x15, x23]
1000b6d54:     	ubfx	x24, x19, #20, #4
1000b6d58:     	ldrsb	w24, [x17, x24]
1000b6d5c:     	add	w5, w5, w20
1000b6d60:     	add	w5, w5, w21
1000b6d64:     	ubfx	x20, x19, #24, #4
1000b6d68:     	ldrsb	w20, [x4, x20]
1000b6d6c:     	add	w5, w5, w22
1000b6d70:     	add	w5, w5, w23
1000b6d74:     	add	x6, x9, x6
1000b6d78:     	lsr	x19, x19, #28
1000b6d7c:     	ldrsb	w19, [x6, x19]
1000b6d80:     	add	w5, w5, w24
1000b6d84:     	add	w5, w5, w20
1000b6d88:     	add	w5, w5, w19
1000b6d8c:     	scvtf	s0, w5
1000b6d90:     	ldp	s1, s2, [x3]
1000b6d94:     	fadd	s0, s1, s0
1000b6d98:     	str	s0, [x3]
1000b6d9c:     	ldr	w5, [x7, #4]
1000b6da0:     	and	x7, x5, #0xf
1000b6da4:     	ubfx	x19, x5, #4, #4
1000b6da8:     	ldrsb	w14, [x14, x7]
1000b6dac:     	ldrsb	w12, [x12, x19]
1000b6db0:     	ubfx	x7, x5, #8, #4
1000b6db4:     	ubfx	x19, x5, #12, #4
1000b6db8:     	ldrsb	w13, [x13, x7]
1000b6dbc:     	ldrsb	w16, [x16, x19]
1000b6dc0:     	ubfx	x7, x5, #16, #4
1000b6dc4:     	ldrsb	w15, [x15, x7]
1000b6dc8:     	add	w12, w14, w12
1000b6dcc:     	add	w12, w12, w13
1000b6dd0:     	ubfx	x13, x5, #20, #4
1000b6dd4:     	ldrsb	w13, [x17, x13]
1000b6dd8:     	add	w12, w12, w16
1000b6ddc:     	add	w12, w12, w15
1000b6de0:     	ubfx	x14, x5, #24, #4
1000b6de4:     	ldrsb	w14, [x4, x14]
1000b6de8:     	lsr	x15, x5, #28
1000b6dec:     	add	w12, w12, w13
1000b6df0:     	add	w12, w12, w14
1000b6df4:     	ldrsb	w13, [x6, x15]
1000b6df8:     	add	w12, w12, w13
1000b6dfc:     	scvtf	s1, w12
1000b6e00:     	fadd	s1, s2, s1
1000b6e04:     	str	s1, [x3, #4]
1000b6e08:     	add	x12, x10, #8
1000b6e0c:     	add	x11, x11, x8
1000b6e10:     	add	x13, x10, #16
1000b6e14:     	mov	x10, x12
1000b6e18:     	cmp	x13, x2
1000b6e1c:     	b.ls	0x1000b6cc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b6e20:     	cmp	x12, x2
1000b6e24:     	b.hs	0x1000b6ec4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x238>
1000b6e28:     	lsl	w9, w12, #2
1000b6e2c:     	mov	w10, #-16
1000b6e30:     	lsr	x11, x12, #3
1000b6e34:     	mul	x11, x8, x11
1000b6e38:     	ubfx	x13, x12, #1, #2
1000b6e3c:     	orr	x11, x11, x13
1000b6e40:     	ldrb	w11, [x1, x11]
1000b6e44:     	and	w13, w9, #0x4
1000b6e48:     	lsr	w11, w11, w13
1000b6e4c:     	and	w14, w11, #0xf
1000b6e50:     	cmp	w14, #8
1000b6e54:     	csel	w14, wzr, w10, lo
1000b6e58:     	and	x15, x12, #0xfffffffffffffff8
1000b6e5c:     	bfxil	x15, x12, #1, #2
1000b6e60:     	add	x15, x0, x15
1000b6e64:     	ldrb	w16, [x15]
1000b6e68:     	lsr	w16, w16, w13
1000b6e6c:     	bfxil	w14, w11, #0, #4
1000b6e70:     	and	w11, w16, #0xf
1000b6e74:     	cmp	w11, #8
1000b6e78:     	csel	w11, wzr, w10, lo
1000b6e7c:     	bfxil	w11, w16, #0, #4
1000b6e80:     	scvtf	s2, w14
1000b6e84:     	scvtf	s3, w11
1000b6e88:     	fmsub	s0, s3, s2, s0
1000b6e8c:     	str	s0, [x3]
1000b6e90:     	ldrb	w11, [x15, #4]
1000b6e94:     	lsr	w11, w11, w13
1000b6e98:     	and	w13, w11, #0xf
1000b6e9c:     	cmp	w13, #8
1000b6ea0:     	csel	w13, wzr, w10, lo
1000b6ea4:     	bfxil	w13, w11, #0, #4
1000b6ea8:     	scvtf	s3, w13
1000b6eac:     	fmsub	s1, s3, s2, s1
1000b6eb0:     	str	s1, [x3, #4]
1000b6eb4:     	add	x12, x12, #1
1000b6eb8:     	add	w9, w9, #4
1000b6ebc:     	cmp	x2, x12
1000b6ec0:     	b.ne	0x1000b6e30 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b6ec4:     	ldp	x20, x19, [sp, #32]
1000b6ec8:     	ldp	x22, x21, [sp, #16]
1000b6ecc:     	ldp	x24, x23, [sp], #48
1000b6ed0:     	ret

