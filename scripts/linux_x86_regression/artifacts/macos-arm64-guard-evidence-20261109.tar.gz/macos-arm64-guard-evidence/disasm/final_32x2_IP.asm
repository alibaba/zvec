00000001000d1e60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d1e60:     	sub	sp, sp, #400
1000d1e64:     	stp	x28, x27, [sp, #304]
1000d1e68:     	stp	x26, x25, [sp, #320]
1000d1e6c:     	stp	x24, x23, [sp, #336]
1000d1e70:     	stp	x22, x21, [sp, #352]
1000d1e74:     	stp	x20, x19, [sp, #368]
1000d1e78:     	stp	x29, x30, [sp, #384]
1000d1e7c:     	add	x29, sp, #384
1000d1e80:     	str	x3, [sp]
1000d1e84:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x30>
1000d1e88:     	ldr	x8, [x8, #392]
1000d1e8c:     	ldr	x8, [x8]
1000d1e90:     	stur	x8, [x29, #-96]
1000d1e94:     	movi.2d	v0, #0000000000000000
1000d1e98:     	stp	q0, q0, [sp, #256]
1000d1e9c:     	stp	q0, q0, [sp, #224]
1000d1ea0:     	stp	q0, q0, [sp, #192]
1000d1ea4:     	stp	q0, q0, [sp, #160]
1000d1ea8:     	stp	q0, q0, [sp, #128]
1000d1eac:     	stp	q0, q0, [sp, #96]
1000d1eb0:     	stp	q0, q0, [sp, #64]
1000d1eb4:     	stp	q0, q0, [sp, #32]
1000d1eb8:     	ands	x8, x2, #0xfffffffffffffffe
1000d1ebc:     	b.eq	0x1000d2040 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d1ec0:     	add	x8, x1, x8
1000d1ec4:     	str	x8, [sp, #8]
1000d1ec8:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x6c>
1000d1ecc:     	add	x9, x9, #1980
1000d1ed0:     	mov	x11, #0
1000d1ed4:     	ldp	w4, w23, [x1]
1000d1ed8:     	ubfx	x8, x4, #8, #4
1000d1edc:     	stp	x1, x8, [sp, #16]
1000d1ee0:     	ubfx	x13, x4, #16, #4
1000d1ee4:     	and	x14, x4, #0xf
1000d1ee8:     	ubfx	x15, x4, #24, #4
1000d1eec:     	ubfx	x16, x4, #4, #4
1000d1ef0:     	ubfx	x17, x4, #12, #4
1000d1ef4:     	ubfx	x2, x4, #20, #4
1000d1ef8:     	lsr	x4, x4, #28
1000d1efc:     	and	x5, x23, #0xf
1000d1f00:     	ubfx	x6, x23, #8, #4
1000d1f04:     	ubfx	x7, x23, #16, #4
1000d1f08:     	ubfx	x19, x23, #24, #4
1000d1f0c:     	ubfx	x20, x23, #4, #4
1000d1f10:     	ubfx	x21, x23, #12, #4
1000d1f14:     	ubfx	x22, x23, #20, #4
1000d1f18:     	lsr	x23, x23, #28
1000d1f1c:     	ldr	w24, [x0, x11]
1000d1f20:     	lsl	w25, w24, #4
1000d1f24:     	and	x25, x25, #0xf0
1000d1f28:     	add	x25, x9, x25
1000d1f2c:     	and	x26, x24, #0xf0
1000d1f30:     	add	x26, x9, x26
1000d1f34:     	lsr	x27, x24, #4
1000d1f38:     	and	x27, x27, #0xf0
1000d1f3c:     	add	x27, x9, x27
1000d1f40:     	lsr	x28, x24, #8
1000d1f44:     	and	x28, x28, #0xf0
1000d1f48:     	add	x28, x9, x28
1000d1f4c:     	lsr	x30, x24, #12
1000d1f50:     	and	x30, x30, #0xf0
1000d1f54:     	add	x30, x9, x30
1000d1f58:     	lsr	x8, x24, #16
1000d1f5c:     	and	x8, x8, #0xf0
1000d1f60:     	add	x8, x9, x8
1000d1f64:     	lsr	x3, x24, #20
1000d1f68:     	and	x3, x3, #0xf0
1000d1f6c:     	add	x3, x9, x3
1000d1f70:     	lsr	x24, x24, #24
1000d1f74:     	and	x24, x24, #0xf0
1000d1f78:     	ldrsb	w10, [x25, x14]
1000d1f7c:     	ldr	x12, [sp, #24]
1000d1f80:     	ldrsb	w1, [x27, x12]
1000d1f84:     	ldrsb	w12, [x30, x13]
1000d1f88:     	add	w10, w10, w1
1000d1f8c:     	add	w10, w10, w12
1000d1f90:     	ldrsb	w12, [x3, x15]
1000d1f94:     	ldrsb	w1, [x26, x16]
1000d1f98:     	add	w10, w10, w12
1000d1f9c:     	add	w10, w10, w1
1000d1fa0:     	ldrsb	w12, [x28, x17]
1000d1fa4:     	ldrsb	w1, [x8, x2]
1000d1fa8:     	add	x24, x9, x24
1000d1fac:     	add	w10, w10, w12
1000d1fb0:     	add	w10, w10, w1
1000d1fb4:     	ldrsb	w12, [x24, x4]
1000d1fb8:     	add	w10, w10, w12
1000d1fbc:     	scvtf	s0, w10
1000d1fc0:     	add	x10, sp, #32
1000d1fc4:     	add	x10, x10, x11
1000d1fc8:     	ldr	s1, [x10]
1000d1fcc:     	ldrsb	w12, [x25, x5]
1000d1fd0:     	fadd	s0, s1, s0
1000d1fd4:     	ldrsb	w1, [x27, x6]
1000d1fd8:     	ldrsb	w25, [x30, x7]
1000d1fdc:     	add	w12, w12, w1
1000d1fe0:     	add	w12, w12, w25
1000d1fe4:     	ldrsb	w1, [x3, x19]
1000d1fe8:     	ldrsb	w3, [x26, x20]
1000d1fec:     	add	w12, w12, w1
1000d1ff0:     	add	w12, w12, w3
1000d1ff4:     	ldrsb	w1, [x28, x21]
1000d1ff8:     	ldrsb	w8, [x8, x22]
1000d1ffc:     	add	w12, w12, w1
1000d2000:     	add	w8, w12, w8
1000d2004:     	ldrsb	w12, [x24, x23]
1000d2008:     	add	w8, w8, w12
1000d200c:     	scvtf	s1, w8
1000d2010:     	str	s0, [x10]
1000d2014:     	ldr	s0, [x10, #128]
1000d2018:     	fadd	s0, s0, s1
1000d201c:     	str	s0, [x10, #128]
1000d2020:     	add	x11, x11, #4
1000d2024:     	cmp	x11, #128
1000d2028:     	b.ne	0x1000d1f1c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d202c:     	add	x0, x0, #128
1000d2030:     	ldp	x8, x1, [sp, #8]
1000d2034:     	add	x1, x1, #8
1000d2038:     	cmp	x1, x8
1000d203c:     	b.ne	0x1000d1ed0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d2040:     	ldp	q0, q1, [sp, #224]
1000d2044:     	ldr	x8, [sp]
1000d2048:     	stp	q0, q1, [x8, #192]
1000d204c:     	ldp	q0, q1, [sp, #256]
1000d2050:     	stp	q0, q1, [x8, #224]
1000d2054:     	ldp	q0, q1, [sp, #160]
1000d2058:     	stp	q0, q1, [x8, #128]
1000d205c:     	ldp	q0, q1, [sp, #192]
1000d2060:     	stp	q0, q1, [x8, #160]
1000d2064:     	ldp	q0, q1, [sp, #96]
1000d2068:     	stp	q0, q1, [x8, #64]
1000d206c:     	ldp	q0, q1, [sp, #128]
1000d2070:     	stp	q0, q1, [x8, #96]
1000d2074:     	ldp	q0, q1, [sp, #32]
1000d2078:     	stp	q0, q1, [x8]
1000d207c:     	ldp	q0, q1, [sp, #64]
1000d2080:     	stp	q0, q1, [x8, #32]
1000d2084:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x22c>
1000d2088:     	ldr	x8, [x8, #392]
1000d208c:     	ldr	x8, [x8]
1000d2090:     	ldur	x9, [x29, #-96]
1000d2094:     	cmp	x8, x9
1000d2098:     	b.ne	0x1000d20bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d209c:     	ldp	x29, x30, [sp, #384]
1000d20a0:     	ldp	x20, x19, [sp, #368]
1000d20a4:     	ldp	x22, x21, [sp, #352]
1000d20a8:     	ldp	x24, x23, [sp, #336]
1000d20ac:     	ldp	x26, x25, [sp, #320]
1000d20b0:     	ldp	x28, x27, [sp, #304]
1000d20b4:     	add	sp, sp, #400
1000d20b8:     	ret
1000d20bc:     	bl	0x100163694 <_strcmp+0x100163694>

