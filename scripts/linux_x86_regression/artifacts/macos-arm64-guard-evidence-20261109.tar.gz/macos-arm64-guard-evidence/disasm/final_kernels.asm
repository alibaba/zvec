
/Users/xingrui/Documents/workspace/zvec/ivf_many_to_many/validation/macos_arm64_guard_20261109/bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000445e0 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000445e0:     	sub	sp, sp, #80
1000445e4:     	stp	x22, x21, [sp, #32]
1000445e8:     	stp	x20, x19, [sp, #48]
1000445ec:     	stp	x29, x30, [sp, #64]
1000445f0:     	add	x29, sp, #64
1000445f4:     	mov	x19, x3
1000445f8:     	mov	x20, x2
1000445fc:     	mov	x21, x1
100044600:     	mov	x22, x0
100044604:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2e0>
100044608:     	ldr	x8, [x8, #16]
10004460c:     	ldaprb	w8, [x8]
100044610:     	tbz	w8, #0, 0x10004465c <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100044614:     	stp	x21, x22, [sp, #16]
100044618:     	stp	x19, x20, [sp]
10004461c:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x2f8>
100044620:     	ldr	x8, [x8, #192]
100044624:     	ldr	x0, [x8, #24]
100044628:     	cbz	x0, 0x1000446b4 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
10004462c:     	ldr	x8, [x0]
100044630:     	ldr	x8, [x8, #48]
100044634:     	add	x1, sp, #24
100044638:     	add	x2, sp, #16
10004463c:     	add	x3, sp, #8
100044640:     	mov	x4, sp
100044644:     	blr	x8
100044648:     	ldp	x29, x30, [sp, #64]
10004464c:     	ldp	x20, x19, [sp, #48]
100044650:     	ldp	x22, x21, [sp, #32]
100044654:     	add	sp, sp, #80
100044658:     	ret
10004465c:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x338>
100044660:     	ldr	x0, [x0, #16]
100044664:     	bl	0x100163670 <_strcmp+0x100163670>
100044668:     	cbz	w0, 0x100044614 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
10004466c:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x348>
100044670:     	ldr	x8, [x8, #192]
100044674:     	mov	w0, #0
100044678:     	mov	w1, #2
10004467c:     	mov	w2, #8
100044680:     	mov	w3, #0
100044684:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
100044688:     	adrp	x0, 0x100005000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa0c>
10004468c:     	add	x0, x0, #3000
100044690:     	adrp	x1, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x36c>
100044694:     	ldr	x1, [x1, #192]
100044698:     	adrp	x2, 0x100000000 <void run<zvec::ailego::Float16, 1ul, 1ul, true>(char const*)+0xa08>
10004469c:     	add	x2, x2, #0
1000446a0:     	bl	0x100163640 <_strcmp+0x100163640>
1000446a4:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x380>
1000446a8:     	ldr	x0, [x0, #16]
1000446ac:     	bl	0x10016367c <_strcmp+0x10016367c>
1000446b0:     	b	0x100044614 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000446b4:     	bl	0x100005c04 <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000446b8:     	mov	x19, x0
1000446bc:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x398>
1000446c0:     	ldr	x0, [x0, #16]
1000446c4:     	bl	0x100163664 <_strcmp+0x100163664>
1000446c8:     	mov	x0, x19
1000446cc:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

00000001000446d4 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)>:
1000446d4:     	sub	sp, sp, #80
1000446d8:     	stp	x22, x21, [sp, #32]
1000446dc:     	stp	x20, x19, [sp, #48]
1000446e0:     	stp	x29, x30, [sp, #64]
1000446e4:     	add	x29, sp, #64
1000446e8:     	mov	x19, x3
1000446ec:     	mov	x20, x2
1000446f0:     	mov	x21, x1
1000446f4:     	mov	x22, x0
1000446f8:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3d4>
1000446fc:     	ldr	x8, [x8, #24]
100044700:     	ldaprb	w8, [x8]
100044704:     	tbz	w8, #0, 0x100044750 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x7c>
100044708:     	stp	x21, x22, [sp, #16]
10004470c:     	stp	x19, x20, [sp]
100044710:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x3ec>
100044714:     	ldr	x8, [x8, #200]
100044718:     	ldr	x0, [x8, #24]
10004471c:     	cbz	x0, 0x1000447a8 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xd4>
100044720:     	ldr	x8, [x0]
100044724:     	ldr	x8, [x8, #48]
100044728:     	add	x1, sp, #24
10004472c:     	add	x2, sp, #16
100044730:     	add	x3, sp, #8
100044734:     	mov	x4, sp
100044738:     	blr	x8
10004473c:     	ldp	x29, x30, [sp, #64]
100044740:     	ldp	x20, x19, [sp, #48]
100044744:     	ldp	x22, x21, [sp, #32]
100044748:     	add	sp, sp, #80
10004474c:     	ret
100044750:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x42c>
100044754:     	ldr	x0, [x0, #24]
100044758:     	bl	0x100163670 <_strcmp+0x100163670>
10004475c:     	cbz	w0, 0x100044708 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
100044760:     	adrp	x8, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x43c>
100044764:     	ldr	x8, [x8, #200]
100044768:     	mov	w0, #2
10004476c:     	mov	w1, #2
100044770:     	mov	w2, #8
100044774:     	mov	w3, #0
100044778:     	bl	0x1001606f8 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
10004477c:     	adrp	x0, 0x100005000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0xa0>
100044780:     	add	x0, x0, #3000
100044784:     	adrp	x1, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x460>
100044788:     	ldr	x1, [x1, #200]
10004478c:     	adrp	x2, 0x100000000 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x9c>
100044790:     	add	x2, x2, #0
100044794:     	bl	0x100163640 <_strcmp+0x100163640>
100044798:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x474>
10004479c:     	ldr	x0, [x0, #24]
1000447a0:     	bl	0x10016367c <_strcmp+0x10016367c>
1000447a4:     	b	0x100044708 <zvec::turbo::DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(zvec::ailego::Float16 const*, zvec::ailego::Float16 const*, unsigned long, float*)+0x34>
1000447a8:     	bl	0x100005c04 <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000447ac:     	mov	x19, x0
1000447b0:     	adrp	x0, 0x10016c000 <void run<zvec::ailego::Float16, 2ul, 1ul, false>(char const*)+0x48c>
1000447b4:     	ldr	x0, [x0, #24]
1000447b8:     	bl	0x100163664 <_strcmp+0x100163664>
1000447bc:     	mov	x0, x19
1000447c0:     	bl	0x1001635d4 <_strcmp+0x1001635d4>

00000001000b6a20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b6a20:     	stp	x24, x23, [sp, #-48]!
1000b6a24:     	stp	x22, x21, [sp, #16]
1000b6a28:     	stp	x20, x19, [sp, #32]
1000b6a2c:     	str	xzr, [x3]
1000b6a30:     	lsl	x8, x4, #2
1000b6a34:     	cmp	x2, #8
1000b6a38:     	b.hs	0x1000b6a4c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b6a3c:     	mov	x12, #0
1000b6a40:     	movi	d1, #0000000000000000
1000b6a44:     	movi	d0, #0000000000000000
1000b6a48:     	b	0x1000b6bb4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b6a4c:     	mov	x10, #0
1000b6a50:     	adrp	x9, 0x100169000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x90>
1000b6a54:     	add	x9, x9, #3772
1000b6a58:     	mov	x11, x1
1000b6a5c:     	ldr	w4, [x11]
1000b6a60:     	lsl	w12, w4, #4
1000b6a64:     	and	x13, x12, #0xf0
1000b6a68:     	and	x12, x4, #0xf0
1000b6a6c:     	add	x12, x9, x12
1000b6a70:     	lsr	x14, x4, #4
1000b6a74:     	and	x15, x14, #0xf0
1000b6a78:     	add	x14, x9, x13
1000b6a7c:     	add	x13, x9, x15
1000b6a80:     	lsr	x15, x4, #8
1000b6a84:     	and	x15, x15, #0xf0
1000b6a88:     	lsr	x16, x4, #12
1000b6a8c:     	and	x17, x16, #0xf0
1000b6a90:     	add	x16, x9, x15
1000b6a94:     	add	x15, x9, x17
1000b6a98:     	lsr	x17, x4, #16
1000b6a9c:     	and	x17, x17, #0xf0
1000b6aa0:     	lsr	x5, x4, #20
1000b6aa4:     	and	x5, x5, #0xf0
1000b6aa8:     	add	x17, x9, x17
1000b6aac:     	lsr	x4, x4, #24
1000b6ab0:     	and	x6, x4, #0xf0
1000b6ab4:     	add	x7, x0, x10
1000b6ab8:     	ldr	w19, [x7]
1000b6abc:     	and	x20, x19, #0xf
1000b6ac0:     	add	x4, x9, x5
1000b6ac4:     	ldrb	w5, [x14, x20]
1000b6ac8:     	ubfx	x20, x19, #4, #4
1000b6acc:     	ubfx	x21, x19, #8, #4
1000b6ad0:     	ldrb	w20, [x12, x20]
1000b6ad4:     	ldrb	w21, [x13, x21]
1000b6ad8:     	ubfx	x22, x19, #12, #4
1000b6adc:     	ubfx	x23, x19, #16, #4
1000b6ae0:     	ldrb	w22, [x16, x22]
1000b6ae4:     	ldrb	w23, [x15, x23]
1000b6ae8:     	ubfx	x24, x19, #20, #4
1000b6aec:     	ldrb	w24, [x17, x24]
1000b6af0:     	add	w5, w5, w20
1000b6af4:     	add	w5, w5, w21
1000b6af8:     	ubfx	x20, x19, #24, #4
1000b6afc:     	ldrb	w20, [x4, x20]
1000b6b00:     	add	w5, w5, w22
1000b6b04:     	add	w5, w5, w23
1000b6b08:     	add	x6, x9, x6
1000b6b0c:     	lsr	x19, x19, #28
1000b6b10:     	ldrb	w19, [x6, x19]
1000b6b14:     	add	w5, w5, w24
1000b6b18:     	add	w5, w5, w20
1000b6b1c:     	add	w5, w5, w19
1000b6b20:     	scvtf	s0, w5
1000b6b24:     	ldp	s1, s2, [x3]
1000b6b28:     	fadd	s0, s1, s0
1000b6b2c:     	str	s0, [x3]
1000b6b30:     	ldr	w5, [x7, #4]
1000b6b34:     	and	x7, x5, #0xf
1000b6b38:     	ubfx	x19, x5, #4, #4
1000b6b3c:     	ldrb	w14, [x14, x7]
1000b6b40:     	ldrb	w12, [x12, x19]
1000b6b44:     	ubfx	x7, x5, #8, #4
1000b6b48:     	ubfx	x19, x5, #12, #4
1000b6b4c:     	ldrb	w13, [x13, x7]
1000b6b50:     	ldrb	w16, [x16, x19]
1000b6b54:     	ubfx	x7, x5, #16, #4
1000b6b58:     	ldrb	w15, [x15, x7]
1000b6b5c:     	add	w12, w14, w12
1000b6b60:     	add	w12, w12, w13
1000b6b64:     	ubfx	x13, x5, #20, #4
1000b6b68:     	ldrb	w13, [x17, x13]
1000b6b6c:     	add	w12, w12, w16
1000b6b70:     	add	w12, w12, w15
1000b6b74:     	ubfx	x14, x5, #24, #4
1000b6b78:     	ldrb	w14, [x4, x14]
1000b6b7c:     	lsr	x15, x5, #28
1000b6b80:     	add	w12, w12, w13
1000b6b84:     	add	w12, w12, w14
1000b6b88:     	ldrb	w13, [x6, x15]
1000b6b8c:     	add	w12, w12, w13
1000b6b90:     	scvtf	s1, w12
1000b6b94:     	fadd	s1, s2, s1
1000b6b98:     	str	s1, [x3, #4]
1000b6b9c:     	add	x12, x10, #8
1000b6ba0:     	add	x11, x11, x8
1000b6ba4:     	add	x13, x10, #16
1000b6ba8:     	mov	x10, x12
1000b6bac:     	cmp	x13, x2
1000b6bb0:     	b.ls	0x1000b6a5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b6bb4:     	cmp	x12, x2
1000b6bb8:     	b.hs	0x1000b6c60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x240>
1000b6bbc:     	lsl	w9, w12, #2
1000b6bc0:     	mov	w10, #-16
1000b6bc4:     	lsr	x11, x12, #3
1000b6bc8:     	mul	x11, x8, x11
1000b6bcc:     	ubfx	x13, x12, #1, #2
1000b6bd0:     	orr	x11, x11, x13
1000b6bd4:     	and	w13, w9, #0x4
1000b6bd8:     	ldrb	w11, [x1, x11]
1000b6bdc:     	lsr	w11, w11, w13
1000b6be0:     	and	w14, w11, #0xf
1000b6be4:     	cmp	w14, #8
1000b6be8:     	csel	w14, wzr, w10, lo
1000b6bec:     	and	x15, x12, #0xfffffffffffffff8
1000b6bf0:     	bfxil	w14, w11, #0, #4
1000b6bf4:     	bfxil	x15, x12, #1, #2
1000b6bf8:     	add	x11, x0, x15
1000b6bfc:     	ldrb	w15, [x11]
1000b6c00:     	lsr	w15, w15, w13
1000b6c04:     	scvtf	s2, w14
1000b6c08:     	and	w14, w15, #0xf
1000b6c0c:     	cmp	w14, #8
1000b6c10:     	csel	w14, wzr, w10, lo
1000b6c14:     	bfxil	w14, w15, #0, #4
1000b6c18:     	scvtf	s3, w14
1000b6c1c:     	fsub	s3, s3, s2
1000b6c20:     	fmadd	s0, s3, s3, s0
1000b6c24:     	str	s0, [x3]
1000b6c28:     	ldrb	w11, [x11, #4]
1000b6c2c:     	lsr	w11, w11, w13
1000b6c30:     	and	w13, w11, #0xf
1000b6c34:     	cmp	w13, #8
1000b6c38:     	csel	w13, wzr, w10, lo
1000b6c3c:     	bfxil	w13, w11, #0, #4
1000b6c40:     	scvtf	s3, w13
1000b6c44:     	fsub	s2, s3, s2
1000b6c48:     	fmadd	s1, s2, s2, s1
1000b6c4c:     	str	s1, [x3, #4]
1000b6c50:     	add	x12, x12, #1
1000b6c54:     	add	w9, w9, #4
1000b6c58:     	cmp	x2, x12
1000b6c5c:     	b.ne	0x1000b6bc4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b6c60:     	ldp	x20, x19, [sp, #32]
1000b6c64:     	ldp	x22, x21, [sp, #16]
1000b6c68:     	ldp	x24, x23, [sp], #48
1000b6c6c:     	ret

00000001000b6c8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b6c8c:     	stp	x24, x23, [sp, #-48]!
1000b6c90:     	stp	x22, x21, [sp, #16]
1000b6c94:     	stp	x20, x19, [sp, #32]
1000b6c98:     	str	xzr, [x3]
1000b6c9c:     	lsl	x8, x4, #2
1000b6ca0:     	cmp	x2, #8
1000b6ca4:     	b.hs	0x1000b6cb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b6ca8:     	mov	x12, #0
1000b6cac:     	movi	d1, #0000000000000000
1000b6cb0:     	movi	d0, #0000000000000000
1000b6cb4:     	b	0x1000b6e20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x194>
1000b6cb8:     	mov	x10, #0
1000b6cbc:     	adrp	x9, 0x100169000 <void run<unsigned char, 2ul, 2ul, false>(char const*)+0xb4>
1000b6cc0:     	add	x9, x9, #4028
1000b6cc4:     	mov	x11, x1
1000b6cc8:     	ldr	w4, [x11]
1000b6ccc:     	lsl	w12, w4, #4
1000b6cd0:     	and	x13, x12, #0xf0
1000b6cd4:     	and	x12, x4, #0xf0
1000b6cd8:     	add	x12, x9, x12
1000b6cdc:     	lsr	x14, x4, #4
1000b6ce0:     	and	x15, x14, #0xf0
1000b6ce4:     	add	x14, x9, x13
1000b6ce8:     	add	x13, x9, x15
1000b6cec:     	lsr	x15, x4, #8
1000b6cf0:     	and	x15, x15, #0xf0
1000b6cf4:     	lsr	x16, x4, #12
1000b6cf8:     	and	x17, x16, #0xf0
1000b6cfc:     	add	x16, x9, x15
1000b6d00:     	add	x15, x9, x17
1000b6d04:     	lsr	x17, x4, #16
1000b6d08:     	and	x17, x17, #0xf0
1000b6d0c:     	lsr	x5, x4, #20
1000b6d10:     	and	x5, x5, #0xf0
1000b6d14:     	add	x17, x9, x17
1000b6d18:     	lsr	x4, x4, #24
1000b6d1c:     	and	x6, x4, #0xf0
1000b6d20:     	add	x7, x0, x10
1000b6d24:     	ldr	w19, [x7]
1000b6d28:     	and	x20, x19, #0xf
1000b6d2c:     	add	x4, x9, x5
1000b6d30:     	ldrsb	w5, [x14, x20]
1000b6d34:     	ubfx	x20, x19, #4, #4
1000b6d38:     	ubfx	x21, x19, #8, #4
1000b6d3c:     	ldrsb	w20, [x12, x20]
1000b6d40:     	ldrsb	w21, [x13, x21]
1000b6d44:     	ubfx	x22, x19, #12, #4
1000b6d48:     	ubfx	x23, x19, #16, #4
1000b6d4c:     	ldrsb	w22, [x16, x22]
1000b6d50:     	ldrsb	w23, [x15, x23]
1000b6d54:     	ubfx	x24, x19, #20, #4
1000b6d58:     	ldrsb	w24, [x17, x24]
1000b6d5c:     	add	w5, w5, w20
1000b6d60:     	add	w5, w5, w21
1000b6d64:     	ubfx	x20, x19, #24, #4
1000b6d68:     	ldrsb	w20, [x4, x20]
1000b6d6c:     	add	w5, w5, w22
1000b6d70:     	add	w5, w5, w23
1000b6d74:     	add	x6, x9, x6
1000b6d78:     	lsr	x19, x19, #28
1000b6d7c:     	ldrsb	w19, [x6, x19]
1000b6d80:     	add	w5, w5, w24
1000b6d84:     	add	w5, w5, w20
1000b6d88:     	add	w5, w5, w19
1000b6d8c:     	scvtf	s0, w5
1000b6d90:     	ldp	s1, s2, [x3]
1000b6d94:     	fadd	s0, s1, s0
1000b6d98:     	str	s0, [x3]
1000b6d9c:     	ldr	w5, [x7, #4]
1000b6da0:     	and	x7, x5, #0xf
1000b6da4:     	ubfx	x19, x5, #4, #4
1000b6da8:     	ldrsb	w14, [x14, x7]
1000b6dac:     	ldrsb	w12, [x12, x19]
1000b6db0:     	ubfx	x7, x5, #8, #4
1000b6db4:     	ubfx	x19, x5, #12, #4
1000b6db8:     	ldrsb	w13, [x13, x7]
1000b6dbc:     	ldrsb	w16, [x16, x19]
1000b6dc0:     	ubfx	x7, x5, #16, #4
1000b6dc4:     	ldrsb	w15, [x15, x7]
1000b6dc8:     	add	w12, w14, w12
1000b6dcc:     	add	w12, w12, w13
1000b6dd0:     	ubfx	x13, x5, #20, #4
1000b6dd4:     	ldrsb	w13, [x17, x13]
1000b6dd8:     	add	w12, w12, w16
1000b6ddc:     	add	w12, w12, w15
1000b6de0:     	ubfx	x14, x5, #24, #4
1000b6de4:     	ldrsb	w14, [x4, x14]
1000b6de8:     	lsr	x15, x5, #28
1000b6dec:     	add	w12, w12, w13
1000b6df0:     	add	w12, w12, w14
1000b6df4:     	ldrsb	w13, [x6, x15]
1000b6df8:     	add	w12, w12, w13
1000b6dfc:     	scvtf	s1, w12
1000b6e00:     	fadd	s1, s2, s1
1000b6e04:     	str	s1, [x3, #4]
1000b6e08:     	add	x12, x10, #8
1000b6e0c:     	add	x11, x11, x8
1000b6e10:     	add	x13, x10, #16
1000b6e14:     	mov	x10, x12
1000b6e18:     	cmp	x13, x2
1000b6e1c:     	b.ls	0x1000b6cc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000b6e20:     	cmp	x12, x2
1000b6e24:     	b.hs	0x1000b6ec4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x238>
1000b6e28:     	lsl	w9, w12, #2
1000b6e2c:     	mov	w10, #-16
1000b6e30:     	lsr	x11, x12, #3
1000b6e34:     	mul	x11, x8, x11
1000b6e38:     	ubfx	x13, x12, #1, #2
1000b6e3c:     	orr	x11, x11, x13
1000b6e40:     	ldrb	w11, [x1, x11]
1000b6e44:     	and	w13, w9, #0x4
1000b6e48:     	lsr	w11, w11, w13
1000b6e4c:     	and	w14, w11, #0xf
1000b6e50:     	cmp	w14, #8
1000b6e54:     	csel	w14, wzr, w10, lo
1000b6e58:     	and	x15, x12, #0xfffffffffffffff8
1000b6e5c:     	bfxil	x15, x12, #1, #2
1000b6e60:     	add	x15, x0, x15
1000b6e64:     	ldrb	w16, [x15]
1000b6e68:     	lsr	w16, w16, w13
1000b6e6c:     	bfxil	w14, w11, #0, #4
1000b6e70:     	and	w11, w16, #0xf
1000b6e74:     	cmp	w11, #8
1000b6e78:     	csel	w11, wzr, w10, lo
1000b6e7c:     	bfxil	w11, w16, #0, #4
1000b6e80:     	scvtf	s2, w14
1000b6e84:     	scvtf	s3, w11
1000b6e88:     	fmsub	s0, s3, s2, s0
1000b6e8c:     	str	s0, [x3]
1000b6e90:     	ldrb	w11, [x15, #4]
1000b6e94:     	lsr	w11, w11, w13
1000b6e98:     	and	w13, w11, #0xf
1000b6e9c:     	cmp	w13, #8
1000b6ea0:     	csel	w13, wzr, w10, lo
1000b6ea4:     	bfxil	w13, w11, #0, #4
1000b6ea8:     	scvtf	s3, w13
1000b6eac:     	fmsub	s1, s3, s2, s1
1000b6eb0:     	str	s1, [x3, #4]
1000b6eb4:     	add	x12, x12, #1
1000b6eb8:     	add	w9, w9, #4
1000b6ebc:     	cmp	x2, x12
1000b6ec0:     	b.ne	0x1000b6e30 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1a4>
1000b6ec4:     	ldp	x20, x19, [sp, #32]
1000b6ec8:     	ldp	x22, x21, [sp, #16]
1000b6ecc:     	ldp	x24, x23, [sp], #48
1000b6ed0:     	ret

00000001000b858c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b858c:     	stp	x22, x21, [sp, #-32]!
1000b8590:     	stp	x20, x19, [sp, #16]
1000b8594:     	ands	x8, x2, #0xfffffffffffffffe
1000b8598:     	b.eq	0x1000b881c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b859c:     	add	x8, x1, x8
1000b85a0:     	movi	d0, #0000000000000000
1000b85a4:     	adrp	x9, 0x100169000 <void kernel<unsigned char, 2ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x20>
1000b85a8:     	add	x9, x9, #3772
1000b85ac:     	movi	d1, #0000000000000000
1000b85b0:     	movi	d2, #0000000000000000
1000b85b4:     	movi	d3, #0000000000000000
1000b85b8:     	ldp	w10, w11, [x0]
1000b85bc:     	lsl	w12, w10, #4
1000b85c0:     	and	x14, x12, #0xf0
1000b85c4:     	mov	x15, x14
1000b85c8:     	ldp	w12, w13, [x1]
1000b85cc:     	bfxil	x15, x12, #0, #4
1000b85d0:     	ldrb	w15, [x9, x15]
1000b85d4:     	and	x16, x10, #0xf0
1000b85d8:     	mov	x17, x16
1000b85dc:     	bfxil	x17, x12, #4, #4
1000b85e0:     	ldrb	w17, [x9, x17]
1000b85e4:     	lsr	x2, x10, #4
1000b85e8:     	and	x2, x2, #0xf0
1000b85ec:     	mov	x4, x2
1000b85f0:     	bfxil	x4, x12, #8, #4
1000b85f4:     	ldrb	w4, [x9, x4]
1000b85f8:     	lsr	x5, x10, #8
1000b85fc:     	and	x5, x5, #0xf0
1000b8600:     	mov	x6, x5
1000b8604:     	bfxil	x6, x12, #12, #4
1000b8608:     	ldrb	w6, [x9, x6]
1000b860c:     	lsr	x7, x10, #12
1000b8610:     	and	x7, x7, #0xf0
1000b8614:     	mov	x19, x7
1000b8618:     	bfxil	x19, x12, #16, #4
1000b861c:     	ldrb	w19, [x9, x19]
1000b8620:     	add	w15, w15, w17
1000b8624:     	add	w15, w15, w4
1000b8628:     	lsr	x17, x10, #16
1000b862c:     	and	x17, x17, #0xf0
1000b8630:     	mov	x4, x17
1000b8634:     	bfxil	x4, x12, #20, #4
1000b8638:     	add	w15, w15, w6
1000b863c:     	add	w15, w15, w19
1000b8640:     	ldrb	w4, [x9, x4]
1000b8644:     	lsr	x6, x10, #20
1000b8648:     	and	x6, x6, #0xf0
1000b864c:     	mov	x19, x6
1000b8650:     	bfxil	x19, x12, #24, #4
1000b8654:     	ldrb	w19, [x9, x19]
1000b8658:     	add	w15, w15, w4
1000b865c:     	add	w15, w15, w19
1000b8660:     	lsr	x10, x10, #24
1000b8664:     	and	x4, x10, #0xf0
1000b8668:     	lsr	x10, x12, #28
1000b866c:     	orr	x19, x4, x10
1000b8670:     	ldrb	w19, [x9, x19]
1000b8674:     	add	w15, w15, w19
1000b8678:     	scvtf	s4, w15
1000b867c:     	fadd	s0, s0, s4
1000b8680:     	bfxil	x14, x13, #0, #4
1000b8684:     	ldrb	w14, [x9, x14]
1000b8688:     	and	x15, x13, #0xf
1000b868c:     	ubfx	x19, x13, #4, #4
1000b8690:     	bfxil	x16, x13, #4, #4
1000b8694:     	ldrb	w16, [x9, x16]
1000b8698:     	ubfx	x20, x13, #8, #4
1000b869c:     	bfxil	x2, x13, #8, #4
1000b86a0:     	ldrb	w2, [x9, x2]
1000b86a4:     	add	w14, w14, w16
1000b86a8:     	add	w14, w14, w2
1000b86ac:     	ubfx	x16, x13, #12, #4
1000b86b0:     	bfxil	x5, x13, #12, #4
1000b86b4:     	ldrb	w2, [x9, x5]
1000b86b8:     	bfxil	x7, x13, #16, #4
1000b86bc:     	ldrb	w5, [x9, x7]
1000b86c0:     	ubfx	x7, x13, #16, #4
1000b86c4:     	add	w14, w14, w2
1000b86c8:     	add	w14, w14, w5
1000b86cc:     	bfxil	x17, x13, #20, #4
1000b86d0:     	ldrb	w17, [x9, x17]
1000b86d4:     	bfxil	x6, x13, #24, #4
1000b86d8:     	ldrb	w2, [x9, x6]
1000b86dc:     	add	w14, w14, w17
1000b86e0:     	add	w17, w14, w2
1000b86e4:     	lsr	x14, x13, #28
1000b86e8:     	orr	x2, x4, x14
1000b86ec:     	ldrb	w2, [x9, x2]
1000b86f0:     	add	w17, w17, w2
1000b86f4:     	scvtf	s4, w17
1000b86f8:     	ubfx	x17, x13, #20, #4
1000b86fc:     	fadd	s2, s2, s4
1000b8700:     	lsl	w2, w11, #4
1000b8704:     	and	x2, x2, #0xf0
1000b8708:     	orr	w15, w2, w15
1000b870c:     	bfxil	x2, x12, #0, #4
1000b8710:     	ldrb	w2, [x9, x2]
1000b8714:     	and	x4, x11, #0xf0
1000b8718:     	orr	w5, w4, w19
1000b871c:     	bfxil	x4, x12, #4, #4
1000b8720:     	ldrb	w4, [x9, x4]
1000b8724:     	lsr	x6, x11, #4
1000b8728:     	and	x6, x6, #0xf0
1000b872c:     	orr	w19, w6, w20
1000b8730:     	bfxil	x6, x12, #8, #4
1000b8734:     	ldrb	w6, [x9, x6]
1000b8738:     	add	w2, w2, w4
1000b873c:     	add	w2, w2, w6
1000b8740:     	lsr	x4, x11, #8
1000b8744:     	and	x4, x4, #0xf0
1000b8748:     	orr	w16, w4, w16
1000b874c:     	lsr	x6, x11, #12
1000b8750:     	and	x6, x6, #0xf0
1000b8754:     	orr	w7, w6, w7
1000b8758:     	lsr	x20, x11, #16
1000b875c:     	and	x20, x20, #0xf0
1000b8760:     	orr	w17, w20, w17
1000b8764:     	lsr	x21, x11, #20
1000b8768:     	and	x21, x21, #0xf0
1000b876c:     	ubfx	x13, x13, #24, #4
1000b8770:     	orr	w13, w21, w13
1000b8774:     	bfxil	x4, x12, #12, #4
1000b8778:     	ldrb	w4, [x9, x4]
1000b877c:     	bfxil	x6, x12, #16, #4
1000b8780:     	ldrb	w6, [x9, x6]
1000b8784:     	bfxil	x20, x12, #20, #4
1000b8788:     	ldrb	w20, [x9, x20]
1000b878c:     	bfxil	x21, x12, #24, #4
1000b8790:     	ldrb	w12, [x9, x21]
1000b8794:     	add	w2, w2, w4
1000b8798:     	add	w2, w2, w6
1000b879c:     	add	w2, w2, w20
1000b87a0:     	add	w12, w2, w12
1000b87a4:     	lsr	x11, x11, #24
1000b87a8:     	and	x11, x11, #0xf0
1000b87ac:     	orr	x10, x11, x10
1000b87b0:     	ldrb	w10, [x9, x10]
1000b87b4:     	add	w10, w12, w10
1000b87b8:     	scvtf	s4, w10
1000b87bc:     	fadd	s1, s1, s4
1000b87c0:     	ldrb	w10, [x9, w15, uxtw]
1000b87c4:     	ldrb	w12, [x9, w5, uxtw]
1000b87c8:     	ldrb	w15, [x9, w19, uxtw]
1000b87cc:     	add	w10, w10, w12
1000b87d0:     	add	w10, w10, w15
1000b87d4:     	ldrb	w12, [x9, w16, uxtw]
1000b87d8:     	ldrb	w15, [x9, w7, uxtw]
1000b87dc:     	add	w10, w10, w12
1000b87e0:     	add	w10, w10, w15
1000b87e4:     	ldrb	w12, [x9, w17, uxtw]
1000b87e8:     	ldrb	w13, [x9, w13, uxtw]
1000b87ec:     	add	w10, w10, w12
1000b87f0:     	add	w10, w10, w13
1000b87f4:     	orr	w11, w11, w14
1000b87f8:     	ldrb	w11, [x9, w11, uxtw]
1000b87fc:     	add	w10, w10, w11
1000b8800:     	scvtf	s4, w10
1000b8804:     	fadd	s3, s3, s4
1000b8808:     	add	x0, x0, #8
1000b880c:     	add	x1, x1, #8
1000b8810:     	cmp	x1, x8
1000b8814:     	b.ne	0x1000b85b8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8818:     	b	0x1000b882c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b881c:     	movi	d0, #0000000000000000
1000b8820:     	movi	d1, #0000000000000000
1000b8824:     	movi	d2, #0000000000000000
1000b8828:     	movi	d3, #0000000000000000
1000b882c:     	str	s0, [x3]
1000b8830:     	str	s1, [x3, #4]
1000b8834:     	str	s2, [x3, #8]
1000b8838:     	str	s3, [x3, #12]
1000b883c:     	ldp	x20, x19, [sp, #16]
1000b8840:     	ldp	x22, x21, [sp], #32
1000b8844:     	ret

00000001000b88f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b88f4:     	stp	x22, x21, [sp, #-32]!
1000b88f8:     	stp	x20, x19, [sp, #16]
1000b88fc:     	ands	x8, x2, #0xfffffffffffffffe
1000b8900:     	b.eq	0x1000b8b84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b8904:     	add	x8, x1, x8
1000b8908:     	movi	d0, #0000000000000000
1000b890c:     	adrp	x9, 0x100169000 <void run<unsigned char, 4ul, 1ul, false>(char const*)+0x20>
1000b8910:     	add	x9, x9, #4028
1000b8914:     	movi	d1, #0000000000000000
1000b8918:     	movi	d2, #0000000000000000
1000b891c:     	movi	d3, #0000000000000000
1000b8920:     	ldp	w10, w11, [x0]
1000b8924:     	lsl	w12, w10, #4
1000b8928:     	and	x14, x12, #0xf0
1000b892c:     	mov	x15, x14
1000b8930:     	ldp	w12, w13, [x1]
1000b8934:     	bfxil	x15, x12, #0, #4
1000b8938:     	ldrsb	w15, [x9, x15]
1000b893c:     	and	x16, x10, #0xf0
1000b8940:     	mov	x17, x16
1000b8944:     	bfxil	x17, x12, #4, #4
1000b8948:     	ldrsb	w17, [x9, x17]
1000b894c:     	lsr	x2, x10, #4
1000b8950:     	and	x2, x2, #0xf0
1000b8954:     	mov	x4, x2
1000b8958:     	bfxil	x4, x12, #8, #4
1000b895c:     	ldrsb	w4, [x9, x4]
1000b8960:     	lsr	x5, x10, #8
1000b8964:     	and	x5, x5, #0xf0
1000b8968:     	mov	x6, x5
1000b896c:     	bfxil	x6, x12, #12, #4
1000b8970:     	ldrsb	w6, [x9, x6]
1000b8974:     	lsr	x7, x10, #12
1000b8978:     	and	x7, x7, #0xf0
1000b897c:     	mov	x19, x7
1000b8980:     	bfxil	x19, x12, #16, #4
1000b8984:     	ldrsb	w19, [x9, x19]
1000b8988:     	add	w15, w15, w17
1000b898c:     	add	w15, w15, w4
1000b8990:     	lsr	x17, x10, #16
1000b8994:     	and	x17, x17, #0xf0
1000b8998:     	mov	x4, x17
1000b899c:     	bfxil	x4, x12, #20, #4
1000b89a0:     	add	w15, w15, w6
1000b89a4:     	add	w15, w15, w19
1000b89a8:     	ldrsb	w4, [x9, x4]
1000b89ac:     	lsr	x6, x10, #20
1000b89b0:     	and	x6, x6, #0xf0
1000b89b4:     	mov	x19, x6
1000b89b8:     	bfxil	x19, x12, #24, #4
1000b89bc:     	ldrsb	w19, [x9, x19]
1000b89c0:     	add	w15, w15, w4
1000b89c4:     	add	w15, w15, w19
1000b89c8:     	lsr	x10, x10, #24
1000b89cc:     	and	x4, x10, #0xf0
1000b89d0:     	lsr	x10, x12, #28
1000b89d4:     	orr	x19, x4, x10
1000b89d8:     	ldrsb	w19, [x9, x19]
1000b89dc:     	add	w15, w15, w19
1000b89e0:     	scvtf	s4, w15
1000b89e4:     	fadd	s0, s0, s4
1000b89e8:     	bfxil	x14, x13, #0, #4
1000b89ec:     	ldrsb	w14, [x9, x14]
1000b89f0:     	and	x15, x13, #0xf
1000b89f4:     	ubfx	x19, x13, #4, #4
1000b89f8:     	bfxil	x16, x13, #4, #4
1000b89fc:     	ldrsb	w16, [x9, x16]
1000b8a00:     	ubfx	x20, x13, #8, #4
1000b8a04:     	bfxil	x2, x13, #8, #4
1000b8a08:     	ldrsb	w2, [x9, x2]
1000b8a0c:     	add	w14, w14, w16
1000b8a10:     	add	w14, w14, w2
1000b8a14:     	ubfx	x16, x13, #12, #4
1000b8a18:     	bfxil	x5, x13, #12, #4
1000b8a1c:     	ldrsb	w2, [x9, x5]
1000b8a20:     	bfxil	x7, x13, #16, #4
1000b8a24:     	ldrsb	w5, [x9, x7]
1000b8a28:     	ubfx	x7, x13, #16, #4
1000b8a2c:     	add	w14, w14, w2
1000b8a30:     	add	w14, w14, w5
1000b8a34:     	bfxil	x17, x13, #20, #4
1000b8a38:     	ldrsb	w17, [x9, x17]
1000b8a3c:     	bfxil	x6, x13, #24, #4
1000b8a40:     	ldrsb	w2, [x9, x6]
1000b8a44:     	add	w14, w14, w17
1000b8a48:     	add	w17, w14, w2
1000b8a4c:     	lsr	x14, x13, #28
1000b8a50:     	orr	x2, x4, x14
1000b8a54:     	ldrsb	w2, [x9, x2]
1000b8a58:     	add	w17, w17, w2
1000b8a5c:     	scvtf	s4, w17
1000b8a60:     	ubfx	x17, x13, #20, #4
1000b8a64:     	fadd	s2, s2, s4
1000b8a68:     	lsl	w2, w11, #4
1000b8a6c:     	and	x2, x2, #0xf0
1000b8a70:     	orr	w15, w2, w15
1000b8a74:     	bfxil	x2, x12, #0, #4
1000b8a78:     	ldrsb	w2, [x9, x2]
1000b8a7c:     	and	x4, x11, #0xf0
1000b8a80:     	orr	w5, w4, w19
1000b8a84:     	bfxil	x4, x12, #4, #4
1000b8a88:     	ldrsb	w4, [x9, x4]
1000b8a8c:     	lsr	x6, x11, #4
1000b8a90:     	and	x6, x6, #0xf0
1000b8a94:     	orr	w19, w6, w20
1000b8a98:     	bfxil	x6, x12, #8, #4
1000b8a9c:     	ldrsb	w6, [x9, x6]
1000b8aa0:     	add	w2, w2, w4
1000b8aa4:     	add	w2, w2, w6
1000b8aa8:     	lsr	x4, x11, #8
1000b8aac:     	and	x4, x4, #0xf0
1000b8ab0:     	orr	w16, w4, w16
1000b8ab4:     	lsr	x6, x11, #12
1000b8ab8:     	and	x6, x6, #0xf0
1000b8abc:     	orr	w7, w6, w7
1000b8ac0:     	lsr	x20, x11, #16
1000b8ac4:     	and	x20, x20, #0xf0
1000b8ac8:     	orr	w17, w20, w17
1000b8acc:     	lsr	x21, x11, #20
1000b8ad0:     	and	x21, x21, #0xf0
1000b8ad4:     	ubfx	x13, x13, #24, #4
1000b8ad8:     	orr	w13, w21, w13
1000b8adc:     	bfxil	x4, x12, #12, #4
1000b8ae0:     	ldrsb	w4, [x9, x4]
1000b8ae4:     	bfxil	x6, x12, #16, #4
1000b8ae8:     	ldrsb	w6, [x9, x6]
1000b8aec:     	bfxil	x20, x12, #20, #4
1000b8af0:     	ldrsb	w20, [x9, x20]
1000b8af4:     	bfxil	x21, x12, #24, #4
1000b8af8:     	ldrsb	w12, [x9, x21]
1000b8afc:     	add	w2, w2, w4
1000b8b00:     	add	w2, w2, w6
1000b8b04:     	add	w2, w2, w20
1000b8b08:     	add	w12, w2, w12
1000b8b0c:     	lsr	x11, x11, #24
1000b8b10:     	and	x11, x11, #0xf0
1000b8b14:     	orr	x10, x11, x10
1000b8b18:     	ldrsb	w10, [x9, x10]
1000b8b1c:     	add	w10, w12, w10
1000b8b20:     	scvtf	s4, w10
1000b8b24:     	fadd	s1, s1, s4
1000b8b28:     	ldrsb	w10, [x9, w15, uxtw]
1000b8b2c:     	ldrsb	w12, [x9, w5, uxtw]
1000b8b30:     	ldrsb	w15, [x9, w19, uxtw]
1000b8b34:     	add	w10, w10, w12
1000b8b38:     	add	w10, w10, w15
1000b8b3c:     	ldrsb	w12, [x9, w16, uxtw]
1000b8b40:     	ldrsb	w15, [x9, w7, uxtw]
1000b8b44:     	add	w10, w10, w12
1000b8b48:     	add	w10, w10, w15
1000b8b4c:     	ldrsb	w12, [x9, w17, uxtw]
1000b8b50:     	ldrsb	w13, [x9, w13, uxtw]
1000b8b54:     	add	w10, w10, w12
1000b8b58:     	add	w10, w10, w13
1000b8b5c:     	orr	w11, w11, w14
1000b8b60:     	ldrsb	w11, [x9, w11, uxtw]
1000b8b64:     	add	w10, w10, w11
1000b8b68:     	scvtf	s4, w10
1000b8b6c:     	fadd	s3, s3, s4
1000b8b70:     	add	x0, x0, #8
1000b8b74:     	add	x1, x1, #8
1000b8b78:     	cmp	x1, x8
1000b8b7c:     	b.ne	0x1000b8920 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8b80:     	b	0x1000b8b94 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b8b84:     	movi	d0, #0000000000000000
1000b8b88:     	movi	d1, #0000000000000000
1000b8b8c:     	movi	d2, #0000000000000000
1000b8b90:     	movi	d3, #0000000000000000
1000b8b94:     	str	s0, [x3]
1000b8b98:     	str	s1, [x3, #4]
1000b8b9c:     	str	s2, [x3, #8]
1000b8ba0:     	str	s3, [x3, #12]
1000b8ba4:     	ldp	x20, x19, [sp, #16]
1000b8ba8:     	ldp	x22, x21, [sp], #32
1000b8bac:     	ret

00000001000b9e84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000b9e84:     	stp	x24, x23, [sp, #-48]!
1000b9e88:     	stp	x22, x21, [sp, #16]
1000b9e8c:     	stp	x20, x19, [sp, #32]
1000b9e90:     	stp	xzr, xzr, [x3]
1000b9e94:     	lsl	x8, x4, #2
1000b9e98:     	cmp	x2, #8
1000b9e9c:     	b.hs	0x1000b9eb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000b9ea0:     	mov	x13, #0
1000b9ea4:     	movi	d1, #0000000000000000
1000b9ea8:     	movi	d0, #0000000000000000
1000b9eac:     	b	0x1000ba0f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000b9eb0:     	mov	x10, #0
1000b9eb4:     	add	x9, x0, #8
1000b9eb8:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f8>
1000b9ebc:     	add	x11, x11, #188
1000b9ec0:     	mov	x12, x1
1000b9ec4:     	ldr	w5, [x12]
1000b9ec8:     	lsl	w13, w5, #4
1000b9ecc:     	and	x14, x13, #0xf0
1000b9ed0:     	and	x13, x5, #0xf0
1000b9ed4:     	add	x13, x11, x13
1000b9ed8:     	add	x14, x11, x14
1000b9edc:     	lsr	x15, x5, #4
1000b9ee0:     	and	x15, x15, #0xf0
1000b9ee4:     	add	x15, x11, x15
1000b9ee8:     	lsr	x16, x5, #8
1000b9eec:     	and	x16, x16, #0xf0
1000b9ef0:     	add	x16, x11, x16
1000b9ef4:     	lsr	x17, x5, #12
1000b9ef8:     	and	x17, x17, #0xf0
1000b9efc:     	add	x17, x11, x17
1000b9f00:     	lsr	x4, x5, #16
1000b9f04:     	and	x4, x4, #0xf0
1000b9f08:     	add	x4, x11, x4
1000b9f0c:     	lsr	x6, x5, #20
1000b9f10:     	and	x6, x6, #0xf0
1000b9f14:     	lsr	x5, x5, #24
1000b9f18:     	and	x7, x5, #0xf0
1000b9f1c:     	ldur	w19, [x9, #-8]
1000b9f20:     	add	x5, x11, x6
1000b9f24:     	and	x6, x19, #0xf
1000b9f28:     	ubfx	x20, x19, #4, #4
1000b9f2c:     	ldrb	w20, [x13, x20]
1000b9f30:     	ldrb	w21, [x14, x6]
1000b9f34:     	ubfx	x6, x19, #8, #4
1000b9f38:     	ldrb	w22, [x15, x6]
1000b9f3c:     	ubfx	x6, x19, #12, #4
1000b9f40:     	ldrb	w23, [x16, x6]
1000b9f44:     	add	x6, x11, x7
1000b9f48:     	ubfx	x7, x19, #16, #4
1000b9f4c:     	ldrb	w7, [x17, x7]
1000b9f50:     	add	w20, w21, w20
1000b9f54:     	add	w20, w20, w22
1000b9f58:     	ubfx	x21, x19, #20, #4
1000b9f5c:     	ldrb	w21, [x4, x21]
1000b9f60:     	ubfx	x22, x19, #24, #4
1000b9f64:     	add	w20, w20, w23
1000b9f68:     	add	w7, w20, w7
1000b9f6c:     	ldrb	w20, [x5, x22]
1000b9f70:     	lsr	x19, x19, #28
1000b9f74:     	ldrb	w19, [x6, x19]
1000b9f78:     	add	w7, w7, w21
1000b9f7c:     	add	w7, w7, w20
1000b9f80:     	add	w7, w7, w19
1000b9f84:     	scvtf	s0, w7
1000b9f88:     	ldp	s1, s2, [x3]
1000b9f8c:     	fadd	s0, s1, s0
1000b9f90:     	str	s0, [x3]
1000b9f94:     	ldur	w7, [x9, #-4]
1000b9f98:     	and	x19, x7, #0xf
1000b9f9c:     	ldrb	w19, [x14, x19]
1000b9fa0:     	ubfx	x20, x7, #4, #4
1000b9fa4:     	ldrb	w20, [x13, x20]
1000b9fa8:     	ubfx	x21, x7, #8, #4
1000b9fac:     	ldrb	w21, [x15, x21]
1000b9fb0:     	ubfx	x22, x7, #12, #4
1000b9fb4:     	ldrb	w22, [x16, x22]
1000b9fb8:     	ubfx	x23, x7, #16, #4
1000b9fbc:     	add	w19, w19, w20
1000b9fc0:     	add	w19, w19, w21
1000b9fc4:     	ldrb	w20, [x17, x23]
1000b9fc8:     	ubfx	x21, x7, #20, #4
1000b9fcc:     	ldrb	w21, [x4, x21]
1000b9fd0:     	add	w19, w19, w22
1000b9fd4:     	add	w19, w19, w20
1000b9fd8:     	ubfx	x20, x7, #24, #4
1000b9fdc:     	ldrb	w20, [x5, x20]
1000b9fe0:     	add	w19, w19, w21
1000b9fe4:     	add	w19, w19, w20
1000b9fe8:     	lsr	x7, x7, #28
1000b9fec:     	ldrb	w7, [x6, x7]
1000b9ff0:     	add	w7, w19, w7
1000b9ff4:     	scvtf	s0, w7
1000b9ff8:     	fadd	s0, s2, s0
1000b9ffc:     	str	s0, [x3, #4]
1000ba000:     	ldr	w7, [x9]
1000ba004:     	and	x19, x7, #0xf
1000ba008:     	ldrb	w19, [x14, x19]
1000ba00c:     	ubfx	x20, x7, #4, #4
1000ba010:     	ldrb	w20, [x13, x20]
1000ba014:     	ubfx	x21, x7, #8, #4
1000ba018:     	ldrb	w21, [x15, x21]
1000ba01c:     	ubfx	x22, x7, #12, #4
1000ba020:     	ldrb	w22, [x16, x22]
1000ba024:     	ubfx	x23, x7, #16, #4
1000ba028:     	add	w19, w19, w20
1000ba02c:     	add	w19, w19, w21
1000ba030:     	ldrb	w20, [x17, x23]
1000ba034:     	ubfx	x21, x7, #20, #4
1000ba038:     	ldrb	w21, [x4, x21]
1000ba03c:     	add	w19, w19, w22
1000ba040:     	add	w19, w19, w20
1000ba044:     	ubfx	x20, x7, #24, #4
1000ba048:     	ldrb	w20, [x5, x20]
1000ba04c:     	add	w19, w19, w21
1000ba050:     	add	w19, w19, w20
1000ba054:     	lsr	x7, x7, #28
1000ba058:     	ldrb	w7, [x6, x7]
1000ba05c:     	add	w7, w19, w7
1000ba060:     	scvtf	s0, w7
1000ba064:     	ldp	s1, s2, [x3, #8]
1000ba068:     	fadd	s0, s1, s0
1000ba06c:     	str	s0, [x3, #8]
1000ba070:     	ldr	w7, [x9, #4]
1000ba074:     	and	x19, x7, #0xf
1000ba078:     	ldrb	w14, [x14, x19]
1000ba07c:     	ubfx	x19, x7, #4, #4
1000ba080:     	ldrb	w13, [x13, x19]
1000ba084:     	ubfx	x19, x7, #8, #4
1000ba088:     	ldrb	w15, [x15, x19]
1000ba08c:     	ubfx	x19, x7, #12, #4
1000ba090:     	ldrb	w16, [x16, x19]
1000ba094:     	ubfx	x19, x7, #16, #4
1000ba098:     	ldrb	w17, [x17, x19]
1000ba09c:     	add	w13, w14, w13
1000ba0a0:     	add	w13, w13, w15
1000ba0a4:     	ubfx	x14, x7, #20, #4
1000ba0a8:     	ldrb	w14, [x4, x14]
1000ba0ac:     	ubfx	x15, x7, #24, #4
1000ba0b0:     	add	w13, w13, w16
1000ba0b4:     	add	w13, w13, w17
1000ba0b8:     	ldrb	w15, [x5, x15]
1000ba0bc:     	lsr	x16, x7, #28
1000ba0c0:     	ldrb	w16, [x6, x16]
1000ba0c4:     	add	w13, w13, w14
1000ba0c8:     	add	w13, w13, w15
1000ba0cc:     	add	w13, w13, w16
1000ba0d0:     	scvtf	s1, w13
1000ba0d4:     	fadd	s1, s2, s1
1000ba0d8:     	str	s1, [x3, #12]
1000ba0dc:     	add	x13, x10, #8
1000ba0e0:     	add	x12, x12, x8
1000ba0e4:     	add	x9, x9, #16
1000ba0e8:     	add	x14, x10, #16
1000ba0ec:     	mov	x10, x13
1000ba0f0:     	cmp	x14, x2
1000ba0f4:     	b.ls	0x1000b9ec4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000ba0f8:     	cmp	x13, x2
1000ba0fc:     	b.hs	0x1000ba1f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x370>
1000ba100:     	ldp	s2, s3, [x3]
1000ba104:     	lsl	w9, w13, #2
1000ba108:     	mov	w10, #-16
1000ba10c:     	lsr	x11, x13, #3
1000ba110:     	mul	x12, x8, x11
1000ba114:     	ubfx	x14, x13, #1, #2
1000ba118:     	orr	x12, x12, x14
1000ba11c:     	ldrb	w12, [x1, x12]
1000ba120:     	and	w15, w9, #0x4
1000ba124:     	lsr	w12, w12, w15
1000ba128:     	and	w16, w12, #0xf
1000ba12c:     	cmp	w16, #8
1000ba130:     	csel	w16, wzr, w10, lo
1000ba134:     	bfxil	w16, w12, #0, #4
1000ba138:     	bfi	x14, x11, #4, #60
1000ba13c:     	add	x11, x0, x14
1000ba140:     	ldrb	w12, [x11]
1000ba144:     	lsr	w12, w12, w15
1000ba148:     	scvtf	s4, w16
1000ba14c:     	and	w14, w12, #0xf
1000ba150:     	cmp	w14, #8
1000ba154:     	csel	w14, wzr, w10, lo
1000ba158:     	bfxil	w14, w12, #0, #4
1000ba15c:     	scvtf	s5, w14
1000ba160:     	fsub	s5, s5, s4
1000ba164:     	fmadd	s2, s5, s5, s2
1000ba168:     	str	s2, [x3]
1000ba16c:     	ldrb	w12, [x11, #4]
1000ba170:     	lsr	w12, w12, w15
1000ba174:     	and	w14, w12, #0xf
1000ba178:     	cmp	w14, #8
1000ba17c:     	csel	w14, wzr, w10, lo
1000ba180:     	bfxil	w14, w12, #0, #4
1000ba184:     	scvtf	s5, w14
1000ba188:     	fsub	s5, s5, s4
1000ba18c:     	fmadd	s3, s5, s5, s3
1000ba190:     	str	s3, [x3, #4]
1000ba194:     	ldrb	w12, [x11, #8]
1000ba198:     	lsr	w12, w12, w15
1000ba19c:     	and	w14, w12, #0xf
1000ba1a0:     	cmp	w14, #8
1000ba1a4:     	csel	w14, wzr, w10, lo
1000ba1a8:     	bfxil	w14, w12, #0, #4
1000ba1ac:     	scvtf	s5, w14
1000ba1b0:     	fsub	s5, s5, s4
1000ba1b4:     	fmadd	s0, s5, s5, s0
1000ba1b8:     	str	s0, [x3, #8]
1000ba1bc:     	ldrb	w11, [x11, #12]
1000ba1c0:     	lsr	w11, w11, w15
1000ba1c4:     	and	w12, w11, #0xf
1000ba1c8:     	cmp	w12, #8
1000ba1cc:     	csel	w12, wzr, w10, lo
1000ba1d0:     	bfxil	w12, w11, #0, #4
1000ba1d4:     	scvtf	s5, w12
1000ba1d8:     	fsub	s4, s5, s4
1000ba1dc:     	fmadd	s1, s4, s4, s1
1000ba1e0:     	str	s1, [x3, #12]
1000ba1e4:     	add	x13, x13, #1
1000ba1e8:     	add	w9, w9, #4
1000ba1ec:     	cmp	x2, x13
1000ba1f0:     	b.ne	0x1000ba10c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000ba1f4:     	ldp	x20, x19, [sp, #32]
1000ba1f8:     	ldp	x22, x21, [sp, #16]
1000ba1fc:     	ldp	x24, x23, [sp], #48
1000ba200:     	ret

00000001000ba220 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000ba220:     	stp	x24, x23, [sp, #-48]!
1000ba224:     	stp	x22, x21, [sp, #16]
1000ba228:     	stp	x20, x19, [sp, #32]
1000ba22c:     	stp	xzr, xzr, [x3]
1000ba230:     	lsl	x8, x4, #2
1000ba234:     	cmp	x2, #8
1000ba238:     	b.hs	0x1000ba24c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000ba23c:     	mov	x13, #0
1000ba240:     	movi	d1, #0000000000000000
1000ba244:     	movi	d0, #0000000000000000
1000ba248:     	b	0x1000ba494 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x274>
1000ba24c:     	mov	x10, #0
1000ba250:     	add	x9, x0, #8
1000ba254:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2f4>
1000ba258:     	add	x11, x11, #444
1000ba25c:     	mov	x12, x1
1000ba260:     	ldr	w5, [x12]
1000ba264:     	lsl	w13, w5, #4
1000ba268:     	and	x14, x13, #0xf0
1000ba26c:     	and	x13, x5, #0xf0
1000ba270:     	add	x13, x11, x13
1000ba274:     	add	x14, x11, x14
1000ba278:     	lsr	x15, x5, #4
1000ba27c:     	and	x15, x15, #0xf0
1000ba280:     	add	x15, x11, x15
1000ba284:     	lsr	x16, x5, #8
1000ba288:     	and	x16, x16, #0xf0
1000ba28c:     	add	x16, x11, x16
1000ba290:     	lsr	x17, x5, #12
1000ba294:     	and	x17, x17, #0xf0
1000ba298:     	add	x17, x11, x17
1000ba29c:     	lsr	x4, x5, #16
1000ba2a0:     	and	x4, x4, #0xf0
1000ba2a4:     	add	x4, x11, x4
1000ba2a8:     	lsr	x6, x5, #20
1000ba2ac:     	and	x6, x6, #0xf0
1000ba2b0:     	lsr	x5, x5, #24
1000ba2b4:     	and	x7, x5, #0xf0
1000ba2b8:     	ldur	w19, [x9, #-8]
1000ba2bc:     	add	x5, x11, x6
1000ba2c0:     	and	x6, x19, #0xf
1000ba2c4:     	ubfx	x20, x19, #4, #4
1000ba2c8:     	ldrsb	w20, [x13, x20]
1000ba2cc:     	ldrsb	w21, [x14, x6]
1000ba2d0:     	ubfx	x6, x19, #8, #4
1000ba2d4:     	ldrsb	w22, [x15, x6]
1000ba2d8:     	ubfx	x6, x19, #12, #4
1000ba2dc:     	ldrsb	w23, [x16, x6]
1000ba2e0:     	add	x6, x11, x7
1000ba2e4:     	ubfx	x7, x19, #16, #4
1000ba2e8:     	ldrsb	w7, [x17, x7]
1000ba2ec:     	add	w20, w21, w20
1000ba2f0:     	add	w20, w20, w22
1000ba2f4:     	ubfx	x21, x19, #20, #4
1000ba2f8:     	ldrsb	w21, [x4, x21]
1000ba2fc:     	ubfx	x22, x19, #24, #4
1000ba300:     	add	w20, w20, w23
1000ba304:     	add	w7, w20, w7
1000ba308:     	ldrsb	w20, [x5, x22]
1000ba30c:     	lsr	x19, x19, #28
1000ba310:     	ldrsb	w19, [x6, x19]
1000ba314:     	add	w7, w7, w21
1000ba318:     	add	w7, w7, w20
1000ba31c:     	add	w7, w7, w19
1000ba320:     	scvtf	s0, w7
1000ba324:     	ldp	s1, s2, [x3]
1000ba328:     	fadd	s0, s1, s0
1000ba32c:     	str	s0, [x3]
1000ba330:     	ldur	w7, [x9, #-4]
1000ba334:     	and	x19, x7, #0xf
1000ba338:     	ldrsb	w19, [x14, x19]
1000ba33c:     	ubfx	x20, x7, #4, #4
1000ba340:     	ldrsb	w20, [x13, x20]
1000ba344:     	ubfx	x21, x7, #8, #4
1000ba348:     	ldrsb	w21, [x15, x21]
1000ba34c:     	ubfx	x22, x7, #12, #4
1000ba350:     	ldrsb	w22, [x16, x22]
1000ba354:     	ubfx	x23, x7, #16, #4
1000ba358:     	add	w19, w19, w20
1000ba35c:     	add	w19, w19, w21
1000ba360:     	ldrsb	w20, [x17, x23]
1000ba364:     	ubfx	x21, x7, #20, #4
1000ba368:     	ldrsb	w21, [x4, x21]
1000ba36c:     	add	w19, w19, w22
1000ba370:     	add	w19, w19, w20
1000ba374:     	ubfx	x20, x7, #24, #4
1000ba378:     	ldrsb	w20, [x5, x20]
1000ba37c:     	add	w19, w19, w21
1000ba380:     	add	w19, w19, w20
1000ba384:     	lsr	x7, x7, #28
1000ba388:     	ldrsb	w7, [x6, x7]
1000ba38c:     	add	w7, w19, w7
1000ba390:     	scvtf	s0, w7
1000ba394:     	fadd	s0, s2, s0
1000ba398:     	str	s0, [x3, #4]
1000ba39c:     	ldr	w7, [x9]
1000ba3a0:     	and	x19, x7, #0xf
1000ba3a4:     	ldrsb	w19, [x14, x19]
1000ba3a8:     	ubfx	x20, x7, #4, #4
1000ba3ac:     	ldrsb	w20, [x13, x20]
1000ba3b0:     	ubfx	x21, x7, #8, #4
1000ba3b4:     	ldrsb	w21, [x15, x21]
1000ba3b8:     	ubfx	x22, x7, #12, #4
1000ba3bc:     	ldrsb	w22, [x16, x22]
1000ba3c0:     	ubfx	x23, x7, #16, #4
1000ba3c4:     	add	w19, w19, w20
1000ba3c8:     	add	w19, w19, w21
1000ba3cc:     	ldrsb	w20, [x17, x23]
1000ba3d0:     	ubfx	x21, x7, #20, #4
1000ba3d4:     	ldrsb	w21, [x4, x21]
1000ba3d8:     	add	w19, w19, w22
1000ba3dc:     	add	w19, w19, w20
1000ba3e0:     	ubfx	x20, x7, #24, #4
1000ba3e4:     	ldrsb	w20, [x5, x20]
1000ba3e8:     	add	w19, w19, w21
1000ba3ec:     	add	w19, w19, w20
1000ba3f0:     	lsr	x7, x7, #28
1000ba3f4:     	ldrsb	w7, [x6, x7]
1000ba3f8:     	add	w7, w19, w7
1000ba3fc:     	scvtf	s0, w7
1000ba400:     	ldp	s1, s2, [x3, #8]
1000ba404:     	fadd	s0, s1, s0
1000ba408:     	str	s0, [x3, #8]
1000ba40c:     	ldr	w7, [x9, #4]
1000ba410:     	and	x19, x7, #0xf
1000ba414:     	ldrsb	w14, [x14, x19]
1000ba418:     	ubfx	x19, x7, #4, #4
1000ba41c:     	ldrsb	w13, [x13, x19]
1000ba420:     	ubfx	x19, x7, #8, #4
1000ba424:     	ldrsb	w15, [x15, x19]
1000ba428:     	ubfx	x19, x7, #12, #4
1000ba42c:     	ldrsb	w16, [x16, x19]
1000ba430:     	ubfx	x19, x7, #16, #4
1000ba434:     	ldrsb	w17, [x17, x19]
1000ba438:     	add	w13, w14, w13
1000ba43c:     	add	w13, w13, w15
1000ba440:     	ubfx	x14, x7, #20, #4
1000ba444:     	ldrsb	w14, [x4, x14]
1000ba448:     	ubfx	x15, x7, #24, #4
1000ba44c:     	add	w13, w13, w16
1000ba450:     	add	w13, w13, w17
1000ba454:     	ldrsb	w15, [x5, x15]
1000ba458:     	lsr	x16, x7, #28
1000ba45c:     	ldrsb	w16, [x6, x16]
1000ba460:     	add	w13, w13, w14
1000ba464:     	add	w13, w13, w15
1000ba468:     	add	w13, w13, w16
1000ba46c:     	scvtf	s1, w13
1000ba470:     	fadd	s1, s2, s1
1000ba474:     	str	s1, [x3, #12]
1000ba478:     	add	x13, x10, #8
1000ba47c:     	add	x12, x12, x8
1000ba480:     	add	x9, x9, #16
1000ba484:     	add	x14, x10, #16
1000ba488:     	mov	x10, x13
1000ba48c:     	cmp	x14, x2
1000ba490:     	b.ls	0x1000ba260 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000ba494:     	cmp	x13, x2
1000ba498:     	b.hs	0x1000ba580 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x360>
1000ba49c:     	ldp	s2, s3, [x3]
1000ba4a0:     	lsl	w9, w13, #2
1000ba4a4:     	mov	w10, #-16
1000ba4a8:     	lsr	x11, x13, #3
1000ba4ac:     	mul	x12, x8, x11
1000ba4b0:     	ubfx	x14, x13, #1, #2
1000ba4b4:     	orr	x12, x12, x14
1000ba4b8:     	ldrb	w12, [x1, x12]
1000ba4bc:     	and	w15, w9, #0x4
1000ba4c0:     	lsr	w12, w12, w15
1000ba4c4:     	and	w16, w12, #0xf
1000ba4c8:     	cmp	w16, #8
1000ba4cc:     	csel	w16, wzr, w10, lo
1000ba4d0:     	bfxil	w16, w12, #0, #4
1000ba4d4:     	bfi	x14, x11, #4, #60
1000ba4d8:     	add	x11, x0, x14
1000ba4dc:     	ldrb	w12, [x11]
1000ba4e0:     	lsr	w12, w12, w15
1000ba4e4:     	scvtf	s4, w16
1000ba4e8:     	and	w14, w12, #0xf
1000ba4ec:     	cmp	w14, #8
1000ba4f0:     	csel	w14, wzr, w10, lo
1000ba4f4:     	bfxil	w14, w12, #0, #4
1000ba4f8:     	scvtf	s5, w14
1000ba4fc:     	fmsub	s2, s5, s4, s2
1000ba500:     	str	s2, [x3]
1000ba504:     	ldrb	w12, [x11, #4]
1000ba508:     	lsr	w12, w12, w15
1000ba50c:     	and	w14, w12, #0xf
1000ba510:     	cmp	w14, #8
1000ba514:     	csel	w14, wzr, w10, lo
1000ba518:     	bfxil	w14, w12, #0, #4
1000ba51c:     	scvtf	s5, w14
1000ba520:     	fmsub	s3, s5, s4, s3
1000ba524:     	str	s3, [x3, #4]
1000ba528:     	ldrb	w12, [x11, #8]
1000ba52c:     	lsr	w12, w12, w15
1000ba530:     	and	w14, w12, #0xf
1000ba534:     	cmp	w14, #8
1000ba538:     	csel	w14, wzr, w10, lo
1000ba53c:     	bfxil	w14, w12, #0, #4
1000ba540:     	scvtf	s5, w14
1000ba544:     	fmsub	s0, s5, s4, s0
1000ba548:     	str	s0, [x3, #8]
1000ba54c:     	ldrb	w11, [x11, #12]
1000ba550:     	lsr	w11, w11, w15
1000ba554:     	and	w12, w11, #0xf
1000ba558:     	cmp	w12, #8
1000ba55c:     	csel	w12, wzr, w10, lo
1000ba560:     	bfxil	w12, w11, #0, #4
1000ba564:     	scvtf	s5, w12
1000ba568:     	fmsub	s1, s5, s4, s1
1000ba56c:     	str	s1, [x3, #12]
1000ba570:     	add	x13, x13, #1
1000ba574:     	add	w9, w9, #4
1000ba578:     	cmp	x2, x13
1000ba57c:     	b.ne	0x1000ba4a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x288>
1000ba580:     	ldp	x20, x19, [sp, #32]
1000ba584:     	ldp	x22, x21, [sp, #16]
1000ba588:     	ldp	x24, x23, [sp], #48
1000ba58c:     	ret

00000001000bc09c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bc09c:     	sub	sp, sp, #176
1000bc0a0:     	stp	x28, x27, [sp, #80]
1000bc0a4:     	stp	x26, x25, [sp, #96]
1000bc0a8:     	stp	x24, x23, [sp, #112]
1000bc0ac:     	stp	x22, x21, [sp, #128]
1000bc0b0:     	stp	x20, x19, [sp, #144]
1000bc0b4:     	stp	x29, x30, [sp, #160]
1000bc0b8:     	add	x29, sp, #160
1000bc0bc:     	str	x3, [sp]
1000bc0c0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x8>
1000bc0c4:     	ldr	x8, [x8, #392]
1000bc0c8:     	ldr	x8, [x8]
1000bc0cc:     	str	x8, [sp, #72]
1000bc0d0:     	movi.2d	v0, #0000000000000000
1000bc0d4:     	stp	q0, q0, [sp, #32]
1000bc0d8:     	ands	x8, x2, #0xfffffffffffffffe
1000bc0dc:     	b.eq	0x1000bc280 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bc0e0:     	add	x8, x1, x8
1000bc0e4:     	str	x8, [sp, #8]
1000bc0e8:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x28>
1000bc0ec:     	add	x9, x9, #188
1000bc0f0:     	mov	x11, #0
1000bc0f4:     	ldp	w4, w23, [x1]
1000bc0f8:     	ubfx	x8, x4, #4, #4
1000bc0fc:     	stp	x1, x8, [sp, #16]
1000bc100:     	ubfx	x13, x4, #8, #4
1000bc104:     	and	x14, x4, #0xf
1000bc108:     	ubfx	x15, x4, #12, #4
1000bc10c:     	ubfx	x16, x4, #16, #4
1000bc110:     	ubfx	x17, x4, #20, #4
1000bc114:     	ubfx	x2, x4, #24, #4
1000bc118:     	lsr	x4, x4, #28
1000bc11c:     	and	x5, x23, #0xf
1000bc120:     	ubfx	x6, x23, #4, #4
1000bc124:     	ubfx	x7, x23, #8, #4
1000bc128:     	ubfx	x19, x23, #12, #4
1000bc12c:     	ubfx	x20, x23, #16, #4
1000bc130:     	ubfx	x21, x23, #20, #4
1000bc134:     	ubfx	x22, x23, #24, #4
1000bc138:     	lsr	x23, x23, #28
1000bc13c:     	ldr	w24, [x0, x11]
1000bc140:     	lsl	w25, w24, #4
1000bc144:     	and	x25, x25, #0xf0
1000bc148:     	orr	x26, x25, x14
1000bc14c:     	ldrb	w26, [x9, x26]
1000bc150:     	and	x27, x24, #0xf0
1000bc154:     	ldr	x8, [sp, #24]
1000bc158:     	orr	x28, x27, x8
1000bc15c:     	ldrb	w28, [x9, x28]
1000bc160:     	lsr	x30, x24, #4
1000bc164:     	and	x30, x30, #0xf0
1000bc168:     	orr	x8, x30, x13
1000bc16c:     	ldrb	w8, [x9, x8]
1000bc170:     	add	w26, w26, w28
1000bc174:     	add	w8, w26, w8
1000bc178:     	lsr	x26, x24, #8
1000bc17c:     	and	x26, x26, #0xf0
1000bc180:     	orr	x28, x26, x15
1000bc184:     	ldrb	w28, [x9, x28]
1000bc188:     	lsr	x3, x24, #12
1000bc18c:     	and	x3, x3, #0xf0
1000bc190:     	orr	x10, x3, x16
1000bc194:     	ldrb	w10, [x9, x10]
1000bc198:     	add	w8, w8, w28
1000bc19c:     	add	w8, w8, w10
1000bc1a0:     	lsr	x10, x24, #16
1000bc1a4:     	and	x10, x10, #0xf0
1000bc1a8:     	orr	x28, x10, x17
1000bc1ac:     	ldrb	w28, [x9, x28]
1000bc1b0:     	lsr	x1, x24, #20
1000bc1b4:     	and	x1, x1, #0xf0
1000bc1b8:     	orr	x12, x1, x2
1000bc1bc:     	ldrb	w12, [x9, x12]
1000bc1c0:     	add	w8, w8, w28
1000bc1c4:     	add	x28, sp, #32
1000bc1c8:     	add	w8, w8, w12
1000bc1cc:     	lsr	x12, x24, #24
1000bc1d0:     	and	x12, x12, #0xf0
1000bc1d4:     	orr	x24, x12, x4
1000bc1d8:     	ldrb	w24, [x9, x24]
1000bc1dc:     	add	w8, w8, w24
1000bc1e0:     	scvtf	s0, w8
1000bc1e4:     	add	x8, x28, x11
1000bc1e8:     	ldr	s1, [x8]
1000bc1ec:     	fadd	s0, s1, s0
1000bc1f0:     	orr	x24, x25, x5
1000bc1f4:     	ldrb	w24, [x9, x24]
1000bc1f8:     	orr	x25, x27, x6
1000bc1fc:     	ldrb	w25, [x9, x25]
1000bc200:     	orr	x27, x30, x7
1000bc204:     	ldrb	w27, [x9, x27]
1000bc208:     	add	w24, w24, w25
1000bc20c:     	add	w24, w24, w27
1000bc210:     	orr	x25, x26, x19
1000bc214:     	ldrb	w25, [x9, x25]
1000bc218:     	orr	x3, x3, x20
1000bc21c:     	ldrb	w3, [x9, x3]
1000bc220:     	orr	x10, x10, x21
1000bc224:     	ldrb	w10, [x9, x10]
1000bc228:     	add	w24, w24, w25
1000bc22c:     	add	w3, w24, w3
1000bc230:     	orr	x1, x1, x22
1000bc234:     	ldrb	w1, [x9, x1]
1000bc238:     	add	w10, w3, w10
1000bc23c:     	add	w10, w10, w1
1000bc240:     	orr	x12, x12, x23
1000bc244:     	ldrb	w12, [x9, x12]
1000bc248:     	add	w10, w10, w12
1000bc24c:     	scvtf	s1, w10
1000bc250:     	str	s0, [x8]
1000bc254:     	ldr	s0, [x8, #16]
1000bc258:     	fadd	s0, s0, s1
1000bc25c:     	str	s0, [x8, #16]
1000bc260:     	add	x11, x11, #4
1000bc264:     	cmp	x11, #16
1000bc268:     	b.ne	0x1000bc13c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bc26c:     	add	x0, x0, #16
1000bc270:     	ldp	x8, x1, [sp, #8]
1000bc274:     	add	x1, x1, #8
1000bc278:     	cmp	x1, x8
1000bc27c:     	b.ne	0x1000bc0f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bc280:     	ldp	q0, q1, [sp, #32]
1000bc284:     	ldr	x8, [sp]
1000bc288:     	stp	q0, q1, [x8]
1000bc28c:     	ldr	x8, [sp, #72]
1000bc290:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d8>
1000bc294:     	ldr	x9, [x9, #392]
1000bc298:     	ldr	x9, [x9]
1000bc29c:     	cmp	x9, x8
1000bc2a0:     	b.ne	0x1000bc2c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bc2a4:     	ldp	x29, x30, [sp, #160]
1000bc2a8:     	ldp	x20, x19, [sp, #144]
1000bc2ac:     	ldp	x22, x21, [sp, #128]
1000bc2b0:     	ldp	x24, x23, [sp, #112]
1000bc2b4:     	ldp	x26, x25, [sp, #96]
1000bc2b8:     	ldp	x28, x27, [sp, #80]
1000bc2bc:     	add	sp, sp, #176
1000bc2c0:     	ret
1000bc2c4:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bc378 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bc378:     	sub	sp, sp, #176
1000bc37c:     	stp	x28, x27, [sp, #80]
1000bc380:     	stp	x26, x25, [sp, #96]
1000bc384:     	stp	x24, x23, [sp, #112]
1000bc388:     	stp	x22, x21, [sp, #128]
1000bc38c:     	stp	x20, x19, [sp, #144]
1000bc390:     	stp	x29, x30, [sp, #160]
1000bc394:     	add	x29, sp, #160
1000bc398:     	str	x3, [sp]
1000bc39c:     	adrp	x8, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xb8>
1000bc3a0:     	ldr	x8, [x8, #392]
1000bc3a4:     	ldr	x8, [x8]
1000bc3a8:     	str	x8, [sp, #72]
1000bc3ac:     	movi.2d	v0, #0000000000000000
1000bc3b0:     	stp	q0, q0, [sp, #32]
1000bc3b4:     	ands	x8, x2, #0xfffffffffffffffe
1000bc3b8:     	b.eq	0x1000bc55c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e4>
1000bc3bc:     	add	x8, x1, x8
1000bc3c0:     	str	x8, [sp, #8]
1000bc3c4:     	adrp	x9, 0x10016a000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0xd8>
1000bc3c8:     	add	x9, x9, #444
1000bc3cc:     	mov	x11, #0
1000bc3d0:     	ldp	w4, w23, [x1]
1000bc3d4:     	ubfx	x8, x4, #4, #4
1000bc3d8:     	stp	x1, x8, [sp, #16]
1000bc3dc:     	ubfx	x13, x4, #8, #4
1000bc3e0:     	and	x14, x4, #0xf
1000bc3e4:     	ubfx	x15, x4, #12, #4
1000bc3e8:     	ubfx	x16, x4, #16, #4
1000bc3ec:     	ubfx	x17, x4, #20, #4
1000bc3f0:     	ubfx	x2, x4, #24, #4
1000bc3f4:     	lsr	x4, x4, #28
1000bc3f8:     	and	x5, x23, #0xf
1000bc3fc:     	ubfx	x6, x23, #4, #4
1000bc400:     	ubfx	x7, x23, #8, #4
1000bc404:     	ubfx	x19, x23, #12, #4
1000bc408:     	ubfx	x20, x23, #16, #4
1000bc40c:     	ubfx	x21, x23, #20, #4
1000bc410:     	ubfx	x22, x23, #24, #4
1000bc414:     	lsr	x23, x23, #28
1000bc418:     	ldr	w24, [x0, x11]
1000bc41c:     	lsl	w25, w24, #4
1000bc420:     	and	x25, x25, #0xf0
1000bc424:     	orr	x26, x25, x14
1000bc428:     	ldrsb	w26, [x9, x26]
1000bc42c:     	and	x27, x24, #0xf0
1000bc430:     	ldr	x8, [sp, #24]
1000bc434:     	orr	x28, x27, x8
1000bc438:     	ldrsb	w28, [x9, x28]
1000bc43c:     	lsr	x30, x24, #4
1000bc440:     	and	x30, x30, #0xf0
1000bc444:     	orr	x8, x30, x13
1000bc448:     	ldrsb	w8, [x9, x8]
1000bc44c:     	add	w26, w26, w28
1000bc450:     	add	w8, w26, w8
1000bc454:     	lsr	x26, x24, #8
1000bc458:     	and	x26, x26, #0xf0
1000bc45c:     	orr	x28, x26, x15
1000bc460:     	ldrsb	w28, [x9, x28]
1000bc464:     	lsr	x3, x24, #12
1000bc468:     	and	x3, x3, #0xf0
1000bc46c:     	orr	x10, x3, x16
1000bc470:     	ldrsb	w10, [x9, x10]
1000bc474:     	add	w8, w8, w28
1000bc478:     	add	w8, w8, w10
1000bc47c:     	lsr	x10, x24, #16
1000bc480:     	and	x10, x10, #0xf0
1000bc484:     	orr	x28, x10, x17
1000bc488:     	ldrsb	w28, [x9, x28]
1000bc48c:     	lsr	x1, x24, #20
1000bc490:     	and	x1, x1, #0xf0
1000bc494:     	orr	x12, x1, x2
1000bc498:     	ldrsb	w12, [x9, x12]
1000bc49c:     	add	w8, w8, w28
1000bc4a0:     	add	x28, sp, #32
1000bc4a4:     	add	w8, w8, w12
1000bc4a8:     	lsr	x12, x24, #24
1000bc4ac:     	and	x12, x12, #0xf0
1000bc4b0:     	orr	x24, x12, x4
1000bc4b4:     	ldrsb	w24, [x9, x24]
1000bc4b8:     	add	w8, w8, w24
1000bc4bc:     	scvtf	s0, w8
1000bc4c0:     	add	x8, x28, x11
1000bc4c4:     	ldr	s1, [x8]
1000bc4c8:     	fadd	s0, s1, s0
1000bc4cc:     	orr	x24, x25, x5
1000bc4d0:     	ldrsb	w24, [x9, x24]
1000bc4d4:     	orr	x25, x27, x6
1000bc4d8:     	ldrsb	w25, [x9, x25]
1000bc4dc:     	orr	x27, x30, x7
1000bc4e0:     	ldrsb	w27, [x9, x27]
1000bc4e4:     	add	w24, w24, w25
1000bc4e8:     	add	w24, w24, w27
1000bc4ec:     	orr	x25, x26, x19
1000bc4f0:     	ldrsb	w25, [x9, x25]
1000bc4f4:     	orr	x3, x3, x20
1000bc4f8:     	ldrsb	w3, [x9, x3]
1000bc4fc:     	orr	x10, x10, x21
1000bc500:     	ldrsb	w10, [x9, x10]
1000bc504:     	add	w24, w24, w25
1000bc508:     	add	w3, w24, w3
1000bc50c:     	orr	x1, x1, x22
1000bc510:     	ldrsb	w1, [x9, x1]
1000bc514:     	add	w10, w3, w10
1000bc518:     	add	w10, w10, w1
1000bc51c:     	orr	x12, x12, x23
1000bc520:     	ldrsb	w12, [x9, x12]
1000bc524:     	add	w10, w10, w12
1000bc528:     	scvtf	s1, w10
1000bc52c:     	str	s0, [x8]
1000bc530:     	ldr	s0, [x8, #16]
1000bc534:     	fadd	s0, s0, s1
1000bc538:     	str	s0, [x8, #16]
1000bc53c:     	add	x11, x11, #4
1000bc540:     	cmp	x11, #16
1000bc544:     	b.ne	0x1000bc418 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa0>
1000bc548:     	add	x0, x0, #16
1000bc54c:     	ldp	x8, x1, [sp, #8]
1000bc550:     	add	x1, x1, #8
1000bc554:     	cmp	x1, x8
1000bc558:     	b.ne	0x1000bc3cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x54>
1000bc55c:     	ldp	q0, q1, [sp, #32]
1000bc560:     	ldr	x8, [sp]
1000bc564:     	stp	q0, q1, [x8]
1000bc568:     	ldr	x8, [sp, #72]
1000bc56c:     	adrp	x9, 0x10016c000 <void run<unsigned char, 4ul, 4ul, false>(char const*)+0x288>
1000bc570:     	ldr	x9, [x9, #392]
1000bc574:     	ldr	x9, [x9]
1000bc578:     	cmp	x9, x8
1000bc57c:     	b.ne	0x1000bc5a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x228>
1000bc580:     	ldp	x29, x30, [sp, #160]
1000bc584:     	ldp	x20, x19, [sp, #144]
1000bc588:     	ldp	x22, x21, [sp, #128]
1000bc58c:     	ldp	x24, x23, [sp, #112]
1000bc590:     	ldp	x26, x25, [sp, #96]
1000bc594:     	ldp	x28, x27, [sp, #80]
1000bc598:     	add	sp, sp, #176
1000bc59c:     	ret
1000bc5a0:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bd828 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bd828:     	sub	sp, sp, #352
1000bd82c:     	stp	x28, x27, [sp, #256]
1000bd830:     	stp	x26, x25, [sp, #272]
1000bd834:     	stp	x24, x23, [sp, #288]
1000bd838:     	stp	x22, x21, [sp, #304]
1000bd83c:     	stp	x20, x19, [sp, #320]
1000bd840:     	stp	x29, x30, [sp, #336]
1000bd844:     	add	x29, sp, #336
1000bd848:     	str	x3, [sp]
1000bd84c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bd850:     	ldr	x8, [x8, #392]
1000bd854:     	ldr	x8, [x8]
1000bd858:     	stur	x8, [x29, #-96]
1000bd85c:     	movi.2d	v0, #0000000000000000
1000bd860:     	stp	q0, q0, [x29, #-128]
1000bd864:     	lsl	x8, x2, #1
1000bd868:     	stp	q0, q0, [x29, #-160]
1000bd86c:     	ands	x8, x8, #0xfffffffffffffffc
1000bd870:     	b.eq	0x1000bdb98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bd874:     	add	x8, x1, x8
1000bd878:     	str	x8, [sp, #8]
1000bd87c:     	sub	x8, x29, #160
1000bd880:     	add	x27, x8, #32
1000bd884:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bd888:     	add	x11, x11, #188
1000bd88c:     	mov	x12, #0
1000bd890:     	ldp	w8, w9, [x1]
1000bd894:     	ubfx	x10, x8, #4, #4
1000bd898:     	str	x10, [sp, #168]
1000bd89c:     	ubfx	x10, x8, #8, #4
1000bd8a0:     	str	x10, [sp, #160]
1000bd8a4:     	and	x10, x8, #0xf
1000bd8a8:     	str	x10, [sp, #152]
1000bd8ac:     	ubfx	x10, x8, #12, #4
1000bd8b0:     	str	x10, [sp, #144]
1000bd8b4:     	ubfx	x10, x8, #16, #4
1000bd8b8:     	str	x10, [sp, #136]
1000bd8bc:     	ubfx	x10, x8, #20, #4
1000bd8c0:     	str	x10, [sp, #128]
1000bd8c4:     	ubfx	x10, x8, #24, #4
1000bd8c8:     	lsr	x8, x8, #28
1000bd8cc:     	stp	x8, x10, [sp, #112]
1000bd8d0:     	and	x10, x9, #0xf
1000bd8d4:     	ubfx	x8, x9, #4, #4
1000bd8d8:     	stp	x8, x10, [sp, #96]
1000bd8dc:     	ubfx	x10, x9, #8, #4
1000bd8e0:     	ubfx	x8, x9, #12, #4
1000bd8e4:     	stp	x8, x10, [sp, #80]
1000bd8e8:     	ubfx	x10, x9, #16, #4
1000bd8ec:     	ubfx	x8, x9, #20, #4
1000bd8f0:     	stp	x8, x10, [sp, #64]
1000bd8f4:     	ubfx	x10, x9, #24, #4
1000bd8f8:     	lsr	x8, x9, #28
1000bd8fc:     	stp	x8, x10, [sp, #48]
1000bd900:     	ldp	w9, w17, [x1, #8]
1000bd904:     	and	x10, x9, #0xf
1000bd908:     	ubfx	x8, x9, #4, #4
1000bd90c:     	stp	x8, x10, [sp, #32]
1000bd910:     	ubfx	x8, x9, #8, #4
1000bd914:     	stp	x1, x8, [sp, #16]
1000bd918:     	ubfx	x28, x9, #12, #4
1000bd91c:     	ubfx	x30, x9, #16, #4
1000bd920:     	ubfx	x8, x9, #20, #4
1000bd924:     	ubfx	x3, x9, #24, #4
1000bd928:     	lsr	x9, x9, #28
1000bd92c:     	and	x1, x17, #0xf
1000bd930:     	ubfx	x10, x17, #4, #4
1000bd934:     	ubfx	x13, x17, #8, #4
1000bd938:     	ubfx	x26, x17, #12, #4
1000bd93c:     	ubfx	x14, x17, #16, #4
1000bd940:     	ubfx	x15, x17, #20, #4
1000bd944:     	ubfx	x16, x17, #24, #4
1000bd948:     	lsr	x17, x17, #28
1000bd94c:     	ldr	w21, [x0, x12]
1000bd950:     	lsl	w2, w21, #4
1000bd954:     	and	x2, x2, #0xf0
1000bd958:     	ldp	x4, x19, [sp, #152]
1000bd95c:     	orr	x4, x2, x4
1000bd960:     	ldrb	w6, [x11, x4]
1000bd964:     	and	x4, x21, #0xf0
1000bd968:     	ldr	x5, [sp, #168]
1000bd96c:     	orr	x5, x4, x5
1000bd970:     	ldrb	w7, [x11, x5]
1000bd974:     	lsr	x5, x21, #4
1000bd978:     	and	x5, x5, #0xf0
1000bd97c:     	orr	x19, x5, x19
1000bd980:     	ldrb	w19, [x11, x19]
1000bd984:     	add	w6, w6, w7
1000bd988:     	add	w19, w6, w19
1000bd98c:     	lsr	x6, x21, #8
1000bd990:     	and	x6, x6, #0xf0
1000bd994:     	ldp	x22, x7, [sp, #136]
1000bd998:     	orr	x7, x6, x7
1000bd99c:     	ldrb	w20, [x11, x7]
1000bd9a0:     	lsr	x7, x21, #12
1000bd9a4:     	and	x7, x7, #0xf0
1000bd9a8:     	orr	x22, x7, x22
1000bd9ac:     	ldrb	w22, [x11, x22]
1000bd9b0:     	add	w19, w19, w20
1000bd9b4:     	add	w22, w19, w22
1000bd9b8:     	lsr	x19, x21, #16
1000bd9bc:     	and	x19, x19, #0xf0
1000bd9c0:     	ldp	x24, x20, [sp, #120]
1000bd9c4:     	orr	x20, x19, x20
1000bd9c8:     	ldrb	w23, [x11, x20]
1000bd9cc:     	lsr	x20, x21, #20
1000bd9d0:     	and	x20, x20, #0xf0
1000bd9d4:     	orr	x24, x20, x24
1000bd9d8:     	ldrb	w24, [x11, x24]
1000bd9dc:     	add	w22, w22, w23
1000bd9e0:     	add	w22, w22, w24
1000bd9e4:     	lsr	x21, x21, #24
1000bd9e8:     	and	x21, x21, #0xf0
1000bd9ec:     	ldr	x23, [sp, #112]
1000bd9f0:     	orr	x23, x21, x23
1000bd9f4:     	ldrb	w23, [x11, x23]
1000bd9f8:     	add	w22, w22, w23
1000bd9fc:     	scvtf	s0, w22
1000bda00:     	ldp	x23, x22, [sp, #96]
1000bda04:     	orr	x22, x2, x22
1000bda08:     	ldrb	w22, [x11, x22]
1000bda0c:     	orr	x23, x4, x23
1000bda10:     	ldrb	w23, [x11, x23]
1000bda14:     	ldr	x24, [sp, #88]
1000bda18:     	orr	x24, x5, x24
1000bda1c:     	ldrb	w24, [x11, x24]
1000bda20:     	add	w22, w22, w23
1000bda24:     	add	w22, w22, w24
1000bda28:     	ldp	x24, x23, [sp, #72]
1000bda2c:     	orr	x23, x6, x23
1000bda30:     	ldrb	w23, [x11, x23]
1000bda34:     	orr	x24, x7, x24
1000bda38:     	ldrb	w24, [x11, x24]
1000bda3c:     	ldr	x25, [sp, #64]
1000bda40:     	orr	x25, x19, x25
1000bda44:     	ldrb	w25, [x11, x25]
1000bda48:     	add	w22, w22, w23
1000bda4c:     	add	w22, w22, w24
1000bda50:     	ldr	x23, [sp, #56]
1000bda54:     	orr	x23, x20, x23
1000bda58:     	ldrb	w23, [x11, x23]
1000bda5c:     	add	w22, w22, w25
1000bda60:     	add	w22, w22, w23
1000bda64:     	ldr	x23, [sp, #48]
1000bda68:     	orr	x23, x21, x23
1000bda6c:     	ldrb	w23, [x11, x23]
1000bda70:     	add	w22, w22, w23
1000bda74:     	scvtf	s1, w22
1000bda78:     	ldp	x23, x22, [sp, #32]
1000bda7c:     	orr	x22, x2, x22
1000bda80:     	ldrb	w22, [x11, x22]
1000bda84:     	orr	x23, x4, x23
1000bda88:     	ldrb	w23, [x11, x23]
1000bda8c:     	ldr	x24, [sp, #24]
1000bda90:     	orr	x24, x5, x24
1000bda94:     	ldrb	w24, [x11, x24]
1000bda98:     	add	w22, w22, w23
1000bda9c:     	add	w22, w22, w24
1000bdaa0:     	orr	x23, x6, x28
1000bdaa4:     	ldrb	w23, [x11, x23]
1000bdaa8:     	orr	x24, x7, x30
1000bdaac:     	ldrb	w24, [x11, x24]
1000bdab0:     	orr	x25, x19, x8
1000bdab4:     	ldrb	w25, [x11, x25]
1000bdab8:     	add	w22, w22, w23
1000bdabc:     	orr	x23, x20, x3
1000bdac0:     	ldrb	w23, [x11, x23]
1000bdac4:     	add	w22, w22, w24
1000bdac8:     	add	w22, w22, w25
1000bdacc:     	add	w22, w22, w23
1000bdad0:     	orr	x23, x21, x9
1000bdad4:     	ldrb	w23, [x11, x23]
1000bdad8:     	add	w22, w22, w23
1000bdadc:     	scvtf	s2, w22
1000bdae0:     	orr	x2, x2, x1
1000bdae4:     	ldrb	w2, [x11, x2]
1000bdae8:     	orr	x4, x4, x10
1000bdaec:     	ldrb	w4, [x11, x4]
1000bdaf0:     	orr	x5, x5, x13
1000bdaf4:     	ldrb	w5, [x11, x5]
1000bdaf8:     	add	w2, w2, w4
1000bdafc:     	add	w2, w2, w5
1000bdb00:     	orr	x4, x6, x26
1000bdb04:     	ldrb	w4, [x11, x4]
1000bdb08:     	orr	x5, x7, x14
1000bdb0c:     	ldrb	w5, [x11, x5]
1000bdb10:     	add	w2, w2, w4
1000bdb14:     	orr	x4, x19, x15
1000bdb18:     	ldrb	w4, [x11, x4]
1000bdb1c:     	add	w2, w2, w5
1000bdb20:     	orr	x5, x20, x16
1000bdb24:     	ldrb	w5, [x11, x5]
1000bdb28:     	add	w2, w2, w4
1000bdb2c:     	add	w2, w2, w5
1000bdb30:     	orr	x4, x21, x17
1000bdb34:     	ldrb	w4, [x11, x4]
1000bdb38:     	add	w2, w2, w4
1000bdb3c:     	sub	x4, x29, #160
1000bdb40:     	scvtf	s3, w2
1000bdb44:     	add	x2, x27, x12
1000bdb48:     	ldur	s4, [x2, #-16]
1000bdb4c:     	fadd	s1, s4, s1
1000bdb50:     	stur	s1, [x2, #-16]
1000bdb54:     	ldr	s1, [x2]
1000bdb58:     	fadd	s1, s1, s2
1000bdb5c:     	str	s1, [x2]
1000bdb60:     	ldr	s1, [x2, #16]
1000bdb64:     	fadd	s1, s1, s3
1000bdb68:     	ldr	s2, [x4, x12]
1000bdb6c:     	str	s1, [x2, #16]
1000bdb70:     	fadd	s0, s2, s0
1000bdb74:     	str	s0, [x4, x12]
1000bdb78:     	add	x12, x12, #4
1000bdb7c:     	cmp	x12, #16
1000bdb80:     	b.ne	0x1000bd94c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000bdb84:     	add	x0, x0, #16
1000bdb88:     	ldp	x8, x1, [sp, #8]
1000bdb8c:     	add	x1, x1, #16
1000bdb90:     	cmp	x1, x8
1000bdb94:     	b.ne	0x1000bd88c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000bdb98:     	ldp	q0, q1, [x29, #-160]
1000bdb9c:     	ldr	x8, [sp]
1000bdba0:     	stp	q0, q1, [x8]
1000bdba4:     	ldp	q0, q1, [x29, #-128]
1000bdba8:     	stp	q0, q1, [x8, #32]
1000bdbac:     	ldur	x8, [x29, #-96]
1000bdbb0:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x18c>
1000bdbb4:     	ldr	x9, [x9, #392]
1000bdbb8:     	ldr	x9, [x9]
1000bdbbc:     	cmp	x9, x8
1000bdbc0:     	b.ne	0x1000bdbe4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000bdbc4:     	ldp	x29, x30, [sp, #336]
1000bdbc8:     	ldp	x20, x19, [sp, #320]
1000bdbcc:     	ldp	x22, x21, [sp, #304]
1000bdbd0:     	ldp	x24, x23, [sp, #288]
1000bdbd4:     	ldp	x26, x25, [sp, #272]
1000bdbd8:     	ldp	x28, x27, [sp, #256]
1000bdbdc:     	add	sp, sp, #352
1000bdbe0:     	ret
1000bdbe4:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bdce0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000bdce0:     	sub	sp, sp, #352
1000bdce4:     	stp	x28, x27, [sp, #256]
1000bdce8:     	stp	x26, x25, [sp, #272]
1000bdcec:     	stp	x24, x23, [sp, #288]
1000bdcf0:     	stp	x22, x21, [sp, #304]
1000bdcf4:     	stp	x20, x19, [sp, #320]
1000bdcf8:     	stp	x29, x30, [sp, #336]
1000bdcfc:     	add	x29, sp, #336
1000bdd00:     	str	x3, [sp]
1000bdd04:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2e0>
1000bdd08:     	ldr	x8, [x8, #392]
1000bdd0c:     	ldr	x8, [x8]
1000bdd10:     	stur	x8, [x29, #-96]
1000bdd14:     	movi.2d	v0, #0000000000000000
1000bdd18:     	stp	q0, q0, [x29, #-128]
1000bdd1c:     	lsl	x8, x2, #1
1000bdd20:     	stp	q0, q0, [x29, #-160]
1000bdd24:     	ands	x8, x8, #0xfffffffffffffffc
1000bdd28:     	b.eq	0x1000be050 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x370>
1000bdd2c:     	add	x8, x1, x8
1000bdd30:     	str	x8, [sp, #8]
1000bdd34:     	sub	x8, x29, #160
1000bdd38:     	add	x27, x8, #32
1000bdd3c:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x310>
1000bdd40:     	add	x11, x11, #444
1000bdd44:     	mov	x12, #0
1000bdd48:     	ldp	w8, w9, [x1]
1000bdd4c:     	ubfx	x10, x8, #4, #4
1000bdd50:     	str	x10, [sp, #168]
1000bdd54:     	ubfx	x10, x8, #8, #4
1000bdd58:     	str	x10, [sp, #160]
1000bdd5c:     	and	x10, x8, #0xf
1000bdd60:     	str	x10, [sp, #152]
1000bdd64:     	ubfx	x10, x8, #12, #4
1000bdd68:     	str	x10, [sp, #144]
1000bdd6c:     	ubfx	x10, x8, #16, #4
1000bdd70:     	str	x10, [sp, #136]
1000bdd74:     	ubfx	x10, x8, #20, #4
1000bdd78:     	str	x10, [sp, #128]
1000bdd7c:     	ubfx	x10, x8, #24, #4
1000bdd80:     	lsr	x8, x8, #28
1000bdd84:     	stp	x8, x10, [sp, #112]
1000bdd88:     	and	x10, x9, #0xf
1000bdd8c:     	ubfx	x8, x9, #4, #4
1000bdd90:     	stp	x8, x10, [sp, #96]
1000bdd94:     	ubfx	x10, x9, #8, #4
1000bdd98:     	ubfx	x8, x9, #12, #4
1000bdd9c:     	stp	x8, x10, [sp, #80]
1000bdda0:     	ubfx	x10, x9, #16, #4
1000bdda4:     	ubfx	x8, x9, #20, #4
1000bdda8:     	stp	x8, x10, [sp, #64]
1000bddac:     	ubfx	x10, x9, #24, #4
1000bddb0:     	lsr	x8, x9, #28
1000bddb4:     	stp	x8, x10, [sp, #48]
1000bddb8:     	ldp	w9, w17, [x1, #8]
1000bddbc:     	and	x10, x9, #0xf
1000bddc0:     	ubfx	x8, x9, #4, #4
1000bddc4:     	stp	x8, x10, [sp, #32]
1000bddc8:     	ubfx	x8, x9, #8, #4
1000bddcc:     	stp	x1, x8, [sp, #16]
1000bddd0:     	ubfx	x28, x9, #12, #4
1000bddd4:     	ubfx	x30, x9, #16, #4
1000bddd8:     	ubfx	x8, x9, #20, #4
1000bdddc:     	ubfx	x3, x9, #24, #4
1000bdde0:     	lsr	x9, x9, #28
1000bdde4:     	and	x1, x17, #0xf
1000bdde8:     	ubfx	x10, x17, #4, #4
1000bddec:     	ubfx	x13, x17, #8, #4
1000bddf0:     	ubfx	x26, x17, #12, #4
1000bddf4:     	ubfx	x14, x17, #16, #4
1000bddf8:     	ubfx	x15, x17, #20, #4
1000bddfc:     	ubfx	x16, x17, #24, #4
1000bde00:     	lsr	x17, x17, #28
1000bde04:     	ldr	w21, [x0, x12]
1000bde08:     	lsl	w2, w21, #4
1000bde0c:     	and	x2, x2, #0xf0
1000bde10:     	ldp	x4, x19, [sp, #152]
1000bde14:     	orr	x4, x2, x4
1000bde18:     	ldrsb	w6, [x11, x4]
1000bde1c:     	and	x4, x21, #0xf0
1000bde20:     	ldr	x5, [sp, #168]
1000bde24:     	orr	x5, x4, x5
1000bde28:     	ldrsb	w7, [x11, x5]
1000bde2c:     	lsr	x5, x21, #4
1000bde30:     	and	x5, x5, #0xf0
1000bde34:     	orr	x19, x5, x19
1000bde38:     	ldrsb	w19, [x11, x19]
1000bde3c:     	add	w6, w6, w7
1000bde40:     	add	w19, w6, w19
1000bde44:     	lsr	x6, x21, #8
1000bde48:     	and	x6, x6, #0xf0
1000bde4c:     	ldp	x22, x7, [sp, #136]
1000bde50:     	orr	x7, x6, x7
1000bde54:     	ldrsb	w20, [x11, x7]
1000bde58:     	lsr	x7, x21, #12
1000bde5c:     	and	x7, x7, #0xf0
1000bde60:     	orr	x22, x7, x22
1000bde64:     	ldrsb	w22, [x11, x22]
1000bde68:     	add	w19, w19, w20
1000bde6c:     	add	w22, w19, w22
1000bde70:     	lsr	x19, x21, #16
1000bde74:     	and	x19, x19, #0xf0
1000bde78:     	ldp	x24, x20, [sp, #120]
1000bde7c:     	orr	x20, x19, x20
1000bde80:     	ldrsb	w23, [x11, x20]
1000bde84:     	lsr	x20, x21, #20
1000bde88:     	and	x20, x20, #0xf0
1000bde8c:     	orr	x24, x20, x24
1000bde90:     	ldrsb	w24, [x11, x24]
1000bde94:     	add	w22, w22, w23
1000bde98:     	add	w22, w22, w24
1000bde9c:     	lsr	x21, x21, #24
1000bdea0:     	and	x21, x21, #0xf0
1000bdea4:     	ldr	x23, [sp, #112]
1000bdea8:     	orr	x23, x21, x23
1000bdeac:     	ldrsb	w23, [x11, x23]
1000bdeb0:     	add	w22, w22, w23
1000bdeb4:     	scvtf	s0, w22
1000bdeb8:     	ldp	x23, x22, [sp, #96]
1000bdebc:     	orr	x22, x2, x22
1000bdec0:     	ldrsb	w22, [x11, x22]
1000bdec4:     	orr	x23, x4, x23
1000bdec8:     	ldrsb	w23, [x11, x23]
1000bdecc:     	ldr	x24, [sp, #88]
1000bded0:     	orr	x24, x5, x24
1000bded4:     	ldrsb	w24, [x11, x24]
1000bded8:     	add	w22, w22, w23
1000bdedc:     	add	w22, w22, w24
1000bdee0:     	ldp	x24, x23, [sp, #72]
1000bdee4:     	orr	x23, x6, x23
1000bdee8:     	ldrsb	w23, [x11, x23]
1000bdeec:     	orr	x24, x7, x24
1000bdef0:     	ldrsb	w24, [x11, x24]
1000bdef4:     	ldr	x25, [sp, #64]
1000bdef8:     	orr	x25, x19, x25
1000bdefc:     	ldrsb	w25, [x11, x25]
1000bdf00:     	add	w22, w22, w23
1000bdf04:     	add	w22, w22, w24
1000bdf08:     	ldr	x23, [sp, #56]
1000bdf0c:     	orr	x23, x20, x23
1000bdf10:     	ldrsb	w23, [x11, x23]
1000bdf14:     	add	w22, w22, w25
1000bdf18:     	add	w22, w22, w23
1000bdf1c:     	ldr	x23, [sp, #48]
1000bdf20:     	orr	x23, x21, x23
1000bdf24:     	ldrsb	w23, [x11, x23]
1000bdf28:     	add	w22, w22, w23
1000bdf2c:     	scvtf	s1, w22
1000bdf30:     	ldp	x23, x22, [sp, #32]
1000bdf34:     	orr	x22, x2, x22
1000bdf38:     	ldrsb	w22, [x11, x22]
1000bdf3c:     	orr	x23, x4, x23
1000bdf40:     	ldrsb	w23, [x11, x23]
1000bdf44:     	ldr	x24, [sp, #24]
1000bdf48:     	orr	x24, x5, x24
1000bdf4c:     	ldrsb	w24, [x11, x24]
1000bdf50:     	add	w22, w22, w23
1000bdf54:     	add	w22, w22, w24
1000bdf58:     	orr	x23, x6, x28
1000bdf5c:     	ldrsb	w23, [x11, x23]
1000bdf60:     	orr	x24, x7, x30
1000bdf64:     	ldrsb	w24, [x11, x24]
1000bdf68:     	orr	x25, x19, x8
1000bdf6c:     	ldrsb	w25, [x11, x25]
1000bdf70:     	add	w22, w22, w23
1000bdf74:     	orr	x23, x20, x3
1000bdf78:     	ldrsb	w23, [x11, x23]
1000bdf7c:     	add	w22, w22, w24
1000bdf80:     	add	w22, w22, w25
1000bdf84:     	add	w22, w22, w23
1000bdf88:     	orr	x23, x21, x9
1000bdf8c:     	ldrsb	w23, [x11, x23]
1000bdf90:     	add	w22, w22, w23
1000bdf94:     	scvtf	s2, w22
1000bdf98:     	orr	x2, x2, x1
1000bdf9c:     	ldrsb	w2, [x11, x2]
1000bdfa0:     	orr	x4, x4, x10
1000bdfa4:     	ldrsb	w4, [x11, x4]
1000bdfa8:     	orr	x5, x5, x13
1000bdfac:     	ldrsb	w5, [x11, x5]
1000bdfb0:     	add	w2, w2, w4
1000bdfb4:     	add	w2, w2, w5
1000bdfb8:     	orr	x4, x6, x26
1000bdfbc:     	ldrsb	w4, [x11, x4]
1000bdfc0:     	orr	x5, x7, x14
1000bdfc4:     	ldrsb	w5, [x11, x5]
1000bdfc8:     	add	w2, w2, w4
1000bdfcc:     	orr	x4, x19, x15
1000bdfd0:     	ldrsb	w4, [x11, x4]
1000bdfd4:     	add	w2, w2, w5
1000bdfd8:     	orr	x5, x20, x16
1000bdfdc:     	ldrsb	w5, [x11, x5]
1000bdfe0:     	add	w2, w2, w4
1000bdfe4:     	add	w2, w2, w5
1000bdfe8:     	orr	x4, x21, x17
1000bdfec:     	ldrsb	w4, [x11, x4]
1000bdff0:     	add	w2, w2, w4
1000bdff4:     	sub	x4, x29, #160
1000bdff8:     	scvtf	s3, w2
1000bdffc:     	add	x2, x27, x12
1000be000:     	ldur	s4, [x2, #-16]
1000be004:     	fadd	s1, s4, s1
1000be008:     	stur	s1, [x2, #-16]
1000be00c:     	ldr	s1, [x2]
1000be010:     	fadd	s1, s1, s2
1000be014:     	str	s1, [x2]
1000be018:     	ldr	s1, [x2, #16]
1000be01c:     	fadd	s1, s1, s3
1000be020:     	ldr	s2, [x4, x12]
1000be024:     	str	s1, [x2, #16]
1000be028:     	fadd	s0, s2, s0
1000be02c:     	str	s0, [x4, x12]
1000be030:     	add	x12, x12, #4
1000be034:     	cmp	x12, #16
1000be038:     	b.ne	0x1000bde04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x124>
1000be03c:     	add	x0, x0, #16
1000be040:     	ldp	x8, x1, [sp, #8]
1000be044:     	add	x1, x1, #16
1000be048:     	cmp	x1, x8
1000be04c:     	b.ne	0x1000bdd44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000be050:     	ldp	q0, q1, [x29, #-160]
1000be054:     	ldr	x8, [sp]
1000be058:     	stp	q0, q1, [x8]
1000be05c:     	ldp	q0, q1, [x29, #-128]
1000be060:     	stp	q0, q1, [x8, #32]
1000be064:     	ldur	x8, [x29, #-96]
1000be068:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 1ul, false>(char const*)+0x280>
1000be06c:     	ldr	x9, [x9, #392]
1000be070:     	ldr	x9, [x9]
1000be074:     	cmp	x9, x8
1000be078:     	b.ne	0x1000be09c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 4ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3bc>
1000be07c:     	ldp	x29, x30, [sp, #336]
1000be080:     	ldp	x20, x19, [sp, #320]
1000be084:     	ldp	x22, x21, [sp, #304]
1000be088:     	ldp	x24, x23, [sp, #288]
1000be08c:     	ldp	x26, x25, [sp, #272]
1000be090:     	ldp	x28, x27, [sp, #256]
1000be094:     	add	sp, sp, #352
1000be098:     	ret
1000be09c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000bf7a0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bf7a0:     	stp	x24, x23, [sp, #-48]!
1000bf7a4:     	stp	x22, x21, [sp, #16]
1000bf7a8:     	stp	x20, x19, [sp, #32]
1000bf7ac:     	movi.2d	v0, #0000000000000000
1000bf7b0:     	stp	q0, q0, [x3]
1000bf7b4:     	lsl	x8, x4, #2
1000bf7b8:     	cmp	x2, #8
1000bf7bc:     	b.hs	0x1000bf7c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bf7c0:     	mov	x13, #0
1000bf7c4:     	b	0x1000bfbc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bf7c8:     	mov	x10, #0
1000bf7cc:     	add	x9, x0, #16
1000bf7d0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bf7d4:     	add	x11, x11, #700
1000bf7d8:     	mov	x12, x1
1000bf7dc:     	ldr	w5, [x12]
1000bf7e0:     	lsr	x13, x5, #24
1000bf7e4:     	and	x13, x13, #0xf0
1000bf7e8:     	lsr	x14, x5, #20
1000bf7ec:     	and	x14, x14, #0xf0
1000bf7f0:     	add	x13, x11, x13
1000bf7f4:     	add	x14, x11, x14
1000bf7f8:     	lsr	x15, x5, #16
1000bf7fc:     	and	x15, x15, #0xf0
1000bf800:     	lsr	x16, x5, #12
1000bf804:     	and	x6, x16, #0xf0
1000bf808:     	add	x15, x11, x15
1000bf80c:     	lsr	x16, x5, #8
1000bf810:     	and	x16, x16, #0xf0
1000bf814:     	add	x16, x11, x16
1000bf818:     	lsr	x17, x5, #4
1000bf81c:     	and	x17, x17, #0xf0
1000bf820:     	add	x17, x11, x17
1000bf824:     	and	x4, x5, #0xf0
1000bf828:     	add	x4, x11, x4
1000bf82c:     	lsl	w5, w5, #4
1000bf830:     	and	x5, x5, #0xf0
1000bf834:     	ldur	w7, [x9, #-16]
1000bf838:     	add	x5, x11, x5
1000bf83c:     	and	x19, x7, #0xf
1000bf840:     	ubfx	x20, x7, #4, #4
1000bf844:     	ldrb	w20, [x4, x20]
1000bf848:     	ldrb	w19, [x5, x19]
1000bf84c:     	ubfx	x21, x7, #8, #4
1000bf850:     	ldrb	w21, [x17, x21]
1000bf854:     	ubfx	x22, x7, #12, #4
1000bf858:     	ldrb	w22, [x16, x22]
1000bf85c:     	add	x6, x11, x6
1000bf860:     	ubfx	x23, x7, #16, #4
1000bf864:     	ldrb	w23, [x6, x23]
1000bf868:     	add	w19, w19, w20
1000bf86c:     	add	w19, w19, w21
1000bf870:     	ubfx	x20, x7, #20, #4
1000bf874:     	ldrb	w20, [x15, x20]
1000bf878:     	ubfx	x21, x7, #24, #4
1000bf87c:     	add	w19, w19, w22
1000bf880:     	add	w19, w19, w23
1000bf884:     	ldrb	w21, [x14, x21]
1000bf888:     	lsr	x7, x7, #28
1000bf88c:     	ldrb	w7, [x13, x7]
1000bf890:     	add	w19, w19, w20
1000bf894:     	add	w19, w19, w21
1000bf898:     	add	w7, w19, w7
1000bf89c:     	scvtf	s0, w7
1000bf8a0:     	ldp	s1, s2, [x3]
1000bf8a4:     	fadd	s0, s1, s0
1000bf8a8:     	str	s0, [x3]
1000bf8ac:     	ldur	w7, [x9, #-12]
1000bf8b0:     	and	x19, x7, #0xf
1000bf8b4:     	ldrb	w19, [x5, x19]
1000bf8b8:     	ubfx	x20, x7, #4, #4
1000bf8bc:     	ldrb	w20, [x4, x20]
1000bf8c0:     	ubfx	x21, x7, #8, #4
1000bf8c4:     	ldrb	w21, [x17, x21]
1000bf8c8:     	ubfx	x22, x7, #12, #4
1000bf8cc:     	ldrb	w22, [x16, x22]
1000bf8d0:     	ubfx	x23, x7, #16, #4
1000bf8d4:     	add	w19, w19, w20
1000bf8d8:     	add	w19, w19, w21
1000bf8dc:     	ldrb	w20, [x6, x23]
1000bf8e0:     	ubfx	x21, x7, #20, #4
1000bf8e4:     	ldrb	w21, [x15, x21]
1000bf8e8:     	add	w19, w19, w22
1000bf8ec:     	add	w19, w19, w20
1000bf8f0:     	ubfx	x20, x7, #24, #4
1000bf8f4:     	ldrb	w20, [x14, x20]
1000bf8f8:     	add	w19, w19, w21
1000bf8fc:     	add	w19, w19, w20
1000bf900:     	lsr	x7, x7, #28
1000bf904:     	ldrb	w7, [x13, x7]
1000bf908:     	add	w7, w19, w7
1000bf90c:     	scvtf	s0, w7
1000bf910:     	fadd	s0, s2, s0
1000bf914:     	str	s0, [x3, #4]
1000bf918:     	ldur	w7, [x9, #-8]
1000bf91c:     	and	x19, x7, #0xf
1000bf920:     	ldrb	w19, [x5, x19]
1000bf924:     	ubfx	x20, x7, #4, #4
1000bf928:     	ldrb	w20, [x4, x20]
1000bf92c:     	ubfx	x21, x7, #8, #4
1000bf930:     	ldrb	w21, [x17, x21]
1000bf934:     	ubfx	x22, x7, #12, #4
1000bf938:     	ldrb	w22, [x16, x22]
1000bf93c:     	ubfx	x23, x7, #16, #4
1000bf940:     	add	w19, w19, w20
1000bf944:     	add	w19, w19, w21
1000bf948:     	ldrb	w20, [x6, x23]
1000bf94c:     	ubfx	x21, x7, #20, #4
1000bf950:     	ldrb	w21, [x15, x21]
1000bf954:     	add	w19, w19, w22
1000bf958:     	add	w19, w19, w20
1000bf95c:     	ubfx	x20, x7, #24, #4
1000bf960:     	ldrb	w20, [x14, x20]
1000bf964:     	add	w19, w19, w21
1000bf968:     	add	w19, w19, w20
1000bf96c:     	lsr	x7, x7, #28
1000bf970:     	ldrb	w7, [x13, x7]
1000bf974:     	add	w7, w19, w7
1000bf978:     	scvtf	s0, w7
1000bf97c:     	ldp	s1, s2, [x3, #8]
1000bf980:     	fadd	s0, s1, s0
1000bf984:     	str	s0, [x3, #8]
1000bf988:     	ldur	w7, [x9, #-4]
1000bf98c:     	and	x19, x7, #0xf
1000bf990:     	ldrb	w19, [x5, x19]
1000bf994:     	ubfx	x20, x7, #4, #4
1000bf998:     	ldrb	w20, [x4, x20]
1000bf99c:     	ubfx	x21, x7, #8, #4
1000bf9a0:     	ldrb	w21, [x17, x21]
1000bf9a4:     	ubfx	x22, x7, #12, #4
1000bf9a8:     	ldrb	w22, [x16, x22]
1000bf9ac:     	ubfx	x23, x7, #16, #4
1000bf9b0:     	ldrb	w23, [x6, x23]
1000bf9b4:     	ubfx	x24, x7, #20, #4
1000bf9b8:     	add	w19, w19, w20
1000bf9bc:     	add	w19, w19, w21
1000bf9c0:     	ldrb	w20, [x15, x24]
1000bf9c4:     	ubfx	x21, x7, #24, #4
1000bf9c8:     	ldrb	w21, [x14, x21]
1000bf9cc:     	add	w19, w19, w22
1000bf9d0:     	add	w19, w19, w23
1000bf9d4:     	lsr	x7, x7, #28
1000bf9d8:     	ldrb	w7, [x13, x7]
1000bf9dc:     	add	w19, w19, w20
1000bf9e0:     	add	w19, w19, w21
1000bf9e4:     	add	w7, w19, w7
1000bf9e8:     	scvtf	s0, w7
1000bf9ec:     	fadd	s0, s2, s0
1000bf9f0:     	str	s0, [x3, #12]
1000bf9f4:     	ldr	w7, [x9]
1000bf9f8:     	and	x19, x7, #0xf
1000bf9fc:     	ldrb	w19, [x5, x19]
1000bfa00:     	ubfx	x20, x7, #4, #4
1000bfa04:     	ldrb	w20, [x4, x20]
1000bfa08:     	ubfx	x21, x7, #8, #4
1000bfa0c:     	ldrb	w21, [x17, x21]
1000bfa10:     	ubfx	x22, x7, #12, #4
1000bfa14:     	ldrb	w22, [x16, x22]
1000bfa18:     	ubfx	x23, x7, #16, #4
1000bfa1c:     	ldrb	w23, [x6, x23]
1000bfa20:     	add	w19, w19, w20
1000bfa24:     	add	w19, w19, w21
1000bfa28:     	ubfx	x20, x7, #20, #4
1000bfa2c:     	ldrb	w20, [x15, x20]
1000bfa30:     	ubfx	x21, x7, #24, #4
1000bfa34:     	add	w19, w19, w22
1000bfa38:     	add	w19, w19, w23
1000bfa3c:     	ldrb	w21, [x14, x21]
1000bfa40:     	lsr	x7, x7, #28
1000bfa44:     	ldrb	w7, [x13, x7]
1000bfa48:     	add	w19, w19, w20
1000bfa4c:     	add	w19, w19, w21
1000bfa50:     	add	w7, w19, w7
1000bfa54:     	scvtf	s0, w7
1000bfa58:     	ldp	s1, s2, [x3, #16]
1000bfa5c:     	fadd	s0, s1, s0
1000bfa60:     	str	s0, [x3, #16]
1000bfa64:     	ldr	w7, [x9, #4]
1000bfa68:     	and	x19, x7, #0xf
1000bfa6c:     	ldrb	w19, [x5, x19]
1000bfa70:     	ubfx	x20, x7, #4, #4
1000bfa74:     	ldrb	w20, [x4, x20]
1000bfa78:     	ubfx	x21, x7, #8, #4
1000bfa7c:     	ldrb	w21, [x17, x21]
1000bfa80:     	ubfx	x22, x7, #12, #4
1000bfa84:     	ldrb	w22, [x16, x22]
1000bfa88:     	ubfx	x23, x7, #16, #4
1000bfa8c:     	add	w19, w19, w20
1000bfa90:     	add	w19, w19, w21
1000bfa94:     	ldrb	w20, [x6, x23]
1000bfa98:     	ubfx	x21, x7, #20, #4
1000bfa9c:     	ldrb	w21, [x15, x21]
1000bfaa0:     	add	w19, w19, w22
1000bfaa4:     	add	w19, w19, w20
1000bfaa8:     	ubfx	x20, x7, #24, #4
1000bfaac:     	ldrb	w20, [x14, x20]
1000bfab0:     	add	w19, w19, w21
1000bfab4:     	add	w19, w19, w20
1000bfab8:     	lsr	x7, x7, #28
1000bfabc:     	ldrb	w7, [x13, x7]
1000bfac0:     	add	w7, w19, w7
1000bfac4:     	scvtf	s0, w7
1000bfac8:     	fadd	s0, s2, s0
1000bfacc:     	str	s0, [x3, #20]
1000bfad0:     	ldr	w7, [x9, #8]
1000bfad4:     	and	x19, x7, #0xf
1000bfad8:     	ldrb	w19, [x5, x19]
1000bfadc:     	ubfx	x20, x7, #4, #4
1000bfae0:     	ldrb	w20, [x4, x20]
1000bfae4:     	ubfx	x21, x7, #8, #4
1000bfae8:     	ldrb	w21, [x17, x21]
1000bfaec:     	ubfx	x22, x7, #12, #4
1000bfaf0:     	ldrb	w22, [x16, x22]
1000bfaf4:     	ubfx	x23, x7, #16, #4
1000bfaf8:     	add	w19, w19, w20
1000bfafc:     	add	w19, w19, w21
1000bfb00:     	ldrb	w20, [x6, x23]
1000bfb04:     	ubfx	x21, x7, #20, #4
1000bfb08:     	ldrb	w21, [x15, x21]
1000bfb0c:     	add	w19, w19, w22
1000bfb10:     	add	w19, w19, w20
1000bfb14:     	ubfx	x20, x7, #24, #4
1000bfb18:     	ldrb	w20, [x14, x20]
1000bfb1c:     	add	w19, w19, w21
1000bfb20:     	add	w19, w19, w20
1000bfb24:     	lsr	x7, x7, #28
1000bfb28:     	ldrb	w7, [x13, x7]
1000bfb2c:     	add	w7, w19, w7
1000bfb30:     	scvtf	s0, w7
1000bfb34:     	ldp	s1, s2, [x3, #24]
1000bfb38:     	fadd	s0, s1, s0
1000bfb3c:     	str	s0, [x3, #24]
1000bfb40:     	ldr	w7, [x9, #12]
1000bfb44:     	and	x19, x7, #0xf
1000bfb48:     	ldrb	w5, [x5, x19]
1000bfb4c:     	ubfx	x19, x7, #4, #4
1000bfb50:     	ldrb	w4, [x4, x19]
1000bfb54:     	ubfx	x19, x7, #8, #4
1000bfb58:     	ldrb	w17, [x17, x19]
1000bfb5c:     	ubfx	x19, x7, #12, #4
1000bfb60:     	ldrb	w16, [x16, x19]
1000bfb64:     	ubfx	x19, x7, #16, #4
1000bfb68:     	ldrb	w6, [x6, x19]
1000bfb6c:     	add	w4, w5, w4
1000bfb70:     	add	w17, w4, w17
1000bfb74:     	ubfx	x4, x7, #20, #4
1000bfb78:     	ldrb	w15, [x15, x4]
1000bfb7c:     	ubfx	x4, x7, #24, #4
1000bfb80:     	add	w16, w17, w16
1000bfb84:     	add	w16, w16, w6
1000bfb88:     	ldrb	w14, [x14, x4]
1000bfb8c:     	lsr	x17, x7, #28
1000bfb90:     	ldrb	w13, [x13, x17]
1000bfb94:     	add	w15, w16, w15
1000bfb98:     	add	w14, w15, w14
1000bfb9c:     	add	w13, w14, w13
1000bfba0:     	scvtf	s0, w13
1000bfba4:     	fadd	s0, s2, s0
1000bfba8:     	str	s0, [x3, #28]
1000bfbac:     	add	x13, x10, #8
1000bfbb0:     	add	x12, x12, x8
1000bfbb4:     	add	x14, x10, #16
1000bfbb8:     	add	x9, x9, #32
1000bfbbc:     	mov	x10, x13
1000bfbc0:     	cmp	x14, x2
1000bfbc4:     	b.ls	0x1000bf7dc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000bfbc8:     	cmp	x13, x2
1000bfbcc:     	b.hs	0x1000bfd80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5e0>
1000bfbd0:     	ldp	s0, s1, [x3, #8]
1000bfbd4:     	lsl	x9, x13, #2
1000bfbd8:     	mov	w10, #-16
1000bfbdc:     	ldr	s2, [x3, #16]
1000bfbe0:     	lsr	x11, x13, #3
1000bfbe4:     	mul	x12, x8, x11
1000bfbe8:     	ubfx	x11, x13, #1, #2
1000bfbec:     	orr	x12, x12, x11
1000bfbf0:     	ldrb	w14, [x1, x12]
1000bfbf4:     	and	w12, w9, #0x4
1000bfbf8:     	lsr	w14, w14, w12
1000bfbfc:     	and	w15, w14, #0xf
1000bfc00:     	cmp	w15, #8
1000bfc04:     	csel	w15, wzr, w10, lo
1000bfc08:     	and	x16, x9, #0xffffffffffffffe0
1000bfc0c:     	bfxil	x16, x13, #1, #2
1000bfc10:     	bfxil	w15, w14, #0, #4
1000bfc14:     	add	x14, x0, x16
1000bfc18:     	ldrb	w16, [x14]
1000bfc1c:     	lsr	w16, w16, w12
1000bfc20:     	and	w17, w16, #0xf
1000bfc24:     	scvtf	s3, w15
1000bfc28:     	cmp	w17, #8
1000bfc2c:     	csel	w15, wzr, w10, lo
1000bfc30:     	bfxil	w15, w16, #0, #4
1000bfc34:     	scvtf	s4, w15
1000bfc38:     	fsub	s4, s4, s3
1000bfc3c:     	ldp	s5, s6, [x3]
1000bfc40:     	fmadd	s4, s4, s4, s5
1000bfc44:     	str	s4, [x3]
1000bfc48:     	ldrb	w15, [x14, #4]
1000bfc4c:     	lsr	w15, w15, w12
1000bfc50:     	and	w16, w15, #0xf
1000bfc54:     	cmp	w16, #8
1000bfc58:     	csel	w16, wzr, w10, lo
1000bfc5c:     	bfxil	w16, w15, #0, #4
1000bfc60:     	scvtf	s4, w16
1000bfc64:     	fsub	s4, s4, s3
1000bfc68:     	fmadd	s4, s4, s4, s6
1000bfc6c:     	str	s4, [x3, #4]
1000bfc70:     	ldrb	w15, [x14, #8]
1000bfc74:     	lsr	w15, w15, w12
1000bfc78:     	and	w16, w15, #0xf
1000bfc7c:     	cmp	w16, #8
1000bfc80:     	csel	w16, wzr, w10, lo
1000bfc84:     	bfxil	w16, w15, #0, #4
1000bfc88:     	scvtf	s4, w16
1000bfc8c:     	fsub	s4, s4, s3
1000bfc90:     	fmadd	s0, s4, s4, s0
1000bfc94:     	str	s0, [x3, #8]
1000bfc98:     	ldrb	w15, [x14, #12]
1000bfc9c:     	lsr	w15, w15, w12
1000bfca0:     	and	w16, w15, #0xf
1000bfca4:     	cmp	w16, #8
1000bfca8:     	csel	w16, wzr, w10, lo
1000bfcac:     	bfxil	w16, w15, #0, #4
1000bfcb0:     	scvtf	s4, w16
1000bfcb4:     	fsub	s4, s4, s3
1000bfcb8:     	fmadd	s1, s4, s4, s1
1000bfcbc:     	str	s1, [x3, #12]
1000bfcc0:     	ldrb	w15, [x14, #16]
1000bfcc4:     	lsr	w15, w15, w12
1000bfcc8:     	and	w16, w15, #0xf
1000bfccc:     	cmp	w16, #8
1000bfcd0:     	csel	w16, wzr, w10, lo
1000bfcd4:     	bfxil	w16, w15, #0, #4
1000bfcd8:     	scvtf	s4, w16
1000bfcdc:     	fsub	s4, s4, s3
1000bfce0:     	fmadd	s2, s4, s4, s2
1000bfce4:     	str	s2, [x3, #16]
1000bfce8:     	ldrb	w15, [x14, #20]
1000bfcec:     	lsr	w15, w15, w12
1000bfcf0:     	and	w16, w15, #0xf
1000bfcf4:     	cmp	w16, #8
1000bfcf8:     	csel	w16, wzr, w10, lo
1000bfcfc:     	bfxil	w16, w15, #0, #4
1000bfd00:     	scvtf	s4, w16
1000bfd04:     	fsub	s4, s4, s3
1000bfd08:     	ldp	s5, s6, [x3, #20]
1000bfd0c:     	fmadd	s4, s4, s4, s5
1000bfd10:     	str	s4, [x3, #20]
1000bfd14:     	ldrb	w14, [x14, #24]
1000bfd18:     	lsr	w14, w14, w12
1000bfd1c:     	and	w15, w14, #0xf
1000bfd20:     	cmp	w15, #8
1000bfd24:     	csel	w15, wzr, w10, lo
1000bfd28:     	bfxil	w15, w14, #0, #4
1000bfd2c:     	scvtf	s4, w15
1000bfd30:     	fsub	s4, s4, s3
1000bfd34:     	fmadd	s4, s4, s4, s6
1000bfd38:     	str	s4, [x3, #24]
1000bfd3c:     	orr	x11, x9, x11
1000bfd40:     	orr	x11, x11, #0x1c
1000bfd44:     	ldrb	w11, [x0, x11]
1000bfd48:     	lsr	w11, w11, w12
1000bfd4c:     	and	w12, w11, #0xf
1000bfd50:     	cmp	w12, #8
1000bfd54:     	csel	w12, wzr, w10, lo
1000bfd58:     	bfxil	w12, w11, #0, #4
1000bfd5c:     	scvtf	s4, w12
1000bfd60:     	fsub	s3, s4, s3
1000bfd64:     	ldr	s4, [x3, #28]
1000bfd68:     	fmadd	s3, s3, s3, s4
1000bfd6c:     	str	s3, [x3, #28]
1000bfd70:     	add	x13, x13, #1
1000bfd74:     	add	x9, x9, #4
1000bfd78:     	cmp	x2, x13
1000bfd7c:     	b.ne	0x1000bfbe0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000bfd80:     	ldp	x20, x19, [sp, #32]
1000bfd84:     	ldp	x22, x21, [sp, #16]
1000bfd88:     	ldp	x24, x23, [sp], #48
1000bfd8c:     	ret

00000001000bfdb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000bfdb0:     	stp	x24, x23, [sp, #-48]!
1000bfdb4:     	stp	x22, x21, [sp, #16]
1000bfdb8:     	stp	x20, x19, [sp, #32]
1000bfdbc:     	movi.2d	v0, #0000000000000000
1000bfdc0:     	stp	q0, q0, [x3]
1000bfdc4:     	lsl	x8, x4, #2
1000bfdc8:     	cmp	x2, #8
1000bfdcc:     	b.hs	0x1000bfdd8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x28>
1000bfdd0:     	mov	x13, #0
1000bfdd4:     	b	0x1000c01d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x428>
1000bfdd8:     	mov	x10, #0
1000bfddc:     	add	x9, x0, #16
1000bfde0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2dc>
1000bfde4:     	add	x11, x11, #956
1000bfde8:     	mov	x12, x1
1000bfdec:     	ldr	w5, [x12]
1000bfdf0:     	lsr	x13, x5, #24
1000bfdf4:     	and	x13, x13, #0xf0
1000bfdf8:     	lsr	x14, x5, #20
1000bfdfc:     	and	x14, x14, #0xf0
1000bfe00:     	add	x13, x11, x13
1000bfe04:     	add	x14, x11, x14
1000bfe08:     	lsr	x15, x5, #16
1000bfe0c:     	and	x15, x15, #0xf0
1000bfe10:     	lsr	x16, x5, #12
1000bfe14:     	and	x6, x16, #0xf0
1000bfe18:     	add	x15, x11, x15
1000bfe1c:     	lsr	x16, x5, #8
1000bfe20:     	and	x16, x16, #0xf0
1000bfe24:     	add	x16, x11, x16
1000bfe28:     	lsr	x17, x5, #4
1000bfe2c:     	and	x17, x17, #0xf0
1000bfe30:     	add	x17, x11, x17
1000bfe34:     	and	x4, x5, #0xf0
1000bfe38:     	add	x4, x11, x4
1000bfe3c:     	lsl	w5, w5, #4
1000bfe40:     	and	x5, x5, #0xf0
1000bfe44:     	ldur	w7, [x9, #-16]
1000bfe48:     	add	x5, x11, x5
1000bfe4c:     	and	x19, x7, #0xf
1000bfe50:     	ubfx	x20, x7, #4, #4
1000bfe54:     	ldrsb	w20, [x4, x20]
1000bfe58:     	ldrsb	w19, [x5, x19]
1000bfe5c:     	ubfx	x21, x7, #8, #4
1000bfe60:     	ldrsb	w21, [x17, x21]
1000bfe64:     	ubfx	x22, x7, #12, #4
1000bfe68:     	ldrsb	w22, [x16, x22]
1000bfe6c:     	add	x6, x11, x6
1000bfe70:     	ubfx	x23, x7, #16, #4
1000bfe74:     	ldrsb	w23, [x6, x23]
1000bfe78:     	add	w19, w19, w20
1000bfe7c:     	add	w19, w19, w21
1000bfe80:     	ubfx	x20, x7, #20, #4
1000bfe84:     	ldrsb	w20, [x15, x20]
1000bfe88:     	ubfx	x21, x7, #24, #4
1000bfe8c:     	add	w19, w19, w22
1000bfe90:     	add	w19, w19, w23
1000bfe94:     	ldrsb	w21, [x14, x21]
1000bfe98:     	lsr	x7, x7, #28
1000bfe9c:     	ldrsb	w7, [x13, x7]
1000bfea0:     	add	w19, w19, w20
1000bfea4:     	add	w19, w19, w21
1000bfea8:     	add	w7, w19, w7
1000bfeac:     	scvtf	s0, w7
1000bfeb0:     	ldp	s1, s2, [x3]
1000bfeb4:     	fadd	s0, s1, s0
1000bfeb8:     	str	s0, [x3]
1000bfebc:     	ldur	w7, [x9, #-12]
1000bfec0:     	and	x19, x7, #0xf
1000bfec4:     	ldrsb	w19, [x5, x19]
1000bfec8:     	ubfx	x20, x7, #4, #4
1000bfecc:     	ldrsb	w20, [x4, x20]
1000bfed0:     	ubfx	x21, x7, #8, #4
1000bfed4:     	ldrsb	w21, [x17, x21]
1000bfed8:     	ubfx	x22, x7, #12, #4
1000bfedc:     	ldrsb	w22, [x16, x22]
1000bfee0:     	ubfx	x23, x7, #16, #4
1000bfee4:     	add	w19, w19, w20
1000bfee8:     	add	w19, w19, w21
1000bfeec:     	ldrsb	w20, [x6, x23]
1000bfef0:     	ubfx	x21, x7, #20, #4
1000bfef4:     	ldrsb	w21, [x15, x21]
1000bfef8:     	add	w19, w19, w22
1000bfefc:     	add	w19, w19, w20
1000bff00:     	ubfx	x20, x7, #24, #4
1000bff04:     	ldrsb	w20, [x14, x20]
1000bff08:     	add	w19, w19, w21
1000bff0c:     	add	w19, w19, w20
1000bff10:     	lsr	x7, x7, #28
1000bff14:     	ldrsb	w7, [x13, x7]
1000bff18:     	add	w7, w19, w7
1000bff1c:     	scvtf	s0, w7
1000bff20:     	fadd	s0, s2, s0
1000bff24:     	str	s0, [x3, #4]
1000bff28:     	ldur	w7, [x9, #-8]
1000bff2c:     	and	x19, x7, #0xf
1000bff30:     	ldrsb	w19, [x5, x19]
1000bff34:     	ubfx	x20, x7, #4, #4
1000bff38:     	ldrsb	w20, [x4, x20]
1000bff3c:     	ubfx	x21, x7, #8, #4
1000bff40:     	ldrsb	w21, [x17, x21]
1000bff44:     	ubfx	x22, x7, #12, #4
1000bff48:     	ldrsb	w22, [x16, x22]
1000bff4c:     	ubfx	x23, x7, #16, #4
1000bff50:     	add	w19, w19, w20
1000bff54:     	add	w19, w19, w21
1000bff58:     	ldrsb	w20, [x6, x23]
1000bff5c:     	ubfx	x21, x7, #20, #4
1000bff60:     	ldrsb	w21, [x15, x21]
1000bff64:     	add	w19, w19, w22
1000bff68:     	add	w19, w19, w20
1000bff6c:     	ubfx	x20, x7, #24, #4
1000bff70:     	ldrsb	w20, [x14, x20]
1000bff74:     	add	w19, w19, w21
1000bff78:     	add	w19, w19, w20
1000bff7c:     	lsr	x7, x7, #28
1000bff80:     	ldrsb	w7, [x13, x7]
1000bff84:     	add	w7, w19, w7
1000bff88:     	scvtf	s0, w7
1000bff8c:     	ldp	s1, s2, [x3, #8]
1000bff90:     	fadd	s0, s1, s0
1000bff94:     	str	s0, [x3, #8]
1000bff98:     	ldur	w7, [x9, #-4]
1000bff9c:     	and	x19, x7, #0xf
1000bffa0:     	ldrsb	w19, [x5, x19]
1000bffa4:     	ubfx	x20, x7, #4, #4
1000bffa8:     	ldrsb	w20, [x4, x20]
1000bffac:     	ubfx	x21, x7, #8, #4
1000bffb0:     	ldrsb	w21, [x17, x21]
1000bffb4:     	ubfx	x22, x7, #12, #4
1000bffb8:     	ldrsb	w22, [x16, x22]
1000bffbc:     	ubfx	x23, x7, #16, #4
1000bffc0:     	ldrsb	w23, [x6, x23]
1000bffc4:     	ubfx	x24, x7, #20, #4
1000bffc8:     	add	w19, w19, w20
1000bffcc:     	add	w19, w19, w21
1000bffd0:     	ldrsb	w20, [x15, x24]
1000bffd4:     	ubfx	x21, x7, #24, #4
1000bffd8:     	ldrsb	w21, [x14, x21]
1000bffdc:     	add	w19, w19, w22
1000bffe0:     	add	w19, w19, w23
1000bffe4:     	lsr	x7, x7, #28
1000bffe8:     	ldrsb	w7, [x13, x7]
1000bffec:     	add	w19, w19, w20
1000bfff0:     	add	w19, w19, w21
1000bfff4:     	add	w7, w19, w7
1000bfff8:     	scvtf	s0, w7
1000bfffc:     	fadd	s0, s2, s0
1000c0000:     	str	s0, [x3, #12]
1000c0004:     	ldr	w7, [x9]
1000c0008:     	and	x19, x7, #0xf
1000c000c:     	ldrsb	w19, [x5, x19]
1000c0010:     	ubfx	x20, x7, #4, #4
1000c0014:     	ldrsb	w20, [x4, x20]
1000c0018:     	ubfx	x21, x7, #8, #4
1000c001c:     	ldrsb	w21, [x17, x21]
1000c0020:     	ubfx	x22, x7, #12, #4
1000c0024:     	ldrsb	w22, [x16, x22]
1000c0028:     	ubfx	x23, x7, #16, #4
1000c002c:     	ldrsb	w23, [x6, x23]
1000c0030:     	add	w19, w19, w20
1000c0034:     	add	w19, w19, w21
1000c0038:     	ubfx	x20, x7, #20, #4
1000c003c:     	ldrsb	w20, [x15, x20]
1000c0040:     	ubfx	x21, x7, #24, #4
1000c0044:     	add	w19, w19, w22
1000c0048:     	add	w19, w19, w23
1000c004c:     	ldrsb	w21, [x14, x21]
1000c0050:     	lsr	x7, x7, #28
1000c0054:     	ldrsb	w7, [x13, x7]
1000c0058:     	add	w19, w19, w20
1000c005c:     	add	w19, w19, w21
1000c0060:     	add	w7, w19, w7
1000c0064:     	scvtf	s0, w7
1000c0068:     	ldp	s1, s2, [x3, #16]
1000c006c:     	fadd	s0, s1, s0
1000c0070:     	str	s0, [x3, #16]
1000c0074:     	ldr	w7, [x9, #4]
1000c0078:     	and	x19, x7, #0xf
1000c007c:     	ldrsb	w19, [x5, x19]
1000c0080:     	ubfx	x20, x7, #4, #4
1000c0084:     	ldrsb	w20, [x4, x20]
1000c0088:     	ubfx	x21, x7, #8, #4
1000c008c:     	ldrsb	w21, [x17, x21]
1000c0090:     	ubfx	x22, x7, #12, #4
1000c0094:     	ldrsb	w22, [x16, x22]
1000c0098:     	ubfx	x23, x7, #16, #4
1000c009c:     	add	w19, w19, w20
1000c00a0:     	add	w19, w19, w21
1000c00a4:     	ldrsb	w20, [x6, x23]
1000c00a8:     	ubfx	x21, x7, #20, #4
1000c00ac:     	ldrsb	w21, [x15, x21]
1000c00b0:     	add	w19, w19, w22
1000c00b4:     	add	w19, w19, w20
1000c00b8:     	ubfx	x20, x7, #24, #4
1000c00bc:     	ldrsb	w20, [x14, x20]
1000c00c0:     	add	w19, w19, w21
1000c00c4:     	add	w19, w19, w20
1000c00c8:     	lsr	x7, x7, #28
1000c00cc:     	ldrsb	w7, [x13, x7]
1000c00d0:     	add	w7, w19, w7
1000c00d4:     	scvtf	s0, w7
1000c00d8:     	fadd	s0, s2, s0
1000c00dc:     	str	s0, [x3, #20]
1000c00e0:     	ldr	w7, [x9, #8]
1000c00e4:     	and	x19, x7, #0xf
1000c00e8:     	ldrsb	w19, [x5, x19]
1000c00ec:     	ubfx	x20, x7, #4, #4
1000c00f0:     	ldrsb	w20, [x4, x20]
1000c00f4:     	ubfx	x21, x7, #8, #4
1000c00f8:     	ldrsb	w21, [x17, x21]
1000c00fc:     	ubfx	x22, x7, #12, #4
1000c0100:     	ldrsb	w22, [x16, x22]
1000c0104:     	ubfx	x23, x7, #16, #4
1000c0108:     	add	w19, w19, w20
1000c010c:     	add	w19, w19, w21
1000c0110:     	ldrsb	w20, [x6, x23]
1000c0114:     	ubfx	x21, x7, #20, #4
1000c0118:     	ldrsb	w21, [x15, x21]
1000c011c:     	add	w19, w19, w22
1000c0120:     	add	w19, w19, w20
1000c0124:     	ubfx	x20, x7, #24, #4
1000c0128:     	ldrsb	w20, [x14, x20]
1000c012c:     	add	w19, w19, w21
1000c0130:     	add	w19, w19, w20
1000c0134:     	lsr	x7, x7, #28
1000c0138:     	ldrsb	w7, [x13, x7]
1000c013c:     	add	w7, w19, w7
1000c0140:     	scvtf	s0, w7
1000c0144:     	ldp	s1, s2, [x3, #24]
1000c0148:     	fadd	s0, s1, s0
1000c014c:     	str	s0, [x3, #24]
1000c0150:     	ldr	w7, [x9, #12]
1000c0154:     	and	x19, x7, #0xf
1000c0158:     	ldrsb	w5, [x5, x19]
1000c015c:     	ubfx	x19, x7, #4, #4
1000c0160:     	ldrsb	w4, [x4, x19]
1000c0164:     	ubfx	x19, x7, #8, #4
1000c0168:     	ldrsb	w17, [x17, x19]
1000c016c:     	ubfx	x19, x7, #12, #4
1000c0170:     	ldrsb	w16, [x16, x19]
1000c0174:     	ubfx	x19, x7, #16, #4
1000c0178:     	ldrsb	w6, [x6, x19]
1000c017c:     	add	w4, w5, w4
1000c0180:     	add	w17, w4, w17
1000c0184:     	ubfx	x4, x7, #20, #4
1000c0188:     	ldrsb	w15, [x15, x4]
1000c018c:     	ubfx	x4, x7, #24, #4
1000c0190:     	add	w16, w17, w16
1000c0194:     	add	w16, w16, w6
1000c0198:     	ldrsb	w14, [x14, x4]
1000c019c:     	lsr	x17, x7, #28
1000c01a0:     	ldrsb	w13, [x13, x17]
1000c01a4:     	add	w15, w16, w15
1000c01a8:     	add	w14, w15, w14
1000c01ac:     	add	w13, w14, w13
1000c01b0:     	scvtf	s0, w13
1000c01b4:     	fadd	s0, s2, s0
1000c01b8:     	str	s0, [x3, #28]
1000c01bc:     	add	x13, x10, #8
1000c01c0:     	add	x12, x12, x8
1000c01c4:     	add	x14, x10, #16
1000c01c8:     	add	x9, x9, #32
1000c01cc:     	mov	x10, x13
1000c01d0:     	cmp	x14, x2
1000c01d4:     	b.ls	0x1000bfdec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3c>
1000c01d8:     	cmp	x13, x2
1000c01dc:     	b.hs	0x1000c0370 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x5c0>
1000c01e0:     	ldp	s0, s1, [x3, #8]
1000c01e4:     	lsl	x9, x13, #2
1000c01e8:     	mov	w10, #-16
1000c01ec:     	ldr	s2, [x3, #16]
1000c01f0:     	lsr	x11, x13, #3
1000c01f4:     	mul	x12, x8, x11
1000c01f8:     	ubfx	x11, x13, #1, #2
1000c01fc:     	orr	x14, x12, x11
1000c0200:     	and	w12, w9, #0x4
1000c0204:     	ldrb	w14, [x1, x14]
1000c0208:     	lsr	w14, w14, w12
1000c020c:     	and	w15, w14, #0xf
1000c0210:     	cmp	w15, #8
1000c0214:     	csel	w15, wzr, w10, lo
1000c0218:     	and	x16, x9, #0xffffffffffffffe0
1000c021c:     	bfxil	w15, w14, #0, #4
1000c0220:     	bfxil	x16, x13, #1, #2
1000c0224:     	add	x14, x0, x16
1000c0228:     	ldrb	w16, [x14]
1000c022c:     	lsr	w16, w16, w12
1000c0230:     	scvtf	s3, w15
1000c0234:     	and	w15, w16, #0xf
1000c0238:     	cmp	w15, #8
1000c023c:     	csel	w15, wzr, w10, lo
1000c0240:     	bfxil	w15, w16, #0, #4
1000c0244:     	scvtf	s4, w15
1000c0248:     	ldp	s5, s6, [x3]
1000c024c:     	fmsub	s4, s4, s3, s5
1000c0250:     	str	s4, [x3]
1000c0254:     	ldrb	w15, [x14, #4]
1000c0258:     	lsr	w15, w15, w12
1000c025c:     	and	w16, w15, #0xf
1000c0260:     	cmp	w16, #8
1000c0264:     	csel	w16, wzr, w10, lo
1000c0268:     	bfxil	w16, w15, #0, #4
1000c026c:     	scvtf	s4, w16
1000c0270:     	fmsub	s4, s4, s3, s6
1000c0274:     	str	s4, [x3, #4]
1000c0278:     	ldrb	w15, [x14, #8]
1000c027c:     	lsr	w15, w15, w12
1000c0280:     	and	w16, w15, #0xf
1000c0284:     	cmp	w16, #8
1000c0288:     	csel	w16, wzr, w10, lo
1000c028c:     	bfxil	w16, w15, #0, #4
1000c0290:     	scvtf	s4, w16
1000c0294:     	fmsub	s0, s4, s3, s0
1000c0298:     	str	s0, [x3, #8]
1000c029c:     	ldrb	w15, [x14, #12]
1000c02a0:     	lsr	w15, w15, w12
1000c02a4:     	and	w16, w15, #0xf
1000c02a8:     	cmp	w16, #8
1000c02ac:     	csel	w16, wzr, w10, lo
1000c02b0:     	bfxil	w16, w15, #0, #4
1000c02b4:     	scvtf	s4, w16
1000c02b8:     	fmsub	s1, s4, s3, s1
1000c02bc:     	str	s1, [x3, #12]
1000c02c0:     	ldrb	w15, [x14, #16]
1000c02c4:     	lsr	w15, w15, w12
1000c02c8:     	and	w16, w15, #0xf
1000c02cc:     	cmp	w16, #8
1000c02d0:     	csel	w16, wzr, w10, lo
1000c02d4:     	bfxil	w16, w15, #0, #4
1000c02d8:     	scvtf	s4, w16
1000c02dc:     	fmsub	s2, s4, s3, s2
1000c02e0:     	str	s2, [x3, #16]
1000c02e4:     	ldrb	w15, [x14, #20]
1000c02e8:     	lsr	w15, w15, w12
1000c02ec:     	and	w16, w15, #0xf
1000c02f0:     	cmp	w16, #8
1000c02f4:     	csel	w16, wzr, w10, lo
1000c02f8:     	bfxil	w16, w15, #0, #4
1000c02fc:     	scvtf	s4, w16
1000c0300:     	ldp	s5, s6, [x3, #20]
1000c0304:     	fmsub	s4, s4, s3, s5
1000c0308:     	str	s4, [x3, #20]
1000c030c:     	ldrb	w14, [x14, #24]
1000c0310:     	lsr	w14, w14, w12
1000c0314:     	and	w15, w14, #0xf
1000c0318:     	cmp	w15, #8
1000c031c:     	csel	w15, wzr, w10, lo
1000c0320:     	bfxil	w15, w14, #0, #4
1000c0324:     	scvtf	s4, w15
1000c0328:     	fmsub	s4, s4, s3, s6
1000c032c:     	str	s4, [x3, #24]
1000c0330:     	orr	x11, x9, x11
1000c0334:     	orr	x11, x11, #0x1c
1000c0338:     	ldrb	w11, [x0, x11]
1000c033c:     	lsr	w11, w11, w12
1000c0340:     	and	w12, w11, #0xf
1000c0344:     	cmp	w12, #8
1000c0348:     	csel	w12, wzr, w10, lo
1000c034c:     	bfxil	w12, w11, #0, #4
1000c0350:     	scvtf	s4, w12
1000c0354:     	ldr	s5, [x3, #28]
1000c0358:     	fmsub	s3, s4, s3, s5
1000c035c:     	str	s3, [x3, #28]
1000c0360:     	add	x13, x13, #1
1000c0364:     	add	x9, x9, #4
1000c0368:     	cmp	x2, x13
1000c036c:     	b.ne	0x1000c01f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x440>
1000c0370:     	ldp	x20, x19, [sp, #32]
1000c0374:     	ldp	x22, x21, [sp, #16]
1000c0378:     	ldp	x24, x23, [sp], #48
1000c037c:     	ret

00000001000c1920 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c1920:     	sub	sp, sp, #208
1000c1924:     	stp	x28, x27, [sp, #112]
1000c1928:     	stp	x26, x25, [sp, #128]
1000c192c:     	stp	x24, x23, [sp, #144]
1000c1930:     	stp	x22, x21, [sp, #160]
1000c1934:     	stp	x20, x19, [sp, #176]
1000c1938:     	stp	x29, x30, [sp, #192]
1000c193c:     	add	x29, sp, #192
1000c1940:     	str	x3, [sp]
1000c1944:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x4>
1000c1948:     	ldr	x8, [x8, #392]
1000c194c:     	ldr	x8, [x8]
1000c1950:     	stur	x8, [x29, #-88]
1000c1954:     	movi.2d	v0, #0000000000000000
1000c1958:     	stp	q0, q0, [sp, #64]
1000c195c:     	stp	q0, q0, [sp, #32]
1000c1960:     	ands	x8, x2, #0xfffffffffffffffe
1000c1964:     	b.eq	0x1000c1ae8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c1968:     	add	x8, x1, x8
1000c196c:     	str	x8, [sp, #8]
1000c1970:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x28>
1000c1974:     	add	x9, x9, #700
1000c1978:     	mov	x11, #0
1000c197c:     	ldp	w4, w23, [x1]
1000c1980:     	ubfx	x8, x4, #8, #4
1000c1984:     	stp	x1, x8, [sp, #16]
1000c1988:     	ubfx	x13, x4, #16, #4
1000c198c:     	and	x14, x4, #0xf
1000c1990:     	ubfx	x15, x4, #24, #4
1000c1994:     	ubfx	x16, x4, #4, #4
1000c1998:     	ubfx	x17, x4, #12, #4
1000c199c:     	ubfx	x2, x4, #20, #4
1000c19a0:     	lsr	x4, x4, #28
1000c19a4:     	and	x5, x23, #0xf
1000c19a8:     	ubfx	x6, x23, #8, #4
1000c19ac:     	ubfx	x7, x23, #16, #4
1000c19b0:     	ubfx	x19, x23, #24, #4
1000c19b4:     	ubfx	x20, x23, #4, #4
1000c19b8:     	ubfx	x21, x23, #12, #4
1000c19bc:     	ubfx	x22, x23, #20, #4
1000c19c0:     	lsr	x23, x23, #28
1000c19c4:     	ldr	w24, [x0, x11]
1000c19c8:     	lsl	w25, w24, #4
1000c19cc:     	and	x25, x25, #0xf0
1000c19d0:     	add	x25, x9, x25
1000c19d4:     	and	x26, x24, #0xf0
1000c19d8:     	add	x26, x9, x26
1000c19dc:     	lsr	x27, x24, #4
1000c19e0:     	and	x27, x27, #0xf0
1000c19e4:     	add	x27, x9, x27
1000c19e8:     	lsr	x28, x24, #8
1000c19ec:     	and	x28, x28, #0xf0
1000c19f0:     	add	x28, x9, x28
1000c19f4:     	lsr	x30, x24, #12
1000c19f8:     	and	x30, x30, #0xf0
1000c19fc:     	add	x30, x9, x30
1000c1a00:     	lsr	x8, x24, #16
1000c1a04:     	and	x8, x8, #0xf0
1000c1a08:     	add	x8, x9, x8
1000c1a0c:     	lsr	x3, x24, #20
1000c1a10:     	and	x3, x3, #0xf0
1000c1a14:     	add	x3, x9, x3
1000c1a18:     	lsr	x24, x24, #24
1000c1a1c:     	and	x24, x24, #0xf0
1000c1a20:     	ldrb	w10, [x25, x14]
1000c1a24:     	ldr	x12, [sp, #24]
1000c1a28:     	ldrb	w1, [x27, x12]
1000c1a2c:     	ldrb	w12, [x30, x13]
1000c1a30:     	add	w10, w10, w1
1000c1a34:     	add	w10, w10, w12
1000c1a38:     	ldrb	w12, [x3, x15]
1000c1a3c:     	ldrb	w1, [x26, x16]
1000c1a40:     	add	w10, w10, w12
1000c1a44:     	add	w10, w10, w1
1000c1a48:     	ldrb	w12, [x28, x17]
1000c1a4c:     	ldrb	w1, [x8, x2]
1000c1a50:     	add	x24, x9, x24
1000c1a54:     	add	w10, w10, w12
1000c1a58:     	add	w10, w10, w1
1000c1a5c:     	ldrb	w12, [x24, x4]
1000c1a60:     	add	w10, w10, w12
1000c1a64:     	scvtf	s0, w10
1000c1a68:     	add	x10, sp, #32
1000c1a6c:     	add	x10, x10, x11
1000c1a70:     	ldr	s1, [x10]
1000c1a74:     	ldrb	w12, [x25, x5]
1000c1a78:     	fadd	s0, s1, s0
1000c1a7c:     	ldrb	w1, [x27, x6]
1000c1a80:     	ldrb	w25, [x30, x7]
1000c1a84:     	add	w12, w12, w1
1000c1a88:     	add	w12, w12, w25
1000c1a8c:     	ldrb	w1, [x3, x19]
1000c1a90:     	ldrb	w3, [x26, x20]
1000c1a94:     	add	w12, w12, w1
1000c1a98:     	add	w12, w12, w3
1000c1a9c:     	ldrb	w1, [x28, x21]
1000c1aa0:     	ldrb	w8, [x8, x22]
1000c1aa4:     	add	w12, w12, w1
1000c1aa8:     	add	w8, w12, w8
1000c1aac:     	ldrb	w12, [x24, x23]
1000c1ab0:     	add	w8, w8, w12
1000c1ab4:     	scvtf	s1, w8
1000c1ab8:     	str	s0, [x10]
1000c1abc:     	ldr	s0, [x10, #32]
1000c1ac0:     	fadd	s0, s0, s1
1000c1ac4:     	str	s0, [x10, #32]
1000c1ac8:     	add	x11, x11, #4
1000c1acc:     	cmp	x11, #32
1000c1ad0:     	b.ne	0x1000c19c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1ad4:     	add	x0, x0, #32
1000c1ad8:     	ldp	x8, x1, [sp, #8]
1000c1adc:     	add	x1, x1, #8
1000c1ae0:     	cmp	x1, x8
1000c1ae4:     	b.ne	0x1000c1978 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1ae8:     	ldp	q0, q1, [sp, #32]
1000c1aec:     	ldr	x8, [sp]
1000c1af0:     	stp	q0, q1, [x8]
1000c1af4:     	ldp	q0, q1, [sp, #64]
1000c1af8:     	stp	q0, q1, [x8, #32]
1000c1afc:     	ldur	x8, [x29, #-88]
1000c1b00:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c0>
1000c1b04:     	ldr	x9, [x9, #392]
1000c1b08:     	ldr	x9, [x9]
1000c1b0c:     	cmp	x9, x8
1000c1b10:     	b.ne	0x1000c1b34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1b14:     	ldp	x29, x30, [sp, #192]
1000c1b18:     	ldp	x20, x19, [sp, #176]
1000c1b1c:     	ldp	x22, x21, [sp, #160]
1000c1b20:     	ldp	x24, x23, [sp, #144]
1000c1b24:     	ldp	x26, x25, [sp, #128]
1000c1b28:     	ldp	x28, x27, [sp, #112]
1000c1b2c:     	add	sp, sp, #208
1000c1b30:     	ret
1000c1b34:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c1bec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c1bec:     	sub	sp, sp, #208
1000c1bf0:     	stp	x28, x27, [sp, #112]
1000c1bf4:     	stp	x26, x25, [sp, #128]
1000c1bf8:     	stp	x24, x23, [sp, #144]
1000c1bfc:     	stp	x22, x21, [sp, #160]
1000c1c00:     	stp	x20, x19, [sp, #176]
1000c1c04:     	stp	x29, x30, [sp, #192]
1000c1c08:     	add	x29, sp, #192
1000c1c0c:     	str	x3, [sp]
1000c1c10:     	adrp	x8, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xb8>
1000c1c14:     	ldr	x8, [x8, #392]
1000c1c18:     	ldr	x8, [x8]
1000c1c1c:     	stur	x8, [x29, #-88]
1000c1c20:     	movi.2d	v0, #0000000000000000
1000c1c24:     	stp	q0, q0, [sp, #64]
1000c1c28:     	stp	q0, q0, [sp, #32]
1000c1c2c:     	ands	x8, x2, #0xfffffffffffffffe
1000c1c30:     	b.eq	0x1000c1db4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c1c34:     	add	x8, x1, x8
1000c1c38:     	str	x8, [sp, #8]
1000c1c3c:     	adrp	x9, 0x10016a000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xdc>
1000c1c40:     	add	x9, x9, #956
1000c1c44:     	mov	x11, #0
1000c1c48:     	ldp	w4, w23, [x1]
1000c1c4c:     	ubfx	x8, x4, #8, #4
1000c1c50:     	stp	x1, x8, [sp, #16]
1000c1c54:     	ubfx	x13, x4, #16, #4
1000c1c58:     	and	x14, x4, #0xf
1000c1c5c:     	ubfx	x15, x4, #24, #4
1000c1c60:     	ubfx	x16, x4, #4, #4
1000c1c64:     	ubfx	x17, x4, #12, #4
1000c1c68:     	ubfx	x2, x4, #20, #4
1000c1c6c:     	lsr	x4, x4, #28
1000c1c70:     	and	x5, x23, #0xf
1000c1c74:     	ubfx	x6, x23, #8, #4
1000c1c78:     	ubfx	x7, x23, #16, #4
1000c1c7c:     	ubfx	x19, x23, #24, #4
1000c1c80:     	ubfx	x20, x23, #4, #4
1000c1c84:     	ubfx	x21, x23, #12, #4
1000c1c88:     	ubfx	x22, x23, #20, #4
1000c1c8c:     	lsr	x23, x23, #28
1000c1c90:     	ldr	w24, [x0, x11]
1000c1c94:     	lsl	w25, w24, #4
1000c1c98:     	and	x25, x25, #0xf0
1000c1c9c:     	add	x25, x9, x25
1000c1ca0:     	and	x26, x24, #0xf0
1000c1ca4:     	add	x26, x9, x26
1000c1ca8:     	lsr	x27, x24, #4
1000c1cac:     	and	x27, x27, #0xf0
1000c1cb0:     	add	x27, x9, x27
1000c1cb4:     	lsr	x28, x24, #8
1000c1cb8:     	and	x28, x28, #0xf0
1000c1cbc:     	add	x28, x9, x28
1000c1cc0:     	lsr	x30, x24, #12
1000c1cc4:     	and	x30, x30, #0xf0
1000c1cc8:     	add	x30, x9, x30
1000c1ccc:     	lsr	x8, x24, #16
1000c1cd0:     	and	x8, x8, #0xf0
1000c1cd4:     	add	x8, x9, x8
1000c1cd8:     	lsr	x3, x24, #20
1000c1cdc:     	and	x3, x3, #0xf0
1000c1ce0:     	add	x3, x9, x3
1000c1ce4:     	lsr	x24, x24, #24
1000c1ce8:     	and	x24, x24, #0xf0
1000c1cec:     	ldrsb	w10, [x25, x14]
1000c1cf0:     	ldr	x12, [sp, #24]
1000c1cf4:     	ldrsb	w1, [x27, x12]
1000c1cf8:     	ldrsb	w12, [x30, x13]
1000c1cfc:     	add	w10, w10, w1
1000c1d00:     	add	w10, w10, w12
1000c1d04:     	ldrsb	w12, [x3, x15]
1000c1d08:     	ldrsb	w1, [x26, x16]
1000c1d0c:     	add	w10, w10, w12
1000c1d10:     	add	w10, w10, w1
1000c1d14:     	ldrsb	w12, [x28, x17]
1000c1d18:     	ldrsb	w1, [x8, x2]
1000c1d1c:     	add	x24, x9, x24
1000c1d20:     	add	w10, w10, w12
1000c1d24:     	add	w10, w10, w1
1000c1d28:     	ldrsb	w12, [x24, x4]
1000c1d2c:     	add	w10, w10, w12
1000c1d30:     	scvtf	s0, w10
1000c1d34:     	add	x10, sp, #32
1000c1d38:     	add	x10, x10, x11
1000c1d3c:     	ldr	s1, [x10]
1000c1d40:     	ldrsb	w12, [x25, x5]
1000c1d44:     	fadd	s0, s1, s0
1000c1d48:     	ldrsb	w1, [x27, x6]
1000c1d4c:     	ldrsb	w25, [x30, x7]
1000c1d50:     	add	w12, w12, w1
1000c1d54:     	add	w12, w12, w25
1000c1d58:     	ldrsb	w1, [x3, x19]
1000c1d5c:     	ldrsb	w3, [x26, x20]
1000c1d60:     	add	w12, w12, w1
1000c1d64:     	add	w12, w12, w3
1000c1d68:     	ldrsb	w1, [x28, x21]
1000c1d6c:     	ldrsb	w8, [x8, x22]
1000c1d70:     	add	w12, w12, w1
1000c1d74:     	add	w8, w12, w8
1000c1d78:     	ldrsb	w12, [x24, x23]
1000c1d7c:     	add	w8, w8, w12
1000c1d80:     	scvtf	s1, w8
1000c1d84:     	str	s0, [x10]
1000c1d88:     	ldr	s0, [x10, #32]
1000c1d8c:     	fadd	s0, s0, s1
1000c1d90:     	str	s0, [x10, #32]
1000c1d94:     	add	x11, x11, #4
1000c1d98:     	cmp	x11, #32
1000c1d9c:     	b.ne	0x1000c1c90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1da0:     	add	x0, x0, #32
1000c1da4:     	ldp	x8, x1, [sp, #8]
1000c1da8:     	add	x1, x1, #8
1000c1dac:     	cmp	x1, x8
1000c1db0:     	b.ne	0x1000c1c44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1db4:     	ldp	q0, q1, [sp, #32]
1000c1db8:     	ldr	x8, [sp]
1000c1dbc:     	stp	q0, q1, [x8]
1000c1dc0:     	ldp	q0, q1, [sp, #64]
1000c1dc4:     	stp	q0, q1, [x8, #32]
1000c1dc8:     	ldur	x8, [x29, #-88]
1000c1dcc:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x274>
1000c1dd0:     	ldr	x9, [x9, #392]
1000c1dd4:     	ldr	x9, [x9]
1000c1dd8:     	cmp	x9, x8
1000c1ddc:     	b.ne	0x1000c1e00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1de0:     	ldp	x29, x30, [sp, #192]
1000c1de4:     	ldp	x20, x19, [sp, #176]
1000c1de8:     	ldp	x22, x21, [sp, #160]
1000c1dec:     	ldp	x24, x23, [sp, #144]
1000c1df0:     	ldp	x26, x25, [sp, #128]
1000c1df4:     	ldp	x28, x27, [sp, #112]
1000c1df8:     	add	sp, sp, #208
1000c1dfc:     	ret
1000c1e00:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c3700 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c3700:     	sub	sp, sp, #416
1000c3704:     	stp	x28, x27, [sp, #320]
1000c3708:     	stp	x26, x25, [sp, #336]
1000c370c:     	stp	x24, x23, [sp, #352]
1000c3710:     	stp	x22, x21, [sp, #368]
1000c3714:     	stp	x20, x19, [sp, #384]
1000c3718:     	stp	x29, x30, [sp, #400]
1000c371c:     	add	x29, sp, #400
1000c3720:     	str	x3, [sp]
1000c3724:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
1000c3728:     	ldr	x8, [x8, #392]
1000c372c:     	ldr	x8, [x8]
1000c3730:     	stur	x8, [x29, #-96]
1000c3734:     	movi.2d	v0, #0000000000000000
1000c3738:     	stp	q0, q0, [sp, #272]
1000c373c:     	lsl	x8, x2, #1
1000c3740:     	stp	q0, q0, [sp, #240]
1000c3744:     	stp	q0, q0, [sp, #208]
1000c3748:     	stp	q0, q0, [sp, #176]
1000c374c:     	ands	x8, x8, #0xfffffffffffffffc
1000c3750:     	b.eq	0x1000c3a2c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c3754:     	add	x8, x1, x8
1000c3758:     	str	x8, [sp, #8]
1000c375c:     	add	x8, sp, #176
1000c3760:     	add	x27, x8, #64
1000c3764:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x300>
1000c3768:     	add	x11, x11, #700
1000c376c:     	mov	x12, #0
1000c3770:     	ldp	w8, w9, [x1]
1000c3774:     	ubfx	x10, x8, #8, #4
1000c3778:     	str	x10, [sp, #168]
1000c377c:     	ubfx	x10, x8, #16, #4
1000c3780:     	str	x10, [sp, #160]
1000c3784:     	ubfx	x10, x8, #24, #4
1000c3788:     	str	x10, [sp, #152]
1000c378c:     	ldp	w10, w17, [x1, #8]
1000c3790:     	str	x1, [sp, #16]
1000c3794:     	and	x14, x8, #0xf
1000c3798:     	ubfx	x13, x8, #4, #4
1000c379c:     	stp	x13, x14, [sp, #136]
1000c37a0:     	ubfx	x14, x8, #12, #4
1000c37a4:     	ubfx	x13, x8, #20, #4
1000c37a8:     	stp	x13, x14, [sp, #120]
1000c37ac:     	lsr	x8, x8, #28
1000c37b0:     	str	x8, [sp, #112]
1000c37b4:     	and	x8, x9, #0xf
1000c37b8:     	str	x8, [sp, #104]
1000c37bc:     	ubfx	x8, x9, #8, #4
1000c37c0:     	str	x8, [sp, #96]
1000c37c4:     	ubfx	x8, x9, #16, #4
1000c37c8:     	str	x8, [sp, #88]
1000c37cc:     	ubfx	x8, x9, #24, #4
1000c37d0:     	str	x8, [sp, #80]
1000c37d4:     	ubfx	x8, x9, #4, #4
1000c37d8:     	str	x8, [sp, #72]
1000c37dc:     	ubfx	x8, x9, #12, #4
1000c37e0:     	str	x8, [sp, #64]
1000c37e4:     	ubfx	x8, x9, #20, #4
1000c37e8:     	str	x8, [sp, #56]
1000c37ec:     	lsr	x8, x9, #28
1000c37f0:     	str	x8, [sp, #48]
1000c37f4:     	and	x9, x10, #0xf
1000c37f8:     	ubfx	x8, x10, #8, #4
1000c37fc:     	stp	x8, x9, [sp, #32]
1000c3800:     	ubfx	x8, x10, #16, #4
1000c3804:     	str	x8, [sp, #24]
1000c3808:     	ubfx	x28, x10, #24, #4
1000c380c:     	ubfx	x30, x10, #4, #4
1000c3810:     	ubfx	x8, x10, #12, #4
1000c3814:     	ubfx	x3, x10, #20, #4
1000c3818:     	lsr	x9, x10, #28
1000c381c:     	and	x1, x17, #0xf
1000c3820:     	ubfx	x10, x17, #8, #4
1000c3824:     	ubfx	x13, x17, #16, #4
1000c3828:     	ubfx	x26, x17, #24, #4
1000c382c:     	ubfx	x14, x17, #4, #4
1000c3830:     	ubfx	x15, x17, #12, #4
1000c3834:     	ubfx	x16, x17, #20, #4
1000c3838:     	lsr	x17, x17, #28
1000c383c:     	ldr	w20, [x0, x12]
1000c3840:     	lsl	w2, w20, #4
1000c3844:     	and	x2, x2, #0xf0
1000c3848:     	add	x5, x11, x2
1000c384c:     	and	x2, x20, #0xf0
1000c3850:     	add	x2, x11, x2
1000c3854:     	lsr	x4, x20, #4
1000c3858:     	and	x4, x4, #0xf0
1000c385c:     	add	x7, x11, x4
1000c3860:     	lsr	x4, x20, #8
1000c3864:     	and	x4, x4, #0xf0
1000c3868:     	add	x4, x11, x4
1000c386c:     	lsr	x6, x20, #12
1000c3870:     	and	x6, x6, #0xf0
1000c3874:     	add	x19, x11, x6
1000c3878:     	lsr	x6, x20, #16
1000c387c:     	and	x6, x6, #0xf0
1000c3880:     	add	x6, x11, x6
1000c3884:     	lsr	x21, x20, #20
1000c3888:     	and	x21, x21, #0xf0
1000c388c:     	add	x21, x11, x21
1000c3890:     	lsr	x20, x20, #24
1000c3894:     	and	x20, x20, #0xf0
1000c3898:     	ldr	x22, [sp, #144]
1000c389c:     	ldrb	w22, [x5, x22]
1000c38a0:     	add	x20, x11, x20
1000c38a4:     	ldp	x24, x23, [sp, #160]
1000c38a8:     	ldrb	w23, [x7, x23]
1000c38ac:     	ldrb	w24, [x19, x24]
1000c38b0:     	add	w22, w22, w23
1000c38b4:     	add	w22, w22, w24
1000c38b8:     	ldr	x23, [sp, #152]
1000c38bc:     	ldrb	w23, [x21, x23]
1000c38c0:     	ldr	x24, [sp, #136]
1000c38c4:     	ldrb	w24, [x2, x24]
1000c38c8:     	add	w22, w22, w23
1000c38cc:     	add	w22, w22, w24
1000c38d0:     	ldp	x24, x23, [sp, #120]
1000c38d4:     	ldrb	w23, [x4, x23]
1000c38d8:     	ldrb	w24, [x6, x24]
1000c38dc:     	add	w22, w22, w23
1000c38e0:     	add	w22, w22, w24
1000c38e4:     	ldr	x23, [sp, #112]
1000c38e8:     	ldrb	w23, [x20, x23]
1000c38ec:     	add	w22, w22, w23
1000c38f0:     	scvtf	s0, w22
1000c38f4:     	ldp	x23, x22, [sp, #96]
1000c38f8:     	ldrb	w22, [x5, x22]
1000c38fc:     	ldrb	w23, [x7, x23]
1000c3900:     	ldp	x25, x24, [sp, #80]
1000c3904:     	ldrb	w24, [x19, x24]
1000c3908:     	ldrb	w25, [x21, x25]
1000c390c:     	add	w22, w22, w23
1000c3910:     	ldr	x23, [sp, #72]
1000c3914:     	ldrb	w23, [x2, x23]
1000c3918:     	add	w22, w22, w24
1000c391c:     	ldr	x24, [sp, #64]
1000c3920:     	ldrb	w24, [x4, x24]
1000c3924:     	add	w22, w22, w25
1000c3928:     	ldr	x25, [sp, #56]
1000c392c:     	ldrb	w25, [x6, x25]
1000c3930:     	add	w22, w22, w23
1000c3934:     	add	w22, w22, w24
1000c3938:     	add	w22, w22, w25
1000c393c:     	ldr	x23, [sp, #48]
1000c3940:     	ldrb	w23, [x20, x23]
1000c3944:     	add	w22, w22, w23
1000c3948:     	scvtf	s1, w22
1000c394c:     	ldp	x23, x22, [sp, #32]
1000c3950:     	ldrb	w22, [x5, x22]
1000c3954:     	ldrb	w23, [x7, x23]
1000c3958:     	ldr	x24, [sp, #24]
1000c395c:     	ldrb	w24, [x19, x24]
1000c3960:     	add	w22, w22, w23
1000c3964:     	ldrb	w23, [x21, x28]
1000c3968:     	add	w22, w22, w24
1000c396c:     	ldrb	w24, [x2, x30]
1000c3970:     	add	w22, w22, w23
1000c3974:     	ldrb	w23, [x4, x8]
1000c3978:     	add	w22, w22, w24
1000c397c:     	ldrb	w24, [x6, x3]
1000c3980:     	add	w22, w22, w23
1000c3984:     	ldrb	w23, [x20, x9]
1000c3988:     	add	w22, w22, w24
1000c398c:     	add	w22, w22, w23
1000c3990:     	scvtf	s2, w22
1000c3994:     	ldrb	w5, [x5, x1]
1000c3998:     	ldrb	w7, [x7, x10]
1000c399c:     	ldrb	w19, [x19, x13]
1000c39a0:     	add	w5, w5, w7
1000c39a4:     	add	w5, w5, w19
1000c39a8:     	ldrb	w7, [x21, x26]
1000c39ac:     	ldrb	w2, [x2, x14]
1000c39b0:     	add	w5, w5, w7
1000c39b4:     	add	w2, w5, w2
1000c39b8:     	ldrb	w4, [x4, x15]
1000c39bc:     	ldrb	w5, [x6, x16]
1000c39c0:     	add	w2, w2, w4
1000c39c4:     	add	w2, w2, w5
1000c39c8:     	ldrb	w4, [x20, x17]
1000c39cc:     	add	w2, w2, w4
1000c39d0:     	add	x4, sp, #176
1000c39d4:     	scvtf	s3, w2
1000c39d8:     	add	x2, x27, x12
1000c39dc:     	ldur	s4, [x2, #-32]
1000c39e0:     	fadd	s1, s4, s1
1000c39e4:     	stur	s1, [x2, #-32]
1000c39e8:     	ldr	s1, [x2]
1000c39ec:     	fadd	s1, s1, s2
1000c39f0:     	str	s1, [x2]
1000c39f4:     	ldr	s1, [x2, #32]
1000c39f8:     	fadd	s1, s1, s3
1000c39fc:     	ldr	s2, [x4, x12]
1000c3a00:     	str	s1, [x2, #32]
1000c3a04:     	fadd	s0, s2, s0
1000c3a08:     	str	s0, [x4, x12]
1000c3a0c:     	add	x12, x12, #4
1000c3a10:     	cmp	x12, #32
1000c3a14:     	b.ne	0x1000c383c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3a18:     	add	x0, x0, #32
1000c3a1c:     	ldp	x8, x1, [sp, #8]
1000c3a20:     	add	x1, x1, #16
1000c3a24:     	cmp	x1, x8
1000c3a28:     	b.ne	0x1000c376c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c3a2c:     	ldp	q0, q1, [sp, #240]
1000c3a30:     	ldr	x8, [sp]
1000c3a34:     	stp	q0, q1, [x8, #64]
1000c3a38:     	ldp	q0, q1, [sp, #272]
1000c3a3c:     	stp	q0, q1, [x8, #96]
1000c3a40:     	ldp	q0, q1, [sp, #176]
1000c3a44:     	stp	q0, q1, [x8]
1000c3a48:     	ldp	q0, q1, [sp, #208]
1000c3a4c:     	stp	q0, q1, [x8, #32]
1000c3a50:     	ldur	x8, [x29, #-96]
1000c3a54:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000c3a58:     	ldr	x9, [x9, #392]
1000c3a5c:     	ldr	x9, [x9]
1000c3a60:     	cmp	x9, x8
1000c3a64:     	b.ne	0x1000c3a88 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c3a68:     	ldp	x29, x30, [sp, #400]
1000c3a6c:     	ldp	x20, x19, [sp, #384]
1000c3a70:     	ldp	x22, x21, [sp, #368]
1000c3a74:     	ldp	x24, x23, [sp, #352]
1000c3a78:     	ldp	x26, x25, [sp, #336]
1000c3a7c:     	ldp	x28, x27, [sp, #320]
1000c3a80:     	add	sp, sp, #416
1000c3a84:     	ret
1000c3a88:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c3b8c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c3b8c:     	sub	sp, sp, #416
1000c3b90:     	stp	x28, x27, [sp, #320]
1000c3b94:     	stp	x26, x25, [sp, #336]
1000c3b98:     	stp	x24, x23, [sp, #352]
1000c3b9c:     	stp	x22, x21, [sp, #368]
1000c3ba0:     	stp	x20, x19, [sp, #384]
1000c3ba4:     	stp	x29, x30, [sp, #400]
1000c3ba8:     	add	x29, sp, #400
1000c3bac:     	str	x3, [sp]
1000c3bb0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c8>
1000c3bb4:     	ldr	x8, [x8, #392]
1000c3bb8:     	ldr	x8, [x8]
1000c3bbc:     	stur	x8, [x29, #-96]
1000c3bc0:     	movi.2d	v0, #0000000000000000
1000c3bc4:     	stp	q0, q0, [sp, #272]
1000c3bc8:     	lsl	x8, x2, #1
1000c3bcc:     	stp	q0, q0, [sp, #240]
1000c3bd0:     	stp	q0, q0, [sp, #208]
1000c3bd4:     	stp	q0, q0, [sp, #176]
1000c3bd8:     	ands	x8, x8, #0xfffffffffffffffc
1000c3bdc:     	b.eq	0x1000c3eb8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x32c>
1000c3be0:     	add	x8, x1, x8
1000c3be4:     	str	x8, [sp, #8]
1000c3be8:     	add	x8, sp, #176
1000c3bec:     	add	x27, x8, #64
1000c3bf0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x300>
1000c3bf4:     	add	x11, x11, #956
1000c3bf8:     	mov	x12, #0
1000c3bfc:     	ldp	w8, w9, [x1]
1000c3c00:     	ubfx	x10, x8, #8, #4
1000c3c04:     	str	x10, [sp, #168]
1000c3c08:     	ubfx	x10, x8, #16, #4
1000c3c0c:     	str	x10, [sp, #160]
1000c3c10:     	ubfx	x10, x8, #24, #4
1000c3c14:     	str	x10, [sp, #152]
1000c3c18:     	ldp	w10, w17, [x1, #8]
1000c3c1c:     	str	x1, [sp, #16]
1000c3c20:     	and	x14, x8, #0xf
1000c3c24:     	ubfx	x13, x8, #4, #4
1000c3c28:     	stp	x13, x14, [sp, #136]
1000c3c2c:     	ubfx	x14, x8, #12, #4
1000c3c30:     	ubfx	x13, x8, #20, #4
1000c3c34:     	stp	x13, x14, [sp, #120]
1000c3c38:     	lsr	x8, x8, #28
1000c3c3c:     	str	x8, [sp, #112]
1000c3c40:     	and	x8, x9, #0xf
1000c3c44:     	str	x8, [sp, #104]
1000c3c48:     	ubfx	x8, x9, #8, #4
1000c3c4c:     	str	x8, [sp, #96]
1000c3c50:     	ubfx	x8, x9, #16, #4
1000c3c54:     	str	x8, [sp, #88]
1000c3c58:     	ubfx	x8, x9, #24, #4
1000c3c5c:     	str	x8, [sp, #80]
1000c3c60:     	ubfx	x8, x9, #4, #4
1000c3c64:     	str	x8, [sp, #72]
1000c3c68:     	ubfx	x8, x9, #12, #4
1000c3c6c:     	str	x8, [sp, #64]
1000c3c70:     	ubfx	x8, x9, #20, #4
1000c3c74:     	str	x8, [sp, #56]
1000c3c78:     	lsr	x8, x9, #28
1000c3c7c:     	str	x8, [sp, #48]
1000c3c80:     	and	x9, x10, #0xf
1000c3c84:     	ubfx	x8, x10, #8, #4
1000c3c88:     	stp	x8, x9, [sp, #32]
1000c3c8c:     	ubfx	x8, x10, #16, #4
1000c3c90:     	str	x8, [sp, #24]
1000c3c94:     	ubfx	x28, x10, #24, #4
1000c3c98:     	ubfx	x30, x10, #4, #4
1000c3c9c:     	ubfx	x8, x10, #12, #4
1000c3ca0:     	ubfx	x3, x10, #20, #4
1000c3ca4:     	lsr	x9, x10, #28
1000c3ca8:     	and	x1, x17, #0xf
1000c3cac:     	ubfx	x10, x17, #8, #4
1000c3cb0:     	ubfx	x13, x17, #16, #4
1000c3cb4:     	ubfx	x26, x17, #24, #4
1000c3cb8:     	ubfx	x14, x17, #4, #4
1000c3cbc:     	ubfx	x15, x17, #12, #4
1000c3cc0:     	ubfx	x16, x17, #20, #4
1000c3cc4:     	lsr	x17, x17, #28
1000c3cc8:     	ldr	w20, [x0, x12]
1000c3ccc:     	lsl	w2, w20, #4
1000c3cd0:     	and	x2, x2, #0xf0
1000c3cd4:     	add	x5, x11, x2
1000c3cd8:     	and	x2, x20, #0xf0
1000c3cdc:     	add	x2, x11, x2
1000c3ce0:     	lsr	x4, x20, #4
1000c3ce4:     	and	x4, x4, #0xf0
1000c3ce8:     	add	x7, x11, x4
1000c3cec:     	lsr	x4, x20, #8
1000c3cf0:     	and	x4, x4, #0xf0
1000c3cf4:     	add	x4, x11, x4
1000c3cf8:     	lsr	x6, x20, #12
1000c3cfc:     	and	x6, x6, #0xf0
1000c3d00:     	add	x19, x11, x6
1000c3d04:     	lsr	x6, x20, #16
1000c3d08:     	and	x6, x6, #0xf0
1000c3d0c:     	add	x6, x11, x6
1000c3d10:     	lsr	x21, x20, #20
1000c3d14:     	and	x21, x21, #0xf0
1000c3d18:     	add	x21, x11, x21
1000c3d1c:     	lsr	x20, x20, #24
1000c3d20:     	and	x20, x20, #0xf0
1000c3d24:     	ldr	x22, [sp, #144]
1000c3d28:     	ldrsb	w22, [x5, x22]
1000c3d2c:     	add	x20, x11, x20
1000c3d30:     	ldp	x24, x23, [sp, #160]
1000c3d34:     	ldrsb	w23, [x7, x23]
1000c3d38:     	ldrsb	w24, [x19, x24]
1000c3d3c:     	add	w22, w22, w23
1000c3d40:     	add	w22, w22, w24
1000c3d44:     	ldr	x23, [sp, #152]
1000c3d48:     	ldrsb	w23, [x21, x23]
1000c3d4c:     	ldr	x24, [sp, #136]
1000c3d50:     	ldrsb	w24, [x2, x24]
1000c3d54:     	add	w22, w22, w23
1000c3d58:     	add	w22, w22, w24
1000c3d5c:     	ldp	x24, x23, [sp, #120]
1000c3d60:     	ldrsb	w23, [x4, x23]
1000c3d64:     	ldrsb	w24, [x6, x24]
1000c3d68:     	add	w22, w22, w23
1000c3d6c:     	add	w22, w22, w24
1000c3d70:     	ldr	x23, [sp, #112]
1000c3d74:     	ldrsb	w23, [x20, x23]
1000c3d78:     	add	w22, w22, w23
1000c3d7c:     	scvtf	s0, w22
1000c3d80:     	ldp	x23, x22, [sp, #96]
1000c3d84:     	ldrsb	w22, [x5, x22]
1000c3d88:     	ldrsb	w23, [x7, x23]
1000c3d8c:     	ldp	x25, x24, [sp, #80]
1000c3d90:     	ldrsb	w24, [x19, x24]
1000c3d94:     	ldrsb	w25, [x21, x25]
1000c3d98:     	add	w22, w22, w23
1000c3d9c:     	ldr	x23, [sp, #72]
1000c3da0:     	ldrsb	w23, [x2, x23]
1000c3da4:     	add	w22, w22, w24
1000c3da8:     	ldr	x24, [sp, #64]
1000c3dac:     	ldrsb	w24, [x4, x24]
1000c3db0:     	add	w22, w22, w25
1000c3db4:     	ldr	x25, [sp, #56]
1000c3db8:     	ldrsb	w25, [x6, x25]
1000c3dbc:     	add	w22, w22, w23
1000c3dc0:     	add	w22, w22, w24
1000c3dc4:     	add	w22, w22, w25
1000c3dc8:     	ldr	x23, [sp, #48]
1000c3dcc:     	ldrsb	w23, [x20, x23]
1000c3dd0:     	add	w22, w22, w23
1000c3dd4:     	scvtf	s1, w22
1000c3dd8:     	ldp	x23, x22, [sp, #32]
1000c3ddc:     	ldrsb	w22, [x5, x22]
1000c3de0:     	ldrsb	w23, [x7, x23]
1000c3de4:     	ldr	x24, [sp, #24]
1000c3de8:     	ldrsb	w24, [x19, x24]
1000c3dec:     	add	w22, w22, w23
1000c3df0:     	ldrsb	w23, [x21, x28]
1000c3df4:     	add	w22, w22, w24
1000c3df8:     	ldrsb	w24, [x2, x30]
1000c3dfc:     	add	w22, w22, w23
1000c3e00:     	ldrsb	w23, [x4, x8]
1000c3e04:     	add	w22, w22, w24
1000c3e08:     	ldrsb	w24, [x6, x3]
1000c3e0c:     	add	w22, w22, w23
1000c3e10:     	ldrsb	w23, [x20, x9]
1000c3e14:     	add	w22, w22, w24
1000c3e18:     	add	w22, w22, w23
1000c3e1c:     	scvtf	s2, w22
1000c3e20:     	ldrsb	w5, [x5, x1]
1000c3e24:     	ldrsb	w7, [x7, x10]
1000c3e28:     	ldrsb	w19, [x19, x13]
1000c3e2c:     	add	w5, w5, w7
1000c3e30:     	add	w5, w5, w19
1000c3e34:     	ldrsb	w7, [x21, x26]
1000c3e38:     	ldrsb	w2, [x2, x14]
1000c3e3c:     	add	w5, w5, w7
1000c3e40:     	add	w2, w5, w2
1000c3e44:     	ldrsb	w4, [x4, x15]
1000c3e48:     	ldrsb	w5, [x6, x16]
1000c3e4c:     	add	w2, w2, w4
1000c3e50:     	add	w2, w2, w5
1000c3e54:     	ldrsb	w4, [x20, x17]
1000c3e58:     	add	w2, w2, w4
1000c3e5c:     	add	x4, sp, #176
1000c3e60:     	scvtf	s3, w2
1000c3e64:     	add	x2, x27, x12
1000c3e68:     	ldur	s4, [x2, #-32]
1000c3e6c:     	fadd	s1, s4, s1
1000c3e70:     	stur	s1, [x2, #-32]
1000c3e74:     	ldr	s1, [x2]
1000c3e78:     	fadd	s1, s1, s2
1000c3e7c:     	str	s1, [x2]
1000c3e80:     	ldr	s1, [x2, #32]
1000c3e84:     	fadd	s1, s1, s3
1000c3e88:     	ldr	s2, [x4, x12]
1000c3e8c:     	str	s1, [x2, #32]
1000c3e90:     	fadd	s0, s2, s0
1000c3e94:     	str	s0, [x4, x12]
1000c3e98:     	add	x12, x12, #4
1000c3e9c:     	cmp	x12, #32
1000c3ea0:     	b.ne	0x1000c3cc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000c3ea4:     	add	x0, x0, #32
1000c3ea8:     	ldp	x8, x1, [sp, #8]
1000c3eac:     	add	x1, x1, #16
1000c3eb0:     	cmp	x1, x8
1000c3eb4:     	b.ne	0x1000c3bf8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000c3eb8:     	ldp	q0, q1, [sp, #240]
1000c3ebc:     	ldr	x8, [sp]
1000c3ec0:     	stp	q0, q1, [x8, #64]
1000c3ec4:     	ldp	q0, q1, [sp, #272]
1000c3ec8:     	stp	q0, q1, [x8, #96]
1000c3ecc:     	ldp	q0, q1, [sp, #176]
1000c3ed0:     	stp	q0, q1, [x8]
1000c3ed4:     	ldp	q0, q1, [sp, #208]
1000c3ed8:     	stp	q0, q1, [x8, #32]
1000c3edc:     	ldur	x8, [x29, #-96]
1000c3ee0:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 8ul, false>(char const*)+0x26c>
1000c3ee4:     	ldr	x9, [x9, #392]
1000c3ee8:     	ldr	x9, [x9]
1000c3eec:     	cmp	x9, x8
1000c3ef0:     	b.ne	0x1000c3f14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x388>
1000c3ef4:     	ldp	x29, x30, [sp, #400]
1000c3ef8:     	ldp	x20, x19, [sp, #384]
1000c3efc:     	ldp	x22, x21, [sp, #368]
1000c3f00:     	ldp	x24, x23, [sp, #352]
1000c3f04:     	ldp	x26, x25, [sp, #336]
1000c3f08:     	ldp	x28, x27, [sp, #320]
1000c3f0c:     	add	sp, sp, #416
1000c3f10:     	ret
1000c3f14:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c54a4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c54a4:     	stp	x28, x27, [sp, #-96]!
1000c54a8:     	stp	x26, x25, [sp, #16]
1000c54ac:     	stp	x24, x23, [sp, #32]
1000c54b0:     	stp	x22, x21, [sp, #48]
1000c54b4:     	stp	x20, x19, [sp, #64]
1000c54b8:     	stp	x29, x30, [sp, #80]
1000c54bc:     	add	x29, sp, #80
1000c54c0:     	sub	sp, sp, #720
1000c54c4:     	str	x3, [sp, #8]
1000c54c8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c54cc:     	ldr	x8, [x8, #392]
1000c54d0:     	ldr	x8, [x8]
1000c54d4:     	stur	x8, [x29, #-96]
1000c54d8:     	movi.2d	v0, #0000000000000000
1000c54dc:     	stp	q0, q0, [sp, #672]
1000c54e0:     	lsl	x8, x2, #2
1000c54e4:     	stp	q0, q0, [sp, #640]
1000c54e8:     	stp	q0, q0, [sp, #608]
1000c54ec:     	stp	q0, q0, [sp, #576]
1000c54f0:     	stp	q0, q0, [sp, #544]
1000c54f4:     	stp	q0, q0, [sp, #512]
1000c54f8:     	stp	q0, q0, [sp, #480]
1000c54fc:     	stp	q0, q0, [sp, #448]
1000c5500:     	ands	x8, x8, #0xfffffffffffffff8
1000c5504:     	b.eq	0x1000c5a50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c5508:     	add	x8, x1, x8
1000c550c:     	str	x8, [sp, #16]
1000c5510:     	add	x8, sp, #448
1000c5514:     	add	x19, x8, #128
1000c5518:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000c551c:     	add	x11, x11, #700
1000c5520:     	mov	x12, #0
1000c5524:     	ldp	w8, w9, [x1]
1000c5528:     	ubfx	x10, x8, #8, #4
1000c552c:     	str	x10, [sp, #440]
1000c5530:     	ubfx	x10, x8, #16, #4
1000c5534:     	str	x10, [sp, #432]
1000c5538:     	ubfx	x10, x8, #24, #4
1000c553c:     	str	x10, [sp, #424]
1000c5540:     	ldp	w10, w13, [x1, #8]
1000c5544:     	and	x15, x8, #0xf
1000c5548:     	ubfx	x14, x8, #4, #4
1000c554c:     	stp	x14, x15, [sp, #408]
1000c5550:     	ubfx	x15, x8, #12, #4
1000c5554:     	ubfx	x14, x8, #20, #4
1000c5558:     	stp	x14, x15, [sp, #392]
1000c555c:     	lsr	x8, x8, #28
1000c5560:     	str	x8, [sp, #384]
1000c5564:     	and	x8, x9, #0xf
1000c5568:     	str	x8, [sp, #376]
1000c556c:     	ubfx	x8, x9, #8, #4
1000c5570:     	str	x8, [sp, #368]
1000c5574:     	ubfx	x8, x9, #16, #4
1000c5578:     	str	x8, [sp, #360]
1000c557c:     	ubfx	x8, x9, #24, #4
1000c5580:     	str	x8, [sp, #352]
1000c5584:     	ubfx	x8, x9, #4, #4
1000c5588:     	str	x8, [sp, #344]
1000c558c:     	ubfx	x8, x9, #12, #4
1000c5590:     	str	x8, [sp, #336]
1000c5594:     	ubfx	x8, x9, #20, #4
1000c5598:     	str	x8, [sp, #328]
1000c559c:     	lsr	x8, x9, #28
1000c55a0:     	str	x8, [sp, #320]
1000c55a4:     	and	x9, x10, #0xf
1000c55a8:     	ubfx	x8, x10, #8, #4
1000c55ac:     	stp	x8, x9, [sp, #304]
1000c55b0:     	ubfx	x9, x10, #16, #4
1000c55b4:     	ubfx	x8, x10, #24, #4
1000c55b8:     	stp	x8, x9, [sp, #288]
1000c55bc:     	ubfx	x9, x10, #4, #4
1000c55c0:     	ubfx	x8, x10, #12, #4
1000c55c4:     	stp	x8, x9, [sp, #272]
1000c55c8:     	ubfx	x9, x10, #20, #4
1000c55cc:     	lsr	x8, x10, #28
1000c55d0:     	stp	x8, x9, [sp, #256]
1000c55d4:     	and	x9, x13, #0xf
1000c55d8:     	ubfx	x8, x13, #8, #4
1000c55dc:     	stp	x8, x9, [sp, #240]
1000c55e0:     	ubfx	x9, x13, #16, #4
1000c55e4:     	ubfx	x8, x13, #24, #4
1000c55e8:     	stp	x8, x9, [sp, #224]
1000c55ec:     	ubfx	x9, x13, #4, #4
1000c55f0:     	ubfx	x8, x13, #12, #4
1000c55f4:     	stp	x8, x9, [sp, #208]
1000c55f8:     	ubfx	x9, x13, #20, #4
1000c55fc:     	lsr	x8, x13, #28
1000c5600:     	stp	x8, x9, [sp, #192]
1000c5604:     	ldp	w8, w9, [x1, #16]
1000c5608:     	and	x10, x8, #0xf
1000c560c:     	str	x10, [sp, #184]
1000c5610:     	ubfx	x10, x8, #8, #4
1000c5614:     	str	x10, [sp, #176]
1000c5618:     	ubfx	x10, x8, #16, #4
1000c561c:     	str	x10, [sp, #168]
1000c5620:     	ubfx	x10, x8, #24, #4
1000c5624:     	str	x10, [sp, #160]
1000c5628:     	ubfx	x10, x8, #4, #4
1000c562c:     	str	x10, [sp, #152]
1000c5630:     	ubfx	x10, x8, #12, #4
1000c5634:     	str	x10, [sp, #144]
1000c5638:     	ubfx	x10, x8, #20, #4
1000c563c:     	lsr	x8, x8, #28
1000c5640:     	stp	x8, x10, [sp, #128]
1000c5644:     	and	x10, x9, #0xf
1000c5648:     	ubfx	x8, x9, #8, #4
1000c564c:     	stp	x8, x10, [sp, #112]
1000c5650:     	ubfx	x10, x9, #16, #4
1000c5654:     	ubfx	x8, x9, #24, #4
1000c5658:     	stp	x8, x10, [sp, #96]
1000c565c:     	ubfx	x10, x9, #4, #4
1000c5660:     	ubfx	x8, x9, #12, #4
1000c5664:     	stp	x8, x10, [sp, #80]
1000c5668:     	ubfx	x10, x9, #20, #4
1000c566c:     	lsr	x8, x9, #28
1000c5670:     	stp	x8, x10, [sp, #64]
1000c5674:     	ldp	w14, w7, [x1, #24]
1000c5678:     	and	x9, x14, #0xf
1000c567c:     	ubfx	x8, x14, #8, #4
1000c5680:     	stp	x8, x9, [sp, #48]
1000c5684:     	ubfx	x8, x14, #16, #4
1000c5688:     	str	x8, [sp, #40]
1000c568c:     	ubfx	x8, x14, #24, #4
1000c5690:     	stp	x1, x8, [sp, #24]
1000c5694:     	ubfx	x10, x14, #4, #4
1000c5698:     	ubfx	x13, x14, #12, #4
1000c569c:     	ubfx	x9, x14, #20, #4
1000c56a0:     	lsr	x14, x14, #28
1000c56a4:     	and	x15, x7, #0xf
1000c56a8:     	ubfx	x16, x7, #8, #4
1000c56ac:     	ubfx	x17, x7, #16, #4
1000c56b0:     	ubfx	x2, x7, #24, #4
1000c56b4:     	ubfx	x4, x7, #4, #4
1000c56b8:     	ubfx	x5, x7, #12, #4
1000c56bc:     	ubfx	x6, x7, #20, #4
1000c56c0:     	lsr	x7, x7, #28
1000c56c4:     	ldr	w26, [x0, x12]
1000c56c8:     	mov	x1, x19
1000c56cc:     	lsl	w19, w26, #4
1000c56d0:     	and	x19, x19, #0xf0
1000c56d4:     	add	x19, x11, x19
1000c56d8:     	ldr	x8, [sp, #416]
1000c56dc:     	ldrb	w25, [x19, x8]
1000c56e0:     	lsr	x20, x26, #4
1000c56e4:     	and	x20, x20, #0xf0
1000c56e8:     	add	x20, x11, x20
1000c56ec:     	ldr	x8, [sp, #440]
1000c56f0:     	ldrb	w27, [x20, x8]
1000c56f4:     	lsr	x21, x26, #12
1000c56f8:     	and	x21, x21, #0xf0
1000c56fc:     	add	x21, x11, x21
1000c5700:     	ldr	x8, [sp, #432]
1000c5704:     	ldrb	w28, [x21, x8]
1000c5708:     	lsr	x22, x26, #20
1000c570c:     	and	x22, x22, #0xf0
1000c5710:     	add	x23, x11, x22
1000c5714:     	ldr	x8, [sp, #424]
1000c5718:     	ldrb	w30, [x23, x8]
1000c571c:     	and	x22, x26, #0xf0
1000c5720:     	add	x22, x11, x22
1000c5724:     	ldp	x3, x8, [sp, #400]
1000c5728:     	ldrb	w8, [x22, x8]
1000c572c:     	lsr	x24, x26, #8
1000c5730:     	and	x24, x24, #0xf0
1000c5734:     	add	x24, x11, x24
1000c5738:     	ldrb	w3, [x24, x3]
1000c573c:     	add	w27, w25, w27
1000c5740:     	lsr	x25, x26, #16
1000c5744:     	and	x25, x25, #0xf0
1000c5748:     	add	x25, x11, x25
1000c574c:     	add	w27, w27, w28
1000c5750:     	ldr	x28, [sp, #392]
1000c5754:     	ldrb	w28, [x25, x28]
1000c5758:     	lsr	x26, x26, #24
1000c575c:     	and	x26, x26, #0xf0
1000c5760:     	add	x26, x11, x26
1000c5764:     	add	w27, w27, w30
1000c5768:     	ldr	x30, [sp, #384]
1000c576c:     	ldrb	w30, [x26, x30]
1000c5770:     	add	w8, w27, w8
1000c5774:     	add	w8, w8, w3
1000c5778:     	add	w8, w8, w28
1000c577c:     	add	w8, w8, w30
1000c5780:     	scvtf	s0, w8
1000c5784:     	ldp	x3, x8, [sp, #368]
1000c5788:     	ldrb	w8, [x19, x8]
1000c578c:     	ldrb	w3, [x20, x3]
1000c5790:     	ldp	x28, x27, [sp, #352]
1000c5794:     	ldrb	w27, [x21, x27]
1000c5798:     	ldrb	w28, [x23, x28]
1000c579c:     	ldr	x30, [sp, #344]
1000c57a0:     	ldrb	w30, [x22, x30]
1000c57a4:     	add	w8, w8, w3
1000c57a8:     	ldr	x3, [sp, #336]
1000c57ac:     	ldrb	w3, [x24, x3]
1000c57b0:     	add	w8, w8, w27
1000c57b4:     	ldr	x27, [sp, #328]
1000c57b8:     	ldrb	w27, [x25, x27]
1000c57bc:     	add	w8, w8, w28
1000c57c0:     	ldr	x28, [sp, #320]
1000c57c4:     	ldrb	w28, [x26, x28]
1000c57c8:     	add	w8, w8, w30
1000c57cc:     	add	w8, w8, w3
1000c57d0:     	add	w8, w8, w27
1000c57d4:     	add	w8, w8, w28
1000c57d8:     	scvtf	s1, w8
1000c57dc:     	ldp	x3, x8, [sp, #304]
1000c57e0:     	ldrb	w8, [x19, x8]
1000c57e4:     	ldrb	w3, [x20, x3]
1000c57e8:     	ldp	x28, x27, [sp, #288]
1000c57ec:     	ldrb	w27, [x21, x27]
1000c57f0:     	ldrb	w28, [x23, x28]
1000c57f4:     	add	w8, w8, w3
1000c57f8:     	ldr	x3, [sp, #280]
1000c57fc:     	ldrb	w3, [x22, x3]
1000c5800:     	add	w8, w8, w27
1000c5804:     	ldr	x27, [sp, #272]
1000c5808:     	ldrb	w27, [x24, x27]
1000c580c:     	add	w8, w8, w28
1000c5810:     	ldr	x28, [sp, #264]
1000c5814:     	ldrb	w28, [x25, x28]
1000c5818:     	add	w8, w8, w3
1000c581c:     	ldr	x3, [sp, #256]
1000c5820:     	ldrb	w3, [x26, x3]
1000c5824:     	add	w8, w8, w27
1000c5828:     	add	w8, w8, w28
1000c582c:     	add	w8, w8, w3
1000c5830:     	scvtf	s2, w8
1000c5834:     	ldp	x3, x8, [sp, #240]
1000c5838:     	ldrb	w8, [x19, x8]
1000c583c:     	ldrb	w3, [x20, x3]
1000c5840:     	ldp	x28, x27, [sp, #224]
1000c5844:     	ldrb	w27, [x21, x27]
1000c5848:     	ldrb	w28, [x23, x28]
1000c584c:     	add	w8, w8, w3
1000c5850:     	ldr	x3, [sp, #216]
1000c5854:     	ldrb	w3, [x22, x3]
1000c5858:     	add	w8, w8, w27
1000c585c:     	ldr	x27, [sp, #208]
1000c5860:     	ldrb	w27, [x24, x27]
1000c5864:     	add	w8, w8, w28
1000c5868:     	ldr	x28, [sp, #200]
1000c586c:     	ldrb	w28, [x25, x28]
1000c5870:     	add	w8, w8, w3
1000c5874:     	ldr	x3, [sp, #192]
1000c5878:     	ldrb	w3, [x26, x3]
1000c587c:     	add	w8, w8, w27
1000c5880:     	add	w8, w8, w28
1000c5884:     	add	w8, w8, w3
1000c5888:     	scvtf	s3, w8
1000c588c:     	ldp	x3, x8, [sp, #176]
1000c5890:     	ldrb	w8, [x19, x8]
1000c5894:     	ldrb	w3, [x20, x3]
1000c5898:     	ldp	x28, x27, [sp, #160]
1000c589c:     	ldrb	w27, [x21, x27]
1000c58a0:     	ldrb	w28, [x23, x28]
1000c58a4:     	add	w8, w8, w3
1000c58a8:     	add	w8, w8, w27
1000c58ac:     	ldr	x3, [sp, #152]
1000c58b0:     	ldrb	w3, [x22, x3]
1000c58b4:     	add	w8, w8, w28
1000c58b8:     	add	w8, w8, w3
1000c58bc:     	ldp	x27, x3, [sp, #136]
1000c58c0:     	ldrb	w3, [x24, x3]
1000c58c4:     	ldrb	w27, [x25, x27]
1000c58c8:     	add	w8, w8, w3
1000c58cc:     	add	w8, w8, w27
1000c58d0:     	ldr	x3, [sp, #128]
1000c58d4:     	ldrb	w3, [x26, x3]
1000c58d8:     	add	w8, w8, w3
1000c58dc:     	scvtf	s4, w8
1000c58e0:     	ldp	x3, x8, [sp, #112]
1000c58e4:     	ldrb	w8, [x19, x8]
1000c58e8:     	ldrb	w3, [x20, x3]
1000c58ec:     	ldp	x28, x27, [sp, #96]
1000c58f0:     	ldrb	w27, [x21, x27]
1000c58f4:     	ldrb	w28, [x23, x28]
1000c58f8:     	add	w8, w8, w3
1000c58fc:     	ldr	x3, [sp, #88]
1000c5900:     	ldrb	w3, [x22, x3]
1000c5904:     	add	w8, w8, w27
1000c5908:     	ldr	x27, [sp, #80]
1000c590c:     	ldrb	w27, [x24, x27]
1000c5910:     	add	w8, w8, w28
1000c5914:     	ldr	x28, [sp, #72]
1000c5918:     	ldrb	w28, [x25, x28]
1000c591c:     	add	w8, w8, w3
1000c5920:     	add	w8, w8, w27
1000c5924:     	add	w8, w8, w28
1000c5928:     	ldr	x3, [sp, #64]
1000c592c:     	ldrb	w3, [x26, x3]
1000c5930:     	add	w8, w8, w3
1000c5934:     	scvtf	s5, w8
1000c5938:     	ldp	x3, x8, [sp, #48]
1000c593c:     	ldrb	w8, [x19, x8]
1000c5940:     	ldrb	w3, [x20, x3]
1000c5944:     	ldr	x27, [sp, #40]
1000c5948:     	ldrb	w27, [x21, x27]
1000c594c:     	add	w8, w8, w3
1000c5950:     	ldr	x3, [sp, #32]
1000c5954:     	ldrb	w3, [x23, x3]
1000c5958:     	add	w8, w8, w27
1000c595c:     	ldrb	w27, [x22, x10]
1000c5960:     	add	w8, w8, w3
1000c5964:     	ldrb	w3, [x24, x13]
1000c5968:     	add	w8, w8, w27
1000c596c:     	ldrb	w27, [x25, x9]
1000c5970:     	add	w8, w8, w3
1000c5974:     	ldrb	w3, [x26, x14]
1000c5978:     	add	w8, w8, w27
1000c597c:     	add	w8, w8, w3
1000c5980:     	scvtf	s6, w8
1000c5984:     	ldrb	w8, [x19, x15]
1000c5988:     	ldrb	w3, [x20, x16]
1000c598c:     	ldrb	w19, [x21, x17]
1000c5990:     	add	w8, w8, w3
1000c5994:     	add	w8, w8, w19
1000c5998:     	ldrb	w3, [x23, x2]
1000c599c:     	ldrb	w19, [x22, x4]
1000c59a0:     	add	w8, w8, w3
1000c59a4:     	add	w8, w8, w19
1000c59a8:     	ldrb	w3, [x24, x5]
1000c59ac:     	ldrb	w19, [x25, x6]
1000c59b0:     	add	w8, w8, w3
1000c59b4:     	add	w8, w8, w19
1000c59b8:     	mov	x19, x1
1000c59bc:     	ldrb	w3, [x26, x7]
1000c59c0:     	add	w8, w8, w3
1000c59c4:     	add	x3, sp, #448
1000c59c8:     	scvtf	s7, w8
1000c59cc:     	add	x8, x1, x12
1000c59d0:     	ldur	s16, [x8, #-96]
1000c59d4:     	fadd	s1, s16, s1
1000c59d8:     	stur	s1, [x8, #-96]
1000c59dc:     	ldur	s1, [x8, #-64]
1000c59e0:     	fadd	s1, s1, s2
1000c59e4:     	stur	s1, [x8, #-64]
1000c59e8:     	ldur	s1, [x8, #-32]
1000c59ec:     	fadd	s1, s1, s3
1000c59f0:     	stur	s1, [x8, #-32]
1000c59f4:     	ldr	s1, [x8]
1000c59f8:     	fadd	s1, s1, s4
1000c59fc:     	str	s1, [x8]
1000c5a00:     	ldr	s1, [x8, #32]
1000c5a04:     	fadd	s1, s1, s5
1000c5a08:     	str	s1, [x8, #32]
1000c5a0c:     	ldr	s1, [x8, #64]
1000c5a10:     	fadd	s1, s1, s6
1000c5a14:     	str	s1, [x8, #64]
1000c5a18:     	ldr	s1, [x8, #96]
1000c5a1c:     	fadd	s1, s1, s7
1000c5a20:     	ldr	s2, [x3, x12]
1000c5a24:     	str	s1, [x8, #96]
1000c5a28:     	fadd	s0, s2, s0
1000c5a2c:     	str	s0, [x3, x12]
1000c5a30:     	add	x12, x12, #4
1000c5a34:     	cmp	x12, #32
1000c5a38:     	b.ne	0x1000c56c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c5a3c:     	add	x0, x0, #32
1000c5a40:     	ldp	x8, x1, [sp, #16]
1000c5a44:     	add	x1, x1, #32
1000c5a48:     	cmp	x1, x8
1000c5a4c:     	b.ne	0x1000c5520 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c5a50:     	ldp	q0, q1, [sp, #640]
1000c5a54:     	ldr	x8, [sp, #8]
1000c5a58:     	stp	q0, q1, [x8, #192]
1000c5a5c:     	ldp	q0, q1, [sp, #672]
1000c5a60:     	stp	q0, q1, [x8, #224]
1000c5a64:     	ldp	q0, q1, [sp, #576]
1000c5a68:     	stp	q0, q1, [x8, #128]
1000c5a6c:     	ldp	q0, q1, [sp, #608]
1000c5a70:     	stp	q0, q1, [x8, #160]
1000c5a74:     	ldp	q0, q1, [sp, #512]
1000c5a78:     	stp	q0, q1, [x8, #64]
1000c5a7c:     	ldp	q0, q1, [sp, #544]
1000c5a80:     	stp	q0, q1, [x8, #96]
1000c5a84:     	ldp	q0, q1, [sp, #448]
1000c5a88:     	stp	q0, q1, [x8]
1000c5a8c:     	ldp	q0, q1, [sp, #480]
1000c5a90:     	stp	q0, q1, [x8, #32]
1000c5a94:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xd0>
1000c5a98:     	ldr	x8, [x8, #392]
1000c5a9c:     	ldr	x8, [x8]
1000c5aa0:     	ldur	x9, [x29, #-96]
1000c5aa4:     	cmp	x8, x9
1000c5aa8:     	b.ne	0x1000c5acc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c5aac:     	add	sp, sp, #720
1000c5ab0:     	ldp	x29, x30, [sp, #80]
1000c5ab4:     	ldp	x20, x19, [sp, #64]
1000c5ab8:     	ldp	x22, x21, [sp, #48]
1000c5abc:     	ldp	x24, x23, [sp, #32]
1000c5ac0:     	ldp	x26, x25, [sp, #16]
1000c5ac4:     	ldp	x28, x27, [sp], #96
1000c5ac8:     	ret
1000c5acc:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c5c60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c5c60:     	stp	x28, x27, [sp, #-96]!
1000c5c64:     	stp	x26, x25, [sp, #16]
1000c5c68:     	stp	x24, x23, [sp, #32]
1000c5c6c:     	stp	x22, x21, [sp, #48]
1000c5c70:     	stp	x20, x19, [sp, #64]
1000c5c74:     	stp	x29, x30, [sp, #80]
1000c5c78:     	add	x29, sp, #80
1000c5c7c:     	sub	sp, sp, #720
1000c5c80:     	str	x3, [sp, #8]
1000c5c84:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c0>
1000c5c88:     	ldr	x8, [x8, #392]
1000c5c8c:     	ldr	x8, [x8]
1000c5c90:     	stur	x8, [x29, #-96]
1000c5c94:     	movi.2d	v0, #0000000000000000
1000c5c98:     	stp	q0, q0, [sp, #672]
1000c5c9c:     	lsl	x8, x2, #2
1000c5ca0:     	stp	q0, q0, [sp, #640]
1000c5ca4:     	stp	q0, q0, [sp, #608]
1000c5ca8:     	stp	q0, q0, [sp, #576]
1000c5cac:     	stp	q0, q0, [sp, #544]
1000c5cb0:     	stp	q0, q0, [sp, #512]
1000c5cb4:     	stp	q0, q0, [sp, #480]
1000c5cb8:     	stp	q0, q0, [sp, #448]
1000c5cbc:     	ands	x8, x8, #0xfffffffffffffff8
1000c5cc0:     	b.eq	0x1000c620c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5ac>
1000c5cc4:     	add	x8, x1, x8
1000c5cc8:     	str	x8, [sp, #16]
1000c5ccc:     	add	x8, sp, #448
1000c5cd0:     	add	x19, x8, #128
1000c5cd4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000c5cd8:     	add	x11, x11, #956
1000c5cdc:     	mov	x12, #0
1000c5ce0:     	ldp	w8, w9, [x1]
1000c5ce4:     	ubfx	x10, x8, #8, #4
1000c5ce8:     	str	x10, [sp, #440]
1000c5cec:     	ubfx	x10, x8, #16, #4
1000c5cf0:     	str	x10, [sp, #432]
1000c5cf4:     	ubfx	x10, x8, #24, #4
1000c5cf8:     	str	x10, [sp, #424]
1000c5cfc:     	ldp	w10, w13, [x1, #8]
1000c5d00:     	and	x15, x8, #0xf
1000c5d04:     	ubfx	x14, x8, #4, #4
1000c5d08:     	stp	x14, x15, [sp, #408]
1000c5d0c:     	ubfx	x15, x8, #12, #4
1000c5d10:     	ubfx	x14, x8, #20, #4
1000c5d14:     	stp	x14, x15, [sp, #392]
1000c5d18:     	lsr	x8, x8, #28
1000c5d1c:     	str	x8, [sp, #384]
1000c5d20:     	and	x8, x9, #0xf
1000c5d24:     	str	x8, [sp, #376]
1000c5d28:     	ubfx	x8, x9, #8, #4
1000c5d2c:     	str	x8, [sp, #368]
1000c5d30:     	ubfx	x8, x9, #16, #4
1000c5d34:     	str	x8, [sp, #360]
1000c5d38:     	ubfx	x8, x9, #24, #4
1000c5d3c:     	str	x8, [sp, #352]
1000c5d40:     	ubfx	x8, x9, #4, #4
1000c5d44:     	str	x8, [sp, #344]
1000c5d48:     	ubfx	x8, x9, #12, #4
1000c5d4c:     	str	x8, [sp, #336]
1000c5d50:     	ubfx	x8, x9, #20, #4
1000c5d54:     	str	x8, [sp, #328]
1000c5d58:     	lsr	x8, x9, #28
1000c5d5c:     	str	x8, [sp, #320]
1000c5d60:     	and	x9, x10, #0xf
1000c5d64:     	ubfx	x8, x10, #8, #4
1000c5d68:     	stp	x8, x9, [sp, #304]
1000c5d6c:     	ubfx	x9, x10, #16, #4
1000c5d70:     	ubfx	x8, x10, #24, #4
1000c5d74:     	stp	x8, x9, [sp, #288]
1000c5d78:     	ubfx	x9, x10, #4, #4
1000c5d7c:     	ubfx	x8, x10, #12, #4
1000c5d80:     	stp	x8, x9, [sp, #272]
1000c5d84:     	ubfx	x9, x10, #20, #4
1000c5d88:     	lsr	x8, x10, #28
1000c5d8c:     	stp	x8, x9, [sp, #256]
1000c5d90:     	and	x9, x13, #0xf
1000c5d94:     	ubfx	x8, x13, #8, #4
1000c5d98:     	stp	x8, x9, [sp, #240]
1000c5d9c:     	ubfx	x9, x13, #16, #4
1000c5da0:     	ubfx	x8, x13, #24, #4
1000c5da4:     	stp	x8, x9, [sp, #224]
1000c5da8:     	ubfx	x9, x13, #4, #4
1000c5dac:     	ubfx	x8, x13, #12, #4
1000c5db0:     	stp	x8, x9, [sp, #208]
1000c5db4:     	ubfx	x9, x13, #20, #4
1000c5db8:     	lsr	x8, x13, #28
1000c5dbc:     	stp	x8, x9, [sp, #192]
1000c5dc0:     	ldp	w8, w9, [x1, #16]
1000c5dc4:     	and	x10, x8, #0xf
1000c5dc8:     	str	x10, [sp, #184]
1000c5dcc:     	ubfx	x10, x8, #8, #4
1000c5dd0:     	str	x10, [sp, #176]
1000c5dd4:     	ubfx	x10, x8, #16, #4
1000c5dd8:     	str	x10, [sp, #168]
1000c5ddc:     	ubfx	x10, x8, #24, #4
1000c5de0:     	str	x10, [sp, #160]
1000c5de4:     	ubfx	x10, x8, #4, #4
1000c5de8:     	str	x10, [sp, #152]
1000c5dec:     	ubfx	x10, x8, #12, #4
1000c5df0:     	str	x10, [sp, #144]
1000c5df4:     	ubfx	x10, x8, #20, #4
1000c5df8:     	lsr	x8, x8, #28
1000c5dfc:     	stp	x8, x10, [sp, #128]
1000c5e00:     	and	x10, x9, #0xf
1000c5e04:     	ubfx	x8, x9, #8, #4
1000c5e08:     	stp	x8, x10, [sp, #112]
1000c5e0c:     	ubfx	x10, x9, #16, #4
1000c5e10:     	ubfx	x8, x9, #24, #4
1000c5e14:     	stp	x8, x10, [sp, #96]
1000c5e18:     	ubfx	x10, x9, #4, #4
1000c5e1c:     	ubfx	x8, x9, #12, #4
1000c5e20:     	stp	x8, x10, [sp, #80]
1000c5e24:     	ubfx	x10, x9, #20, #4
1000c5e28:     	lsr	x8, x9, #28
1000c5e2c:     	stp	x8, x10, [sp, #64]
1000c5e30:     	ldp	w14, w7, [x1, #24]
1000c5e34:     	and	x9, x14, #0xf
1000c5e38:     	ubfx	x8, x14, #8, #4
1000c5e3c:     	stp	x8, x9, [sp, #48]
1000c5e40:     	ubfx	x8, x14, #16, #4
1000c5e44:     	str	x8, [sp, #40]
1000c5e48:     	ubfx	x8, x14, #24, #4
1000c5e4c:     	stp	x1, x8, [sp, #24]
1000c5e50:     	ubfx	x10, x14, #4, #4
1000c5e54:     	ubfx	x13, x14, #12, #4
1000c5e58:     	ubfx	x9, x14, #20, #4
1000c5e5c:     	lsr	x14, x14, #28
1000c5e60:     	and	x15, x7, #0xf
1000c5e64:     	ubfx	x16, x7, #8, #4
1000c5e68:     	ubfx	x17, x7, #16, #4
1000c5e6c:     	ubfx	x2, x7, #24, #4
1000c5e70:     	ubfx	x4, x7, #4, #4
1000c5e74:     	ubfx	x5, x7, #12, #4
1000c5e78:     	ubfx	x6, x7, #20, #4
1000c5e7c:     	lsr	x7, x7, #28
1000c5e80:     	ldr	w26, [x0, x12]
1000c5e84:     	mov	x1, x19
1000c5e88:     	lsl	w19, w26, #4
1000c5e8c:     	and	x19, x19, #0xf0
1000c5e90:     	add	x19, x11, x19
1000c5e94:     	ldr	x8, [sp, #416]
1000c5e98:     	ldrsb	w25, [x19, x8]
1000c5e9c:     	lsr	x20, x26, #4
1000c5ea0:     	and	x20, x20, #0xf0
1000c5ea4:     	add	x20, x11, x20
1000c5ea8:     	ldr	x8, [sp, #440]
1000c5eac:     	ldrsb	w27, [x20, x8]
1000c5eb0:     	lsr	x21, x26, #12
1000c5eb4:     	and	x21, x21, #0xf0
1000c5eb8:     	add	x21, x11, x21
1000c5ebc:     	ldr	x8, [sp, #432]
1000c5ec0:     	ldrsb	w28, [x21, x8]
1000c5ec4:     	lsr	x22, x26, #20
1000c5ec8:     	and	x22, x22, #0xf0
1000c5ecc:     	add	x23, x11, x22
1000c5ed0:     	ldr	x8, [sp, #424]
1000c5ed4:     	ldrsb	w30, [x23, x8]
1000c5ed8:     	and	x22, x26, #0xf0
1000c5edc:     	add	x22, x11, x22
1000c5ee0:     	ldp	x3, x8, [sp, #400]
1000c5ee4:     	ldrsb	w8, [x22, x8]
1000c5ee8:     	lsr	x24, x26, #8
1000c5eec:     	and	x24, x24, #0xf0
1000c5ef0:     	add	x24, x11, x24
1000c5ef4:     	ldrsb	w3, [x24, x3]
1000c5ef8:     	add	w27, w25, w27
1000c5efc:     	lsr	x25, x26, #16
1000c5f00:     	and	x25, x25, #0xf0
1000c5f04:     	add	x25, x11, x25
1000c5f08:     	add	w27, w27, w28
1000c5f0c:     	ldr	x28, [sp, #392]
1000c5f10:     	ldrsb	w28, [x25, x28]
1000c5f14:     	lsr	x26, x26, #24
1000c5f18:     	and	x26, x26, #0xf0
1000c5f1c:     	add	x26, x11, x26
1000c5f20:     	add	w27, w27, w30
1000c5f24:     	ldr	x30, [sp, #384]
1000c5f28:     	ldrsb	w30, [x26, x30]
1000c5f2c:     	add	w8, w27, w8
1000c5f30:     	add	w8, w8, w3
1000c5f34:     	add	w8, w8, w28
1000c5f38:     	add	w8, w8, w30
1000c5f3c:     	scvtf	s0, w8
1000c5f40:     	ldp	x3, x8, [sp, #368]
1000c5f44:     	ldrsb	w8, [x19, x8]
1000c5f48:     	ldrsb	w3, [x20, x3]
1000c5f4c:     	ldp	x28, x27, [sp, #352]
1000c5f50:     	ldrsb	w27, [x21, x27]
1000c5f54:     	ldrsb	w28, [x23, x28]
1000c5f58:     	ldr	x30, [sp, #344]
1000c5f5c:     	ldrsb	w30, [x22, x30]
1000c5f60:     	add	w8, w8, w3
1000c5f64:     	ldr	x3, [sp, #336]
1000c5f68:     	ldrsb	w3, [x24, x3]
1000c5f6c:     	add	w8, w8, w27
1000c5f70:     	ldr	x27, [sp, #328]
1000c5f74:     	ldrsb	w27, [x25, x27]
1000c5f78:     	add	w8, w8, w28
1000c5f7c:     	ldr	x28, [sp, #320]
1000c5f80:     	ldrsb	w28, [x26, x28]
1000c5f84:     	add	w8, w8, w30
1000c5f88:     	add	w8, w8, w3
1000c5f8c:     	add	w8, w8, w27
1000c5f90:     	add	w8, w8, w28
1000c5f94:     	scvtf	s1, w8
1000c5f98:     	ldp	x3, x8, [sp, #304]
1000c5f9c:     	ldrsb	w8, [x19, x8]
1000c5fa0:     	ldrsb	w3, [x20, x3]
1000c5fa4:     	ldp	x28, x27, [sp, #288]
1000c5fa8:     	ldrsb	w27, [x21, x27]
1000c5fac:     	ldrsb	w28, [x23, x28]
1000c5fb0:     	add	w8, w8, w3
1000c5fb4:     	ldr	x3, [sp, #280]
1000c5fb8:     	ldrsb	w3, [x22, x3]
1000c5fbc:     	add	w8, w8, w27
1000c5fc0:     	ldr	x27, [sp, #272]
1000c5fc4:     	ldrsb	w27, [x24, x27]
1000c5fc8:     	add	w8, w8, w28
1000c5fcc:     	ldr	x28, [sp, #264]
1000c5fd0:     	ldrsb	w28, [x25, x28]
1000c5fd4:     	add	w8, w8, w3
1000c5fd8:     	ldr	x3, [sp, #256]
1000c5fdc:     	ldrsb	w3, [x26, x3]
1000c5fe0:     	add	w8, w8, w27
1000c5fe4:     	add	w8, w8, w28
1000c5fe8:     	add	w8, w8, w3
1000c5fec:     	scvtf	s2, w8
1000c5ff0:     	ldp	x3, x8, [sp, #240]
1000c5ff4:     	ldrsb	w8, [x19, x8]
1000c5ff8:     	ldrsb	w3, [x20, x3]
1000c5ffc:     	ldp	x28, x27, [sp, #224]
1000c6000:     	ldrsb	w27, [x21, x27]
1000c6004:     	ldrsb	w28, [x23, x28]
1000c6008:     	add	w8, w8, w3
1000c600c:     	ldr	x3, [sp, #216]
1000c6010:     	ldrsb	w3, [x22, x3]
1000c6014:     	add	w8, w8, w27
1000c6018:     	ldr	x27, [sp, #208]
1000c601c:     	ldrsb	w27, [x24, x27]
1000c6020:     	add	w8, w8, w28
1000c6024:     	ldr	x28, [sp, #200]
1000c6028:     	ldrsb	w28, [x25, x28]
1000c602c:     	add	w8, w8, w3
1000c6030:     	ldr	x3, [sp, #192]
1000c6034:     	ldrsb	w3, [x26, x3]
1000c6038:     	add	w8, w8, w27
1000c603c:     	add	w8, w8, w28
1000c6040:     	add	w8, w8, w3
1000c6044:     	scvtf	s3, w8
1000c6048:     	ldp	x3, x8, [sp, #176]
1000c604c:     	ldrsb	w8, [x19, x8]
1000c6050:     	ldrsb	w3, [x20, x3]
1000c6054:     	ldp	x28, x27, [sp, #160]
1000c6058:     	ldrsb	w27, [x21, x27]
1000c605c:     	ldrsb	w28, [x23, x28]
1000c6060:     	add	w8, w8, w3
1000c6064:     	add	w8, w8, w27
1000c6068:     	ldr	x3, [sp, #152]
1000c606c:     	ldrsb	w3, [x22, x3]
1000c6070:     	add	w8, w8, w28
1000c6074:     	add	w8, w8, w3
1000c6078:     	ldp	x27, x3, [sp, #136]
1000c607c:     	ldrsb	w3, [x24, x3]
1000c6080:     	ldrsb	w27, [x25, x27]
1000c6084:     	add	w8, w8, w3
1000c6088:     	add	w8, w8, w27
1000c608c:     	ldr	x3, [sp, #128]
1000c6090:     	ldrsb	w3, [x26, x3]
1000c6094:     	add	w8, w8, w3
1000c6098:     	scvtf	s4, w8
1000c609c:     	ldp	x3, x8, [sp, #112]
1000c60a0:     	ldrsb	w8, [x19, x8]
1000c60a4:     	ldrsb	w3, [x20, x3]
1000c60a8:     	ldp	x28, x27, [sp, #96]
1000c60ac:     	ldrsb	w27, [x21, x27]
1000c60b0:     	ldrsb	w28, [x23, x28]
1000c60b4:     	add	w8, w8, w3
1000c60b8:     	ldr	x3, [sp, #88]
1000c60bc:     	ldrsb	w3, [x22, x3]
1000c60c0:     	add	w8, w8, w27
1000c60c4:     	ldr	x27, [sp, #80]
1000c60c8:     	ldrsb	w27, [x24, x27]
1000c60cc:     	add	w8, w8, w28
1000c60d0:     	ldr	x28, [sp, #72]
1000c60d4:     	ldrsb	w28, [x25, x28]
1000c60d8:     	add	w8, w8, w3
1000c60dc:     	add	w8, w8, w27
1000c60e0:     	add	w8, w8, w28
1000c60e4:     	ldr	x3, [sp, #64]
1000c60e8:     	ldrsb	w3, [x26, x3]
1000c60ec:     	add	w8, w8, w3
1000c60f0:     	scvtf	s5, w8
1000c60f4:     	ldp	x3, x8, [sp, #48]
1000c60f8:     	ldrsb	w8, [x19, x8]
1000c60fc:     	ldrsb	w3, [x20, x3]
1000c6100:     	ldr	x27, [sp, #40]
1000c6104:     	ldrsb	w27, [x21, x27]
1000c6108:     	add	w8, w8, w3
1000c610c:     	ldr	x3, [sp, #32]
1000c6110:     	ldrsb	w3, [x23, x3]
1000c6114:     	add	w8, w8, w27
1000c6118:     	ldrsb	w27, [x22, x10]
1000c611c:     	add	w8, w8, w3
1000c6120:     	ldrsb	w3, [x24, x13]
1000c6124:     	add	w8, w8, w27
1000c6128:     	ldrsb	w27, [x25, x9]
1000c612c:     	add	w8, w8, w3
1000c6130:     	ldrsb	w3, [x26, x14]
1000c6134:     	add	w8, w8, w27
1000c6138:     	add	w8, w8, w3
1000c613c:     	scvtf	s6, w8
1000c6140:     	ldrsb	w8, [x19, x15]
1000c6144:     	ldrsb	w3, [x20, x16]
1000c6148:     	ldrsb	w19, [x21, x17]
1000c614c:     	add	w8, w8, w3
1000c6150:     	add	w8, w8, w19
1000c6154:     	ldrsb	w3, [x23, x2]
1000c6158:     	ldrsb	w19, [x22, x4]
1000c615c:     	add	w8, w8, w3
1000c6160:     	add	w8, w8, w19
1000c6164:     	ldrsb	w3, [x24, x5]
1000c6168:     	ldrsb	w19, [x25, x6]
1000c616c:     	add	w8, w8, w3
1000c6170:     	add	w8, w8, w19
1000c6174:     	mov	x19, x1
1000c6178:     	ldrsb	w3, [x26, x7]
1000c617c:     	add	w8, w8, w3
1000c6180:     	add	x3, sp, #448
1000c6184:     	scvtf	s7, w8
1000c6188:     	add	x8, x1, x12
1000c618c:     	ldur	s16, [x8, #-96]
1000c6190:     	fadd	s1, s16, s1
1000c6194:     	stur	s1, [x8, #-96]
1000c6198:     	ldur	s1, [x8, #-64]
1000c619c:     	fadd	s1, s1, s2
1000c61a0:     	stur	s1, [x8, #-64]
1000c61a4:     	ldur	s1, [x8, #-32]
1000c61a8:     	fadd	s1, s1, s3
1000c61ac:     	stur	s1, [x8, #-32]
1000c61b0:     	ldr	s1, [x8]
1000c61b4:     	fadd	s1, s1, s4
1000c61b8:     	str	s1, [x8]
1000c61bc:     	ldr	s1, [x8, #32]
1000c61c0:     	fadd	s1, s1, s5
1000c61c4:     	str	s1, [x8, #32]
1000c61c8:     	ldr	s1, [x8, #64]
1000c61cc:     	fadd	s1, s1, s6
1000c61d0:     	str	s1, [x8, #64]
1000c61d4:     	ldr	s1, [x8, #96]
1000c61d8:     	fadd	s1, s1, s7
1000c61dc:     	ldr	s2, [x3, x12]
1000c61e0:     	str	s1, [x8, #96]
1000c61e4:     	fadd	s0, s2, s0
1000c61e8:     	str	s0, [x3, x12]
1000c61ec:     	add	x12, x12, #4
1000c61f0:     	cmp	x12, #32
1000c61f4:     	b.ne	0x1000c5e80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x220>
1000c61f8:     	add	x0, x0, #32
1000c61fc:     	ldp	x8, x1, [sp, #16]
1000c6200:     	add	x1, x1, #32
1000c6204:     	cmp	x1, x8
1000c6208:     	b.ne	0x1000c5cdc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000c620c:     	ldp	q0, q1, [sp, #640]
1000c6210:     	ldr	x8, [sp, #8]
1000c6214:     	stp	q0, q1, [x8, #192]
1000c6218:     	ldp	q0, q1, [sp, #672]
1000c621c:     	stp	q0, q1, [x8, #224]
1000c6220:     	ldp	q0, q1, [sp, #576]
1000c6224:     	stp	q0, q1, [x8, #128]
1000c6228:     	ldp	q0, q1, [sp, #608]
1000c622c:     	stp	q0, q1, [x8, #160]
1000c6230:     	ldp	q0, q1, [sp, #512]
1000c6234:     	stp	q0, q1, [x8, #64]
1000c6238:     	ldp	q0, q1, [sp, #544]
1000c623c:     	stp	q0, q1, [x8, #96]
1000c6240:     	ldp	q0, q1, [sp, #448]
1000c6244:     	stp	q0, q1, [x8]
1000c6248:     	ldp	q0, q1, [sp, #480]
1000c624c:     	stp	q0, q1, [x8, #32]
1000c6250:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 1ul, false>(char const*)+0x25c>
1000c6254:     	ldr	x8, [x8, #392]
1000c6258:     	ldr	x8, [x8]
1000c625c:     	ldur	x9, [x29, #-96]
1000c6260:     	cmp	x8, x9
1000c6264:     	b.ne	0x1000c6288 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x628>
1000c6268:     	add	sp, sp, #720
1000c626c:     	ldp	x29, x30, [sp, #80]
1000c6270:     	ldp	x20, x19, [sp, #64]
1000c6274:     	ldp	x22, x21, [sp, #48]
1000c6278:     	ldp	x24, x23, [sp, #32]
1000c627c:     	ldp	x26, x25, [sp, #16]
1000c6280:     	ldp	x28, x27, [sp], #96
1000c6284:     	ret
1000c6288:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c71c4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c71c4:     	stp	x22, x21, [sp, #-32]!
1000c71c8:     	stp	x20, x19, [sp, #16]
1000c71cc:     	movi.2d	v0, #0000000000000000
1000c71d0:     	stp	q0, q0, [x3, #32]
1000c71d4:     	stp	q0, q0, [x3]
1000c71d8:     	cmp	x2, #8
1000c71dc:     	b.hs	0x1000c71e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c71e0:     	mov	x8, #0
1000c71e4:     	b	0x1000c72f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c71e8:     	mov	x8, #0
1000c71ec:     	mov	w12, #8
1000c71f0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b8>
1000c71f4:     	add	x9, x9, #1212
1000c71f8:     	mov	x10, x0
1000c71fc:     	mov	x11, #0
1000c7200:     	lsr	x8, x8, #1
1000c7204:     	mul	x8, x8, x4
1000c7208:     	ldr	w6, [x1, x8]
1000c720c:     	mov	x8, x12
1000c7210:     	lsl	w12, w6, #4
1000c7214:     	and	x12, x12, #0xf0
1000c7218:     	add	x12, x9, x12
1000c721c:     	and	x13, x6, #0xf0
1000c7220:     	add	x13, x9, x13
1000c7224:     	lsr	x14, x6, #4
1000c7228:     	and	x14, x14, #0xf0
1000c722c:     	add	x14, x9, x14
1000c7230:     	lsr	x15, x6, #8
1000c7234:     	and	x15, x15, #0xf0
1000c7238:     	add	x15, x9, x15
1000c723c:     	lsr	x16, x6, #12
1000c7240:     	and	x16, x16, #0xf0
1000c7244:     	add	x16, x9, x16
1000c7248:     	lsr	x17, x6, #16
1000c724c:     	and	x17, x17, #0xf0
1000c7250:     	add	x17, x9, x17
1000c7254:     	lsr	x5, x6, #20
1000c7258:     	and	x5, x5, #0xf0
1000c725c:     	add	x5, x9, x5
1000c7260:     	lsr	x6, x6, #24
1000c7264:     	and	x6, x6, #0xf0
1000c7268:     	add	x6, x9, x6
1000c726c:     	ldr	w7, [x10, x11]
1000c7270:     	and	x19, x7, #0xf
1000c7274:     	ldrb	w19, [x12, x19]
1000c7278:     	ubfx	x20, x7, #4, #4
1000c727c:     	ldrb	w20, [x13, x20]
1000c7280:     	ubfx	x21, x7, #8, #4
1000c7284:     	ldrb	w21, [x14, x21]
1000c7288:     	add	w19, w19, w20
1000c728c:     	add	w19, w19, w21
1000c7290:     	ubfx	x20, x7, #12, #4
1000c7294:     	ldrb	w20, [x15, x20]
1000c7298:     	ubfx	x21, x7, #16, #4
1000c729c:     	ldrb	w21, [x16, x21]
1000c72a0:     	add	w19, w19, w20
1000c72a4:     	add	w19, w19, w21
1000c72a8:     	ubfx	x20, x7, #20, #4
1000c72ac:     	ldrb	w20, [x17, x20]
1000c72b0:     	ubfx	x21, x7, #24, #4
1000c72b4:     	ldrb	w21, [x5, x21]
1000c72b8:     	lsr	x7, x7, #28
1000c72bc:     	ldrb	w7, [x6, x7]
1000c72c0:     	add	w19, w19, w20
1000c72c4:     	add	w19, w19, w21
1000c72c8:     	add	w7, w19, w7
1000c72cc:     	scvtf	s0, w7
1000c72d0:     	ldr	s1, [x3, x11]
1000c72d4:     	fadd	s0, s1, s0
1000c72d8:     	str	s0, [x3, x11]
1000c72dc:     	add	x11, x11, #4
1000c72e0:     	cmp	x11, #64
1000c72e4:     	b.ne	0x1000c726c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c72e8:     	add	x12, x8, #8
1000c72ec:     	add	x10, x10, #64
1000c72f0:     	cmp	x12, x2
1000c72f4:     	b.ls	0x1000c71fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c72f8:     	cmp	x8, x2
1000c72fc:     	b.hs	0x1000c75f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x430>
1000c7300:     	lsl	x9, x4, #2
1000c7304:     	lsl	w10, w8, #2
1000c7308:     	mov	w11, #-16
1000c730c:     	lsr	x13, x8, #3
1000c7310:     	mul	x12, x9, x13
1000c7314:     	ubfx	x14, x8, #1, #2
1000c7318:     	orr	x15, x12, x14
1000c731c:     	and	w12, w10, #0x4
1000c7320:     	ldrb	w15, [x1, x15]
1000c7324:     	lsr	w15, w15, w12
1000c7328:     	and	w16, w15, #0xf
1000c732c:     	cmp	w16, #8
1000c7330:     	csel	w16, wzr, w11, lo
1000c7334:     	bfi	x14, x13, #6, #58
1000c7338:     	bfxil	w16, w15, #0, #4
1000c733c:     	add	x13, x0, x14
1000c7340:     	ldrb	w14, [x13]
1000c7344:     	lsr	w14, w14, w12
1000c7348:     	and	w15, w14, #0xf
1000c734c:     	scvtf	s0, w16
1000c7350:     	cmp	w15, #8
1000c7354:     	csel	w15, wzr, w11, lo
1000c7358:     	bfxil	w15, w14, #0, #4
1000c735c:     	scvtf	s1, w15
1000c7360:     	fsub	s1, s1, s0
1000c7364:     	ldp	s2, s3, [x3]
1000c7368:     	fmadd	s1, s1, s1, s2
1000c736c:     	str	s1, [x3]
1000c7370:     	ldrb	w14, [x13, #4]
1000c7374:     	lsr	w14, w14, w12
1000c7378:     	and	w15, w14, #0xf
1000c737c:     	cmp	w15, #8
1000c7380:     	csel	w15, wzr, w11, lo
1000c7384:     	bfxil	w15, w14, #0, #4
1000c7388:     	scvtf	s1, w15
1000c738c:     	fsub	s1, s1, s0
1000c7390:     	fmadd	s1, s1, s1, s3
1000c7394:     	str	s1, [x3, #4]
1000c7398:     	ldrb	w14, [x13, #8]
1000c739c:     	lsr	w14, w14, w12
1000c73a0:     	and	w15, w14, #0xf
1000c73a4:     	cmp	w15, #8
1000c73a8:     	csel	w15, wzr, w11, lo
1000c73ac:     	bfxil	w15, w14, #0, #4
1000c73b0:     	scvtf	s1, w15
1000c73b4:     	fsub	s1, s1, s0
1000c73b8:     	ldp	s2, s3, [x3, #8]
1000c73bc:     	fmadd	s1, s1, s1, s2
1000c73c0:     	str	s1, [x3, #8]
1000c73c4:     	ldrb	w14, [x13, #12]
1000c73c8:     	lsr	w14, w14, w12
1000c73cc:     	and	w15, w14, #0xf
1000c73d0:     	cmp	w15, #8
1000c73d4:     	csel	w15, wzr, w11, lo
1000c73d8:     	bfxil	w15, w14, #0, #4
1000c73dc:     	scvtf	s1, w15
1000c73e0:     	fsub	s1, s1, s0
1000c73e4:     	fmadd	s1, s1, s1, s3
1000c73e8:     	str	s1, [x3, #12]
1000c73ec:     	ldrb	w14, [x13, #16]
1000c73f0:     	lsr	w14, w14, w12
1000c73f4:     	and	w15, w14, #0xf
1000c73f8:     	cmp	w15, #8
1000c73fc:     	csel	w15, wzr, w11, lo
1000c7400:     	bfxil	w15, w14, #0, #4
1000c7404:     	scvtf	s1, w15
1000c7408:     	fsub	s1, s1, s0
1000c740c:     	ldp	s2, s3, [x3, #16]
1000c7410:     	fmadd	s1, s1, s1, s2
1000c7414:     	str	s1, [x3, #16]
1000c7418:     	ldrb	w14, [x13, #20]
1000c741c:     	lsr	w14, w14, w12
1000c7420:     	and	w15, w14, #0xf
1000c7424:     	cmp	w15, #8
1000c7428:     	csel	w15, wzr, w11, lo
1000c742c:     	bfxil	w15, w14, #0, #4
1000c7430:     	scvtf	s1, w15
1000c7434:     	fsub	s1, s1, s0
1000c7438:     	fmadd	s1, s1, s1, s3
1000c743c:     	str	s1, [x3, #20]
1000c7440:     	ldrb	w14, [x13, #24]
1000c7444:     	lsr	w14, w14, w12
1000c7448:     	and	w15, w14, #0xf
1000c744c:     	cmp	w15, #8
1000c7450:     	csel	w15, wzr, w11, lo
1000c7454:     	bfxil	w15, w14, #0, #4
1000c7458:     	scvtf	s1, w15
1000c745c:     	fsub	s1, s1, s0
1000c7460:     	ldp	s2, s3, [x3, #24]
1000c7464:     	fmadd	s1, s1, s1, s2
1000c7468:     	str	s1, [x3, #24]
1000c746c:     	ldrb	w14, [x13, #28]
1000c7470:     	lsr	w14, w14, w12
1000c7474:     	and	w15, w14, #0xf
1000c7478:     	cmp	w15, #8
1000c747c:     	csel	w15, wzr, w11, lo
1000c7480:     	bfxil	w15, w14, #0, #4
1000c7484:     	scvtf	s1, w15
1000c7488:     	fsub	s1, s1, s0
1000c748c:     	fmadd	s1, s1, s1, s3
1000c7490:     	str	s1, [x3, #28]
1000c7494:     	ldrb	w14, [x13, #32]
1000c7498:     	lsr	w14, w14, w12
1000c749c:     	and	w15, w14, #0xf
1000c74a0:     	cmp	w15, #8
1000c74a4:     	csel	w15, wzr, w11, lo
1000c74a8:     	bfxil	w15, w14, #0, #4
1000c74ac:     	scvtf	s1, w15
1000c74b0:     	fsub	s1, s1, s0
1000c74b4:     	ldp	s2, s3, [x3, #32]
1000c74b8:     	fmadd	s1, s1, s1, s2
1000c74bc:     	str	s1, [x3, #32]
1000c74c0:     	ldrb	w14, [x13, #36]
1000c74c4:     	lsr	w14, w14, w12
1000c74c8:     	and	w15, w14, #0xf
1000c74cc:     	cmp	w15, #8
1000c74d0:     	csel	w15, wzr, w11, lo
1000c74d4:     	bfxil	w15, w14, #0, #4
1000c74d8:     	scvtf	s1, w15
1000c74dc:     	fsub	s1, s1, s0
1000c74e0:     	fmadd	s1, s1, s1, s3
1000c74e4:     	str	s1, [x3, #36]
1000c74e8:     	ldrb	w14, [x13, #40]
1000c74ec:     	lsr	w14, w14, w12
1000c74f0:     	and	w15, w14, #0xf
1000c74f4:     	cmp	w15, #8
1000c74f8:     	csel	w15, wzr, w11, lo
1000c74fc:     	bfxil	w15, w14, #0, #4
1000c7500:     	scvtf	s1, w15
1000c7504:     	fsub	s1, s1, s0
1000c7508:     	ldp	s2, s3, [x3, #40]
1000c750c:     	fmadd	s1, s1, s1, s2
1000c7510:     	str	s1, [x3, #40]
1000c7514:     	ldrb	w14, [x13, #44]
1000c7518:     	lsr	w14, w14, w12
1000c751c:     	and	w15, w14, #0xf
1000c7520:     	cmp	w15, #8
1000c7524:     	csel	w15, wzr, w11, lo
1000c7528:     	bfxil	w15, w14, #0, #4
1000c752c:     	scvtf	s1, w15
1000c7530:     	fsub	s1, s1, s0
1000c7534:     	fmadd	s1, s1, s1, s3
1000c7538:     	str	s1, [x3, #44]
1000c753c:     	ldrb	w14, [x13, #48]
1000c7540:     	lsr	w14, w14, w12
1000c7544:     	and	w15, w14, #0xf
1000c7548:     	cmp	w15, #8
1000c754c:     	csel	w15, wzr, w11, lo
1000c7550:     	bfxil	w15, w14, #0, #4
1000c7554:     	scvtf	s1, w15
1000c7558:     	fsub	s1, s1, s0
1000c755c:     	ldp	s2, s3, [x3, #48]
1000c7560:     	fmadd	s1, s1, s1, s2
1000c7564:     	str	s1, [x3, #48]
1000c7568:     	ldrb	w14, [x13, #52]
1000c756c:     	lsr	w14, w14, w12
1000c7570:     	and	w15, w14, #0xf
1000c7574:     	cmp	w15, #8
1000c7578:     	csel	w15, wzr, w11, lo
1000c757c:     	bfxil	w15, w14, #0, #4
1000c7580:     	scvtf	s1, w15
1000c7584:     	fsub	s1, s1, s0
1000c7588:     	fmadd	s1, s1, s1, s3
1000c758c:     	str	s1, [x3, #52]
1000c7590:     	ldrb	w14, [x13, #56]
1000c7594:     	lsr	w14, w14, w12
1000c7598:     	and	w15, w14, #0xf
1000c759c:     	cmp	w15, #8
1000c75a0:     	csel	w15, wzr, w11, lo
1000c75a4:     	bfxil	w15, w14, #0, #4
1000c75a8:     	scvtf	s1, w15
1000c75ac:     	fsub	s1, s1, s0
1000c75b0:     	ldp	s2, s3, [x3, #56]
1000c75b4:     	fmadd	s1, s1, s1, s2
1000c75b8:     	str	s1, [x3, #56]
1000c75bc:     	ldrb	w13, [x13, #60]
1000c75c0:     	lsr	w12, w13, w12
1000c75c4:     	and	w13, w12, #0xf
1000c75c8:     	cmp	w13, #8
1000c75cc:     	csel	w13, wzr, w11, lo
1000c75d0:     	bfxil	w13, w12, #0, #4
1000c75d4:     	scvtf	s1, w13
1000c75d8:     	fsub	s0, s1, s0
1000c75dc:     	fmadd	s0, s0, s0, s3
1000c75e0:     	str	s0, [x3, #60]
1000c75e4:     	add	x8, x8, #1
1000c75e8:     	add	w10, w10, #4
1000c75ec:     	cmp	x2, x8
1000c75f0:     	b.ne	0x1000c730c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c75f4:     	ldp	x20, x19, [sp, #16]
1000c75f8:     	ldp	x22, x21, [sp], #32
1000c75fc:     	ret

00000001000c7624 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000c7624:     	stp	x22, x21, [sp, #-32]!
1000c7628:     	stp	x20, x19, [sp, #16]
1000c762c:     	movi.2d	v0, #0000000000000000
1000c7630:     	stp	q0, q0, [x3, #32]
1000c7634:     	stp	q0, q0, [x3]
1000c7638:     	cmp	x2, #8
1000c763c:     	b.hs	0x1000c7648 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x24>
1000c7640:     	mov	x8, #0
1000c7644:     	b	0x1000c7758 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x134>
1000c7648:     	mov	x8, #0
1000c764c:     	mov	w12, #8
1000c7650:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2b8>
1000c7654:     	add	x9, x9, #1468
1000c7658:     	mov	x10, x0
1000c765c:     	mov	x11, #0
1000c7660:     	lsr	x8, x8, #1
1000c7664:     	mul	x8, x8, x4
1000c7668:     	ldr	w6, [x1, x8]
1000c766c:     	mov	x8, x12
1000c7670:     	lsl	w12, w6, #4
1000c7674:     	and	x12, x12, #0xf0
1000c7678:     	add	x12, x9, x12
1000c767c:     	and	x13, x6, #0xf0
1000c7680:     	add	x13, x9, x13
1000c7684:     	lsr	x14, x6, #4
1000c7688:     	and	x14, x14, #0xf0
1000c768c:     	add	x14, x9, x14
1000c7690:     	lsr	x15, x6, #8
1000c7694:     	and	x15, x15, #0xf0
1000c7698:     	add	x15, x9, x15
1000c769c:     	lsr	x16, x6, #12
1000c76a0:     	and	x16, x16, #0xf0
1000c76a4:     	add	x16, x9, x16
1000c76a8:     	lsr	x17, x6, #16
1000c76ac:     	and	x17, x17, #0xf0
1000c76b0:     	add	x17, x9, x17
1000c76b4:     	lsr	x5, x6, #20
1000c76b8:     	and	x5, x5, #0xf0
1000c76bc:     	add	x5, x9, x5
1000c76c0:     	lsr	x6, x6, #24
1000c76c4:     	and	x6, x6, #0xf0
1000c76c8:     	add	x6, x9, x6
1000c76cc:     	ldr	w7, [x10, x11]
1000c76d0:     	and	x19, x7, #0xf
1000c76d4:     	ldrsb	w19, [x12, x19]
1000c76d8:     	ubfx	x20, x7, #4, #4
1000c76dc:     	ldrsb	w20, [x13, x20]
1000c76e0:     	ubfx	x21, x7, #8, #4
1000c76e4:     	ldrsb	w21, [x14, x21]
1000c76e8:     	add	w19, w19, w20
1000c76ec:     	add	w19, w19, w21
1000c76f0:     	ubfx	x20, x7, #12, #4
1000c76f4:     	ldrsb	w20, [x15, x20]
1000c76f8:     	ubfx	x21, x7, #16, #4
1000c76fc:     	ldrsb	w21, [x16, x21]
1000c7700:     	add	w19, w19, w20
1000c7704:     	add	w19, w19, w21
1000c7708:     	ubfx	x20, x7, #20, #4
1000c770c:     	ldrsb	w20, [x17, x20]
1000c7710:     	ubfx	x21, x7, #24, #4
1000c7714:     	ldrsb	w21, [x5, x21]
1000c7718:     	lsr	x7, x7, #28
1000c771c:     	ldrsb	w7, [x6, x7]
1000c7720:     	add	w19, w19, w20
1000c7724:     	add	w19, w19, w21
1000c7728:     	add	w7, w19, w7
1000c772c:     	scvtf	s0, w7
1000c7730:     	ldr	s1, [x3, x11]
1000c7734:     	fadd	s0, s1, s0
1000c7738:     	str	s0, [x3, x11]
1000c773c:     	add	x11, x11, #4
1000c7740:     	cmp	x11, #64
1000c7744:     	b.ne	0x1000c76cc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xa8>
1000c7748:     	add	x12, x8, #8
1000c774c:     	add	x10, x10, #64
1000c7750:     	cmp	x12, x2
1000c7754:     	b.ls	0x1000c765c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x38>
1000c7758:     	cmp	x8, x2
1000c775c:     	b.hs	0x1000c7a14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x3f0>
1000c7760:     	lsl	x9, x4, #2
1000c7764:     	lsl	w10, w8, #2
1000c7768:     	mov	w11, #-16
1000c776c:     	lsr	x13, x8, #3
1000c7770:     	mul	x12, x9, x13
1000c7774:     	ubfx	x14, x8, #1, #2
1000c7778:     	orr	x12, x12, x14
1000c777c:     	ldrb	w15, [x1, x12]
1000c7780:     	and	w12, w10, #0x4
1000c7784:     	lsr	w15, w15, w12
1000c7788:     	and	w16, w15, #0xf
1000c778c:     	cmp	w16, #8
1000c7790:     	csel	w16, wzr, w11, lo
1000c7794:     	bfi	x14, x13, #6, #58
1000c7798:     	add	x13, x0, x14
1000c779c:     	ldrb	w14, [x13]
1000c77a0:     	lsr	w14, w14, w12
1000c77a4:     	bfxil	w16, w15, #0, #4
1000c77a8:     	and	w15, w14, #0xf
1000c77ac:     	cmp	w15, #8
1000c77b0:     	csel	w15, wzr, w11, lo
1000c77b4:     	bfxil	w15, w14, #0, #4
1000c77b8:     	scvtf	s0, w16
1000c77bc:     	scvtf	s1, w15
1000c77c0:     	ldp	s2, s3, [x3]
1000c77c4:     	fmsub	s1, s1, s0, s2
1000c77c8:     	str	s1, [x3]
1000c77cc:     	ldrb	w14, [x13, #4]
1000c77d0:     	lsr	w14, w14, w12
1000c77d4:     	and	w15, w14, #0xf
1000c77d8:     	cmp	w15, #8
1000c77dc:     	csel	w15, wzr, w11, lo
1000c77e0:     	bfxil	w15, w14, #0, #4
1000c77e4:     	scvtf	s1, w15
1000c77e8:     	fmsub	s1, s1, s0, s3
1000c77ec:     	str	s1, [x3, #4]
1000c77f0:     	ldrb	w14, [x13, #8]
1000c77f4:     	lsr	w14, w14, w12
1000c77f8:     	and	w15, w14, #0xf
1000c77fc:     	cmp	w15, #8
1000c7800:     	csel	w15, wzr, w11, lo
1000c7804:     	bfxil	w15, w14, #0, #4
1000c7808:     	scvtf	s1, w15
1000c780c:     	ldp	s2, s3, [x3, #8]
1000c7810:     	fmsub	s1, s1, s0, s2
1000c7814:     	str	s1, [x3, #8]
1000c7818:     	ldrb	w14, [x13, #12]
1000c781c:     	lsr	w14, w14, w12
1000c7820:     	and	w15, w14, #0xf
1000c7824:     	cmp	w15, #8
1000c7828:     	csel	w15, wzr, w11, lo
1000c782c:     	bfxil	w15, w14, #0, #4
1000c7830:     	scvtf	s1, w15
1000c7834:     	fmsub	s1, s1, s0, s3
1000c7838:     	str	s1, [x3, #12]
1000c783c:     	ldrb	w14, [x13, #16]
1000c7840:     	lsr	w14, w14, w12
1000c7844:     	and	w15, w14, #0xf
1000c7848:     	cmp	w15, #8
1000c784c:     	csel	w15, wzr, w11, lo
1000c7850:     	bfxil	w15, w14, #0, #4
1000c7854:     	scvtf	s1, w15
1000c7858:     	ldp	s2, s3, [x3, #16]
1000c785c:     	fmsub	s1, s1, s0, s2
1000c7860:     	str	s1, [x3, #16]
1000c7864:     	ldrb	w14, [x13, #20]
1000c7868:     	lsr	w14, w14, w12
1000c786c:     	and	w15, w14, #0xf
1000c7870:     	cmp	w15, #8
1000c7874:     	csel	w15, wzr, w11, lo
1000c7878:     	bfxil	w15, w14, #0, #4
1000c787c:     	scvtf	s1, w15
1000c7880:     	fmsub	s1, s1, s0, s3
1000c7884:     	str	s1, [x3, #20]
1000c7888:     	ldrb	w14, [x13, #24]
1000c788c:     	lsr	w14, w14, w12
1000c7890:     	and	w15, w14, #0xf
1000c7894:     	cmp	w15, #8
1000c7898:     	csel	w15, wzr, w11, lo
1000c789c:     	bfxil	w15, w14, #0, #4
1000c78a0:     	scvtf	s1, w15
1000c78a4:     	ldp	s2, s3, [x3, #24]
1000c78a8:     	fmsub	s1, s1, s0, s2
1000c78ac:     	str	s1, [x3, #24]
1000c78b0:     	ldrb	w14, [x13, #28]
1000c78b4:     	lsr	w14, w14, w12
1000c78b8:     	and	w15, w14, #0xf
1000c78bc:     	cmp	w15, #8
1000c78c0:     	csel	w15, wzr, w11, lo
1000c78c4:     	bfxil	w15, w14, #0, #4
1000c78c8:     	scvtf	s1, w15
1000c78cc:     	fmsub	s1, s1, s0, s3
1000c78d0:     	str	s1, [x3, #28]
1000c78d4:     	ldrb	w14, [x13, #32]
1000c78d8:     	lsr	w14, w14, w12
1000c78dc:     	and	w15, w14, #0xf
1000c78e0:     	cmp	w15, #8
1000c78e4:     	csel	w15, wzr, w11, lo
1000c78e8:     	bfxil	w15, w14, #0, #4
1000c78ec:     	scvtf	s1, w15
1000c78f0:     	ldp	s2, s3, [x3, #32]
1000c78f4:     	fmsub	s1, s1, s0, s2
1000c78f8:     	str	s1, [x3, #32]
1000c78fc:     	ldrb	w14, [x13, #36]
1000c7900:     	lsr	w14, w14, w12
1000c7904:     	and	w15, w14, #0xf
1000c7908:     	cmp	w15, #8
1000c790c:     	csel	w15, wzr, w11, lo
1000c7910:     	bfxil	w15, w14, #0, #4
1000c7914:     	scvtf	s1, w15
1000c7918:     	fmsub	s1, s1, s0, s3
1000c791c:     	str	s1, [x3, #36]
1000c7920:     	ldrb	w14, [x13, #40]
1000c7924:     	lsr	w14, w14, w12
1000c7928:     	and	w15, w14, #0xf
1000c792c:     	cmp	w15, #8
1000c7930:     	csel	w15, wzr, w11, lo
1000c7934:     	bfxil	w15, w14, #0, #4
1000c7938:     	scvtf	s1, w15
1000c793c:     	ldp	s2, s3, [x3, #40]
1000c7940:     	fmsub	s1, s1, s0, s2
1000c7944:     	str	s1, [x3, #40]
1000c7948:     	ldrb	w14, [x13, #44]
1000c794c:     	lsr	w14, w14, w12
1000c7950:     	and	w15, w14, #0xf
1000c7954:     	cmp	w15, #8
1000c7958:     	csel	w15, wzr, w11, lo
1000c795c:     	bfxil	w15, w14, #0, #4
1000c7960:     	scvtf	s1, w15
1000c7964:     	fmsub	s1, s1, s0, s3
1000c7968:     	str	s1, [x3, #44]
1000c796c:     	ldrb	w14, [x13, #48]
1000c7970:     	lsr	w14, w14, w12
1000c7974:     	and	w15, w14, #0xf
1000c7978:     	cmp	w15, #8
1000c797c:     	csel	w15, wzr, w11, lo
1000c7980:     	bfxil	w15, w14, #0, #4
1000c7984:     	scvtf	s1, w15
1000c7988:     	ldp	s2, s3, [x3, #48]
1000c798c:     	fmsub	s1, s1, s0, s2
1000c7990:     	str	s1, [x3, #48]
1000c7994:     	ldrb	w14, [x13, #52]
1000c7998:     	lsr	w14, w14, w12
1000c799c:     	and	w15, w14, #0xf
1000c79a0:     	cmp	w15, #8
1000c79a4:     	csel	w15, wzr, w11, lo
1000c79a8:     	bfxil	w15, w14, #0, #4
1000c79ac:     	scvtf	s1, w15
1000c79b0:     	fmsub	s1, s1, s0, s3
1000c79b4:     	str	s1, [x3, #52]
1000c79b8:     	ldrb	w14, [x13, #56]
1000c79bc:     	lsr	w14, w14, w12
1000c79c0:     	and	w15, w14, #0xf
1000c79c4:     	cmp	w15, #8
1000c79c8:     	csel	w15, wzr, w11, lo
1000c79cc:     	bfxil	w15, w14, #0, #4
1000c79d0:     	scvtf	s1, w15
1000c79d4:     	ldp	s2, s3, [x3, #56]
1000c79d8:     	fmsub	s1, s1, s0, s2
1000c79dc:     	str	s1, [x3, #56]
1000c79e0:     	ldrb	w13, [x13, #60]
1000c79e4:     	lsr	w12, w13, w12
1000c79e8:     	and	w13, w12, #0xf
1000c79ec:     	cmp	w13, #8
1000c79f0:     	csel	w13, wzr, w11, lo
1000c79f4:     	bfxil	w13, w12, #0, #4
1000c79f8:     	scvtf	s1, w13
1000c79fc:     	fmsub	s0, s1, s0, s3
1000c7a00:     	str	s0, [x3, #60]
1000c7a04:     	add	x8, x8, #1
1000c7a08:     	add	w10, w10, #4
1000c7a0c:     	cmp	x2, x8
1000c7a10:     	b.ne	0x1000c776c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x148>
1000c7a14:     	ldp	x20, x19, [sp, #16]
1000c7a18:     	ldp	x22, x21, [sp], #32
1000c7a1c:     	ret

00000001000c8e00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c8e00:     	sub	sp, sp, #272
1000c8e04:     	stp	x28, x27, [sp, #176]
1000c8e08:     	stp	x26, x25, [sp, #192]
1000c8e0c:     	stp	x24, x23, [sp, #208]
1000c8e10:     	stp	x22, x21, [sp, #224]
1000c8e14:     	stp	x20, x19, [sp, #240]
1000c8e18:     	stp	x29, x30, [sp, #256]
1000c8e1c:     	add	x29, sp, #256
1000c8e20:     	str	x3, [sp]
1000c8e24:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x84>
1000c8e28:     	ldr	x8, [x8, #392]
1000c8e2c:     	ldr	x8, [x8]
1000c8e30:     	stur	x8, [x29, #-96]
1000c8e34:     	movi.2d	v0, #0000000000000000
1000c8e38:     	stp	q0, q0, [sp, #128]
1000c8e3c:     	stp	q0, q0, [sp, #96]
1000c8e40:     	stp	q0, q0, [sp, #64]
1000c8e44:     	stp	q0, q0, [sp, #32]
1000c8e48:     	ands	x8, x2, #0xfffffffffffffffe
1000c8e4c:     	b.eq	0x1000c8fd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c8e50:     	add	x8, x1, x8
1000c8e54:     	str	x8, [sp, #8]
1000c8e58:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c8e5c:     	add	x9, x9, #1212
1000c8e60:     	mov	x11, #0
1000c8e64:     	ldp	w4, w23, [x1]
1000c8e68:     	ubfx	x8, x4, #8, #4
1000c8e6c:     	stp	x1, x8, [sp, #16]
1000c8e70:     	ubfx	x13, x4, #16, #4
1000c8e74:     	and	x14, x4, #0xf
1000c8e78:     	ubfx	x15, x4, #24, #4
1000c8e7c:     	ubfx	x16, x4, #4, #4
1000c8e80:     	ubfx	x17, x4, #12, #4
1000c8e84:     	ubfx	x2, x4, #20, #4
1000c8e88:     	lsr	x4, x4, #28
1000c8e8c:     	and	x5, x23, #0xf
1000c8e90:     	ubfx	x6, x23, #8, #4
1000c8e94:     	ubfx	x7, x23, #16, #4
1000c8e98:     	ubfx	x19, x23, #24, #4
1000c8e9c:     	ubfx	x20, x23, #4, #4
1000c8ea0:     	ubfx	x21, x23, #12, #4
1000c8ea4:     	ubfx	x22, x23, #20, #4
1000c8ea8:     	lsr	x23, x23, #28
1000c8eac:     	ldr	w24, [x0, x11]
1000c8eb0:     	lsl	w25, w24, #4
1000c8eb4:     	and	x25, x25, #0xf0
1000c8eb8:     	add	x25, x9, x25
1000c8ebc:     	and	x26, x24, #0xf0
1000c8ec0:     	add	x26, x9, x26
1000c8ec4:     	lsr	x27, x24, #4
1000c8ec8:     	and	x27, x27, #0xf0
1000c8ecc:     	add	x27, x9, x27
1000c8ed0:     	lsr	x28, x24, #8
1000c8ed4:     	and	x28, x28, #0xf0
1000c8ed8:     	add	x28, x9, x28
1000c8edc:     	lsr	x30, x24, #12
1000c8ee0:     	and	x30, x30, #0xf0
1000c8ee4:     	add	x30, x9, x30
1000c8ee8:     	lsr	x8, x24, #16
1000c8eec:     	and	x8, x8, #0xf0
1000c8ef0:     	add	x8, x9, x8
1000c8ef4:     	lsr	x3, x24, #20
1000c8ef8:     	and	x3, x3, #0xf0
1000c8efc:     	add	x3, x9, x3
1000c8f00:     	lsr	x24, x24, #24
1000c8f04:     	and	x24, x24, #0xf0
1000c8f08:     	ldrb	w10, [x25, x14]
1000c8f0c:     	ldr	x12, [sp, #24]
1000c8f10:     	ldrb	w1, [x27, x12]
1000c8f14:     	ldrb	w12, [x30, x13]
1000c8f18:     	add	w10, w10, w1
1000c8f1c:     	add	w10, w10, w12
1000c8f20:     	ldrb	w12, [x3, x15]
1000c8f24:     	ldrb	w1, [x26, x16]
1000c8f28:     	add	w10, w10, w12
1000c8f2c:     	add	w10, w10, w1
1000c8f30:     	ldrb	w12, [x28, x17]
1000c8f34:     	ldrb	w1, [x8, x2]
1000c8f38:     	add	x24, x9, x24
1000c8f3c:     	add	w10, w10, w12
1000c8f40:     	add	w10, w10, w1
1000c8f44:     	ldrb	w12, [x24, x4]
1000c8f48:     	add	w10, w10, w12
1000c8f4c:     	scvtf	s0, w10
1000c8f50:     	add	x10, sp, #32
1000c8f54:     	add	x10, x10, x11
1000c8f58:     	ldr	s1, [x10]
1000c8f5c:     	ldrb	w12, [x25, x5]
1000c8f60:     	fadd	s0, s1, s0
1000c8f64:     	ldrb	w1, [x27, x6]
1000c8f68:     	ldrb	w25, [x30, x7]
1000c8f6c:     	add	w12, w12, w1
1000c8f70:     	add	w12, w12, w25
1000c8f74:     	ldrb	w1, [x3, x19]
1000c8f78:     	ldrb	w3, [x26, x20]
1000c8f7c:     	add	w12, w12, w1
1000c8f80:     	add	w12, w12, w3
1000c8f84:     	ldrb	w1, [x28, x21]
1000c8f88:     	ldrb	w8, [x8, x22]
1000c8f8c:     	add	w12, w12, w1
1000c8f90:     	add	w8, w12, w8
1000c8f94:     	ldrb	w12, [x24, x23]
1000c8f98:     	add	w8, w8, w12
1000c8f9c:     	scvtf	s1, w8
1000c8fa0:     	str	s0, [x10]
1000c8fa4:     	ldr	s0, [x10, #64]
1000c8fa8:     	fadd	s0, s0, s1
1000c8fac:     	str	s0, [x10, #64]
1000c8fb0:     	add	x11, x11, #4
1000c8fb4:     	cmp	x11, #64
1000c8fb8:     	b.ne	0x1000c8eac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c8fbc:     	add	x0, x0, #64
1000c8fc0:     	ldp	x8, x1, [sp, #8]
1000c8fc4:     	add	x1, x1, #8
1000c8fc8:     	cmp	x1, x8
1000c8fcc:     	b.ne	0x1000c8e60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c8fd0:     	ldp	q0, q1, [sp, #96]
1000c8fd4:     	ldr	x8, [sp]
1000c8fd8:     	stp	q0, q1, [x8, #64]
1000c8fdc:     	ldp	q0, q1, [sp, #128]
1000c8fe0:     	stp	q0, q1, [x8, #96]
1000c8fe4:     	ldp	q0, q1, [sp, #32]
1000c8fe8:     	stp	q0, q1, [x8]
1000c8fec:     	ldp	q0, q1, [sp, #64]
1000c8ff0:     	stp	q0, q1, [x8, #32]
1000c8ff4:     	ldur	x8, [x29, #-96]
1000c8ff8:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x19c>
1000c8ffc:     	ldr	x9, [x9, #392]
1000c9000:     	ldr	x9, [x9]
1000c9004:     	cmp	x9, x8
1000c9008:     	b.ne	0x1000c902c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c900c:     	ldp	x29, x30, [sp, #256]
1000c9010:     	ldp	x20, x19, [sp, #240]
1000c9014:     	ldp	x22, x21, [sp, #224]
1000c9018:     	ldp	x24, x23, [sp, #208]
1000c901c:     	ldp	x26, x25, [sp, #192]
1000c9020:     	ldp	x28, x27, [sp, #176]
1000c9024:     	add	sp, sp, #272
1000c9028:     	ret
1000c902c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000c90ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c90ec:     	sub	sp, sp, #272
1000c90f0:     	stp	x28, x27, [sp, #176]
1000c90f4:     	stp	x26, x25, [sp, #192]
1000c90f8:     	stp	x24, x23, [sp, #208]
1000c90fc:     	stp	x22, x21, [sp, #224]
1000c9100:     	stp	x20, x19, [sp, #240]
1000c9104:     	stp	x29, x30, [sp, #256]
1000c9108:     	add	x29, sp, #256
1000c910c:     	str	x3, [sp]
1000c9110:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x80>
1000c9114:     	ldr	x8, [x8, #392]
1000c9118:     	ldr	x8, [x8]
1000c911c:     	stur	x8, [x29, #-96]
1000c9120:     	movi.2d	v0, #0000000000000000
1000c9124:     	stp	q0, q0, [sp, #128]
1000c9128:     	stp	q0, q0, [sp, #96]
1000c912c:     	stp	q0, q0, [sp, #64]
1000c9130:     	stp	q0, q0, [sp, #32]
1000c9134:     	ands	x8, x2, #0xfffffffffffffffe
1000c9138:     	b.eq	0x1000c92bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c913c:     	add	x8, x1, x8
1000c9140:     	str	x8, [sp, #8]
1000c9144:     	adrp	x9, 0x10016a000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0xac>
1000c9148:     	add	x9, x9, #1468
1000c914c:     	mov	x11, #0
1000c9150:     	ldp	w4, w23, [x1]
1000c9154:     	ubfx	x8, x4, #8, #4
1000c9158:     	stp	x1, x8, [sp, #16]
1000c915c:     	ubfx	x13, x4, #16, #4
1000c9160:     	and	x14, x4, #0xf
1000c9164:     	ubfx	x15, x4, #24, #4
1000c9168:     	ubfx	x16, x4, #4, #4
1000c916c:     	ubfx	x17, x4, #12, #4
1000c9170:     	ubfx	x2, x4, #20, #4
1000c9174:     	lsr	x4, x4, #28
1000c9178:     	and	x5, x23, #0xf
1000c917c:     	ubfx	x6, x23, #8, #4
1000c9180:     	ubfx	x7, x23, #16, #4
1000c9184:     	ubfx	x19, x23, #24, #4
1000c9188:     	ubfx	x20, x23, #4, #4
1000c918c:     	ubfx	x21, x23, #12, #4
1000c9190:     	ubfx	x22, x23, #20, #4
1000c9194:     	lsr	x23, x23, #28
1000c9198:     	ldr	w24, [x0, x11]
1000c919c:     	lsl	w25, w24, #4
1000c91a0:     	and	x25, x25, #0xf0
1000c91a4:     	add	x25, x9, x25
1000c91a8:     	and	x26, x24, #0xf0
1000c91ac:     	add	x26, x9, x26
1000c91b0:     	lsr	x27, x24, #4
1000c91b4:     	and	x27, x27, #0xf0
1000c91b8:     	add	x27, x9, x27
1000c91bc:     	lsr	x28, x24, #8
1000c91c0:     	and	x28, x28, #0xf0
1000c91c4:     	add	x28, x9, x28
1000c91c8:     	lsr	x30, x24, #12
1000c91cc:     	and	x30, x30, #0xf0
1000c91d0:     	add	x30, x9, x30
1000c91d4:     	lsr	x8, x24, #16
1000c91d8:     	and	x8, x8, #0xf0
1000c91dc:     	add	x8, x9, x8
1000c91e0:     	lsr	x3, x24, #20
1000c91e4:     	and	x3, x3, #0xf0
1000c91e8:     	add	x3, x9, x3
1000c91ec:     	lsr	x24, x24, #24
1000c91f0:     	and	x24, x24, #0xf0
1000c91f4:     	ldrsb	w10, [x25, x14]
1000c91f8:     	ldr	x12, [sp, #24]
1000c91fc:     	ldrsb	w1, [x27, x12]
1000c9200:     	ldrsb	w12, [x30, x13]
1000c9204:     	add	w10, w10, w1
1000c9208:     	add	w10, w10, w12
1000c920c:     	ldrsb	w12, [x3, x15]
1000c9210:     	ldrsb	w1, [x26, x16]
1000c9214:     	add	w10, w10, w12
1000c9218:     	add	w10, w10, w1
1000c921c:     	ldrsb	w12, [x28, x17]
1000c9220:     	ldrsb	w1, [x8, x2]
1000c9224:     	add	x24, x9, x24
1000c9228:     	add	w10, w10, w12
1000c922c:     	add	w10, w10, w1
1000c9230:     	ldrsb	w12, [x24, x4]
1000c9234:     	add	w10, w10, w12
1000c9238:     	scvtf	s0, w10
1000c923c:     	add	x10, sp, #32
1000c9240:     	add	x10, x10, x11
1000c9244:     	ldr	s1, [x10]
1000c9248:     	ldrsb	w12, [x25, x5]
1000c924c:     	fadd	s0, s1, s0
1000c9250:     	ldrsb	w1, [x27, x6]
1000c9254:     	ldrsb	w25, [x30, x7]
1000c9258:     	add	w12, w12, w1
1000c925c:     	add	w12, w12, w25
1000c9260:     	ldrsb	w1, [x3, x19]
1000c9264:     	ldrsb	w3, [x26, x20]
1000c9268:     	add	w12, w12, w1
1000c926c:     	add	w12, w12, w3
1000c9270:     	ldrsb	w1, [x28, x21]
1000c9274:     	ldrsb	w8, [x8, x22]
1000c9278:     	add	w12, w12, w1
1000c927c:     	add	w8, w12, w8
1000c9280:     	ldrsb	w12, [x24, x23]
1000c9284:     	add	w8, w8, w12
1000c9288:     	scvtf	s1, w8
1000c928c:     	str	s0, [x10]
1000c9290:     	ldr	s0, [x10, #64]
1000c9294:     	fadd	s0, s0, s1
1000c9298:     	str	s0, [x10, #64]
1000c929c:     	add	x11, x11, #4
1000c92a0:     	cmp	x11, #64
1000c92a4:     	b.ne	0x1000c9198 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c92a8:     	add	x0, x0, #64
1000c92ac:     	ldp	x8, x1, [sp, #8]
1000c92b0:     	add	x1, x1, #8
1000c92b4:     	cmp	x1, x8
1000c92b8:     	b.ne	0x1000c914c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c92bc:     	ldp	q0, q1, [sp, #96]
1000c92c0:     	ldr	x8, [sp]
1000c92c4:     	stp	q0, q1, [x8, #64]
1000c92c8:     	ldp	q0, q1, [sp, #128]
1000c92cc:     	stp	q0, q1, [x8, #96]
1000c92d0:     	ldp	q0, q1, [sp, #32]
1000c92d4:     	stp	q0, q1, [x8]
1000c92d8:     	ldp	q0, q1, [sp, #64]
1000c92dc:     	stp	q0, q1, [x8, #32]
1000c92e0:     	ldur	x8, [x29, #-96]
1000c92e4:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x254>
1000c92e8:     	ldr	x9, [x9, #392]
1000c92ec:     	ldr	x9, [x9]
1000c92f0:     	cmp	x9, x8
1000c92f4:     	b.ne	0x1000c9318 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c92f8:     	ldp	x29, x30, [sp, #256]
1000c92fc:     	ldp	x20, x19, [sp, #240]
1000c9300:     	ldp	x22, x21, [sp, #224]
1000c9304:     	ldp	x24, x23, [sp, #208]
1000c9308:     	ldp	x26, x25, [sp, #192]
1000c930c:     	ldp	x28, x27, [sp, #176]
1000c9310:     	add	sp, sp, #272
1000c9314:     	ret
1000c9318:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000ca768 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ca768:     	stp	x28, x27, [sp, #-96]!
1000ca76c:     	stp	x26, x25, [sp, #16]
1000ca770:     	stp	x24, x23, [sp, #32]
1000ca774:     	stp	x22, x21, [sp, #48]
1000ca778:     	stp	x20, x19, [sp, #64]
1000ca77c:     	stp	x29, x30, [sp, #80]
1000ca780:     	add	x29, sp, #80
1000ca784:     	sub	sp, sp, #448
1000ca788:     	str	x3, [sp]
1000ca78c:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000ca790:     	ldr	x8, [x8, #392]
1000ca794:     	ldr	x8, [x8]
1000ca798:     	stur	x8, [x29, #-96]
1000ca79c:     	movi.2d	v0, #0000000000000000
1000ca7a0:     	stp	q0, q0, [sp, #400]
1000ca7a4:     	lsl	x8, x2, #1
1000ca7a8:     	stp	q0, q0, [sp, #368]
1000ca7ac:     	stp	q0, q0, [sp, #336]
1000ca7b0:     	stp	q0, q0, [sp, #304]
1000ca7b4:     	stp	q0, q0, [sp, #272]
1000ca7b8:     	stp	q0, q0, [sp, #240]
1000ca7bc:     	stp	q0, q0, [sp, #208]
1000ca7c0:     	stp	q0, q0, [sp, #176]
1000ca7c4:     	ands	x8, x8, #0xfffffffffffffffc
1000ca7c8:     	b.eq	0x1000caaa4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000ca7cc:     	add	x8, x1, x8
1000ca7d0:     	str	x8, [sp, #8]
1000ca7d4:     	add	x8, sp, #176
1000ca7d8:     	add	x27, x8, #128
1000ca7dc:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000ca7e0:     	add	x11, x11, #1212
1000ca7e4:     	mov	x12, #0
1000ca7e8:     	ldp	w8, w9, [x1]
1000ca7ec:     	ubfx	x10, x8, #8, #4
1000ca7f0:     	str	x10, [sp, #168]
1000ca7f4:     	ubfx	x10, x8, #16, #4
1000ca7f8:     	str	x10, [sp, #160]
1000ca7fc:     	ubfx	x10, x8, #24, #4
1000ca800:     	str	x10, [sp, #152]
1000ca804:     	ldp	w10, w17, [x1, #8]
1000ca808:     	str	x1, [sp, #16]
1000ca80c:     	and	x14, x8, #0xf
1000ca810:     	ubfx	x13, x8, #4, #4
1000ca814:     	stp	x13, x14, [sp, #136]
1000ca818:     	ubfx	x14, x8, #12, #4
1000ca81c:     	ubfx	x13, x8, #20, #4
1000ca820:     	stp	x13, x14, [sp, #120]
1000ca824:     	lsr	x8, x8, #28
1000ca828:     	str	x8, [sp, #112]
1000ca82c:     	and	x8, x9, #0xf
1000ca830:     	str	x8, [sp, #104]
1000ca834:     	ubfx	x8, x9, #8, #4
1000ca838:     	str	x8, [sp, #96]
1000ca83c:     	ubfx	x8, x9, #16, #4
1000ca840:     	str	x8, [sp, #88]
1000ca844:     	ubfx	x8, x9, #24, #4
1000ca848:     	str	x8, [sp, #80]
1000ca84c:     	ubfx	x8, x9, #4, #4
1000ca850:     	str	x8, [sp, #72]
1000ca854:     	ubfx	x8, x9, #12, #4
1000ca858:     	str	x8, [sp, #64]
1000ca85c:     	ubfx	x8, x9, #20, #4
1000ca860:     	str	x8, [sp, #56]
1000ca864:     	lsr	x8, x9, #28
1000ca868:     	str	x8, [sp, #48]
1000ca86c:     	and	x9, x10, #0xf
1000ca870:     	ubfx	x8, x10, #8, #4
1000ca874:     	stp	x8, x9, [sp, #32]
1000ca878:     	ubfx	x8, x10, #16, #4
1000ca87c:     	str	x8, [sp, #24]
1000ca880:     	ubfx	x28, x10, #24, #4
1000ca884:     	ubfx	x30, x10, #4, #4
1000ca888:     	ubfx	x8, x10, #12, #4
1000ca88c:     	ubfx	x3, x10, #20, #4
1000ca890:     	lsr	x9, x10, #28
1000ca894:     	and	x1, x17, #0xf
1000ca898:     	ubfx	x10, x17, #8, #4
1000ca89c:     	ubfx	x13, x17, #16, #4
1000ca8a0:     	ubfx	x26, x17, #24, #4
1000ca8a4:     	ubfx	x14, x17, #4, #4
1000ca8a8:     	ubfx	x15, x17, #12, #4
1000ca8ac:     	ubfx	x16, x17, #20, #4
1000ca8b0:     	lsr	x17, x17, #28
1000ca8b4:     	ldr	w20, [x0, x12]
1000ca8b8:     	lsl	w2, w20, #4
1000ca8bc:     	and	x2, x2, #0xf0
1000ca8c0:     	add	x5, x11, x2
1000ca8c4:     	and	x2, x20, #0xf0
1000ca8c8:     	add	x2, x11, x2
1000ca8cc:     	lsr	x4, x20, #4
1000ca8d0:     	and	x4, x4, #0xf0
1000ca8d4:     	add	x7, x11, x4
1000ca8d8:     	lsr	x4, x20, #8
1000ca8dc:     	and	x4, x4, #0xf0
1000ca8e0:     	add	x4, x11, x4
1000ca8e4:     	lsr	x6, x20, #12
1000ca8e8:     	and	x6, x6, #0xf0
1000ca8ec:     	add	x19, x11, x6
1000ca8f0:     	lsr	x6, x20, #16
1000ca8f4:     	and	x6, x6, #0xf0
1000ca8f8:     	add	x6, x11, x6
1000ca8fc:     	lsr	x21, x20, #20
1000ca900:     	and	x21, x21, #0xf0
1000ca904:     	add	x21, x11, x21
1000ca908:     	lsr	x20, x20, #24
1000ca90c:     	and	x20, x20, #0xf0
1000ca910:     	ldr	x22, [sp, #144]
1000ca914:     	ldrb	w22, [x5, x22]
1000ca918:     	add	x20, x11, x20
1000ca91c:     	ldp	x24, x23, [sp, #160]
1000ca920:     	ldrb	w23, [x7, x23]
1000ca924:     	ldrb	w24, [x19, x24]
1000ca928:     	add	w22, w22, w23
1000ca92c:     	add	w22, w22, w24
1000ca930:     	ldr	x23, [sp, #152]
1000ca934:     	ldrb	w23, [x21, x23]
1000ca938:     	ldr	x24, [sp, #136]
1000ca93c:     	ldrb	w24, [x2, x24]
1000ca940:     	add	w22, w22, w23
1000ca944:     	add	w22, w22, w24
1000ca948:     	ldp	x24, x23, [sp, #120]
1000ca94c:     	ldrb	w23, [x4, x23]
1000ca950:     	ldrb	w24, [x6, x24]
1000ca954:     	add	w22, w22, w23
1000ca958:     	add	w22, w22, w24
1000ca95c:     	ldr	x23, [sp, #112]
1000ca960:     	ldrb	w23, [x20, x23]
1000ca964:     	add	w22, w22, w23
1000ca968:     	scvtf	s0, w22
1000ca96c:     	ldp	x23, x22, [sp, #96]
1000ca970:     	ldrb	w22, [x5, x22]
1000ca974:     	ldrb	w23, [x7, x23]
1000ca978:     	ldp	x25, x24, [sp, #80]
1000ca97c:     	ldrb	w24, [x19, x24]
1000ca980:     	ldrb	w25, [x21, x25]
1000ca984:     	add	w22, w22, w23
1000ca988:     	ldr	x23, [sp, #72]
1000ca98c:     	ldrb	w23, [x2, x23]
1000ca990:     	add	w22, w22, w24
1000ca994:     	ldr	x24, [sp, #64]
1000ca998:     	ldrb	w24, [x4, x24]
1000ca99c:     	add	w22, w22, w25
1000ca9a0:     	ldr	x25, [sp, #56]
1000ca9a4:     	ldrb	w25, [x6, x25]
1000ca9a8:     	add	w22, w22, w23
1000ca9ac:     	add	w22, w22, w24
1000ca9b0:     	add	w22, w22, w25
1000ca9b4:     	ldr	x23, [sp, #48]
1000ca9b8:     	ldrb	w23, [x20, x23]
1000ca9bc:     	add	w22, w22, w23
1000ca9c0:     	scvtf	s1, w22
1000ca9c4:     	ldp	x23, x22, [sp, #32]
1000ca9c8:     	ldrb	w22, [x5, x22]
1000ca9cc:     	ldrb	w23, [x7, x23]
1000ca9d0:     	ldr	x24, [sp, #24]
1000ca9d4:     	ldrb	w24, [x19, x24]
1000ca9d8:     	add	w22, w22, w23
1000ca9dc:     	ldrb	w23, [x21, x28]
1000ca9e0:     	add	w22, w22, w24
1000ca9e4:     	ldrb	w24, [x2, x30]
1000ca9e8:     	add	w22, w22, w23
1000ca9ec:     	ldrb	w23, [x4, x8]
1000ca9f0:     	add	w22, w22, w24
1000ca9f4:     	ldrb	w24, [x6, x3]
1000ca9f8:     	add	w22, w22, w23
1000ca9fc:     	ldrb	w23, [x20, x9]
1000caa00:     	add	w22, w22, w24
1000caa04:     	add	w22, w22, w23
1000caa08:     	scvtf	s2, w22
1000caa0c:     	ldrb	w5, [x5, x1]
1000caa10:     	ldrb	w7, [x7, x10]
1000caa14:     	ldrb	w19, [x19, x13]
1000caa18:     	add	w5, w5, w7
1000caa1c:     	add	w5, w5, w19
1000caa20:     	ldrb	w7, [x21, x26]
1000caa24:     	ldrb	w2, [x2, x14]
1000caa28:     	add	w5, w5, w7
1000caa2c:     	add	w2, w5, w2
1000caa30:     	ldrb	w4, [x4, x15]
1000caa34:     	ldrb	w5, [x6, x16]
1000caa38:     	add	w2, w2, w4
1000caa3c:     	add	w2, w2, w5
1000caa40:     	ldrb	w4, [x20, x17]
1000caa44:     	add	w2, w2, w4
1000caa48:     	add	x4, sp, #176
1000caa4c:     	scvtf	s3, w2
1000caa50:     	add	x2, x27, x12
1000caa54:     	ldur	s4, [x2, #-64]
1000caa58:     	fadd	s1, s4, s1
1000caa5c:     	stur	s1, [x2, #-64]
1000caa60:     	ldr	s1, [x2]
1000caa64:     	fadd	s1, s1, s2
1000caa68:     	str	s1, [x2]
1000caa6c:     	ldr	s1, [x2, #64]
1000caa70:     	fadd	s1, s1, s3
1000caa74:     	ldr	s2, [x4, x12]
1000caa78:     	str	s1, [x2, #64]
1000caa7c:     	fadd	s0, s2, s0
1000caa80:     	str	s0, [x4, x12]
1000caa84:     	add	x12, x12, #4
1000caa88:     	cmp	x12, #64
1000caa8c:     	b.ne	0x1000ca8b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000caa90:     	add	x0, x0, #64
1000caa94:     	ldp	x8, x1, [sp, #8]
1000caa98:     	add	x1, x1, #16
1000caa9c:     	cmp	x1, x8
1000caaa0:     	b.ne	0x1000ca7e4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000caaa4:     	ldp	q0, q1, [sp, #368]
1000caaa8:     	ldr	x8, [sp]
1000caaac:     	stp	q0, q1, [x8, #192]
1000caab0:     	ldp	q0, q1, [sp, #400]
1000caab4:     	stp	q0, q1, [x8, #224]
1000caab8:     	ldp	q0, q1, [sp, #304]
1000caabc:     	stp	q0, q1, [x8, #128]
1000caac0:     	ldp	q0, q1, [sp, #336]
1000caac4:     	stp	q0, q1, [x8, #160]
1000caac8:     	ldp	q0, q1, [sp, #240]
1000caacc:     	stp	q0, q1, [x8, #64]
1000caad0:     	ldp	q0, q1, [sp, #272]
1000caad4:     	stp	q0, q1, [x8, #96]
1000caad8:     	ldp	q0, q1, [sp, #176]
1000caadc:     	stp	q0, q1, [x8]
1000caae0:     	ldp	q0, q1, [sp, #208]
1000caae4:     	stp	q0, q1, [x8, #32]
1000caae8:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x13c>
1000caaec:     	ldr	x8, [x8, #392]
1000caaf0:     	ldr	x8, [x8]
1000caaf4:     	ldur	x9, [x29, #-96]
1000caaf8:     	cmp	x8, x9
1000caafc:     	b.ne	0x1000cab20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000cab00:     	add	sp, sp, #448
1000cab04:     	ldp	x29, x30, [sp, #80]
1000cab08:     	ldp	x20, x19, [sp, #64]
1000cab0c:     	ldp	x22, x21, [sp, #48]
1000cab10:     	ldp	x24, x23, [sp, #32]
1000cab14:     	ldp	x26, x25, [sp, #16]
1000cab18:     	ldp	x28, x27, [sp], #96
1000cab1c:     	ret
1000cab20:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cac34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cac34:     	stp	x28, x27, [sp, #-96]!
1000cac38:     	stp	x26, x25, [sp, #16]
1000cac3c:     	stp	x24, x23, [sp, #32]
1000cac40:     	stp	x22, x21, [sp, #48]
1000cac44:     	stp	x20, x19, [sp, #64]
1000cac48:     	stp	x29, x30, [sp, #80]
1000cac4c:     	add	x29, sp, #80
1000cac50:     	sub	sp, sp, #448
1000cac54:     	str	x3, [sp]
1000cac58:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000cac5c:     	ldr	x8, [x8, #392]
1000cac60:     	ldr	x8, [x8]
1000cac64:     	stur	x8, [x29, #-96]
1000cac68:     	movi.2d	v0, #0000000000000000
1000cac6c:     	stp	q0, q0, [sp, #400]
1000cac70:     	lsl	x8, x2, #1
1000cac74:     	stp	q0, q0, [sp, #368]
1000cac78:     	stp	q0, q0, [sp, #336]
1000cac7c:     	stp	q0, q0, [sp, #304]
1000cac80:     	stp	q0, q0, [sp, #272]
1000cac84:     	stp	q0, q0, [sp, #240]
1000cac88:     	stp	q0, q0, [sp, #208]
1000cac8c:     	stp	q0, q0, [sp, #176]
1000cac90:     	ands	x8, x8, #0xfffffffffffffffc
1000cac94:     	b.eq	0x1000caf70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000cac98:     	add	x8, x1, x8
1000cac9c:     	str	x8, [sp, #8]
1000caca0:     	add	x8, sp, #176
1000caca4:     	add	x27, x8, #128
1000caca8:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000cacac:     	add	x11, x11, #1468
1000cacb0:     	mov	x12, #0
1000cacb4:     	ldp	w8, w9, [x1]
1000cacb8:     	ubfx	x10, x8, #8, #4
1000cacbc:     	str	x10, [sp, #168]
1000cacc0:     	ubfx	x10, x8, #16, #4
1000cacc4:     	str	x10, [sp, #160]
1000cacc8:     	ubfx	x10, x8, #24, #4
1000caccc:     	str	x10, [sp, #152]
1000cacd0:     	ldp	w10, w17, [x1, #8]
1000cacd4:     	str	x1, [sp, #16]
1000cacd8:     	and	x14, x8, #0xf
1000cacdc:     	ubfx	x13, x8, #4, #4
1000cace0:     	stp	x13, x14, [sp, #136]
1000cace4:     	ubfx	x14, x8, #12, #4
1000cace8:     	ubfx	x13, x8, #20, #4
1000cacec:     	stp	x13, x14, [sp, #120]
1000cacf0:     	lsr	x8, x8, #28
1000cacf4:     	str	x8, [sp, #112]
1000cacf8:     	and	x8, x9, #0xf
1000cacfc:     	str	x8, [sp, #104]
1000cad00:     	ubfx	x8, x9, #8, #4
1000cad04:     	str	x8, [sp, #96]
1000cad08:     	ubfx	x8, x9, #16, #4
1000cad0c:     	str	x8, [sp, #88]
1000cad10:     	ubfx	x8, x9, #24, #4
1000cad14:     	str	x8, [sp, #80]
1000cad18:     	ubfx	x8, x9, #4, #4
1000cad1c:     	str	x8, [sp, #72]
1000cad20:     	ubfx	x8, x9, #12, #4
1000cad24:     	str	x8, [sp, #64]
1000cad28:     	ubfx	x8, x9, #20, #4
1000cad2c:     	str	x8, [sp, #56]
1000cad30:     	lsr	x8, x9, #28
1000cad34:     	str	x8, [sp, #48]
1000cad38:     	and	x9, x10, #0xf
1000cad3c:     	ubfx	x8, x10, #8, #4
1000cad40:     	stp	x8, x9, [sp, #32]
1000cad44:     	ubfx	x8, x10, #16, #4
1000cad48:     	str	x8, [sp, #24]
1000cad4c:     	ubfx	x28, x10, #24, #4
1000cad50:     	ubfx	x30, x10, #4, #4
1000cad54:     	ubfx	x8, x10, #12, #4
1000cad58:     	ubfx	x3, x10, #20, #4
1000cad5c:     	lsr	x9, x10, #28
1000cad60:     	and	x1, x17, #0xf
1000cad64:     	ubfx	x10, x17, #8, #4
1000cad68:     	ubfx	x13, x17, #16, #4
1000cad6c:     	ubfx	x26, x17, #24, #4
1000cad70:     	ubfx	x14, x17, #4, #4
1000cad74:     	ubfx	x15, x17, #12, #4
1000cad78:     	ubfx	x16, x17, #20, #4
1000cad7c:     	lsr	x17, x17, #28
1000cad80:     	ldr	w20, [x0, x12]
1000cad84:     	lsl	w2, w20, #4
1000cad88:     	and	x2, x2, #0xf0
1000cad8c:     	add	x5, x11, x2
1000cad90:     	and	x2, x20, #0xf0
1000cad94:     	add	x2, x11, x2
1000cad98:     	lsr	x4, x20, #4
1000cad9c:     	and	x4, x4, #0xf0
1000cada0:     	add	x7, x11, x4
1000cada4:     	lsr	x4, x20, #8
1000cada8:     	and	x4, x4, #0xf0
1000cadac:     	add	x4, x11, x4
1000cadb0:     	lsr	x6, x20, #12
1000cadb4:     	and	x6, x6, #0xf0
1000cadb8:     	add	x19, x11, x6
1000cadbc:     	lsr	x6, x20, #16
1000cadc0:     	and	x6, x6, #0xf0
1000cadc4:     	add	x6, x11, x6
1000cadc8:     	lsr	x21, x20, #20
1000cadcc:     	and	x21, x21, #0xf0
1000cadd0:     	add	x21, x11, x21
1000cadd4:     	lsr	x20, x20, #24
1000cadd8:     	and	x20, x20, #0xf0
1000caddc:     	ldr	x22, [sp, #144]
1000cade0:     	ldrsb	w22, [x5, x22]
1000cade4:     	add	x20, x11, x20
1000cade8:     	ldp	x24, x23, [sp, #160]
1000cadec:     	ldrsb	w23, [x7, x23]
1000cadf0:     	ldrsb	w24, [x19, x24]
1000cadf4:     	add	w22, w22, w23
1000cadf8:     	add	w22, w22, w24
1000cadfc:     	ldr	x23, [sp, #152]
1000cae00:     	ldrsb	w23, [x21, x23]
1000cae04:     	ldr	x24, [sp, #136]
1000cae08:     	ldrsb	w24, [x2, x24]
1000cae0c:     	add	w22, w22, w23
1000cae10:     	add	w22, w22, w24
1000cae14:     	ldp	x24, x23, [sp, #120]
1000cae18:     	ldrsb	w23, [x4, x23]
1000cae1c:     	ldrsb	w24, [x6, x24]
1000cae20:     	add	w22, w22, w23
1000cae24:     	add	w22, w22, w24
1000cae28:     	ldr	x23, [sp, #112]
1000cae2c:     	ldrsb	w23, [x20, x23]
1000cae30:     	add	w22, w22, w23
1000cae34:     	scvtf	s0, w22
1000cae38:     	ldp	x23, x22, [sp, #96]
1000cae3c:     	ldrsb	w22, [x5, x22]
1000cae40:     	ldrsb	w23, [x7, x23]
1000cae44:     	ldp	x25, x24, [sp, #80]
1000cae48:     	ldrsb	w24, [x19, x24]
1000cae4c:     	ldrsb	w25, [x21, x25]
1000cae50:     	add	w22, w22, w23
1000cae54:     	ldr	x23, [sp, #72]
1000cae58:     	ldrsb	w23, [x2, x23]
1000cae5c:     	add	w22, w22, w24
1000cae60:     	ldr	x24, [sp, #64]
1000cae64:     	ldrsb	w24, [x4, x24]
1000cae68:     	add	w22, w22, w25
1000cae6c:     	ldr	x25, [sp, #56]
1000cae70:     	ldrsb	w25, [x6, x25]
1000cae74:     	add	w22, w22, w23
1000cae78:     	add	w22, w22, w24
1000cae7c:     	add	w22, w22, w25
1000cae80:     	ldr	x23, [sp, #48]
1000cae84:     	ldrsb	w23, [x20, x23]
1000cae88:     	add	w22, w22, w23
1000cae8c:     	scvtf	s1, w22
1000cae90:     	ldp	x23, x22, [sp, #32]
1000cae94:     	ldrsb	w22, [x5, x22]
1000cae98:     	ldrsb	w23, [x7, x23]
1000cae9c:     	ldr	x24, [sp, #24]
1000caea0:     	ldrsb	w24, [x19, x24]
1000caea4:     	add	w22, w22, w23
1000caea8:     	ldrsb	w23, [x21, x28]
1000caeac:     	add	w22, w22, w24
1000caeb0:     	ldrsb	w24, [x2, x30]
1000caeb4:     	add	w22, w22, w23
1000caeb8:     	ldrsb	w23, [x4, x8]
1000caebc:     	add	w22, w22, w24
1000caec0:     	ldrsb	w24, [x6, x3]
1000caec4:     	add	w22, w22, w23
1000caec8:     	ldrsb	w23, [x20, x9]
1000caecc:     	add	w22, w22, w24
1000caed0:     	add	w22, w22, w23
1000caed4:     	scvtf	s2, w22
1000caed8:     	ldrsb	w5, [x5, x1]
1000caedc:     	ldrsb	w7, [x7, x10]
1000caee0:     	ldrsb	w19, [x19, x13]
1000caee4:     	add	w5, w5, w7
1000caee8:     	add	w5, w5, w19
1000caeec:     	ldrsb	w7, [x21, x26]
1000caef0:     	ldrsb	w2, [x2, x14]
1000caef4:     	add	w5, w5, w7
1000caef8:     	add	w2, w5, w2
1000caefc:     	ldrsb	w4, [x4, x15]
1000caf00:     	ldrsb	w5, [x6, x16]
1000caf04:     	add	w2, w2, w4
1000caf08:     	add	w2, w2, w5
1000caf0c:     	ldrsb	w4, [x20, x17]
1000caf10:     	add	w2, w2, w4
1000caf14:     	add	x4, sp, #176
1000caf18:     	scvtf	s3, w2
1000caf1c:     	add	x2, x27, x12
1000caf20:     	ldur	s4, [x2, #-64]
1000caf24:     	fadd	s1, s4, s1
1000caf28:     	stur	s1, [x2, #-64]
1000caf2c:     	ldr	s1, [x2]
1000caf30:     	fadd	s1, s1, s2
1000caf34:     	str	s1, [x2]
1000caf38:     	ldr	s1, [x2, #64]
1000caf3c:     	fadd	s1, s1, s3
1000caf40:     	ldr	s2, [x4, x12]
1000caf44:     	str	s1, [x2, #64]
1000caf48:     	fadd	s0, s2, s0
1000caf4c:     	str	s0, [x4, x12]
1000caf50:     	add	x12, x12, #4
1000caf54:     	cmp	x12, #64
1000caf58:     	b.ne	0x1000cad80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000caf5c:     	add	x0, x0, #64
1000caf60:     	ldp	x8, x1, [sp, #8]
1000caf64:     	add	x1, x1, #16
1000caf68:     	cmp	x1, x8
1000caf6c:     	b.ne	0x1000cacb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000caf70:     	ldp	q0, q1, [sp, #368]
1000caf74:     	ldr	x8, [sp]
1000caf78:     	stp	q0, q1, [x8, #192]
1000caf7c:     	ldp	q0, q1, [sp, #400]
1000caf80:     	stp	q0, q1, [x8, #224]
1000caf84:     	ldp	q0, q1, [sp, #304]
1000caf88:     	stp	q0, q1, [x8, #128]
1000caf8c:     	ldp	q0, q1, [sp, #336]
1000caf90:     	stp	q0, q1, [x8, #160]
1000caf94:     	ldp	q0, q1, [sp, #240]
1000caf98:     	stp	q0, q1, [x8, #64]
1000caf9c:     	ldp	q0, q1, [sp, #272]
1000cafa0:     	stp	q0, q1, [x8, #96]
1000cafa4:     	ldp	q0, q1, [sp, #176]
1000cafa8:     	stp	q0, q1, [x8]
1000cafac:     	ldp	q0, q1, [sp, #208]
1000cafb0:     	stp	q0, q1, [x8, #32]
1000cafb4:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 8ul, false>(char const*)+0x24c>
1000cafb8:     	ldr	x8, [x8, #392]
1000cafbc:     	ldr	x8, [x8]
1000cafc0:     	ldur	x9, [x29, #-96]
1000cafc4:     	cmp	x8, x9
1000cafc8:     	b.ne	0x1000cafec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000cafcc:     	add	sp, sp, #448
1000cafd0:     	ldp	x29, x30, [sp, #80]
1000cafd4:     	ldp	x20, x19, [sp, #64]
1000cafd8:     	ldp	x22, x21, [sp, #48]
1000cafdc:     	ldp	x24, x23, [sp, #32]
1000cafe0:     	ldp	x26, x25, [sp, #16]
1000cafe4:     	ldp	x28, x27, [sp], #96
1000cafe8:     	ret
1000cafec:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cc944 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cc944:     	stp	x28, x27, [sp, #-96]!
1000cc948:     	stp	x26, x25, [sp, #16]
1000cc94c:     	stp	x24, x23, [sp, #32]
1000cc950:     	stp	x22, x21, [sp, #48]
1000cc954:     	stp	x20, x19, [sp, #64]
1000cc958:     	stp	x29, x30, [sp, #80]
1000cc95c:     	add	x29, sp, #80
1000cc960:     	sub	sp, sp, #976
1000cc964:     	str	x3, [sp, #8]
1000cc968:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a4>
1000cc96c:     	ldr	x8, [x8, #392]
1000cc970:     	ldr	x8, [x8]
1000cc974:     	stur	x8, [x29, #-96]
1000cc978:     	movi.2d	v0, #0000000000000000
1000cc97c:     	stp	q0, q0, [sp, #928]
1000cc980:     	lsl	x8, x2, #2
1000cc984:     	stp	q0, q0, [sp, #896]
1000cc988:     	stp	q0, q0, [sp, #864]
1000cc98c:     	stp	q0, q0, [sp, #832]
1000cc990:     	stp	q0, q0, [sp, #800]
1000cc994:     	stp	q0, q0, [sp, #768]
1000cc998:     	stp	q0, q0, [sp, #736]
1000cc99c:     	stp	q0, q0, [sp, #704]
1000cc9a0:     	stp	q0, q0, [sp, #672]
1000cc9a4:     	stp	q0, q0, [sp, #640]
1000cc9a8:     	stp	q0, q0, [sp, #608]
1000cc9ac:     	stp	q0, q0, [sp, #576]
1000cc9b0:     	stp	q0, q0, [sp, #544]
1000cc9b4:     	stp	q0, q0, [sp, #512]
1000cc9b8:     	stp	q0, q0, [sp, #480]
1000cc9bc:     	stp	q0, q0, [sp, #448]
1000cc9c0:     	ands	x8, x8, #0xfffffffffffffff8
1000cc9c4:     	b.eq	0x1000ccf14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cc9c8:     	add	x8, x1, x8
1000cc9cc:     	str	x8, [sp, #16]
1000cc9d0:     	add	x8, sp, #448
1000cc9d4:     	add	x19, x8, #256
1000cc9d8:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30c>
1000cc9dc:     	add	x11, x11, #1212
1000cc9e0:     	mov	x12, #0
1000cc9e4:     	ldp	w8, w9, [x1]
1000cc9e8:     	ubfx	x10, x8, #8, #4
1000cc9ec:     	str	x10, [sp, #440]
1000cc9f0:     	ubfx	x10, x8, #16, #4
1000cc9f4:     	str	x10, [sp, #432]
1000cc9f8:     	ubfx	x10, x8, #24, #4
1000cc9fc:     	str	x10, [sp, #424]
1000cca00:     	ldp	w10, w13, [x1, #8]
1000cca04:     	and	x15, x8, #0xf
1000cca08:     	ubfx	x14, x8, #4, #4
1000cca0c:     	stp	x14, x15, [sp, #408]
1000cca10:     	ubfx	x15, x8, #12, #4
1000cca14:     	ubfx	x14, x8, #20, #4
1000cca18:     	stp	x14, x15, [sp, #392]
1000cca1c:     	lsr	x8, x8, #28
1000cca20:     	str	x8, [sp, #384]
1000cca24:     	and	x8, x9, #0xf
1000cca28:     	str	x8, [sp, #376]
1000cca2c:     	ubfx	x8, x9, #8, #4
1000cca30:     	str	x8, [sp, #368]
1000cca34:     	ubfx	x8, x9, #16, #4
1000cca38:     	str	x8, [sp, #360]
1000cca3c:     	ubfx	x8, x9, #24, #4
1000cca40:     	str	x8, [sp, #352]
1000cca44:     	ubfx	x8, x9, #4, #4
1000cca48:     	str	x8, [sp, #344]
1000cca4c:     	ubfx	x8, x9, #12, #4
1000cca50:     	str	x8, [sp, #336]
1000cca54:     	ubfx	x8, x9, #20, #4
1000cca58:     	str	x8, [sp, #328]
1000cca5c:     	lsr	x8, x9, #28
1000cca60:     	str	x8, [sp, #320]
1000cca64:     	and	x9, x10, #0xf
1000cca68:     	ubfx	x8, x10, #8, #4
1000cca6c:     	stp	x8, x9, [sp, #304]
1000cca70:     	ubfx	x9, x10, #16, #4
1000cca74:     	ubfx	x8, x10, #24, #4
1000cca78:     	stp	x8, x9, [sp, #288]
1000cca7c:     	ubfx	x9, x10, #4, #4
1000cca80:     	ubfx	x8, x10, #12, #4
1000cca84:     	stp	x8, x9, [sp, #272]
1000cca88:     	ubfx	x9, x10, #20, #4
1000cca8c:     	lsr	x8, x10, #28
1000cca90:     	stp	x8, x9, [sp, #256]
1000cca94:     	and	x9, x13, #0xf
1000cca98:     	ubfx	x8, x13, #8, #4
1000cca9c:     	stp	x8, x9, [sp, #240]
1000ccaa0:     	ubfx	x9, x13, #16, #4
1000ccaa4:     	ubfx	x8, x13, #24, #4
1000ccaa8:     	stp	x8, x9, [sp, #224]
1000ccaac:     	ubfx	x9, x13, #4, #4
1000ccab0:     	ubfx	x8, x13, #12, #4
1000ccab4:     	stp	x8, x9, [sp, #208]
1000ccab8:     	ubfx	x9, x13, #20, #4
1000ccabc:     	lsr	x8, x13, #28
1000ccac0:     	stp	x8, x9, [sp, #192]
1000ccac4:     	ldp	w8, w9, [x1, #16]
1000ccac8:     	and	x10, x8, #0xf
1000ccacc:     	str	x10, [sp, #184]
1000ccad0:     	ubfx	x10, x8, #8, #4
1000ccad4:     	str	x10, [sp, #176]
1000ccad8:     	ubfx	x10, x8, #16, #4
1000ccadc:     	str	x10, [sp, #168]
1000ccae0:     	ubfx	x10, x8, #24, #4
1000ccae4:     	str	x10, [sp, #160]
1000ccae8:     	ubfx	x10, x8, #4, #4
1000ccaec:     	str	x10, [sp, #152]
1000ccaf0:     	ubfx	x10, x8, #12, #4
1000ccaf4:     	str	x10, [sp, #144]
1000ccaf8:     	ubfx	x10, x8, #20, #4
1000ccafc:     	lsr	x8, x8, #28
1000ccb00:     	stp	x8, x10, [sp, #128]
1000ccb04:     	and	x10, x9, #0xf
1000ccb08:     	ubfx	x8, x9, #8, #4
1000ccb0c:     	stp	x8, x10, [sp, #112]
1000ccb10:     	ubfx	x10, x9, #16, #4
1000ccb14:     	ubfx	x8, x9, #24, #4
1000ccb18:     	stp	x8, x10, [sp, #96]
1000ccb1c:     	ubfx	x10, x9, #4, #4
1000ccb20:     	ubfx	x8, x9, #12, #4
1000ccb24:     	stp	x8, x10, [sp, #80]
1000ccb28:     	ubfx	x10, x9, #20, #4
1000ccb2c:     	lsr	x8, x9, #28
1000ccb30:     	stp	x8, x10, [sp, #64]
1000ccb34:     	ldp	w14, w7, [x1, #24]
1000ccb38:     	and	x9, x14, #0xf
1000ccb3c:     	ubfx	x8, x14, #8, #4
1000ccb40:     	stp	x8, x9, [sp, #48]
1000ccb44:     	ubfx	x8, x14, #16, #4
1000ccb48:     	str	x8, [sp, #40]
1000ccb4c:     	ubfx	x8, x14, #24, #4
1000ccb50:     	stp	x1, x8, [sp, #24]
1000ccb54:     	ubfx	x10, x14, #4, #4
1000ccb58:     	ubfx	x13, x14, #12, #4
1000ccb5c:     	ubfx	x9, x14, #20, #4
1000ccb60:     	lsr	x14, x14, #28
1000ccb64:     	and	x15, x7, #0xf
1000ccb68:     	ubfx	x16, x7, #8, #4
1000ccb6c:     	ubfx	x17, x7, #16, #4
1000ccb70:     	ubfx	x2, x7, #24, #4
1000ccb74:     	ubfx	x4, x7, #4, #4
1000ccb78:     	ubfx	x5, x7, #12, #4
1000ccb7c:     	ubfx	x6, x7, #20, #4
1000ccb80:     	lsr	x7, x7, #28
1000ccb84:     	ldr	w26, [x0, x12]
1000ccb88:     	mov	x1, x19
1000ccb8c:     	lsl	w19, w26, #4
1000ccb90:     	and	x19, x19, #0xf0
1000ccb94:     	add	x19, x11, x19
1000ccb98:     	ldr	x8, [sp, #416]
1000ccb9c:     	ldrb	w25, [x19, x8]
1000ccba0:     	lsr	x20, x26, #4
1000ccba4:     	and	x20, x20, #0xf0
1000ccba8:     	add	x20, x11, x20
1000ccbac:     	ldr	x8, [sp, #440]
1000ccbb0:     	ldrb	w27, [x20, x8]
1000ccbb4:     	lsr	x21, x26, #12
1000ccbb8:     	and	x21, x21, #0xf0
1000ccbbc:     	add	x21, x11, x21
1000ccbc0:     	ldr	x8, [sp, #432]
1000ccbc4:     	ldrb	w28, [x21, x8]
1000ccbc8:     	lsr	x22, x26, #20
1000ccbcc:     	and	x22, x22, #0xf0
1000ccbd0:     	add	x23, x11, x22
1000ccbd4:     	ldr	x8, [sp, #424]
1000ccbd8:     	ldrb	w30, [x23, x8]
1000ccbdc:     	and	x22, x26, #0xf0
1000ccbe0:     	add	x22, x11, x22
1000ccbe4:     	ldr	x8, [sp, #408]
1000ccbe8:     	ldrb	w3, [x22, x8]
1000ccbec:     	lsr	x24, x26, #8
1000ccbf0:     	and	x24, x24, #0xf0
1000ccbf4:     	add	x24, x11, x24
1000ccbf8:     	ldr	x8, [sp, #400]
1000ccbfc:     	ldrb	w8, [x24, x8]
1000ccc00:     	add	w27, w25, w27
1000ccc04:     	lsr	x25, x26, #16
1000ccc08:     	and	x25, x25, #0xf0
1000ccc0c:     	add	x25, x11, x25
1000ccc10:     	add	w27, w27, w28
1000ccc14:     	ldr	x28, [sp, #392]
1000ccc18:     	ldrb	w28, [x25, x28]
1000ccc1c:     	lsr	x26, x26, #24
1000ccc20:     	and	x26, x26, #0xf0
1000ccc24:     	add	x26, x11, x26
1000ccc28:     	add	w27, w27, w30
1000ccc2c:     	ldr	x30, [sp, #384]
1000ccc30:     	ldrb	w30, [x26, x30]
1000ccc34:     	add	w3, w27, w3
1000ccc38:     	add	w8, w3, w8
1000ccc3c:     	add	w8, w8, w28
1000ccc40:     	add	w8, w8, w30
1000ccc44:     	scvtf	s0, w8
1000ccc48:     	ldp	x3, x8, [sp, #368]
1000ccc4c:     	ldrb	w8, [x19, x8]
1000ccc50:     	ldrb	w3, [x20, x3]
1000ccc54:     	ldp	x28, x27, [sp, #352]
1000ccc58:     	ldrb	w27, [x21, x27]
1000ccc5c:     	ldrb	w28, [x23, x28]
1000ccc60:     	ldr	x30, [sp, #344]
1000ccc64:     	ldrb	w30, [x22, x30]
1000ccc68:     	add	w8, w8, w3
1000ccc6c:     	ldr	x3, [sp, #336]
1000ccc70:     	ldrb	w3, [x24, x3]
1000ccc74:     	add	w8, w8, w27
1000ccc78:     	ldr	x27, [sp, #328]
1000ccc7c:     	ldrb	w27, [x25, x27]
1000ccc80:     	add	w8, w8, w28
1000ccc84:     	ldr	x28, [sp, #320]
1000ccc88:     	ldrb	w28, [x26, x28]
1000ccc8c:     	add	w8, w8, w30
1000ccc90:     	add	w8, w8, w3
1000ccc94:     	add	w8, w8, w27
1000ccc98:     	add	w8, w8, w28
1000ccc9c:     	scvtf	s1, w8
1000ccca0:     	ldp	x3, x8, [sp, #304]
1000ccca4:     	ldrb	w8, [x19, x8]
1000ccca8:     	ldrb	w3, [x20, x3]
1000cccac:     	ldp	x28, x27, [sp, #288]
1000cccb0:     	ldrb	w27, [x21, x27]
1000cccb4:     	ldrb	w28, [x23, x28]
1000cccb8:     	add	w8, w8, w3
1000cccbc:     	ldr	x3, [sp, #280]
1000cccc0:     	ldrb	w3, [x22, x3]
1000cccc4:     	add	w8, w8, w27
1000cccc8:     	ldr	x27, [sp, #272]
1000ccccc:     	ldrb	w27, [x24, x27]
1000cccd0:     	add	w8, w8, w28
1000cccd4:     	ldr	x28, [sp, #264]
1000cccd8:     	ldrb	w28, [x25, x28]
1000cccdc:     	add	w8, w8, w3
1000ccce0:     	ldr	x3, [sp, #256]
1000ccce4:     	ldrb	w3, [x26, x3]
1000ccce8:     	add	w8, w8, w27
1000cccec:     	add	w8, w8, w28
1000cccf0:     	add	w8, w8, w3
1000cccf4:     	scvtf	s2, w8
1000cccf8:     	ldp	x3, x8, [sp, #240]
1000cccfc:     	ldrb	w8, [x19, x8]
1000ccd00:     	ldrb	w3, [x20, x3]
1000ccd04:     	ldp	x28, x27, [sp, #224]
1000ccd08:     	ldrb	w27, [x21, x27]
1000ccd0c:     	ldrb	w28, [x23, x28]
1000ccd10:     	add	w8, w8, w3
1000ccd14:     	ldr	x3, [sp, #216]
1000ccd18:     	ldrb	w3, [x22, x3]
1000ccd1c:     	add	w8, w8, w27
1000ccd20:     	ldr	x27, [sp, #208]
1000ccd24:     	ldrb	w27, [x24, x27]
1000ccd28:     	add	w8, w8, w28
1000ccd2c:     	ldr	x28, [sp, #200]
1000ccd30:     	ldrb	w28, [x25, x28]
1000ccd34:     	add	w8, w8, w3
1000ccd38:     	ldr	x3, [sp, #192]
1000ccd3c:     	ldrb	w3, [x26, x3]
1000ccd40:     	add	w8, w8, w27
1000ccd44:     	add	w8, w8, w28
1000ccd48:     	add	w8, w8, w3
1000ccd4c:     	scvtf	s3, w8
1000ccd50:     	ldp	x3, x8, [sp, #176]
1000ccd54:     	ldrb	w8, [x19, x8]
1000ccd58:     	ldrb	w3, [x20, x3]
1000ccd5c:     	ldp	x28, x27, [sp, #160]
1000ccd60:     	ldrb	w27, [x21, x27]
1000ccd64:     	ldrb	w28, [x23, x28]
1000ccd68:     	add	w8, w8, w3
1000ccd6c:     	add	w8, w8, w27
1000ccd70:     	ldr	x3, [sp, #152]
1000ccd74:     	ldrb	w3, [x22, x3]
1000ccd78:     	add	w8, w8, w28
1000ccd7c:     	add	w8, w8, w3
1000ccd80:     	ldp	x27, x3, [sp, #136]
1000ccd84:     	ldrb	w3, [x24, x3]
1000ccd88:     	ldrb	w27, [x25, x27]
1000ccd8c:     	add	w8, w8, w3
1000ccd90:     	add	w8, w8, w27
1000ccd94:     	ldr	x3, [sp, #128]
1000ccd98:     	ldrb	w3, [x26, x3]
1000ccd9c:     	add	w8, w8, w3
1000ccda0:     	scvtf	s4, w8
1000ccda4:     	ldp	x3, x8, [sp, #112]
1000ccda8:     	ldrb	w8, [x19, x8]
1000ccdac:     	ldrb	w3, [x20, x3]
1000ccdb0:     	ldp	x28, x27, [sp, #96]
1000ccdb4:     	ldrb	w27, [x21, x27]
1000ccdb8:     	ldrb	w28, [x23, x28]
1000ccdbc:     	add	w8, w8, w3
1000ccdc0:     	ldr	x3, [sp, #88]
1000ccdc4:     	ldrb	w3, [x22, x3]
1000ccdc8:     	add	w8, w8, w27
1000ccdcc:     	ldr	x27, [sp, #80]
1000ccdd0:     	ldrb	w27, [x24, x27]
1000ccdd4:     	add	w8, w8, w28
1000ccdd8:     	ldr	x28, [sp, #72]
1000ccddc:     	ldrb	w28, [x25, x28]
1000ccde0:     	add	w8, w8, w3
1000ccde4:     	add	w8, w8, w27
1000ccde8:     	add	w8, w8, w28
1000ccdec:     	ldr	x3, [sp, #64]
1000ccdf0:     	ldrb	w3, [x26, x3]
1000ccdf4:     	add	w8, w8, w3
1000ccdf8:     	scvtf	s5, w8
1000ccdfc:     	ldp	x3, x8, [sp, #48]
1000cce00:     	ldrb	w8, [x19, x8]
1000cce04:     	ldrb	w3, [x20, x3]
1000cce08:     	ldr	x27, [sp, #40]
1000cce0c:     	ldrb	w27, [x21, x27]
1000cce10:     	add	w8, w8, w3
1000cce14:     	ldr	x3, [sp, #32]
1000cce18:     	ldrb	w3, [x23, x3]
1000cce1c:     	add	w8, w8, w27
1000cce20:     	ldrb	w27, [x22, x10]
1000cce24:     	add	w8, w8, w3
1000cce28:     	ldrb	w3, [x24, x13]
1000cce2c:     	add	w8, w8, w27
1000cce30:     	ldrb	w27, [x25, x9]
1000cce34:     	add	w8, w8, w3
1000cce38:     	ldrb	w3, [x26, x14]
1000cce3c:     	add	w8, w8, w27
1000cce40:     	add	w8, w8, w3
1000cce44:     	scvtf	s6, w8
1000cce48:     	ldrb	w8, [x19, x15]
1000cce4c:     	ldrb	w3, [x20, x16]
1000cce50:     	ldrb	w19, [x21, x17]
1000cce54:     	add	w8, w8, w3
1000cce58:     	add	w8, w8, w19
1000cce5c:     	ldrb	w3, [x23, x2]
1000cce60:     	ldrb	w19, [x22, x4]
1000cce64:     	add	w8, w8, w3
1000cce68:     	add	w8, w8, w19
1000cce6c:     	ldrb	w3, [x24, x5]
1000cce70:     	ldrb	w19, [x25, x6]
1000cce74:     	add	w8, w8, w3
1000cce78:     	add	w8, w8, w19
1000cce7c:     	mov	x19, x1
1000cce80:     	ldrb	w3, [x26, x7]
1000cce84:     	add	w8, w8, w3
1000cce88:     	add	x3, sp, #448
1000cce8c:     	scvtf	s7, w8
1000cce90:     	add	x8, x1, x12
1000cce94:     	ldur	s16, [x8, #-192]
1000cce98:     	fadd	s1, s16, s1
1000cce9c:     	stur	s1, [x8, #-192]
1000ccea0:     	ldur	s1, [x8, #-128]
1000ccea4:     	fadd	s1, s1, s2
1000ccea8:     	stur	s1, [x8, #-128]
1000cceac:     	ldur	s1, [x8, #-64]
1000cceb0:     	fadd	s1, s1, s3
1000cceb4:     	stur	s1, [x8, #-64]
1000cceb8:     	ldr	s1, [x8]
1000ccebc:     	fadd	s1, s1, s4
1000ccec0:     	str	s1, [x8]
1000ccec4:     	ldr	s1, [x8, #64]
1000ccec8:     	fadd	s1, s1, s5
1000ccecc:     	str	s1, [x8, #64]
1000cced0:     	ldr	s1, [x8, #128]
1000cced4:     	fadd	s1, s1, s6
1000cced8:     	str	s1, [x8, #128]
1000ccedc:     	ldr	s1, [x8, #192]
1000ccee0:     	fadd	s1, s1, s7
1000ccee4:     	ldr	s2, [x3, x12]
1000ccee8:     	str	s1, [x8, #192]
1000cceec:     	fadd	s0, s2, s0
1000ccef0:     	str	s0, [x3, x12]
1000ccef4:     	add	x12, x12, #4
1000ccef8:     	cmp	x12, #64
1000ccefc:     	b.ne	0x1000ccb84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000ccf00:     	add	x0, x0, #64
1000ccf04:     	ldp	x8, x1, [sp, #16]
1000ccf08:     	add	x1, x1, #32
1000ccf0c:     	cmp	x1, x8
1000ccf10:     	b.ne	0x1000cc9e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000ccf14:     	add	x1, sp, #448
1000ccf18:     	ldr	x0, [sp, #8]
1000ccf1c:     	mov	w2, #512
1000ccf20:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ccf24:     	ldur	x8, [x29, #-96]
1000ccf28:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x98>
1000ccf2c:     	ldr	x9, [x9, #392]
1000ccf30:     	ldr	x9, [x9]
1000ccf34:     	cmp	x9, x8
1000ccf38:     	b.ne	0x1000ccf5c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000ccf3c:     	add	sp, sp, #976
1000ccf40:     	ldp	x29, x30, [sp, #80]
1000ccf44:     	ldp	x20, x19, [sp, #64]
1000ccf48:     	ldp	x22, x21, [sp, #48]
1000ccf4c:     	ldp	x24, x23, [sp, #32]
1000ccf50:     	ldp	x26, x25, [sp, #16]
1000ccf54:     	ldp	x28, x27, [sp], #96
1000ccf58:     	ret
1000ccf5c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cd110 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cd110:     	stp	x28, x27, [sp, #-96]!
1000cd114:     	stp	x26, x25, [sp, #16]
1000cd118:     	stp	x24, x23, [sp, #32]
1000cd11c:     	stp	x22, x21, [sp, #48]
1000cd120:     	stp	x20, x19, [sp, #64]
1000cd124:     	stp	x29, x30, [sp, #80]
1000cd128:     	add	x29, sp, #80
1000cd12c:     	sub	sp, sp, #976
1000cd130:     	str	x3, [sp, #8]
1000cd134:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000cd138:     	ldr	x8, [x8, #392]
1000cd13c:     	ldr	x8, [x8]
1000cd140:     	stur	x8, [x29, #-96]
1000cd144:     	movi.2d	v0, #0000000000000000
1000cd148:     	stp	q0, q0, [sp, #928]
1000cd14c:     	lsl	x8, x2, #2
1000cd150:     	stp	q0, q0, [sp, #896]
1000cd154:     	stp	q0, q0, [sp, #864]
1000cd158:     	stp	q0, q0, [sp, #832]
1000cd15c:     	stp	q0, q0, [sp, #800]
1000cd160:     	stp	q0, q0, [sp, #768]
1000cd164:     	stp	q0, q0, [sp, #736]
1000cd168:     	stp	q0, q0, [sp, #704]
1000cd16c:     	stp	q0, q0, [sp, #672]
1000cd170:     	stp	q0, q0, [sp, #640]
1000cd174:     	stp	q0, q0, [sp, #608]
1000cd178:     	stp	q0, q0, [sp, #576]
1000cd17c:     	stp	q0, q0, [sp, #544]
1000cd180:     	stp	q0, q0, [sp, #512]
1000cd184:     	stp	q0, q0, [sp, #480]
1000cd188:     	stp	q0, q0, [sp, #448]
1000cd18c:     	ands	x8, x8, #0xfffffffffffffff8
1000cd190:     	b.eq	0x1000cd6e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cd194:     	add	x8, x1, x8
1000cd198:     	str	x8, [sp, #16]
1000cd19c:     	add	x8, sp, #448
1000cd1a0:     	add	x19, x8, #256
1000cd1a4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000cd1a8:     	add	x11, x11, #1468
1000cd1ac:     	mov	x12, #0
1000cd1b0:     	ldp	w8, w9, [x1]
1000cd1b4:     	ubfx	x10, x8, #8, #4
1000cd1b8:     	str	x10, [sp, #440]
1000cd1bc:     	ubfx	x10, x8, #16, #4
1000cd1c0:     	str	x10, [sp, #432]
1000cd1c4:     	ubfx	x10, x8, #24, #4
1000cd1c8:     	str	x10, [sp, #424]
1000cd1cc:     	ldp	w10, w13, [x1, #8]
1000cd1d0:     	and	x15, x8, #0xf
1000cd1d4:     	ubfx	x14, x8, #4, #4
1000cd1d8:     	stp	x14, x15, [sp, #408]
1000cd1dc:     	ubfx	x15, x8, #12, #4
1000cd1e0:     	ubfx	x14, x8, #20, #4
1000cd1e4:     	stp	x14, x15, [sp, #392]
1000cd1e8:     	lsr	x8, x8, #28
1000cd1ec:     	str	x8, [sp, #384]
1000cd1f0:     	and	x8, x9, #0xf
1000cd1f4:     	str	x8, [sp, #376]
1000cd1f8:     	ubfx	x8, x9, #8, #4
1000cd1fc:     	str	x8, [sp, #368]
1000cd200:     	ubfx	x8, x9, #16, #4
1000cd204:     	str	x8, [sp, #360]
1000cd208:     	ubfx	x8, x9, #24, #4
1000cd20c:     	str	x8, [sp, #352]
1000cd210:     	ubfx	x8, x9, #4, #4
1000cd214:     	str	x8, [sp, #344]
1000cd218:     	ubfx	x8, x9, #12, #4
1000cd21c:     	str	x8, [sp, #336]
1000cd220:     	ubfx	x8, x9, #20, #4
1000cd224:     	str	x8, [sp, #328]
1000cd228:     	lsr	x8, x9, #28
1000cd22c:     	str	x8, [sp, #320]
1000cd230:     	and	x9, x10, #0xf
1000cd234:     	ubfx	x8, x10, #8, #4
1000cd238:     	stp	x8, x9, [sp, #304]
1000cd23c:     	ubfx	x9, x10, #16, #4
1000cd240:     	ubfx	x8, x10, #24, #4
1000cd244:     	stp	x8, x9, [sp, #288]
1000cd248:     	ubfx	x9, x10, #4, #4
1000cd24c:     	ubfx	x8, x10, #12, #4
1000cd250:     	stp	x8, x9, [sp, #272]
1000cd254:     	ubfx	x9, x10, #20, #4
1000cd258:     	lsr	x8, x10, #28
1000cd25c:     	stp	x8, x9, [sp, #256]
1000cd260:     	and	x9, x13, #0xf
1000cd264:     	ubfx	x8, x13, #8, #4
1000cd268:     	stp	x8, x9, [sp, #240]
1000cd26c:     	ubfx	x9, x13, #16, #4
1000cd270:     	ubfx	x8, x13, #24, #4
1000cd274:     	stp	x8, x9, [sp, #224]
1000cd278:     	ubfx	x9, x13, #4, #4
1000cd27c:     	ubfx	x8, x13, #12, #4
1000cd280:     	stp	x8, x9, [sp, #208]
1000cd284:     	ubfx	x9, x13, #20, #4
1000cd288:     	lsr	x8, x13, #28
1000cd28c:     	stp	x8, x9, [sp, #192]
1000cd290:     	ldp	w8, w9, [x1, #16]
1000cd294:     	and	x10, x8, #0xf
1000cd298:     	str	x10, [sp, #184]
1000cd29c:     	ubfx	x10, x8, #8, #4
1000cd2a0:     	str	x10, [sp, #176]
1000cd2a4:     	ubfx	x10, x8, #16, #4
1000cd2a8:     	str	x10, [sp, #168]
1000cd2ac:     	ubfx	x10, x8, #24, #4
1000cd2b0:     	str	x10, [sp, #160]
1000cd2b4:     	ubfx	x10, x8, #4, #4
1000cd2b8:     	str	x10, [sp, #152]
1000cd2bc:     	ubfx	x10, x8, #12, #4
1000cd2c0:     	str	x10, [sp, #144]
1000cd2c4:     	ubfx	x10, x8, #20, #4
1000cd2c8:     	lsr	x8, x8, #28
1000cd2cc:     	stp	x8, x10, [sp, #128]
1000cd2d0:     	and	x10, x9, #0xf
1000cd2d4:     	ubfx	x8, x9, #8, #4
1000cd2d8:     	stp	x8, x10, [sp, #112]
1000cd2dc:     	ubfx	x10, x9, #16, #4
1000cd2e0:     	ubfx	x8, x9, #24, #4
1000cd2e4:     	stp	x8, x10, [sp, #96]
1000cd2e8:     	ubfx	x10, x9, #4, #4
1000cd2ec:     	ubfx	x8, x9, #12, #4
1000cd2f0:     	stp	x8, x10, [sp, #80]
1000cd2f4:     	ubfx	x10, x9, #20, #4
1000cd2f8:     	lsr	x8, x9, #28
1000cd2fc:     	stp	x8, x10, [sp, #64]
1000cd300:     	ldp	w14, w7, [x1, #24]
1000cd304:     	and	x9, x14, #0xf
1000cd308:     	ubfx	x8, x14, #8, #4
1000cd30c:     	stp	x8, x9, [sp, #48]
1000cd310:     	ubfx	x8, x14, #16, #4
1000cd314:     	str	x8, [sp, #40]
1000cd318:     	ubfx	x8, x14, #24, #4
1000cd31c:     	stp	x1, x8, [sp, #24]
1000cd320:     	ubfx	x10, x14, #4, #4
1000cd324:     	ubfx	x13, x14, #12, #4
1000cd328:     	ubfx	x9, x14, #20, #4
1000cd32c:     	lsr	x14, x14, #28
1000cd330:     	and	x15, x7, #0xf
1000cd334:     	ubfx	x16, x7, #8, #4
1000cd338:     	ubfx	x17, x7, #16, #4
1000cd33c:     	ubfx	x2, x7, #24, #4
1000cd340:     	ubfx	x4, x7, #4, #4
1000cd344:     	ubfx	x5, x7, #12, #4
1000cd348:     	ubfx	x6, x7, #20, #4
1000cd34c:     	lsr	x7, x7, #28
1000cd350:     	ldr	w26, [x0, x12]
1000cd354:     	mov	x1, x19
1000cd358:     	lsl	w19, w26, #4
1000cd35c:     	and	x19, x19, #0xf0
1000cd360:     	add	x19, x11, x19
1000cd364:     	ldr	x8, [sp, #416]
1000cd368:     	ldrsb	w25, [x19, x8]
1000cd36c:     	lsr	x20, x26, #4
1000cd370:     	and	x20, x20, #0xf0
1000cd374:     	add	x20, x11, x20
1000cd378:     	ldr	x8, [sp, #440]
1000cd37c:     	ldrsb	w27, [x20, x8]
1000cd380:     	lsr	x21, x26, #12
1000cd384:     	and	x21, x21, #0xf0
1000cd388:     	add	x21, x11, x21
1000cd38c:     	ldr	x8, [sp, #432]
1000cd390:     	ldrsb	w28, [x21, x8]
1000cd394:     	lsr	x22, x26, #20
1000cd398:     	and	x22, x22, #0xf0
1000cd39c:     	add	x23, x11, x22
1000cd3a0:     	ldr	x8, [sp, #424]
1000cd3a4:     	ldrsb	w30, [x23, x8]
1000cd3a8:     	and	x22, x26, #0xf0
1000cd3ac:     	add	x22, x11, x22
1000cd3b0:     	ldr	x8, [sp, #408]
1000cd3b4:     	ldrsb	w3, [x22, x8]
1000cd3b8:     	lsr	x24, x26, #8
1000cd3bc:     	and	x24, x24, #0xf0
1000cd3c0:     	add	x24, x11, x24
1000cd3c4:     	ldr	x8, [sp, #400]
1000cd3c8:     	ldrsb	w8, [x24, x8]
1000cd3cc:     	add	w27, w25, w27
1000cd3d0:     	lsr	x25, x26, #16
1000cd3d4:     	and	x25, x25, #0xf0
1000cd3d8:     	add	x25, x11, x25
1000cd3dc:     	add	w27, w27, w28
1000cd3e0:     	ldr	x28, [sp, #392]
1000cd3e4:     	ldrsb	w28, [x25, x28]
1000cd3e8:     	lsr	x26, x26, #24
1000cd3ec:     	and	x26, x26, #0xf0
1000cd3f0:     	add	x26, x11, x26
1000cd3f4:     	add	w27, w27, w30
1000cd3f8:     	ldr	x30, [sp, #384]
1000cd3fc:     	ldrsb	w30, [x26, x30]
1000cd400:     	add	w3, w27, w3
1000cd404:     	add	w8, w3, w8
1000cd408:     	add	w8, w8, w28
1000cd40c:     	add	w8, w8, w30
1000cd410:     	scvtf	s0, w8
1000cd414:     	ldp	x3, x8, [sp, #368]
1000cd418:     	ldrsb	w8, [x19, x8]
1000cd41c:     	ldrsb	w3, [x20, x3]
1000cd420:     	ldp	x28, x27, [sp, #352]
1000cd424:     	ldrsb	w27, [x21, x27]
1000cd428:     	ldrsb	w28, [x23, x28]
1000cd42c:     	ldr	x30, [sp, #344]
1000cd430:     	ldrsb	w30, [x22, x30]
1000cd434:     	add	w8, w8, w3
1000cd438:     	ldr	x3, [sp, #336]
1000cd43c:     	ldrsb	w3, [x24, x3]
1000cd440:     	add	w8, w8, w27
1000cd444:     	ldr	x27, [sp, #328]
1000cd448:     	ldrsb	w27, [x25, x27]
1000cd44c:     	add	w8, w8, w28
1000cd450:     	ldr	x28, [sp, #320]
1000cd454:     	ldrsb	w28, [x26, x28]
1000cd458:     	add	w8, w8, w30
1000cd45c:     	add	w8, w8, w3
1000cd460:     	add	w8, w8, w27
1000cd464:     	add	w8, w8, w28
1000cd468:     	scvtf	s1, w8
1000cd46c:     	ldp	x3, x8, [sp, #304]
1000cd470:     	ldrsb	w8, [x19, x8]
1000cd474:     	ldrsb	w3, [x20, x3]
1000cd478:     	ldp	x28, x27, [sp, #288]
1000cd47c:     	ldrsb	w27, [x21, x27]
1000cd480:     	ldrsb	w28, [x23, x28]
1000cd484:     	add	w8, w8, w3
1000cd488:     	ldr	x3, [sp, #280]
1000cd48c:     	ldrsb	w3, [x22, x3]
1000cd490:     	add	w8, w8, w27
1000cd494:     	ldr	x27, [sp, #272]
1000cd498:     	ldrsb	w27, [x24, x27]
1000cd49c:     	add	w8, w8, w28
1000cd4a0:     	ldr	x28, [sp, #264]
1000cd4a4:     	ldrsb	w28, [x25, x28]
1000cd4a8:     	add	w8, w8, w3
1000cd4ac:     	ldr	x3, [sp, #256]
1000cd4b0:     	ldrsb	w3, [x26, x3]
1000cd4b4:     	add	w8, w8, w27
1000cd4b8:     	add	w8, w8, w28
1000cd4bc:     	add	w8, w8, w3
1000cd4c0:     	scvtf	s2, w8
1000cd4c4:     	ldp	x3, x8, [sp, #240]
1000cd4c8:     	ldrsb	w8, [x19, x8]
1000cd4cc:     	ldrsb	w3, [x20, x3]
1000cd4d0:     	ldp	x28, x27, [sp, #224]
1000cd4d4:     	ldrsb	w27, [x21, x27]
1000cd4d8:     	ldrsb	w28, [x23, x28]
1000cd4dc:     	add	w8, w8, w3
1000cd4e0:     	ldr	x3, [sp, #216]
1000cd4e4:     	ldrsb	w3, [x22, x3]
1000cd4e8:     	add	w8, w8, w27
1000cd4ec:     	ldr	x27, [sp, #208]
1000cd4f0:     	ldrsb	w27, [x24, x27]
1000cd4f4:     	add	w8, w8, w28
1000cd4f8:     	ldr	x28, [sp, #200]
1000cd4fc:     	ldrsb	w28, [x25, x28]
1000cd500:     	add	w8, w8, w3
1000cd504:     	ldr	x3, [sp, #192]
1000cd508:     	ldrsb	w3, [x26, x3]
1000cd50c:     	add	w8, w8, w27
1000cd510:     	add	w8, w8, w28
1000cd514:     	add	w8, w8, w3
1000cd518:     	scvtf	s3, w8
1000cd51c:     	ldp	x3, x8, [sp, #176]
1000cd520:     	ldrsb	w8, [x19, x8]
1000cd524:     	ldrsb	w3, [x20, x3]
1000cd528:     	ldp	x28, x27, [sp, #160]
1000cd52c:     	ldrsb	w27, [x21, x27]
1000cd530:     	ldrsb	w28, [x23, x28]
1000cd534:     	add	w8, w8, w3
1000cd538:     	add	w8, w8, w27
1000cd53c:     	ldr	x3, [sp, #152]
1000cd540:     	ldrsb	w3, [x22, x3]
1000cd544:     	add	w8, w8, w28
1000cd548:     	add	w8, w8, w3
1000cd54c:     	ldp	x27, x3, [sp, #136]
1000cd550:     	ldrsb	w3, [x24, x3]
1000cd554:     	ldrsb	w27, [x25, x27]
1000cd558:     	add	w8, w8, w3
1000cd55c:     	add	w8, w8, w27
1000cd560:     	ldr	x3, [sp, #128]
1000cd564:     	ldrsb	w3, [x26, x3]
1000cd568:     	add	w8, w8, w3
1000cd56c:     	scvtf	s4, w8
1000cd570:     	ldp	x3, x8, [sp, #112]
1000cd574:     	ldrsb	w8, [x19, x8]
1000cd578:     	ldrsb	w3, [x20, x3]
1000cd57c:     	ldp	x28, x27, [sp, #96]
1000cd580:     	ldrsb	w27, [x21, x27]
1000cd584:     	ldrsb	w28, [x23, x28]
1000cd588:     	add	w8, w8, w3
1000cd58c:     	ldr	x3, [sp, #88]
1000cd590:     	ldrsb	w3, [x22, x3]
1000cd594:     	add	w8, w8, w27
1000cd598:     	ldr	x27, [sp, #80]
1000cd59c:     	ldrsb	w27, [x24, x27]
1000cd5a0:     	add	w8, w8, w28
1000cd5a4:     	ldr	x28, [sp, #72]
1000cd5a8:     	ldrsb	w28, [x25, x28]
1000cd5ac:     	add	w8, w8, w3
1000cd5b0:     	add	w8, w8, w27
1000cd5b4:     	add	w8, w8, w28
1000cd5b8:     	ldr	x3, [sp, #64]
1000cd5bc:     	ldrsb	w3, [x26, x3]
1000cd5c0:     	add	w8, w8, w3
1000cd5c4:     	scvtf	s5, w8
1000cd5c8:     	ldp	x3, x8, [sp, #48]
1000cd5cc:     	ldrsb	w8, [x19, x8]
1000cd5d0:     	ldrsb	w3, [x20, x3]
1000cd5d4:     	ldr	x27, [sp, #40]
1000cd5d8:     	ldrsb	w27, [x21, x27]
1000cd5dc:     	add	w8, w8, w3
1000cd5e0:     	ldr	x3, [sp, #32]
1000cd5e4:     	ldrsb	w3, [x23, x3]
1000cd5e8:     	add	w8, w8, w27
1000cd5ec:     	ldrsb	w27, [x22, x10]
1000cd5f0:     	add	w8, w8, w3
1000cd5f4:     	ldrsb	w3, [x24, x13]
1000cd5f8:     	add	w8, w8, w27
1000cd5fc:     	ldrsb	w27, [x25, x9]
1000cd600:     	add	w8, w8, w3
1000cd604:     	ldrsb	w3, [x26, x14]
1000cd608:     	add	w8, w8, w27
1000cd60c:     	add	w8, w8, w3
1000cd610:     	scvtf	s6, w8
1000cd614:     	ldrsb	w8, [x19, x15]
1000cd618:     	ldrsb	w3, [x20, x16]
1000cd61c:     	ldrsb	w19, [x21, x17]
1000cd620:     	add	w8, w8, w3
1000cd624:     	add	w8, w8, w19
1000cd628:     	ldrsb	w3, [x23, x2]
1000cd62c:     	ldrsb	w19, [x22, x4]
1000cd630:     	add	w8, w8, w3
1000cd634:     	add	w8, w8, w19
1000cd638:     	ldrsb	w3, [x24, x5]
1000cd63c:     	ldrsb	w19, [x25, x6]
1000cd640:     	add	w8, w8, w3
1000cd644:     	add	w8, w8, w19
1000cd648:     	mov	x19, x1
1000cd64c:     	ldrsb	w3, [x26, x7]
1000cd650:     	add	w8, w8, w3
1000cd654:     	add	x3, sp, #448
1000cd658:     	scvtf	s7, w8
1000cd65c:     	add	x8, x1, x12
1000cd660:     	ldur	s16, [x8, #-192]
1000cd664:     	fadd	s1, s16, s1
1000cd668:     	stur	s1, [x8, #-192]
1000cd66c:     	ldur	s1, [x8, #-128]
1000cd670:     	fadd	s1, s1, s2
1000cd674:     	stur	s1, [x8, #-128]
1000cd678:     	ldur	s1, [x8, #-64]
1000cd67c:     	fadd	s1, s1, s3
1000cd680:     	stur	s1, [x8, #-64]
1000cd684:     	ldr	s1, [x8]
1000cd688:     	fadd	s1, s1, s4
1000cd68c:     	str	s1, [x8]
1000cd690:     	ldr	s1, [x8, #64]
1000cd694:     	fadd	s1, s1, s5
1000cd698:     	str	s1, [x8, #64]
1000cd69c:     	ldr	s1, [x8, #128]
1000cd6a0:     	fadd	s1, s1, s6
1000cd6a4:     	str	s1, [x8, #128]
1000cd6a8:     	ldr	s1, [x8, #192]
1000cd6ac:     	fadd	s1, s1, s7
1000cd6b0:     	ldr	s2, [x3, x12]
1000cd6b4:     	str	s1, [x8, #192]
1000cd6b8:     	fadd	s0, s2, s0
1000cd6bc:     	str	s0, [x3, x12]
1000cd6c0:     	add	x12, x12, #4
1000cd6c4:     	cmp	x12, #64
1000cd6c8:     	b.ne	0x1000cd350 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000cd6cc:     	add	x0, x0, #64
1000cd6d0:     	ldp	x8, x1, [sp, #16]
1000cd6d4:     	add	x1, x1, #32
1000cd6d8:     	cmp	x1, x8
1000cd6dc:     	b.ne	0x1000cd1ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000cd6e0:     	add	x1, sp, #448
1000cd6e4:     	ldr	x0, [sp, #8]
1000cd6e8:     	mov	w2, #512
1000cd6ec:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000cd6f0:     	ldur	x8, [x29, #-96]
1000cd6f4:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x244>
1000cd6f8:     	ldr	x9, [x9, #392]
1000cd6fc:     	ldr	x9, [x9]
1000cd700:     	cmp	x9, x8
1000cd704:     	b.ne	0x1000cd728 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000cd708:     	add	sp, sp, #976
1000cd70c:     	ldp	x29, x30, [sp, #80]
1000cd710:     	ldp	x20, x19, [sp, #64]
1000cd714:     	ldp	x22, x21, [sp, #48]
1000cd718:     	ldp	x24, x23, [sp, #32]
1000cd71c:     	ldp	x26, x25, [sp, #16]
1000cd720:     	ldp	x28, x27, [sp], #96
1000cd724:     	ret
1000cd728:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000ce9a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000ce9a8:     	stp	x28, x27, [sp, #-64]!
1000ce9ac:     	stp	x22, x21, [sp, #16]
1000ce9b0:     	stp	x20, x19, [sp, #32]
1000ce9b4:     	stp	x29, x30, [sp, #48]
1000ce9b8:     	add	x29, sp, #48
1000ce9bc:     	sub	sp, sp, #1040
1000ce9c0:     	mov	x19, x3
1000ce9c4:     	mov	x20, x1
1000ce9c8:     	mov	x21, x0
1000ce9cc:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf4>
1000ce9d0:     	ldr	x8, [x8, #392]
1000ce9d4:     	ldr	x8, [x8]
1000ce9d8:     	stur	x8, [x29, #-56]
1000ce9dc:     	lsl	x8, x2, #3
1000ce9e0:     	and	x22, x8, #0xfffffffffffffff0
1000ce9e4:     	add	x0, sp, #8
1000ce9e8:     	mov	w1, #1024
1000ce9ec:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000ce9f0:     	cbz	x22, 0x1000ceb08 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000ce9f4:     	add	x8, x20, x22
1000ce9f8:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x118>
1000ce9fc:     	add	x9, x9, #1212
1000cea00:     	mov	x10, #0
1000cea04:     	add	x11, sp, #8
1000cea08:     	mov	x12, #0
1000cea0c:     	ldr	w2, [x21, x10, lsl #2]
1000cea10:     	lsl	w13, w2, #4
1000cea14:     	and	x13, x13, #0xf0
1000cea18:     	and	x14, x2, #0xf0
1000cea1c:     	lsr	x15, x2, #4
1000cea20:     	and	x15, x15, #0xf0
1000cea24:     	lsr	x16, x2, #8
1000cea28:     	and	x16, x16, #0xf0
1000cea2c:     	lsr	x17, x2, #12
1000cea30:     	and	x17, x17, #0xf0
1000cea34:     	lsr	x0, x2, #16
1000cea38:     	and	x0, x0, #0xf0
1000cea3c:     	lsr	x1, x2, #20
1000cea40:     	and	x1, x1, #0xf0
1000cea44:     	lsr	x2, x2, #24
1000cea48:     	and	x2, x2, #0xf0
1000cea4c:     	mov	x3, x11
1000cea50:     	ldr	w4, [x20, x12]
1000cea54:     	and	x5, x4, #0xf
1000cea58:     	orr	x5, x13, x5
1000cea5c:     	ldrb	w5, [x9, x5]
1000cea60:     	ubfx	x6, x4, #4, #4
1000cea64:     	orr	x6, x14, x6
1000cea68:     	ldrb	w6, [x9, x6]
1000cea6c:     	ubfx	x7, x4, #8, #4
1000cea70:     	orr	x7, x15, x7
1000cea74:     	ldrb	w7, [x9, x7]
1000cea78:     	add	w5, w5, w6
1000cea7c:     	add	w5, w5, w7
1000cea80:     	ubfx	x6, x4, #12, #4
1000cea84:     	orr	x6, x16, x6
1000cea88:     	ldrb	w6, [x9, x6]
1000cea8c:     	ubfx	x7, x4, #16, #4
1000cea90:     	orr	x7, x17, x7
1000cea94:     	ldrb	w7, [x9, x7]
1000cea98:     	add	w5, w5, w6
1000cea9c:     	add	w5, w5, w7
1000ceaa0:     	ubfx	x6, x4, #20, #4
1000ceaa4:     	orr	x6, x0, x6
1000ceaa8:     	ldrb	w6, [x9, x6]
1000ceaac:     	ubfx	x7, x4, #24, #4
1000ceab0:     	orr	x7, x1, x7
1000ceab4:     	ldrb	w7, [x9, x7]
1000ceab8:     	add	w5, w5, w6
1000ceabc:     	add	w5, w5, w7
1000ceac0:     	orr	x4, x2, x4, lsr #28
1000ceac4:     	ldrb	w4, [x9, x4]
1000ceac8:     	add	w4, w5, w4
1000ceacc:     	scvtf	s0, w4
1000cead0:     	ldr	s1, [x3]
1000cead4:     	fadd	s0, s1, s0
1000cead8:     	str	s0, [x3], #64
1000ceadc:     	add	x12, x12, #4
1000ceae0:     	cmp	x12, #64
1000ceae4:     	b.ne	0x1000cea50 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000ceae8:     	add	x10, x10, #1
1000ceaec:     	add	x11, x11, #4
1000ceaf0:     	cmp	x10, #16
1000ceaf4:     	b.ne	0x1000cea08 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000ceaf8:     	add	x21, x21, #64
1000ceafc:     	add	x20, x20, #64
1000ceb00:     	cmp	x20, x8
1000ceb04:     	b.ne	0x1000cea00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000ceb08:     	add	x1, sp, #8
1000ceb0c:     	mov	x0, x19
1000ceb10:     	mov	w2, #1024
1000ceb14:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000ceb18:     	ldur	x8, [x29, #-56]
1000ceb1c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x244>
1000ceb20:     	ldr	x9, [x9, #392]
1000ceb24:     	ldr	x9, [x9]
1000ceb28:     	cmp	x9, x8
1000ceb2c:     	b.ne	0x1000ceb48 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000ceb30:     	add	sp, sp, #1040
1000ceb34:     	ldp	x29, x30, [sp, #48]
1000ceb38:     	ldp	x20, x19, [sp, #32]
1000ceb3c:     	ldp	x22, x21, [sp, #16]
1000ceb40:     	ldp	x28, x27, [sp], #64
1000ceb44:     	ret
1000ceb48:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000cedc0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cedc0:     	stp	x28, x27, [sp, #-64]!
1000cedc4:     	stp	x22, x21, [sp, #16]
1000cedc8:     	stp	x20, x19, [sp, #32]
1000cedcc:     	stp	x29, x30, [sp, #48]
1000cedd0:     	add	x29, sp, #48
1000cedd4:     	sub	sp, sp, #1040
1000cedd8:     	mov	x19, x3
1000ceddc:     	mov	x20, x1
1000cede0:     	mov	x21, x0
1000cede4:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0xf8>
1000cede8:     	ldr	x8, [x8, #392]
1000cedec:     	ldr	x8, [x8]
1000cedf0:     	stur	x8, [x29, #-56]
1000cedf4:     	lsl	x8, x2, #3
1000cedf8:     	and	x22, x8, #0xfffffffffffffff0
1000cedfc:     	add	x0, sp, #8
1000cee00:     	mov	w1, #1024
1000cee04:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000cee08:     	cbz	x22, 0x1000cef20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000cee0c:     	add	x8, x20, x22
1000cee10:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x11c>
1000cee14:     	add	x9, x9, #1468
1000cee18:     	mov	x10, #0
1000cee1c:     	add	x11, sp, #8
1000cee20:     	mov	x12, #0
1000cee24:     	ldr	w2, [x21, x10, lsl #2]
1000cee28:     	lsl	w13, w2, #4
1000cee2c:     	and	x13, x13, #0xf0
1000cee30:     	and	x14, x2, #0xf0
1000cee34:     	lsr	x15, x2, #4
1000cee38:     	and	x15, x15, #0xf0
1000cee3c:     	lsr	x16, x2, #8
1000cee40:     	and	x16, x16, #0xf0
1000cee44:     	lsr	x17, x2, #12
1000cee48:     	and	x17, x17, #0xf0
1000cee4c:     	lsr	x0, x2, #16
1000cee50:     	and	x0, x0, #0xf0
1000cee54:     	lsr	x1, x2, #20
1000cee58:     	and	x1, x1, #0xf0
1000cee5c:     	lsr	x2, x2, #24
1000cee60:     	and	x2, x2, #0xf0
1000cee64:     	mov	x3, x11
1000cee68:     	ldr	w4, [x20, x12]
1000cee6c:     	and	x5, x4, #0xf
1000cee70:     	orr	x5, x13, x5
1000cee74:     	ldrsb	w5, [x9, x5]
1000cee78:     	ubfx	x6, x4, #4, #4
1000cee7c:     	orr	x6, x14, x6
1000cee80:     	ldrsb	w6, [x9, x6]
1000cee84:     	ubfx	x7, x4, #8, #4
1000cee88:     	orr	x7, x15, x7
1000cee8c:     	ldrsb	w7, [x9, x7]
1000cee90:     	add	w5, w5, w6
1000cee94:     	add	w5, w5, w7
1000cee98:     	ubfx	x6, x4, #12, #4
1000cee9c:     	orr	x6, x16, x6
1000ceea0:     	ldrsb	w6, [x9, x6]
1000ceea4:     	ubfx	x7, x4, #16, #4
1000ceea8:     	orr	x7, x17, x7
1000ceeac:     	ldrsb	w7, [x9, x7]
1000ceeb0:     	add	w5, w5, w6
1000ceeb4:     	add	w5, w5, w7
1000ceeb8:     	ubfx	x6, x4, #20, #4
1000ceebc:     	orr	x6, x0, x6
1000ceec0:     	ldrsb	w6, [x9, x6]
1000ceec4:     	ubfx	x7, x4, #24, #4
1000ceec8:     	orr	x7, x1, x7
1000ceecc:     	ldrsb	w7, [x9, x7]
1000ceed0:     	add	w5, w5, w6
1000ceed4:     	add	w5, w5, w7
1000ceed8:     	orr	x4, x2, x4, lsr #28
1000ceedc:     	ldrsb	w4, [x9, x4]
1000ceee0:     	add	w4, w5, w4
1000ceee4:     	scvtf	s0, w4
1000ceee8:     	ldr	s1, [x3]
1000ceeec:     	fadd	s0, s1, s0
1000ceef0:     	str	s0, [x3], #64
1000ceef4:     	add	x12, x12, #4
1000ceef8:     	cmp	x12, #64
1000ceefc:     	b.ne	0x1000cee68 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000cef00:     	add	x10, x10, #1
1000cef04:     	add	x11, x11, #4
1000cef08:     	cmp	x10, #16
1000cef0c:     	b.ne	0x1000cee20 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000cef10:     	add	x21, x21, #64
1000cef14:     	add	x20, x20, #64
1000cef18:     	cmp	x20, x8
1000cef1c:     	b.ne	0x1000cee18 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000cef20:     	add	x1, sp, #8
1000cef24:     	mov	x0, x19
1000cef28:     	mov	w2, #1024
1000cef2c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000cef30:     	ldur	x8, [x29, #-56]
1000cef34:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 1ul, false>(char const*)+0x248>
1000cef38:     	ldr	x9, [x9, #392]
1000cef3c:     	ldr	x9, [x9]
1000cef40:     	cmp	x9, x8
1000cef44:     	b.ne	0x1000cef60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000cef48:     	add	sp, sp, #1040
1000cef4c:     	ldp	x29, x30, [sp, #48]
1000cef50:     	ldp	x20, x19, [sp, #32]
1000cef54:     	ldp	x22, x21, [sp, #16]
1000cef58:     	ldp	x28, x27, [sp], #64
1000cef5c:     	ret
1000cef60:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d01ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000d01ac:     	stp	x22, x21, [sp, #-32]!
1000d01b0:     	stp	x20, x19, [sp, #16]
1000d01b4:     	movi.2d	v0, #0000000000000000
1000d01b8:     	stp	q0, q0, [x3, #96]
1000d01bc:     	stp	q0, q0, [x3, #64]
1000d01c0:     	stp	q0, q0, [x3, #32]
1000d01c4:     	stp	q0, q0, [x3]
1000d01c8:     	cmp	x2, #8
1000d01cc:     	b.hs	0x1000d01d8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000d01d0:     	mov	x8, #0
1000d01d4:     	b	0x1000d02e8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000d01d8:     	mov	x8, #0
1000d01dc:     	mov	w12, #8
1000d01e0:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x94>
1000d01e4:     	add	x9, x9, #1724
1000d01e8:     	mov	x10, x0
1000d01ec:     	mov	x11, #0
1000d01f0:     	lsr	x8, x8, #1
1000d01f4:     	mul	x8, x8, x4
1000d01f8:     	ldr	w6, [x1, x8]
1000d01fc:     	mov	x8, x12
1000d0200:     	lsl	w12, w6, #4
1000d0204:     	and	x12, x12, #0xf0
1000d0208:     	add	x12, x9, x12
1000d020c:     	and	x13, x6, #0xf0
1000d0210:     	add	x13, x9, x13
1000d0214:     	lsr	x14, x6, #4
1000d0218:     	and	x14, x14, #0xf0
1000d021c:     	add	x14, x9, x14
1000d0220:     	lsr	x15, x6, #8
1000d0224:     	and	x15, x15, #0xf0
1000d0228:     	add	x15, x9, x15
1000d022c:     	lsr	x16, x6, #12
1000d0230:     	and	x16, x16, #0xf0
1000d0234:     	add	x16, x9, x16
1000d0238:     	lsr	x17, x6, #16
1000d023c:     	and	x17, x17, #0xf0
1000d0240:     	add	x17, x9, x17
1000d0244:     	lsr	x5, x6, #20
1000d0248:     	and	x5, x5, #0xf0
1000d024c:     	add	x5, x9, x5
1000d0250:     	lsr	x6, x6, #24
1000d0254:     	and	x6, x6, #0xf0
1000d0258:     	add	x6, x9, x6
1000d025c:     	ldr	w7, [x10, x11]
1000d0260:     	and	x19, x7, #0xf
1000d0264:     	ldrb	w19, [x12, x19]
1000d0268:     	ubfx	x20, x7, #4, #4
1000d026c:     	ldrb	w20, [x13, x20]
1000d0270:     	ubfx	x21, x7, #8, #4
1000d0274:     	ldrb	w21, [x14, x21]
1000d0278:     	add	w19, w19, w20
1000d027c:     	add	w19, w19, w21
1000d0280:     	ubfx	x20, x7, #12, #4
1000d0284:     	ldrb	w20, [x15, x20]
1000d0288:     	ubfx	x21, x7, #16, #4
1000d028c:     	ldrb	w21, [x16, x21]
1000d0290:     	add	w19, w19, w20
1000d0294:     	add	w19, w19, w21
1000d0298:     	ubfx	x20, x7, #20, #4
1000d029c:     	ldrb	w20, [x17, x20]
1000d02a0:     	ubfx	x21, x7, #24, #4
1000d02a4:     	ldrb	w21, [x5, x21]
1000d02a8:     	lsr	x7, x7, #28
1000d02ac:     	ldrb	w7, [x6, x7]
1000d02b0:     	add	w19, w19, w20
1000d02b4:     	add	w19, w19, w21
1000d02b8:     	add	w7, w19, w7
1000d02bc:     	scvtf	s0, w7
1000d02c0:     	ldr	s1, [x3, x11]
1000d02c4:     	fadd	s0, s1, s0
1000d02c8:     	str	s0, [x3, x11]
1000d02cc:     	add	x11, x11, #4
1000d02d0:     	cmp	x11, #128
1000d02d4:     	b.ne	0x1000d025c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000d02d8:     	add	x12, x8, #8
1000d02dc:     	add	x10, x10, #128
1000d02e0:     	cmp	x12, x2
1000d02e4:     	b.ls	0x1000d01ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000d02e8:     	cmp	x8, x2
1000d02ec:     	b.hs	0x1000d037c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1d0>
1000d02f0:     	lsl	x9, x4, #2
1000d02f4:     	mov	w10, #-16
1000d02f8:     	mov	x11, #0
1000d02fc:     	lsr	x13, x8, #3
1000d0300:     	lsl	x12, x13, #7
1000d0304:     	mul	x14, x9, x13
1000d0308:     	ubfx	x13, x8, #1, #2
1000d030c:     	orr	x14, x14, x13
1000d0310:     	ldrb	w15, [x1, x14]
1000d0314:     	ubfiz	w14, w8, #2, #1
1000d0318:     	lsr	w15, w15, w14
1000d031c:     	and	w16, w15, #0xf
1000d0320:     	cmp	w16, #8
1000d0324:     	csel	w16, wzr, w10, lo
1000d0328:     	bfxil	w16, w15, #0, #4
1000d032c:     	scvtf	s0, w16
1000d0330:     	add	x15, x12, x11
1000d0334:     	orr	x15, x15, x13
1000d0338:     	ldrb	w15, [x0, x15]
1000d033c:     	lsr	w15, w15, w14
1000d0340:     	and	w16, w15, #0xf
1000d0344:     	cmp	w16, #8
1000d0348:     	csel	w16, wzr, w10, lo
1000d034c:     	bfxil	w16, w15, #0, #4
1000d0350:     	scvtf	s1, w16
1000d0354:     	ldr	s2, [x3, x11]
1000d0358:     	fsub	s1, s1, s0
1000d035c:     	fmadd	s1, s1, s1, s2
1000d0360:     	str	s1, [x3, x11]
1000d0364:     	add	x11, x11, #4
1000d0368:     	cmp	x11, #128
1000d036c:     	b.ne	0x1000d0330 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000d0370:     	add	x8, x8, #1
1000d0374:     	cmp	x8, x2
1000d0378:     	b.ne	0x1000d02f8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000d037c:     	ldp	x20, x19, [sp, #16]
1000d0380:     	ldp	x22, x21, [sp], #32
1000d0384:     	ret

00000001000d03b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)>:
1000d03b4:     	stp	x22, x21, [sp, #-32]!
1000d03b8:     	stp	x20, x19, [sp, #16]
1000d03bc:     	movi.2d	v0, #0000000000000000
1000d03c0:     	stp	q0, q0, [x3, #96]
1000d03c4:     	stp	q0, q0, [x3, #64]
1000d03c8:     	stp	q0, q0, [x3, #32]
1000d03cc:     	stp	q0, q0, [x3]
1000d03d0:     	cmp	x2, #8
1000d03d4:     	b.hs	0x1000d03e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x2c>
1000d03d8:     	mov	x8, #0
1000d03dc:     	b	0x1000d04f0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x13c>
1000d03e0:     	mov	x8, #0
1000d03e4:     	mov	w12, #8
1000d03e8:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 2ul, false>(char const*)+0xc4>
1000d03ec:     	add	x9, x9, #1980
1000d03f0:     	mov	x10, x0
1000d03f4:     	mov	x11, #0
1000d03f8:     	lsr	x8, x8, #1
1000d03fc:     	mul	x8, x8, x4
1000d0400:     	ldr	w6, [x1, x8]
1000d0404:     	mov	x8, x12
1000d0408:     	lsl	w12, w6, #4
1000d040c:     	and	x12, x12, #0xf0
1000d0410:     	add	x12, x9, x12
1000d0414:     	and	x13, x6, #0xf0
1000d0418:     	add	x13, x9, x13
1000d041c:     	lsr	x14, x6, #4
1000d0420:     	and	x14, x14, #0xf0
1000d0424:     	add	x14, x9, x14
1000d0428:     	lsr	x15, x6, #8
1000d042c:     	and	x15, x15, #0xf0
1000d0430:     	add	x15, x9, x15
1000d0434:     	lsr	x16, x6, #12
1000d0438:     	and	x16, x16, #0xf0
1000d043c:     	add	x16, x9, x16
1000d0440:     	lsr	x17, x6, #16
1000d0444:     	and	x17, x17, #0xf0
1000d0448:     	add	x17, x9, x17
1000d044c:     	lsr	x5, x6, #20
1000d0450:     	and	x5, x5, #0xf0
1000d0454:     	add	x5, x9, x5
1000d0458:     	lsr	x6, x6, #24
1000d045c:     	and	x6, x6, #0xf0
1000d0460:     	add	x6, x9, x6
1000d0464:     	ldr	w7, [x10, x11]
1000d0468:     	and	x19, x7, #0xf
1000d046c:     	ldrsb	w19, [x12, x19]
1000d0470:     	ubfx	x20, x7, #4, #4
1000d0474:     	ldrsb	w20, [x13, x20]
1000d0478:     	ubfx	x21, x7, #8, #4
1000d047c:     	ldrsb	w21, [x14, x21]
1000d0480:     	add	w19, w19, w20
1000d0484:     	add	w19, w19, w21
1000d0488:     	ubfx	x20, x7, #12, #4
1000d048c:     	ldrsb	w20, [x15, x20]
1000d0490:     	ubfx	x21, x7, #16, #4
1000d0494:     	ldrsb	w21, [x16, x21]
1000d0498:     	add	w19, w19, w20
1000d049c:     	add	w19, w19, w21
1000d04a0:     	ubfx	x20, x7, #20, #4
1000d04a4:     	ldrsb	w20, [x17, x20]
1000d04a8:     	ubfx	x21, x7, #24, #4
1000d04ac:     	ldrsb	w21, [x5, x21]
1000d04b0:     	lsr	x7, x7, #28
1000d04b4:     	ldrsb	w7, [x6, x7]
1000d04b8:     	add	w19, w19, w20
1000d04bc:     	add	w19, w19, w21
1000d04c0:     	add	w7, w19, w7
1000d04c4:     	scvtf	s0, w7
1000d04c8:     	ldr	s1, [x3, x11]
1000d04cc:     	fadd	s0, s1, s0
1000d04d0:     	str	s0, [x3, x11]
1000d04d4:     	add	x11, x11, #4
1000d04d8:     	cmp	x11, #128
1000d04dc:     	b.ne	0x1000d0464 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0xb0>
1000d04e0:     	add	x12, x8, #8
1000d04e4:     	add	x10, x10, #128
1000d04e8:     	cmp	x12, x2
1000d04ec:     	b.ls	0x1000d03f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x40>
1000d04f0:     	cmp	x8, x2
1000d04f4:     	b.hs	0x1000d0580 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x1cc>
1000d04f8:     	lsl	x9, x4, #2
1000d04fc:     	mov	w10, #-16
1000d0500:     	mov	x11, #0
1000d0504:     	lsr	x13, x8, #3
1000d0508:     	lsl	x12, x13, #7
1000d050c:     	mul	x14, x9, x13
1000d0510:     	ubfx	x13, x8, #1, #2
1000d0514:     	orr	x14, x14, x13
1000d0518:     	ldrb	w15, [x1, x14]
1000d051c:     	ubfiz	w14, w8, #2, #1
1000d0520:     	lsr	w15, w15, w14
1000d0524:     	and	w16, w15, #0xf
1000d0528:     	cmp	w16, #8
1000d052c:     	csel	w16, wzr, w10, lo
1000d0530:     	bfxil	w16, w15, #0, #4
1000d0534:     	scvtf	s0, w16
1000d0538:     	add	x15, x12, x11
1000d053c:     	orr	x15, x15, x13
1000d0540:     	ldrb	w15, [x0, x15]
1000d0544:     	lsr	w15, w15, w14
1000d0548:     	and	w16, w15, #0xf
1000d054c:     	cmp	w16, #8
1000d0550:     	csel	w16, wzr, w10, lo
1000d0554:     	bfxil	w16, w15, #0, #4
1000d0558:     	scvtf	s1, w16
1000d055c:     	ldr	s2, [x3, x11]
1000d0560:     	fmsub	s1, s1, s0, s2
1000d0564:     	str	s1, [x3, x11]
1000d0568:     	add	x11, x11, #4
1000d056c:     	cmp	x11, #128
1000d0570:     	b.ne	0x1000d0538 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x184>
1000d0574:     	add	x8, x8, #1
1000d0578:     	cmp	x8, x2
1000d057c:     	b.ne	0x1000d0500 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputeSingleColumn<false>(unsigned char const*, unsigned char const*, unsigned long, float*, unsigned long, float*, float*)+0x14c>
1000d0580:     	ldp	x20, x19, [sp, #16]
1000d0584:     	ldp	x22, x21, [sp], #32
1000d0588:     	ret

00000001000d1b34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d1b34:     	sub	sp, sp, #400
1000d1b38:     	stp	x28, x27, [sp, #304]
1000d1b3c:     	stp	x26, x25, [sp, #320]
1000d1b40:     	stp	x24, x23, [sp, #336]
1000d1b44:     	stp	x22, x21, [sp, #352]
1000d1b48:     	stp	x20, x19, [sp, #368]
1000d1b4c:     	stp	x29, x30, [sp, #384]
1000d1b50:     	add	x29, sp, #384
1000d1b54:     	str	x3, [sp]
1000d1b58:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x30>
1000d1b5c:     	ldr	x8, [x8, #392]
1000d1b60:     	ldr	x8, [x8]
1000d1b64:     	stur	x8, [x29, #-96]
1000d1b68:     	movi.2d	v0, #0000000000000000
1000d1b6c:     	stp	q0, q0, [sp, #256]
1000d1b70:     	stp	q0, q0, [sp, #224]
1000d1b74:     	stp	q0, q0, [sp, #192]
1000d1b78:     	stp	q0, q0, [sp, #160]
1000d1b7c:     	stp	q0, q0, [sp, #128]
1000d1b80:     	stp	q0, q0, [sp, #96]
1000d1b84:     	stp	q0, q0, [sp, #64]
1000d1b88:     	stp	q0, q0, [sp, #32]
1000d1b8c:     	ands	x8, x2, #0xfffffffffffffffe
1000d1b90:     	b.eq	0x1000d1d14 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d1b94:     	add	x8, x1, x8
1000d1b98:     	str	x8, [sp, #8]
1000d1b9c:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 32ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d1ba0:     	add	x9, x9, #1724
1000d1ba4:     	mov	x11, #0
1000d1ba8:     	ldp	w4, w23, [x1]
1000d1bac:     	ubfx	x8, x4, #8, #4
1000d1bb0:     	stp	x1, x8, [sp, #16]
1000d1bb4:     	ubfx	x13, x4, #16, #4
1000d1bb8:     	and	x14, x4, #0xf
1000d1bbc:     	ubfx	x15, x4, #24, #4
1000d1bc0:     	ubfx	x16, x4, #4, #4
1000d1bc4:     	ubfx	x17, x4, #12, #4
1000d1bc8:     	ubfx	x2, x4, #20, #4
1000d1bcc:     	lsr	x4, x4, #28
1000d1bd0:     	and	x5, x23, #0xf
1000d1bd4:     	ubfx	x6, x23, #8, #4
1000d1bd8:     	ubfx	x7, x23, #16, #4
1000d1bdc:     	ubfx	x19, x23, #24, #4
1000d1be0:     	ubfx	x20, x23, #4, #4
1000d1be4:     	ubfx	x21, x23, #12, #4
1000d1be8:     	ubfx	x22, x23, #20, #4
1000d1bec:     	lsr	x23, x23, #28
1000d1bf0:     	ldr	w24, [x0, x11]
1000d1bf4:     	lsl	w25, w24, #4
1000d1bf8:     	and	x25, x25, #0xf0
1000d1bfc:     	add	x25, x9, x25
1000d1c00:     	and	x26, x24, #0xf0
1000d1c04:     	add	x26, x9, x26
1000d1c08:     	lsr	x27, x24, #4
1000d1c0c:     	and	x27, x27, #0xf0
1000d1c10:     	add	x27, x9, x27
1000d1c14:     	lsr	x28, x24, #8
1000d1c18:     	and	x28, x28, #0xf0
1000d1c1c:     	add	x28, x9, x28
1000d1c20:     	lsr	x30, x24, #12
1000d1c24:     	and	x30, x30, #0xf0
1000d1c28:     	add	x30, x9, x30
1000d1c2c:     	lsr	x8, x24, #16
1000d1c30:     	and	x8, x8, #0xf0
1000d1c34:     	add	x8, x9, x8
1000d1c38:     	lsr	x3, x24, #20
1000d1c3c:     	and	x3, x3, #0xf0
1000d1c40:     	add	x3, x9, x3
1000d1c44:     	lsr	x24, x24, #24
1000d1c48:     	and	x24, x24, #0xf0
1000d1c4c:     	ldrb	w10, [x25, x14]
1000d1c50:     	ldr	x12, [sp, #24]
1000d1c54:     	ldrb	w1, [x27, x12]
1000d1c58:     	ldrb	w12, [x30, x13]
1000d1c5c:     	add	w10, w10, w1
1000d1c60:     	add	w10, w10, w12
1000d1c64:     	ldrb	w12, [x3, x15]
1000d1c68:     	ldrb	w1, [x26, x16]
1000d1c6c:     	add	w10, w10, w12
1000d1c70:     	add	w10, w10, w1
1000d1c74:     	ldrb	w12, [x28, x17]
1000d1c78:     	ldrb	w1, [x8, x2]
1000d1c7c:     	add	x24, x9, x24
1000d1c80:     	add	w10, w10, w12
1000d1c84:     	add	w10, w10, w1
1000d1c88:     	ldrb	w12, [x24, x4]
1000d1c8c:     	add	w10, w10, w12
1000d1c90:     	scvtf	s0, w10
1000d1c94:     	add	x10, sp, #32
1000d1c98:     	add	x10, x10, x11
1000d1c9c:     	ldr	s1, [x10]
1000d1ca0:     	ldrb	w12, [x25, x5]
1000d1ca4:     	fadd	s0, s1, s0
1000d1ca8:     	ldrb	w1, [x27, x6]
1000d1cac:     	ldrb	w25, [x30, x7]
1000d1cb0:     	add	w12, w12, w1
1000d1cb4:     	add	w12, w12, w25
1000d1cb8:     	ldrb	w1, [x3, x19]
1000d1cbc:     	ldrb	w3, [x26, x20]
1000d1cc0:     	add	w12, w12, w1
1000d1cc4:     	add	w12, w12, w3
1000d1cc8:     	ldrb	w1, [x28, x21]
1000d1ccc:     	ldrb	w8, [x8, x22]
1000d1cd0:     	add	w12, w12, w1
1000d1cd4:     	add	w8, w12, w8
1000d1cd8:     	ldrb	w12, [x24, x23]
1000d1cdc:     	add	w8, w8, w12
1000d1ce0:     	scvtf	s1, w8
1000d1ce4:     	str	s0, [x10]
1000d1ce8:     	ldr	s0, [x10, #128]
1000d1cec:     	fadd	s0, s0, s1
1000d1cf0:     	str	s0, [x10, #128]
1000d1cf4:     	add	x11, x11, #4
1000d1cf8:     	cmp	x11, #128
1000d1cfc:     	b.ne	0x1000d1bf0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d1d00:     	add	x0, x0, #128
1000d1d04:     	ldp	x8, x1, [sp, #8]
1000d1d08:     	add	x1, x1, #8
1000d1d0c:     	cmp	x1, x8
1000d1d10:     	b.ne	0x1000d1ba4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d1d14:     	ldp	q0, q1, [sp, #224]
1000d1d18:     	ldr	x8, [sp]
1000d1d1c:     	stp	q0, q1, [x8, #192]
1000d1d20:     	ldp	q0, q1, [sp, #256]
1000d1d24:     	stp	q0, q1, [x8, #224]
1000d1d28:     	ldp	q0, q1, [sp, #160]
1000d1d2c:     	stp	q0, q1, [x8, #128]
1000d1d30:     	ldp	q0, q1, [sp, #192]
1000d1d34:     	stp	q0, q1, [x8, #160]
1000d1d38:     	ldp	q0, q1, [sp, #96]
1000d1d3c:     	stp	q0, q1, [x8, #64]
1000d1d40:     	ldp	q0, q1, [sp, #128]
1000d1d44:     	stp	q0, q1, [x8, #96]
1000d1d48:     	ldp	q0, q1, [sp, #32]
1000d1d4c:     	stp	q0, q1, [x8]
1000d1d50:     	ldp	q0, q1, [sp, #64]
1000d1d54:     	stp	q0, q1, [x8, #32]
1000d1d58:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x164>
1000d1d5c:     	ldr	x8, [x8, #392]
1000d1d60:     	ldr	x8, [x8]
1000d1d64:     	ldur	x9, [x29, #-96]
1000d1d68:     	cmp	x8, x9
1000d1d6c:     	b.ne	0x1000d1d90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d1d70:     	ldp	x29, x30, [sp, #384]
1000d1d74:     	ldp	x20, x19, [sp, #368]
1000d1d78:     	ldp	x22, x21, [sp, #352]
1000d1d7c:     	ldp	x24, x23, [sp, #336]
1000d1d80:     	ldp	x26, x25, [sp, #320]
1000d1d84:     	ldp	x28, x27, [sp, #304]
1000d1d88:     	add	sp, sp, #400
1000d1d8c:     	ret
1000d1d90:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d1e60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d1e60:     	sub	sp, sp, #400
1000d1e64:     	stp	x28, x27, [sp, #304]
1000d1e68:     	stp	x26, x25, [sp, #320]
1000d1e6c:     	stp	x24, x23, [sp, #336]
1000d1e70:     	stp	x22, x21, [sp, #352]
1000d1e74:     	stp	x20, x19, [sp, #368]
1000d1e78:     	stp	x29, x30, [sp, #384]
1000d1e7c:     	add	x29, sp, #384
1000d1e80:     	str	x3, [sp]
1000d1e84:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x30>
1000d1e88:     	ldr	x8, [x8, #392]
1000d1e8c:     	ldr	x8, [x8]
1000d1e90:     	stur	x8, [x29, #-96]
1000d1e94:     	movi.2d	v0, #0000000000000000
1000d1e98:     	stp	q0, q0, [sp, #256]
1000d1e9c:     	stp	q0, q0, [sp, #224]
1000d1ea0:     	stp	q0, q0, [sp, #192]
1000d1ea4:     	stp	q0, q0, [sp, #160]
1000d1ea8:     	stp	q0, q0, [sp, #128]
1000d1eac:     	stp	q0, q0, [sp, #96]
1000d1eb0:     	stp	q0, q0, [sp, #64]
1000d1eb4:     	stp	q0, q0, [sp, #32]
1000d1eb8:     	ands	x8, x2, #0xfffffffffffffffe
1000d1ebc:     	b.eq	0x1000d2040 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1e0>
1000d1ec0:     	add	x8, x1, x8
1000d1ec4:     	str	x8, [sp, #8]
1000d1ec8:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x6c>
1000d1ecc:     	add	x9, x9, #1980
1000d1ed0:     	mov	x11, #0
1000d1ed4:     	ldp	w4, w23, [x1]
1000d1ed8:     	ubfx	x8, x4, #8, #4
1000d1edc:     	stp	x1, x8, [sp, #16]
1000d1ee0:     	ubfx	x13, x4, #16, #4
1000d1ee4:     	and	x14, x4, #0xf
1000d1ee8:     	ubfx	x15, x4, #24, #4
1000d1eec:     	ubfx	x16, x4, #4, #4
1000d1ef0:     	ubfx	x17, x4, #12, #4
1000d1ef4:     	ubfx	x2, x4, #20, #4
1000d1ef8:     	lsr	x4, x4, #28
1000d1efc:     	and	x5, x23, #0xf
1000d1f00:     	ubfx	x6, x23, #8, #4
1000d1f04:     	ubfx	x7, x23, #16, #4
1000d1f08:     	ubfx	x19, x23, #24, #4
1000d1f0c:     	ubfx	x20, x23, #4, #4
1000d1f10:     	ubfx	x21, x23, #12, #4
1000d1f14:     	ubfx	x22, x23, #20, #4
1000d1f18:     	lsr	x23, x23, #28
1000d1f1c:     	ldr	w24, [x0, x11]
1000d1f20:     	lsl	w25, w24, #4
1000d1f24:     	and	x25, x25, #0xf0
1000d1f28:     	add	x25, x9, x25
1000d1f2c:     	and	x26, x24, #0xf0
1000d1f30:     	add	x26, x9, x26
1000d1f34:     	lsr	x27, x24, #4
1000d1f38:     	and	x27, x27, #0xf0
1000d1f3c:     	add	x27, x9, x27
1000d1f40:     	lsr	x28, x24, #8
1000d1f44:     	and	x28, x28, #0xf0
1000d1f48:     	add	x28, x9, x28
1000d1f4c:     	lsr	x30, x24, #12
1000d1f50:     	and	x30, x30, #0xf0
1000d1f54:     	add	x30, x9, x30
1000d1f58:     	lsr	x8, x24, #16
1000d1f5c:     	and	x8, x8, #0xf0
1000d1f60:     	add	x8, x9, x8
1000d1f64:     	lsr	x3, x24, #20
1000d1f68:     	and	x3, x3, #0xf0
1000d1f6c:     	add	x3, x9, x3
1000d1f70:     	lsr	x24, x24, #24
1000d1f74:     	and	x24, x24, #0xf0
1000d1f78:     	ldrsb	w10, [x25, x14]
1000d1f7c:     	ldr	x12, [sp, #24]
1000d1f80:     	ldrsb	w1, [x27, x12]
1000d1f84:     	ldrsb	w12, [x30, x13]
1000d1f88:     	add	w10, w10, w1
1000d1f8c:     	add	w10, w10, w12
1000d1f90:     	ldrsb	w12, [x3, x15]
1000d1f94:     	ldrsb	w1, [x26, x16]
1000d1f98:     	add	w10, w10, w12
1000d1f9c:     	add	w10, w10, w1
1000d1fa0:     	ldrsb	w12, [x28, x17]
1000d1fa4:     	ldrsb	w1, [x8, x2]
1000d1fa8:     	add	x24, x9, x24
1000d1fac:     	add	w10, w10, w12
1000d1fb0:     	add	w10, w10, w1
1000d1fb4:     	ldrsb	w12, [x24, x4]
1000d1fb8:     	add	w10, w10, w12
1000d1fbc:     	scvtf	s0, w10
1000d1fc0:     	add	x10, sp, #32
1000d1fc4:     	add	x10, x10, x11
1000d1fc8:     	ldr	s1, [x10]
1000d1fcc:     	ldrsb	w12, [x25, x5]
1000d1fd0:     	fadd	s0, s1, s0
1000d1fd4:     	ldrsb	w1, [x27, x6]
1000d1fd8:     	ldrsb	w25, [x30, x7]
1000d1fdc:     	add	w12, w12, w1
1000d1fe0:     	add	w12, w12, w25
1000d1fe4:     	ldrsb	w1, [x3, x19]
1000d1fe8:     	ldrsb	w3, [x26, x20]
1000d1fec:     	add	w12, w12, w1
1000d1ff0:     	add	w12, w12, w3
1000d1ff4:     	ldrsb	w1, [x28, x21]
1000d1ff8:     	ldrsb	w8, [x8, x22]
1000d1ffc:     	add	w12, w12, w1
1000d2000:     	add	w8, w12, w8
1000d2004:     	ldrsb	w12, [x24, x23]
1000d2008:     	add	w8, w8, w12
1000d200c:     	scvtf	s1, w8
1000d2010:     	str	s0, [x10]
1000d2014:     	ldr	s0, [x10, #128]
1000d2018:     	fadd	s0, s0, s1
1000d201c:     	str	s0, [x10, #128]
1000d2020:     	add	x11, x11, #4
1000d2024:     	cmp	x11, #128
1000d2028:     	b.ne	0x1000d1f1c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d202c:     	add	x0, x0, #128
1000d2030:     	ldp	x8, x1, [sp, #8]
1000d2034:     	add	x1, x1, #8
1000d2038:     	cmp	x1, x8
1000d203c:     	b.ne	0x1000d1ed0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x70>
1000d2040:     	ldp	q0, q1, [sp, #224]
1000d2044:     	ldr	x8, [sp]
1000d2048:     	stp	q0, q1, [x8, #192]
1000d204c:     	ldp	q0, q1, [sp, #256]
1000d2050:     	stp	q0, q1, [x8, #224]
1000d2054:     	ldp	q0, q1, [sp, #160]
1000d2058:     	stp	q0, q1, [x8, #128]
1000d205c:     	ldp	q0, q1, [sp, #192]
1000d2060:     	stp	q0, q1, [x8, #160]
1000d2064:     	ldp	q0, q1, [sp, #96]
1000d2068:     	stp	q0, q1, [x8, #64]
1000d206c:     	ldp	q0, q1, [sp, #128]
1000d2070:     	stp	q0, q1, [x8, #96]
1000d2074:     	ldp	q0, q1, [sp, #32]
1000d2078:     	stp	q0, q1, [x8]
1000d207c:     	ldp	q0, q1, [sp, #64]
1000d2080:     	stp	q0, q1, [x8, #32]
1000d2084:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 4ul, false>(char const*)+0x22c>
1000d2088:     	ldr	x8, [x8, #392]
1000d208c:     	ldr	x8, [x8]
1000d2090:     	ldur	x9, [x29, #-96]
1000d2094:     	cmp	x8, x9
1000d2098:     	b.ne	0x1000d20bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x25c>
1000d209c:     	ldp	x29, x30, [sp, #384]
1000d20a0:     	ldp	x20, x19, [sp, #368]
1000d20a4:     	ldp	x22, x21, [sp, #352]
1000d20a8:     	ldp	x24, x23, [sp, #336]
1000d20ac:     	ldp	x26, x25, [sp, #320]
1000d20b0:     	ldp	x28, x27, [sp, #304]
1000d20b4:     	add	sp, sp, #400
1000d20b8:     	ret
1000d20bc:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d392c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d392c:     	stp	x28, x27, [sp, #-96]!
1000d3930:     	stp	x26, x25, [sp, #16]
1000d3934:     	stp	x24, x23, [sp, #32]
1000d3938:     	stp	x22, x21, [sp, #48]
1000d393c:     	stp	x20, x19, [sp, #64]
1000d3940:     	stp	x29, x30, [sp, #80]
1000d3944:     	add	x29, sp, #80
1000d3948:     	sub	sp, sp, #704
1000d394c:     	str	x3, [sp]
1000d3950:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d3954:     	ldr	x8, [x8, #392]
1000d3958:     	ldr	x8, [x8]
1000d395c:     	stur	x8, [x29, #-96]
1000d3960:     	movi.2d	v0, #0000000000000000
1000d3964:     	stp	q0, q0, [sp, #656]
1000d3968:     	lsl	x8, x2, #1
1000d396c:     	stp	q0, q0, [sp, #624]
1000d3970:     	stp	q0, q0, [sp, #592]
1000d3974:     	stp	q0, q0, [sp, #560]
1000d3978:     	stp	q0, q0, [sp, #528]
1000d397c:     	stp	q0, q0, [sp, #496]
1000d3980:     	stp	q0, q0, [sp, #464]
1000d3984:     	stp	q0, q0, [sp, #432]
1000d3988:     	stp	q0, q0, [sp, #400]
1000d398c:     	stp	q0, q0, [sp, #368]
1000d3990:     	stp	q0, q0, [sp, #336]
1000d3994:     	stp	q0, q0, [sp, #304]
1000d3998:     	stp	q0, q0, [sp, #272]
1000d399c:     	stp	q0, q0, [sp, #240]
1000d39a0:     	stp	q0, q0, [sp, #208]
1000d39a4:     	stp	q0, q0, [sp, #176]
1000d39a8:     	ands	x8, x8, #0xfffffffffffffffc
1000d39ac:     	b.eq	0x1000d3c88 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d39b0:     	add	x8, x1, x8
1000d39b4:     	str	x8, [sp, #8]
1000d39b8:     	add	x8, sp, #176
1000d39bc:     	add	x27, x8, #256
1000d39c0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d39c4:     	add	x11, x11, #1724
1000d39c8:     	mov	x12, #0
1000d39cc:     	ldp	w8, w9, [x1]
1000d39d0:     	ubfx	x10, x8, #8, #4
1000d39d4:     	str	x10, [sp, #168]
1000d39d8:     	ubfx	x10, x8, #16, #4
1000d39dc:     	str	x10, [sp, #160]
1000d39e0:     	ubfx	x10, x8, #24, #4
1000d39e4:     	str	x10, [sp, #152]
1000d39e8:     	ldp	w10, w17, [x1, #8]
1000d39ec:     	str	x1, [sp, #16]
1000d39f0:     	and	x14, x8, #0xf
1000d39f4:     	ubfx	x13, x8, #4, #4
1000d39f8:     	stp	x13, x14, [sp, #136]
1000d39fc:     	ubfx	x14, x8, #12, #4
1000d3a00:     	ubfx	x13, x8, #20, #4
1000d3a04:     	stp	x13, x14, [sp, #120]
1000d3a08:     	lsr	x8, x8, #28
1000d3a0c:     	str	x8, [sp, #112]
1000d3a10:     	and	x8, x9, #0xf
1000d3a14:     	str	x8, [sp, #104]
1000d3a18:     	ubfx	x8, x9, #8, #4
1000d3a1c:     	str	x8, [sp, #96]
1000d3a20:     	ubfx	x8, x9, #16, #4
1000d3a24:     	str	x8, [sp, #88]
1000d3a28:     	ubfx	x8, x9, #24, #4
1000d3a2c:     	str	x8, [sp, #80]
1000d3a30:     	ubfx	x8, x9, #4, #4
1000d3a34:     	str	x8, [sp, #72]
1000d3a38:     	ubfx	x8, x9, #12, #4
1000d3a3c:     	str	x8, [sp, #64]
1000d3a40:     	ubfx	x8, x9, #20, #4
1000d3a44:     	str	x8, [sp, #56]
1000d3a48:     	lsr	x8, x9, #28
1000d3a4c:     	str	x8, [sp, #48]
1000d3a50:     	and	x9, x10, #0xf
1000d3a54:     	ubfx	x8, x10, #8, #4
1000d3a58:     	stp	x8, x9, [sp, #32]
1000d3a5c:     	ubfx	x8, x10, #16, #4
1000d3a60:     	str	x8, [sp, #24]
1000d3a64:     	ubfx	x28, x10, #24, #4
1000d3a68:     	ubfx	x30, x10, #4, #4
1000d3a6c:     	ubfx	x3, x10, #12, #4
1000d3a70:     	ubfx	x8, x10, #20, #4
1000d3a74:     	lsr	x9, x10, #28
1000d3a78:     	and	x1, x17, #0xf
1000d3a7c:     	ubfx	x10, x17, #8, #4
1000d3a80:     	ubfx	x13, x17, #16, #4
1000d3a84:     	ubfx	x26, x17, #24, #4
1000d3a88:     	ubfx	x14, x17, #4, #4
1000d3a8c:     	ubfx	x15, x17, #12, #4
1000d3a90:     	ubfx	x16, x17, #20, #4
1000d3a94:     	lsr	x17, x17, #28
1000d3a98:     	ldr	w20, [x0, x12]
1000d3a9c:     	lsl	w2, w20, #4
1000d3aa0:     	and	x2, x2, #0xf0
1000d3aa4:     	add	x5, x11, x2
1000d3aa8:     	and	x2, x20, #0xf0
1000d3aac:     	add	x2, x11, x2
1000d3ab0:     	lsr	x4, x20, #4
1000d3ab4:     	and	x4, x4, #0xf0
1000d3ab8:     	add	x7, x11, x4
1000d3abc:     	lsr	x4, x20, #8
1000d3ac0:     	and	x4, x4, #0xf0
1000d3ac4:     	add	x4, x11, x4
1000d3ac8:     	lsr	x6, x20, #12
1000d3acc:     	and	x6, x6, #0xf0
1000d3ad0:     	add	x19, x11, x6
1000d3ad4:     	lsr	x6, x20, #16
1000d3ad8:     	and	x6, x6, #0xf0
1000d3adc:     	add	x6, x11, x6
1000d3ae0:     	lsr	x21, x20, #20
1000d3ae4:     	and	x21, x21, #0xf0
1000d3ae8:     	add	x21, x11, x21
1000d3aec:     	lsr	x20, x20, #24
1000d3af0:     	and	x20, x20, #0xf0
1000d3af4:     	ldr	x22, [sp, #144]
1000d3af8:     	ldrb	w22, [x5, x22]
1000d3afc:     	add	x20, x11, x20
1000d3b00:     	ldp	x24, x23, [sp, #160]
1000d3b04:     	ldrb	w23, [x7, x23]
1000d3b08:     	ldrb	w24, [x19, x24]
1000d3b0c:     	add	w22, w22, w23
1000d3b10:     	add	w22, w22, w24
1000d3b14:     	ldr	x23, [sp, #152]
1000d3b18:     	ldrb	w23, [x21, x23]
1000d3b1c:     	ldr	x24, [sp, #136]
1000d3b20:     	ldrb	w24, [x2, x24]
1000d3b24:     	add	w22, w22, w23
1000d3b28:     	add	w22, w22, w24
1000d3b2c:     	ldp	x24, x23, [sp, #120]
1000d3b30:     	ldrb	w23, [x4, x23]
1000d3b34:     	ldrb	w24, [x6, x24]
1000d3b38:     	add	w22, w22, w23
1000d3b3c:     	add	w22, w22, w24
1000d3b40:     	ldr	x23, [sp, #112]
1000d3b44:     	ldrb	w23, [x20, x23]
1000d3b48:     	add	w22, w22, w23
1000d3b4c:     	scvtf	s0, w22
1000d3b50:     	ldp	x23, x22, [sp, #96]
1000d3b54:     	ldrb	w22, [x5, x22]
1000d3b58:     	ldrb	w23, [x7, x23]
1000d3b5c:     	ldp	x25, x24, [sp, #80]
1000d3b60:     	ldrb	w24, [x19, x24]
1000d3b64:     	ldrb	w25, [x21, x25]
1000d3b68:     	add	w22, w22, w23
1000d3b6c:     	ldr	x23, [sp, #72]
1000d3b70:     	ldrb	w23, [x2, x23]
1000d3b74:     	add	w22, w22, w24
1000d3b78:     	ldr	x24, [sp, #64]
1000d3b7c:     	ldrb	w24, [x4, x24]
1000d3b80:     	add	w22, w22, w25
1000d3b84:     	ldr	x25, [sp, #56]
1000d3b88:     	ldrb	w25, [x6, x25]
1000d3b8c:     	add	w22, w22, w23
1000d3b90:     	add	w22, w22, w24
1000d3b94:     	add	w22, w22, w25
1000d3b98:     	ldr	x23, [sp, #48]
1000d3b9c:     	ldrb	w23, [x20, x23]
1000d3ba0:     	add	w22, w22, w23
1000d3ba4:     	scvtf	s1, w22
1000d3ba8:     	ldp	x23, x22, [sp, #32]
1000d3bac:     	ldrb	w22, [x5, x22]
1000d3bb0:     	ldrb	w23, [x7, x23]
1000d3bb4:     	ldr	x24, [sp, #24]
1000d3bb8:     	ldrb	w24, [x19, x24]
1000d3bbc:     	add	w22, w22, w23
1000d3bc0:     	ldrb	w23, [x21, x28]
1000d3bc4:     	add	w22, w22, w24
1000d3bc8:     	ldrb	w24, [x2, x30]
1000d3bcc:     	add	w22, w22, w23
1000d3bd0:     	ldrb	w23, [x4, x3]
1000d3bd4:     	add	w22, w22, w24
1000d3bd8:     	ldrb	w24, [x6, x8]
1000d3bdc:     	add	w22, w22, w23
1000d3be0:     	ldrb	w23, [x20, x9]
1000d3be4:     	add	w22, w22, w24
1000d3be8:     	add	w22, w22, w23
1000d3bec:     	scvtf	s2, w22
1000d3bf0:     	ldrb	w5, [x5, x1]
1000d3bf4:     	ldrb	w7, [x7, x10]
1000d3bf8:     	ldrb	w19, [x19, x13]
1000d3bfc:     	add	w5, w5, w7
1000d3c00:     	add	w5, w5, w19
1000d3c04:     	ldrb	w7, [x21, x26]
1000d3c08:     	ldrb	w2, [x2, x14]
1000d3c0c:     	add	w5, w5, w7
1000d3c10:     	add	w2, w5, w2
1000d3c14:     	ldrb	w4, [x4, x15]
1000d3c18:     	ldrb	w5, [x6, x16]
1000d3c1c:     	add	w2, w2, w4
1000d3c20:     	add	w2, w2, w5
1000d3c24:     	ldrb	w4, [x20, x17]
1000d3c28:     	add	w2, w2, w4
1000d3c2c:     	add	x4, sp, #176
1000d3c30:     	scvtf	s3, w2
1000d3c34:     	add	x2, x27, x12
1000d3c38:     	ldur	s4, [x2, #-128]
1000d3c3c:     	fadd	s1, s4, s1
1000d3c40:     	stur	s1, [x2, #-128]
1000d3c44:     	ldr	s1, [x2]
1000d3c48:     	fadd	s1, s1, s2
1000d3c4c:     	str	s1, [x2]
1000d3c50:     	ldr	s1, [x2, #128]
1000d3c54:     	fadd	s1, s1, s3
1000d3c58:     	ldr	s2, [x4, x12]
1000d3c5c:     	str	s1, [x2, #128]
1000d3c60:     	fadd	s0, s2, s0
1000d3c64:     	str	s0, [x4, x12]
1000d3c68:     	add	x12, x12, #4
1000d3c6c:     	cmp	x12, #128
1000d3c70:     	b.ne	0x1000d3a98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d3c74:     	add	x0, x0, #128
1000d3c78:     	ldp	x8, x1, [sp, #8]
1000d3c7c:     	add	x1, x1, #16
1000d3c80:     	cmp	x1, x8
1000d3c84:     	b.ne	0x1000d39c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d3c88:     	add	x1, sp, #176
1000d3c8c:     	ldr	x0, [sp]
1000d3c90:     	mov	w2, #512
1000d3c94:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d3c98:     	ldur	x8, [x29, #-96]
1000d3c9c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xfc>
1000d3ca0:     	ldr	x9, [x9, #392]
1000d3ca4:     	ldr	x9, [x9]
1000d3ca8:     	cmp	x9, x8
1000d3cac:     	b.ne	0x1000d3cd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d3cb0:     	add	sp, sp, #704
1000d3cb4:     	ldp	x29, x30, [sp, #80]
1000d3cb8:     	ldp	x20, x19, [sp, #64]
1000d3cbc:     	ldp	x22, x21, [sp, #48]
1000d3cc0:     	ldp	x24, x23, [sp, #32]
1000d3cc4:     	ldp	x26, x25, [sp, #16]
1000d3cc8:     	ldp	x28, x27, [sp], #96
1000d3ccc:     	ret
1000d3cd0:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d3e04 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d3e04:     	stp	x28, x27, [sp, #-96]!
1000d3e08:     	stp	x26, x25, [sp, #16]
1000d3e0c:     	stp	x24, x23, [sp, #32]
1000d3e10:     	stp	x22, x21, [sp, #48]
1000d3e14:     	stp	x20, x19, [sp, #64]
1000d3e18:     	stp	x29, x30, [sp, #80]
1000d3e1c:     	add	x29, sp, #80
1000d3e20:     	sub	sp, sp, #704
1000d3e24:     	str	x3, [sp]
1000d3e28:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d3e2c:     	ldr	x8, [x8, #392]
1000d3e30:     	ldr	x8, [x8]
1000d3e34:     	stur	x8, [x29, #-96]
1000d3e38:     	movi.2d	v0, #0000000000000000
1000d3e3c:     	stp	q0, q0, [sp, #656]
1000d3e40:     	lsl	x8, x2, #1
1000d3e44:     	stp	q0, q0, [sp, #624]
1000d3e48:     	stp	q0, q0, [sp, #592]
1000d3e4c:     	stp	q0, q0, [sp, #560]
1000d3e50:     	stp	q0, q0, [sp, #528]
1000d3e54:     	stp	q0, q0, [sp, #496]
1000d3e58:     	stp	q0, q0, [sp, #464]
1000d3e5c:     	stp	q0, q0, [sp, #432]
1000d3e60:     	stp	q0, q0, [sp, #400]
1000d3e64:     	stp	q0, q0, [sp, #368]
1000d3e68:     	stp	q0, q0, [sp, #336]
1000d3e6c:     	stp	q0, q0, [sp, #304]
1000d3e70:     	stp	q0, q0, [sp, #272]
1000d3e74:     	stp	q0, q0, [sp, #240]
1000d3e78:     	stp	q0, q0, [sp, #208]
1000d3e7c:     	stp	q0, q0, [sp, #176]
1000d3e80:     	ands	x8, x8, #0xfffffffffffffffc
1000d3e84:     	b.eq	0x1000d4160 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d3e88:     	add	x8, x1, x8
1000d3e8c:     	str	x8, [sp, #8]
1000d3e90:     	add	x8, sp, #176
1000d3e94:     	add	x27, x8, #256
1000d3e98:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d3e9c:     	add	x11, x11, #1980
1000d3ea0:     	mov	x12, #0
1000d3ea4:     	ldp	w8, w9, [x1]
1000d3ea8:     	ubfx	x10, x8, #8, #4
1000d3eac:     	str	x10, [sp, #168]
1000d3eb0:     	ubfx	x10, x8, #16, #4
1000d3eb4:     	str	x10, [sp, #160]
1000d3eb8:     	ubfx	x10, x8, #24, #4
1000d3ebc:     	str	x10, [sp, #152]
1000d3ec0:     	ldp	w10, w17, [x1, #8]
1000d3ec4:     	str	x1, [sp, #16]
1000d3ec8:     	and	x14, x8, #0xf
1000d3ecc:     	ubfx	x13, x8, #4, #4
1000d3ed0:     	stp	x13, x14, [sp, #136]
1000d3ed4:     	ubfx	x14, x8, #12, #4
1000d3ed8:     	ubfx	x13, x8, #20, #4
1000d3edc:     	stp	x13, x14, [sp, #120]
1000d3ee0:     	lsr	x8, x8, #28
1000d3ee4:     	str	x8, [sp, #112]
1000d3ee8:     	and	x8, x9, #0xf
1000d3eec:     	str	x8, [sp, #104]
1000d3ef0:     	ubfx	x8, x9, #8, #4
1000d3ef4:     	str	x8, [sp, #96]
1000d3ef8:     	ubfx	x8, x9, #16, #4
1000d3efc:     	str	x8, [sp, #88]
1000d3f00:     	ubfx	x8, x9, #24, #4
1000d3f04:     	str	x8, [sp, #80]
1000d3f08:     	ubfx	x8, x9, #4, #4
1000d3f0c:     	str	x8, [sp, #72]
1000d3f10:     	ubfx	x8, x9, #12, #4
1000d3f14:     	str	x8, [sp, #64]
1000d3f18:     	ubfx	x8, x9, #20, #4
1000d3f1c:     	str	x8, [sp, #56]
1000d3f20:     	lsr	x8, x9, #28
1000d3f24:     	str	x8, [sp, #48]
1000d3f28:     	and	x9, x10, #0xf
1000d3f2c:     	ubfx	x8, x10, #8, #4
1000d3f30:     	stp	x8, x9, [sp, #32]
1000d3f34:     	ubfx	x8, x10, #16, #4
1000d3f38:     	str	x8, [sp, #24]
1000d3f3c:     	ubfx	x28, x10, #24, #4
1000d3f40:     	ubfx	x30, x10, #4, #4
1000d3f44:     	ubfx	x3, x10, #12, #4
1000d3f48:     	ubfx	x8, x10, #20, #4
1000d3f4c:     	lsr	x9, x10, #28
1000d3f50:     	and	x1, x17, #0xf
1000d3f54:     	ubfx	x10, x17, #8, #4
1000d3f58:     	ubfx	x13, x17, #16, #4
1000d3f5c:     	ubfx	x26, x17, #24, #4
1000d3f60:     	ubfx	x14, x17, #4, #4
1000d3f64:     	ubfx	x15, x17, #12, #4
1000d3f68:     	ubfx	x16, x17, #20, #4
1000d3f6c:     	lsr	x17, x17, #28
1000d3f70:     	ldr	w20, [x0, x12]
1000d3f74:     	lsl	w2, w20, #4
1000d3f78:     	and	x2, x2, #0xf0
1000d3f7c:     	add	x5, x11, x2
1000d3f80:     	and	x2, x20, #0xf0
1000d3f84:     	add	x2, x11, x2
1000d3f88:     	lsr	x4, x20, #4
1000d3f8c:     	and	x4, x4, #0xf0
1000d3f90:     	add	x7, x11, x4
1000d3f94:     	lsr	x4, x20, #8
1000d3f98:     	and	x4, x4, #0xf0
1000d3f9c:     	add	x4, x11, x4
1000d3fa0:     	lsr	x6, x20, #12
1000d3fa4:     	and	x6, x6, #0xf0
1000d3fa8:     	add	x19, x11, x6
1000d3fac:     	lsr	x6, x20, #16
1000d3fb0:     	and	x6, x6, #0xf0
1000d3fb4:     	add	x6, x11, x6
1000d3fb8:     	lsr	x21, x20, #20
1000d3fbc:     	and	x21, x21, #0xf0
1000d3fc0:     	add	x21, x11, x21
1000d3fc4:     	lsr	x20, x20, #24
1000d3fc8:     	and	x20, x20, #0xf0
1000d3fcc:     	ldr	x22, [sp, #144]
1000d3fd0:     	ldrsb	w22, [x5, x22]
1000d3fd4:     	add	x20, x11, x20
1000d3fd8:     	ldp	x24, x23, [sp, #160]
1000d3fdc:     	ldrsb	w23, [x7, x23]
1000d3fe0:     	ldrsb	w24, [x19, x24]
1000d3fe4:     	add	w22, w22, w23
1000d3fe8:     	add	w22, w22, w24
1000d3fec:     	ldr	x23, [sp, #152]
1000d3ff0:     	ldrsb	w23, [x21, x23]
1000d3ff4:     	ldr	x24, [sp, #136]
1000d3ff8:     	ldrsb	w24, [x2, x24]
1000d3ffc:     	add	w22, w22, w23
1000d4000:     	add	w22, w22, w24
1000d4004:     	ldp	x24, x23, [sp, #120]
1000d4008:     	ldrsb	w23, [x4, x23]
1000d400c:     	ldrsb	w24, [x6, x24]
1000d4010:     	add	w22, w22, w23
1000d4014:     	add	w22, w22, w24
1000d4018:     	ldr	x23, [sp, #112]
1000d401c:     	ldrsb	w23, [x20, x23]
1000d4020:     	add	w22, w22, w23
1000d4024:     	scvtf	s0, w22
1000d4028:     	ldp	x23, x22, [sp, #96]
1000d402c:     	ldrsb	w22, [x5, x22]
1000d4030:     	ldrsb	w23, [x7, x23]
1000d4034:     	ldp	x25, x24, [sp, #80]
1000d4038:     	ldrsb	w24, [x19, x24]
1000d403c:     	ldrsb	w25, [x21, x25]
1000d4040:     	add	w22, w22, w23
1000d4044:     	ldr	x23, [sp, #72]
1000d4048:     	ldrsb	w23, [x2, x23]
1000d404c:     	add	w22, w22, w24
1000d4050:     	ldr	x24, [sp, #64]
1000d4054:     	ldrsb	w24, [x4, x24]
1000d4058:     	add	w22, w22, w25
1000d405c:     	ldr	x25, [sp, #56]
1000d4060:     	ldrsb	w25, [x6, x25]
1000d4064:     	add	w22, w22, w23
1000d4068:     	add	w22, w22, w24
1000d406c:     	add	w22, w22, w25
1000d4070:     	ldr	x23, [sp, #48]
1000d4074:     	ldrsb	w23, [x20, x23]
1000d4078:     	add	w22, w22, w23
1000d407c:     	scvtf	s1, w22
1000d4080:     	ldp	x23, x22, [sp, #32]
1000d4084:     	ldrsb	w22, [x5, x22]
1000d4088:     	ldrsb	w23, [x7, x23]
1000d408c:     	ldr	x24, [sp, #24]
1000d4090:     	ldrsb	w24, [x19, x24]
1000d4094:     	add	w22, w22, w23
1000d4098:     	ldrsb	w23, [x21, x28]
1000d409c:     	add	w22, w22, w24
1000d40a0:     	ldrsb	w24, [x2, x30]
1000d40a4:     	add	w22, w22, w23
1000d40a8:     	ldrsb	w23, [x4, x3]
1000d40ac:     	add	w22, w22, w24
1000d40b0:     	ldrsb	w24, [x6, x8]
1000d40b4:     	add	w22, w22, w23
1000d40b8:     	ldrsb	w23, [x20, x9]
1000d40bc:     	add	w22, w22, w24
1000d40c0:     	add	w22, w22, w23
1000d40c4:     	scvtf	s2, w22
1000d40c8:     	ldrsb	w5, [x5, x1]
1000d40cc:     	ldrsb	w7, [x7, x10]
1000d40d0:     	ldrsb	w19, [x19, x13]
1000d40d4:     	add	w5, w5, w7
1000d40d8:     	add	w5, w5, w19
1000d40dc:     	ldrsb	w7, [x21, x26]
1000d40e0:     	ldrsb	w2, [x2, x14]
1000d40e4:     	add	w5, w5, w7
1000d40e8:     	add	w2, w5, w2
1000d40ec:     	ldrsb	w4, [x4, x15]
1000d40f0:     	ldrsb	w5, [x6, x16]
1000d40f4:     	add	w2, w2, w4
1000d40f8:     	add	w2, w2, w5
1000d40fc:     	ldrsb	w4, [x20, x17]
1000d4100:     	add	w2, w2, w4
1000d4104:     	add	x4, sp, #176
1000d4108:     	scvtf	s3, w2
1000d410c:     	add	x2, x27, x12
1000d4110:     	ldur	s4, [x2, #-128]
1000d4114:     	fadd	s1, s4, s1
1000d4118:     	stur	s1, [x2, #-128]
1000d411c:     	ldr	s1, [x2]
1000d4120:     	fadd	s1, s1, s2
1000d4124:     	str	s1, [x2]
1000d4128:     	ldr	s1, [x2, #128]
1000d412c:     	fadd	s1, s1, s3
1000d4130:     	ldr	s2, [x4, x12]
1000d4134:     	str	s1, [x2, #128]
1000d4138:     	fadd	s0, s2, s0
1000d413c:     	str	s0, [x4, x12]
1000d4140:     	add	x12, x12, #4
1000d4144:     	cmp	x12, #128
1000d4148:     	b.ne	0x1000d3f70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d414c:     	add	x0, x0, #128
1000d4150:     	ldp	x8, x1, [sp, #8]
1000d4154:     	add	x1, x1, #16
1000d4158:     	cmp	x1, x8
1000d415c:     	b.ne	0x1000d3ea0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d4160:     	add	x1, sp, #176
1000d4164:     	ldr	x0, [sp]
1000d4168:     	mov	w2, #512
1000d416c:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d4170:     	ldur	x8, [x29, #-96]
1000d4174:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 8ul, false>(char const*)+0x228>
1000d4178:     	ldr	x9, [x9, #392]
1000d417c:     	ldr	x9, [x9]
1000d4180:     	cmp	x9, x8
1000d4184:     	b.ne	0x1000d41a8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d4188:     	add	sp, sp, #704
1000d418c:     	ldp	x29, x30, [sp, #80]
1000d4190:     	ldp	x20, x19, [sp, #64]
1000d4194:     	ldp	x22, x21, [sp, #48]
1000d4198:     	ldp	x24, x23, [sp, #32]
1000d419c:     	ldp	x26, x25, [sp, #16]
1000d41a0:     	ldp	x28, x27, [sp], #96
1000d41a4:     	ret
1000d41a8:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d5e0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d5e0c:     	stp	x28, x27, [sp, #-96]!
1000d5e10:     	stp	x26, x25, [sp, #16]
1000d5e14:     	stp	x24, x23, [sp, #32]
1000d5e18:     	stp	x22, x21, [sp, #48]
1000d5e1c:     	stp	x20, x19, [sp, #64]
1000d5e20:     	stp	x29, x30, [sp, #80]
1000d5e24:     	add	x29, sp, #80
1000d5e28:     	sub	sp, sp, #1488
1000d5e2c:     	str	x3, [sp]
1000d5e30:     	mov	x20, x1
1000d5e34:     	mov	x22, x0
1000d5e38:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d5e3c:     	ldr	x8, [x8, #392]
1000d5e40:     	ldr	x8, [x8]
1000d5e44:     	stur	x8, [x29, #-96]
1000d5e48:     	lsl	x8, x2, #2
1000d5e4c:     	and	x19, x8, #0xfffffffffffffff8
1000d5e50:     	add	x0, sp, #448
1000d5e54:     	mov	w1, #1024
1000d5e58:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d5e5c:     	cbz	x19, 0x1000d6388 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d5e60:     	add	x8, x20, x19
1000d5e64:     	str	x8, [sp, #8]
1000d5e68:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2b0>
1000d5e6c:     	add	x9, x9, #1724
1000d5e70:     	mov	x10, #0
1000d5e74:     	ldp	w8, w11, [x20]
1000d5e78:     	ubfx	x13, x8, #8, #4
1000d5e7c:     	ubfx	x12, x8, #16, #4
1000d5e80:     	stp	x12, x13, [sp, #432]
1000d5e84:     	ubfx	x15, x8, #24, #4
1000d5e88:     	ldp	w12, w13, [x20, #8]
1000d5e8c:     	and	x14, x8, #0xf
1000d5e90:     	stp	x14, x15, [sp, #416]
1000d5e94:     	ubfx	x15, x8, #4, #4
1000d5e98:     	ubfx	x14, x8, #12, #4
1000d5e9c:     	stp	x14, x15, [sp, #400]
1000d5ea0:     	ubfx	x14, x8, #20, #4
1000d5ea4:     	lsr	x8, x8, #28
1000d5ea8:     	stp	x8, x14, [sp, #384]
1000d5eac:     	and	x8, x11, #0xf
1000d5eb0:     	str	x8, [sp, #376]
1000d5eb4:     	ubfx	x8, x11, #8, #4
1000d5eb8:     	str	x8, [sp, #368]
1000d5ebc:     	ubfx	x8, x11, #16, #4
1000d5ec0:     	str	x8, [sp, #360]
1000d5ec4:     	ubfx	x8, x11, #24, #4
1000d5ec8:     	str	x8, [sp, #352]
1000d5ecc:     	ubfx	x8, x11, #4, #4
1000d5ed0:     	str	x8, [sp, #344]
1000d5ed4:     	ubfx	x8, x11, #12, #4
1000d5ed8:     	str	x8, [sp, #336]
1000d5edc:     	ubfx	x8, x11, #20, #4
1000d5ee0:     	str	x8, [sp, #328]
1000d5ee4:     	lsr	x8, x11, #28
1000d5ee8:     	str	x8, [sp, #320]
1000d5eec:     	and	x11, x12, #0xf
1000d5ef0:     	ubfx	x8, x12, #8, #4
1000d5ef4:     	stp	x8, x11, [sp, #304]
1000d5ef8:     	ubfx	x11, x12, #16, #4
1000d5efc:     	ubfx	x8, x12, #24, #4
1000d5f00:     	stp	x8, x11, [sp, #288]
1000d5f04:     	ubfx	x11, x12, #4, #4
1000d5f08:     	ubfx	x8, x12, #12, #4
1000d5f0c:     	stp	x8, x11, [sp, #272]
1000d5f10:     	ubfx	x11, x12, #20, #4
1000d5f14:     	lsr	x8, x12, #28
1000d5f18:     	stp	x8, x11, [sp, #256]
1000d5f1c:     	and	x11, x13, #0xf
1000d5f20:     	ubfx	x8, x13, #8, #4
1000d5f24:     	stp	x8, x11, [sp, #240]
1000d5f28:     	ubfx	x11, x13, #16, #4
1000d5f2c:     	ubfx	x8, x13, #24, #4
1000d5f30:     	stp	x8, x11, [sp, #224]
1000d5f34:     	ubfx	x11, x13, #4, #4
1000d5f38:     	ubfx	x8, x13, #12, #4
1000d5f3c:     	stp	x8, x11, [sp, #208]
1000d5f40:     	ubfx	x11, x13, #20, #4
1000d5f44:     	lsr	x8, x13, #28
1000d5f48:     	stp	x8, x11, [sp, #192]
1000d5f4c:     	ldp	w8, w11, [x20, #16]
1000d5f50:     	and	x13, x8, #0xf
1000d5f54:     	ubfx	x12, x8, #8, #4
1000d5f58:     	stp	x12, x13, [sp, #176]
1000d5f5c:     	ubfx	x13, x8, #16, #4
1000d5f60:     	ubfx	x12, x8, #24, #4
1000d5f64:     	stp	x12, x13, [sp, #160]
1000d5f68:     	ubfx	x13, x8, #4, #4
1000d5f6c:     	ubfx	x12, x8, #12, #4
1000d5f70:     	stp	x12, x13, [sp, #144]
1000d5f74:     	ubfx	x12, x8, #20, #4
1000d5f78:     	lsr	x8, x8, #28
1000d5f7c:     	stp	x8, x12, [sp, #128]
1000d5f80:     	and	x8, x11, #0xf
1000d5f84:     	str	x8, [sp, #120]
1000d5f88:     	ubfx	x8, x11, #8, #4
1000d5f8c:     	str	x8, [sp, #112]
1000d5f90:     	ubfx	x8, x11, #16, #4
1000d5f94:     	str	x8, [sp, #104]
1000d5f98:     	ubfx	x8, x11, #24, #4
1000d5f9c:     	str	x8, [sp, #96]
1000d5fa0:     	ubfx	x8, x11, #4, #4
1000d5fa4:     	str	x8, [sp, #88]
1000d5fa8:     	ubfx	x8, x11, #12, #4
1000d5fac:     	str	x8, [sp, #80]
1000d5fb0:     	ubfx	x8, x11, #20, #4
1000d5fb4:     	str	x8, [sp, #72]
1000d5fb8:     	lsr	x8, x11, #28
1000d5fbc:     	str	x8, [sp, #64]
1000d5fc0:     	ldp	w13, w2, [x20, #24]
1000d5fc4:     	and	x11, x13, #0xf
1000d5fc8:     	ubfx	x8, x13, #8, #4
1000d5fcc:     	stp	x8, x11, [sp, #48]
1000d5fd0:     	ubfx	x11, x13, #16, #4
1000d5fd4:     	ubfx	x8, x13, #24, #4
1000d5fd8:     	stp	x8, x11, [sp, #32]
1000d5fdc:     	ubfx	x8, x13, #4, #4
1000d5fe0:     	stp	x20, x8, [sp, #16]
1000d5fe4:     	ubfx	x11, x13, #12, #4
1000d5fe8:     	ubfx	x12, x13, #20, #4
1000d5fec:     	lsr	x13, x13, #28
1000d5ff0:     	and	x14, x2, #0xf
1000d5ff4:     	ubfx	x21, x2, #8, #4
1000d5ff8:     	ubfx	x15, x2, #16, #4
1000d5ffc:     	ubfx	x16, x2, #24, #4
1000d6000:     	ubfx	x17, x2, #4, #4
1000d6004:     	ubfx	x0, x2, #12, #4
1000d6008:     	ubfx	x1, x2, #20, #4
1000d600c:     	lsr	x2, x2, #28
1000d6010:     	ldr	w25, [x22, x10]
1000d6014:     	lsl	w3, w25, #4
1000d6018:     	and	x3, x3, #0xf0
1000d601c:     	add	x3, x9, x3
1000d6020:     	ldr	x8, [sp, #416]
1000d6024:     	ldrb	w26, [x3, x8]
1000d6028:     	lsr	x4, x25, #4
1000d602c:     	and	x4, x4, #0xf0
1000d6030:     	add	x4, x9, x4
1000d6034:     	ldr	x8, [sp, #440]
1000d6038:     	ldrb	w27, [x4, x8]
1000d603c:     	lsr	x5, x25, #12
1000d6040:     	and	x5, x5, #0xf0
1000d6044:     	add	x5, x9, x5
1000d6048:     	ldr	x8, [sp, #432]
1000d604c:     	ldrb	w28, [x5, x8]
1000d6050:     	lsr	x6, x25, #20
1000d6054:     	and	x6, x6, #0xf0
1000d6058:     	add	x7, x9, x6
1000d605c:     	ldr	x8, [sp, #424]
1000d6060:     	ldrb	w30, [x7, x8]
1000d6064:     	and	x6, x25, #0xf0
1000d6068:     	add	x6, x9, x6
1000d606c:     	ldr	x8, [sp, #408]
1000d6070:     	ldrb	w19, [x6, x8]
1000d6074:     	lsr	x23, x25, #8
1000d6078:     	and	x23, x23, #0xf0
1000d607c:     	add	x23, x9, x23
1000d6080:     	ldp	x20, x8, [sp, #392]
1000d6084:     	ldrb	w8, [x23, x8]
1000d6088:     	lsr	x24, x25, #16
1000d608c:     	and	x24, x24, #0xf0
1000d6090:     	add	x24, x9, x24
1000d6094:     	ldrb	w20, [x24, x20]
1000d6098:     	lsr	x25, x25, #24
1000d609c:     	and	x25, x25, #0xf0
1000d60a0:     	add	x25, x9, x25
1000d60a4:     	add	w26, w26, w27
1000d60a8:     	ldr	x27, [sp, #384]
1000d60ac:     	ldrb	w27, [x25, x27]
1000d60b0:     	add	w26, w26, w28
1000d60b4:     	add	w26, w26, w30
1000d60b8:     	add	w19, w26, w19
1000d60bc:     	add	w8, w19, w8
1000d60c0:     	add	w8, w8, w20
1000d60c4:     	add	w8, w8, w27
1000d60c8:     	scvtf	s0, w8
1000d60cc:     	ldp	x19, x8, [sp, #368]
1000d60d0:     	ldrb	w8, [x3, x8]
1000d60d4:     	ldrb	w19, [x4, x19]
1000d60d8:     	ldp	x26, x20, [sp, #352]
1000d60dc:     	ldrb	w20, [x5, x20]
1000d60e0:     	ldrb	w26, [x7, x26]
1000d60e4:     	ldp	x28, x27, [sp, #336]
1000d60e8:     	ldrb	w27, [x6, x27]
1000d60ec:     	ldrb	w28, [x23, x28]
1000d60f0:     	add	w8, w8, w19
1000d60f4:     	ldr	x19, [sp, #328]
1000d60f8:     	ldrb	w19, [x24, x19]
1000d60fc:     	add	w8, w8, w20
1000d6100:     	add	w8, w8, w26
1000d6104:     	ldr	x20, [sp, #320]
1000d6108:     	ldrb	w20, [x25, x20]
1000d610c:     	add	w8, w8, w27
1000d6110:     	add	w8, w8, w28
1000d6114:     	add	w8, w8, w19
1000d6118:     	add	w8, w8, w20
1000d611c:     	scvtf	s1, w8
1000d6120:     	ldp	x19, x8, [sp, #304]
1000d6124:     	ldrb	w8, [x3, x8]
1000d6128:     	ldrb	w19, [x4, x19]
1000d612c:     	ldp	x26, x20, [sp, #288]
1000d6130:     	ldrb	w20, [x5, x20]
1000d6134:     	ldrb	w26, [x7, x26]
1000d6138:     	ldr	x27, [sp, #280]
1000d613c:     	ldrb	w27, [x6, x27]
1000d6140:     	add	w8, w8, w19
1000d6144:     	ldr	x19, [sp, #272]
1000d6148:     	ldrb	w19, [x23, x19]
1000d614c:     	add	w8, w8, w20
1000d6150:     	ldr	x20, [sp, #264]
1000d6154:     	ldrb	w20, [x24, x20]
1000d6158:     	add	w8, w8, w26
1000d615c:     	ldr	x26, [sp, #256]
1000d6160:     	ldrb	w26, [x25, x26]
1000d6164:     	add	w8, w8, w27
1000d6168:     	add	w8, w8, w19
1000d616c:     	add	w8, w8, w20
1000d6170:     	add	w8, w8, w26
1000d6174:     	scvtf	s2, w8
1000d6178:     	ldp	x19, x8, [sp, #240]
1000d617c:     	ldrb	w8, [x3, x8]
1000d6180:     	ldrb	w19, [x4, x19]
1000d6184:     	ldp	x26, x20, [sp, #224]
1000d6188:     	ldrb	w20, [x5, x20]
1000d618c:     	ldrb	w26, [x7, x26]
1000d6190:     	add	w8, w8, w19
1000d6194:     	ldr	x19, [sp, #216]
1000d6198:     	ldrb	w19, [x6, x19]
1000d619c:     	add	w8, w8, w20
1000d61a0:     	ldr	x20, [sp, #208]
1000d61a4:     	ldrb	w20, [x23, x20]
1000d61a8:     	add	w8, w8, w26
1000d61ac:     	ldr	x26, [sp, #200]
1000d61b0:     	ldrb	w26, [x24, x26]
1000d61b4:     	add	w8, w8, w19
1000d61b8:     	ldr	x19, [sp, #192]
1000d61bc:     	ldrb	w19, [x25, x19]
1000d61c0:     	add	w8, w8, w20
1000d61c4:     	add	w8, w8, w26
1000d61c8:     	add	w8, w8, w19
1000d61cc:     	scvtf	s3, w8
1000d61d0:     	ldp	x19, x8, [sp, #176]
1000d61d4:     	ldrb	w8, [x3, x8]
1000d61d8:     	ldrb	w19, [x4, x19]
1000d61dc:     	ldp	x26, x20, [sp, #160]
1000d61e0:     	ldrb	w20, [x5, x20]
1000d61e4:     	ldrb	w26, [x7, x26]
1000d61e8:     	add	w8, w8, w19
1000d61ec:     	add	w8, w8, w20
1000d61f0:     	ldp	x20, x19, [sp, #144]
1000d61f4:     	ldrb	w19, [x6, x19]
1000d61f8:     	ldrb	w20, [x23, x20]
1000d61fc:     	add	w8, w8, w26
1000d6200:     	add	w8, w8, w19
1000d6204:     	ldp	x26, x19, [sp, #128]
1000d6208:     	ldrb	w19, [x24, x19]
1000d620c:     	ldrb	w26, [x25, x26]
1000d6210:     	add	w8, w8, w20
1000d6214:     	add	w8, w8, w19
1000d6218:     	add	w8, w8, w26
1000d621c:     	scvtf	s4, w8
1000d6220:     	ldp	x19, x8, [sp, #112]
1000d6224:     	ldrb	w8, [x3, x8]
1000d6228:     	ldrb	w19, [x4, x19]
1000d622c:     	ldr	x20, [sp, #104]
1000d6230:     	ldrb	w20, [x5, x20]
1000d6234:     	add	w8, w8, w19
1000d6238:     	add	w8, w8, w20
1000d623c:     	ldp	x20, x19, [sp, #88]
1000d6240:     	ldrb	w19, [x7, x19]
1000d6244:     	ldrb	w20, [x6, x20]
1000d6248:     	add	w8, w8, w19
1000d624c:     	add	w8, w8, w20
1000d6250:     	ldp	x20, x19, [sp, #72]
1000d6254:     	ldrb	w19, [x23, x19]
1000d6258:     	ldrb	w20, [x24, x20]
1000d625c:     	add	w8, w8, w19
1000d6260:     	add	w8, w8, w20
1000d6264:     	ldr	x19, [sp, #64]
1000d6268:     	ldrb	w19, [x25, x19]
1000d626c:     	add	w8, w8, w19
1000d6270:     	scvtf	s5, w8
1000d6274:     	ldp	x19, x8, [sp, #48]
1000d6278:     	ldrb	w8, [x3, x8]
1000d627c:     	ldrb	w19, [x4, x19]
1000d6280:     	ldp	x26, x20, [sp, #32]
1000d6284:     	ldrb	w20, [x5, x20]
1000d6288:     	ldrb	w26, [x7, x26]
1000d628c:     	add	w8, w8, w19
1000d6290:     	ldr	x19, [sp, #24]
1000d6294:     	ldrb	w19, [x6, x19]
1000d6298:     	add	w8, w8, w20
1000d629c:     	ldrb	w20, [x23, x11]
1000d62a0:     	add	w8, w8, w26
1000d62a4:     	ldrb	w26, [x24, x12]
1000d62a8:     	add	w8, w8, w19
1000d62ac:     	add	w8, w8, w20
1000d62b0:     	add	w8, w8, w26
1000d62b4:     	ldrb	w19, [x25, x13]
1000d62b8:     	add	w8, w8, w19
1000d62bc:     	scvtf	s6, w8
1000d62c0:     	ldrb	w8, [x3, x14]
1000d62c4:     	ldrb	w3, [x4, x21]
1000d62c8:     	ldrb	w4, [x5, x15]
1000d62cc:     	add	w8, w8, w3
1000d62d0:     	add	w8, w8, w4
1000d62d4:     	ldrb	w3, [x7, x16]
1000d62d8:     	ldrb	w4, [x6, x17]
1000d62dc:     	add	w8, w8, w3
1000d62e0:     	add	w8, w8, w4
1000d62e4:     	ldrb	w3, [x23, x0]
1000d62e8:     	add	x5, sp, #448
1000d62ec:     	ldrb	w4, [x24, x1]
1000d62f0:     	add	w8, w8, w3
1000d62f4:     	add	w8, w8, w4
1000d62f8:     	ldrb	w3, [x25, x2]
1000d62fc:     	add	w8, w8, w3
1000d6300:     	scvtf	s7, w8
1000d6304:     	add	x8, x5, x10
1000d6308:     	ldr	s16, [x8]
1000d630c:     	fadd	s0, s16, s0
1000d6310:     	str	s0, [x8]
1000d6314:     	ldr	s0, [x8, #128]
1000d6318:     	fadd	s0, s0, s1
1000d631c:     	str	s0, [x8, #128]
1000d6320:     	ldr	s0, [x8, #256]
1000d6324:     	fadd	s0, s0, s2
1000d6328:     	str	s0, [x8, #256]
1000d632c:     	ldr	s0, [x8, #384]
1000d6330:     	fadd	s0, s0, s3
1000d6334:     	str	s0, [x8, #384]
1000d6338:     	ldr	s0, [x8, #512]
1000d633c:     	fadd	s0, s0, s4
1000d6340:     	str	s0, [x8, #512]
1000d6344:     	ldr	s0, [x8, #640]
1000d6348:     	fadd	s0, s0, s5
1000d634c:     	str	s0, [x8, #640]
1000d6350:     	ldr	s0, [x8, #768]
1000d6354:     	fadd	s0, s0, s6
1000d6358:     	ldr	s1, [x8, #896]
1000d635c:     	fadd	s1, s1, s7
1000d6360:     	str	s0, [x8, #768]
1000d6364:     	str	s1, [x8, #896]
1000d6368:     	add	x10, x10, #4
1000d636c:     	cmp	x10, #128
1000d6370:     	b.ne	0x1000d6010 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d6374:     	add	x22, x22, #128
1000d6378:     	ldp	x8, x20, [sp, #8]
1000d637c:     	add	x20, x20, #32
1000d6380:     	cmp	x20, x8
1000d6384:     	b.ne	0x1000d5e70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d6388:     	add	x1, sp, #448
1000d638c:     	ldr	x0, [sp]
1000d6390:     	mov	w2, #1024
1000d6394:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d6398:     	ldur	x8, [x29, #-96]
1000d639c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000d63a0:     	ldr	x9, [x9, #392]
1000d63a4:     	ldr	x9, [x9]
1000d63a8:     	cmp	x9, x8
1000d63ac:     	b.ne	0x1000d63d0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d63b0:     	add	sp, sp, #1488
1000d63b4:     	ldp	x29, x30, [sp, #80]
1000d63b8:     	ldp	x20, x19, [sp, #64]
1000d63bc:     	ldp	x22, x21, [sp, #48]
1000d63c0:     	ldp	x24, x23, [sp, #32]
1000d63c4:     	ldp	x26, x25, [sp, #16]
1000d63c8:     	ldp	x28, x27, [sp], #96
1000d63cc:     	ret
1000d63d0:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d6548 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d6548:     	stp	x28, x27, [sp, #-96]!
1000d654c:     	stp	x26, x25, [sp, #16]
1000d6550:     	stp	x24, x23, [sp, #32]
1000d6554:     	stp	x22, x21, [sp, #48]
1000d6558:     	stp	x20, x19, [sp, #64]
1000d655c:     	stp	x29, x30, [sp, #80]
1000d6560:     	add	x29, sp, #80
1000d6564:     	sub	sp, sp, #1488
1000d6568:     	str	x3, [sp]
1000d656c:     	mov	x20, x1
1000d6570:     	mov	x22, x0
1000d6574:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x284>
1000d6578:     	ldr	x8, [x8, #392]
1000d657c:     	ldr	x8, [x8]
1000d6580:     	stur	x8, [x29, #-96]
1000d6584:     	lsl	x8, x2, #2
1000d6588:     	and	x19, x8, #0xfffffffffffffff8
1000d658c:     	add	x0, sp, #448
1000d6590:     	mov	w1, #1024
1000d6594:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d6598:     	cbz	x19, 0x1000d6ac4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x57c>
1000d659c:     	add	x8, x20, x19
1000d65a0:     	str	x8, [sp, #8]
1000d65a4:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000d65a8:     	add	x9, x9, #1980
1000d65ac:     	mov	x10, #0
1000d65b0:     	ldp	w8, w11, [x20]
1000d65b4:     	ubfx	x13, x8, #8, #4
1000d65b8:     	ubfx	x12, x8, #16, #4
1000d65bc:     	stp	x12, x13, [sp, #432]
1000d65c0:     	ubfx	x15, x8, #24, #4
1000d65c4:     	ldp	w12, w13, [x20, #8]
1000d65c8:     	and	x14, x8, #0xf
1000d65cc:     	stp	x14, x15, [sp, #416]
1000d65d0:     	ubfx	x15, x8, #4, #4
1000d65d4:     	ubfx	x14, x8, #12, #4
1000d65d8:     	stp	x14, x15, [sp, #400]
1000d65dc:     	ubfx	x14, x8, #20, #4
1000d65e0:     	lsr	x8, x8, #28
1000d65e4:     	stp	x8, x14, [sp, #384]
1000d65e8:     	and	x8, x11, #0xf
1000d65ec:     	str	x8, [sp, #376]
1000d65f0:     	ubfx	x8, x11, #8, #4
1000d65f4:     	str	x8, [sp, #368]
1000d65f8:     	ubfx	x8, x11, #16, #4
1000d65fc:     	str	x8, [sp, #360]
1000d6600:     	ubfx	x8, x11, #24, #4
1000d6604:     	str	x8, [sp, #352]
1000d6608:     	ubfx	x8, x11, #4, #4
1000d660c:     	str	x8, [sp, #344]
1000d6610:     	ubfx	x8, x11, #12, #4
1000d6614:     	str	x8, [sp, #336]
1000d6618:     	ubfx	x8, x11, #20, #4
1000d661c:     	str	x8, [sp, #328]
1000d6620:     	lsr	x8, x11, #28
1000d6624:     	str	x8, [sp, #320]
1000d6628:     	and	x11, x12, #0xf
1000d662c:     	ubfx	x8, x12, #8, #4
1000d6630:     	stp	x8, x11, [sp, #304]
1000d6634:     	ubfx	x11, x12, #16, #4
1000d6638:     	ubfx	x8, x12, #24, #4
1000d663c:     	stp	x8, x11, [sp, #288]
1000d6640:     	ubfx	x11, x12, #4, #4
1000d6644:     	ubfx	x8, x12, #12, #4
1000d6648:     	stp	x8, x11, [sp, #272]
1000d664c:     	ubfx	x11, x12, #20, #4
1000d6650:     	lsr	x8, x12, #28
1000d6654:     	stp	x8, x11, [sp, #256]
1000d6658:     	and	x11, x13, #0xf
1000d665c:     	ubfx	x8, x13, #8, #4
1000d6660:     	stp	x8, x11, [sp, #240]
1000d6664:     	ubfx	x11, x13, #16, #4
1000d6668:     	ubfx	x8, x13, #24, #4
1000d666c:     	stp	x8, x11, [sp, #224]
1000d6670:     	ubfx	x11, x13, #4, #4
1000d6674:     	ubfx	x8, x13, #12, #4
1000d6678:     	stp	x8, x11, [sp, #208]
1000d667c:     	ubfx	x11, x13, #20, #4
1000d6680:     	lsr	x8, x13, #28
1000d6684:     	stp	x8, x11, [sp, #192]
1000d6688:     	ldp	w8, w11, [x20, #16]
1000d668c:     	and	x13, x8, #0xf
1000d6690:     	ubfx	x12, x8, #8, #4
1000d6694:     	stp	x12, x13, [sp, #176]
1000d6698:     	ubfx	x13, x8, #16, #4
1000d669c:     	ubfx	x12, x8, #24, #4
1000d66a0:     	stp	x12, x13, [sp, #160]
1000d66a4:     	ubfx	x13, x8, #4, #4
1000d66a8:     	ubfx	x12, x8, #12, #4
1000d66ac:     	stp	x12, x13, [sp, #144]
1000d66b0:     	ubfx	x12, x8, #20, #4
1000d66b4:     	lsr	x8, x8, #28
1000d66b8:     	stp	x8, x12, [sp, #128]
1000d66bc:     	and	x8, x11, #0xf
1000d66c0:     	str	x8, [sp, #120]
1000d66c4:     	ubfx	x8, x11, #8, #4
1000d66c8:     	str	x8, [sp, #112]
1000d66cc:     	ubfx	x8, x11, #16, #4
1000d66d0:     	str	x8, [sp, #104]
1000d66d4:     	ubfx	x8, x11, #24, #4
1000d66d8:     	str	x8, [sp, #96]
1000d66dc:     	ubfx	x8, x11, #4, #4
1000d66e0:     	str	x8, [sp, #88]
1000d66e4:     	ubfx	x8, x11, #12, #4
1000d66e8:     	str	x8, [sp, #80]
1000d66ec:     	ubfx	x8, x11, #20, #4
1000d66f0:     	str	x8, [sp, #72]
1000d66f4:     	lsr	x8, x11, #28
1000d66f8:     	str	x8, [sp, #64]
1000d66fc:     	ldp	w13, w2, [x20, #24]
1000d6700:     	and	x11, x13, #0xf
1000d6704:     	ubfx	x8, x13, #8, #4
1000d6708:     	stp	x8, x11, [sp, #48]
1000d670c:     	ubfx	x11, x13, #16, #4
1000d6710:     	ubfx	x8, x13, #24, #4
1000d6714:     	stp	x8, x11, [sp, #32]
1000d6718:     	ubfx	x8, x13, #4, #4
1000d671c:     	stp	x20, x8, [sp, #16]
1000d6720:     	ubfx	x11, x13, #12, #4
1000d6724:     	ubfx	x12, x13, #20, #4
1000d6728:     	lsr	x13, x13, #28
1000d672c:     	and	x14, x2, #0xf
1000d6730:     	ubfx	x21, x2, #8, #4
1000d6734:     	ubfx	x15, x2, #16, #4
1000d6738:     	ubfx	x16, x2, #24, #4
1000d673c:     	ubfx	x17, x2, #4, #4
1000d6740:     	ubfx	x0, x2, #12, #4
1000d6744:     	ubfx	x1, x2, #20, #4
1000d6748:     	lsr	x2, x2, #28
1000d674c:     	ldr	w25, [x22, x10]
1000d6750:     	lsl	w3, w25, #4
1000d6754:     	and	x3, x3, #0xf0
1000d6758:     	add	x3, x9, x3
1000d675c:     	ldr	x8, [sp, #416]
1000d6760:     	ldrsb	w26, [x3, x8]
1000d6764:     	lsr	x4, x25, #4
1000d6768:     	and	x4, x4, #0xf0
1000d676c:     	add	x4, x9, x4
1000d6770:     	ldr	x8, [sp, #440]
1000d6774:     	ldrsb	w27, [x4, x8]
1000d6778:     	lsr	x5, x25, #12
1000d677c:     	and	x5, x5, #0xf0
1000d6780:     	add	x5, x9, x5
1000d6784:     	ldr	x8, [sp, #432]
1000d6788:     	ldrsb	w28, [x5, x8]
1000d678c:     	lsr	x6, x25, #20
1000d6790:     	and	x6, x6, #0xf0
1000d6794:     	add	x7, x9, x6
1000d6798:     	ldr	x8, [sp, #424]
1000d679c:     	ldrsb	w30, [x7, x8]
1000d67a0:     	and	x6, x25, #0xf0
1000d67a4:     	add	x6, x9, x6
1000d67a8:     	ldr	x8, [sp, #408]
1000d67ac:     	ldrsb	w19, [x6, x8]
1000d67b0:     	lsr	x23, x25, #8
1000d67b4:     	and	x23, x23, #0xf0
1000d67b8:     	add	x23, x9, x23
1000d67bc:     	ldp	x20, x8, [sp, #392]
1000d67c0:     	ldrsb	w8, [x23, x8]
1000d67c4:     	lsr	x24, x25, #16
1000d67c8:     	and	x24, x24, #0xf0
1000d67cc:     	add	x24, x9, x24
1000d67d0:     	ldrsb	w20, [x24, x20]
1000d67d4:     	lsr	x25, x25, #24
1000d67d8:     	and	x25, x25, #0xf0
1000d67dc:     	add	x25, x9, x25
1000d67e0:     	add	w26, w26, w27
1000d67e4:     	ldr	x27, [sp, #384]
1000d67e8:     	ldrsb	w27, [x25, x27]
1000d67ec:     	add	w26, w26, w28
1000d67f0:     	add	w26, w26, w30
1000d67f4:     	add	w19, w26, w19
1000d67f8:     	add	w8, w19, w8
1000d67fc:     	add	w8, w8, w20
1000d6800:     	add	w8, w8, w27
1000d6804:     	scvtf	s0, w8
1000d6808:     	ldp	x19, x8, [sp, #368]
1000d680c:     	ldrsb	w8, [x3, x8]
1000d6810:     	ldrsb	w19, [x4, x19]
1000d6814:     	ldp	x26, x20, [sp, #352]
1000d6818:     	ldrsb	w20, [x5, x20]
1000d681c:     	ldrsb	w26, [x7, x26]
1000d6820:     	ldp	x28, x27, [sp, #336]
1000d6824:     	ldrsb	w27, [x6, x27]
1000d6828:     	ldrsb	w28, [x23, x28]
1000d682c:     	add	w8, w8, w19
1000d6830:     	ldr	x19, [sp, #328]
1000d6834:     	ldrsb	w19, [x24, x19]
1000d6838:     	add	w8, w8, w20
1000d683c:     	add	w8, w8, w26
1000d6840:     	ldr	x20, [sp, #320]
1000d6844:     	ldrsb	w20, [x25, x20]
1000d6848:     	add	w8, w8, w27
1000d684c:     	add	w8, w8, w28
1000d6850:     	add	w8, w8, w19
1000d6854:     	add	w8, w8, w20
1000d6858:     	scvtf	s1, w8
1000d685c:     	ldp	x19, x8, [sp, #304]
1000d6860:     	ldrsb	w8, [x3, x8]
1000d6864:     	ldrsb	w19, [x4, x19]
1000d6868:     	ldp	x26, x20, [sp, #288]
1000d686c:     	ldrsb	w20, [x5, x20]
1000d6870:     	ldrsb	w26, [x7, x26]
1000d6874:     	ldr	x27, [sp, #280]
1000d6878:     	ldrsb	w27, [x6, x27]
1000d687c:     	add	w8, w8, w19
1000d6880:     	ldr	x19, [sp, #272]
1000d6884:     	ldrsb	w19, [x23, x19]
1000d6888:     	add	w8, w8, w20
1000d688c:     	ldr	x20, [sp, #264]
1000d6890:     	ldrsb	w20, [x24, x20]
1000d6894:     	add	w8, w8, w26
1000d6898:     	ldr	x26, [sp, #256]
1000d689c:     	ldrsb	w26, [x25, x26]
1000d68a0:     	add	w8, w8, w27
1000d68a4:     	add	w8, w8, w19
1000d68a8:     	add	w8, w8, w20
1000d68ac:     	add	w8, w8, w26
1000d68b0:     	scvtf	s2, w8
1000d68b4:     	ldp	x19, x8, [sp, #240]
1000d68b8:     	ldrsb	w8, [x3, x8]
1000d68bc:     	ldrsb	w19, [x4, x19]
1000d68c0:     	ldp	x26, x20, [sp, #224]
1000d68c4:     	ldrsb	w20, [x5, x20]
1000d68c8:     	ldrsb	w26, [x7, x26]
1000d68cc:     	add	w8, w8, w19
1000d68d0:     	ldr	x19, [sp, #216]
1000d68d4:     	ldrsb	w19, [x6, x19]
1000d68d8:     	add	w8, w8, w20
1000d68dc:     	ldr	x20, [sp, #208]
1000d68e0:     	ldrsb	w20, [x23, x20]
1000d68e4:     	add	w8, w8, w26
1000d68e8:     	ldr	x26, [sp, #200]
1000d68ec:     	ldrsb	w26, [x24, x26]
1000d68f0:     	add	w8, w8, w19
1000d68f4:     	ldr	x19, [sp, #192]
1000d68f8:     	ldrsb	w19, [x25, x19]
1000d68fc:     	add	w8, w8, w20
1000d6900:     	add	w8, w8, w26
1000d6904:     	add	w8, w8, w19
1000d6908:     	scvtf	s3, w8
1000d690c:     	ldp	x19, x8, [sp, #176]
1000d6910:     	ldrsb	w8, [x3, x8]
1000d6914:     	ldrsb	w19, [x4, x19]
1000d6918:     	ldp	x26, x20, [sp, #160]
1000d691c:     	ldrsb	w20, [x5, x20]
1000d6920:     	ldrsb	w26, [x7, x26]
1000d6924:     	add	w8, w8, w19
1000d6928:     	add	w8, w8, w20
1000d692c:     	ldp	x20, x19, [sp, #144]
1000d6930:     	ldrsb	w19, [x6, x19]
1000d6934:     	ldrsb	w20, [x23, x20]
1000d6938:     	add	w8, w8, w26
1000d693c:     	add	w8, w8, w19
1000d6940:     	ldp	x26, x19, [sp, #128]
1000d6944:     	ldrsb	w19, [x24, x19]
1000d6948:     	ldrsb	w26, [x25, x26]
1000d694c:     	add	w8, w8, w20
1000d6950:     	add	w8, w8, w19
1000d6954:     	add	w8, w8, w26
1000d6958:     	scvtf	s4, w8
1000d695c:     	ldp	x19, x8, [sp, #112]
1000d6960:     	ldrsb	w8, [x3, x8]
1000d6964:     	ldrsb	w19, [x4, x19]
1000d6968:     	ldr	x20, [sp, #104]
1000d696c:     	ldrsb	w20, [x5, x20]
1000d6970:     	add	w8, w8, w19
1000d6974:     	add	w8, w8, w20
1000d6978:     	ldp	x20, x19, [sp, #88]
1000d697c:     	ldrsb	w19, [x7, x19]
1000d6980:     	ldrsb	w20, [x6, x20]
1000d6984:     	add	w8, w8, w19
1000d6988:     	add	w8, w8, w20
1000d698c:     	ldp	x20, x19, [sp, #72]
1000d6990:     	ldrsb	w19, [x23, x19]
1000d6994:     	ldrsb	w20, [x24, x20]
1000d6998:     	add	w8, w8, w19
1000d699c:     	add	w8, w8, w20
1000d69a0:     	ldr	x19, [sp, #64]
1000d69a4:     	ldrsb	w19, [x25, x19]
1000d69a8:     	add	w8, w8, w19
1000d69ac:     	scvtf	s5, w8
1000d69b0:     	ldp	x19, x8, [sp, #48]
1000d69b4:     	ldrsb	w8, [x3, x8]
1000d69b8:     	ldrsb	w19, [x4, x19]
1000d69bc:     	ldp	x26, x20, [sp, #32]
1000d69c0:     	ldrsb	w20, [x5, x20]
1000d69c4:     	ldrsb	w26, [x7, x26]
1000d69c8:     	add	w8, w8, w19
1000d69cc:     	ldr	x19, [sp, #24]
1000d69d0:     	ldrsb	w19, [x6, x19]
1000d69d4:     	add	w8, w8, w20
1000d69d8:     	ldrsb	w20, [x23, x11]
1000d69dc:     	add	w8, w8, w26
1000d69e0:     	ldrsb	w26, [x24, x12]
1000d69e4:     	add	w8, w8, w19
1000d69e8:     	add	w8, w8, w20
1000d69ec:     	add	w8, w8, w26
1000d69f0:     	ldrsb	w19, [x25, x13]
1000d69f4:     	add	w8, w8, w19
1000d69f8:     	scvtf	s6, w8
1000d69fc:     	ldrsb	w8, [x3, x14]
1000d6a00:     	ldrsb	w3, [x4, x21]
1000d6a04:     	ldrsb	w4, [x5, x15]
1000d6a08:     	add	w8, w8, w3
1000d6a0c:     	add	w8, w8, w4
1000d6a10:     	ldrsb	w3, [x7, x16]
1000d6a14:     	ldrsb	w4, [x6, x17]
1000d6a18:     	add	w8, w8, w3
1000d6a1c:     	add	w8, w8, w4
1000d6a20:     	ldrsb	w3, [x23, x0]
1000d6a24:     	add	x5, sp, #448
1000d6a28:     	ldrsb	w4, [x24, x1]
1000d6a2c:     	add	w8, w8, w3
1000d6a30:     	add	w8, w8, w4
1000d6a34:     	ldrsb	w3, [x25, x2]
1000d6a38:     	add	w8, w8, w3
1000d6a3c:     	scvtf	s7, w8
1000d6a40:     	add	x8, x5, x10
1000d6a44:     	ldr	s16, [x8]
1000d6a48:     	fadd	s0, s16, s0
1000d6a4c:     	str	s0, [x8]
1000d6a50:     	ldr	s0, [x8, #128]
1000d6a54:     	fadd	s0, s0, s1
1000d6a58:     	str	s0, [x8, #128]
1000d6a5c:     	ldr	s0, [x8, #256]
1000d6a60:     	fadd	s0, s0, s2
1000d6a64:     	str	s0, [x8, #256]
1000d6a68:     	ldr	s0, [x8, #384]
1000d6a6c:     	fadd	s0, s0, s3
1000d6a70:     	str	s0, [x8, #384]
1000d6a74:     	ldr	s0, [x8, #512]
1000d6a78:     	fadd	s0, s0, s4
1000d6a7c:     	str	s0, [x8, #512]
1000d6a80:     	ldr	s0, [x8, #640]
1000d6a84:     	fadd	s0, s0, s5
1000d6a88:     	str	s0, [x8, #640]
1000d6a8c:     	ldr	s0, [x8, #768]
1000d6a90:     	fadd	s0, s0, s6
1000d6a94:     	ldr	s1, [x8, #896]
1000d6a98:     	fadd	s1, s1, s7
1000d6a9c:     	str	s0, [x8, #768]
1000d6aa0:     	str	s1, [x8, #896]
1000d6aa4:     	add	x10, x10, #4
1000d6aa8:     	cmp	x10, #128
1000d6aac:     	b.ne	0x1000d674c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x204>
1000d6ab0:     	add	x22, x22, #128
1000d6ab4:     	ldp	x8, x20, [sp, #8]
1000d6ab8:     	add	x20, x20, #32
1000d6abc:     	cmp	x20, x8
1000d6ac0:     	b.ne	0x1000d65ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x64>
1000d6ac4:     	add	x1, sp, #448
1000d6ac8:     	ldr	x0, [sp]
1000d6acc:     	mov	w2, #1024
1000d6ad0:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d6ad4:     	ldur	x8, [x29, #-96]
1000d6ad8:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 16ul, false>(char const*)+0x220>
1000d6adc:     	ldr	x9, [x9, #392]
1000d6ae0:     	ldr	x9, [x9]
1000d6ae4:     	cmp	x9, x8
1000d6ae8:     	b.ne	0x1000d6b0c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5c4>
1000d6aec:     	add	sp, sp, #1488
1000d6af0:     	ldp	x29, x30, [sp, #80]
1000d6af4:     	ldp	x20, x19, [sp, #64]
1000d6af8:     	ldp	x22, x21, [sp, #48]
1000d6afc:     	ldp	x24, x23, [sp, #32]
1000d6b00:     	ldp	x26, x25, [sp, #16]
1000d6b04:     	ldp	x28, x27, [sp], #96
1000d6b08:     	ret
1000d6b0c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d819c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d819c:     	stp	x28, x27, [sp, #-64]!
1000d81a0:     	stp	x22, x21, [sp, #16]
1000d81a4:     	stp	x20, x19, [sp, #32]
1000d81a8:     	stp	x29, x30, [sp, #48]
1000d81ac:     	add	x29, sp, #48
1000d81b0:     	sub	sp, sp, #2064
1000d81b4:     	mov	x19, x3
1000d81b8:     	mov	x20, x1
1000d81bc:     	mov	x21, x0
1000d81c0:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xcc>
1000d81c4:     	ldr	x8, [x8, #392]
1000d81c8:     	ldr	x8, [x8]
1000d81cc:     	stur	x8, [x29, #-56]
1000d81d0:     	lsl	x8, x2, #3
1000d81d4:     	and	x22, x8, #0xfffffffffffffff0
1000d81d8:     	add	x0, sp, #8
1000d81dc:     	mov	w1, #2048
1000d81e0:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d81e4:     	cbz	x22, 0x1000d82fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d81e8:     	add	x8, x20, x22
1000d81ec:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xf0>
1000d81f0:     	add	x9, x9, #1724
1000d81f4:     	mov	x10, #0
1000d81f8:     	add	x11, sp, #8
1000d81fc:     	mov	x12, #0
1000d8200:     	ldr	w2, [x21, x10, lsl #2]
1000d8204:     	lsl	w13, w2, #4
1000d8208:     	and	x13, x13, #0xf0
1000d820c:     	and	x14, x2, #0xf0
1000d8210:     	lsr	x15, x2, #4
1000d8214:     	and	x15, x15, #0xf0
1000d8218:     	lsr	x16, x2, #8
1000d821c:     	and	x16, x16, #0xf0
1000d8220:     	lsr	x17, x2, #12
1000d8224:     	and	x17, x17, #0xf0
1000d8228:     	lsr	x0, x2, #16
1000d822c:     	and	x0, x0, #0xf0
1000d8230:     	lsr	x1, x2, #20
1000d8234:     	and	x1, x1, #0xf0
1000d8238:     	lsr	x2, x2, #24
1000d823c:     	and	x2, x2, #0xf0
1000d8240:     	mov	x3, x11
1000d8244:     	ldr	w4, [x20, x12]
1000d8248:     	and	x5, x4, #0xf
1000d824c:     	orr	x5, x13, x5
1000d8250:     	ldrb	w5, [x9, x5]
1000d8254:     	ubfx	x6, x4, #4, #4
1000d8258:     	orr	x6, x14, x6
1000d825c:     	ldrb	w6, [x9, x6]
1000d8260:     	ubfx	x7, x4, #8, #4
1000d8264:     	orr	x7, x15, x7
1000d8268:     	ldrb	w7, [x9, x7]
1000d826c:     	add	w5, w5, w6
1000d8270:     	add	w5, w5, w7
1000d8274:     	ubfx	x6, x4, #12, #4
1000d8278:     	orr	x6, x16, x6
1000d827c:     	ldrb	w6, [x9, x6]
1000d8280:     	ubfx	x7, x4, #16, #4
1000d8284:     	orr	x7, x17, x7
1000d8288:     	ldrb	w7, [x9, x7]
1000d828c:     	add	w5, w5, w6
1000d8290:     	add	w5, w5, w7
1000d8294:     	ubfx	x6, x4, #20, #4
1000d8298:     	orr	x6, x0, x6
1000d829c:     	ldrb	w6, [x9, x6]
1000d82a0:     	ubfx	x7, x4, #24, #4
1000d82a4:     	orr	x7, x1, x7
1000d82a8:     	ldrb	w7, [x9, x7]
1000d82ac:     	add	w5, w5, w6
1000d82b0:     	add	w5, w5, w7
1000d82b4:     	orr	x4, x2, x4, lsr #28
1000d82b8:     	ldrb	w4, [x9, x4]
1000d82bc:     	add	w4, w5, w4
1000d82c0:     	scvtf	s0, w4
1000d82c4:     	ldr	s1, [x3]
1000d82c8:     	fadd	s0, s1, s0
1000d82cc:     	str	s0, [x3], #128
1000d82d0:     	add	x12, x12, #4
1000d82d4:     	cmp	x12, #64
1000d82d8:     	b.ne	0x1000d8244 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d82dc:     	add	x10, x10, #1
1000d82e0:     	add	x11, x11, #4
1000d82e4:     	cmp	x10, #32
1000d82e8:     	b.ne	0x1000d81fc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d82ec:     	add	x21, x21, #128
1000d82f0:     	add	x20, x20, #64
1000d82f4:     	cmp	x20, x8
1000d82f8:     	b.ne	0x1000d81f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d82fc:     	add	x1, sp, #8
1000d8300:     	mov	x0, x19
1000d8304:     	mov	w2, #2048
1000d8308:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d830c:     	ldur	x8, [x29, #-56]
1000d8310:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x21c>
1000d8314:     	ldr	x9, [x9, #392]
1000d8318:     	ldr	x9, [x9]
1000d831c:     	cmp	x9, x8
1000d8320:     	b.ne	0x1000d833c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d8324:     	add	sp, sp, #2064
1000d8328:     	ldp	x29, x30, [sp, #48]
1000d832c:     	ldp	x20, x19, [sp, #32]
1000d8330:     	ldp	x22, x21, [sp, #16]
1000d8334:     	ldp	x28, x27, [sp], #64
1000d8338:     	ret
1000d833c:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d85b4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d85b4:     	stp	x28, x27, [sp, #-64]!
1000d85b8:     	stp	x22, x21, [sp, #16]
1000d85bc:     	stp	x20, x19, [sp, #32]
1000d85c0:     	stp	x29, x30, [sp, #48]
1000d85c4:     	add	x29, sp, #48
1000d85c8:     	sub	sp, sp, #2064
1000d85cc:     	mov	x19, x3
1000d85d0:     	mov	x20, x1
1000d85d4:     	mov	x21, x0
1000d85d8:     	adrp	x8, 0x10016c000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xd0>
1000d85dc:     	ldr	x8, [x8, #392]
1000d85e0:     	ldr	x8, [x8]
1000d85e4:     	stur	x8, [x29, #-56]
1000d85e8:     	lsl	x8, x2, #3
1000d85ec:     	and	x22, x8, #0xfffffffffffffff0
1000d85f0:     	add	x0, sp, #8
1000d85f4:     	mov	w1, #2048
1000d85f8:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d85fc:     	cbz	x22, 0x1000d8714 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d8600:     	add	x8, x20, x22
1000d8604:     	adrp	x9, 0x10016a000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0xf4>
1000d8608:     	add	x9, x9, #1980
1000d860c:     	mov	x10, #0
1000d8610:     	add	x11, sp, #8
1000d8614:     	mov	x12, #0
1000d8618:     	ldr	w2, [x21, x10, lsl #2]
1000d861c:     	lsl	w13, w2, #4
1000d8620:     	and	x13, x13, #0xf0
1000d8624:     	and	x14, x2, #0xf0
1000d8628:     	lsr	x15, x2, #4
1000d862c:     	and	x15, x15, #0xf0
1000d8630:     	lsr	x16, x2, #8
1000d8634:     	and	x16, x16, #0xf0
1000d8638:     	lsr	x17, x2, #12
1000d863c:     	and	x17, x17, #0xf0
1000d8640:     	lsr	x0, x2, #16
1000d8644:     	and	x0, x0, #0xf0
1000d8648:     	lsr	x1, x2, #20
1000d864c:     	and	x1, x1, #0xf0
1000d8650:     	lsr	x2, x2, #24
1000d8654:     	and	x2, x2, #0xf0
1000d8658:     	mov	x3, x11
1000d865c:     	ldr	w4, [x20, x12]
1000d8660:     	and	x5, x4, #0xf
1000d8664:     	orr	x5, x13, x5
1000d8668:     	ldrsb	w5, [x9, x5]
1000d866c:     	ubfx	x6, x4, #4, #4
1000d8670:     	orr	x6, x14, x6
1000d8674:     	ldrsb	w6, [x9, x6]
1000d8678:     	ubfx	x7, x4, #8, #4
1000d867c:     	orr	x7, x15, x7
1000d8680:     	ldrsb	w7, [x9, x7]
1000d8684:     	add	w5, w5, w6
1000d8688:     	add	w5, w5, w7
1000d868c:     	ubfx	x6, x4, #12, #4
1000d8690:     	orr	x6, x16, x6
1000d8694:     	ldrsb	w6, [x9, x6]
1000d8698:     	ubfx	x7, x4, #16, #4
1000d869c:     	orr	x7, x17, x7
1000d86a0:     	ldrsb	w7, [x9, x7]
1000d86a4:     	add	w5, w5, w6
1000d86a8:     	add	w5, w5, w7
1000d86ac:     	ubfx	x6, x4, #20, #4
1000d86b0:     	orr	x6, x0, x6
1000d86b4:     	ldrsb	w6, [x9, x6]
1000d86b8:     	ubfx	x7, x4, #24, #4
1000d86bc:     	orr	x7, x1, x7
1000d86c0:     	ldrsb	w7, [x9, x7]
1000d86c4:     	add	w5, w5, w6
1000d86c8:     	add	w5, w5, w7
1000d86cc:     	orr	x4, x2, x4, lsr #28
1000d86d0:     	ldrsb	w4, [x9, x4]
1000d86d4:     	add	w4, w5, w4
1000d86d8:     	scvtf	s0, w4
1000d86dc:     	ldr	s1, [x3]
1000d86e0:     	fadd	s0, s1, s0
1000d86e4:     	str	s0, [x3], #128
1000d86e8:     	add	x12, x12, #4
1000d86ec:     	cmp	x12, #64
1000d86f0:     	b.ne	0x1000d865c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d86f4:     	add	x10, x10, #1
1000d86f8:     	add	x11, x11, #4
1000d86fc:     	cmp	x10, #32
1000d8700:     	b.ne	0x1000d8614 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000d8704:     	add	x21, x21, #128
1000d8708:     	add	x20, x20, #64
1000d870c:     	cmp	x20, x8
1000d8710:     	b.ne	0x1000d860c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000d8714:     	add	x1, sp, #8
1000d8718:     	mov	x0, x19
1000d871c:     	mov	w2, #2048
1000d8720:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d8724:     	ldur	x8, [x29, #-56]
1000d8728:     	adrp	x9, 0x10016c000 <void run<unsigned char, 32ul, 32ul, false>(char const*)+0x220>
1000d872c:     	ldr	x9, [x9, #392]
1000d8730:     	ldr	x9, [x9]
1000d8734:     	cmp	x9, x8
1000d8738:     	b.ne	0x1000d8754 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<16ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1a0>
1000d873c:     	add	sp, sp, #2064
1000d8740:     	ldp	x29, x30, [sp, #48]
1000d8744:     	ldp	x20, x19, [sp, #32]
1000d8748:     	ldp	x22, x21, [sp, #16]
1000d874c:     	ldp	x28, x27, [sp], #64
1000d8750:     	ret
1000d8754:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d9bc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9bc8:     	stp	x28, x27, [sp, #-64]!
1000d9bcc:     	stp	x22, x21, [sp, #16]
1000d9bd0:     	stp	x20, x19, [sp, #32]
1000d9bd4:     	stp	x29, x30, [sp, #48]
1000d9bd8:     	add	x29, sp, #48
1000d9bdc:     	mov	w9, #4112
1000d9be0:     	adrp	x16, 0x10016c000 <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d9be4:     	ldr	x16, [x16, #304]
1000d9be8:     	blr	x16
1000d9bec:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9bf0:     	sub	sp, sp, #16
1000d9bf4:     	mov	x19, x3
1000d9bf8:     	mov	x20, x1
1000d9bfc:     	mov	x21, x0
1000d9c00:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x10>
1000d9c04:     	ldr	x8, [x8, #392]
1000d9c08:     	ldr	x8, [x8]
1000d9c0c:     	stur	x8, [x29, #-56]
1000d9c10:     	lsl	x8, x2, #4
1000d9c14:     	and	x22, x8, #0xffffffffffffffe0
1000d9c18:     	add	x0, sp, #8
1000d9c1c:     	mov	w1, #4096
1000d9c20:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9c24:     	cbz	x22, 0x1000d9d3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d9c28:     	add	x8, x20, x22
1000d9c2c:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x34>
1000d9c30:     	add	x9, x9, #1724
1000d9c34:     	mov	x10, #0
1000d9c38:     	add	x11, sp, #8
1000d9c3c:     	mov	x12, #0
1000d9c40:     	ldr	w2, [x21, x10, lsl #2]
1000d9c44:     	lsl	w13, w2, #4
1000d9c48:     	and	x13, x13, #0xf0
1000d9c4c:     	and	x14, x2, #0xf0
1000d9c50:     	lsr	x15, x2, #4
1000d9c54:     	and	x15, x15, #0xf0
1000d9c58:     	lsr	x16, x2, #8
1000d9c5c:     	and	x16, x16, #0xf0
1000d9c60:     	lsr	x17, x2, #12
1000d9c64:     	and	x17, x17, #0xf0
1000d9c68:     	lsr	x0, x2, #16
1000d9c6c:     	and	x0, x0, #0xf0
1000d9c70:     	lsr	x1, x2, #20
1000d9c74:     	and	x1, x1, #0xf0
1000d9c78:     	lsr	x2, x2, #24
1000d9c7c:     	and	x2, x2, #0xf0
1000d9c80:     	mov	x3, x11
1000d9c84:     	ldr	w4, [x20, x12]
1000d9c88:     	and	x5, x4, #0xf
1000d9c8c:     	orr	x5, x13, x5
1000d9c90:     	ldrb	w5, [x9, x5]
1000d9c94:     	ubfx	x6, x4, #4, #4
1000d9c98:     	orr	x6, x14, x6
1000d9c9c:     	ldrb	w6, [x9, x6]
1000d9ca0:     	ubfx	x7, x4, #8, #4
1000d9ca4:     	orr	x7, x15, x7
1000d9ca8:     	ldrb	w7, [x9, x7]
1000d9cac:     	add	w5, w5, w6
1000d9cb0:     	add	w5, w5, w7
1000d9cb4:     	ubfx	x6, x4, #12, #4
1000d9cb8:     	orr	x6, x16, x6
1000d9cbc:     	ldrb	w6, [x9, x6]
1000d9cc0:     	ubfx	x7, x4, #16, #4
1000d9cc4:     	orr	x7, x17, x7
1000d9cc8:     	ldrb	w7, [x9, x7]
1000d9ccc:     	add	w5, w5, w6
1000d9cd0:     	add	w5, w5, w7
1000d9cd4:     	ubfx	x6, x4, #20, #4
1000d9cd8:     	orr	x6, x0, x6
1000d9cdc:     	ldrb	w6, [x9, x6]
1000d9ce0:     	ubfx	x7, x4, #24, #4
1000d9ce4:     	orr	x7, x1, x7
1000d9ce8:     	ldrb	w7, [x9, x7]
1000d9cec:     	add	w5, w5, w6
1000d9cf0:     	add	w5, w5, w7
1000d9cf4:     	orr	x4, x2, x4, lsr #28
1000d9cf8:     	ldrb	w4, [x9, x4]
1000d9cfc:     	add	w4, w5, w4
1000d9d00:     	scvtf	s0, w4
1000d9d04:     	ldr	s1, [x3]
1000d9d08:     	fadd	s0, s1, s0
1000d9d0c:     	str	s0, [x3], #128
1000d9d10:     	add	x12, x12, #4
1000d9d14:     	cmp	x12, #128
1000d9d18:     	b.ne	0x1000d9c84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d9d1c:     	add	x10, x10, #1
1000d9d20:     	add	x11, x11, #4
1000d9d24:     	cmp	x10, #32
1000d9d28:     	b.ne	0x1000d9c3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d9d2c:     	add	x21, x21, #128
1000d9d30:     	add	x20, x20, #128
1000d9d34:     	cmp	x20, x8
1000d9d38:     	b.ne	0x1000d9c34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d9d3c:     	add	x1, sp, #8
1000d9d40:     	mov	x0, x19
1000d9d44:     	mov	w2, #4096
1000d9d48:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9d4c:     	ldur	x8, [x29, #-56]
1000d9d50:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d9d54:     	ldr	x9, [x9, #392]
1000d9d58:     	ldr	x9, [x9]
1000d9d5c:     	cmp	x9, x8
1000d9d60:     	b.ne	0x1000d9d80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d9d64:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9d68:     	add	sp, sp, #16
1000d9d6c:     	ldp	x29, x30, [sp, #48]
1000d9d70:     	ldp	x20, x19, [sp, #32]
1000d9d74:     	ldp	x22, x21, [sp, #16]
1000d9d78:     	ldp	x28, x27, [sp], #64
1000d9d7c:     	ret
1000d9d80:     	bl	0x100163694 <_strcmp+0x100163694>

00000001000d9e3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9e3c:     	stp	x28, x27, [sp, #-64]!
1000d9e40:     	stp	x22, x21, [sp, #16]
1000d9e44:     	stp	x20, x19, [sp, #32]
1000d9e48:     	stp	x29, x30, [sp, #48]
1000d9e4c:     	add	x29, sp, #48
1000d9e50:     	mov	w9, #4112
1000d9e54:     	adrp	x16, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x34>
1000d9e58:     	ldr	x16, [x16, #304]
1000d9e5c:     	blr	x16
1000d9e60:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9e64:     	sub	sp, sp, #16
1000d9e68:     	mov	x19, x3
1000d9e6c:     	mov	x20, x1
1000d9e70:     	mov	x21, x0
1000d9e74:     	adrp	x8, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x54>
1000d9e78:     	ldr	x8, [x8, #392]
1000d9e7c:     	ldr	x8, [x8]
1000d9e80:     	stur	x8, [x29, #-56]
1000d9e84:     	lsl	x8, x2, #4
1000d9e88:     	and	x22, x8, #0xffffffffffffffe0
1000d9e8c:     	add	x0, sp, #8
1000d9e90:     	mov	w1, #4096
1000d9e94:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9e98:     	cbz	x22, 0x1000d9fb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d9e9c:     	add	x8, x20, x22
1000d9ea0:     	adrp	x9, 0x10016a000 <void run<double, 1ul, 1ul, false>(char const*)+0x78>
1000d9ea4:     	add	x9, x9, #1980
1000d9ea8:     	mov	x10, #0
1000d9eac:     	add	x11, sp, #8
1000d9eb0:     	mov	x12, #0
1000d9eb4:     	ldr	w2, [x21, x10, lsl #2]
1000d9eb8:     	lsl	w13, w2, #4
1000d9ebc:     	and	x13, x13, #0xf0
1000d9ec0:     	and	x14, x2, #0xf0
1000d9ec4:     	lsr	x15, x2, #4
1000d9ec8:     	and	x15, x15, #0xf0
1000d9ecc:     	lsr	x16, x2, #8
1000d9ed0:     	and	x16, x16, #0xf0
1000d9ed4:     	lsr	x17, x2, #12
1000d9ed8:     	and	x17, x17, #0xf0
1000d9edc:     	lsr	x0, x2, #16
1000d9ee0:     	and	x0, x0, #0xf0
1000d9ee4:     	lsr	x1, x2, #20
1000d9ee8:     	and	x1, x1, #0xf0
1000d9eec:     	lsr	x2, x2, #24
1000d9ef0:     	and	x2, x2, #0xf0
1000d9ef4:     	mov	x3, x11
1000d9ef8:     	ldr	w4, [x20, x12]
1000d9efc:     	and	x5, x4, #0xf
1000d9f00:     	orr	x5, x13, x5
1000d9f04:     	ldrsb	w5, [x9, x5]
1000d9f08:     	ubfx	x6, x4, #4, #4
1000d9f0c:     	orr	x6, x14, x6
1000d9f10:     	ldrsb	w6, [x9, x6]
1000d9f14:     	ubfx	x7, x4, #8, #4
1000d9f18:     	orr	x7, x15, x7
1000d9f1c:     	ldrsb	w7, [x9, x7]
1000d9f20:     	add	w5, w5, w6
1000d9f24:     	add	w5, w5, w7
1000d9f28:     	ubfx	x6, x4, #12, #4
1000d9f2c:     	orr	x6, x16, x6
1000d9f30:     	ldrsb	w6, [x9, x6]
1000d9f34:     	ubfx	x7, x4, #16, #4
1000d9f38:     	orr	x7, x17, x7
1000d9f3c:     	ldrsb	w7, [x9, x7]
1000d9f40:     	add	w5, w5, w6
1000d9f44:     	add	w5, w5, w7
1000d9f48:     	ubfx	x6, x4, #20, #4
1000d9f4c:     	orr	x6, x0, x6
1000d9f50:     	ldrsb	w6, [x9, x6]
1000d9f54:     	ubfx	x7, x4, #24, #4
1000d9f58:     	orr	x7, x1, x7
1000d9f5c:     	ldrsb	w7, [x9, x7]
1000d9f60:     	add	w5, w5, w6
1000d9f64:     	add	w5, w5, w7
1000d9f68:     	orr	x4, x2, x4, lsr #28
1000d9f6c:     	ldrsb	w4, [x9, x4]
1000d9f70:     	add	w4, w5, w4
1000d9f74:     	scvtf	s0, w4
1000d9f78:     	ldr	s1, [x3]
1000d9f7c:     	fadd	s0, s1, s0
1000d9f80:     	str	s0, [x3], #128
1000d9f84:     	add	x12, x12, #4
1000d9f88:     	cmp	x12, #128
1000d9f8c:     	b.ne	0x1000d9ef8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d9f90:     	add	x10, x10, #1
1000d9f94:     	add	x11, x11, #4
1000d9f98:     	cmp	x10, #32
1000d9f9c:     	b.ne	0x1000d9eb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d9fa0:     	add	x21, x21, #128
1000d9fa4:     	add	x20, x20, #128
1000d9fa8:     	cmp	x20, x8
1000d9fac:     	b.ne	0x1000d9ea8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d9fb0:     	add	x1, sp, #8
1000d9fb4:     	mov	x0, x19
1000d9fb8:     	mov	w2, #4096
1000d9fbc:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9fc0:     	ldur	x8, [x29, #-56]
1000d9fc4:     	adrp	x9, 0x10016c000 <void run<double, 1ul, 1ul, false>(char const*)+0x1a4>
1000d9fc8:     	ldr	x9, [x9, #392]
1000d9fcc:     	ldr	x9, [x9]
1000d9fd0:     	cmp	x9, x8
1000d9fd4:     	b.ne	0x1000d9ff4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d9fd8:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9fdc:     	add	sp, sp, #16
1000d9fe0:     	ldp	x29, x30, [sp, #48]
1000d9fe4:     	ldp	x20, x19, [sp, #32]
1000d9fe8:     	ldp	x22, x21, [sp, #16]
1000d9fec:     	ldp	x28, x27, [sp], #64
1000d9ff0:     	ret
1000d9ff4:     	bl	0x100163694 <_strcmp+0x100163694>

00000001001155ac <void kernel<short, 1ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
1001155ac:     	b	0x1001155b0 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(short const*, short const*, unsigned long, float*)>

00000001001156a0 <void kernel<short, 1ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001156a0:     	b	0x1001156a4 <zvec::turbo::DistanceMatrix<short, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(short const*, short const*, unsigned long, float*)>

0000000100116bb8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100116bb8:     	stp	d9, d8, [sp, #-16]!
100116bbc:     	cbz	x2, 0x100116bd8 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x20>
100116bc0:     	cmp	x2, #32
100116bc4:     	b.hs	0x100116be4 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x2c>
100116bc8:     	mov	x8, #0
100116bcc:     	movi	d1, #0000000000000000
100116bd0:     	movi	d0, #0000000000000000
100116bd4:     	b	0x100116f38 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x380>
100116bd8:     	str	xzr, [x3]
100116bdc:     	ldp	d9, d8, [sp], #16
100116be0:     	ret
100116be4:     	and	x8, x2, #0xffffffffffffffe0
100116be8:     	add	x9, x1, #32
100116bec:     	add	x10, x0, #64
100116bf0:     	movi	d1, #0000000000000000
100116bf4:     	mov	x11, x8
100116bf8:     	movi	d0, #0000000000000000
100116bfc:     	ldp	q3, q2, [x9, #-32]
100116c00:     	sub	x12, x10, #64
100116c04:     	ld2.8h	{ v27, v28 }, [x12]
100116c08:     	ldp	q5, q4, [x9]
100116c0c:     	sub	x12, x10, #32
100116c10:     	ld2.8h	{ v23, v24 }, [x12]
100116c14:     	mov	x12, x10
100116c18:     	ld2.8h	{ v20, v21 }, [x12], #32
100116c1c:     	ld2.8h	{ v18, v19 }, [x12]
100116c20:     	sshll2.4s	v17, v27, #0
100116c24:     	sshll.4s	v26, v27, #0
100116c28:     	sshll2.4s	v16, v23, #0
100116c2c:     	sshll.4s	v25, v23, #0
100116c30:     	sshll2.4s	v7, v20, #0
100116c34:     	sshll.4s	v22, v20, #0
100116c38:     	sshll2.4s	v6, v18, #0
100116c3c:     	sshll2.4s	v29, v28, #0
100116c40:     	sshll.4s	v30, v18, #0
100116c44:     	sshll.4s	v27, v28, #0
100116c48:     	sshll2.4s	v28, v24, #0
100116c4c:     	sshll.4s	v23, v24, #0
100116c50:     	sshll2.4s	v24, v21, #0
100116c54:     	sshll.4s	v21, v21, #0
100116c58:     	sshll2.4s	v31, v19, #0
100116c5c:     	sshll.4s	v8, v19, #0
100116c60:     	sshll.4s	v18, v3, #0
100116c64:     	scvtf.4s	v18, v18
100116c68:     	scvtf.4s	v19, v26
100116c6c:     	scvtf.4s	v26, v27
100116c70:     	fsub.4s	v20, v19, v18
100116c74:     	fsub.4s	v26, v26, v18
100116c78:     	sshll2.4s	v3, v3, #0
100116c7c:     	scvtf.4s	v3, v3
100116c80:     	scvtf.4s	v17, v17
100116c84:     	scvtf.4s	v18, v29
100116c88:     	fsub.4s	v19, v17, v3
100116c8c:     	fsub.4s	v27, v18, v3
100116c90:     	sshll.4s	v3, v2, #0
100116c94:     	scvtf.4s	v3, v3
100116c98:     	scvtf.4s	v17, v25
100116c9c:     	scvtf.4s	v23, v23
100116ca0:     	fsub.4s	v18, v17, v3
100116ca4:     	fsub.4s	v23, v23, v3
100116ca8:     	sshll2.4s	v2, v2, #0
100116cac:     	scvtf.4s	v2, v2
100116cb0:     	scvtf.4s	v3, v16
100116cb4:     	scvtf.4s	v16, v28
100116cb8:     	fsub.4s	v17, v3, v2
100116cbc:     	fsub.4s	v25, v16, v2
100116cc0:     	sshll.4s	v2, v5, #0
100116cc4:     	scvtf.4s	v2, v2
100116cc8:     	scvtf.4s	v3, v22
100116ccc:     	scvtf.4s	v21, v21
100116cd0:     	fsub.4s	v16, v3, v2
100116cd4:     	fsub.4s	v21, v21, v2
100116cd8:     	sshll2.4s	v2, v5, #0
100116cdc:     	scvtf.4s	v2, v2
100116ce0:     	scvtf.4s	v3, v7
100116ce4:     	scvtf.4s	v7, v24
100116ce8:     	fsub.4s	v5, v3, v2
100116cec:     	fsub.4s	v7, v7, v2
100116cf0:     	sshll.4s	v2, v4, #0
100116cf4:     	scvtf.4s	v2, v2
100116cf8:     	scvtf.4s	v3, v30
100116cfc:     	scvtf.4s	v22, v8
100116d00:     	fsub.4s	v3, v3, v2
100116d04:     	fsub.4s	v22, v22, v2
100116d08:     	sshll2.4s	v2, v4, #0
100116d0c:     	scvtf.4s	v4, v2
100116d10:     	scvtf.4s	v2, v6
100116d14:     	scvtf.4s	v6, v31
100116d18:     	fsub.4s	v2, v2, v4
100116d1c:     	fsub.4s	v4, v6, v4
100116d20:     	fmul.4s	v6, v26, v26
100116d24:     	mov	s24, v6[1]
100116d28:     	fadd	s1, s1, s6
100116d2c:     	fadd	s1, s1, s24
100116d30:     	mov	s24, v6[2]
100116d34:     	fadd	s1, s1, s24
100116d38:     	fmul.4s	v24, v27, v27
100116d3c:     	mov	s6, v6[3]
100116d40:     	fadd	s1, s1, s6
100116d44:     	mov	s6, v24[1]
100116d48:     	fadd	s1, s1, s24
100116d4c:     	fadd	s1, s1, s6
100116d50:     	mov	s6, v24[2]
100116d54:     	fadd	s1, s1, s6
100116d58:     	mov	s6, v24[3]
100116d5c:     	fmul.4s	v23, v23, v23
100116d60:     	fadd	s1, s1, s6
100116d64:     	mov	s6, v23[1]
100116d68:     	fadd	s1, s1, s23
100116d6c:     	fadd	s1, s1, s6
100116d70:     	mov	s6, v23[2]
100116d74:     	fadd	s1, s1, s6
100116d78:     	fmul.4s	v6, v25, v25
100116d7c:     	mov	s23, v23[3]
100116d80:     	fadd	s1, s1, s23
100116d84:     	mov	s23, v6[1]
100116d88:     	fadd	s1, s1, s6
100116d8c:     	fadd	s1, s1, s23
100116d90:     	mov	s23, v6[2]
100116d94:     	fadd	s1, s1, s23
100116d98:     	mov	s6, v6[3]
100116d9c:     	fmul.4s	v21, v21, v21
100116da0:     	fadd	s1, s1, s6
100116da4:     	mov	s6, v21[1]
100116da8:     	fadd	s1, s1, s21
100116dac:     	fadd	s1, s1, s6
100116db0:     	mov	s6, v21[2]
100116db4:     	fadd	s1, s1, s6
100116db8:     	fmul.4s	v6, v7, v7
100116dbc:     	mov	s7, v21[3]
100116dc0:     	fadd	s1, s1, s7
100116dc4:     	mov	s7, v6[1]
100116dc8:     	fadd	s1, s1, s6
100116dcc:     	fadd	s1, s1, s7
100116dd0:     	mov	s7, v6[2]
100116dd4:     	fadd	s1, s1, s7
100116dd8:     	fmul.4s	v7, v20, v20
100116ddc:     	mov	s6, v6[3]
100116de0:     	fmul.4s	v20, v22, v22
100116de4:     	fadd	s1, s1, s6
100116de8:     	mov	s6, v20[1]
100116dec:     	fadd	s1, s1, s20
100116df0:     	fadd	s1, s1, s6
100116df4:     	mov	s6, v20[2]
100116df8:     	fadd	s1, s1, s6
100116dfc:     	mov	s6, v7[1]
100116e00:     	fadd	s0, s0, s7
100116e04:     	fadd	s0, s0, s6
100116e08:     	mov	s6, v7[2]
100116e0c:     	fadd	s0, s0, s6
100116e10:     	mov	s6, v7[3]
100116e14:     	fadd	s0, s0, s6
100116e18:     	fmul.4s	v6, v19, v19
100116e1c:     	mov	s7, v20[3]
100116e20:     	fadd	s1, s1, s7
100116e24:     	mov	s7, v6[1]
100116e28:     	fadd	s0, s0, s6
100116e2c:     	fadd	s0, s0, s7
100116e30:     	mov	s7, v6[2]
100116e34:     	fadd	s0, s0, s7
100116e38:     	mov	s6, v6[3]
100116e3c:     	fmul.4s	v7, v18, v18
100116e40:     	fmul.4s	v4, v4, v4
100116e44:     	fadd	s0, s0, s6
100116e48:     	mov	s6, v4[1]
100116e4c:     	fadd	s1, s1, s4
100116e50:     	fadd	s1, s1, s6
100116e54:     	mov	s6, v7[1]
100116e58:     	fadd	s0, s0, s7
100116e5c:     	fadd	s0, s0, s6
100116e60:     	mov	s6, v7[2]
100116e64:     	fadd	s0, s0, s6
100116e68:     	fmul.4s	v6, v17, v17
100116e6c:     	mov	s7, v7[3]
100116e70:     	fadd	s0, s0, s7
100116e74:     	mov	s7, v6[1]
100116e78:     	fadd	s0, s0, s6
100116e7c:     	fadd	s0, s0, s7
100116e80:     	mov	s7, v6[2]
100116e84:     	fadd	s0, s0, s7
100116e88:     	mov	s6, v6[3]
100116e8c:     	fmul.4s	v7, v16, v16
100116e90:     	fadd	s0, s0, s6
100116e94:     	mov	s6, v4[2]
100116e98:     	fadd	s1, s1, s6
100116e9c:     	mov	s6, v7[1]
100116ea0:     	fadd	s0, s0, s7
100116ea4:     	fadd	s0, s0, s6
100116ea8:     	mov	s6, v7[2]
100116eac:     	fadd	s0, s0, s6
100116eb0:     	fmul.4s	v5, v5, v5
100116eb4:     	mov	s6, v7[3]
100116eb8:     	fadd	s0, s0, s6
100116ebc:     	mov	s6, v5[1]
100116ec0:     	fadd	s0, s0, s5
100116ec4:     	fadd	s0, s0, s6
100116ec8:     	mov	s6, v5[2]
100116ecc:     	fadd	s0, s0, s6
100116ed0:     	mov	s5, v5[3]
100116ed4:     	fadd	s0, s0, s5
100116ed8:     	fmul.4s	v3, v3, v3
100116edc:     	mov	s4, v4[3]
100116ee0:     	fadd	s1, s1, s4
100116ee4:     	mov	s4, v3[1]
100116ee8:     	fadd	s0, s0, s3
100116eec:     	fadd	s0, s0, s4
100116ef0:     	mov	s4, v3[2]
100116ef4:     	fadd	s0, s0, s4
100116ef8:     	fmul.4s	v2, v2, v2
100116efc:     	mov	s3, v3[3]
100116f00:     	fadd	s0, s0, s3
100116f04:     	mov	s3, v2[1]
100116f08:     	fadd	s0, s0, s2
100116f0c:     	fadd	s0, s0, s3
100116f10:     	mov	s3, v2[2]
100116f14:     	fadd	s0, s0, s3
100116f18:     	mov	s2, v2[3]
100116f1c:     	fadd	s0, s0, s2
100116f20:     	add	x9, x9, #64
100116f24:     	add	x10, x10, #128
100116f28:     	subs	x11, x11, #32
100116f2c:     	b.ne	0x100116bfc <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x44>
100116f30:     	cmp	x8, x2
100116f34:     	b.eq	0x100116f84 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
100116f38:     	sub	x9, x2, x8
100116f3c:     	add	x10, x0, x8, lsl #2
100116f40:     	add	x10, x10, #2
100116f44:     	add	x8, x1, x8, lsl #1
100116f48:     	ldrsh	w11, [x8], #2
100116f4c:     	scvtf	s2, w11
100116f50:     	ldur	h3, [x10, #-2]
100116f54:     	sshll.4s	v3, v3, #0
100116f58:     	scvtf	s3, s3
100116f5c:     	fsub	s3, s3, s2
100116f60:     	fmadd	s0, s3, s3, s0
100116f64:     	ldr	h3, [x10]
100116f68:     	sshll.4s	v3, v3, #0
100116f6c:     	scvtf	s3, s3
100116f70:     	fsub	s2, s3, s2
100116f74:     	fmadd	s1, s2, s2, s1
100116f78:     	add	x10, x10, #4
100116f7c:     	subs	x9, x9, #1
100116f80:     	b.ne	0x100116f48 <void kernel<short, 2ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
100116f84:     	stp	s0, s1, [x3]
100116f88:     	ldp	d9, d8, [sp], #16
100116f8c:     	ret

0000000100116f90 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
100116f90:     	cbz	x2, 0x100116fac <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x1c>
100116f94:     	cmp	x2, #32
100116f98:     	b.hs	0x100116fb4 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x24>
100116f9c:     	mov	x8, #0
100116fa0:     	movi	d1, #0000000000000000
100116fa4:     	movi	d0, #0000000000000000
100116fa8:     	b	0x100117308 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x378>
100116fac:     	str	xzr, [x3]
100116fb0:     	ret
100116fb4:     	and	x8, x2, #0xffffffffffffffe0
100116fb8:     	add	x9, x1, #32
100116fbc:     	add	x10, x0, #64
100116fc0:     	movi	d1, #0000000000000000
100116fc4:     	mov	x11, x8
100116fc8:     	movi	d0, #0000000000000000
100116fcc:     	ldp	q4, q2, [x9, #-32]
100116fd0:     	sub	x12, x10, #64
100116fd4:     	ld2.8h	{ v27, v28 }, [x12]
100116fd8:     	ldp	q5, q3, [x9]
100116fdc:     	sub	x12, x10, #32
100116fe0:     	ld2.8h	{ v25, v26 }, [x12]
100116fe4:     	mov	x12, x10
100116fe8:     	ld2.8h	{ v22, v23 }, [x12], #32
100116fec:     	ld2.8h	{ v20, v21 }, [x12]
100116ff0:     	sshll2.4s	v24, v27, #0
100116ff4:     	sshll.4s	v19, v27, #0
100116ff8:     	sshll2.4s	v18, v25, #0
100116ffc:     	sshll.4s	v17, v25, #0
100117000:     	sshll2.4s	v16, v22, #0
100117004:     	sshll.4s	v7, v22, #0
100117008:     	sshll2.4s	v6, v20, #0
10011700c:     	sshll2.4s	v30, v28, #0
100117010:     	sshll.4s	v29, v20, #0
100117014:     	sshll.4s	v27, v28, #0
100117018:     	sshll2.4s	v28, v26, #0
10011701c:     	sshll.4s	v25, v26, #0
100117020:     	sshll2.4s	v26, v23, #0
100117024:     	sshll.4s	v22, v23, #0
100117028:     	sshll2.4s	v23, v21, #0
10011702c:     	sshll.4s	v21, v21, #0
100117030:     	sshll2.4s	v20, v4, #0
100117034:     	scvtf.4s	v31, v20
100117038:     	scvtf.4s	v20, v24
10011703c:     	fneg.4s	v20, v20
100117040:     	fmul.4s	v20, v20, v31
100117044:     	scvtf.4s	v24, v30
100117048:     	fneg.4s	v24, v24
10011704c:     	fmul.4s	v24, v24, v31
100117050:     	sshll.4s	v4, v4, #0
100117054:     	scvtf.4s	v4, v4
100117058:     	scvtf.4s	v19, v19
10011705c:     	fneg.4s	v19, v19
100117060:     	fmul.4s	v19, v19, v4
100117064:     	scvtf.4s	v27, v27
100117068:     	fneg.4s	v27, v27
10011706c:     	fmul.4s	v27, v27, v4
100117070:     	sshll2.4s	v4, v2, #0
100117074:     	scvtf.4s	v30, v4
100117078:     	scvtf.4s	v4, v18
10011707c:     	fneg.4s	v4, v4
100117080:     	scvtf.4s	v18, v28
100117084:     	fneg.4s	v18, v18
100117088:     	fmul.4s	v4, v4, v30
10011708c:     	fmul.4s	v18, v18, v30
100117090:     	sshll.4s	v2, v2, #0
100117094:     	scvtf.4s	v2, v2
100117098:     	scvtf.4s	v17, v17
10011709c:     	fneg.4s	v17, v17
1001170a0:     	fmul.4s	v17, v17, v2
1001170a4:     	scvtf.4s	v25, v25
1001170a8:     	fneg.4s	v25, v25
1001170ac:     	fmul.4s	v25, v25, v2
1001170b0:     	sshll2.4s	v2, v5, #0
1001170b4:     	scvtf.4s	v16, v16
1001170b8:     	scvtf.4s	v28, v2
1001170bc:     	fneg.4s	v2, v16
1001170c0:     	fmul.4s	v2, v2, v28
1001170c4:     	scvtf.4s	v16, v26
1001170c8:     	fneg.4s	v16, v16
1001170cc:     	fmul.4s	v16, v16, v28
1001170d0:     	sshll.4s	v5, v5, #0
1001170d4:     	scvtf.4s	v5, v5
1001170d8:     	scvtf.4s	v7, v7
1001170dc:     	fneg.4s	v7, v7
1001170e0:     	scvtf.4s	v22, v22
1001170e4:     	fneg.4s	v22, v22
1001170e8:     	fmul.4s	v7, v7, v5
1001170ec:     	fmul.4s	v22, v22, v5
1001170f0:     	sshll2.4s	v5, v3, #0
1001170f4:     	scvtf.4s	v26, v5
1001170f8:     	scvtf.4s	v5, v6
1001170fc:     	fneg.4s	v5, v5
100117100:     	fmul.4s	v5, v5, v26
100117104:     	scvtf.4s	v6, v23
100117108:     	fneg.4s	v6, v6
10011710c:     	fmul.4s	v6, v6, v26
100117110:     	sshll.4s	v3, v3, #0
100117114:     	scvtf.4s	v3, v3
100117118:     	scvtf.4s	v23, v29
10011711c:     	fneg.4s	v23, v23
100117120:     	fmul.4s	v23, v23, v3
100117124:     	scvtf.4s	v21, v21
100117128:     	fneg.4s	v21, v21
10011712c:     	fmul.4s	v3, v21, v3
100117130:     	mov	s21, v27[1]
100117134:     	fadd	s1, s1, s27
100117138:     	fadd	s1, s1, s21
10011713c:     	mov	s21, v27[2]
100117140:     	fadd	s1, s1, s21
100117144:     	mov	s21, v27[3]
100117148:     	fadd	s1, s1, s21
10011714c:     	mov	s21, v24[1]
100117150:     	fadd	s1, s1, s24
100117154:     	fadd	s1, s1, s21
100117158:     	mov	s21, v24[2]
10011715c:     	fadd	s1, s1, s21
100117160:     	mov	s21, v24[3]
100117164:     	fadd	s1, s1, s21
100117168:     	mov	s21, v25[1]
10011716c:     	fadd	s1, s1, s25
100117170:     	fadd	s1, s1, s21
100117174:     	mov	s21, v25[2]
100117178:     	fadd	s1, s1, s21
10011717c:     	mov	s21, v25[3]
100117180:     	fadd	s1, s1, s21
100117184:     	mov	s21, v18[1]
100117188:     	fadd	s1, s1, s18
10011718c:     	fadd	s1, s1, s21
100117190:     	mov	s21, v18[2]
100117194:     	fadd	s1, s1, s21
100117198:     	mov	s18, v18[3]
10011719c:     	fadd	s1, s1, s18
1001171a0:     	mov	s18, v22[1]
1001171a4:     	fadd	s1, s1, s22
1001171a8:     	fadd	s1, s1, s18
1001171ac:     	mov	s18, v22[2]
1001171b0:     	fadd	s1, s1, s18
1001171b4:     	mov	s18, v22[3]
1001171b8:     	fadd	s1, s1, s18
1001171bc:     	mov	s18, v16[1]
1001171c0:     	fadd	s1, s1, s16
1001171c4:     	fadd	s1, s1, s18
1001171c8:     	mov	s18, v16[2]
1001171cc:     	fadd	s1, s1, s18
1001171d0:     	mov	s16, v16[3]
1001171d4:     	fadd	s1, s1, s16
1001171d8:     	mov	s16, v3[1]
1001171dc:     	fadd	s1, s1, s3
1001171e0:     	fadd	s1, s1, s16
1001171e4:     	mov	s16, v3[2]
1001171e8:     	fadd	s1, s1, s16
1001171ec:     	fadd	s0, s0, s19
1001171f0:     	mov	s16, v19[1]
1001171f4:     	fadd	s0, s0, s16
1001171f8:     	mov	s16, v19[2]
1001171fc:     	fadd	s0, s0, s16
100117200:     	mov	s16, v19[3]
100117204:     	fadd	s0, s0, s16
100117208:     	mov	s16, v20[1]
10011720c:     	fadd	s0, s0, s20
100117210:     	fadd	s0, s0, s16
100117214:     	mov	s16, v20[2]
100117218:     	fadd	s0, s0, s16
10011721c:     	mov	s3, v3[3]
100117220:     	fadd	s1, s1, s3
100117224:     	mov	s3, v20[3]
100117228:     	fadd	s0, s0, s3
10011722c:     	mov	s3, v17[1]
100117230:     	fadd	s0, s0, s17
100117234:     	fadd	s0, s0, s3
100117238:     	mov	s3, v17[2]
10011723c:     	fadd	s0, s0, s3
100117240:     	mov	s3, v17[3]
100117244:     	fadd	s0, s0, s3
100117248:     	mov	s3, v6[1]
10011724c:     	fadd	s1, s1, s6
100117250:     	fadd	s1, s1, s3
100117254:     	mov	s3, v4[1]
100117258:     	fadd	s0, s0, s4
10011725c:     	fadd	s0, s0, s3
100117260:     	mov	s3, v4[2]
100117264:     	fadd	s0, s0, s3
100117268:     	mov	s3, v4[3]
10011726c:     	fadd	s0, s0, s3
100117270:     	mov	s3, v7[1]
100117274:     	fadd	s0, s0, s7
100117278:     	fadd	s0, s0, s3
10011727c:     	mov	s3, v6[2]
100117280:     	fadd	s1, s1, s3
100117284:     	mov	s3, v7[2]
100117288:     	fadd	s0, s0, s3
10011728c:     	mov	s3, v7[3]
100117290:     	fadd	s0, s0, s3
100117294:     	fadd	s0, s0, s2
100117298:     	mov	s3, v2[1]
10011729c:     	fadd	s0, s0, s3
1001172a0:     	mov	s3, v2[2]
1001172a4:     	fadd	s0, s0, s3
1001172a8:     	mov	s2, v2[3]
1001172ac:     	fadd	s0, s0, s2
1001172b0:     	mov	s2, v23[1]
1001172b4:     	fadd	s0, s0, s23
1001172b8:     	fadd	s0, s0, s2
1001172bc:     	mov	s2, v23[2]
1001172c0:     	fadd	s0, s0, s2
1001172c4:     	mov	s2, v6[3]
1001172c8:     	fadd	s1, s1, s2
1001172cc:     	mov	s2, v23[3]
1001172d0:     	fadd	s0, s0, s2
1001172d4:     	mov	s2, v5[1]
1001172d8:     	fadd	s0, s0, s5
1001172dc:     	fadd	s0, s0, s2
1001172e0:     	mov	s2, v5[2]
1001172e4:     	fadd	s0, s0, s2
1001172e8:     	mov	s2, v5[3]
1001172ec:     	fadd	s0, s0, s2
1001172f0:     	add	x9, x9, #64
1001172f4:     	add	x10, x10, #128
1001172f8:     	subs	x11, x11, #32
1001172fc:     	b.ne	0x100116fcc <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3c>
100117300:     	cmp	x8, x2
100117304:     	b.eq	0x10011734c <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x3bc>
100117308:     	sub	x9, x2, x8
10011730c:     	add	x10, x0, x8, lsl #2
100117310:     	add	x10, x10, #2
100117314:     	add	x8, x1, x8, lsl #1
100117318:     	ldrsh	w11, [x8], #2
10011731c:     	scvtf	s2, w11
100117320:     	ldur	h3, [x10, #-2]
100117324:     	sshll.4s	v3, v3, #0
100117328:     	scvtf	s3, s3
10011732c:     	fmsub	s0, s3, s2, s0
100117330:     	ldr	h3, [x10]
100117334:     	sshll.4s	v3, v3, #0
100117338:     	scvtf	s3, s3
10011733c:     	fmsub	s1, s3, s2, s1
100117340:     	add	x10, x10, #4
100117344:     	subs	x9, x9, #1
100117348:     	b.ne	0x100117318 <void kernel<short, 2ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x388>
10011734c:     	stp	s0, s1, [x3]
100117350:     	ret

0000000100118eb8 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
100118eb8:     	cbz	x2, 0x100118f18 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x60>
100118ebc:     	ldrsh	w8, [x1]
100118ec0:     	fmov	s0, w8
100118ec4:     	ldrsh	w8, [x1, #2]
100118ec8:     	mov.s	v0[1], w8
100118ecc:     	scvtf.2s	v0, v0
100118ed0:     	zip1.4s	v0, v0, v0
100118ed4:     	ldrsh	w8, [x0]
100118ed8:     	fmov	s1, w8
100118edc:     	ldrsh	w8, [x0, #2]
100118ee0:     	mov.s	v1[1], w8
100118ee4:     	scvtf.2s	v1, v1
100118ee8:     	mov.d	v1[1], v1[0]
100118eec:     	fsub.4s	v0, v1, v0
100118ef0:     	fmul.4s	v0, v0, v0
100118ef4:     	str	q0, [x3]
100118ef8:     	subs	x11, x2, #1
100118efc:     	b.eq	0x10011912c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x274>
100118f00:     	cmp	x2, #9
100118f04:     	b.hs	0x100118f20 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x68>
100118f08:     	mov	w8, #1
100118f0c:     	mov	x9, x1
100118f10:     	mov	x10, x0
100118f14:     	b	0x1001190d0 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x218>
100118f18:     	stp	xzr, xzr, [x3]
100118f1c:     	ret
100118f20:     	and	x12, x11, #0xfffffffffffffff8
100118f24:     	lsl	x8, x12, #2
100118f28:     	add	x9, x1, x8
100118f2c:     	add	x10, x0, x8
100118f30:     	orr	x8, x12, #0x1
100118f34:     	mov	s3, v0[1]
100118f38:     	mov	s2, v0[2]
100118f3c:     	mov	s1, v0[3]
100118f40:     	add	x13, x0, #4
100118f44:     	add	x14, x1, #4
100118f48:     	mov	x15, x12
100118f4c:     	ld2.8h	{ v4, v5 }, [x13], #32
100118f50:     	sshll2.4s	v6, v4, #0
100118f54:     	scvtf.4s	v6, v6
100118f58:     	sshll.4s	v7, v4, #0
100118f5c:     	scvtf.4s	v7, v7
100118f60:     	ld2.8h	{ v16, v17 }, [x14], #32
100118f64:     	sshll2.4s	v18, v16, #0
100118f68:     	scvtf.4s	v18, v18
100118f6c:     	sshll.4s	v19, v16, #0
100118f70:     	scvtf.4s	v19, v19
100118f74:     	sshll2.4s	v20, v17, #0
100118f78:     	sshll.4s	v16, v17, #0
100118f7c:     	sshll2.4s	v17, v5, #0
100118f80:     	sshll.4s	v4, v5, #0
100118f84:     	fsub.4s	v5, v7, v19
100118f88:     	scvtf.4s	v16, v16
100118f8c:     	fsub.4s	v7, v7, v16
100118f90:     	scvtf.4s	v4, v4
100118f94:     	fsub.4s	v19, v4, v19
100118f98:     	fsub.4s	v4, v4, v16
100118f9c:     	fsub.4s	v16, v6, v18
100118fa0:     	scvtf.4s	v20, v20
100118fa4:     	fsub.4s	v6, v6, v20
100118fa8:     	scvtf.4s	v17, v17
100118fac:     	fsub.4s	v18, v17, v18
100118fb0:     	fsub.4s	v17, v17, v20
100118fb4:     	fmul.4s	v4, v4, v4
100118fb8:     	mov	s20, v4[1]
100118fbc:     	fadd	s1, s1, s4
100118fc0:     	fadd	s1, s1, s20
100118fc4:     	mov	s20, v4[2]
100118fc8:     	fadd	s1, s1, s20
100118fcc:     	fmul.4s	v17, v17, v17
100118fd0:     	mov	s4, v4[3]
100118fd4:     	fadd	s1, s1, s4
100118fd8:     	mov	s4, v17[1]
100118fdc:     	fadd	s1, s1, s17
100118fe0:     	fadd	s1, s1, s4
100118fe4:     	mov	s4, v17[2]
100118fe8:     	fadd	s1, s1, s4
100118fec:     	fmul.4s	v4, v19, v19
100118ff0:     	mov	s17, v17[3]
100118ff4:     	fadd	s1, s1, s17
100118ff8:     	mov	s17, v4[1]
100118ffc:     	fadd	s3, s3, s4
100119000:     	fadd	s3, s3, s17
100119004:     	mov	s17, v4[2]
100119008:     	fadd	s3, s3, s17
10011900c:     	fmul.4s	v17, v18, v18
100119010:     	mov	s4, v4[3]
100119014:     	fadd	s3, s3, s4
100119018:     	mov	s4, v17[1]
10011901c:     	fadd	s3, s3, s17
100119020:     	fadd	s3, s3, s4
100119024:     	mov	s4, v17[2]
100119028:     	fadd	s3, s3, s4
10011902c:     	fmul.4s	v4, v7, v7
100119030:     	mov	s7, v17[3]
100119034:     	fadd	s3, s3, s7
100119038:     	mov	s7, v4[1]
10011903c:     	fadd	s2, s2, s4
100119040:     	fadd	s2, s2, s7
100119044:     	mov	s7, v4[2]
100119048:     	fadd	s2, s2, s7
10011904c:     	fmul.4s	v6, v6, v6
100119050:     	mov	s4, v4[3]
100119054:     	fadd	s2, s2, s4
100119058:     	mov	s4, v6[1]
10011905c:     	fadd	s2, s2, s6
100119060:     	fadd	s2, s2, s4
100119064:     	mov	s4, v6[2]
100119068:     	fadd	s2, s2, s4
10011906c:     	fmul.4s	v4, v5, v5
100119070:     	mov	s5, v6[3]
100119074:     	fadd	s2, s2, s5
100119078:     	mov	s5, v4[1]
10011907c:     	fadd	s0, s0, s4
100119080:     	fadd	s0, s0, s5
100119084:     	mov	s5, v4[2]
100119088:     	fadd	s0, s0, s5
10011908c:     	fmul.4s	v5, v16, v16
100119090:     	mov	s4, v4[3]
100119094:     	fadd	s0, s0, s4
100119098:     	mov	s4, v5[1]
10011909c:     	fadd	s0, s0, s5
1001190a0:     	fadd	s0, s0, s4
1001190a4:     	mov	s4, v5[3]
1001190a8:     	mov	s5, v5[2]
1001190ac:     	fadd	s0, s0, s5
1001190b0:     	fadd	s0, s0, s4
1001190b4:     	subs	x15, x15, #8
1001190b8:     	b.ne	0x100118f4c <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x94>
1001190bc:     	mov.s	v0[1], v3[0]
1001190c0:     	mov.s	v0[2], v2[0]
1001190c4:     	mov.s	v0[3], v1[0]
1001190c8:     	cmp	x11, x12
1001190cc:     	b.eq	0x100119128 <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x270>
1001190d0:     	add	x9, x9, #4
1001190d4:     	add	x10, x10, #4
1001190d8:     	sub	x8, x2, x8
1001190dc:     	ldrsh	w11, [x9]
1001190e0:     	fmov	s1, w11
1001190e4:     	ldrsh	w11, [x9, #2]
1001190e8:     	mov.s	v1[1], w11
1001190ec:     	scvtf.2s	v1, v1
1001190f0:     	zip1.4s	v1, v1, v1
1001190f4:     	ldrsh	w11, [x10]
1001190f8:     	fmov	s2, w11
1001190fc:     	ldrsh	w11, [x10, #2]
100119100:     	mov.s	v2[1], w11
100119104:     	scvtf.2s	v2, v2
100119108:     	mov.d	v2[1], v2[0]
10011910c:     	fsub.4s	v1, v2, v1
100119110:     	fmul.4s	v1, v1, v1
100119114:     	fadd.4s	v0, v0, v1
100119118:     	add	x9, x9, #4
10011911c:     	add	x10, x10, #4
100119120:     	subs	x8, x8, #1
100119124:     	b.ne	0x1001190dc <void kernel<short, 2ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x224>
100119128:     	str	q0, [x3]
10011912c:     	ret

0000000100119130 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
100119130:     	cbz	x2, 0x1001191d0 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0xa0>
100119134:     	ldrsh	w8, [x1, #2]
100119138:     	ldrsh	w9, [x1]
10011913c:     	fmov	s0, w9
100119140:     	mov.s	v0[1], w8
100119144:     	ldrsh	w8, [x0, #2]
100119148:     	ldrsh	w9, [x0]
10011914c:     	fmov	s1, w9
100119150:     	mov.s	v1[1], w8
100119154:     	mov.s	v1[2], w9
100119158:     	mov.s	v1[3], w8
10011915c:     	zip1.4s	v0, v0, v0
100119160:     	mul.4s	v0, v1, v0
100119164:     	scvtf.4s	v0, v0
100119168:     	fneg.4s	v0, v0
10011916c:     	str	q0, [x3]
100119170:     	subs	x8, x2, #1
100119174:     	b.eq	0x1001191cc <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x9c>
100119178:     	add	x9, x0, #4
10011917c:     	add	x10, x1, #4
100119180:     	ldrsh	w11, [x10, #2]
100119184:     	ldrsh	w12, [x10]
100119188:     	fmov	s1, w12
10011918c:     	mov.s	v1[1], w11
100119190:     	zip1.4s	v1, v1, v1
100119194:     	ldrsh	w11, [x9, #2]
100119198:     	ldrsh	w12, [x9]
10011919c:     	fmov	s2, w12
1001191a0:     	mov.s	v2[1], w11
1001191a4:     	mov.s	v2[2], w12
1001191a8:     	mov.s	v2[3], w11
1001191ac:     	mul.4s	v1, v2, v1
1001191b0:     	scvtf.4s	v1, v1
1001191b4:     	fsub.4s	v0, v0, v1
1001191b8:     	add	x9, x9, #4
1001191bc:     	add	x10, x10, #4
1001191c0:     	subs	x8, x8, #1
1001191c4:     	b.ne	0x100119180 <void kernel<short, 2ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x50>
1001191c8:     	str	q0, [x3]
1001191cc:     	ret
1001191d0:     	stp	xzr, xzr, [x3]
1001191d4:     	ret

000000010011aa74 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
10011aa74:     	cbz	x2, 0x10011aabc <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x48>
10011aa78:     	ldr	h0, [x1]
10011aa7c:     	sshll.4s	v0, v0, #0
10011aa80:     	scvtf	s0, s0
10011aa84:     	ldr	d1, [x0]
10011aa88:     	sshll.4s	v1, v1, #0
10011aa8c:     	scvtf.4s	v1, v1
10011aa90:     	dup.4s	v0, v0[0]
10011aa94:     	fsub.4s	v0, v1, v0
10011aa98:     	fmul.4s	v0, v0, v0
10011aa9c:     	str	q0, [x3]
10011aaa0:     	subs	x10, x2, #1
10011aaa4:     	b.eq	0x10011ae40 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3cc>
10011aaa8:     	cmp	x2, #17
10011aaac:     	b.hs	0x10011aac4 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x50>
10011aab0:     	mov	w8, #1
10011aab4:     	mov	x9, x1
10011aab8:     	b	0x10011ae04 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x390>
10011aabc:     	stp	xzr, xzr, [x3]
10011aac0:     	ret
10011aac4:     	and	x11, x10, #0xfffffffffffffff0
10011aac8:     	add	x9, x1, x11, lsl #1
10011aacc:     	orr	x8, x11, #0x1
10011aad0:     	mov	s1, v0[1]
10011aad4:     	mov	s2, v0[2]
10011aad8:     	mov	s3, v0[3]
10011aadc:     	add	x12, x0, #72
10011aae0:     	add	x13, x1, #18
10011aae4:     	mov	x14, x11
10011aae8:     	add	x0, x0, x11, lsl #3
10011aaec:     	sub	x15, x12, #64
10011aaf0:     	ld4.8h	{ v16, v17, v18, v19 }, [x15]
10011aaf4:     	ld4.8h	{ v20, v21, v22, v23 }, [x12]
10011aaf8:     	sshll2.4s	v5, v16, #0
10011aafc:     	sshll2.4s	v4, v20, #0
10011ab00:     	sshll.4s	v7, v16, #0
10011ab04:     	sshll.4s	v6, v20, #0
10011ab08:     	sshll2.4s	v25, v17, #0
10011ab0c:     	sshll.4s	v27, v17, #0
10011ab10:     	sshll2.4s	v24, v21, #0
10011ab14:     	sshll.4s	v26, v21, #0
10011ab18:     	sshll2.4s	v28, v18, #0
10011ab1c:     	sshll.4s	v29, v18, #0
10011ab20:     	sshll2.4s	v30, v19, #0
10011ab24:     	sshll.4s	v16, v19, #0
10011ab28:     	sshll2.4s	v17, v22, #0
10011ab2c:     	sshll.4s	v18, v22, #0
10011ab30:     	sshll2.4s	v19, v23, #0
10011ab34:     	sshll.4s	v20, v23, #0
10011ab38:     	ldur	q21, [x13, #-16]
10011ab3c:     	sshll.4s	v22, v21, #0
10011ab40:     	scvtf.4s	v22, v22
10011ab44:     	scvtf.4s	v7, v7
10011ab48:     	fsub.4s	v7, v7, v22
10011ab4c:     	scvtf.4s	v23, v27
10011ab50:     	fsub.4s	v23, v23, v22
10011ab54:     	scvtf.4s	v27, v29
10011ab58:     	fsub.4s	v27, v27, v22
10011ab5c:     	scvtf.4s	v16, v16
10011ab60:     	fsub.4s	v22, v16, v22
10011ab64:     	ldr	q29, [x13]
10011ab68:     	sshll2.4s	v16, v21, #0
10011ab6c:     	scvtf.4s	v21, v16
10011ab70:     	scvtf.4s	v5, v5
10011ab74:     	scvtf.4s	v25, v25
10011ab78:     	fsub.4s	v16, v5, v21
10011ab7c:     	fsub.4s	v25, v25, v21
10011ab80:     	scvtf.4s	v5, v28
10011ab84:     	fsub.4s	v28, v5, v21
10011ab88:     	scvtf.4s	v5, v30
10011ab8c:     	fsub.4s	v21, v5, v21
10011ab90:     	sshll.4s	v5, v29, #0
10011ab94:     	scvtf.4s	v30, v5
10011ab98:     	scvtf.4s	v5, v6
10011ab9c:     	fsub.4s	v5, v5, v30
10011aba0:     	scvtf.4s	v6, v26
10011aba4:     	scvtf.4s	v18, v18
10011aba8:     	fsub.4s	v6, v6, v30
10011abac:     	fsub.4s	v18, v18, v30
10011abb0:     	scvtf.4s	v20, v20
10011abb4:     	fsub.4s	v20, v20, v30
10011abb8:     	sshll2.4s	v26, v29, #0
10011abbc:     	scvtf.4s	v26, v26
10011abc0:     	scvtf.4s	v4, v4
10011abc4:     	fsub.4s	v4, v4, v26
10011abc8:     	scvtf.4s	v24, v24
10011abcc:     	fsub.4s	v24, v24, v26
10011abd0:     	scvtf.4s	v17, v17
10011abd4:     	scvtf.4s	v19, v19
10011abd8:     	fsub.4s	v17, v17, v26
10011abdc:     	fsub.4s	v19, v19, v26
10011abe0:     	fmul.4s	v22, v22, v22
10011abe4:     	mov	s26, v22[1]
10011abe8:     	fadd	s3, s3, s22
10011abec:     	fadd	s3, s3, s26
10011abf0:     	mov	s26, v22[2]
10011abf4:     	fadd	s3, s3, s26
10011abf8:     	fmul.4s	v21, v21, v21
10011abfc:     	mov	s22, v22[3]
10011ac00:     	fadd	s3, s3, s22
10011ac04:     	mov	s22, v21[1]
10011ac08:     	fadd	s3, s3, s21
10011ac0c:     	fadd	s3, s3, s22
10011ac10:     	mov	s22, v21[2]
10011ac14:     	fadd	s3, s3, s22
10011ac18:     	mov	s21, v21[3]
10011ac1c:     	fmul.4s	v20, v20, v20
10011ac20:     	fadd	s3, s3, s21
10011ac24:     	mov	s21, v20[1]
10011ac28:     	fadd	s3, s3, s20
10011ac2c:     	fadd	s3, s3, s21
10011ac30:     	mov	s21, v20[2]
10011ac34:     	fadd	s3, s3, s21
10011ac38:     	fmul.4s	v21, v27, v27
10011ac3c:     	fmul.4s	v19, v19, v19
10011ac40:     	mov	s20, v20[3]
10011ac44:     	fadd	s3, s3, s20
10011ac48:     	mov	s20, v19[1]
10011ac4c:     	fadd	s3, s3, s19
10011ac50:     	fadd	s3, s3, s20
10011ac54:     	mov	s20, v21[1]
10011ac58:     	fadd	s2, s2, s21
10011ac5c:     	fadd	s2, s2, s20
10011ac60:     	mov	s20, v21[2]
10011ac64:     	fadd	s2, s2, s20
10011ac68:     	fmul.4s	v20, v28, v28
10011ac6c:     	mov	s21, v21[3]
10011ac70:     	fadd	s2, s2, s21
10011ac74:     	mov	s21, v20[1]
10011ac78:     	fadd	s2, s2, s20
10011ac7c:     	fadd	s2, s2, s21
10011ac80:     	mov	s21, v20[2]
10011ac84:     	fadd	s2, s2, s21
10011ac88:     	mov	s20, v20[3]
10011ac8c:     	fmul.4s	v18, v18, v18
10011ac90:     	fadd	s2, s2, s20
10011ac94:     	mov	s20, v18[1]
10011ac98:     	fadd	s2, s2, s18
10011ac9c:     	fadd	s2, s2, s20
10011aca0:     	mov	s20, v18[2]
10011aca4:     	fadd	s2, s2, s20
10011aca8:     	fmul.4s	v20, v23, v23
10011acac:     	fmul.4s	v17, v17, v17
10011acb0:     	mov	s18, v18[3]
10011acb4:     	fadd	s2, s2, s18
10011acb8:     	mov	s18, v17[1]
10011acbc:     	fadd	s2, s2, s17
10011acc0:     	fadd	s2, s2, s18
10011acc4:     	mov	s18, v19[2]
10011acc8:     	fadd	s3, s3, s18
10011accc:     	mov	s18, v17[2]
10011acd0:     	fadd	s2, s2, s18
10011acd4:     	mov	s18, v20[1]
10011acd8:     	fadd	s1, s1, s20
10011acdc:     	fadd	s1, s1, s18
10011ace0:     	mov	s18, v20[2]
10011ace4:     	fadd	s1, s1, s18
10011ace8:     	mov	s18, v20[3]
10011acec:     	fadd	s1, s1, s18
10011acf0:     	fmul.4s	v18, v25, v25
10011acf4:     	mov	s19, v19[3]
10011acf8:     	fadd	s3, s3, s19
10011acfc:     	mov	s19, v18[1]
10011ad00:     	fadd	s1, s1, s18
10011ad04:     	fadd	s1, s1, s19
10011ad08:     	mov	s19, v18[2]
10011ad0c:     	fadd	s1, s1, s19
10011ad10:     	mov	s18, v18[3]
10011ad14:     	fmul.4s	v6, v6, v6
10011ad18:     	fadd	s1, s1, s18
10011ad1c:     	mov	s18, v6[1]
10011ad20:     	fadd	s1, s1, s6
10011ad24:     	fadd	s1, s1, s18
10011ad28:     	mov	s18, v6[2]
10011ad2c:     	fadd	s1, s1, s18
10011ad30:     	fmul.4s	v18, v24, v24
10011ad34:     	mov	s6, v6[3]
10011ad38:     	fadd	s1, s1, s6
10011ad3c:     	mov	s6, v18[1]
10011ad40:     	fadd	s1, s1, s18
10011ad44:     	fadd	s1, s1, s6
10011ad48:     	mov	s6, v18[2]
10011ad4c:     	fadd	s1, s1, s6
10011ad50:     	fmul.4s	v6, v7, v7
10011ad54:     	mov	s7, v17[3]
10011ad58:     	fadd	s2, s2, s7
10011ad5c:     	mov	s7, v6[1]
10011ad60:     	fadd	s0, s0, s6
10011ad64:     	fadd	s0, s0, s7
10011ad68:     	mov	s7, v6[2]
10011ad6c:     	fadd	s0, s0, s7
10011ad70:     	fmul.4s	v7, v16, v16
10011ad74:     	mov	s6, v6[3]
10011ad78:     	fadd	s0, s0, s6
10011ad7c:     	mov	s6, v7[1]
10011ad80:     	fadd	s0, s0, s7
10011ad84:     	fadd	s0, s0, s6
10011ad88:     	mov	s6, v7[2]
10011ad8c:     	fadd	s0, s0, s6
10011ad90:     	mov	s6, v7[3]
10011ad94:     	fadd	s0, s0, s6
10011ad98:     	fmul.4s	v5, v5, v5
10011ad9c:     	mov	s6, v18[3]
10011ada0:     	fadd	s1, s1, s6
10011ada4:     	mov	s6, v5[1]
10011ada8:     	fadd	s0, s0, s5
10011adac:     	fadd	s0, s0, s6
10011adb0:     	mov	s6, v5[2]
10011adb4:     	fadd	s0, s0, s6
10011adb8:     	fmul.4s	v4, v4, v4
10011adbc:     	mov	s5, v5[3]
10011adc0:     	fadd	s0, s0, s5
10011adc4:     	mov	s5, v4[1]
10011adc8:     	fadd	s0, s0, s4
10011adcc:     	fadd	s0, s0, s5
10011add0:     	mov	s5, v4[2]
10011add4:     	fadd	s0, s0, s5
10011add8:     	mov	s4, v4[3]
10011addc:     	fadd	s0, s0, s4
10011ade0:     	add	x12, x12, #128
10011ade4:     	add	x13, x13, #32
10011ade8:     	subs	x14, x14, #16
10011adec:     	b.ne	0x10011aaec <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x78>
10011adf0:     	mov.s	v0[1], v1[0]
10011adf4:     	mov.s	v0[2], v2[0]
10011adf8:     	mov.s	v0[3], v3[0]
10011adfc:     	cmp	x10, x11
10011ae00:     	b.eq	0x10011ae3c <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x3c8>
10011ae04:     	add	x9, x9, #2
10011ae08:     	add	x10, x0, #8
10011ae0c:     	sub	x8, x2, x8
10011ae10:     	ldrsh	w11, [x9], #2
10011ae14:     	scvtf	s1, w11
10011ae18:     	ldr	d2, [x10], #8
10011ae1c:     	sshll.4s	v2, v2, #0
10011ae20:     	scvtf.4s	v2, v2
10011ae24:     	dup.4s	v1, v1[0]
10011ae28:     	fsub.4s	v1, v2, v1
10011ae2c:     	fmul.4s	v1, v1, v1
10011ae30:     	fadd.4s	v0, v0, v1
10011ae34:     	subs	x8, x8, #1
10011ae38:     	b.ne	0x10011ae10 <void kernel<short, 4ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x39c>
10011ae3c:     	str	q0, [x3]
10011ae40:     	ret

000000010011ae44 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
10011ae44:     	cbz	x2, 0x10011ae9c <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x58>
10011ae48:     	ld1r.4h	{ v0 }, [x1]
10011ae4c:     	ldr	d1, [x0]
10011ae50:     	smull.4s	v0, v0, v1
10011ae54:     	scvtf.4s	v0, v0
10011ae58:     	fneg.4s	v0, v0
10011ae5c:     	str	q0, [x3]
10011ae60:     	cmp	x2, #1
10011ae64:     	b.eq	0x10011ae98 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x54>
10011ae68:     	add	x8, x1, #2
10011ae6c:     	add	x9, x0, #8
10011ae70:     	lsl	x10, x2, #1
10011ae74:     	sub	x10, x10, #2
10011ae78:     	ldr	d1, [x9], #8
10011ae7c:     	ld1r.4h	{ v2 }, [x8], #2
10011ae80:     	smull.4s	v1, v2, v1
10011ae84:     	scvtf.4s	v1, v1
10011ae88:     	fsub.4s	v0, v0, v1
10011ae8c:     	subs	x10, x10, #2
10011ae90:     	b.ne	0x10011ae78 <void kernel<short, 4ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x34>
10011ae94:     	str	q0, [x3]
10011ae98:     	ret
10011ae9c:     	stp	xzr, xzr, [x3]
10011aea0:     	ret

000000010011d0c4 <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10011d0c4:     	cbz	x2, 0x10011d0cc <void kernel<short, 4ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10011d0c8:     	b	0x10011d0d8 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011d0cc:     	movi.2d	v0, #0000000000000000
10011d0d0:     	stp	q0, q0, [x3]
10011d0d4:     	ret

000000010011d4ac <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10011d4ac:     	cbz	x2, 0x10011d4b4 <void kernel<short, 4ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011d4b0:     	b	0x10011d4c0 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
10011d4b4:     	movi.2d	v0, #0000000000000000
10011d4b8:     	stp	q0, q0, [x3]
10011d4bc:     	ret

000000010011f16c <void kernel<short, 4ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10011f16c:     	b	0x10011f170 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010011f26c <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10011f26c:     	cbz	x2, 0x10011f274 <void kernel<short, 4ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
10011f270:     	b	0x10011f284 <void zvec::turbo::InterleavedDistanceMatrix<short, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
10011f274:     	movi.2d	v0, #0000000000000000
10011f278:     	stp	q0, q0, [x3, #32]
10011f27c:     	stp	q0, q0, [x3]
10011f280:     	ret

0000000100121508 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100121508:     	cbz	x2, 0x100121510 <void kernel<short, 8ul, 1ul, false>(short const*, short const*, unsigned long, float*)+0x8>
10012150c:     	b	0x10012151c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
100121510:     	movi.2d	v0, #0000000000000000
100121514:     	stp	q0, q0, [x3]
100121518:     	ret

00000001001215b4 <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001215b4:     	cbz	x2, 0x1001215bc <void kernel<short, 8ul, 1ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001215b8:     	b	0x1001215c8 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(short const*, short const*, unsigned long, float*)>
1001215bc:     	movi.2d	v0, #0000000000000000
1001215c0:     	stp	q0, q0, [x3]
1001215c4:     	ret

00000001001237f4 <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
1001237f4:     	cbz	x2, 0x1001237fc <void kernel<short, 8ul, 2ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001237f8:     	b	0x10012380c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
1001237fc:     	movi.2d	v0, #0000000000000000
100123800:     	stp	q0, q0, [x3, #32]
100123804:     	stp	q0, q0, [x3]
100123808:     	ret

000000010012394c <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10012394c:     	cbz	x2, 0x100123954 <void kernel<short, 8ul, 2ul, true>(short const*, short const*, unsigned long, float*)+0x8>
100123950:     	b	0x100123964 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(short const*, short const*, unsigned long, float*)>
100123954:     	movi.2d	v0, #0000000000000000
100123958:     	stp	q0, q0, [x3, #32]
10012395c:     	stp	q0, q0, [x3]
100123960:     	ret

00000001001261b0 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
1001261b0:     	cbz	x2, 0x1001261b8 <void kernel<short, 8ul, 4ul, false>(short const*, short const*, unsigned long, float*)+0x8>
1001261b4:     	b	0x1001261d0 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001261b8:     	movi.2d	v0, #0000000000000000
1001261bc:     	stp	q0, q0, [x3, #96]
1001261c0:     	stp	q0, q0, [x3, #64]
1001261c4:     	stp	q0, q0, [x3, #32]
1001261c8:     	stp	q0, q0, [x3]
1001261cc:     	ret

00000001001263c0 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
1001263c0:     	cbz	x2, 0x1001263c8 <void kernel<short, 8ul, 4ul, true>(short const*, short const*, unsigned long, float*)+0x8>
1001263c4:     	b	0x1001263e0 <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(short const*, short const*, unsigned long, float*)>
1001263c8:     	movi.2d	v0, #0000000000000000
1001263cc:     	stp	q0, q0, [x3, #96]
1001263d0:     	stp	q0, q0, [x3, #64]
1001263d4:     	stp	q0, q0, [x3, #32]
1001263d8:     	stp	q0, q0, [x3]
1001263dc:     	ret

0000000100128dfc <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100128dfc:     	cbz	x2, 0x100128e04 <void kernel<short, 8ul, 8ul, false>(short const*, short const*, unsigned long, float*)+0x8>
100128e00:     	b	0x100128e2c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(short const*, short const*, unsigned long, float*)>
100128e04:     	movi.2d	v0, #0000000000000000
100128e08:     	stp	q0, q0, [x3, #224]
100128e0c:     	stp	q0, q0, [x3, #192]
100128e10:     	stp	q0, q0, [x3, #160]
100128e14:     	stp	q0, q0, [x3, #128]
100128e18:     	stp	q0, q0, [x3, #96]
100128e1c:     	stp	q0, q0, [x3, #64]
100128e20:     	stp	q0, q0, [x3, #32]
100128e24:     	stp	q0, q0, [x3]
100128e28:     	ret

0000000100129248 <void kernel<short, 8ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100129248:     	b	0x10012924c <void zvec::turbo::InterleavedDistanceMatrix<short, 8ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

000000010012b674 <void kernel<short, 16ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
10012b674:     	b	0x10012b678 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010012b708 <void kernel<short, 16ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
10012b708:     	b	0x10012b70c <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010012e1a4 <void kernel<short, 16ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10012e1a4:     	b	0x10012e1a8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010012e2c4 <void kernel<short, 16ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10012e2c4:     	b	0x10012e2c8 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

00000001001310d0 <void kernel<short, 16ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
1001310d0:     	b	0x1001310d4 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

0000000100131300 <void kernel<short, 16ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
100131300:     	b	0x100131304 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

0000000100134b54 <void kernel<short, 16ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
100134b54:     	b	0x100134b58 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100134c44 <void kernel<short, 16ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100134c44:     	b	0x100134c48 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

00000001001385b8 <void kernel<short, 16ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
1001385b8:     	b	0x1001385bc <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010013866c <void kernel<short, 16ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10013866c:     	b	0x100138670 <void zvec::turbo::InterleavedDistanceMatrix<short, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

0000000100139608 <void kernel<short, 32ul, 1ul, false>(short const*, short const*, unsigned long, float*)>:
100139608:     	b	0x10013960c <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

00000001001397bc <void kernel<short, 32ul, 1ul, true>(short const*, short const*, unsigned long, float*)>:
1001397bc:     	b	0x1001397c0 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<1ul>(short const*, short const*, unsigned long, float*)>

000000010013b1c0 <void kernel<short, 32ul, 2ul, false>(short const*, short const*, unsigned long, float*)>:
10013b1c0:     	b	0x10013b1c4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010013b520 <void kernel<short, 32ul, 2ul, true>(short const*, short const*, unsigned long, float*)>:
10013b520:     	b	0x10013b524 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(short const*, short const*, unsigned long, float*)>

000000010013d524 <void kernel<short, 32ul, 4ul, false>(short const*, short const*, unsigned long, float*)>:
10013d524:     	b	0x10013d528 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

000000010013d72c <void kernel<short, 32ul, 4ul, true>(short const*, short const*, unsigned long, float*)>:
10013d72c:     	b	0x10013d730 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(short const*, short const*, unsigned long, float*)>

00000001001401c8 <void kernel<short, 32ul, 8ul, false>(short const*, short const*, unsigned long, float*)>:
1001401c8:     	b	0x1001401cc <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100140394 <void kernel<short, 32ul, 8ul, true>(short const*, short const*, unsigned long, float*)>:
100140394:     	b	0x100140398 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(short const*, short const*, unsigned long, float*)>

0000000100142eb0 <void kernel<short, 32ul, 16ul, false>(short const*, short const*, unsigned long, float*)>:
100142eb0:     	b	0x100142eb4 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

000000010014307c <void kernel<short, 32ul, 16ul, true>(short const*, short const*, unsigned long, float*)>:
10014307c:     	b	0x100143080 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(short const*, short const*, unsigned long, float*)>

00000001001448c8 <void kernel<short, 32ul, 32ul, false>(short const*, short const*, unsigned long, float*)>:
1001448c8:     	b	0x1001448cc <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100144a94 <void kernel<short, 32ul, 32ul, true>(short const*, short const*, unsigned long, float*)>:
100144a94:     	b	0x100144a98 <void zvec::turbo::InterleavedDistanceMatrix<short, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(short const*, short const*, unsigned long, float*)>

0000000100146fcc <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)>:
100146fcc:     	add	x8, x0, x2, lsl #1
100146fd0:     	ands	x9, x2, #0xfffffffffffffff8
100146fd4:     	b.eq	0x10014706c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xa0>
100146fd8:     	add	x11, x0, x9, lsl #1
100146fdc:     	lsl	x9, x2, #1
100146fe0:     	and	x9, x9, #0xfffffffffffffff0
100146fe4:     	movi.2d	v0, #0000000000000000
100146fe8:     	mov	x10, x0
100146fec:     	movi.2d	v1, #0000000000000000
100146ff0:     	ldr	q2, [x10], #16
100146ff4:     	ldr	q3, [x1], #16
100146ff8:     	fcvtl	v4.4s, v2.4h
100146ffc:     	fcvtl	v5.4s, v3.4h
100147000:     	fmla.4s	v0, v5, v4
100147004:     	fcvtl2	v2.4s, v2.8h
100147008:     	fcvtl2	v3.4s, v3.8h
10014700c:     	fmla.4s	v1, v3, v2
100147010:     	subs	x9, x9, #16
100147014:     	b.ne	0x100146ff0 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x24>
100147018:     	sub	x9, x8, x11
10014701c:     	cmp	x9, #7
100147020:     	b.lt	0x100147038 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147024:     	ldr	d2, [x11], #8
100147028:     	fcvtl	v2.4s, v2.4h
10014702c:     	ldr	d3, [x1], #8
100147030:     	fcvtl	v3.4s, v3.4h
100147034:     	fmla.4s	v0, v3, v2
100147038:     	fadd.4s	v0, v1, v0
10014703c:     	faddp.4s	v0, v0, v0
100147040:     	faddp.2s	s0, v0
100147044:     	cmp	x11, x8
100147048:     	b.eq	0x100147188 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014704c:     	add	x9, x0, x2, lsl #1
100147050:     	sub	x9, x9, x11
100147054:     	sub	x9, x9, #2
100147058:     	cmp	x9, #30
10014705c:     	b.hs	0x100147088 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xbc>
100147060:     	mov	x9, x11
100147064:     	mov	x10, x1
100147068:     	b	0x10014716c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
10014706c:     	movi.2d	v1, #0000000000000000
100147070:     	movi.2d	v0, #0000000000000000
100147074:     	mov	x11, x0
100147078:     	sub	x9, x8, x0
10014707c:     	cmp	x9, #7
100147080:     	b.ge	0x100147024 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x58>
100147084:     	b	0x100147038 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x6c>
100147088:     	lsr	x9, x9, #1
10014708c:     	add	x12, x9, #1
100147090:     	and	x13, x12, #0xfffffffffffffff0
100147094:     	lsl	x10, x13, #1
100147098:     	add	x9, x11, x10
10014709c:     	add	x10, x1, x10
1001470a0:     	add	x14, x1, #16
1001470a4:     	add	x11, x11, #16
1001470a8:     	mov	x15, x13
1001470ac:     	ldp	q1, q2, [x11, #-16]
1001470b0:     	fcvtl	v3.4s, v1.4h
1001470b4:     	fcvtl2	v1.4s, v1.8h
1001470b8:     	fcvtl	v4.4s, v2.4h
1001470bc:     	fcvtl2	v2.4s, v2.8h
1001470c0:     	ldp	q5, q6, [x14, #-16]
1001470c4:     	fcvtl	v7.4s, v5.4h
1001470c8:     	fcvtl2	v5.4s, v5.8h
1001470cc:     	fcvtl	v16.4s, v6.4h
1001470d0:     	fcvtl2	v6.4s, v6.8h
1001470d4:     	fmul.4s	v1, v1, v5
1001470d8:     	mov	s5, v1[3]
1001470dc:     	mov	s17, v1[2]
1001470e0:     	mov	s18, v1[1]
1001470e4:     	fmul.4s	v3, v3, v7
1001470e8:     	mov	s7, v3[3]
1001470ec:     	mov	s19, v3[2]
1001470f0:     	mov	s20, v3[1]
1001470f4:     	fmul.4s	v2, v2, v6
1001470f8:     	mov	s6, v2[3]
1001470fc:     	mov	s21, v2[2]
100147100:     	mov	s22, v2[1]
100147104:     	fmul.4s	v4, v4, v16
100147108:     	mov	s16, v4[3]
10014710c:     	mov	s23, v4[2]
100147110:     	mov	s24, v4[1]
100147114:     	fadd	s0, s0, s3
100147118:     	fadd	s0, s0, s20
10014711c:     	fadd	s0, s0, s19
100147120:     	fadd	s0, s0, s7
100147124:     	fadd	s0, s0, s1
100147128:     	fadd	s0, s0, s18
10014712c:     	fadd	s0, s0, s17
100147130:     	fadd	s0, s0, s5
100147134:     	fadd	s0, s0, s4
100147138:     	fadd	s0, s0, s24
10014713c:     	fadd	s0, s0, s23
100147140:     	fadd	s0, s0, s16
100147144:     	fadd	s0, s0, s2
100147148:     	fadd	s0, s0, s22
10014714c:     	fadd	s0, s0, s21
100147150:     	fadd	s0, s0, s6
100147154:     	add	x14, x14, #32
100147158:     	add	x11, x11, #32
10014715c:     	subs	x15, x15, #16
100147160:     	b.ne	0x1001470ac <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0xe0>
100147164:     	cmp	x12, x13
100147168:     	b.eq	0x100147188 <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1bc>
10014716c:     	ldr	h1, [x9], #2
100147170:     	fcvt	s1, h1
100147174:     	ldr	h2, [x10], #2
100147178:     	fcvt	s2, h2
10014717c:     	fmadd	s0, s1, s2, s0
100147180:     	cmp	x9, x8
100147184:     	b.ne	0x10014716c <zvec::turbo::neon::inner_product_fp16_distance(void const*, void const*, unsigned long, float*)+0x1a0>
100147188:     	fneg	s0, s0
10014718c:     	str	s0, [x3]
100147190:     	ret
