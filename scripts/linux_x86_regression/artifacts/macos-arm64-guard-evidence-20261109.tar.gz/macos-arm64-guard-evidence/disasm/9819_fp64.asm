
bin/9819_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100003620 <void kernel<float, 1ul, 1ul, false>(float const*, float const*, unsigned long, float*)>:
100003620:     	b	0x1000036c0 <zvec::turbo::DistanceMatrix<float, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(float const*, float const*, unsigned long, float*)>

000000010000385c <void kernel<float, 1ul, 1ul, true>(float const*, float const*, unsigned long, float*)>:
10000385c:     	b	0x100003860 <zvec::turbo::DistanceMatrix<float, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(float const*, float const*, unsigned long, float*)>

00000001000d7440 <void kernel<double, 1ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000d7440:     	b	0x1000d7444 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)>

00000001000d7444 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)>:
1000d7444:     	sub	sp, sp, #80
1000d7448:     	stp	x22, x21, [sp, #32]
1000d744c:     	stp	x20, x19, [sp, #48]
1000d7450:     	stp	x29, x30, [sp, #64]
1000d7454:     	add	x29, sp, #64
1000d7458:     	mov	x19, x3
1000d745c:     	mov	x20, x2
1000d7460:     	mov	x21, x1
1000d7464:     	mov	x22, x0
1000d7468:     	adrp	x8, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x84>
1000d746c:     	ldr	x8, [x8, #48]
1000d7470:     	ldaprb	w8, [x8]
1000d7474:     	tbz	w8, #0, 0x1000d74c0 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0x7c>
1000d7478:     	stp	x21, x22, [sp, #16]
1000d747c:     	stp	x19, x20, [sp]
1000d7480:     	adrp	x8, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x9c>
1000d7484:     	ldr	x8, [x8, #224]
1000d7488:     	ldr	x0, [x8, #24]
1000d748c:     	cbz	x0, 0x1000d7518 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0xd4>
1000d7490:     	ldr	x8, [x0]
1000d7494:     	ldr	x8, [x8, #48]
1000d7498:     	add	x1, sp, #24
1000d749c:     	add	x2, sp, #16
1000d74a0:     	add	x3, sp, #8
1000d74a4:     	mov	x4, sp
1000d74a8:     	blr	x8
1000d74ac:     	ldp	x29, x30, [sp, #64]
1000d74b0:     	ldp	x20, x19, [sp, #48]
1000d74b4:     	ldp	x22, x21, [sp, #32]
1000d74b8:     	add	sp, sp, #80
1000d74bc:     	ret
1000d74c0:     	adrp	x0, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0xdc>
1000d74c4:     	ldr	x0, [x0, #48]
1000d74c8:     	bl	0x10015f690 <_strcmp+0x10015f690>
1000d74cc:     	cbz	w0, 0x1000d7478 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000d74d0:     	adrp	x8, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0xec>
1000d74d4:     	ldr	x8, [x8, #224]
1000d74d8:     	mov	w0, #0
1000d74dc:     	mov	w1, #8
1000d74e0:     	mov	w2, #8
1000d74e4:     	mov	w3, #0
1000d74e8:     	bl	0x10015c718 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
1000d74ec:     	adrp	x0, 0x100003000 <void run<double, 1ul, 1ul, true>(char const*)+0x738>
1000d74f0:     	add	x0, x0, #1968
1000d74f4:     	adrp	x1, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x110>
1000d74f8:     	ldr	x1, [x1, #224]
1000d74fc:     	adrp	x2, 0x100000000 <void run<double, 1ul, 1ul, true>(char const*)+0x73c>
1000d7500:     	add	x2, x2, #0
1000d7504:     	bl	0x10015f660 <_strcmp+0x10015f660>
1000d7508:     	adrp	x0, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x124>
1000d750c:     	ldr	x0, [x0, #48]
1000d7510:     	bl	0x10015f69c <_strcmp+0x10015f69c>
1000d7514:     	b	0x1000d7478 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)0>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000d7518:     	bl	0x1000037fc <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000d751c:     	mov	x19, x0
1000d7520:     	adrp	x0, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x13c>
1000d7524:     	ldr	x0, [x0, #48]
1000d7528:     	bl	0x10015f684 <_strcmp+0x10015f684>
1000d752c:     	mov	x0, x19
1000d7530:     	bl	0x10015f5f4 <_strcmp+0x10015f5f4>

00000001000d7534 <void kernel<double, 1ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000d7534:     	b	0x1000d7538 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)>

00000001000d7538 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)>:
1000d7538:     	sub	sp, sp, #80
1000d753c:     	stp	x22, x21, [sp, #32]
1000d7540:     	stp	x20, x19, [sp, #48]
1000d7544:     	stp	x29, x30, [sp, #64]
1000d7548:     	add	x29, sp, #64
1000d754c:     	mov	x19, x3
1000d7550:     	mov	x20, x2
1000d7554:     	mov	x21, x1
1000d7558:     	mov	x22, x0
1000d755c:     	adrp	x8, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x178>
1000d7560:     	ldr	x8, [x8, #56]
1000d7564:     	ldaprb	w8, [x8]
1000d7568:     	tbz	w8, #0, 0x1000d75b4 <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0x7c>
1000d756c:     	stp	x21, x22, [sp, #16]
1000d7570:     	stp	x19, x20, [sp]
1000d7574:     	adrp	x8, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x190>
1000d7578:     	ldr	x8, [x8, #232]
1000d757c:     	ldr	x0, [x8, #24]
1000d7580:     	cbz	x0, 0x1000d760c <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0xd4>
1000d7584:     	ldr	x8, [x0]
1000d7588:     	ldr	x8, [x8, #48]
1000d758c:     	add	x1, sp, #24
1000d7590:     	add	x2, sp, #16
1000d7594:     	add	x3, sp, #8
1000d7598:     	mov	x4, sp
1000d759c:     	blr	x8
1000d75a0:     	ldp	x29, x30, [sp, #64]
1000d75a4:     	ldp	x20, x19, [sp, #48]
1000d75a8:     	ldp	x22, x21, [sp, #32]
1000d75ac:     	add	sp, sp, #80
1000d75b0:     	ret
1000d75b4:     	adrp	x0, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x1d0>
1000d75b8:     	ldr	x0, [x0, #56]
1000d75bc:     	bl	0x10015f690 <_strcmp+0x10015f690>
1000d75c0:     	cbz	w0, 0x1000d756c <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000d75c4:     	adrp	x8, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x1e0>
1000d75c8:     	ldr	x8, [x8, #232]
1000d75cc:     	mov	w0, #2
1000d75d0:     	mov	w1, #8
1000d75d4:     	mov	w2, #8
1000d75d8:     	mov	w3, #0
1000d75dc:     	bl	0x10015c718 <zvec::turbo::get_distance_func(zvec::turbo::MetricType, zvec::turbo::DataType, zvec::turbo::QuantizeType, zvec::turbo::CpuArchType)>
1000d75e0:     	adrp	x0, 0x100003000 <void run<double, 1ul, 1ul, true>(char const*)+0x82c>
1000d75e4:     	add	x0, x0, #1968
1000d75e8:     	adrp	x1, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x204>
1000d75ec:     	ldr	x1, [x1, #232]
1000d75f0:     	adrp	x2, 0x100000000 <void run<double, 1ul, 1ul, true>(char const*)+0x830>
1000d75f4:     	add	x2, x2, #0
1000d75f8:     	bl	0x10015f660 <_strcmp+0x10015f660>
1000d75fc:     	adrp	x0, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x218>
1000d7600:     	ldr	x0, [x0, #56]
1000d7604:     	bl	0x10015f69c <_strcmp+0x10015f69c>
1000d7608:     	b	0x1000d756c <zvec::turbo::DistanceMatrix<double, 1ul, 1ul, (zvec::turbo::MetricType)2>::Compute(double const*, double const*, unsigned long, float*)+0x34>
1000d760c:     	bl	0x1000037fc <std::__1::__throw_bad_function_call[abi:ue170006]()>
1000d7610:     	mov	x19, x0
1000d7614:     	adrp	x0, 0x100168000 <void run<double, 2ul, 1ul, false>(char const*)+0x230>
1000d7618:     	ldr	x0, [x0, #56]
1000d761c:     	bl	0x10015f684 <_strcmp+0x10015f684>
1000d7620:     	mov	x0, x19
1000d7624:     	bl	0x10015f5f4 <_strcmp+0x10015f5f4>

00000001000d911c <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000d911c:     	cbz	x2, 0x1000d9154 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x38>
1000d9120:     	ld1r.2d	{ v0 }, [x1]
1000d9124:     	ldr	q1, [x0]
1000d9128:     	fsub.2d	v0, v1, v0
1000d912c:     	fmul.2d	v0, v0, v0
1000d9130:     	fcvtn	v0.2s, v0.2d
1000d9134:     	str	d0, [x3]
1000d9138:     	subs	x10, x2, #1
1000d913c:     	b.eq	0x1000d92a8 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x18c>
1000d9140:     	cmp	x2, #9
1000d9144:     	b.hs	0x1000d915c <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x40>
1000d9148:     	mov	w8, #1
1000d914c:     	mov	x9, x1
1000d9150:     	b	0x1000d9278 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x15c>
1000d9154:     	str	xzr, [x3]
1000d9158:     	ret
1000d915c:     	and	x11, x10, #0xfffffffffffffff8
1000d9160:     	add	x9, x1, x11, lsl #3
1000d9164:     	orr	x8, x11, #0x1
1000d9168:     	mov	s1, v0[1]
1000d916c:     	add	x12, x0, #80
1000d9170:     	add	x13, x1, #40
1000d9174:     	mov	x14, x11
1000d9178:     	add	x0, x0, x11, lsl #4
1000d917c:     	sub	x15, x12, #64
1000d9180:     	sub	x16, x12, #32
1000d9184:     	ldp	q2, q3, [x13, #-32]
1000d9188:     	ld2.2d	{ v4, v5 }, [x15]
1000d918c:     	ldp	q6, q7, [x13], #64
1000d9190:     	ld2.2d	{ v16, v17 }, [x16]
1000d9194:     	mov	x15, x12
1000d9198:     	ld2.2d	{ v18, v19 }, [x15], #32
1000d919c:     	ld2.2d	{ v20, v21 }, [x15]
1000d91a0:     	fsub.2d	v22, v4, v2
1000d91a4:     	fsub.2d	v23, v16, v3
1000d91a8:     	fsub.2d	v24, v18, v6
1000d91ac:     	fsub.2d	v25, v20, v7
1000d91b0:     	fmul.2d	v22, v22, v22
1000d91b4:     	fmul.2d	v23, v23, v23
1000d91b8:     	fmul.2d	v24, v24, v24
1000d91bc:     	fmul.2d	v25, v25, v25
1000d91c0:     	fcvtn	v22.2s, v22.2d
1000d91c4:     	mov	s26, v22[1]
1000d91c8:     	fcvtn	v23.2s, v23.2d
1000d91cc:     	mov	s27, v23[1]
1000d91d0:     	fcvtn	v24.2s, v24.2d
1000d91d4:     	mov	s28, v24[1]
1000d91d8:     	fcvtn	v25.2s, v25.2d
1000d91dc:     	mov	s29, v25[1]
1000d91e0:     	fsub.2d	v2, v5, v2
1000d91e4:     	fsub.2d	v3, v17, v3
1000d91e8:     	fsub.2d	v4, v19, v6
1000d91ec:     	fsub.2d	v5, v21, v7
1000d91f0:     	fmul.2d	v2, v2, v2
1000d91f4:     	fmul.2d	v3, v3, v3
1000d91f8:     	fmul.2d	v4, v4, v4
1000d91fc:     	fmul.2d	v5, v5, v5
1000d9200:     	fcvtn	v2.2s, v2.2d
1000d9204:     	mov	s6, v2[1]
1000d9208:     	fcvtn	v3.2s, v3.2d
1000d920c:     	mov	s7, v3[1]
1000d9210:     	fcvtn	v4.2s, v4.2d
1000d9214:     	mov	s16, v4[1]
1000d9218:     	fcvtn	v5.2s, v5.2d
1000d921c:     	mov	s17, v5[1]
1000d9220:     	fadd	s1, s1, s2
1000d9224:     	fadd	s1, s1, s6
1000d9228:     	fadd	s1, s1, s3
1000d922c:     	fadd	s1, s1, s7
1000d9230:     	fadd	s1, s1, s4
1000d9234:     	fadd	s1, s1, s16
1000d9238:     	fadd	s1, s1, s5
1000d923c:     	fadd	s1, s1, s17
1000d9240:     	fadd	s0, s0, s22
1000d9244:     	fadd	s0, s0, s26
1000d9248:     	fadd	s0, s0, s23
1000d924c:     	fadd	s0, s0, s27
1000d9250:     	fadd	s0, s0, s24
1000d9254:     	fadd	s0, s0, s28
1000d9258:     	fadd	s0, s0, s25
1000d925c:     	fadd	s0, s0, s29
1000d9260:     	add	x12, x12, #128
1000d9264:     	subs	x14, x14, #8
1000d9268:     	b.ne	0x1000d917c <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x60>
1000d926c:     	mov.s	v0[1], v1[0]
1000d9270:     	cmp	x10, x11
1000d9274:     	b.eq	0x1000d92a4 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x188>
1000d9278:     	add	x9, x9, #8
1000d927c:     	add	x10, x0, #16
1000d9280:     	sub	x8, x2, x8
1000d9284:     	ldr	q1, [x10], #16
1000d9288:     	ld1r.2d	{ v2 }, [x9], #8
1000d928c:     	fsub.2d	v1, v1, v2
1000d9290:     	fmul.2d	v1, v1, v1
1000d9294:     	fcvtn	v1.2s, v1.2d
1000d9298:     	fadd.2s	v0, v0, v1
1000d929c:     	subs	x8, x8, #1
1000d92a0:     	b.ne	0x1000d9284 <void kernel<double, 2ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x168>
1000d92a4:     	str	d0, [x3]
1000d92a8:     	ret

00000001000d92ac <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000d92ac:     	cbz	x2, 0x1000d9304 <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x58>
1000d92b0:     	ldr	d0, [x1]
1000d92b4:     	ldr	q1, [x0]
1000d92b8:     	fmul.2d	v0, v1, v0[0]
1000d92bc:     	fcvtn	v0.2s, v0.2d
1000d92c0:     	fneg.2s	v0, v0
1000d92c4:     	str	d0, [x3]
1000d92c8:     	cmp	x2, #1
1000d92cc:     	b.eq	0x1000d9300 <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x54>
1000d92d0:     	add	x8, x1, #8
1000d92d4:     	add	x9, x0, #16
1000d92d8:     	lsl	x10, x2, #3
1000d92dc:     	sub	x10, x10, #8
1000d92e0:     	fcvtl	v0.2d, v0.2s
1000d92e4:     	ldr	q1, [x9], #16
1000d92e8:     	ld1r.2d	{ v2 }, [x8], #8
1000d92ec:     	fmls.2d	v0, v2, v1
1000d92f0:     	fcvtn	v0.2s, v0.2d
1000d92f4:     	subs	x10, x10, #8
1000d92f8:     	b.ne	0x1000d92e0 <void kernel<double, 2ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x34>
1000d92fc:     	str	d0, [x3]
1000d9300:     	ret
1000d9304:     	str	xzr, [x3]
1000d9308:     	ret

00000001000db578 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000db578:     	cbz	x2, 0x1000db5c8 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x50>
1000db57c:     	ldr	q0, [x1]
1000db580:     	dup.2d	v1, v0[1]
1000db584:     	dup.2d	v0, v0[0]
1000db588:     	ldr	q2, [x0]
1000db58c:     	fsub.2d	v0, v2, v0
1000db590:     	fsub.2d	v1, v2, v1
1000db594:     	fmul.2d	v1, v1, v1
1000db598:     	fmul.2d	v0, v0, v0
1000db59c:     	fcvtn	v0.2s, v0.2d
1000db5a0:     	fcvtn2	v0.4s, v1.2d
1000db5a4:     	str	q0, [x3]
1000db5a8:     	subs	x11, x2, #1
1000db5ac:     	b.eq	0x1000db81c <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x2a4>
1000db5b0:     	cmp	x2, #9
1000db5b4:     	b.hs	0x1000db5d0 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x58>
1000db5b8:     	mov	w8, #1
1000db5bc:     	mov	x9, x1
1000db5c0:     	mov	x10, x0
1000db5c4:     	b	0x1000db7d8 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x260>
1000db5c8:     	stp	xzr, xzr, [x3]
1000db5cc:     	ret
1000db5d0:     	and	x12, x11, #0xfffffffffffffff8
1000db5d4:     	lsl	x8, x12, #4
1000db5d8:     	add	x9, x1, x8
1000db5dc:     	add	x10, x0, x8
1000db5e0:     	orr	x8, x12, #0x1
1000db5e4:     	mov	s1, v0[1]
1000db5e8:     	mov	s2, v0[2]
1000db5ec:     	mov	s3, v0[3]
1000db5f0:     	add	x13, x0, #80
1000db5f4:     	add	x14, x1, #80
1000db5f8:     	mov	x15, x12
1000db5fc:     	sub	x16, x13, #64
1000db600:     	ld2.2d	{ v6, v7 }, [x16]
1000db604:     	sub	x16, x13, #32
1000db608:     	ld2.2d	{ v16, v17 }, [x16]
1000db60c:     	mov	x17, x13
1000db610:     	ld2.2d	{ v18, v19 }, [x17], #32
1000db614:     	sub	x16, x14, #64
1000db618:     	ld2.2d	{ v22, v23 }, [x16]
1000db61c:     	sub	x16, x14, #32
1000db620:     	ld2.2d	{ v26, v27 }, [x16]
1000db624:     	mov	x16, x14
1000db628:     	ld2.2d	{ v24, v25 }, [x17]
1000db62c:     	ld2.2d	{ v28, v29 }, [x16], #32
1000db630:     	fsub.2d	v5, v6, v22
1000db634:     	fsub.2d	v4, v16, v26
1000db638:     	fsub.2d	v21, v6, v23
1000db63c:     	fsub.2d	v20, v16, v27
1000db640:     	fsub.2d	v30, v7, v22
1000db644:     	fsub.2d	v6, v7, v23
1000db648:     	fsub.2d	v7, v18, v28
1000db64c:     	fsub.2d	v22, v17, v26
1000db650:     	fsub.2d	v16, v17, v27
1000db654:     	ld2.2d	{ v26, v27 }, [x16]
1000db658:     	fsub.2d	v17, v18, v29
1000db65c:     	fsub.2d	v23, v19, v28
1000db660:     	fsub.2d	v18, v19, v29
1000db664:     	fsub.2d	v19, v24, v26
1000db668:     	fsub.2d	v28, v24, v27
1000db66c:     	fsub.2d	v29, v25, v26
1000db670:     	fsub.2d	v24, v25, v27
1000db674:     	fmul.2d	v6, v6, v6
1000db678:     	fcvtn	v6.2s, v6.2d
1000db67c:     	fadd	s3, s3, s6
1000db680:     	mov	s6, v6[1]
1000db684:     	fadd	s3, s3, s6
1000db688:     	fmul.2d	v6, v16, v16
1000db68c:     	fcvtn	v6.2s, v6.2d
1000db690:     	fadd	s3, s3, s6
1000db694:     	mov	s6, v6[1]
1000db698:     	fadd	s3, s3, s6
1000db69c:     	fmul.2d	v6, v18, v18
1000db6a0:     	fcvtn	v6.2s, v6.2d
1000db6a4:     	fadd	s3, s3, s6
1000db6a8:     	mov	s6, v6[1]
1000db6ac:     	fadd	s3, s3, s6
1000db6b0:     	fmul.2d	v6, v30, v30
1000db6b4:     	fcvtn	v6.2s, v6.2d
1000db6b8:     	fadd	s1, s1, s6
1000db6bc:     	mov	s6, v6[1]
1000db6c0:     	fadd	s1, s1, s6
1000db6c4:     	fmul.2d	v6, v22, v22
1000db6c8:     	fcvtn	v6.2s, v6.2d
1000db6cc:     	fadd	s1, s1, s6
1000db6d0:     	mov	s6, v6[1]
1000db6d4:     	fadd	s1, s1, s6
1000db6d8:     	fmul.2d	v6, v23, v23
1000db6dc:     	fcvtn	v6.2s, v6.2d
1000db6e0:     	fadd	s1, s1, s6
1000db6e4:     	mov	s6, v6[1]
1000db6e8:     	fadd	s1, s1, s6
1000db6ec:     	fmul.2d	v6, v24, v24
1000db6f0:     	fcvtn	v6.2s, v6.2d
1000db6f4:     	fadd	s3, s3, s6
1000db6f8:     	mov	s6, v6[1]
1000db6fc:     	fadd	s3, s3, s6
1000db700:     	fmul.2d	v6, v29, v29
1000db704:     	fcvtn	v6.2s, v6.2d
1000db708:     	fadd	s1, s1, s6
1000db70c:     	mov	s6, v6[1]
1000db710:     	fadd	s1, s1, s6
1000db714:     	fmul.2d	v6, v21, v21
1000db718:     	fcvtn	v6.2s, v6.2d
1000db71c:     	fadd	s2, s2, s6
1000db720:     	mov	s6, v6[1]
1000db724:     	fadd	s2, s2, s6
1000db728:     	fmul.2d	v6, v20, v20
1000db72c:     	fcvtn	v6.2s, v6.2d
1000db730:     	fadd	s2, s2, s6
1000db734:     	mov	s6, v6[1]
1000db738:     	fadd	s2, s2, s6
1000db73c:     	fmul.2d	v6, v17, v17
1000db740:     	fcvtn	v6.2s, v6.2d
1000db744:     	fadd	s2, s2, s6
1000db748:     	mov	s6, v6[1]
1000db74c:     	fadd	s2, s2, s6
1000db750:     	fmul.2d	v5, v5, v5
1000db754:     	fcvtn	v5.2s, v5.2d
1000db758:     	fadd	s0, s0, s5
1000db75c:     	mov	s5, v5[1]
1000db760:     	fadd	s0, s0, s5
1000db764:     	fmul.2d	v5, v28, v28
1000db768:     	fcvtn	v5.2s, v5.2d
1000db76c:     	fadd	s2, s2, s5
1000db770:     	mov	s5, v5[1]
1000db774:     	fadd	s2, s2, s5
1000db778:     	fmul.2d	v4, v4, v4
1000db77c:     	fcvtn	v4.2s, v4.2d
1000db780:     	fadd	s0, s0, s4
1000db784:     	mov	s4, v4[1]
1000db788:     	fadd	s0, s0, s4
1000db78c:     	fmul.2d	v4, v7, v7
1000db790:     	fcvtn	v4.2s, v4.2d
1000db794:     	fadd	s0, s0, s4
1000db798:     	mov	s4, v4[1]
1000db79c:     	fadd	s0, s0, s4
1000db7a0:     	fmul.2d	v4, v19, v19
1000db7a4:     	fcvtn	v4.2s, v4.2d
1000db7a8:     	fadd	s0, s0, s4
1000db7ac:     	mov	s4, v4[1]
1000db7b0:     	fadd	s0, s0, s4
1000db7b4:     	add	x13, x13, #128
1000db7b8:     	add	x14, x14, #128
1000db7bc:     	subs	x15, x15, #8
1000db7c0:     	b.ne	0x1000db5fc <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x84>
1000db7c4:     	mov.s	v0[1], v1[0]
1000db7c8:     	mov.s	v0[2], v2[0]
1000db7cc:     	mov.s	v0[3], v3[0]
1000db7d0:     	cmp	x11, x12
1000db7d4:     	b.eq	0x1000db818 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x2a0>
1000db7d8:     	add	x9, x9, #16
1000db7dc:     	add	x10, x10, #16
1000db7e0:     	sub	x8, x2, x8
1000db7e4:     	ldr	q1, [x9], #16
1000db7e8:     	dup.2d	v2, v1[1]
1000db7ec:     	dup.2d	v1, v1[0]
1000db7f0:     	ldr	q3, [x10], #16
1000db7f4:     	fsub.2d	v1, v3, v1
1000db7f8:     	fsub.2d	v2, v3, v2
1000db7fc:     	fmul.2d	v2, v2, v2
1000db800:     	fmul.2d	v1, v1, v1
1000db804:     	fcvtn	v1.2s, v1.2d
1000db808:     	fcvtn2	v1.4s, v2.2d
1000db80c:     	fadd.4s	v0, v0, v1
1000db810:     	subs	x8, x8, #1
1000db814:     	b.ne	0x1000db7e4 <void kernel<double, 2ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x26c>
1000db818:     	str	q0, [x3]
1000db81c:     	ret

00000001000db820 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000db820:     	cbz	x2, 0x1000db884 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x64>
1000db824:     	ldr	q0, [x1]
1000db828:     	ldr	q1, [x0]
1000db82c:     	fmul.2d	v2, v1, v0[1]
1000db830:     	fmul.2d	v0, v1, v0[0]
1000db834:     	fcvtn	v0.2s, v0.2d
1000db838:     	fcvtn2	v0.4s, v2.2d
1000db83c:     	fneg.4s	v0, v0
1000db840:     	str	q0, [x3]
1000db844:     	subs	x8, x2, #1
1000db848:     	b.eq	0x1000db880 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x60>
1000db84c:     	add	x9, x0, #16
1000db850:     	add	x10, x1, #16
1000db854:     	fcvtl	v1.2d, v0.2s
1000db858:     	ldr	q2, [x10], #16
1000db85c:     	ldr	q3, [x9], #16
1000db860:     	fcvtl2	v4.2d, v0.4s
1000db864:     	fmls.2d	v4, v3, v2[1]
1000db868:     	fmls.2d	v1, v3, v2[0]
1000db86c:     	fcvtn	v0.2s, v1.2d
1000db870:     	fcvtn2	v0.4s, v4.2d
1000db874:     	subs	x8, x8, #1
1000db878:     	b.ne	0x1000db854 <void kernel<double, 2ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x34>
1000db87c:     	str	q0, [x3]
1000db880:     	ret
1000db884:     	stp	xzr, xzr, [x3]
1000db888:     	ret

00000001000de080 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000de080:     	stp	d9, d8, [sp, #-16]!
1000de084:     	cbz	x2, 0x1000de0c8 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x48>
1000de088:     	ldp	q1, q0, [x0]
1000de08c:     	ld1r.2d	{ v2 }, [x1]
1000de090:     	fsub.2d	v1, v1, v2
1000de094:     	fsub.2d	v0, v0, v2
1000de098:     	fmul.2d	v2, v0, v0
1000de09c:     	fmul.2d	v0, v1, v1
1000de0a0:     	fcvtn	v0.2s, v0.2d
1000de0a4:     	fcvtn2	v0.4s, v2.2d
1000de0a8:     	str	q0, [x3]
1000de0ac:     	subs	x10, x2, #1
1000de0b0:     	b.eq	0x1000de300 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x280>
1000de0b4:     	cmp	x2, #9
1000de0b8:     	b.hs	0x1000de0d4 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x54>
1000de0bc:     	mov	w8, #1
1000de0c0:     	mov	x9, x1
1000de0c4:     	b	0x1000de2c4 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x244>
1000de0c8:     	stp	xzr, xzr, [x3]
1000de0cc:     	ldp	d9, d8, [sp], #16
1000de0d0:     	ret
1000de0d4:     	and	x11, x10, #0xfffffffffffffff8
1000de0d8:     	add	x9, x1, x11, lsl #3
1000de0dc:     	orr	x8, x11, #0x1
1000de0e0:     	mov	s3, v0[1]
1000de0e4:     	mov	s1, v0[2]
1000de0e8:     	mov	s2, v0[3]
1000de0ec:     	add	x12, x0, #160
1000de0f0:     	add	x13, x1, #40
1000de0f4:     	mov	x14, x11
1000de0f8:     	add	x0, x0, x11, lsl #5
1000de0fc:     	sub	x15, x12, #128
1000de100:     	ld4.2d	{ v16, v17, v18, v19 }, [x15]
1000de104:     	sub	x15, x12, #64
1000de108:     	ld4.2d	{ v22, v23, v24, v25 }, [x15]
1000de10c:     	ldp	q27, q26, [x13, #-32]
1000de110:     	ldp	q21, q7, [x13]
1000de114:     	mov	x15, x12
1000de118:     	ld4.2d	{ v28, v29, v30, v31 }, [x15], #64
1000de11c:     	fsub.2d	v6, v16, v27
1000de120:     	fsub.2d	v4, v28, v21
1000de124:     	fsub.2d	v5, v22, v26
1000de128:     	fsub.2d	v20, v17, v27
1000de12c:     	fsub.2d	v8, v18, v27
1000de130:     	fsub.2d	v16, v19, v27
1000de134:     	fsub.2d	v17, v23, v26
1000de138:     	fsub.2d	v18, v24, v26
1000de13c:     	fsub.2d	v19, v25, v26
1000de140:     	ld4.2d	{ v22, v23, v24, v25 }, [x15]
1000de144:     	fsub.2d	v26, v29, v21
1000de148:     	fsub.2d	v27, v30, v21
1000de14c:     	fsub.2d	v21, v31, v21
1000de150:     	fsub.2d	v28, v22, v7
1000de154:     	fsub.2d	v29, v23, v7
1000de158:     	fsub.2d	v30, v24, v7
1000de15c:     	fsub.2d	v7, v25, v7
1000de160:     	fmul.2d	v16, v16, v16
1000de164:     	fcvtn	v16.2s, v16.2d
1000de168:     	fadd	s2, s2, s16
1000de16c:     	mov	s16, v16[1]
1000de170:     	fadd	s2, s2, s16
1000de174:     	fmul.2d	v16, v19, v19
1000de178:     	fcvtn	v16.2s, v16.2d
1000de17c:     	fadd	s2, s2, s16
1000de180:     	mov	s16, v16[1]
1000de184:     	fadd	s2, s2, s16
1000de188:     	fmul.2d	v16, v21, v21
1000de18c:     	fcvtn	v16.2s, v16.2d
1000de190:     	fadd	s2, s2, s16
1000de194:     	mov	s16, v16[1]
1000de198:     	fadd	s2, s2, s16
1000de19c:     	fmul.2d	v16, v8, v8
1000de1a0:     	fcvtn	v16.2s, v16.2d
1000de1a4:     	fadd	s1, s1, s16
1000de1a8:     	mov	s16, v16[1]
1000de1ac:     	fadd	s1, s1, s16
1000de1b0:     	fmul.2d	v16, v18, v18
1000de1b4:     	fcvtn	v16.2s, v16.2d
1000de1b8:     	fadd	s1, s1, s16
1000de1bc:     	mov	s16, v16[1]
1000de1c0:     	fadd	s1, s1, s16
1000de1c4:     	fmul.2d	v16, v27, v27
1000de1c8:     	fcvtn	v16.2s, v16.2d
1000de1cc:     	fadd	s1, s1, s16
1000de1d0:     	mov	s16, v16[1]
1000de1d4:     	fadd	s1, s1, s16
1000de1d8:     	fmul.2d	v7, v7, v7
1000de1dc:     	fcvtn	v7.2s, v7.2d
1000de1e0:     	fadd	s2, s2, s7
1000de1e4:     	mov	s7, v7[1]
1000de1e8:     	fadd	s2, s2, s7
1000de1ec:     	fmul.2d	v7, v30, v30
1000de1f0:     	fcvtn	v7.2s, v7.2d
1000de1f4:     	fadd	s1, s1, s7
1000de1f8:     	mov	s7, v7[1]
1000de1fc:     	fadd	s1, s1, s7
1000de200:     	fmul.2d	v7, v20, v20
1000de204:     	fcvtn	v7.2s, v7.2d
1000de208:     	fadd	s3, s3, s7
1000de20c:     	mov	s7, v7[1]
1000de210:     	fadd	s3, s3, s7
1000de214:     	fmul.2d	v7, v17, v17
1000de218:     	fcvtn	v7.2s, v7.2d
1000de21c:     	fadd	s3, s3, s7
1000de220:     	mov	s7, v7[1]
1000de224:     	fadd	s3, s3, s7
1000de228:     	fmul.2d	v7, v26, v26
1000de22c:     	fcvtn	v7.2s, v7.2d
1000de230:     	fadd	s3, s3, s7
1000de234:     	mov	s7, v7[1]
1000de238:     	fadd	s3, s3, s7
1000de23c:     	fmul.2d	v6, v6, v6
1000de240:     	fcvtn	v6.2s, v6.2d
1000de244:     	fadd	s0, s0, s6
1000de248:     	mov	s6, v6[1]
1000de24c:     	fadd	s0, s0, s6
1000de250:     	fmul.2d	v6, v29, v29
1000de254:     	fcvtn	v6.2s, v6.2d
1000de258:     	fadd	s3, s3, s6
1000de25c:     	mov	s6, v6[1]
1000de260:     	fadd	s3, s3, s6
1000de264:     	fmul.2d	v5, v5, v5
1000de268:     	fcvtn	v5.2s, v5.2d
1000de26c:     	fadd	s0, s0, s5
1000de270:     	mov	s5, v5[1]
1000de274:     	fadd	s0, s0, s5
1000de278:     	fmul.2d	v4, v4, v4
1000de27c:     	fcvtn	v4.2s, v4.2d
1000de280:     	fadd	s0, s0, s4
1000de284:     	mov	s4, v4[1]
1000de288:     	fadd	s0, s0, s4
1000de28c:     	fmul.2d	v4, v28, v28
1000de290:     	fcvtn	v4.2s, v4.2d
1000de294:     	fadd	s0, s0, s4
1000de298:     	mov	s4, v4[1]
1000de29c:     	fadd	s0, s0, s4
1000de2a0:     	add	x12, x12, #256
1000de2a4:     	add	x13, x13, #64
1000de2a8:     	subs	x14, x14, #8
1000de2ac:     	b.ne	0x1000de0fc <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x7c>
1000de2b0:     	mov.s	v0[1], v3[0]
1000de2b4:     	mov.s	v0[2], v1[0]
1000de2b8:     	mov.s	v0[3], v2[0]
1000de2bc:     	cmp	x10, x11
1000de2c0:     	b.eq	0x1000de2fc <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x27c>
1000de2c4:     	add	x9, x9, #8
1000de2c8:     	add	x10, x0, #32
1000de2cc:     	sub	x8, x2, x8
1000de2d0:     	ldp	q2, q1, [x10], #32
1000de2d4:     	ld1r.2d	{ v3 }, [x9], #8
1000de2d8:     	fsub.2d	v2, v2, v3
1000de2dc:     	fsub.2d	v1, v1, v3
1000de2e0:     	fmul.2d	v1, v1, v1
1000de2e4:     	fmul.2d	v2, v2, v2
1000de2e8:     	fcvtn	v2.2s, v2.2d
1000de2ec:     	fcvtn2	v2.4s, v1.2d
1000de2f0:     	fadd.4s	v0, v0, v2
1000de2f4:     	subs	x8, x8, #1
1000de2f8:     	b.ne	0x1000de2d0 <void kernel<double, 4ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x250>
1000de2fc:     	str	q0, [x3]
1000de300:     	ldp	d9, d8, [sp], #16
1000de304:     	ret

00000001000de308 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000de308:     	cbz	x2, 0x1000de374 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x6c>
1000de30c:     	ldr	d0, [x1]
1000de310:     	ldp	q1, q2, [x0]
1000de314:     	fmul.2d	v2, v2, v0[0]
1000de318:     	fmul.2d	v0, v1, v0[0]
1000de31c:     	fcvtn	v0.2s, v0.2d
1000de320:     	fcvtn2	v0.4s, v2.2d
1000de324:     	fneg.4s	v0, v0
1000de328:     	str	q0, [x3]
1000de32c:     	cmp	x2, #1
1000de330:     	b.eq	0x1000de370 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x68>
1000de334:     	add	x8, x1, #8
1000de338:     	add	x9, x0, #32
1000de33c:     	lsl	x10, x2, #3
1000de340:     	sub	x10, x10, #8
1000de344:     	fcvtl	v1.2d, v0.2s
1000de348:     	fcvtl2	v2.2d, v0.4s
1000de34c:     	ldp	q0, q3, [x9], #32
1000de350:     	ld1r.2d	{ v4 }, [x8], #8
1000de354:     	fmls.2d	v2, v4, v3
1000de358:     	fmls.2d	v1, v4, v0
1000de35c:     	fcvtn	v0.2s, v1.2d
1000de360:     	fcvtn2	v0.4s, v2.2d
1000de364:     	subs	x10, x10, #8
1000de368:     	b.ne	0x1000de344 <void kernel<double, 4ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x3c>
1000de36c:     	str	q0, [x3]
1000de370:     	ret
1000de374:     	stp	xzr, xzr, [x3]
1000de378:     	ret

00000001000e0bd0 <void kernel<double, 4ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000e0bd0:     	cbz	x2, 0x1000e0bd8 <void kernel<double, 4ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000e0bd4:     	b	0x1000e0be4 <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000e0bd8:     	movi.2d	v0, #0000000000000000
1000e0bdc:     	stp	q0, q0, [x3]
1000e0be0:     	ret

00000001000e0ed8 <void kernel<double, 4ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000e0ed8:     	cbz	x2, 0x1000e0ee0 <void kernel<double, 4ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000e0edc:     	b	0x1000e0eec <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000e0ee0:     	movi.2d	v0, #0000000000000000
1000e0ee4:     	stp	q0, q0, [x3]
1000e0ee8:     	ret

00000001000e3c84 <void kernel<double, 4ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
1000e3c84:     	cbz	x2, 0x1000e3c8c <void kernel<double, 4ul, 4ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000e3c88:     	b	0x1000e3c9c <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000e3c8c:     	movi.2d	v0, #0000000000000000
1000e3c90:     	stp	q0, q0, [x3, #32]
1000e3c94:     	stp	q0, q0, [x3]
1000e3c98:     	ret

00000001000e40b8 <void kernel<double, 4ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
1000e40b8:     	cbz	x2, 0x1000e40c0 <void kernel<double, 4ul, 4ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000e40bc:     	b	0x1000e40d0 <void zvec::turbo::InterleavedDistanceMatrix<double, 4ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000e40c0:     	movi.2d	v0, #0000000000000000
1000e40c4:     	stp	q0, q0, [x3, #32]
1000e40c8:     	stp	q0, q0, [x3]
1000e40cc:     	ret

00000001000e62a4 <void kernel<double, 8ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000e62a4:     	cbz	x2, 0x1000e62ac <void kernel<double, 8ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000e62a8:     	b	0x1000e62b8 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000e62ac:     	movi.2d	v0, #0000000000000000
1000e62b0:     	stp	q0, q0, [x3]
1000e62b4:     	ret

00000001000e6360 <void kernel<double, 8ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000e6360:     	cbz	x2, 0x1000e6368 <void kernel<double, 8ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000e6364:     	b	0x1000e6374 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000e6368:     	movi.2d	v0, #0000000000000000
1000e636c:     	stp	q0, q0, [x3]
1000e6370:     	ret

00000001000eb060 <void kernel<double, 8ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000eb060:     	cbz	x2, 0x1000eb068 <void kernel<double, 8ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000eb064:     	b	0x1000eb078 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000eb068:     	movi.2d	v0, #0000000000000000
1000eb06c:     	stp	q0, q0, [x3, #32]
1000eb070:     	stp	q0, q0, [x3]
1000eb074:     	ret

00000001000eb1e8 <void kernel<double, 8ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000eb1e8:     	cbz	x2, 0x1000eb1f0 <void kernel<double, 8ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000eb1ec:     	b	0x1000eb200 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000eb1f0:     	movi.2d	v0, #0000000000000000
1000eb1f4:     	stp	q0, q0, [x3, #32]
1000eb1f8:     	stp	q0, q0, [x3]
1000eb1fc:     	ret

00000001000f115c <void kernel<double, 8ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
1000f115c:     	cbz	x2, 0x1000f1164 <void kernel<double, 8ul, 4ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000f1160:     	b	0x1000f117c <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000f1164:     	movi.2d	v0, #0000000000000000
1000f1168:     	stp	q0, q0, [x3, #96]
1000f116c:     	stp	q0, q0, [x3, #64]
1000f1170:     	stp	q0, q0, [x3, #32]
1000f1174:     	stp	q0, q0, [x3]
1000f1178:     	ret

00000001000f13c8 <void kernel<double, 8ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
1000f13c8:     	cbz	x2, 0x1000f13d0 <void kernel<double, 8ul, 4ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000f13cc:     	b	0x1000f13e8 <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000f13d0:     	movi.2d	v0, #0000000000000000
1000f13d4:     	stp	q0, q0, [x3, #96]
1000f13d8:     	stp	q0, q0, [x3, #64]
1000f13dc:     	stp	q0, q0, [x3, #32]
1000f13e0:     	stp	q0, q0, [x3]
1000f13e4:     	ret

00000001000f5ddc <void kernel<double, 8ul, 8ul, false>(double const*, double const*, unsigned long, float*)>:
1000f5ddc:     	cbz	x2, 0x1000f5de4 <void kernel<double, 8ul, 8ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000f5de0:     	b	0x1000f5e0c <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1000f5de4:     	movi.2d	v0, #0000000000000000
1000f5de8:     	stp	q0, q0, [x3, #224]
1000f5dec:     	stp	q0, q0, [x3, #192]
1000f5df0:     	stp	q0, q0, [x3, #160]
1000f5df4:     	stp	q0, q0, [x3, #128]
1000f5df8:     	stp	q0, q0, [x3, #96]
1000f5dfc:     	stp	q0, q0, [x3, #64]
1000f5e00:     	stp	q0, q0, [x3, #32]
1000f5e04:     	stp	q0, q0, [x3]
1000f5e08:     	ret

00000001000f628c <void kernel<double, 8ul, 8ul, true>(double const*, double const*, unsigned long, float*)>:
1000f628c:     	cbz	x2, 0x1000f6294 <void kernel<double, 8ul, 8ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000f6290:     	b	0x1000f62bc <void zvec::turbo::InterleavedDistanceMatrix<double, 8ul, (zvec::turbo::MetricType)2>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1000f6294:     	movi.2d	v0, #0000000000000000
1000f6298:     	stp	q0, q0, [x3, #224]
1000f629c:     	stp	q0, q0, [x3, #192]
1000f62a0:     	stp	q0, q0, [x3, #160]
1000f62a4:     	stp	q0, q0, [x3, #128]
1000f62a8:     	stp	q0, q0, [x3, #96]
1000f62ac:     	stp	q0, q0, [x3, #64]
1000f62b0:     	stp	q0, q0, [x3, #32]
1000f62b4:     	stp	q0, q0, [x3]
1000f62b8:     	ret

00000001000f7bd4 <void kernel<double, 16ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1000f7bd4:     	cbz	x2, 0x1000f7bdc <void kernel<double, 16ul, 1ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000f7bd8:     	b	0x1000f7bec <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000f7bdc:     	movi.2d	v0, #0000000000000000
1000f7be0:     	stp	q0, q0, [x3, #32]
1000f7be4:     	stp	q0, q0, [x3]
1000f7be8:     	ret

00000001000f7d38 <void kernel<double, 16ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
1000f7d38:     	cbz	x2, 0x1000f7d40 <void kernel<double, 16ul, 1ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000f7d3c:     	b	0x1000f7d50 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<1ul>(double const*, double const*, unsigned long, float*)>
1000f7d40:     	movi.2d	v0, #0000000000000000
1000f7d44:     	stp	q0, q0, [x3, #32]
1000f7d48:     	stp	q0, q0, [x3]
1000f7d4c:     	ret

00000001000f9ac0 <void kernel<double, 16ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
1000f9ac0:     	cbz	x2, 0x1000f9ac8 <void kernel<double, 16ul, 2ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000f9ac4:     	b	0x1000f9ae0 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000f9ac8:     	movi.2d	v0, #0000000000000000
1000f9acc:     	stp	q0, q0, [x3, #96]
1000f9ad0:     	stp	q0, q0, [x3, #64]
1000f9ad4:     	stp	q0, q0, [x3, #32]
1000f9ad8:     	stp	q0, q0, [x3]
1000f9adc:     	ret

00000001000f9d1c <void kernel<double, 16ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
1000f9d1c:     	cbz	x2, 0x1000f9d24 <void kernel<double, 16ul, 2ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000f9d20:     	b	0x1000f9d3c <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<2ul>(double const*, double const*, unsigned long, float*)>
1000f9d24:     	movi.2d	v0, #0000000000000000
1000f9d28:     	stp	q0, q0, [x3, #96]
1000f9d2c:     	stp	q0, q0, [x3, #64]
1000f9d30:     	stp	q0, q0, [x3, #32]
1000f9d34:     	stp	q0, q0, [x3]
1000f9d38:     	ret

00000001000fc628 <void kernel<double, 16ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
1000fc628:     	cbz	x2, 0x1000fc630 <void kernel<double, 16ul, 4ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000fc62c:     	b	0x1000fc658 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000fc630:     	movi.2d	v0, #0000000000000000
1000fc634:     	stp	q0, q0, [x3, #224]
1000fc638:     	stp	q0, q0, [x3, #192]
1000fc63c:     	stp	q0, q0, [x3, #160]
1000fc640:     	stp	q0, q0, [x3, #128]
1000fc644:     	stp	q0, q0, [x3, #96]
1000fc648:     	stp	q0, q0, [x3, #64]
1000fc64c:     	stp	q0, q0, [x3, #32]
1000fc650:     	stp	q0, q0, [x3]
1000fc654:     	ret

00000001000fca74 <void kernel<double, 16ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
1000fca74:     	cbz	x2, 0x1000fca7c <void kernel<double, 16ul, 4ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1000fca78:     	b	0x1000fcaa4 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<4ul>(double const*, double const*, unsigned long, float*)>
1000fca7c:     	movi.2d	v0, #0000000000000000
1000fca80:     	stp	q0, q0, [x3, #224]
1000fca84:     	stp	q0, q0, [x3, #192]
1000fca88:     	stp	q0, q0, [x3, #160]
1000fca8c:     	stp	q0, q0, [x3, #128]
1000fca90:     	stp	q0, q0, [x3, #96]
1000fca94:     	stp	q0, q0, [x3, #64]
1000fca98:     	stp	q0, q0, [x3, #32]
1000fca9c:     	stp	q0, q0, [x3]
1000fcaa0:     	ret

00000001000ff8a0 <void kernel<double, 16ul, 8ul, false>(double const*, double const*, unsigned long, float*)>:
1000ff8a0:     	cbz	x2, 0x1000ff8a8 <void kernel<double, 16ul, 8ul, false>(double const*, double const*, unsigned long, float*)+0x8>
1000ff8a4:     	b	0x1000ff8f0 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1000ff8a8:     	movi.2d	v0, #0000000000000000
1000ff8ac:     	stp	q0, q0, [x3, #480]
1000ff8b0:     	stp	q0, q0, [x3, #448]
1000ff8b4:     	stp	q0, q0, [x3, #416]
1000ff8b8:     	stp	q0, q0, [x3, #384]
1000ff8bc:     	stp	q0, q0, [x3, #352]
1000ff8c0:     	stp	q0, q0, [x3, #320]
1000ff8c4:     	stp	q0, q0, [x3, #288]
1000ff8c8:     	stp	q0, q0, [x3, #256]
1000ff8cc:     	stp	q0, q0, [x3, #224]
1000ff8d0:     	stp	q0, q0, [x3, #192]
1000ff8d4:     	stp	q0, q0, [x3, #160]
1000ff8d8:     	stp	q0, q0, [x3, #128]
1000ff8dc:     	stp	q0, q0, [x3, #96]
1000ff8e0:     	stp	q0, q0, [x3, #64]
1000ff8e4:     	stp	q0, q0, [x3, #32]
1000ff8e8:     	stp	q0, q0, [x3]
1000ff8ec:     	ret

00000001001001bc <void kernel<double, 16ul, 8ul, true>(double const*, double const*, unsigned long, float*)>:
1001001bc:     	cbz	x2, 0x1001001c4 <void kernel<double, 16ul, 8ul, true>(double const*, double const*, unsigned long, float*)+0x8>
1001001c0:     	b	0x10010020c <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::ComputeSmall<8ul>(double const*, double const*, unsigned long, float*)>
1001001c4:     	movi.2d	v0, #0000000000000000
1001001c8:     	stp	q0, q0, [x3, #480]
1001001cc:     	stp	q0, q0, [x3, #448]
1001001d0:     	stp	q0, q0, [x3, #416]
1001001d4:     	stp	q0, q0, [x3, #384]
1001001d8:     	stp	q0, q0, [x3, #352]
1001001dc:     	stp	q0, q0, [x3, #320]
1001001e0:     	stp	q0, q0, [x3, #288]
1001001e4:     	stp	q0, q0, [x3, #256]
1001001e8:     	stp	q0, q0, [x3, #224]
1001001ec:     	stp	q0, q0, [x3, #192]
1001001f0:     	stp	q0, q0, [x3, #160]
1001001f4:     	stp	q0, q0, [x3, #128]
1001001f8:     	stp	q0, q0, [x3, #96]
1001001fc:     	stp	q0, q0, [x3, #64]
100100200:     	stp	q0, q0, [x3, #32]
100100204:     	stp	q0, q0, [x3]
100100208:     	ret

00000001001023d8 <void kernel<double, 16ul, 16ul, false>(double const*, double const*, unsigned long, float*)>:
1001023d8:     	b	0x1001023dc <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)0>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

00000001001024c4 <void kernel<double, 16ul, 16ul, true>(double const*, double const*, unsigned long, float*)>:
1001024c4:     	b	0x1001024c8 <void zvec::turbo::InterleavedDistanceMatrix<double, 16ul, (zvec::turbo::MetricType)2>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

00000001001039b4 <void kernel<double, 32ul, 1ul, false>(double const*, double const*, unsigned long, float*)>:
1001039b4:     	b	0x1001039b8 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<1ul>(double const*, double const*, unsigned long, float*)>

0000000100103b18 <void kernel<double, 32ul, 1ul, true>(double const*, double const*, unsigned long, float*)>:
100103b18:     	b	0x100103b1c <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<1ul>(double const*, double const*, unsigned long, float*)>

0000000100105acc <void kernel<double, 32ul, 2ul, false>(double const*, double const*, unsigned long, float*)>:
100105acc:     	b	0x100105ad0 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<2ul>(double const*, double const*, unsigned long, float*)>

0000000100105d9c <void kernel<double, 32ul, 2ul, true>(double const*, double const*, unsigned long, float*)>:
100105d9c:     	b	0x100105da0 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<2ul>(double const*, double const*, unsigned long, float*)>

0000000100108b00 <void kernel<double, 32ul, 4ul, false>(double const*, double const*, unsigned long, float*)>:
100108b00:     	b	0x100108b04 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<4ul>(double const*, double const*, unsigned long, float*)>

0000000100108cc0 <void kernel<double, 32ul, 4ul, true>(double const*, double const*, unsigned long, float*)>:
100108cc0:     	b	0x100108cc4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<4ul>(double const*, double const*, unsigned long, float*)>

000000010010bac0 <void kernel<double, 32ul, 8ul, false>(double const*, double const*, unsigned long, float*)>:
10010bac0:     	b	0x10010bac4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<8ul>(double const*, double const*, unsigned long, float*)>

000000010010bc44 <void kernel<double, 32ul, 8ul, true>(double const*, double const*, unsigned long, float*)>:
10010bc44:     	b	0x10010bc48 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<8ul>(double const*, double const*, unsigned long, float*)>

000000010010dde0 <void kernel<double, 32ul, 16ul, false>(double const*, double const*, unsigned long, float*)>:
10010dde0:     	b	0x10010dde4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

000000010010df64 <void kernel<double, 32ul, 16ul, true>(double const*, double const*, unsigned long, float*)>:
10010df64:     	b	0x10010df68 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<16ul>(double const*, double const*, unsigned long, float*)>

00000001001100e0 <void kernel<double, 32ul, 32ul, false>(double const*, double const*, unsigned long, float*)>:
1001100e0:     	b	0x1001100e4 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)0>::Compute<32ul>(double const*, double const*, unsigned long, float*)>

0000000100110264 <void kernel<double, 32ul, 32ul, true>(double const*, double const*, unsigned long, float*)>:
100110264:     	b	0x100110268 <void zvec::turbo::InterleavedDistanceMatrix<double, 32ul, (zvec::turbo::MetricType)2>::Compute<32ul>(double const*, double const*, unsigned long, float*)>
