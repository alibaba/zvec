00000001000c90ec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c90ec:     	sub	sp, sp, #272
1000c90f0:     	stp	x28, x27, [sp, #176]
1000c90f4:     	stp	x26, x25, [sp, #192]
1000c90f8:     	stp	x24, x23, [sp, #208]
1000c90fc:     	stp	x22, x21, [sp, #224]
1000c9100:     	stp	x20, x19, [sp, #240]
1000c9104:     	stp	x29, x30, [sp, #256]
1000c9108:     	add	x29, sp, #256
1000c910c:     	str	x3, [sp]
1000c9110:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x80>
1000c9114:     	ldr	x8, [x8, #392]
1000c9118:     	ldr	x8, [x8]
1000c911c:     	stur	x8, [x29, #-96]
1000c9120:     	movi.2d	v0, #0000000000000000
1000c9124:     	stp	q0, q0, [sp, #128]
1000c9128:     	stp	q0, q0, [sp, #96]
1000c912c:     	stp	q0, q0, [sp, #64]
1000c9130:     	stp	q0, q0, [sp, #32]
1000c9134:     	ands	x8, x2, #0xfffffffffffffffe
1000c9138:     	b.eq	0x1000c92bc <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c913c:     	add	x8, x1, x8
1000c9140:     	str	x8, [sp, #8]
1000c9144:     	adrp	x9, 0x10016a000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0xac>
1000c9148:     	add	x9, x9, #1468
1000c914c:     	mov	x11, #0
1000c9150:     	ldp	w4, w23, [x1]
1000c9154:     	ubfx	x8, x4, #8, #4
1000c9158:     	stp	x1, x8, [sp, #16]
1000c915c:     	ubfx	x13, x4, #16, #4
1000c9160:     	and	x14, x4, #0xf
1000c9164:     	ubfx	x15, x4, #24, #4
1000c9168:     	ubfx	x16, x4, #4, #4
1000c916c:     	ubfx	x17, x4, #12, #4
1000c9170:     	ubfx	x2, x4, #20, #4
1000c9174:     	lsr	x4, x4, #28
1000c9178:     	and	x5, x23, #0xf
1000c917c:     	ubfx	x6, x23, #8, #4
1000c9180:     	ubfx	x7, x23, #16, #4
1000c9184:     	ubfx	x19, x23, #24, #4
1000c9188:     	ubfx	x20, x23, #4, #4
1000c918c:     	ubfx	x21, x23, #12, #4
1000c9190:     	ubfx	x22, x23, #20, #4
1000c9194:     	lsr	x23, x23, #28
1000c9198:     	ldr	w24, [x0, x11]
1000c919c:     	lsl	w25, w24, #4
1000c91a0:     	and	x25, x25, #0xf0
1000c91a4:     	add	x25, x9, x25
1000c91a8:     	and	x26, x24, #0xf0
1000c91ac:     	add	x26, x9, x26
1000c91b0:     	lsr	x27, x24, #4
1000c91b4:     	and	x27, x27, #0xf0
1000c91b8:     	add	x27, x9, x27
1000c91bc:     	lsr	x28, x24, #8
1000c91c0:     	and	x28, x28, #0xf0
1000c91c4:     	add	x28, x9, x28
1000c91c8:     	lsr	x30, x24, #12
1000c91cc:     	and	x30, x30, #0xf0
1000c91d0:     	add	x30, x9, x30
1000c91d4:     	lsr	x8, x24, #16
1000c91d8:     	and	x8, x8, #0xf0
1000c91dc:     	add	x8, x9, x8
1000c91e0:     	lsr	x3, x24, #20
1000c91e4:     	and	x3, x3, #0xf0
1000c91e8:     	add	x3, x9, x3
1000c91ec:     	lsr	x24, x24, #24
1000c91f0:     	and	x24, x24, #0xf0
1000c91f4:     	ldrsb	w10, [x25, x14]
1000c91f8:     	ldr	x12, [sp, #24]
1000c91fc:     	ldrsb	w1, [x27, x12]
1000c9200:     	ldrsb	w12, [x30, x13]
1000c9204:     	add	w10, w10, w1
1000c9208:     	add	w10, w10, w12
1000c920c:     	ldrsb	w12, [x3, x15]
1000c9210:     	ldrsb	w1, [x26, x16]
1000c9214:     	add	w10, w10, w12
1000c9218:     	add	w10, w10, w1
1000c921c:     	ldrsb	w12, [x28, x17]
1000c9220:     	ldrsb	w1, [x8, x2]
1000c9224:     	add	x24, x9, x24
1000c9228:     	add	w10, w10, w12
1000c922c:     	add	w10, w10, w1
1000c9230:     	ldrsb	w12, [x24, x4]
1000c9234:     	add	w10, w10, w12
1000c9238:     	scvtf	s0, w10
1000c923c:     	add	x10, sp, #32
1000c9240:     	add	x10, x10, x11
1000c9244:     	ldr	s1, [x10]
1000c9248:     	ldrsb	w12, [x25, x5]
1000c924c:     	fadd	s0, s1, s0
1000c9250:     	ldrsb	w1, [x27, x6]
1000c9254:     	ldrsb	w25, [x30, x7]
1000c9258:     	add	w12, w12, w1
1000c925c:     	add	w12, w12, w25
1000c9260:     	ldrsb	w1, [x3, x19]
1000c9264:     	ldrsb	w3, [x26, x20]
1000c9268:     	add	w12, w12, w1
1000c926c:     	add	w12, w12, w3
1000c9270:     	ldrsb	w1, [x28, x21]
1000c9274:     	ldrsb	w8, [x8, x22]
1000c9278:     	add	w12, w12, w1
1000c927c:     	add	w8, w12, w8
1000c9280:     	ldrsb	w12, [x24, x23]
1000c9284:     	add	w8, w8, w12
1000c9288:     	scvtf	s1, w8
1000c928c:     	str	s0, [x10]
1000c9290:     	ldr	s0, [x10, #64]
1000c9294:     	fadd	s0, s0, s1
1000c9298:     	str	s0, [x10, #64]
1000c929c:     	add	x11, x11, #4
1000c92a0:     	cmp	x11, #64
1000c92a4:     	b.ne	0x1000c9198 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c92a8:     	add	x0, x0, #64
1000c92ac:     	ldp	x8, x1, [sp, #8]
1000c92b0:     	add	x1, x1, #8
1000c92b4:     	cmp	x1, x8
1000c92b8:     	b.ne	0x1000c914c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c92bc:     	ldp	q0, q1, [sp, #96]
1000c92c0:     	ldr	x8, [sp]
1000c92c4:     	stp	q0, q1, [x8, #64]
1000c92c8:     	ldp	q0, q1, [sp, #128]
1000c92cc:     	stp	q0, q1, [x8, #96]
1000c92d0:     	ldp	q0, q1, [sp, #32]
1000c92d4:     	stp	q0, q1, [x8]
1000c92d8:     	ldp	q0, q1, [sp, #64]
1000c92dc:     	stp	q0, q1, [x8, #32]
1000c92e0:     	ldur	x8, [x29, #-96]
1000c92e4:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 4ul, false>(char const*)+0x254>
1000c92e8:     	ldr	x9, [x9, #392]
1000c92ec:     	ldr	x9, [x9]
1000c92f0:     	cmp	x9, x8
1000c92f4:     	b.ne	0x1000c9318 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c92f8:     	ldp	x29, x30, [sp, #256]
1000c92fc:     	ldp	x20, x19, [sp, #240]
1000c9300:     	ldp	x22, x21, [sp, #224]
1000c9304:     	ldp	x24, x23, [sp, #208]
1000c9308:     	ldp	x26, x25, [sp, #192]
1000c930c:     	ldp	x28, x27, [sp, #176]
1000c9310:     	add	sp, sp, #272
1000c9314:     	ret
1000c9318:     	bl	0x100163694 <_strcmp+0x100163694>

