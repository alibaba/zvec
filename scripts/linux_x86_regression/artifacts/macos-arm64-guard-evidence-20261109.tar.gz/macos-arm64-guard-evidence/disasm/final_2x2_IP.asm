00000001000b88f4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000b88f4:     	stp	x22, x21, [sp, #-32]!
1000b88f8:     	stp	x20, x19, [sp, #16]
1000b88fc:     	ands	x8, x2, #0xfffffffffffffffe
1000b8900:     	b.eq	0x1000b8b84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x290>
1000b8904:     	add	x8, x1, x8
1000b8908:     	movi	d0, #0000000000000000
1000b890c:     	adrp	x9, 0x100169000 <void run<unsigned char, 4ul, 1ul, false>(char const*)+0x20>
1000b8910:     	add	x9, x9, #4028
1000b8914:     	movi	d1, #0000000000000000
1000b8918:     	movi	d2, #0000000000000000
1000b891c:     	movi	d3, #0000000000000000
1000b8920:     	ldp	w10, w11, [x0]
1000b8924:     	lsl	w12, w10, #4
1000b8928:     	and	x14, x12, #0xf0
1000b892c:     	mov	x15, x14
1000b8930:     	ldp	w12, w13, [x1]
1000b8934:     	bfxil	x15, x12, #0, #4
1000b8938:     	ldrsb	w15, [x9, x15]
1000b893c:     	and	x16, x10, #0xf0
1000b8940:     	mov	x17, x16
1000b8944:     	bfxil	x17, x12, #4, #4
1000b8948:     	ldrsb	w17, [x9, x17]
1000b894c:     	lsr	x2, x10, #4
1000b8950:     	and	x2, x2, #0xf0
1000b8954:     	mov	x4, x2
1000b8958:     	bfxil	x4, x12, #8, #4
1000b895c:     	ldrsb	w4, [x9, x4]
1000b8960:     	lsr	x5, x10, #8
1000b8964:     	and	x5, x5, #0xf0
1000b8968:     	mov	x6, x5
1000b896c:     	bfxil	x6, x12, #12, #4
1000b8970:     	ldrsb	w6, [x9, x6]
1000b8974:     	lsr	x7, x10, #12
1000b8978:     	and	x7, x7, #0xf0
1000b897c:     	mov	x19, x7
1000b8980:     	bfxil	x19, x12, #16, #4
1000b8984:     	ldrsb	w19, [x9, x19]
1000b8988:     	add	w15, w15, w17
1000b898c:     	add	w15, w15, w4
1000b8990:     	lsr	x17, x10, #16
1000b8994:     	and	x17, x17, #0xf0
1000b8998:     	mov	x4, x17
1000b899c:     	bfxil	x4, x12, #20, #4
1000b89a0:     	add	w15, w15, w6
1000b89a4:     	add	w15, w15, w19
1000b89a8:     	ldrsb	w4, [x9, x4]
1000b89ac:     	lsr	x6, x10, #20
1000b89b0:     	and	x6, x6, #0xf0
1000b89b4:     	mov	x19, x6
1000b89b8:     	bfxil	x19, x12, #24, #4
1000b89bc:     	ldrsb	w19, [x9, x19]
1000b89c0:     	add	w15, w15, w4
1000b89c4:     	add	w15, w15, w19
1000b89c8:     	lsr	x10, x10, #24
1000b89cc:     	and	x4, x10, #0xf0
1000b89d0:     	lsr	x10, x12, #28
1000b89d4:     	orr	x19, x4, x10
1000b89d8:     	ldrsb	w19, [x9, x19]
1000b89dc:     	add	w15, w15, w19
1000b89e0:     	scvtf	s4, w15
1000b89e4:     	fadd	s0, s0, s4
1000b89e8:     	bfxil	x14, x13, #0, #4
1000b89ec:     	ldrsb	w14, [x9, x14]
1000b89f0:     	and	x15, x13, #0xf
1000b89f4:     	ubfx	x19, x13, #4, #4
1000b89f8:     	bfxil	x16, x13, #4, #4
1000b89fc:     	ldrsb	w16, [x9, x16]
1000b8a00:     	ubfx	x20, x13, #8, #4
1000b8a04:     	bfxil	x2, x13, #8, #4
1000b8a08:     	ldrsb	w2, [x9, x2]
1000b8a0c:     	add	w14, w14, w16
1000b8a10:     	add	w14, w14, w2
1000b8a14:     	ubfx	x16, x13, #12, #4
1000b8a18:     	bfxil	x5, x13, #12, #4
1000b8a1c:     	ldrsb	w2, [x9, x5]
1000b8a20:     	bfxil	x7, x13, #16, #4
1000b8a24:     	ldrsb	w5, [x9, x7]
1000b8a28:     	ubfx	x7, x13, #16, #4
1000b8a2c:     	add	w14, w14, w2
1000b8a30:     	add	w14, w14, w5
1000b8a34:     	bfxil	x17, x13, #20, #4
1000b8a38:     	ldrsb	w17, [x9, x17]
1000b8a3c:     	bfxil	x6, x13, #24, #4
1000b8a40:     	ldrsb	w2, [x9, x6]
1000b8a44:     	add	w14, w14, w17
1000b8a48:     	add	w17, w14, w2
1000b8a4c:     	lsr	x14, x13, #28
1000b8a50:     	orr	x2, x4, x14
1000b8a54:     	ldrsb	w2, [x9, x2]
1000b8a58:     	add	w17, w17, w2
1000b8a5c:     	scvtf	s4, w17
1000b8a60:     	ubfx	x17, x13, #20, #4
1000b8a64:     	fadd	s2, s2, s4
1000b8a68:     	lsl	w2, w11, #4
1000b8a6c:     	and	x2, x2, #0xf0
1000b8a70:     	orr	w15, w2, w15
1000b8a74:     	bfxil	x2, x12, #0, #4
1000b8a78:     	ldrsb	w2, [x9, x2]
1000b8a7c:     	and	x4, x11, #0xf0
1000b8a80:     	orr	w5, w4, w19
1000b8a84:     	bfxil	x4, x12, #4, #4
1000b8a88:     	ldrsb	w4, [x9, x4]
1000b8a8c:     	lsr	x6, x11, #4
1000b8a90:     	and	x6, x6, #0xf0
1000b8a94:     	orr	w19, w6, w20
1000b8a98:     	bfxil	x6, x12, #8, #4
1000b8a9c:     	ldrsb	w6, [x9, x6]
1000b8aa0:     	add	w2, w2, w4
1000b8aa4:     	add	w2, w2, w6
1000b8aa8:     	lsr	x4, x11, #8
1000b8aac:     	and	x4, x4, #0xf0
1000b8ab0:     	orr	w16, w4, w16
1000b8ab4:     	lsr	x6, x11, #12
1000b8ab8:     	and	x6, x6, #0xf0
1000b8abc:     	orr	w7, w6, w7
1000b8ac0:     	lsr	x20, x11, #16
1000b8ac4:     	and	x20, x20, #0xf0
1000b8ac8:     	orr	w17, w20, w17
1000b8acc:     	lsr	x21, x11, #20
1000b8ad0:     	and	x21, x21, #0xf0
1000b8ad4:     	ubfx	x13, x13, #24, #4
1000b8ad8:     	orr	w13, w21, w13
1000b8adc:     	bfxil	x4, x12, #12, #4
1000b8ae0:     	ldrsb	w4, [x9, x4]
1000b8ae4:     	bfxil	x6, x12, #16, #4
1000b8ae8:     	ldrsb	w6, [x9, x6]
1000b8aec:     	bfxil	x20, x12, #20, #4
1000b8af0:     	ldrsb	w20, [x9, x20]
1000b8af4:     	bfxil	x21, x12, #24, #4
1000b8af8:     	ldrsb	w12, [x9, x21]
1000b8afc:     	add	w2, w2, w4
1000b8b00:     	add	w2, w2, w6
1000b8b04:     	add	w2, w2, w20
1000b8b08:     	add	w12, w2, w12
1000b8b0c:     	lsr	x11, x11, #24
1000b8b10:     	and	x11, x11, #0xf0
1000b8b14:     	orr	x10, x11, x10
1000b8b18:     	ldrsb	w10, [x9, x10]
1000b8b1c:     	add	w10, w12, w10
1000b8b20:     	scvtf	s4, w10
1000b8b24:     	fadd	s1, s1, s4
1000b8b28:     	ldrsb	w10, [x9, w15, uxtw]
1000b8b2c:     	ldrsb	w12, [x9, w5, uxtw]
1000b8b30:     	ldrsb	w15, [x9, w19, uxtw]
1000b8b34:     	add	w10, w10, w12
1000b8b38:     	add	w10, w10, w15
1000b8b3c:     	ldrsb	w12, [x9, w16, uxtw]
1000b8b40:     	ldrsb	w15, [x9, w7, uxtw]
1000b8b44:     	add	w10, w10, w12
1000b8b48:     	add	w10, w10, w15
1000b8b4c:     	ldrsb	w12, [x9, w17, uxtw]
1000b8b50:     	ldrsb	w13, [x9, w13, uxtw]
1000b8b54:     	add	w10, w10, w12
1000b8b58:     	add	w10, w10, w13
1000b8b5c:     	orr	w11, w11, w14
1000b8b60:     	ldrsb	w11, [x9, w11, uxtw]
1000b8b64:     	add	w10, w10, w11
1000b8b68:     	scvtf	s4, w10
1000b8b6c:     	fadd	s3, s3, s4
1000b8b70:     	add	x0, x0, #8
1000b8b74:     	add	x1, x1, #8
1000b8b78:     	cmp	x1, x8
1000b8b7c:     	b.ne	0x1000b8920 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2c>
1000b8b80:     	b	0x1000b8b94 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 2ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000b8b84:     	movi	d0, #0000000000000000
1000b8b88:     	movi	d1, #0000000000000000
1000b8b8c:     	movi	d2, #0000000000000000
1000b8b90:     	movi	d3, #0000000000000000
1000b8b94:     	str	s0, [x3]
1000b8b98:     	str	s1, [x3, #4]
1000b8b9c:     	str	s2, [x3, #8]
1000b8ba0:     	str	s3, [x3, #12]
1000b8ba4:     	ldp	x20, x19, [sp, #16]
1000b8ba8:     	ldp	x22, x21, [sp], #32
1000b8bac:     	ret

