00000001000d9bc8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d9bc8:     	stp	x28, x27, [sp, #-64]!
1000d9bcc:     	stp	x22, x21, [sp, #16]
1000d9bd0:     	stp	x20, x19, [sp, #32]
1000d9bd4:     	stp	x29, x30, [sp, #48]
1000d9bd8:     	add	x29, sp, #48
1000d9bdc:     	mov	w9, #4112
1000d9be0:     	adrp	x16, 0x10016c000 <void kernel<unsigned char, 32ul, 32ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa8>
1000d9be4:     	ldr	x16, [x16, #304]
1000d9be8:     	blr	x16
1000d9bec:     	sub	sp, sp, #1, lsl #12     ; =4096
1000d9bf0:     	sub	sp, sp, #16
1000d9bf4:     	mov	x19, x3
1000d9bf8:     	mov	x20, x1
1000d9bfc:     	mov	x21, x0
1000d9c00:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x10>
1000d9c04:     	ldr	x8, [x8, #392]
1000d9c08:     	ldr	x8, [x8]
1000d9c0c:     	stur	x8, [x29, #-56]
1000d9c10:     	lsl	x8, x2, #4
1000d9c14:     	and	x22, x8, #0xffffffffffffffe0
1000d9c18:     	add	x0, sp, #8
1000d9c1c:     	mov	w1, #4096
1000d9c20:     	bl	0x1001636ac <_strcmp+0x1001636ac>
1000d9c24:     	cbz	x22, 0x1000d9d3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x174>
1000d9c28:     	add	x8, x20, x22
1000d9c2c:     	adrp	x9, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x34>
1000d9c30:     	add	x9, x9, #1724
1000d9c34:     	mov	x10, #0
1000d9c38:     	add	x11, sp, #8
1000d9c3c:     	mov	x12, #0
1000d9c40:     	ldr	w2, [x21, x10, lsl #2]
1000d9c44:     	lsl	w13, w2, #4
1000d9c48:     	and	x13, x13, #0xf0
1000d9c4c:     	and	x14, x2, #0xf0
1000d9c50:     	lsr	x15, x2, #4
1000d9c54:     	and	x15, x15, #0xf0
1000d9c58:     	lsr	x16, x2, #8
1000d9c5c:     	and	x16, x16, #0xf0
1000d9c60:     	lsr	x17, x2, #12
1000d9c64:     	and	x17, x17, #0xf0
1000d9c68:     	lsr	x0, x2, #16
1000d9c6c:     	and	x0, x0, #0xf0
1000d9c70:     	lsr	x1, x2, #20
1000d9c74:     	and	x1, x1, #0xf0
1000d9c78:     	lsr	x2, x2, #24
1000d9c7c:     	and	x2, x2, #0xf0
1000d9c80:     	mov	x3, x11
1000d9c84:     	ldr	w4, [x20, x12]
1000d9c88:     	and	x5, x4, #0xf
1000d9c8c:     	orr	x5, x13, x5
1000d9c90:     	ldrb	w5, [x9, x5]
1000d9c94:     	ubfx	x6, x4, #4, #4
1000d9c98:     	orr	x6, x14, x6
1000d9c9c:     	ldrb	w6, [x9, x6]
1000d9ca0:     	ubfx	x7, x4, #8, #4
1000d9ca4:     	orr	x7, x15, x7
1000d9ca8:     	ldrb	w7, [x9, x7]
1000d9cac:     	add	w5, w5, w6
1000d9cb0:     	add	w5, w5, w7
1000d9cb4:     	ubfx	x6, x4, #12, #4
1000d9cb8:     	orr	x6, x16, x6
1000d9cbc:     	ldrb	w6, [x9, x6]
1000d9cc0:     	ubfx	x7, x4, #16, #4
1000d9cc4:     	orr	x7, x17, x7
1000d9cc8:     	ldrb	w7, [x9, x7]
1000d9ccc:     	add	w5, w5, w6
1000d9cd0:     	add	w5, w5, w7
1000d9cd4:     	ubfx	x6, x4, #20, #4
1000d9cd8:     	orr	x6, x0, x6
1000d9cdc:     	ldrb	w6, [x9, x6]
1000d9ce0:     	ubfx	x7, x4, #24, #4
1000d9ce4:     	orr	x7, x1, x7
1000d9ce8:     	ldrb	w7, [x9, x7]
1000d9cec:     	add	w5, w5, w6
1000d9cf0:     	add	w5, w5, w7
1000d9cf4:     	orr	x4, x2, x4, lsr #28
1000d9cf8:     	ldrb	w4, [x9, x4]
1000d9cfc:     	add	w4, w5, w4
1000d9d00:     	scvtf	s0, w4
1000d9d04:     	ldr	s1, [x3]
1000d9d08:     	fadd	s0, s1, s0
1000d9d0c:     	str	s0, [x3], #128
1000d9d10:     	add	x12, x12, #4
1000d9d14:     	cmp	x12, #128
1000d9d18:     	b.ne	0x1000d9c84 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xbc>
1000d9d1c:     	add	x10, x10, #1
1000d9d20:     	add	x11, x11, #4
1000d9d24:     	cmp	x10, #32
1000d9d28:     	b.ne	0x1000d9c3c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x74>
1000d9d2c:     	add	x21, x21, #128
1000d9d30:     	add	x20, x20, #128
1000d9d34:     	cmp	x20, x8
1000d9d38:     	b.ne	0x1000d9c34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x6c>
1000d9d3c:     	add	x1, sp, #8
1000d9d40:     	mov	x0, x19
1000d9d44:     	mov	w2, #4096
1000d9d48:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d9d4c:     	ldur	x8, [x29, #-56]
1000d9d50:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x160>
1000d9d54:     	ldr	x9, [x9, #392]
1000d9d58:     	ldr	x9, [x9]
1000d9d5c:     	cmp	x9, x8
1000d9d60:     	b.ne	0x1000d9d80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<32ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1b8>
1000d9d64:     	add	sp, sp, #1, lsl #12     ; =4096
1000d9d68:     	add	sp, sp, #16
1000d9d6c:     	ldp	x29, x30, [sp, #48]
1000d9d70:     	ldp	x20, x19, [sp, #32]
1000d9d74:     	ldp	x22, x21, [sp, #16]
1000d9d78:     	ldp	x28, x27, [sp], #64
1000d9d7c:     	ret
1000d9d80:     	bl	0x100163694 <_strcmp+0x100163694>

