
bin/final_matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100161c50 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)>:
100161c50:     	cbz	x2, 0x100161c68 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0x18>
100161c54:     	cmp	x2, #8
100161c58:     	b.hs	0x100161c74 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0x24>
100161c5c:     	mov	x8, #0
100161c60:     	movi	d0, #0000000000000000
100161c64:     	b	0x100161d08 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0xb8>
100161c68:     	movi	d0, #0000000000000000
100161c6c:     	str	s0, [x3]
100161c70:     	ret
100161c74:     	and	x8, x2, #0xfffffffffffffff8
100161c78:     	add	x9, x0, #32
100161c7c:     	add	x10, x1, #32
100161c80:     	movi	d0, #0000000000000000
100161c84:     	mov	x11, x8
100161c88:     	ldp	q1, q2, [x9, #-32]
100161c8c:     	ldp	q3, q4, [x9], #64
100161c90:     	ldp	q5, q6, [x10, #-32]
100161c94:     	ldp	q7, q16, [x10], #64
100161c98:     	fsub.2d	v1, v1, v5
100161c9c:     	fsub.2d	v2, v2, v6
100161ca0:     	fsub.2d	v3, v3, v7
100161ca4:     	fsub.2d	v4, v4, v16
100161ca8:     	fmul.2d	v1, v1, v1
100161cac:     	fmul.2d	v2, v2, v2
100161cb0:     	fmul.2d	v3, v3, v3
100161cb4:     	fmul.2d	v4, v4, v4
100161cb8:     	fcvtn	v1.2s, v1.2d
100161cbc:     	mov	s5, v1[1]
100161cc0:     	fcvtn	v2.2s, v2.2d
100161cc4:     	mov	s6, v2[1]
100161cc8:     	fcvtn	v3.2s, v3.2d
100161ccc:     	mov	s7, v3[1]
100161cd0:     	fcvtn	v4.2s, v4.2d
100161cd4:     	mov	s16, v4[1]
100161cd8:     	fadd	s0, s0, s1
100161cdc:     	fadd	s0, s0, s5
100161ce0:     	fadd	s0, s0, s2
100161ce4:     	fadd	s0, s0, s6
100161ce8:     	fadd	s0, s0, s3
100161cec:     	fadd	s0, s0, s7
100161cf0:     	fadd	s0, s0, s4
100161cf4:     	fadd	s0, s0, s16
100161cf8:     	subs	x11, x11, #8
100161cfc:     	b.ne	0x100161c88 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0x38>
100161d00:     	cmp	x8, x2
100161d04:     	b.eq	0x100161d38 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0xe8>
100161d08:     	sub	x9, x2, x8
100161d0c:     	lsl	x10, x8, #3
100161d10:     	add	x8, x1, x10
100161d14:     	add	x10, x0, x10
100161d18:     	ldr	d1, [x10], #8
100161d1c:     	ldr	d2, [x8], #8
100161d20:     	fsub	d1, d1, d2
100161d24:     	fmul	d1, d1, d1
100161d28:     	fcvt	s1, d1
100161d2c:     	fadd	s0, s0, s1
100161d30:     	subs	x9, x9, #1
100161d34:     	b.ne	0x100161d18 <void zvec::turbo::scalar::raw_numeric_distance<double, false>(void const*, void const*, unsigned long, float*)+0xc8>
100161d38:     	str	s0, [x3]
100161d3c:     	ret

0000000100161f4c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)>:
100161f4c:     	cbz	x2, 0x100161f64 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0x18>
100161f50:     	cmp	x2, #8
100161f54:     	b.hs	0x100161f6c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0x20>
100161f58:     	mov	x8, #0
100161f5c:     	movi	d0, #0000000000000000
100161f60:     	b	0x100161ff0 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xa4>
100161f64:     	movi	d0, #0000000000000000
100161f68:     	b	0x10016201c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xd0>
100161f6c:     	and	x8, x2, #0xfffffffffffffff8
100161f70:     	add	x9, x0, #32
100161f74:     	add	x10, x1, #32
100161f78:     	movi	d0, #0000000000000000
100161f7c:     	mov	x11, x8
100161f80:     	ldp	q1, q2, [x9, #-32]
100161f84:     	ldp	q3, q4, [x9], #64
100161f88:     	ldp	q5, q6, [x10, #-32]
100161f8c:     	ldp	q7, q16, [x10], #64
100161f90:     	fmul.2d	v1, v1, v5
100161f94:     	fmul.2d	v2, v2, v6
100161f98:     	fmul.2d	v3, v3, v7
100161f9c:     	fmul.2d	v4, v4, v16
100161fa0:     	fcvtn	v1.2s, v1.2d
100161fa4:     	mov	s5, v1[1]
100161fa8:     	fcvtn	v2.2s, v2.2d
100161fac:     	mov	s6, v2[1]
100161fb0:     	fcvtn	v3.2s, v3.2d
100161fb4:     	mov	s7, v3[1]
100161fb8:     	fcvtn	v4.2s, v4.2d
100161fbc:     	mov	s16, v4[1]
100161fc0:     	fadd	s0, s0, s1
100161fc4:     	fadd	s0, s0, s5
100161fc8:     	fadd	s0, s0, s2
100161fcc:     	fadd	s0, s0, s6
100161fd0:     	fadd	s0, s0, s3
100161fd4:     	fadd	s0, s0, s7
100161fd8:     	fadd	s0, s0, s4
100161fdc:     	fadd	s0, s0, s16
100161fe0:     	subs	x11, x11, #8
100161fe4:     	b.ne	0x100161f80 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0x34>
100161fe8:     	cmp	x8, x2
100161fec:     	b.eq	0x10016201c <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xd0>
100161ff0:     	sub	x9, x2, x8
100161ff4:     	lsl	x10, x8, #3
100161ff8:     	add	x8, x1, x10
100161ffc:     	add	x10, x0, x10
100162000:     	ldr	d1, [x10], #8
100162004:     	ldr	d2, [x8], #8
100162008:     	fmul	d1, d1, d2
10016200c:     	fcvt	s1, d1
100162010:     	fadd	s0, s0, s1
100162014:     	subs	x9, x9, #1
100162018:     	b.ne	0x100162000 <void zvec::turbo::scalar::raw_numeric_distance<double, true>(void const*, void const*, unsigned long, float*)+0xb4>
10016201c:     	fneg	s0, s0
100162020:     	str	s0, [x3]
100162024:     	ret

0000000100162214 <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)>:
100162214:     	cbz	x2, 0x10016222c <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x18>
100162218:     	cmp	x2, #16
10016221c:     	b.hs	0x100162238 <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x24>
100162220:     	mov	x8, #0
100162224:     	movi	d0, #0000000000000000
100162228:     	b	0x1001623cc <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x1b8>
10016222c:     	movi	d0, #0000000000000000
100162230:     	str	s0, [x3]
100162234:     	ret
100162238:     	and	x8, x2, #0xfffffffffffffff0
10016223c:     	add	x9, x0, #16
100162240:     	add	x10, x1, #16
100162244:     	movi	d0, #0000000000000000
100162248:     	mov	x11, x8
10016224c:     	ldp	q1, q2, [x9, #-16]
100162250:     	sshll.4s	v3, v1, #0
100162254:     	sshll.2d	v4, v3, #0
100162258:     	scvtf.2d	v4, v4
10016225c:     	sshll2.2d	v3, v3, #0
100162260:     	scvtf.2d	v3, v3
100162264:     	sshll2.4s	v1, v1, #0
100162268:     	sshll.2d	v5, v1, #0
10016226c:     	scvtf.2d	v5, v5
100162270:     	sshll2.2d	v1, v1, #0
100162274:     	scvtf.2d	v1, v1
100162278:     	sshll.4s	v6, v2, #0
10016227c:     	sshll.2d	v7, v6, #0
100162280:     	scvtf.2d	v7, v7
100162284:     	sshll2.2d	v6, v6, #0
100162288:     	scvtf.2d	v6, v6
10016228c:     	sshll2.4s	v2, v2, #0
100162290:     	sshll.2d	v16, v2, #0
100162294:     	scvtf.2d	v16, v16
100162298:     	sshll2.2d	v2, v2, #0
10016229c:     	scvtf.2d	v2, v2
1001622a0:     	ldp	q17, q18, [x10, #-16]
1001622a4:     	sshll.4s	v19, v17, #0
1001622a8:     	sshll.2d	v20, v19, #0
1001622ac:     	scvtf.2d	v20, v20
1001622b0:     	sshll2.2d	v19, v19, #0
1001622b4:     	scvtf.2d	v19, v19
1001622b8:     	sshll2.4s	v17, v17, #0
1001622bc:     	sshll.2d	v21, v17, #0
1001622c0:     	scvtf.2d	v21, v21
1001622c4:     	sshll2.2d	v17, v17, #0
1001622c8:     	scvtf.2d	v17, v17
1001622cc:     	sshll.4s	v22, v18, #0
1001622d0:     	sshll.2d	v23, v22, #0
1001622d4:     	scvtf.2d	v23, v23
1001622d8:     	sshll2.2d	v22, v22, #0
1001622dc:     	scvtf.2d	v22, v22
1001622e0:     	sshll2.4s	v18, v18, #0
1001622e4:     	sshll.2d	v24, v18, #0
1001622e8:     	scvtf.2d	v24, v24
1001622ec:     	sshll2.2d	v18, v18, #0
1001622f0:     	scvtf.2d	v18, v18
1001622f4:     	fsub.2d	v1, v1, v17
1001622f8:     	fsub.2d	v5, v5, v21
1001622fc:     	fsub.2d	v3, v3, v19
100162300:     	fsub.2d	v4, v4, v20
100162304:     	fsub.2d	v2, v2, v18
100162308:     	fsub.2d	v16, v16, v24
10016230c:     	fsub.2d	v6, v6, v22
100162310:     	fsub.2d	v7, v7, v23
100162314:     	fmul.2d	v4, v4, v4
100162318:     	fmul.2d	v3, v3, v3
10016231c:     	fmul.2d	v5, v5, v5
100162320:     	fmul.2d	v1, v1, v1
100162324:     	fmul.2d	v7, v7, v7
100162328:     	fmul.2d	v6, v6, v6
10016232c:     	fmul.2d	v16, v16, v16
100162330:     	fmul.2d	v2, v2, v2
100162334:     	fcvtn	v1.2s, v1.2d
100162338:     	mov	s17, v1[1]
10016233c:     	fcvtn	v5.2s, v5.2d
100162340:     	mov	s18, v5[1]
100162344:     	fcvtn	v3.2s, v3.2d
100162348:     	mov	s19, v3[1]
10016234c:     	fcvtn	v4.2s, v4.2d
100162350:     	mov	s20, v4[1]
100162354:     	fcvtn	v2.2s, v2.2d
100162358:     	mov	s21, v2[1]
10016235c:     	fcvtn	v16.2s, v16.2d
100162360:     	mov	s22, v16[1]
100162364:     	fcvtn	v6.2s, v6.2d
100162368:     	mov	s23, v6[1]
10016236c:     	fcvtn	v7.2s, v7.2d
100162370:     	mov	s24, v7[1]
100162374:     	fadd	s0, s0, s4
100162378:     	fadd	s0, s0, s20
10016237c:     	fadd	s0, s0, s3
100162380:     	fadd	s0, s0, s19
100162384:     	fadd	s0, s0, s5
100162388:     	fadd	s0, s0, s18
10016238c:     	fadd	s0, s0, s1
100162390:     	fadd	s0, s0, s17
100162394:     	fadd	s0, s0, s7
100162398:     	fadd	s0, s0, s24
10016239c:     	fadd	s0, s0, s6
1001623a0:     	fadd	s0, s0, s23
1001623a4:     	fadd	s0, s0, s16
1001623a8:     	fadd	s0, s0, s22
1001623ac:     	fadd	s0, s0, s2
1001623b0:     	fadd	s0, s0, s21
1001623b4:     	add	x9, x9, #32
1001623b8:     	add	x10, x10, #32
1001623bc:     	subs	x11, x11, #16
1001623c0:     	b.ne	0x10016224c <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x38>
1001623c4:     	cmp	x8, x2
1001623c8:     	b.eq	0x100162404 <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x1f0>
1001623cc:     	sub	x9, x2, x8
1001623d0:     	lsl	x10, x8, #1
1001623d4:     	add	x8, x1, x10
1001623d8:     	add	x10, x0, x10
1001623dc:     	ldrsh	w11, [x10], #2
1001623e0:     	scvtf	d1, w11
1001623e4:     	ldrsh	w11, [x8], #2
1001623e8:     	scvtf	d2, w11
1001623ec:     	fsub	d1, d1, d2
1001623f0:     	fmul	d1, d1, d1
1001623f4:     	fcvt	s1, d1
1001623f8:     	fadd	s0, s0, s1
1001623fc:     	subs	x9, x9, #1
100162400:     	b.ne	0x1001623dc <void zvec::turbo::scalar::raw_numeric_distance<short, false>(void const*, void const*, unsigned long, float*)+0x1c8>
100162404:     	str	s0, [x3]
100162408:     	ret

0000000100162674 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)>:
100162674:     	cbz	x2, 0x10016268c <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x18>
100162678:     	cmp	x2, #32
10016267c:     	b.hs	0x100162694 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x20>
100162680:     	mov	x8, #0
100162684:     	movi	d0, #0000000000000000
100162688:     	b	0x1001627e8 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x174>
10016268c:     	movi	d0, #0000000000000000
100162690:     	b	0x100162814 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x1a0>
100162694:     	and	x8, x2, #0xffffffffffffffe0
100162698:     	add	x9, x0, #32
10016269c:     	add	x10, x1, #32
1001626a0:     	movi	d0, #0000000000000000
1001626a4:     	mov	x11, x8
1001626a8:     	ldp	q1, q2, [x9, #-32]
1001626ac:     	ldp	q3, q4, [x9], #64
1001626b0:     	ldp	q5, q6, [x10, #-32]
1001626b4:     	ldp	q7, q16, [x10], #64
1001626b8:     	smull.4s	v17, v5, v1
1001626bc:     	smull2.4s	v5, v5, v1
1001626c0:     	smull.4s	v18, v6, v2
1001626c4:     	smull2.4s	v2, v6, v2
1001626c8:     	smull.4s	v6, v7, v3
1001626cc:     	smull2.4s	v3, v7, v3
1001626d0:     	smull.4s	v7, v16, v4
1001626d4:     	smull2.4s	v1, v16, v4
1001626d8:     	scvtf.4s	v4, v17
1001626dc:     	mov	s16, v4[1]
1001626e0:     	fadd	s0, s0, s4
1001626e4:     	fadd	s0, s0, s16
1001626e8:     	mov	s16, v4[2]
1001626ec:     	fadd	s0, s0, s16
1001626f0:     	scvtf.4s	v5, v5
1001626f4:     	mov	s4, v4[3]
1001626f8:     	fadd	s0, s0, s4
1001626fc:     	mov	s4, v5[1]
100162700:     	fadd	s0, s0, s5
100162704:     	fadd	s0, s0, s4
100162708:     	mov	s4, v5[2]
10016270c:     	fadd	s0, s0, s4
100162710:     	mov	s4, v5[3]
100162714:     	scvtf.4s	v5, v18
100162718:     	fadd	s0, s0, s4
10016271c:     	mov	s4, v5[1]
100162720:     	fadd	s0, s0, s5
100162724:     	fadd	s0, s0, s4
100162728:     	mov	s4, v5[2]
10016272c:     	fadd	s0, s0, s4
100162730:     	scvtf.4s	v2, v2
100162734:     	mov	s4, v5[3]
100162738:     	fadd	s0, s0, s4
10016273c:     	mov	s4, v2[1]
100162740:     	fadd	s0, s0, s2
100162744:     	fadd	s0, s0, s4
100162748:     	mov	s4, v2[2]
10016274c:     	fadd	s0, s0, s4
100162750:     	mov	s2, v2[3]
100162754:     	scvtf.4s	v4, v6
100162758:     	fadd	s0, s0, s2
10016275c:     	mov	s2, v4[1]
100162760:     	fadd	s0, s0, s4
100162764:     	fadd	s0, s0, s2
100162768:     	mov	s2, v4[2]
10016276c:     	fadd	s0, s0, s2
100162770:     	scvtf.4s	v2, v3
100162774:     	mov	s3, v4[3]
100162778:     	fadd	s0, s0, s3
10016277c:     	mov	s3, v2[1]
100162780:     	fadd	s0, s0, s2
100162784:     	fadd	s0, s0, s3
100162788:     	mov	s3, v2[2]
10016278c:     	fadd	s0, s0, s3
100162790:     	mov	s2, v2[3]
100162794:     	scvtf.4s	v3, v7
100162798:     	fadd	s0, s0, s2
10016279c:     	mov	s2, v3[1]
1001627a0:     	fadd	s0, s0, s3
1001627a4:     	fadd	s0, s0, s2
1001627a8:     	mov	s2, v3[2]
1001627ac:     	fadd	s0, s0, s2
1001627b0:     	scvtf.4s	v1, v1
1001627b4:     	mov	s2, v3[3]
1001627b8:     	fadd	s0, s0, s2
1001627bc:     	mov	s2, v1[1]
1001627c0:     	fadd	s0, s0, s1
1001627c4:     	fadd	s0, s0, s2
1001627c8:     	mov	s2, v1[2]
1001627cc:     	fadd	s0, s0, s2
1001627d0:     	mov	s1, v1[3]
1001627d4:     	fadd	s0, s0, s1
1001627d8:     	subs	x11, x11, #32
1001627dc:     	b.ne	0x1001626a8 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x34>
1001627e0:     	cmp	x8, x2
1001627e4:     	b.eq	0x100162814 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x1a0>
1001627e8:     	sub	x9, x2, x8
1001627ec:     	lsl	x10, x8, #1
1001627f0:     	add	x8, x1, x10
1001627f4:     	add	x10, x0, x10
1001627f8:     	ldrsh	w11, [x10], #2
1001627fc:     	ldrsh	w12, [x8], #2
100162800:     	mul	w11, w12, w11
100162804:     	scvtf	s1, w11
100162808:     	fadd	s0, s0, s1
10016280c:     	subs	x9, x9, #1
100162810:     	b.ne	0x1001627f8 <void zvec::turbo::scalar::raw_numeric_distance<short, true>(void const*, void const*, unsigned long, float*)+0x184>
100162814:     	fneg	s0, s0
100162818:     	str	s0, [x3]
10016281c:     	ret
