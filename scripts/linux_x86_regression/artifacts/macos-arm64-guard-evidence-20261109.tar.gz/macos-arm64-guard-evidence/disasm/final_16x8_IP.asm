00000001000cd110 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cd110:     	stp	x28, x27, [sp, #-96]!
1000cd114:     	stp	x26, x25, [sp, #16]
1000cd118:     	stp	x24, x23, [sp, #32]
1000cd11c:     	stp	x22, x21, [sp, #48]
1000cd120:     	stp	x20, x19, [sp, #64]
1000cd124:     	stp	x29, x30, [sp, #80]
1000cd128:     	add	x29, sp, #80
1000cd12c:     	sub	sp, sp, #976
1000cd130:     	str	x3, [sp, #8]
1000cd134:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2a0>
1000cd138:     	ldr	x8, [x8, #392]
1000cd13c:     	ldr	x8, [x8]
1000cd140:     	stur	x8, [x29, #-96]
1000cd144:     	movi.2d	v0, #0000000000000000
1000cd148:     	stp	q0, q0, [sp, #928]
1000cd14c:     	lsl	x8, x2, #2
1000cd150:     	stp	q0, q0, [sp, #896]
1000cd154:     	stp	q0, q0, [sp, #864]
1000cd158:     	stp	q0, q0, [sp, #832]
1000cd15c:     	stp	q0, q0, [sp, #800]
1000cd160:     	stp	q0, q0, [sp, #768]
1000cd164:     	stp	q0, q0, [sp, #736]
1000cd168:     	stp	q0, q0, [sp, #704]
1000cd16c:     	stp	q0, q0, [sp, #672]
1000cd170:     	stp	q0, q0, [sp, #640]
1000cd174:     	stp	q0, q0, [sp, #608]
1000cd178:     	stp	q0, q0, [sp, #576]
1000cd17c:     	stp	q0, q0, [sp, #544]
1000cd180:     	stp	q0, q0, [sp, #512]
1000cd184:     	stp	q0, q0, [sp, #480]
1000cd188:     	stp	q0, q0, [sp, #448]
1000cd18c:     	ands	x8, x8, #0xfffffffffffffff8
1000cd190:     	b.eq	0x1000cd6e0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x5d0>
1000cd194:     	add	x8, x1, x8
1000cd198:     	str	x8, [sp, #16]
1000cd19c:     	add	x8, sp, #448
1000cd1a0:     	add	x19, x8, #256
1000cd1a4:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x308>
1000cd1a8:     	add	x11, x11, #1468
1000cd1ac:     	mov	x12, #0
1000cd1b0:     	ldp	w8, w9, [x1]
1000cd1b4:     	ubfx	x10, x8, #8, #4
1000cd1b8:     	str	x10, [sp, #440]
1000cd1bc:     	ubfx	x10, x8, #16, #4
1000cd1c0:     	str	x10, [sp, #432]
1000cd1c4:     	ubfx	x10, x8, #24, #4
1000cd1c8:     	str	x10, [sp, #424]
1000cd1cc:     	ldp	w10, w13, [x1, #8]
1000cd1d0:     	and	x15, x8, #0xf
1000cd1d4:     	ubfx	x14, x8, #4, #4
1000cd1d8:     	stp	x14, x15, [sp, #408]
1000cd1dc:     	ubfx	x15, x8, #12, #4
1000cd1e0:     	ubfx	x14, x8, #20, #4
1000cd1e4:     	stp	x14, x15, [sp, #392]
1000cd1e8:     	lsr	x8, x8, #28
1000cd1ec:     	str	x8, [sp, #384]
1000cd1f0:     	and	x8, x9, #0xf
1000cd1f4:     	str	x8, [sp, #376]
1000cd1f8:     	ubfx	x8, x9, #8, #4
1000cd1fc:     	str	x8, [sp, #368]
1000cd200:     	ubfx	x8, x9, #16, #4
1000cd204:     	str	x8, [sp, #360]
1000cd208:     	ubfx	x8, x9, #24, #4
1000cd20c:     	str	x8, [sp, #352]
1000cd210:     	ubfx	x8, x9, #4, #4
1000cd214:     	str	x8, [sp, #344]
1000cd218:     	ubfx	x8, x9, #12, #4
1000cd21c:     	str	x8, [sp, #336]
1000cd220:     	ubfx	x8, x9, #20, #4
1000cd224:     	str	x8, [sp, #328]
1000cd228:     	lsr	x8, x9, #28
1000cd22c:     	str	x8, [sp, #320]
1000cd230:     	and	x9, x10, #0xf
1000cd234:     	ubfx	x8, x10, #8, #4
1000cd238:     	stp	x8, x9, [sp, #304]
1000cd23c:     	ubfx	x9, x10, #16, #4
1000cd240:     	ubfx	x8, x10, #24, #4
1000cd244:     	stp	x8, x9, [sp, #288]
1000cd248:     	ubfx	x9, x10, #4, #4
1000cd24c:     	ubfx	x8, x10, #12, #4
1000cd250:     	stp	x8, x9, [sp, #272]
1000cd254:     	ubfx	x9, x10, #20, #4
1000cd258:     	lsr	x8, x10, #28
1000cd25c:     	stp	x8, x9, [sp, #256]
1000cd260:     	and	x9, x13, #0xf
1000cd264:     	ubfx	x8, x13, #8, #4
1000cd268:     	stp	x8, x9, [sp, #240]
1000cd26c:     	ubfx	x9, x13, #16, #4
1000cd270:     	ubfx	x8, x13, #24, #4
1000cd274:     	stp	x8, x9, [sp, #224]
1000cd278:     	ubfx	x9, x13, #4, #4
1000cd27c:     	ubfx	x8, x13, #12, #4
1000cd280:     	stp	x8, x9, [sp, #208]
1000cd284:     	ubfx	x9, x13, #20, #4
1000cd288:     	lsr	x8, x13, #28
1000cd28c:     	stp	x8, x9, [sp, #192]
1000cd290:     	ldp	w8, w9, [x1, #16]
1000cd294:     	and	x10, x8, #0xf
1000cd298:     	str	x10, [sp, #184]
1000cd29c:     	ubfx	x10, x8, #8, #4
1000cd2a0:     	str	x10, [sp, #176]
1000cd2a4:     	ubfx	x10, x8, #16, #4
1000cd2a8:     	str	x10, [sp, #168]
1000cd2ac:     	ubfx	x10, x8, #24, #4
1000cd2b0:     	str	x10, [sp, #160]
1000cd2b4:     	ubfx	x10, x8, #4, #4
1000cd2b8:     	str	x10, [sp, #152]
1000cd2bc:     	ubfx	x10, x8, #12, #4
1000cd2c0:     	str	x10, [sp, #144]
1000cd2c4:     	ubfx	x10, x8, #20, #4
1000cd2c8:     	lsr	x8, x8, #28
1000cd2cc:     	stp	x8, x10, [sp, #128]
1000cd2d0:     	and	x10, x9, #0xf
1000cd2d4:     	ubfx	x8, x9, #8, #4
1000cd2d8:     	stp	x8, x10, [sp, #112]
1000cd2dc:     	ubfx	x10, x9, #16, #4
1000cd2e0:     	ubfx	x8, x9, #24, #4
1000cd2e4:     	stp	x8, x10, [sp, #96]
1000cd2e8:     	ubfx	x10, x9, #4, #4
1000cd2ec:     	ubfx	x8, x9, #12, #4
1000cd2f0:     	stp	x8, x10, [sp, #80]
1000cd2f4:     	ubfx	x10, x9, #20, #4
1000cd2f8:     	lsr	x8, x9, #28
1000cd2fc:     	stp	x8, x10, [sp, #64]
1000cd300:     	ldp	w14, w7, [x1, #24]
1000cd304:     	and	x9, x14, #0xf
1000cd308:     	ubfx	x8, x14, #8, #4
1000cd30c:     	stp	x8, x9, [sp, #48]
1000cd310:     	ubfx	x8, x14, #16, #4
1000cd314:     	str	x8, [sp, #40]
1000cd318:     	ubfx	x8, x14, #24, #4
1000cd31c:     	stp	x1, x8, [sp, #24]
1000cd320:     	ubfx	x10, x14, #4, #4
1000cd324:     	ubfx	x13, x14, #12, #4
1000cd328:     	ubfx	x9, x14, #20, #4
1000cd32c:     	lsr	x14, x14, #28
1000cd330:     	and	x15, x7, #0xf
1000cd334:     	ubfx	x16, x7, #8, #4
1000cd338:     	ubfx	x17, x7, #16, #4
1000cd33c:     	ubfx	x2, x7, #24, #4
1000cd340:     	ubfx	x4, x7, #4, #4
1000cd344:     	ubfx	x5, x7, #12, #4
1000cd348:     	ubfx	x6, x7, #20, #4
1000cd34c:     	lsr	x7, x7, #28
1000cd350:     	ldr	w26, [x0, x12]
1000cd354:     	mov	x1, x19
1000cd358:     	lsl	w19, w26, #4
1000cd35c:     	and	x19, x19, #0xf0
1000cd360:     	add	x19, x11, x19
1000cd364:     	ldr	x8, [sp, #416]
1000cd368:     	ldrsb	w25, [x19, x8]
1000cd36c:     	lsr	x20, x26, #4
1000cd370:     	and	x20, x20, #0xf0
1000cd374:     	add	x20, x11, x20
1000cd378:     	ldr	x8, [sp, #440]
1000cd37c:     	ldrsb	w27, [x20, x8]
1000cd380:     	lsr	x21, x26, #12
1000cd384:     	and	x21, x21, #0xf0
1000cd388:     	add	x21, x11, x21
1000cd38c:     	ldr	x8, [sp, #432]
1000cd390:     	ldrsb	w28, [x21, x8]
1000cd394:     	lsr	x22, x26, #20
1000cd398:     	and	x22, x22, #0xf0
1000cd39c:     	add	x23, x11, x22
1000cd3a0:     	ldr	x8, [sp, #424]
1000cd3a4:     	ldrsb	w30, [x23, x8]
1000cd3a8:     	and	x22, x26, #0xf0
1000cd3ac:     	add	x22, x11, x22
1000cd3b0:     	ldr	x8, [sp, #408]
1000cd3b4:     	ldrsb	w3, [x22, x8]
1000cd3b8:     	lsr	x24, x26, #8
1000cd3bc:     	and	x24, x24, #0xf0
1000cd3c0:     	add	x24, x11, x24
1000cd3c4:     	ldr	x8, [sp, #400]
1000cd3c8:     	ldrsb	w8, [x24, x8]
1000cd3cc:     	add	w27, w25, w27
1000cd3d0:     	lsr	x25, x26, #16
1000cd3d4:     	and	x25, x25, #0xf0
1000cd3d8:     	add	x25, x11, x25
1000cd3dc:     	add	w27, w27, w28
1000cd3e0:     	ldr	x28, [sp, #392]
1000cd3e4:     	ldrsb	w28, [x25, x28]
1000cd3e8:     	lsr	x26, x26, #24
1000cd3ec:     	and	x26, x26, #0xf0
1000cd3f0:     	add	x26, x11, x26
1000cd3f4:     	add	w27, w27, w30
1000cd3f8:     	ldr	x30, [sp, #384]
1000cd3fc:     	ldrsb	w30, [x26, x30]
1000cd400:     	add	w3, w27, w3
1000cd404:     	add	w8, w3, w8
1000cd408:     	add	w8, w8, w28
1000cd40c:     	add	w8, w8, w30
1000cd410:     	scvtf	s0, w8
1000cd414:     	ldp	x3, x8, [sp, #368]
1000cd418:     	ldrsb	w8, [x19, x8]
1000cd41c:     	ldrsb	w3, [x20, x3]
1000cd420:     	ldp	x28, x27, [sp, #352]
1000cd424:     	ldrsb	w27, [x21, x27]
1000cd428:     	ldrsb	w28, [x23, x28]
1000cd42c:     	ldr	x30, [sp, #344]
1000cd430:     	ldrsb	w30, [x22, x30]
1000cd434:     	add	w8, w8, w3
1000cd438:     	ldr	x3, [sp, #336]
1000cd43c:     	ldrsb	w3, [x24, x3]
1000cd440:     	add	w8, w8, w27
1000cd444:     	ldr	x27, [sp, #328]
1000cd448:     	ldrsb	w27, [x25, x27]
1000cd44c:     	add	w8, w8, w28
1000cd450:     	ldr	x28, [sp, #320]
1000cd454:     	ldrsb	w28, [x26, x28]
1000cd458:     	add	w8, w8, w30
1000cd45c:     	add	w8, w8, w3
1000cd460:     	add	w8, w8, w27
1000cd464:     	add	w8, w8, w28
1000cd468:     	scvtf	s1, w8
1000cd46c:     	ldp	x3, x8, [sp, #304]
1000cd470:     	ldrsb	w8, [x19, x8]
1000cd474:     	ldrsb	w3, [x20, x3]
1000cd478:     	ldp	x28, x27, [sp, #288]
1000cd47c:     	ldrsb	w27, [x21, x27]
1000cd480:     	ldrsb	w28, [x23, x28]
1000cd484:     	add	w8, w8, w3
1000cd488:     	ldr	x3, [sp, #280]
1000cd48c:     	ldrsb	w3, [x22, x3]
1000cd490:     	add	w8, w8, w27
1000cd494:     	ldr	x27, [sp, #272]
1000cd498:     	ldrsb	w27, [x24, x27]
1000cd49c:     	add	w8, w8, w28
1000cd4a0:     	ldr	x28, [sp, #264]
1000cd4a4:     	ldrsb	w28, [x25, x28]
1000cd4a8:     	add	w8, w8, w3
1000cd4ac:     	ldr	x3, [sp, #256]
1000cd4b0:     	ldrsb	w3, [x26, x3]
1000cd4b4:     	add	w8, w8, w27
1000cd4b8:     	add	w8, w8, w28
1000cd4bc:     	add	w8, w8, w3
1000cd4c0:     	scvtf	s2, w8
1000cd4c4:     	ldp	x3, x8, [sp, #240]
1000cd4c8:     	ldrsb	w8, [x19, x8]
1000cd4cc:     	ldrsb	w3, [x20, x3]
1000cd4d0:     	ldp	x28, x27, [sp, #224]
1000cd4d4:     	ldrsb	w27, [x21, x27]
1000cd4d8:     	ldrsb	w28, [x23, x28]
1000cd4dc:     	add	w8, w8, w3
1000cd4e0:     	ldr	x3, [sp, #216]
1000cd4e4:     	ldrsb	w3, [x22, x3]
1000cd4e8:     	add	w8, w8, w27
1000cd4ec:     	ldr	x27, [sp, #208]
1000cd4f0:     	ldrsb	w27, [x24, x27]
1000cd4f4:     	add	w8, w8, w28
1000cd4f8:     	ldr	x28, [sp, #200]
1000cd4fc:     	ldrsb	w28, [x25, x28]
1000cd500:     	add	w8, w8, w3
1000cd504:     	ldr	x3, [sp, #192]
1000cd508:     	ldrsb	w3, [x26, x3]
1000cd50c:     	add	w8, w8, w27
1000cd510:     	add	w8, w8, w28
1000cd514:     	add	w8, w8, w3
1000cd518:     	scvtf	s3, w8
1000cd51c:     	ldp	x3, x8, [sp, #176]
1000cd520:     	ldrsb	w8, [x19, x8]
1000cd524:     	ldrsb	w3, [x20, x3]
1000cd528:     	ldp	x28, x27, [sp, #160]
1000cd52c:     	ldrsb	w27, [x21, x27]
1000cd530:     	ldrsb	w28, [x23, x28]
1000cd534:     	add	w8, w8, w3
1000cd538:     	add	w8, w8, w27
1000cd53c:     	ldr	x3, [sp, #152]
1000cd540:     	ldrsb	w3, [x22, x3]
1000cd544:     	add	w8, w8, w28
1000cd548:     	add	w8, w8, w3
1000cd54c:     	ldp	x27, x3, [sp, #136]
1000cd550:     	ldrsb	w3, [x24, x3]
1000cd554:     	ldrsb	w27, [x25, x27]
1000cd558:     	add	w8, w8, w3
1000cd55c:     	add	w8, w8, w27
1000cd560:     	ldr	x3, [sp, #128]
1000cd564:     	ldrsb	w3, [x26, x3]
1000cd568:     	add	w8, w8, w3
1000cd56c:     	scvtf	s4, w8
1000cd570:     	ldp	x3, x8, [sp, #112]
1000cd574:     	ldrsb	w8, [x19, x8]
1000cd578:     	ldrsb	w3, [x20, x3]
1000cd57c:     	ldp	x28, x27, [sp, #96]
1000cd580:     	ldrsb	w27, [x21, x27]
1000cd584:     	ldrsb	w28, [x23, x28]
1000cd588:     	add	w8, w8, w3
1000cd58c:     	ldr	x3, [sp, #88]
1000cd590:     	ldrsb	w3, [x22, x3]
1000cd594:     	add	w8, w8, w27
1000cd598:     	ldr	x27, [sp, #80]
1000cd59c:     	ldrsb	w27, [x24, x27]
1000cd5a0:     	add	w8, w8, w28
1000cd5a4:     	ldr	x28, [sp, #72]
1000cd5a8:     	ldrsb	w28, [x25, x28]
1000cd5ac:     	add	w8, w8, w3
1000cd5b0:     	add	w8, w8, w27
1000cd5b4:     	add	w8, w8, w28
1000cd5b8:     	ldr	x3, [sp, #64]
1000cd5bc:     	ldrsb	w3, [x26, x3]
1000cd5c0:     	add	w8, w8, w3
1000cd5c4:     	scvtf	s5, w8
1000cd5c8:     	ldp	x3, x8, [sp, #48]
1000cd5cc:     	ldrsb	w8, [x19, x8]
1000cd5d0:     	ldrsb	w3, [x20, x3]
1000cd5d4:     	ldr	x27, [sp, #40]
1000cd5d8:     	ldrsb	w27, [x21, x27]
1000cd5dc:     	add	w8, w8, w3
1000cd5e0:     	ldr	x3, [sp, #32]
1000cd5e4:     	ldrsb	w3, [x23, x3]
1000cd5e8:     	add	w8, w8, w27
1000cd5ec:     	ldrsb	w27, [x22, x10]
1000cd5f0:     	add	w8, w8, w3
1000cd5f4:     	ldrsb	w3, [x24, x13]
1000cd5f8:     	add	w8, w8, w27
1000cd5fc:     	ldrsb	w27, [x25, x9]
1000cd600:     	add	w8, w8, w3
1000cd604:     	ldrsb	w3, [x26, x14]
1000cd608:     	add	w8, w8, w27
1000cd60c:     	add	w8, w8, w3
1000cd610:     	scvtf	s6, w8
1000cd614:     	ldrsb	w8, [x19, x15]
1000cd618:     	ldrsb	w3, [x20, x16]
1000cd61c:     	ldrsb	w19, [x21, x17]
1000cd620:     	add	w8, w8, w3
1000cd624:     	add	w8, w8, w19
1000cd628:     	ldrsb	w3, [x23, x2]
1000cd62c:     	ldrsb	w19, [x22, x4]
1000cd630:     	add	w8, w8, w3
1000cd634:     	add	w8, w8, w19
1000cd638:     	ldrsb	w3, [x24, x5]
1000cd63c:     	ldrsb	w19, [x25, x6]
1000cd640:     	add	w8, w8, w3
1000cd644:     	add	w8, w8, w19
1000cd648:     	mov	x19, x1
1000cd64c:     	ldrsb	w3, [x26, x7]
1000cd650:     	add	w8, w8, w3
1000cd654:     	add	x3, sp, #448
1000cd658:     	scvtf	s7, w8
1000cd65c:     	add	x8, x1, x12
1000cd660:     	ldur	s16, [x8, #-192]
1000cd664:     	fadd	s1, s16, s1
1000cd668:     	stur	s1, [x8, #-192]
1000cd66c:     	ldur	s1, [x8, #-128]
1000cd670:     	fadd	s1, s1, s2
1000cd674:     	stur	s1, [x8, #-128]
1000cd678:     	ldur	s1, [x8, #-64]
1000cd67c:     	fadd	s1, s1, s3
1000cd680:     	stur	s1, [x8, #-64]
1000cd684:     	ldr	s1, [x8]
1000cd688:     	fadd	s1, s1, s4
1000cd68c:     	str	s1, [x8]
1000cd690:     	ldr	s1, [x8, #64]
1000cd694:     	fadd	s1, s1, s5
1000cd698:     	str	s1, [x8, #64]
1000cd69c:     	ldr	s1, [x8, #128]
1000cd6a0:     	fadd	s1, s1, s6
1000cd6a4:     	str	s1, [x8, #128]
1000cd6a8:     	ldr	s1, [x8, #192]
1000cd6ac:     	fadd	s1, s1, s7
1000cd6b0:     	ldr	s2, [x3, x12]
1000cd6b4:     	str	s1, [x8, #192]
1000cd6b8:     	fadd	s0, s2, s0
1000cd6bc:     	str	s0, [x3, x12]
1000cd6c0:     	add	x12, x12, #4
1000cd6c4:     	cmp	x12, #64
1000cd6c8:     	b.ne	0x1000cd350 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x240>
1000cd6cc:     	add	x0, x0, #64
1000cd6d0:     	ldp	x8, x1, [sp, #16]
1000cd6d4:     	add	x1, x1, #32
1000cd6d8:     	cmp	x1, x8
1000cd6dc:     	b.ne	0x1000cd1ac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000cd6e0:     	add	x1, sp, #448
1000cd6e4:     	ldr	x0, [sp, #8]
1000cd6e8:     	mov	w2, #512
1000cd6ec:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000cd6f0:     	ldur	x8, [x29, #-96]
1000cd6f4:     	adrp	x9, 0x10016c000 <void run<unsigned char, 16ul, 16ul, false>(char const*)+0x244>
1000cd6f8:     	ldr	x9, [x9, #392]
1000cd6fc:     	ldr	x9, [x9]
1000cd700:     	cmp	x9, x8
1000cd704:     	b.ne	0x1000cd728 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<8ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x618>
1000cd708:     	add	sp, sp, #976
1000cd70c:     	ldp	x29, x30, [sp, #80]
1000cd710:     	ldp	x20, x19, [sp, #64]
1000cd714:     	ldp	x22, x21, [sp, #48]
1000cd718:     	ldp	x24, x23, [sp, #32]
1000cd71c:     	ldp	x26, x25, [sp, #16]
1000cd720:     	ldp	x28, x27, [sp], #96
1000cd724:     	ret
1000cd728:     	bl	0x100163694 <_strcmp+0x100163694>

