00000001000c1bec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c1bec:     	sub	sp, sp, #208
1000c1bf0:     	stp	x28, x27, [sp, #112]
1000c1bf4:     	stp	x26, x25, [sp, #128]
1000c1bf8:     	stp	x24, x23, [sp, #144]
1000c1bfc:     	stp	x22, x21, [sp, #160]
1000c1c00:     	stp	x20, x19, [sp, #176]
1000c1c04:     	stp	x29, x30, [sp, #192]
1000c1c08:     	add	x29, sp, #192
1000c1c0c:     	str	x3, [sp]
1000c1c10:     	adrp	x8, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xb8>
1000c1c14:     	ldr	x8, [x8, #392]
1000c1c18:     	ldr	x8, [x8]
1000c1c1c:     	stur	x8, [x29, #-88]
1000c1c20:     	movi.2d	v0, #0000000000000000
1000c1c24:     	stp	q0, q0, [sp, #64]
1000c1c28:     	stp	q0, q0, [sp, #32]
1000c1c2c:     	ands	x8, x2, #0xfffffffffffffffe
1000c1c30:     	b.eq	0x1000c1db4 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1c8>
1000c1c34:     	add	x8, x1, x8
1000c1c38:     	str	x8, [sp, #8]
1000c1c3c:     	adrp	x9, 0x10016a000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0xdc>
1000c1c40:     	add	x9, x9, #956
1000c1c44:     	mov	x11, #0
1000c1c48:     	ldp	w4, w23, [x1]
1000c1c4c:     	ubfx	x8, x4, #8, #4
1000c1c50:     	stp	x1, x8, [sp, #16]
1000c1c54:     	ubfx	x13, x4, #16, #4
1000c1c58:     	and	x14, x4, #0xf
1000c1c5c:     	ubfx	x15, x4, #24, #4
1000c1c60:     	ubfx	x16, x4, #4, #4
1000c1c64:     	ubfx	x17, x4, #12, #4
1000c1c68:     	ubfx	x2, x4, #20, #4
1000c1c6c:     	lsr	x4, x4, #28
1000c1c70:     	and	x5, x23, #0xf
1000c1c74:     	ubfx	x6, x23, #8, #4
1000c1c78:     	ubfx	x7, x23, #16, #4
1000c1c7c:     	ubfx	x19, x23, #24, #4
1000c1c80:     	ubfx	x20, x23, #4, #4
1000c1c84:     	ubfx	x21, x23, #12, #4
1000c1c88:     	ubfx	x22, x23, #20, #4
1000c1c8c:     	lsr	x23, x23, #28
1000c1c90:     	ldr	w24, [x0, x11]
1000c1c94:     	lsl	w25, w24, #4
1000c1c98:     	and	x25, x25, #0xf0
1000c1c9c:     	add	x25, x9, x25
1000c1ca0:     	and	x26, x24, #0xf0
1000c1ca4:     	add	x26, x9, x26
1000c1ca8:     	lsr	x27, x24, #4
1000c1cac:     	and	x27, x27, #0xf0
1000c1cb0:     	add	x27, x9, x27
1000c1cb4:     	lsr	x28, x24, #8
1000c1cb8:     	and	x28, x28, #0xf0
1000c1cbc:     	add	x28, x9, x28
1000c1cc0:     	lsr	x30, x24, #12
1000c1cc4:     	and	x30, x30, #0xf0
1000c1cc8:     	add	x30, x9, x30
1000c1ccc:     	lsr	x8, x24, #16
1000c1cd0:     	and	x8, x8, #0xf0
1000c1cd4:     	add	x8, x9, x8
1000c1cd8:     	lsr	x3, x24, #20
1000c1cdc:     	and	x3, x3, #0xf0
1000c1ce0:     	add	x3, x9, x3
1000c1ce4:     	lsr	x24, x24, #24
1000c1ce8:     	and	x24, x24, #0xf0
1000c1cec:     	ldrsb	w10, [x25, x14]
1000c1cf0:     	ldr	x12, [sp, #24]
1000c1cf4:     	ldrsb	w1, [x27, x12]
1000c1cf8:     	ldrsb	w12, [x30, x13]
1000c1cfc:     	add	w10, w10, w1
1000c1d00:     	add	w10, w10, w12
1000c1d04:     	ldrsb	w12, [x3, x15]
1000c1d08:     	ldrsb	w1, [x26, x16]
1000c1d0c:     	add	w10, w10, w12
1000c1d10:     	add	w10, w10, w1
1000c1d14:     	ldrsb	w12, [x28, x17]
1000c1d18:     	ldrsb	w1, [x8, x2]
1000c1d1c:     	add	x24, x9, x24
1000c1d20:     	add	w10, w10, w12
1000c1d24:     	add	w10, w10, w1
1000c1d28:     	ldrsb	w12, [x24, x4]
1000c1d2c:     	add	w10, w10, w12
1000c1d30:     	scvtf	s0, w10
1000c1d34:     	add	x10, sp, #32
1000c1d38:     	add	x10, x10, x11
1000c1d3c:     	ldr	s1, [x10]
1000c1d40:     	ldrsb	w12, [x25, x5]
1000c1d44:     	fadd	s0, s1, s0
1000c1d48:     	ldrsb	w1, [x27, x6]
1000c1d4c:     	ldrsb	w25, [x30, x7]
1000c1d50:     	add	w12, w12, w1
1000c1d54:     	add	w12, w12, w25
1000c1d58:     	ldrsb	w1, [x3, x19]
1000c1d5c:     	ldrsb	w3, [x26, x20]
1000c1d60:     	add	w12, w12, w1
1000c1d64:     	add	w12, w12, w3
1000c1d68:     	ldrsb	w1, [x28, x21]
1000c1d6c:     	ldrsb	w8, [x8, x22]
1000c1d70:     	add	w12, w12, w1
1000c1d74:     	add	w8, w12, w8
1000c1d78:     	ldrsb	w12, [x24, x23]
1000c1d7c:     	add	w8, w8, w12
1000c1d80:     	scvtf	s1, w8
1000c1d84:     	str	s0, [x10]
1000c1d88:     	ldr	s0, [x10, #32]
1000c1d8c:     	fadd	s0, s0, s1
1000c1d90:     	str	s0, [x10, #32]
1000c1d94:     	add	x11, x11, #4
1000c1d98:     	cmp	x11, #32
1000c1d9c:     	b.ne	0x1000c1c90 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xa4>
1000c1da0:     	add	x0, x0, #32
1000c1da4:     	ldp	x8, x1, [sp, #8]
1000c1da8:     	add	x1, x1, #8
1000c1dac:     	cmp	x1, x8
1000c1db0:     	b.ne	0x1000c1c44 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x58>
1000c1db4:     	ldp	q0, q1, [sp, #32]
1000c1db8:     	ldr	x8, [sp]
1000c1dbc:     	stp	q0, q1, [x8]
1000c1dc0:     	ldp	q0, q1, [sp, #64]
1000c1dc4:     	stp	q0, q1, [x8, #32]
1000c1dc8:     	ldur	x8, [x29, #-88]
1000c1dcc:     	adrp	x9, 0x10016c000 <void run<unsigned char, 8ul, 4ul, false>(char const*)+0x274>
1000c1dd0:     	ldr	x9, [x9, #392]
1000c1dd4:     	ldr	x9, [x9]
1000c1dd8:     	cmp	x9, x8
1000c1ddc:     	b.ne	0x1000c1e00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 8ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x214>
1000c1de0:     	ldp	x29, x30, [sp, #192]
1000c1de4:     	ldp	x20, x19, [sp, #176]
1000c1de8:     	ldp	x22, x21, [sp, #160]
1000c1dec:     	ldp	x24, x23, [sp, #144]
1000c1df0:     	ldp	x26, x25, [sp, #128]
1000c1df4:     	ldp	x28, x27, [sp, #112]
1000c1df8:     	add	sp, sp, #208
1000c1dfc:     	ret
1000c1e00:     	bl	0x100163694 <_strcmp+0x100163694>

