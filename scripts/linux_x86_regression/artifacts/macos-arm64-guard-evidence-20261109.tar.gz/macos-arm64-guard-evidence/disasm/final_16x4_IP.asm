00000001000cac34 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000cac34:     	stp	x28, x27, [sp, #-96]!
1000cac38:     	stp	x26, x25, [sp, #16]
1000cac3c:     	stp	x24, x23, [sp, #32]
1000cac40:     	stp	x22, x21, [sp, #48]
1000cac44:     	stp	x20, x19, [sp, #64]
1000cac48:     	stp	x29, x30, [sp, #80]
1000cac4c:     	add	x29, sp, #80
1000cac50:     	sub	sp, sp, #448
1000cac54:     	str	x3, [sp]
1000cac58:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2ac>
1000cac5c:     	ldr	x8, [x8, #392]
1000cac60:     	ldr	x8, [x8]
1000cac64:     	stur	x8, [x29, #-96]
1000cac68:     	movi.2d	v0, #0000000000000000
1000cac6c:     	stp	q0, q0, [sp, #400]
1000cac70:     	lsl	x8, x2, #1
1000cac74:     	stp	q0, q0, [sp, #368]
1000cac78:     	stp	q0, q0, [sp, #336]
1000cac7c:     	stp	q0, q0, [sp, #304]
1000cac80:     	stp	q0, q0, [sp, #272]
1000cac84:     	stp	q0, q0, [sp, #240]
1000cac88:     	stp	q0, q0, [sp, #208]
1000cac8c:     	stp	q0, q0, [sp, #176]
1000cac90:     	ands	x8, x8, #0xfffffffffffffffc
1000cac94:     	b.eq	0x1000caf70 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x33c>
1000cac98:     	add	x8, x1, x8
1000cac9c:     	str	x8, [sp, #8]
1000caca0:     	add	x8, sp, #176
1000caca4:     	add	x27, x8, #128
1000caca8:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f4>
1000cacac:     	add	x11, x11, #1468
1000cacb0:     	mov	x12, #0
1000cacb4:     	ldp	w8, w9, [x1]
1000cacb8:     	ubfx	x10, x8, #8, #4
1000cacbc:     	str	x10, [sp, #168]
1000cacc0:     	ubfx	x10, x8, #16, #4
1000cacc4:     	str	x10, [sp, #160]
1000cacc8:     	ubfx	x10, x8, #24, #4
1000caccc:     	str	x10, [sp, #152]
1000cacd0:     	ldp	w10, w17, [x1, #8]
1000cacd4:     	str	x1, [sp, #16]
1000cacd8:     	and	x14, x8, #0xf
1000cacdc:     	ubfx	x13, x8, #4, #4
1000cace0:     	stp	x13, x14, [sp, #136]
1000cace4:     	ubfx	x14, x8, #12, #4
1000cace8:     	ubfx	x13, x8, #20, #4
1000cacec:     	stp	x13, x14, [sp, #120]
1000cacf0:     	lsr	x8, x8, #28
1000cacf4:     	str	x8, [sp, #112]
1000cacf8:     	and	x8, x9, #0xf
1000cacfc:     	str	x8, [sp, #104]
1000cad00:     	ubfx	x8, x9, #8, #4
1000cad04:     	str	x8, [sp, #96]
1000cad08:     	ubfx	x8, x9, #16, #4
1000cad0c:     	str	x8, [sp, #88]
1000cad10:     	ubfx	x8, x9, #24, #4
1000cad14:     	str	x8, [sp, #80]
1000cad18:     	ubfx	x8, x9, #4, #4
1000cad1c:     	str	x8, [sp, #72]
1000cad20:     	ubfx	x8, x9, #12, #4
1000cad24:     	str	x8, [sp, #64]
1000cad28:     	ubfx	x8, x9, #20, #4
1000cad2c:     	str	x8, [sp, #56]
1000cad30:     	lsr	x8, x9, #28
1000cad34:     	str	x8, [sp, #48]
1000cad38:     	and	x9, x10, #0xf
1000cad3c:     	ubfx	x8, x10, #8, #4
1000cad40:     	stp	x8, x9, [sp, #32]
1000cad44:     	ubfx	x8, x10, #16, #4
1000cad48:     	str	x8, [sp, #24]
1000cad4c:     	ubfx	x28, x10, #24, #4
1000cad50:     	ubfx	x30, x10, #4, #4
1000cad54:     	ubfx	x8, x10, #12, #4
1000cad58:     	ubfx	x3, x10, #20, #4
1000cad5c:     	lsr	x9, x10, #28
1000cad60:     	and	x1, x17, #0xf
1000cad64:     	ubfx	x10, x17, #8, #4
1000cad68:     	ubfx	x13, x17, #16, #4
1000cad6c:     	ubfx	x26, x17, #24, #4
1000cad70:     	ubfx	x14, x17, #4, #4
1000cad74:     	ubfx	x15, x17, #12, #4
1000cad78:     	ubfx	x16, x17, #20, #4
1000cad7c:     	lsr	x17, x17, #28
1000cad80:     	ldr	w20, [x0, x12]
1000cad84:     	lsl	w2, w20, #4
1000cad88:     	and	x2, x2, #0xf0
1000cad8c:     	add	x5, x11, x2
1000cad90:     	and	x2, x20, #0xf0
1000cad94:     	add	x2, x11, x2
1000cad98:     	lsr	x4, x20, #4
1000cad9c:     	and	x4, x4, #0xf0
1000cada0:     	add	x7, x11, x4
1000cada4:     	lsr	x4, x20, #8
1000cada8:     	and	x4, x4, #0xf0
1000cadac:     	add	x4, x11, x4
1000cadb0:     	lsr	x6, x20, #12
1000cadb4:     	and	x6, x6, #0xf0
1000cadb8:     	add	x19, x11, x6
1000cadbc:     	lsr	x6, x20, #16
1000cadc0:     	and	x6, x6, #0xf0
1000cadc4:     	add	x6, x11, x6
1000cadc8:     	lsr	x21, x20, #20
1000cadcc:     	and	x21, x21, #0xf0
1000cadd0:     	add	x21, x11, x21
1000cadd4:     	lsr	x20, x20, #24
1000cadd8:     	and	x20, x20, #0xf0
1000caddc:     	ldr	x22, [sp, #144]
1000cade0:     	ldrsb	w22, [x5, x22]
1000cade4:     	add	x20, x11, x20
1000cade8:     	ldp	x24, x23, [sp, #160]
1000cadec:     	ldrsb	w23, [x7, x23]
1000cadf0:     	ldrsb	w24, [x19, x24]
1000cadf4:     	add	w22, w22, w23
1000cadf8:     	add	w22, w22, w24
1000cadfc:     	ldr	x23, [sp, #152]
1000cae00:     	ldrsb	w23, [x21, x23]
1000cae04:     	ldr	x24, [sp, #136]
1000cae08:     	ldrsb	w24, [x2, x24]
1000cae0c:     	add	w22, w22, w23
1000cae10:     	add	w22, w22, w24
1000cae14:     	ldp	x24, x23, [sp, #120]
1000cae18:     	ldrsb	w23, [x4, x23]
1000cae1c:     	ldrsb	w24, [x6, x24]
1000cae20:     	add	w22, w22, w23
1000cae24:     	add	w22, w22, w24
1000cae28:     	ldr	x23, [sp, #112]
1000cae2c:     	ldrsb	w23, [x20, x23]
1000cae30:     	add	w22, w22, w23
1000cae34:     	scvtf	s0, w22
1000cae38:     	ldp	x23, x22, [sp, #96]
1000cae3c:     	ldrsb	w22, [x5, x22]
1000cae40:     	ldrsb	w23, [x7, x23]
1000cae44:     	ldp	x25, x24, [sp, #80]
1000cae48:     	ldrsb	w24, [x19, x24]
1000cae4c:     	ldrsb	w25, [x21, x25]
1000cae50:     	add	w22, w22, w23
1000cae54:     	ldr	x23, [sp, #72]
1000cae58:     	ldrsb	w23, [x2, x23]
1000cae5c:     	add	w22, w22, w24
1000cae60:     	ldr	x24, [sp, #64]
1000cae64:     	ldrsb	w24, [x4, x24]
1000cae68:     	add	w22, w22, w25
1000cae6c:     	ldr	x25, [sp, #56]
1000cae70:     	ldrsb	w25, [x6, x25]
1000cae74:     	add	w22, w22, w23
1000cae78:     	add	w22, w22, w24
1000cae7c:     	add	w22, w22, w25
1000cae80:     	ldr	x23, [sp, #48]
1000cae84:     	ldrsb	w23, [x20, x23]
1000cae88:     	add	w22, w22, w23
1000cae8c:     	scvtf	s1, w22
1000cae90:     	ldp	x23, x22, [sp, #32]
1000cae94:     	ldrsb	w22, [x5, x22]
1000cae98:     	ldrsb	w23, [x7, x23]
1000cae9c:     	ldr	x24, [sp, #24]
1000caea0:     	ldrsb	w24, [x19, x24]
1000caea4:     	add	w22, w22, w23
1000caea8:     	ldrsb	w23, [x21, x28]
1000caeac:     	add	w22, w22, w24
1000caeb0:     	ldrsb	w24, [x2, x30]
1000caeb4:     	add	w22, w22, w23
1000caeb8:     	ldrsb	w23, [x4, x8]
1000caebc:     	add	w22, w22, w24
1000caec0:     	ldrsb	w24, [x6, x3]
1000caec4:     	add	w22, w22, w23
1000caec8:     	ldrsb	w23, [x20, x9]
1000caecc:     	add	w22, w22, w24
1000caed0:     	add	w22, w22, w23
1000caed4:     	scvtf	s2, w22
1000caed8:     	ldrsb	w5, [x5, x1]
1000caedc:     	ldrsb	w7, [x7, x10]
1000caee0:     	ldrsb	w19, [x19, x13]
1000caee4:     	add	w5, w5, w7
1000caee8:     	add	w5, w5, w19
1000caeec:     	ldrsb	w7, [x21, x26]
1000caef0:     	ldrsb	w2, [x2, x14]
1000caef4:     	add	w5, w5, w7
1000caef8:     	add	w2, w5, w2
1000caefc:     	ldrsb	w4, [x4, x15]
1000caf00:     	ldrsb	w5, [x6, x16]
1000caf04:     	add	w2, w2, w4
1000caf08:     	add	w2, w2, w5
1000caf0c:     	ldrsb	w4, [x20, x17]
1000caf10:     	add	w2, w2, w4
1000caf14:     	add	x4, sp, #176
1000caf18:     	scvtf	s3, w2
1000caf1c:     	add	x2, x27, x12
1000caf20:     	ldur	s4, [x2, #-64]
1000caf24:     	fadd	s1, s4, s1
1000caf28:     	stur	s1, [x2, #-64]
1000caf2c:     	ldr	s1, [x2]
1000caf30:     	fadd	s1, s1, s2
1000caf34:     	str	s1, [x2]
1000caf38:     	ldr	s1, [x2, #64]
1000caf3c:     	fadd	s1, s1, s3
1000caf40:     	ldr	s2, [x4, x12]
1000caf44:     	str	s1, [x2, #64]
1000caf48:     	fadd	s0, s2, s0
1000caf4c:     	str	s0, [x4, x12]
1000caf50:     	add	x12, x12, #4
1000caf54:     	cmp	x12, #64
1000caf58:     	b.ne	0x1000cad80 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x14c>
1000caf5c:     	add	x0, x0, #64
1000caf60:     	ldp	x8, x1, [sp, #8]
1000caf64:     	add	x1, x1, #16
1000caf68:     	cmp	x1, x8
1000caf6c:     	b.ne	0x1000cacb0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x7c>
1000caf70:     	ldp	q0, q1, [sp, #368]
1000caf74:     	ldr	x8, [sp]
1000caf78:     	stp	q0, q1, [x8, #192]
1000caf7c:     	ldp	q0, q1, [sp, #400]
1000caf80:     	stp	q0, q1, [x8, #224]
1000caf84:     	ldp	q0, q1, [sp, #304]
1000caf88:     	stp	q0, q1, [x8, #128]
1000caf8c:     	ldp	q0, q1, [sp, #336]
1000caf90:     	stp	q0, q1, [x8, #160]
1000caf94:     	ldp	q0, q1, [sp, #240]
1000caf98:     	stp	q0, q1, [x8, #64]
1000caf9c:     	ldp	q0, q1, [sp, #272]
1000cafa0:     	stp	q0, q1, [x8, #96]
1000cafa4:     	ldp	q0, q1, [sp, #176]
1000cafa8:     	stp	q0, q1, [x8]
1000cafac:     	ldp	q0, q1, [sp, #208]
1000cafb0:     	stp	q0, q1, [x8, #32]
1000cafb4:     	adrp	x8, 0x10016c000 <void run<unsigned char, 16ul, 8ul, false>(char const*)+0x24c>
1000cafb8:     	ldr	x8, [x8, #392]
1000cafbc:     	ldr	x8, [x8]
1000cafc0:     	ldur	x9, [x29, #-96]
1000cafc4:     	cmp	x8, x9
1000cafc8:     	b.ne	0x1000cafec <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3b8>
1000cafcc:     	add	sp, sp, #448
1000cafd0:     	ldp	x29, x30, [sp, #80]
1000cafd4:     	ldp	x20, x19, [sp, #64]
1000cafd8:     	ldp	x22, x21, [sp, #48]
1000cafdc:     	ldp	x24, x23, [sp, #32]
1000cafe0:     	ldp	x26, x25, [sp, #16]
1000cafe4:     	ldp	x28, x27, [sp], #96
1000cafe8:     	ret
1000cafec:     	bl	0x100163694 <_strcmp+0x100163694>

