00000001000d392c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000d392c:     	stp	x28, x27, [sp, #-96]!
1000d3930:     	stp	x26, x25, [sp, #16]
1000d3934:     	stp	x24, x23, [sp, #32]
1000d3938:     	stp	x22, x21, [sp, #48]
1000d393c:     	stp	x20, x19, [sp, #64]
1000d3940:     	stp	x29, x30, [sp, #80]
1000d3944:     	add	x29, sp, #80
1000d3948:     	sub	sp, sp, #704
1000d394c:     	str	x3, [sp]
1000d3950:     	adrp	x8, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x288>
1000d3954:     	ldr	x8, [x8, #392]
1000d3958:     	ldr	x8, [x8]
1000d395c:     	stur	x8, [x29, #-96]
1000d3960:     	movi.2d	v0, #0000000000000000
1000d3964:     	stp	q0, q0, [sp, #656]
1000d3968:     	lsl	x8, x2, #1
1000d396c:     	stp	q0, q0, [sp, #624]
1000d3970:     	stp	q0, q0, [sp, #592]
1000d3974:     	stp	q0, q0, [sp, #560]
1000d3978:     	stp	q0, q0, [sp, #528]
1000d397c:     	stp	q0, q0, [sp, #496]
1000d3980:     	stp	q0, q0, [sp, #464]
1000d3984:     	stp	q0, q0, [sp, #432]
1000d3988:     	stp	q0, q0, [sp, #400]
1000d398c:     	stp	q0, q0, [sp, #368]
1000d3990:     	stp	q0, q0, [sp, #336]
1000d3994:     	stp	q0, q0, [sp, #304]
1000d3998:     	stp	q0, q0, [sp, #272]
1000d399c:     	stp	q0, q0, [sp, #240]
1000d39a0:     	stp	q0, q0, [sp, #208]
1000d39a4:     	stp	q0, q0, [sp, #176]
1000d39a8:     	ands	x8, x8, #0xfffffffffffffffc
1000d39ac:     	b.eq	0x1000d3c88 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x35c>
1000d39b0:     	add	x8, x1, x8
1000d39b4:     	str	x8, [sp, #8]
1000d39b8:     	add	x8, sp, #176
1000d39bc:     	add	x27, x8, #256
1000d39c0:     	adrp	x11, 0x10016a000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x2f0>
1000d39c4:     	add	x11, x11, #1724
1000d39c8:     	mov	x12, #0
1000d39cc:     	ldp	w8, w9, [x1]
1000d39d0:     	ubfx	x10, x8, #8, #4
1000d39d4:     	str	x10, [sp, #168]
1000d39d8:     	ubfx	x10, x8, #16, #4
1000d39dc:     	str	x10, [sp, #160]
1000d39e0:     	ubfx	x10, x8, #24, #4
1000d39e4:     	str	x10, [sp, #152]
1000d39e8:     	ldp	w10, w17, [x1, #8]
1000d39ec:     	str	x1, [sp, #16]
1000d39f0:     	and	x14, x8, #0xf
1000d39f4:     	ubfx	x13, x8, #4, #4
1000d39f8:     	stp	x13, x14, [sp, #136]
1000d39fc:     	ubfx	x14, x8, #12, #4
1000d3a00:     	ubfx	x13, x8, #20, #4
1000d3a04:     	stp	x13, x14, [sp, #120]
1000d3a08:     	lsr	x8, x8, #28
1000d3a0c:     	str	x8, [sp, #112]
1000d3a10:     	and	x8, x9, #0xf
1000d3a14:     	str	x8, [sp, #104]
1000d3a18:     	ubfx	x8, x9, #8, #4
1000d3a1c:     	str	x8, [sp, #96]
1000d3a20:     	ubfx	x8, x9, #16, #4
1000d3a24:     	str	x8, [sp, #88]
1000d3a28:     	ubfx	x8, x9, #24, #4
1000d3a2c:     	str	x8, [sp, #80]
1000d3a30:     	ubfx	x8, x9, #4, #4
1000d3a34:     	str	x8, [sp, #72]
1000d3a38:     	ubfx	x8, x9, #12, #4
1000d3a3c:     	str	x8, [sp, #64]
1000d3a40:     	ubfx	x8, x9, #20, #4
1000d3a44:     	str	x8, [sp, #56]
1000d3a48:     	lsr	x8, x9, #28
1000d3a4c:     	str	x8, [sp, #48]
1000d3a50:     	and	x9, x10, #0xf
1000d3a54:     	ubfx	x8, x10, #8, #4
1000d3a58:     	stp	x8, x9, [sp, #32]
1000d3a5c:     	ubfx	x8, x10, #16, #4
1000d3a60:     	str	x8, [sp, #24]
1000d3a64:     	ubfx	x28, x10, #24, #4
1000d3a68:     	ubfx	x30, x10, #4, #4
1000d3a6c:     	ubfx	x3, x10, #12, #4
1000d3a70:     	ubfx	x8, x10, #20, #4
1000d3a74:     	lsr	x9, x10, #28
1000d3a78:     	and	x1, x17, #0xf
1000d3a7c:     	ubfx	x10, x17, #8, #4
1000d3a80:     	ubfx	x13, x17, #16, #4
1000d3a84:     	ubfx	x26, x17, #24, #4
1000d3a88:     	ubfx	x14, x17, #4, #4
1000d3a8c:     	ubfx	x15, x17, #12, #4
1000d3a90:     	ubfx	x16, x17, #20, #4
1000d3a94:     	lsr	x17, x17, #28
1000d3a98:     	ldr	w20, [x0, x12]
1000d3a9c:     	lsl	w2, w20, #4
1000d3aa0:     	and	x2, x2, #0xf0
1000d3aa4:     	add	x5, x11, x2
1000d3aa8:     	and	x2, x20, #0xf0
1000d3aac:     	add	x2, x11, x2
1000d3ab0:     	lsr	x4, x20, #4
1000d3ab4:     	and	x4, x4, #0xf0
1000d3ab8:     	add	x7, x11, x4
1000d3abc:     	lsr	x4, x20, #8
1000d3ac0:     	and	x4, x4, #0xf0
1000d3ac4:     	add	x4, x11, x4
1000d3ac8:     	lsr	x6, x20, #12
1000d3acc:     	and	x6, x6, #0xf0
1000d3ad0:     	add	x19, x11, x6
1000d3ad4:     	lsr	x6, x20, #16
1000d3ad8:     	and	x6, x6, #0xf0
1000d3adc:     	add	x6, x11, x6
1000d3ae0:     	lsr	x21, x20, #20
1000d3ae4:     	and	x21, x21, #0xf0
1000d3ae8:     	add	x21, x11, x21
1000d3aec:     	lsr	x20, x20, #24
1000d3af0:     	and	x20, x20, #0xf0
1000d3af4:     	ldr	x22, [sp, #144]
1000d3af8:     	ldrb	w22, [x5, x22]
1000d3afc:     	add	x20, x11, x20
1000d3b00:     	ldp	x24, x23, [sp, #160]
1000d3b04:     	ldrb	w23, [x7, x23]
1000d3b08:     	ldrb	w24, [x19, x24]
1000d3b0c:     	add	w22, w22, w23
1000d3b10:     	add	w22, w22, w24
1000d3b14:     	ldr	x23, [sp, #152]
1000d3b18:     	ldrb	w23, [x21, x23]
1000d3b1c:     	ldr	x24, [sp, #136]
1000d3b20:     	ldrb	w24, [x2, x24]
1000d3b24:     	add	w22, w22, w23
1000d3b28:     	add	w22, w22, w24
1000d3b2c:     	ldp	x24, x23, [sp, #120]
1000d3b30:     	ldrb	w23, [x4, x23]
1000d3b34:     	ldrb	w24, [x6, x24]
1000d3b38:     	add	w22, w22, w23
1000d3b3c:     	add	w22, w22, w24
1000d3b40:     	ldr	x23, [sp, #112]
1000d3b44:     	ldrb	w23, [x20, x23]
1000d3b48:     	add	w22, w22, w23
1000d3b4c:     	scvtf	s0, w22
1000d3b50:     	ldp	x23, x22, [sp, #96]
1000d3b54:     	ldrb	w22, [x5, x22]
1000d3b58:     	ldrb	w23, [x7, x23]
1000d3b5c:     	ldp	x25, x24, [sp, #80]
1000d3b60:     	ldrb	w24, [x19, x24]
1000d3b64:     	ldrb	w25, [x21, x25]
1000d3b68:     	add	w22, w22, w23
1000d3b6c:     	ldr	x23, [sp, #72]
1000d3b70:     	ldrb	w23, [x2, x23]
1000d3b74:     	add	w22, w22, w24
1000d3b78:     	ldr	x24, [sp, #64]
1000d3b7c:     	ldrb	w24, [x4, x24]
1000d3b80:     	add	w22, w22, w25
1000d3b84:     	ldr	x25, [sp, #56]
1000d3b88:     	ldrb	w25, [x6, x25]
1000d3b8c:     	add	w22, w22, w23
1000d3b90:     	add	w22, w22, w24
1000d3b94:     	add	w22, w22, w25
1000d3b98:     	ldr	x23, [sp, #48]
1000d3b9c:     	ldrb	w23, [x20, x23]
1000d3ba0:     	add	w22, w22, w23
1000d3ba4:     	scvtf	s1, w22
1000d3ba8:     	ldp	x23, x22, [sp, #32]
1000d3bac:     	ldrb	w22, [x5, x22]
1000d3bb0:     	ldrb	w23, [x7, x23]
1000d3bb4:     	ldr	x24, [sp, #24]
1000d3bb8:     	ldrb	w24, [x19, x24]
1000d3bbc:     	add	w22, w22, w23
1000d3bc0:     	ldrb	w23, [x21, x28]
1000d3bc4:     	add	w22, w22, w24
1000d3bc8:     	ldrb	w24, [x2, x30]
1000d3bcc:     	add	w22, w22, w23
1000d3bd0:     	ldrb	w23, [x4, x3]
1000d3bd4:     	add	w22, w22, w24
1000d3bd8:     	ldrb	w24, [x6, x8]
1000d3bdc:     	add	w22, w22, w23
1000d3be0:     	ldrb	w23, [x20, x9]
1000d3be4:     	add	w22, w22, w24
1000d3be8:     	add	w22, w22, w23
1000d3bec:     	scvtf	s2, w22
1000d3bf0:     	ldrb	w5, [x5, x1]
1000d3bf4:     	ldrb	w7, [x7, x10]
1000d3bf8:     	ldrb	w19, [x19, x13]
1000d3bfc:     	add	w5, w5, w7
1000d3c00:     	add	w5, w5, w19
1000d3c04:     	ldrb	w7, [x21, x26]
1000d3c08:     	ldrb	w2, [x2, x14]
1000d3c0c:     	add	w5, w5, w7
1000d3c10:     	add	w2, w5, w2
1000d3c14:     	ldrb	w4, [x4, x15]
1000d3c18:     	ldrb	w5, [x6, x16]
1000d3c1c:     	add	w2, w2, w4
1000d3c20:     	add	w2, w2, w5
1000d3c24:     	ldrb	w4, [x20, x17]
1000d3c28:     	add	w2, w2, w4
1000d3c2c:     	add	x4, sp, #176
1000d3c30:     	scvtf	s3, w2
1000d3c34:     	add	x2, x27, x12
1000d3c38:     	ldur	s4, [x2, #-128]
1000d3c3c:     	fadd	s1, s4, s1
1000d3c40:     	stur	s1, [x2, #-128]
1000d3c44:     	ldr	s1, [x2]
1000d3c48:     	fadd	s1, s1, s2
1000d3c4c:     	str	s1, [x2]
1000d3c50:     	ldr	s1, [x2, #128]
1000d3c54:     	fadd	s1, s1, s3
1000d3c58:     	ldr	s2, [x4, x12]
1000d3c5c:     	str	s1, [x2, #128]
1000d3c60:     	fadd	s0, s2, s0
1000d3c64:     	str	s0, [x4, x12]
1000d3c68:     	add	x12, x12, #4
1000d3c6c:     	cmp	x12, #128
1000d3c70:     	b.ne	0x1000d3a98 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x16c>
1000d3c74:     	add	x0, x0, #128
1000d3c78:     	ldp	x8, x1, [sp, #8]
1000d3c7c:     	add	x1, x1, #16
1000d3c80:     	cmp	x1, x8
1000d3c84:     	b.ne	0x1000d39c8 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x9c>
1000d3c88:     	add	x1, sp, #176
1000d3c8c:     	ldr	x0, [sp]
1000d3c90:     	mov	w2, #512
1000d3c94:     	bl	0x1001636dc <_strcmp+0x1001636dc>
1000d3c98:     	ldur	x8, [x29, #-96]
1000d3c9c:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xfc>
1000d3ca0:     	ldr	x9, [x9, #392]
1000d3ca4:     	ldr	x9, [x9]
1000d3ca8:     	cmp	x9, x8
1000d3cac:     	b.ne	0x1000d3cd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 32ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<4ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x3a4>
1000d3cb0:     	add	sp, sp, #704
1000d3cb4:     	ldp	x29, x30, [sp, #80]
1000d3cb8:     	ldp	x20, x19, [sp, #64]
1000d3cbc:     	ldp	x22, x21, [sp, #48]
1000d3cc0:     	ldp	x24, x23, [sp, #32]
1000d3cc4:     	ldp	x26, x25, [sp, #16]
1000d3cc8:     	ldp	x28, x27, [sp], #96
1000d3ccc:     	ret
1000d3cd0:     	bl	0x100163694 <_strcmp+0x100163694>

