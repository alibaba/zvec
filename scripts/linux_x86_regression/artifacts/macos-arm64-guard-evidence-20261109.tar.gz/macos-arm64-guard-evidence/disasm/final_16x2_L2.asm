00000001000c8e00 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)>:
1000c8e00:     	sub	sp, sp, #272
1000c8e04:     	stp	x28, x27, [sp, #176]
1000c8e08:     	stp	x26, x25, [sp, #192]
1000c8e0c:     	stp	x24, x23, [sp, #208]
1000c8e10:     	stp	x22, x21, [sp, #224]
1000c8e14:     	stp	x20, x19, [sp, #240]
1000c8e18:     	stp	x29, x30, [sp, #256]
1000c8e1c:     	add	x29, sp, #256
1000c8e20:     	str	x3, [sp]
1000c8e24:     	adrp	x8, 0x10016c000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x84>
1000c8e28:     	ldr	x8, [x8, #392]
1000c8e2c:     	ldr	x8, [x8]
1000c8e30:     	stur	x8, [x29, #-96]
1000c8e34:     	movi.2d	v0, #0000000000000000
1000c8e38:     	stp	q0, q0, [sp, #128]
1000c8e3c:     	stp	q0, q0, [sp, #96]
1000c8e40:     	stp	q0, q0, [sp, #64]
1000c8e44:     	stp	q0, q0, [sp, #32]
1000c8e48:     	ands	x8, x2, #0xfffffffffffffffe
1000c8e4c:     	b.eq	0x1000c8fd0 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x1d0>
1000c8e50:     	add	x8, x1, x8
1000c8e54:     	str	x8, [sp, #8]
1000c8e58:     	adrp	x9, 0x10016a000 <void kernel<unsigned char, 16ul, 2ul, true>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xb0>
1000c8e5c:     	add	x9, x9, #1212
1000c8e60:     	mov	x11, #0
1000c8e64:     	ldp	w4, w23, [x1]
1000c8e68:     	ubfx	x8, x4, #8, #4
1000c8e6c:     	stp	x1, x8, [sp, #16]
1000c8e70:     	ubfx	x13, x4, #16, #4
1000c8e74:     	and	x14, x4, #0xf
1000c8e78:     	ubfx	x15, x4, #24, #4
1000c8e7c:     	ubfx	x16, x4, #4, #4
1000c8e80:     	ubfx	x17, x4, #12, #4
1000c8e84:     	ubfx	x2, x4, #20, #4
1000c8e88:     	lsr	x4, x4, #28
1000c8e8c:     	and	x5, x23, #0xf
1000c8e90:     	ubfx	x6, x23, #8, #4
1000c8e94:     	ubfx	x7, x23, #16, #4
1000c8e98:     	ubfx	x19, x23, #24, #4
1000c8e9c:     	ubfx	x20, x23, #4, #4
1000c8ea0:     	ubfx	x21, x23, #12, #4
1000c8ea4:     	ubfx	x22, x23, #20, #4
1000c8ea8:     	lsr	x23, x23, #28
1000c8eac:     	ldr	w24, [x0, x11]
1000c8eb0:     	lsl	w25, w24, #4
1000c8eb4:     	and	x25, x25, #0xf0
1000c8eb8:     	add	x25, x9, x25
1000c8ebc:     	and	x26, x24, #0xf0
1000c8ec0:     	add	x26, x9, x26
1000c8ec4:     	lsr	x27, x24, #4
1000c8ec8:     	and	x27, x27, #0xf0
1000c8ecc:     	add	x27, x9, x27
1000c8ed0:     	lsr	x28, x24, #8
1000c8ed4:     	and	x28, x28, #0xf0
1000c8ed8:     	add	x28, x9, x28
1000c8edc:     	lsr	x30, x24, #12
1000c8ee0:     	and	x30, x30, #0xf0
1000c8ee4:     	add	x30, x9, x30
1000c8ee8:     	lsr	x8, x24, #16
1000c8eec:     	and	x8, x8, #0xf0
1000c8ef0:     	add	x8, x9, x8
1000c8ef4:     	lsr	x3, x24, #20
1000c8ef8:     	and	x3, x3, #0xf0
1000c8efc:     	add	x3, x9, x3
1000c8f00:     	lsr	x24, x24, #24
1000c8f04:     	and	x24, x24, #0xf0
1000c8f08:     	ldrb	w10, [x25, x14]
1000c8f0c:     	ldr	x12, [sp, #24]
1000c8f10:     	ldrb	w1, [x27, x12]
1000c8f14:     	ldrb	w12, [x30, x13]
1000c8f18:     	add	w10, w10, w1
1000c8f1c:     	add	w10, w10, w12
1000c8f20:     	ldrb	w12, [x3, x15]
1000c8f24:     	ldrb	w1, [x26, x16]
1000c8f28:     	add	w10, w10, w12
1000c8f2c:     	add	w10, w10, w1
1000c8f30:     	ldrb	w12, [x28, x17]
1000c8f34:     	ldrb	w1, [x8, x2]
1000c8f38:     	add	x24, x9, x24
1000c8f3c:     	add	w10, w10, w12
1000c8f40:     	add	w10, w10, w1
1000c8f44:     	ldrb	w12, [x24, x4]
1000c8f48:     	add	w10, w10, w12
1000c8f4c:     	scvtf	s0, w10
1000c8f50:     	add	x10, sp, #32
1000c8f54:     	add	x10, x10, x11
1000c8f58:     	ldr	s1, [x10]
1000c8f5c:     	ldrb	w12, [x25, x5]
1000c8f60:     	fadd	s0, s1, s0
1000c8f64:     	ldrb	w1, [x27, x6]
1000c8f68:     	ldrb	w25, [x30, x7]
1000c8f6c:     	add	w12, w12, w1
1000c8f70:     	add	w12, w12, w25
1000c8f74:     	ldrb	w1, [x3, x19]
1000c8f78:     	ldrb	w3, [x26, x20]
1000c8f7c:     	add	w12, w12, w1
1000c8f80:     	add	w12, w12, w3
1000c8f84:     	ldrb	w1, [x28, x21]
1000c8f88:     	ldrb	w8, [x8, x22]
1000c8f8c:     	add	w12, w12, w1
1000c8f90:     	add	w8, w12, w8
1000c8f94:     	ldrb	w12, [x24, x23]
1000c8f98:     	add	w8, w8, w12
1000c8f9c:     	scvtf	s1, w8
1000c8fa0:     	str	s0, [x10]
1000c8fa4:     	ldr	s0, [x10, #64]
1000c8fa8:     	fadd	s0, s0, s1
1000c8fac:     	str	s0, [x10, #64]
1000c8fb0:     	add	x11, x11, #4
1000c8fb4:     	cmp	x11, #64
1000c8fb8:     	b.ne	0x1000c8eac <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0xac>
1000c8fbc:     	add	x0, x0, #64
1000c8fc0:     	ldp	x8, x1, [sp, #8]
1000c8fc4:     	add	x1, x1, #8
1000c8fc8:     	cmp	x1, x8
1000c8fcc:     	b.ne	0x1000c8e60 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x60>
1000c8fd0:     	ldp	q0, q1, [sp, #96]
1000c8fd4:     	ldr	x8, [sp]
1000c8fd8:     	stp	q0, q1, [x8, #64]
1000c8fdc:     	ldp	q0, q1, [sp, #128]
1000c8fe0:     	stp	q0, q1, [x8, #96]
1000c8fe4:     	ldp	q0, q1, [sp, #32]
1000c8fe8:     	stp	q0, q1, [x8]
1000c8fec:     	ldp	q0, q1, [sp, #64]
1000c8ff0:     	stp	q0, q1, [x8, #32]
1000c8ff4:     	ldur	x8, [x29, #-96]
1000c8ff8:     	adrp	x9, 0x10016c000 <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)2>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x19c>
1000c8ffc:     	ldr	x9, [x9, #392]
1000c9000:     	ldr	x9, [x9]
1000c9004:     	cmp	x9, x8
1000c9008:     	b.ne	0x1000c902c <void zvec::turbo::InterleavedDistanceMatrix<unsigned char, 16ul, (zvec::turbo::MetricType)0>::ComputePackedColumns<2ul>(unsigned char const*, unsigned char const*, unsigned long, float*)+0x22c>
1000c900c:     	ldp	x29, x30, [sp, #256]
1000c9010:     	ldp	x20, x19, [sp, #240]
1000c9014:     	ldp	x22, x21, [sp, #224]
1000c9018:     	ldp	x24, x23, [sp, #208]
1000c901c:     	ldp	x26, x25, [sp, #192]
1000c9020:     	ldp	x28, x27, [sp, #176]
1000c9024:     	add	sp, sp, #272
1000c9028:     	ret
1000c902c:     	bl	0x100163694 <_strcmp+0x100163694>

