from pathlib import Path
import subprocess,re,json
r=Path(__file__).resolve().parent;summary={}
for v in ['9819','unguarded','final']:
 p=r/'bin'/f'{v}_matrix';raw=subprocess.check_output(['nm','-n',str(p)],text=True).splitlines();names=[l.split()[-1] for l in raw if len(l.split())==3];ds=subprocess.check_output(['c++filt'],input='\n'.join(names)+'\n',text=True).splitlines()
 selected=[n for n,d in zip(names,ds) if ('InterleavedDistanceMatrix<unsigned char' in d and ('ComputePackedColumns' in d or 'ComputeSingleColumn' in d)) or 'kernel<short' in d or ('DistanceMatrix<zvec::ailego::Float16, 1ul, 1ul' in d and '::distance' not in d) or ('neon::' in d and 'inner_product_fp16_distance' in d)]
 b=subprocess.check_output(['xcrun','llvm-objdump','-d','--no-show-raw-insn','--disassemble-symbols='+','.join(selected),str(p)]);data=subprocess.check_output(['c++filt'],input=b).decode();(r/'disasm'/f'{v}_kernels.asm').write_text(data)
 summary[v]={}
 for m in re.finditer(r'^([0-9a-f]+) <([^\n]+)>:\n(.*?)(?=^[0-9a-f]+ <|\Z)',data,re.M|re.S):
  shape=re.search(r'unsigned char, (\d+)ul, .*MetricType\)(\d)>::Compute(\w+)<(\d+ul|false)>',m[2])
  if shape:
   key=f'{shape[1]}x{shape[4][:-2] if shape[3]=="PackedColumns" else "1"}_{"L2" if shape[2]=="0" else "IP"}';(r/'disasm'/f'{v}_{key}.asm').write_text(m[0]);lines=m[3].splitlines();summary[v][key]={'instructions':sum(bool(re.match(r'^[0-9a-f]+:',l)) for l in lines),'stack_access_instructions':sum('[sp' in l for l in lines)}
(r/'disasm/int4_sizes.json').write_text(json.dumps(summary,indent=2))
for k in ['16x16_L2','32x16_L2','32x32_L2','32x1_IP']:print(k,{v:summary[v][k] for v in summary})
