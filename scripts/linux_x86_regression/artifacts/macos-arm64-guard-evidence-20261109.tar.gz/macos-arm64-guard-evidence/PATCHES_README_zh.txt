本包是 macOS ARM64 最小修复及验证证据；原分支尚未提交/推送此修复。
先读 ARM64_GUARD_REPORT_zh.md，尤其第 7～9 节的残余项和平台范围。

源码基线：richyreachy/zvec，fix/legacy-matrix-distance-performance，c65ac889。
c65ac889 相对 9819c706 没有 src/tests 变动。

选择且仅选择一份补丁：
1. 从 9819c706 或 c65ac889（尚未应用 x86 final）开始：
   git apply --check /绝对路径/buildinfo/guarded_vs_9819c706.patch
   git apply /绝对路径/buildinfo/guarded_vs_9819c706.patch
2. 已应用交接包 x86 final（matrix.h 与 matrix_unguarded.h 相同）：
   git apply --check /绝对路径/buildinfo/arm64_guard_vs_unguarded.patch
   git apply /绝对路径/buildinfo/arm64_guard_vs_unguarded.patch

建议在独立工作树操作，保留现有改动和原始证据；两份补丁勿重复应用。
完整修复只改 src/turbo/distance/matrix.h。

包内执行脚本保留本机路径，是复现记录，不是跨机器一键运行包。
跨机复验需重新配置 checkout/deps/build 路径，沿用仓库 scripts/linux_x86_regression 工具和既有服务器执行流程。
x86 检查证明本次 ARM 条件调整的预处理 token/交叉编译目标文件不变；不代表本次在 Linux 服务器重跑过。
不要将本包报告表述为“所有形状零回退”：完整 sweep 的 FP16 1×1 布局相关项仍保留。
