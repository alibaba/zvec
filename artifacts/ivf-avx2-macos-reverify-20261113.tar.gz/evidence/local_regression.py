from pathlib import Path
import sys,json,os
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'))
import run as kit
import reverify as verify
b=r/'build';deps=Path('/Users/xingrui/Documents/workspace/zvec/legacy_code_cleanup/zvec')
paths=['tests/turbo','tests/core/metric','tests/core/algorithm/flat','tests/core/algorithm/ivf']
targets=sorted(p.stem for folder in paths for p in (repo/folder).glob('*_test.cc'))
kit.run(['cmake','--build',b,'--parallel','4','--target',*kit.LIBS,*targets,'legacy_ivf_comparison'],r/'build-full.log')
results={};bindir=r/'bin';bindir.mkdir(exist_ok=True)
for target in targets+['legacy_ivf_comparison']:
 kit.static_link(b,target,bindir/target,r/'link.log')
 if target=='legacy_ivf_comparison':os.environ['ZVEC_LEGACY_READ_FIXTURES']=str(r.parent/'ivf_interleaved_avx2_20261113/handoff/old-index-fixtures')
 results[target]=verify.test(bindir/target,r/'correctness'/target)
 print(target,{k:v for k,v in results[target].items() if k!='diagnostics'},flush=True)
 kit.dump(r/'correctness.json',results)
os.environ.pop('ZVEC_LEGACY_READ_FIXTURES',None)
sb=r/'build-sanitized';kit.configure(repo,sb,deps,r/'configure-sanitized.log',True)
verify.check_instrumentation(sb,r/'instrumentation.json')
kit.run(['cmake','--build',sb,'--parallel','4','--target',*kit.LIBS,*verify.SAN_TESTS],r/'build-sanitized.log')
sbindir=r/'bin-sanitized';sbindir.mkdir(exist_ok=True);san={}
for target in verify.SAN_TESTS:
 kit.static_link(sb,target,sbindir/target,r/'link-sanitized.log')
 san[target]=verify.test(sbindir/target,r/'sanitized'/target,True)
 print('sanitized',target,{k:v for k,v in san[target].items() if k!='diagnostics'},'diagnostics',len(san[target]['diagnostics']),flush=True)
 kit.dump(r/'sanitized.json',san)
print('regular passed',all(x['ok'] for x in results.values()),'sanitized clean',all(x['ok'] for x in san.values()),flush=True)
