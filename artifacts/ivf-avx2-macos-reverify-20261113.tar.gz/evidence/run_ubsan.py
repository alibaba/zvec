from pathlib import Path
import sys,json
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'))
import run as kit
import reverify as verify
version=sys.argv[1]
b=r/('build-ubsan' if version=='after' else 'build-ubsan-before')
if version=='before':
 source=r/'tooling-final-prepare/sources/before'
 kit.run(['cmake','-S',repo/'scripts/ivf_interleaved_avx2_regression','-B',b,'-G','Ninja','-DPROJECT_ROOT_DIR='+str(source),'-DVALIDATION_DEPS=/Users/xingrui/Documents/workspace/zvec/legacy_code_cleanup/zvec','-DVALIDATION_FIXED=ON','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_INTERPROCEDURAL_OPTIMIZATION=OFF','-DVALIDATION_SANITIZE=ON','-DVALIDATION_SANITIZERS=undefined'],r/'configure-ubsan-before.log')
 kit.run(['cmake','--build',b,'--parallel','4','--target',*kit.LIBS,*verify.SAN_TESTS],r/'build-ubsan-before.log')
commands=json.loads((b/'compile_commands.json').read_text());missing=[x['file'] for x in commands if '-fsanitize=undefined' not in x['command'] or '-fno-sanitize=' in x['command']]
assert not missing,missing
kit.dump(r/('instrumentation-ubsan-'+version+'.json'),{'translation_units':len(commands),'missing_or_suppressed':missing})
bindir=r/('bin-ubsan-'+version);bindir.mkdir();results={}
for target in verify.SAN_TESTS:
 kit.static_link(b,target,bindir/target,r/('link-ubsan-'+version+'.log'))
 results[target]=verify.test(bindir/target,r/('ubsan-'+version)/target,True)
 print(version,target,{k:v for k,v in results[target].items() if k!='diagnostics'},'reports',len(results[target]['diagnostics']),flush=True)
 kit.dump(r/('ubsan-'+version+'.json'),results)
