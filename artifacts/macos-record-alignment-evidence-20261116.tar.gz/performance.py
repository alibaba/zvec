from pathlib import Path
import sys,shutil,json,hashlib
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'));import run as kit,reverify as v
out=r/'performance';out.mkdir();before=r/'bin-before';before.mkdir();old=r.parent/'ivf_interleaved_avx2_20261113/bin/tools-bench';shutil.copy2(old,before/'ivf_interleaved_bench')
kit.dump(out/'provenance.json',dict(baseline_commit='e2ac9ee02a72b2da2265003c17b27357942a2d0d',baseline_binary=str(old),baseline_sha256=v.digest(old),candidate_sha256=v.digest(r/'bin/ivf_interleaved_bench'),production_source_comparison='All src/ hashes in ivf_interleaved_avx2_20261113/final-source-sha256.json match git HEAD; no production changes',sample_ms=50))
result=v.benchmark(out,{'before':before,'after':r/'bin'},None,50);kit.dump(out/'SUMMARY.json',result);print(result,flush=True)
