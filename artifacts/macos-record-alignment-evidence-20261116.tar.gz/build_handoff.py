from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';out=r/'handoff';out.mkdir(exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='e2ac9ee02a72b2da2265003c17b27357942a2d0d'
subprocess.run(['git','archive','--format=tar.gz','--output='+str(out/'source-base.tar.gz'),head],cwd=repo,check=True)
def new_patch(name):
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',name],cwd=repo,stdout=subprocess.PIPE)
 assert p.returncode==1;return p.stdout
name='tests/turbo/turbo_record_alignment_test.cc';(out/'baseline-vs-head.patch').write_bytes(new_patch(name))
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)+new_patch('src/turbo/distance/common/record_metadata.h');(out/'candidate-vs-baseline.patch').write_bytes(patch)
with tarfile.open(out/'source-base.tar.gz') as t:base={x.name:digest(t.extractfile(x).read()) for x in t.getmembers() if x.isfile()}
base[name]=digest((repo/name).read_bytes());dump(out/'before-source-sha256.json',base)
after=dict(base)
changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=repo,text=True).splitlines()+['src/turbo/distance/common/record_metadata.h']
for name in changed:after[name]=digest((repo/name).read_bytes())
dump(out/'after-source-sha256.json',after)
shutil.copytree(r.parent/'ivf_interleaved_avx2_20261113/handoff/old-index-fixtures',out/'old-index-fixtures',dirs_exist_ok=True)
tools=out/'tools';tools.mkdir(exist_ok=True)
for name in ['reverify.py','run.py','CMakeLists.txt','bench.cc','benchmark_clock.h','dispatch_probe.cc','legacy_compatibility.cc','validation-fixes.patch','validation-fixes.json','REVERIFY_zh.txt','record_alignment.py','RECORD_ALIGNMENT_zh.txt']:
 shutil.copy2(repo/'scripts/ivf_interleaved_avx2_regression'/name,tools/name)
shutil.copy2(tools/'RECORD_ALIGNMENT_zh.txt',out/'START_HERE_zh.txt')
dump(out/'alignment-manifest.json',dict(baseline_commit=head,candidate='baseline + candidate-vs-baseline.patch; uncommitted production fix',test_patch_sha256=digest((out/'baseline-vs-head.patch').read_bytes()),production_patch_sha256=digest(patch),production_files=changed))
(out/'SHA256SUMS').write_text(''.join(digest(p.read_bytes())+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
archive=repo/'artifacts/ivf-record-alignment-handoff-20261116.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(out.iterdir()):t.add(p,arcname=p.name)
Path(str(archive)+'.sha256').write_text(digest(archive.read_bytes())+'  '+archive.name+'\n')
print(archive);print(Path(str(archive)+'.sha256').read_text())
