	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo4avx236squared_euclidean_int4_distance_avx2EPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI0_1:
	.space	16,240
LCPI0_2:
	.space	16,8
LCPI0_3:
	.space	16,15
LCPI0_4:
	.byte	0                               ## 0x0
	.byte	2                               ## 0x2
	.byte	4                               ## 0x4
	.byte	6                               ## 0x6
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI0_5:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4avx236squared_euclidean_int4_distance_avx2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4avx236squared_euclidean_int4_distance_avx2EPKvS3_mPf: ## @_ZN4zvec5turbo4avx236squared_euclidean_int4_distance_avx2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$33, %rdx
	jb	LBB0_18
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	addq	$-32, %rdx
	movq	%rdx, %r10
	shrq	%r10
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%eax, %eax
	cmpq	$32, %rdx
	jae	LBB0_3
## %bb.2:
	vpxor	%xmm1, %xmm1, %xmm1
	jmp	LBB0_6
LBB0_3:
	vmovdqa	LCPI0_0(%rip), %ymm1            ## ymm1 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	movq	%rax, %r8
	vpmovzxbw	(%rdi,%rax), %ymm2      ## ymm2 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpmovzxbw	(%rsi,%rax), %ymm3      ## ymm3 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm2, %ymm4
	vpsraw	$12, %ymm4, %ymm4
	vpsllw	$12, %ymm3, %ymm5
	vpsraw	$12, %ymm5, %ymm5
	vpmullw	%ymm4, %ymm5, %ymm4
	vpsllw	$8, %ymm2, %ymm2
	vpsraw	$12, %ymm2, %ymm2
	vpsllw	$8, %ymm3, %ymm3
	vpsraw	$12, %ymm3, %ymm3
	vpmullw	%ymm2, %ymm3, %ymm2
	vpmaddwd	%ymm1, %ymm4, %ymm3
	vpaddd	%ymm0, %ymm3, %ymm0
	vpmaddwd	%ymm1, %ymm2, %ymm2
	vpaddd	%ymm2, %ymm0, %ymm0
	addq	$16, %rax
	addq	$32, %r8
	cmpq	%r10, %r8
	jbe	LBB0_4
## %bb.5:
	vextracti128	$1, %ymm0, %xmm1
	vpmovsxdq	%xmm1, %ymm1
	vpmovsxdq	%xmm0, %ymm0
LBB0_6:
	vpaddq	%ymm1, %ymm0, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r9
	movq	%r10, %r11
	subq	%rax, %r11
	jbe	LBB0_14
## %bb.7:
	cmpq	$8, %r11
	jae	LBB0_9
## %bb.8:
	movq	%rax, %r11
	jmp	LBB0_12
LBB0_9:
	movl	%r10d, %r8d
	andl	$7, %r8d
	subq	%r8, %r11
	addq	%rax, %r11
	vmovq	%r9, %xmm0
	vpxor	%xmm1, %xmm1, %xmm1
	vmovdqa	LCPI0_1(%rip), %xmm2            ## xmm2 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI0_2(%rip), %xmm3            ## xmm3 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI0_3(%rip), %xmm4            ## xmm4 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vmovdqa	LCPI0_4(%rip), %xmm5            ## xmm5 = <0,2,4,6,u,u,u,u,u,u,u,u,u,u,u,u>
	.p2align	4, 0x90
LBB0_10:                                ## =>This Inner Loop Header: Depth=1
	vmovd	(%rdi,%rax), %xmm6              ## xmm6 = mem[0],zero,zero,zero
	vmovd	4(%rdi,%rax), %xmm7             ## xmm7 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm6, %xmm8
	vpand	%xmm2, %xmm8, %xmm8
	vpsrlw	$4, %xmm8, %xmm8
	vpxor	%xmm3, %xmm8, %xmm8
	vpsubb	%xmm3, %xmm8, %xmm8
	vpsllw	$4, %xmm7, %xmm9
	vpand	%xmm2, %xmm9, %xmm9
	vpsrlw	$4, %xmm9, %xmm9
	vpxor	%xmm3, %xmm9, %xmm9
	vpsubb	%xmm3, %xmm9, %xmm9
	vpsrlw	$4, %xmm6, %xmm6
	vpand	%xmm4, %xmm6, %xmm6
	vpxor	%xmm3, %xmm6, %xmm6
	vpsubb	%xmm3, %xmm6, %xmm6
	vpsrlw	$4, %xmm7, %xmm7
	vpand	%xmm4, %xmm7, %xmm7
	vpxor	%xmm3, %xmm7, %xmm7
	vpsubb	%xmm3, %xmm7, %xmm7
	vmovd	(%rsi,%rax), %xmm10             ## xmm10 = mem[0],zero,zero,zero
	vmovd	4(%rsi,%rax), %xmm11            ## xmm11 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm10, %xmm12
	vpand	%xmm2, %xmm12, %xmm12
	vpsrlw	$4, %xmm12, %xmm12
	vpxor	%xmm3, %xmm12, %xmm12
	vpsubb	%xmm3, %xmm12, %xmm12
	vpsllw	$4, %xmm11, %xmm13
	vpand	%xmm2, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm3, %xmm13, %xmm13
	vpsubb	%xmm3, %xmm13, %xmm13
	vpsrlw	$4, %xmm10, %xmm10
	vpand	%xmm4, %xmm10, %xmm10
	vpxor	%xmm3, %xmm10, %xmm10
	vpsubb	%xmm3, %xmm10, %xmm10
	vpsrlw	$4, %xmm11, %xmm11
	vpand	%xmm4, %xmm11, %xmm11
	vpxor	%xmm3, %xmm11, %xmm11
	vpsubb	%xmm3, %xmm11, %xmm11
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm12, %xmm12          ## xmm12 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmullw	%xmm8, %xmm12, %xmm8
	vpshufb	%xmm5, %xmm8, %xmm8
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm13, %xmm12          ## xmm12 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmullw	%xmm9, %xmm12, %xmm9
	vpshufb	%xmm5, %xmm9, %xmm9
	vpmovsxbq	%xmm8, %ymm8
	vpmovsxbq	%xmm9, %ymm9
	vpmovzxbw	%xmm6, %xmm6            ## xmm6 = xmm6[0],zero,xmm6[1],zero,xmm6[2],zero,xmm6[3],zero,xmm6[4],zero,xmm6[5],zero,xmm6[6],zero,xmm6[7],zero
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmullw	%xmm6, %xmm10, %xmm6
	vpshufb	%xmm5, %xmm6, %xmm6
	vpmovzxbw	%xmm7, %xmm7            ## xmm7 = xmm7[0],zero,xmm7[1],zero,xmm7[2],zero,xmm7[3],zero,xmm7[4],zero,xmm7[5],zero,xmm7[6],zero,xmm7[7],zero
	vpmovzxbw	%xmm11, %xmm10          ## xmm10 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmullw	%xmm7, %xmm10, %xmm7
	vpshufb	%xmm5, %xmm7, %xmm7
	vpmovsxbq	%xmm6, %ymm6
	vpaddq	%ymm6, %ymm0, %ymm0
	vpaddq	%ymm0, %ymm8, %ymm0
	vpmovsxbq	%xmm7, %ymm6
	vpaddq	%ymm6, %ymm1, %ymm1
	vpaddq	%ymm1, %ymm9, %ymm1
	addq	$8, %rax
	cmpq	%rax, %r11
	jne	LBB0_10
## %bb.11:
	vpaddq	%ymm0, %ymm1, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r9
	testq	%r8, %r8
	je	LBB0_14
LBB0_12:
	movq	%r9, %rbx
	.p2align	4, 0x90
LBB0_13:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %r14d
	movl	%r14d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r14b
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%r14b
	movsbq	%r9b, %r8
	movsbq	%al, %r9
	addq	%rbx, %r9
	addq	%r8, %r9
	incq	%r11
	movq	%r9, %rbx
	cmpq	%r11, %r10
	jne	LBB0_13
LBB0_14:
	vcvtsi2ss	%r9, %xmm14, %xmm3
	vmovss	(%rdi,%r10), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	vmovss	(%rsi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vmulss	%xmm1, %xmm1, %xmm2
	vmulss	12(%rsi,%r10), %xmm2, %xmm2
	vmovss	4(%rdi,%r10), %xmm4             ## xmm4 = mem[0],zero,zero,zero
	vmulss	%xmm0, %xmm0, %xmm5
	vfmadd132ss	12(%rdi,%r10), %xmm2, %xmm5 ## xmm5 = (xmm5 * mem) + xmm2
	vmulss	LCPI0_5(%rip), %xmm0, %xmm2
	vmulss	%xmm1, %xmm2, %xmm2
	vfmadd213ss	%xmm5, %xmm3, %xmm2     ## xmm2 = (xmm3 * xmm2) + xmm5
	vsubss	4(%rsi,%r10), %xmm4, %xmm3
	vmulss	%xmm3, %xmm3, %xmm4
	testq	%rdx, %rdx
	js	LBB0_15
## %bb.16:
	vcvtsi2ss	%rdx, %xmm14, %xmm5
	jmp	LBB0_17
LBB0_15:
	andl	$1, %edx
	orq	%r10, %rdx
	vcvtsi2ss	%rdx, %xmm14, %xmm5
	vaddss	%xmm5, %xmm5, %xmm5
LBB0_17:
	vfmadd213ss	%xmm2, %xmm4, %xmm5     ## xmm5 = (xmm4 * xmm5) + xmm2
	vaddss	%xmm3, %xmm3, %xmm2
	vmulss	8(%rsi,%r10), %xmm1, %xmm1
	vfmsub132ss	8(%rdi,%r10), %xmm1, %xmm0 ## xmm0 = (xmm0 * mem) - xmm1
	vfmadd213ss	%xmm5, %xmm2, %xmm0     ## xmm0 = (xmm2 * xmm0) + xmm5
	vmovss	%xmm0, (%rcx)
	popq	%rbx
	popq	%r14
	popq	%rbp
LBB0_18:
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo4avx242squared_euclidean_int4_batch_distance_avx2EPKPKvS3_mmPfS5_
LCPI1_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI1_1:
	.space	16,240
LCPI1_2:
	.space	16,8
LCPI1_3:
	.space	16,15
LCPI1_4:
	.byte	0                               ## 0x0
	.byte	2                               ## 0x2
	.byte	4                               ## 0x4
	.byte	6                               ## 0x6
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI1_5:
	.long	0x80000000                      ## float -0
LCPI1_6:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4avx242squared_euclidean_int4_batch_distance_avx2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4avx242squared_euclidean_int4_batch_distance_avx2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4avx242squared_euclidean_int4_batch_distance_avx2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$33, %rcx
	jb	LBB1_32
## %bb.1:
	movq	%rsi, %r12
	addq	$-32, %rcx
	movq	%rcx, -48(%rbp)                 ## 8-byte Spill
	cmpq	$2, %rdx
	movq	%rdx, -56(%rbp)                 ## 8-byte Spill
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movq	%rdi, -64(%rbp)                 ## 8-byte Spill
	jae	LBB1_7
## %bb.2:
	xorl	%r13d, %r13d
LBB1_3:
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	%rax, %rsi
	shrq	%rsi
	cmpq	%rdx, %r13
	movq	-72(%rbp), %r14                 ## 8-byte Reload
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	jae	LBB1_26
## %bb.4:
	movl	%esi, %edi
	andl	$7, %edi
	movq	%rsi, %r8
	andq	$-8, %r8
	vmovdqa	LCPI1_1(%rip), %xmm0            ## xmm0 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI1_2(%rip), %xmm1            ## xmm1 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI1_3(%rip), %xmm2            ## xmm2 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vmovdqa	LCPI1_4(%rip), %xmm3            ## xmm3 = <0,2,4,6,u,u,u,u,u,u,u,u,u,u,u,u>
	vmovdqa	LCPI1_0(%rip), %ymm4            ## ymm4 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	jmp	LBB1_5
	.p2align	4, 0x90
LBB1_25:                                ##   in Loop: Header=BB1_5 Depth=1
	vcvtsi2ss	%rcx, %xmm15, %xmm5
	vmovss	%xmm5, (%r14,%r13,4)
	incq	%r13
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %r13
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	je	LBB1_26
LBB1_5:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_16 Depth 2
                                        ##     Child Loop BB1_21 Depth 2
                                        ##     Child Loop BB1_24 Depth 2
	movq	(%r15,%r13,8), %r9
	vpxor	%xmm5, %xmm5, %xmm5
	cmpq	$32, %rax
	jae	LBB1_15
## %bb.6:                               ##   in Loop: Header=BB1_5 Depth=1
	xorl	%eax, %eax
	jmp	LBB1_17
	.p2align	4, 0x90
LBB1_15:                                ##   in Loop: Header=BB1_5 Depth=1
	xorl	%ecx, %ecx
	.p2align	4, 0x90
LBB1_16:                                ##   Parent Loop BB1_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbw	(%r12,%rcx), %ymm6      ## ymm6 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm6, %ymm7
	vpsraw	$12, %ymm7, %ymm7
	vpsllw	$8, %ymm6, %ymm6
	vpsraw	$12, %ymm6, %ymm6
	vpmovzxbw	(%r9,%rcx), %ymm8       ## ymm8 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm8, %ymm9
	vpsraw	$12, %ymm9, %ymm9
	vpmullw	%ymm7, %ymm9, %ymm7
	vpsllw	$8, %ymm8, %ymm8
	vpsraw	$12, %ymm8, %ymm8
	vpmullw	%ymm6, %ymm8, %ymm6
	vpmaddwd	%ymm4, %ymm7, %ymm7
	vpaddd	%ymm5, %ymm7, %ymm5
	vpmaddwd	%ymm4, %ymm6, %ymm6
	vpaddd	%ymm6, %ymm5, %ymm5
	leaq	16(%rcx), %rax
	addq	$32, %rcx
	cmpq	%rsi, %rcx
	movq	%rax, %rcx
	jbe	LBB1_16
LBB1_17:                                ##   in Loop: Header=BB1_5 Depth=1
	vextracti128	$1, %ymm5, %xmm6
	vpmovsxdq	%xmm6, %ymm6
	vpmovsxdq	%xmm5, %ymm5
	vpaddq	%ymm6, %ymm5, %ymm5
	vextracti128	$1, %ymm5, %xmm6
	vpaddq	%xmm6, %xmm5, %xmm5
	vpshufd	$238, %xmm5, %xmm6              ## xmm6 = xmm5[2,3,2,3]
	vpaddq	%xmm6, %xmm5, %xmm5
	vmovq	%xmm5, %rcx
	movq	%rsi, %r10
	subq	%rax, %r10
	jbe	LBB1_25
## %bb.18:                              ##   in Loop: Header=BB1_5 Depth=1
	cmpq	$8, %r10
	jae	LBB1_20
## %bb.19:                              ##   in Loop: Header=BB1_5 Depth=1
	movq	%rax, %r10
	jmp	LBB1_23
	.p2align	4, 0x90
LBB1_20:                                ##   in Loop: Header=BB1_5 Depth=1
	subq	%rdi, %r10
	addq	%rax, %r10
	vmovq	%rcx, %xmm5
	vpxor	%xmm6, %xmm6, %xmm6
	.p2align	4, 0x90
LBB1_21:                                ##   Parent Loop BB1_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovd	(%r9,%rax), %xmm7               ## xmm7 = mem[0],zero,zero,zero
	vmovd	4(%r9,%rax), %xmm8              ## xmm8 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm7, %xmm9
	vpand	%xmm0, %xmm9, %xmm9
	vpsrlw	$4, %xmm9, %xmm9
	vpxor	%xmm1, %xmm9, %xmm9
	vpsubb	%xmm1, %xmm9, %xmm9
	vpsllw	$4, %xmm8, %xmm10
	vpand	%xmm0, %xmm10, %xmm10
	vpsrlw	$4, %xmm10, %xmm10
	vpxor	%xmm1, %xmm10, %xmm10
	vpsubb	%xmm1, %xmm10, %xmm10
	vpsrlw	$4, %xmm7, %xmm7
	vpand	%xmm2, %xmm7, %xmm7
	vpxor	%xmm1, %xmm7, %xmm7
	vpsubb	%xmm1, %xmm7, %xmm7
	vpsrlw	$4, %xmm8, %xmm8
	vpand	%xmm2, %xmm8, %xmm8
	vpxor	%xmm1, %xmm8, %xmm8
	vpsubb	%xmm1, %xmm8, %xmm8
	vmovd	(%r12,%rax), %xmm11             ## xmm11 = mem[0],zero,zero,zero
	vmovd	4(%r12,%rax), %xmm12            ## xmm12 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm11, %xmm13
	vpand	%xmm0, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm1, %xmm13, %xmm13
	vpsubb	%xmm1, %xmm13, %xmm13
	vpsllw	$4, %xmm12, %xmm14
	vpand	%xmm0, %xmm14, %xmm14
	vpsrlw	$4, %xmm14, %xmm14
	vpxor	%xmm1, %xmm14, %xmm14
	vpsubb	%xmm1, %xmm14, %xmm14
	vpsrlw	$4, %xmm11, %xmm11
	vpand	%xmm2, %xmm11, %xmm11
	vpxor	%xmm1, %xmm11, %xmm11
	vpsubb	%xmm1, %xmm11, %xmm11
	vpsrlw	$4, %xmm12, %xmm12
	vpand	%xmm2, %xmm12, %xmm12
	vpxor	%xmm1, %xmm12, %xmm12
	vpsubb	%xmm1, %xmm12, %xmm12
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm13, %xmm13          ## xmm13 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmullw	%xmm9, %xmm13, %xmm9
	vpshufb	%xmm3, %xmm9, %xmm9
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmovzxbw	%xmm14, %xmm13          ## xmm13 = xmm14[0],zero,xmm14[1],zero,xmm14[2],zero,xmm14[3],zero,xmm14[4],zero,xmm14[5],zero,xmm14[6],zero,xmm14[7],zero
	vpmullw	%xmm10, %xmm13, %xmm10
	vpshufb	%xmm3, %xmm10, %xmm10
	vpmovsxbq	%xmm9, %ymm9
	vpmovsxbq	%xmm10, %ymm10
	vpmovzxbw	%xmm7, %xmm7            ## xmm7 = xmm7[0],zero,xmm7[1],zero,xmm7[2],zero,xmm7[3],zero,xmm7[4],zero,xmm7[5],zero,xmm7[6],zero,xmm7[7],zero
	vpmovzxbw	%xmm11, %xmm11          ## xmm11 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmullw	%xmm7, %xmm11, %xmm7
	vpshufb	%xmm3, %xmm7, %xmm7
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm12, %xmm11          ## xmm11 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmullw	%xmm8, %xmm11, %xmm8
	vpshufb	%xmm3, %xmm8, %xmm8
	vpmovsxbq	%xmm7, %ymm7
	vpaddq	%ymm7, %ymm5, %ymm5
	vpaddq	%ymm5, %ymm9, %ymm5
	vpmovsxbq	%xmm8, %ymm7
	vpaddq	%ymm7, %ymm6, %ymm6
	vpaddq	%ymm6, %ymm10, %ymm6
	addq	$8, %rax
	cmpq	%rax, %r8
	jne	LBB1_21
## %bb.22:                              ##   in Loop: Header=BB1_5 Depth=1
	vpaddq	%ymm5, %ymm6, %ymm5
	vextracti128	$1, %ymm5, %xmm6
	vpaddq	%xmm6, %xmm5, %xmm5
	vpshufd	$238, %xmm5, %xmm6              ## xmm6 = xmm5[2,3,2,3]
	vpaddq	%xmm6, %xmm5, %xmm5
	vmovq	%xmm5, %rcx
	testq	%rdi, %rdi
	je	LBB1_25
LBB1_23:                                ##   in Loop: Header=BB1_5 Depth=1
	movq	%rcx, %r11
	.p2align	4, 0x90
LBB1_24:                                ##   Parent Loop BB1_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r9,%r10), %ebx
	movl	%ebx, %edx
	shlb	$4, %dl
	sarb	$4, %dl
	movzbl	(%r12,%r10), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%dl
	movl	%eax, %edx
	sarb	$4, %bl
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%bl
	movsbq	%dl, %rdx
	movsbq	%al, %rcx
	addq	%r11, %rcx
	addq	%rdx, %rcx
	incq	%r10
	movq	%rcx, %r11
	cmpq	%r10, %rsi
	jne	LBB1_24
	jmp	LBB1_25
LBB1_26:
	testq	%rdx, %rdx
	je	LBB1_32
## %bb.27:
	vmovss	(%r12,%rsi), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	vmulss	%xmm0, %xmm0, %xmm2
	testq	%rax, %rax
	js	LBB1_28
## %bb.29:
	vcvtsi2ss	%rax, %xmm15, %xmm1
	jmp	LBB1_30
LBB1_7:
	xorl	%r13d, %r13d
	movq	%rdi, %r15
	movq	%r8, %rbx
	jmp	LBB1_8
	.p2align	4, 0x90
LBB1_13:                                ##   in Loop: Header=BB1_8 Depth=1
	movq	40(%r15), %rax
LBB1_14:                                ##   in Loop: Header=BB1_8 Depth=1
	movq	%rax, -80(%rbp)
	movq	%r12, %rdi
	movq	%r15, %rsi
	leaq	-88(%rbp), %rdx
	movq	%rbx, %r8
	callq	__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	addq	$2, %r13
	addq	$8, %rbx
	addq	$16, %r15
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %r14
	ja	LBB1_3
LBB1_8:                                 ## =>This Inner Loop Header: Depth=1
	leaq	4(%r13), %r14
	cmpq	%rdx, %r14
	jae	LBB1_9
## %bb.10:                              ##   in Loop: Header=BB1_8 Depth=1
	movq	32(%r15), %rax
	jmp	LBB1_11
	.p2align	4, 0x90
LBB1_9:                                 ##   in Loop: Header=BB1_8 Depth=1
	xorl	%eax, %eax
LBB1_11:                                ##   in Loop: Header=BB1_8 Depth=1
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	movq	%rax, -88(%rbp)
	leaq	5(%r13), %rax
	cmpq	%rdx, %rax
	jb	LBB1_13
## %bb.12:                              ##   in Loop: Header=BB1_8 Depth=1
	xorl	%eax, %eax
	jmp	LBB1_14
LBB1_28:
	andl	$1, %eax
	orq	%rsi, %rax
	vcvtsi2ss	%rax, %xmm15, %xmm1
	vaddss	%xmm1, %xmm1, %xmm1
LBB1_30:
	vmulss	12(%r12,%rsi), %xmm2, %xmm2
	vmovss	4(%r12,%rsi), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	vbroadcastss	LCPI1_5(%rip), %xmm4    ## xmm4 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	vxorps	%xmm4, %xmm0, %xmm4
	vmulss	8(%r12,%rsi), %xmm4, %xmm4
	xorl	%eax, %eax
	vmovss	LCPI1_6(%rip), %xmm5            ## xmm5 = mem[0],zero,zero,zero
	.p2align	4, 0x90
LBB1_31:                                ## =>This Inner Loop Header: Depth=1
	movq	(%r15,%rax,8), %rcx
	vmovss	(%rcx,%rsi), %xmm6              ## xmm6 = mem[0],zero,zero,zero
	vmovss	4(%rcx,%rsi), %xmm7             ## xmm7 = mem[0],zero,zero,zero
	vsubss	%xmm3, %xmm7, %xmm7
	vmulss	%xmm6, %xmm6, %xmm8
	vfmadd132ss	12(%rcx,%rsi), %xmm2, %xmm8 ## xmm8 = (xmm8 * mem) + xmm2
	vmulss	%xmm5, %xmm6, %xmm9
	vmulss	%xmm0, %xmm9, %xmm9
	vfmadd132ss	(%r14,%rax,4), %xmm8, %xmm9 ## xmm9 = (xmm9 * mem) + xmm8
	vmulss	%xmm7, %xmm7, %xmm8
	vfmadd213ss	%xmm9, %xmm1, %xmm8     ## xmm8 = (xmm1 * xmm8) + xmm9
	vaddss	%xmm7, %xmm7, %xmm7
	vfmadd132ss	8(%rcx,%rsi), %xmm4, %xmm6 ## xmm6 = (xmm6 * mem) + xmm4
	vfmadd213ss	%xmm8, %xmm7, %xmm6     ## xmm6 = (xmm7 * xmm6) + xmm8
	vmovss	%xmm6, (%r14,%rax,4)
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB1_31
LBB1_32:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
LCPI2_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI2_1:
	.space	16,240
LCPI2_2:
	.space	16,8
LCPI2_3:
	.space	16,15
LCPI2_4:
	.byte	0                               ## 0x0
	.byte	2                               ## 0x2
	.byte	4                               ## 0x4
	.byte	6                               ## 0x6
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.weak_def_can_be_hidden	__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.p2align	4, 0x90
__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf: ## @_ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %r9
	shrq	%r9
	cmpq	$32, %rcx
	jae	LBB2_2
## %bb.1:
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r11d, %r11d
	vpxor	%xmm1, %xmm1, %xmm1
	jmp	LBB2_7
LBB2_2:
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	LBB2_5
## %bb.3:
	movq	8(%rdx), %rcx
	movq	(%rsi), %rdx
	movq	8(%rsi), %r10
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r11d, %r11d
	vmovdqa	LCPI2_0(%rip), %ymm2            ## ymm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB2_4:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rbx
	vpmovzxbw	(%rdi,%r11), %ymm3      ## ymm3 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$8, %ymm3, %ymm4
	prefetcht0	(%rax,%r11)
	prefetcht0	(%rcx,%r11)
	vpsllw	$12, %ymm3, %ymm3
	vpsraw	$12, %ymm3, %ymm3
	vpsraw	$12, %ymm4, %ymm4
	vpmovzxbw	(%rdx,%r11), %ymm5      ## ymm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm5, %ymm6
	vpsraw	$12, %ymm6, %ymm6
	vpsllw	$8, %ymm5, %ymm5
	vpsraw	$12, %ymm5, %ymm5
	vpmullw	%ymm3, %ymm6, %ymm6
	vpmaddwd	%ymm2, %ymm6, %ymm6
	vpaddd	%ymm1, %ymm6, %ymm1
	vpmullw	%ymm4, %ymm5, %ymm5
	vpmaddwd	%ymm2, %ymm5, %ymm5
	vpaddd	%ymm5, %ymm1, %ymm1
	vpmovzxbw	(%r10,%r11), %ymm5      ## ymm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm5, %ymm6
	vpsraw	$12, %ymm6, %ymm6
	vpsllw	$8, %ymm5, %ymm5
	vpsraw	$12, %ymm5, %ymm5
	vpmullw	%ymm3, %ymm6, %ymm3
	vpmaddwd	%ymm2, %ymm3, %ymm3
	vpaddd	%ymm0, %ymm3, %ymm0
	vpmullw	%ymm4, %ymm5, %ymm3
	vpmaddwd	%ymm2, %ymm3, %ymm3
	vpaddd	%ymm3, %ymm0, %ymm0
	addq	$16, %r11
	addq	$32, %rbx
	cmpq	%r9, %rbx
	jbe	LBB2_4
	jmp	LBB2_7
LBB2_5:
	movq	(%rsi), %rax
	movq	8(%rsi), %rcx
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r11d, %r11d
	vmovdqa	LCPI2_0(%rip), %ymm2            ## ymm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB2_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rdx
	vpmovzxbw	(%rdi,%r11), %ymm3      ## ymm3 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm3, %ymm4
	vpsraw	$12, %ymm4, %ymm4
	vpsllw	$8, %ymm3, %ymm3
	vpsraw	$12, %ymm3, %ymm3
	vpmovzxbw	(%rax,%r11), %ymm5      ## ymm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm5, %ymm6
	vpsraw	$12, %ymm6, %ymm6
	vpsllw	$8, %ymm5, %ymm5
	vpsraw	$12, %ymm5, %ymm5
	vpmullw	%ymm4, %ymm6, %ymm6
	vpmaddwd	%ymm2, %ymm6, %ymm6
	vpaddd	%ymm1, %ymm6, %ymm1
	vpmullw	%ymm3, %ymm5, %ymm5
	vpmaddwd	%ymm2, %ymm5, %ymm5
	vpaddd	%ymm5, %ymm1, %ymm1
	vpmovzxbw	(%rcx,%r11), %ymm5      ## ymm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero
	vpsllw	$12, %ymm5, %ymm6
	vpsraw	$12, %ymm6, %ymm6
	vpsllw	$8, %ymm5, %ymm5
	vpsraw	$12, %ymm5, %ymm5
	vpmullw	%ymm4, %ymm6, %ymm4
	vpmaddwd	%ymm2, %ymm4, %ymm4
	vpaddd	%ymm0, %ymm4, %ymm0
	vpmullw	%ymm3, %ymm5, %ymm3
	vpmaddwd	%ymm2, %ymm3, %ymm3
	vpaddd	%ymm3, %ymm0, %ymm0
	addq	$16, %r11
	addq	$32, %rdx
	cmpq	%r9, %rdx
	jbe	LBB2_6
LBB2_7:
	movq	%r9, %r10
	subq	%r11, %r10
	jbe	LBB2_8
## %bb.9:
	movq	(%rsi), %rbx
	vmovq	%xmm1, %rax
	cltq
	vextracti128	$1, %ymm1, %xmm2
	vpalignr	$4, %xmm1, %xmm2, %xmm1         ## xmm1 = xmm1[4,5,6,7,8,9,10,11,12,13,14,15],xmm2[0,1,2,3]
	vpextrd	$3, %xmm2, %ecx
	vpmovsxdq	%xmm1, %ymm1
	movslq	%ecx, %rcx
	vextracti128	$1, %ymm1, %xmm3
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm3              ## xmm3 = xmm1[2,3,2,3]
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$233, %xmm2, %xmm2              ## xmm2 = xmm2[1,2,2,3]
	vpmovsxdq	%xmm2, %xmm2
	vmovq	%rcx, %xmm3
	vpunpcklqdq	%xmm3, %xmm1, %xmm1     ## xmm1 = xmm1[0],xmm3[0]
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %rcx
	addq	%rax, %rcx
	cmpq	$8, %r10
	jae	LBB2_11
## %bb.10:
	movq	%r11, %r14
	jmp	LBB2_14
LBB2_8:
	vmovq	%xmm1, %rax
	cltq
	vextracti128	$1, %ymm1, %xmm2
	vpalignr	$4, %xmm1, %xmm2, %xmm1         ## xmm1 = xmm1[4,5,6,7,8,9,10,11,12,13,14,15],xmm2[0,1,2,3]
	vpmovsxdq	%xmm1, %ymm1
	vpextrd	$3, %xmm2, %ecx
	movslq	%ecx, %rcx
	vextracti128	$1, %ymm1, %xmm3
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm3              ## xmm3 = xmm1[2,3,2,3]
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$233, %xmm2, %xmm2              ## xmm2 = xmm2[1,2,2,3]
	vpmovsxdq	%xmm2, %xmm2
	vmovq	%rcx, %xmm3
	vpunpcklqdq	%xmm3, %xmm1, %xmm1     ## xmm1 = xmm1[0],xmm3[0]
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %rcx
	addq	%rax, %rcx
	vcvtsi2ss	%rcx, %xmm7, %xmm1
	vmovss	%xmm1, (%r8)
	vmovq	%xmm0, %rax
	cltq
	vextracti128	$1, %ymm0, %xmm1
	vpalignr	$4, %xmm0, %xmm1, %xmm0         ## xmm0 = xmm0[4,5,6,7,8,9,10,11,12,13,14,15],xmm1[0,1,2,3]
	vpmovsxdq	%xmm0, %ymm0
	vpextrd	$3, %xmm1, %ecx
	movslq	%ecx, %rcx
	vextracti128	$1, %ymm0, %xmm2
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm2              ## xmm2 = xmm0[2,3,2,3]
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$233, %xmm1, %xmm1              ## xmm1 = xmm1[1,2,2,3]
	vpmovsxdq	%xmm1, %xmm1
	vmovq	%rcx, %xmm2
	vpunpcklqdq	%xmm2, %xmm0, %xmm0     ## xmm0 = xmm0[0],xmm2[0]
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rdx
	addq	%rax, %rdx
	jmp	LBB2_23
LBB2_11:
	movq	%r10, %rax
	andq	$-8, %rax
	leaq	(%r11,%rax), %r14
	vmovq	%rcx, %xmm1
	leaq	(%rbx,%r11), %rcx
	addq	$4, %rcx
	leaq	(%rdi,%r11), %rdx
	addq	$4, %rdx
	vpxor	%xmm2, %xmm2, %xmm2
	xorl	%r15d, %r15d
	vmovdqa	LCPI2_1(%rip), %xmm3            ## xmm3 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI2_2(%rip), %xmm4            ## xmm4 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI2_3(%rip), %xmm5            ## xmm5 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vmovdqa	LCPI2_4(%rip), %xmm6            ## xmm6 = <0,2,4,6,u,u,u,u,u,u,u,u,u,u,u,u>
	.p2align	4, 0x90
LBB2_12:                                ## =>This Inner Loop Header: Depth=1
	vmovd	-4(%rcx,%r15), %xmm7            ## xmm7 = mem[0],zero,zero,zero
	vmovd	(%rcx,%r15), %xmm8              ## xmm8 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm7, %xmm9
	vpand	%xmm3, %xmm9, %xmm9
	vpsrlw	$4, %xmm9, %xmm9
	vpxor	%xmm4, %xmm9, %xmm9
	vpsubb	%xmm4, %xmm9, %xmm9
	vpsllw	$4, %xmm8, %xmm10
	vpand	%xmm3, %xmm10, %xmm10
	vpsrlw	$4, %xmm10, %xmm10
	vpxor	%xmm4, %xmm10, %xmm10
	vpsubb	%xmm4, %xmm10, %xmm10
	vpsrlw	$4, %xmm7, %xmm7
	vpand	%xmm5, %xmm7, %xmm7
	vpxor	%xmm4, %xmm7, %xmm7
	vpsubb	%xmm4, %xmm7, %xmm7
	vpsrlw	$4, %xmm8, %xmm8
	vpand	%xmm5, %xmm8, %xmm8
	vpxor	%xmm4, %xmm8, %xmm8
	vpsubb	%xmm4, %xmm8, %xmm8
	vmovd	-4(%rdx,%r15), %xmm11           ## xmm11 = mem[0],zero,zero,zero
	vmovd	(%rdx,%r15), %xmm12             ## xmm12 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm11, %xmm13
	vpand	%xmm3, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm4, %xmm13, %xmm13
	vpsubb	%xmm4, %xmm13, %xmm13
	vpsllw	$4, %xmm12, %xmm14
	vpand	%xmm3, %xmm14, %xmm14
	vpsrlw	$4, %xmm14, %xmm14
	vpxor	%xmm4, %xmm14, %xmm14
	vpsubb	%xmm4, %xmm14, %xmm14
	vpsrlw	$4, %xmm11, %xmm11
	vpand	%xmm5, %xmm11, %xmm11
	vpxor	%xmm4, %xmm11, %xmm11
	vpsubb	%xmm4, %xmm11, %xmm11
	vpsrlw	$4, %xmm12, %xmm12
	vpand	%xmm5, %xmm12, %xmm12
	vpxor	%xmm4, %xmm12, %xmm12
	vpsubb	%xmm4, %xmm12, %xmm12
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm13, %xmm13          ## xmm13 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmullw	%xmm9, %xmm13, %xmm9
	vpshufb	%xmm6, %xmm9, %xmm9
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmovzxbw	%xmm14, %xmm13          ## xmm13 = xmm14[0],zero,xmm14[1],zero,xmm14[2],zero,xmm14[3],zero,xmm14[4],zero,xmm14[5],zero,xmm14[6],zero,xmm14[7],zero
	vpmullw	%xmm10, %xmm13, %xmm10
	vpshufb	%xmm6, %xmm10, %xmm10
	vpmovsxbq	%xmm9, %ymm9
	vpmovsxbq	%xmm10, %ymm10
	vpmovzxbw	%xmm7, %xmm7            ## xmm7 = xmm7[0],zero,xmm7[1],zero,xmm7[2],zero,xmm7[3],zero,xmm7[4],zero,xmm7[5],zero,xmm7[6],zero,xmm7[7],zero
	vpmovzxbw	%xmm11, %xmm11          ## xmm11 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmullw	%xmm7, %xmm11, %xmm7
	vpshufb	%xmm6, %xmm7, %xmm7
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm12, %xmm11          ## xmm11 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmullw	%xmm8, %xmm11, %xmm8
	vpshufb	%xmm6, %xmm8, %xmm8
	vpmovsxbq	%xmm7, %ymm7
	vpaddq	%ymm7, %ymm1, %ymm1
	vpaddq	%ymm1, %ymm9, %ymm1
	vpmovsxbq	%xmm8, %ymm7
	vpaddq	%ymm7, %ymm2, %ymm2
	vpaddq	%ymm2, %ymm10, %ymm2
	addq	$8, %r15
	cmpq	%r15, %rax
	jne	LBB2_12
## %bb.13:
	vpaddq	%ymm1, %ymm2, %ymm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %rcx
	cmpq	%rax, %r10
	je	LBB2_16
LBB2_14:
	movq	%rcx, %r15
	.p2align	4, 0x90
LBB2_15:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%r14), %r12d
	movl	%r12d, %edx
	shlb	$4, %dl
	sarb	$4, %dl
	movzbl	(%rdi,%r14), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%dl
	movl	%eax, %edx
	sarb	$4, %r12b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r12b
	movsbq	%dl, %rdx
	movsbq	%al, %rcx
	addq	%r15, %rcx
	addq	%rdx, %rcx
	incq	%r14
	movq	%rcx, %r15
	cmpq	%r14, %r9
	jne	LBB2_15
LBB2_16:
	vmovq	%xmm0, %rax
	cltq
	vextracti128	$1, %ymm0, %xmm1
	vpalignr	$4, %xmm0, %xmm1, %xmm0         ## xmm0 = xmm0[4,5,6,7,8,9,10,11,12,13,14,15],xmm1[0,1,2,3]
	vpmovsxdq	%xmm0, %ymm0
	vpextrd	$3, %xmm1, %edx
	movslq	%edx, %rdx
	vextracti128	$1, %ymm0, %xmm2
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm2              ## xmm2 = xmm0[2,3,2,3]
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$233, %xmm1, %xmm1              ## xmm1 = xmm1[1,2,2,3]
	vpmovsxdq	%xmm1, %xmm1
	vmovq	%rdx, %xmm2
	vpunpcklqdq	%xmm2, %xmm0, %xmm0     ## xmm0 = xmm0[0],xmm2[0]
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rdx
	vcvtsi2ss	%rcx, %xmm15, %xmm0
	addq	%rax, %rdx
	vmovss	%xmm0, (%r8)
	movq	8(%rsi), %rsi
	cmpq	$8, %r10
	jae	LBB2_18
## %bb.17:
	movq	%r11, %rbx
	jmp	LBB2_21
LBB2_18:
	movq	%r10, %rax
	andq	$-8, %rax
	leaq	(%r11,%rax), %rbx
	vmovq	%rdx, %xmm0
	leaq	(%rsi,%r11), %rcx
	addq	$4, %rcx
	leaq	(%rdi,%r11), %rdx
	addq	$4, %rdx
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%r11d, %r11d
	vmovdqa	LCPI2_1(%rip), %xmm2            ## xmm2 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI2_2(%rip), %xmm3            ## xmm3 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI2_3(%rip), %xmm4            ## xmm4 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vmovdqa	LCPI2_4(%rip), %xmm5            ## xmm5 = <0,2,4,6,u,u,u,u,u,u,u,u,u,u,u,u>
	.p2align	4, 0x90
LBB2_19:                                ## =>This Inner Loop Header: Depth=1
	vmovd	-4(%rcx,%r11), %xmm6            ## xmm6 = mem[0],zero,zero,zero
	vmovd	(%rcx,%r11), %xmm7              ## xmm7 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm6, %xmm8
	vpand	%xmm2, %xmm8, %xmm8
	vpsrlw	$4, %xmm8, %xmm8
	vpxor	%xmm3, %xmm8, %xmm8
	vpsubb	%xmm3, %xmm8, %xmm8
	vpsllw	$4, %xmm7, %xmm9
	vpand	%xmm2, %xmm9, %xmm9
	vpsrlw	$4, %xmm9, %xmm9
	vpxor	%xmm3, %xmm9, %xmm9
	vpsubb	%xmm3, %xmm9, %xmm9
	vpsrlw	$4, %xmm6, %xmm6
	vpand	%xmm4, %xmm6, %xmm6
	vpxor	%xmm3, %xmm6, %xmm6
	vpsubb	%xmm3, %xmm6, %xmm6
	vpsrlw	$4, %xmm7, %xmm7
	vpand	%xmm4, %xmm7, %xmm7
	vpxor	%xmm3, %xmm7, %xmm7
	vpsubb	%xmm3, %xmm7, %xmm7
	vmovd	-4(%rdx,%r11), %xmm10           ## xmm10 = mem[0],zero,zero,zero
	vmovd	(%rdx,%r11), %xmm11             ## xmm11 = mem[0],zero,zero,zero
	vpsllw	$4, %xmm10, %xmm12
	vpand	%xmm2, %xmm12, %xmm12
	vpsrlw	$4, %xmm12, %xmm12
	vpxor	%xmm3, %xmm12, %xmm12
	vpsubb	%xmm3, %xmm12, %xmm12
	vpsllw	$4, %xmm11, %xmm13
	vpand	%xmm2, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm3, %xmm13, %xmm13
	vpsubb	%xmm3, %xmm13, %xmm13
	vpsrlw	$4, %xmm10, %xmm10
	vpand	%xmm4, %xmm10, %xmm10
	vpxor	%xmm3, %xmm10, %xmm10
	vpsubb	%xmm3, %xmm10, %xmm10
	vpsrlw	$4, %xmm11, %xmm11
	vpand	%xmm4, %xmm11, %xmm11
	vpxor	%xmm3, %xmm11, %xmm11
	vpsubb	%xmm3, %xmm11, %xmm11
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm12, %xmm12          ## xmm12 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmullw	%xmm8, %xmm12, %xmm8
	vpshufb	%xmm5, %xmm8, %xmm8
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm13, %xmm12          ## xmm12 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmullw	%xmm9, %xmm12, %xmm9
	vpshufb	%xmm5, %xmm9, %xmm9
	vpmovsxbq	%xmm8, %ymm8
	vpmovsxbq	%xmm9, %ymm9
	vpmovzxbw	%xmm6, %xmm6            ## xmm6 = xmm6[0],zero,xmm6[1],zero,xmm6[2],zero,xmm6[3],zero,xmm6[4],zero,xmm6[5],zero,xmm6[6],zero,xmm6[7],zero
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmullw	%xmm6, %xmm10, %xmm6
	vpshufb	%xmm5, %xmm6, %xmm6
	vpmovzxbw	%xmm7, %xmm7            ## xmm7 = xmm7[0],zero,xmm7[1],zero,xmm7[2],zero,xmm7[3],zero,xmm7[4],zero,xmm7[5],zero,xmm7[6],zero,xmm7[7],zero
	vpmovzxbw	%xmm11, %xmm10          ## xmm10 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmullw	%xmm7, %xmm10, %xmm7
	vpshufb	%xmm5, %xmm7, %xmm7
	vpmovsxbq	%xmm6, %ymm6
	vpaddq	%ymm6, %ymm0, %ymm0
	vpaddq	%ymm0, %ymm8, %ymm0
	vpmovsxbq	%xmm7, %ymm6
	vpaddq	%ymm6, %ymm1, %ymm1
	vpaddq	%ymm1, %ymm9, %ymm1
	addq	$8, %r11
	cmpq	%r11, %rax
	jne	LBB2_19
## %bb.20:
	vpaddq	%ymm0, %ymm1, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rdx
	cmpq	%rax, %r10
	je	LBB2_23
LBB2_21:
	movq	%rdx, %r10
	.p2align	4, 0x90
LBB2_22:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rsi,%rbx), %r11d
	movl	%r11d, %edx
	shlb	$4, %dl
	sarb	$4, %dl
	movzbl	(%rdi,%rbx), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%dl
	movl	%eax, %edx
	sarb	$4, %r11b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r11b
	movsbq	%dl, %rcx
	movsbq	%al, %rdx
	addq	%r10, %rdx
	addq	%rcx, %rdx
	incq	%rbx
	movq	%rdx, %r10
	cmpq	%rbx, %r9
	jne	LBB2_22
LBB2_23:
	vcvtsi2ss	%rdx, %xmm15, %xmm0
	vmovss	%xmm0, 4(%r8)
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
