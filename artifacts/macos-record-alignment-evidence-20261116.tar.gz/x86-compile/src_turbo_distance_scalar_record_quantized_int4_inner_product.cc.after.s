	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo6scalar27inner_product_int4_distanceEPKvS3_mPf
LCPI0_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6scalar27inner_product_int4_distanceEPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo6scalar27inner_product_int4_distanceEPKvS3_mPf: ## @_ZN4zvec5turbo6scalar27inner_product_int4_distanceEPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpl	$33, %edx
	jl	LBB0_5
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	addl	$-32, %edx
	movq	%rdx, %r10
	shrq	%r10
	xorps	%xmm0, %xmm0
	cmpl	$2, %edx
	jb	LBB0_4
## %bb.2:
	xorps	%xmm0, %xmm0
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB0_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %ebx
	movl	%ebx, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %bl
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%bl
	movsbl	%r9b, %r8d
	movsbl	%al, %eax
	addl	%r8d, %eax
	xorps	%xmm1, %xmm1
	cvtsi2ss	%eax, %xmm1
	addss	%xmm1, %xmm0
	incq	%r11
	cmpq	%r11, %r10
	jne	LBB0_3
LBB0_4:
	movss	(%rdi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm4
	mulss	%xmm3, %xmm4
	mulss	%xmm2, %xmm3
	mulss	8(%rsi,%r10), %xmm3
	movss	4(%rsi,%r10), %xmm5             ## xmm5 = mem[0],zero,zero,zero
	mulss	%xmm5, %xmm1
	mulss	8(%rdi,%r10), %xmm1
	mulss	%xmm0, %xmm4
	xorps	%xmm0, %xmm0
	cvtsi2ss	%rdx, %xmm0
	addss	%xmm4, %xmm3
	addss	%xmm3, %xmm1
	mulss	%xmm5, %xmm0
	mulss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	xorps	LCPI0_0(%rip), %xmm0
	movss	%xmm0, (%rcx)
	popq	%rbx
	popq	%rbp
LBB0_5:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo6scalar33inner_product_int4_batch_distanceEPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6scalar33inner_product_int4_batch_distanceEPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo6scalar33inner_product_int4_batch_distanceEPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo6scalar33inner_product_int4_batch_distanceEPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdx, %rdx
	je	LBB1_9
## %bb.1:
	cmpl	$33, %ecx
	jl	LBB1_9
## %bb.2:
	addl	$-32, %ecx
	movq	%rcx, %r10
	shrq	%r10
	cvtsi2ss	%rcx, %xmm0
	cmpl	$2, %ecx
	jae	LBB1_3
## %bb.7:
	xorl	%eax, %eax
	xorps	%xmm1, %xmm1
	movaps	LCPI1_0(%rip), %xmm2            ## xmm2 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_8:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%rdi,%rax,8), %rcx
	movss	(%rcx,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movss	4(%rcx,%r10), %xmm4             ## xmm4 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	movss	4(%rsi,%r10), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	movaps	%xmm3, %xmm7
	mulss	%xmm5, %xmm7
	mulss	%xmm1, %xmm7
	mulss	%xmm4, %xmm5
	mulss	8(%rsi,%r10), %xmm5
	addss	%xmm7, %xmm5
	mulss	%xmm6, %xmm3
	mulss	8(%rcx,%r10), %xmm3
	addss	%xmm5, %xmm3
	mulss	%xmm0, %xmm6
	mulss	%xmm4, %xmm6
	addss	%xmm3, %xmm6
	xorps	%xmm2, %xmm6
	movss	%xmm6, (%r8,%rax,4)
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB1_8
	jmp	LBB1_9
LBB1_3:
	xorl	%r11d, %r11d
	movaps	LCPI1_0(%rip), %xmm1            ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_4:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_5 Depth 2
	movq	(%rdi,%r11,8), %rbx
	xorps	%xmm2, %xmm2
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB1_5:                                 ##   Parent Loop BB1_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r14), %r15d
	movl	%r15d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r14), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r15b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r15b
	movsbl	%r9b, %ecx
	movsbl	%al, %eax
	addl	%ecx, %eax
	xorps	%xmm3, %xmm3
	cvtsi2ss	%eax, %xmm3
	addss	%xmm3, %xmm2
	incq	%r14
	cmpq	%r14, %r10
	jne	LBB1_5
## %bb.6:                               ##   in Loop: Header=BB1_4 Depth=1
	movss	(%rbx,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movss	4(%rbx,%r10), %xmm4             ## xmm4 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	movss	4(%rsi,%r10), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	movaps	%xmm3, %xmm7
	mulss	%xmm5, %xmm7
	mulss	%xmm4, %xmm5
	mulss	8(%rsi,%r10), %xmm5
	mulss	%xmm2, %xmm7
	addss	%xmm5, %xmm7
	mulss	%xmm6, %xmm3
	mulss	8(%rbx,%r10), %xmm3
	addss	%xmm7, %xmm3
	mulss	%xmm0, %xmm6
	mulss	%xmm4, %xmm6
	addss	%xmm3, %xmm6
	xorps	%xmm1, %xmm6
	movss	%xmm6, (%r8,%r11,4)
	incq	%r11
	cmpq	%rdx, %r11
	jne	LBB1_4
LBB1_9:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
