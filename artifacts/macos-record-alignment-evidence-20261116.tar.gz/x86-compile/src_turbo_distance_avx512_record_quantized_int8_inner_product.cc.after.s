	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__const
	.p2align	6, 0x0                          ## -- Begin function _ZN4zvec5turbo6avx51234inner_product_int8_distance_avx512EPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI0_1:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6avx51234inner_product_int8_distance_avx512EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo6avx51234inner_product_int8_distance_avx512EPKvS3_mPf: ## @_ZN4zvec5turbo6avx51234inner_product_int8_distance_avx512EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$21, %rdx
	jb	LBB0_13
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	addq	$-20, %rdx
	vpxor	%xmm0, %xmm0, %xmm0
	cmpq	$32, %rdx
	jae	LBB0_3
## %bb.2:
	xorl	%r8d, %r8d
	jmp	LBB0_5
LBB0_3:
	xorl	%eax, %eax
	vmovdqa64	LCPI0_0(%rip), %zmm1    ## zmm1 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	vpmovsxbw	(%rdi,%rax), %zmm2
	vpmovsxbw	(%rsi,%rax), %zmm3
	vpmullw	%zmm2, %zmm3, %zmm2
	vpmaddwd	%zmm1, %zmm2, %zmm2
	vpaddd	%zmm0, %zmm2, %zmm0
	leaq	32(%rax), %r8
	addq	$64, %rax
	cmpq	%rdx, %rax
	movq	%r8, %rax
	jbe	LBB0_4
LBB0_5:
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %eax
	movslq	%eax, %r10
	movq	%rdx, %rax
	subq	%r8, %rax
	jbe	LBB0_12
## %bb.6:
	cmpq	$32, %rax
	jae	LBB0_8
## %bb.7:
	movq	%r8, %rax
	jmp	LBB0_11
LBB0_8:
	movl	%edx, %r9d
	andl	$31, %r9d
	subq	%r9, %rax
	addq	%r8, %rax
	vmovq	%r10, %xmm0
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	.p2align	4, 0x90
LBB0_9:                                 ## =>This Inner Loop Header: Depth=1
	vpmovsxbq	(%rdi,%r8), %zmm4
	vpmovsxbq	8(%rdi,%r8), %zmm5
	vpmovsxbq	16(%rdi,%r8), %zmm6
	vpmovsxbq	24(%rdi,%r8), %zmm7
	vpmovsxbq	(%rsi,%r8), %zmm8
	vpmuldq	%zmm4, %zmm8, %zmm4
	vpaddq	%zmm0, %zmm4, %zmm0
	vpmovsxbq	8(%rsi,%r8), %zmm4
	vpmuldq	%zmm5, %zmm4, %zmm4
	vpaddq	%zmm1, %zmm4, %zmm1
	vpmovsxbq	16(%rsi,%r8), %zmm4
	vpmuldq	%zmm6, %zmm4, %zmm4
	vpaddq	%zmm2, %zmm4, %zmm2
	vpmovsxbq	24(%rsi,%r8), %zmm4
	vpmuldq	%zmm7, %zmm4, %zmm4
	vpaddq	%zmm3, %zmm4, %zmm3
	addq	$32, %r8
	cmpq	%r8, %rax
	jne	LBB0_9
## %bb.10:
	vpaddq	%zmm0, %zmm1, %zmm0
	vpaddq	%zmm0, %zmm2, %zmm0
	vpaddq	%zmm0, %zmm3, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddq	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r10
	testq	%r9, %r9
	je	LBB0_12
	.p2align	4, 0x90
LBB0_11:                                ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%rax), %r8
	movsbq	(%rsi,%rax), %r9
	imulq	%r8, %r9
	addq	%r9, %r10
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB0_11
LBB0_12:
	vcvtsi2ss	%r10, %xmm9, %xmm0
	vmovss	(%rdi,%rdx), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vmovss	4(%rdi,%rdx), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vmovss	(%rsi,%rdx), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	vmovss	4(%rsi,%rdx), %xmm4             ## xmm4 = mem[0],zero,zero,zero
	vmulss	%xmm3, %xmm1, %xmm5
	vmulss	%xmm3, %xmm2, %xmm3
	vmulss	8(%rsi,%rdx), %xmm3, %xmm3
	vfmadd231ss	%xmm5, %xmm0, %xmm3     ## xmm3 = (xmm0 * xmm5) + xmm3
	vmulss	%xmm4, %xmm1, %xmm0
	vfmadd132ss	8(%rdi,%rdx), %xmm3, %xmm0 ## xmm0 = (xmm0 * mem) + xmm3
	vcvtusi2ss	%rdx, %xmm9, %xmm1
	vmulss	%xmm1, %xmm4, %xmm1
	vfmadd213ss	%xmm0, %xmm2, %xmm1     ## xmm1 = (xmm2 * xmm1) + xmm0
	vxorps	LCPI0_1(%rip){1to4}, %xmm1, %xmm0
	vmovss	%xmm0, (%rcx)
	popq	%rbp
LBB0_13:
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0                          ## -- Begin function _ZN4zvec5turbo6avx51240inner_product_int8_batch_distance_avx512EPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6avx51240inner_product_int8_batch_distance_avx512EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo6avx51240inner_product_int8_batch_distance_avx512EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo6avx51240inner_product_int8_batch_distance_avx512EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$21, %rcx
	jb	LBB1_4
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %r13
	movq	%rdx, %r14
	movq	%rdi, %r15
	leaq	-20(%rcx), %r12
	movq	%rsi, -48(%rbp)                 ## 8-byte Spill
	movq	-48(%rbp), %rsi                 ## 8-byte Reload
	movq	%r12, %rcx
	callq	__ZN4zvec5turbo6avx5128internal23raw_inner_product_batchEPKPKvPKammPf
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	testq	%r14, %r14
	je	LBB1_4
## %bb.2:
	vmovss	-20(%rax,%r13), %xmm0           ## xmm0 = mem[0],zero,zero,zero
	vmovss	-16(%rax,%r13), %xmm1           ## xmm1 = mem[0],zero,zero,zero
	vmovss	-12(%rax,%r13), %xmm2           ## xmm2 = mem[0],zero,zero,zero
	vcvtusi2ss	%r12, %xmm3, %xmm3
	vmulss	%xmm3, %xmm1, %xmm3
	xorl	%eax, %eax
	vbroadcastss	LCPI1_0(%rip), %xmm4    ## xmm4 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r15,%rax,8), %rcx
	vmovss	(%rcx,%r12), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	vmovss	4(%rcx,%r12), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	vmulss	%xmm5, %xmm0, %xmm7
	vmulss	%xmm6, %xmm0, %xmm8
	vmulss	%xmm8, %xmm2, %xmm8
	vfmadd231ss	(%rbx,%rax,4), %xmm7, %xmm8 ## xmm8 = (xmm7 * mem) + xmm8
	vmulss	%xmm5, %xmm1, %xmm5
	vfmadd132ss	8(%rcx,%r12), %xmm8, %xmm5 ## xmm5 = (xmm5 * mem) + xmm8
	vfmadd231ss	%xmm6, %xmm3, %xmm5     ## xmm5 = (xmm3 * xmm6) + xmm5
	vxorps	%xmm4, %xmm5, %xmm5
	vmovss	%xmm5, (%rbx,%rax,4)
	incq	%rax
	cmpq	%rax, %r14
	jne	LBB1_3
LBB1_4:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	6, 0x0                          ## -- Begin function _ZN4zvec5turbo6avx5128internal23raw_inner_product_batchEPKPKvPKammPf
LCPI2_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6avx5128internal23raw_inner_product_batchEPKPKvPKammPf
	.weak_def_can_be_hidden	__ZN4zvec5turbo6avx5128internal23raw_inner_product_batchEPKPKvPKammPf
	.p2align	4, 0x90
__ZN4zvec5turbo6avx5128internal23raw_inner_product_batchEPKPKvPKammPf: ## @_ZN4zvec5turbo6avx5128internal23raw_inner_product_batchEPKPKvPKammPf
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r8, %r13
	cmpq	$2, %rdx
	movq	%r8, -56(%rbp)                  ## 8-byte Spill
	movq	%rdx, -64(%rbp)                 ## 8-byte Spill
	jae	LBB2_35
## %bb.1:
	xorl	%r8d, %r8d
LBB2_2:
	cmpq	%rdx, %r8
	jae	LBB2_69
## %bb.3:
	cmpq	$32, %rcx
	jae	LBB2_4
## %bb.16:
	testq	%rcx, %rcx
	je	LBB2_34
## %bb.17:
	cmpq	$8, %rcx
	jb	LBB2_26
## %bb.18:
	movq	%rcx, %r9
	andq	$-8, %r9
	jmp	LBB2_19
	.p2align	4, 0x90
LBB2_33:                                ##   in Loop: Header=BB2_26 Depth=1
	vcvtsi2ss	%r9, %xmm12, %xmm0
	vmovss	%xmm0, (%r13,%r8,4)
	incq	%r8
	cmpq	%r8, %rdx
	je	LBB2_69
LBB2_26:                                ## =>This Inner Loop Header: Depth=1
	movq	(%rdi,%r8,8), %r10
	movsbq	(%r10), %rax
	movsbq	(%rsi), %r9
	imulq	%rax, %r9
	cmpq	$1, %rcx
	je	LBB2_33
## %bb.27:                              ##   in Loop: Header=BB2_26 Depth=1
	movsbq	1(%r10), %rax
	movsbq	1(%rsi), %r11
	imulq	%rax, %r11
	addq	%r11, %r9
	cmpq	$2, %rcx
	je	LBB2_33
## %bb.28:                              ##   in Loop: Header=BB2_26 Depth=1
	movsbq	2(%r10), %rax
	movsbq	2(%rsi), %r11
	imulq	%rax, %r11
	addq	%r11, %r9
	cmpq	$3, %rcx
	je	LBB2_33
## %bb.29:                              ##   in Loop: Header=BB2_26 Depth=1
	movsbq	3(%r10), %rax
	movsbq	3(%rsi), %r11
	imulq	%rax, %r11
	addq	%r11, %r9
	cmpq	$4, %rcx
	je	LBB2_33
## %bb.30:                              ##   in Loop: Header=BB2_26 Depth=1
	movsbq	4(%r10), %rax
	movsbq	4(%rsi), %r11
	imulq	%rax, %r11
	addq	%r11, %r9
	cmpq	$5, %rcx
	je	LBB2_33
## %bb.31:                              ##   in Loop: Header=BB2_26 Depth=1
	movsbq	5(%r10), %rax
	movsbq	5(%rsi), %r11
	imulq	%rax, %r11
	addq	%r11, %r9
	cmpq	$6, %rcx
	je	LBB2_33
## %bb.32:                              ##   in Loop: Header=BB2_26 Depth=1
	movsbq	6(%r10), %rax
	movsbq	6(%rsi), %r10
	imulq	%rax, %r10
	addq	%r10, %r9
	jmp	LBB2_33
	.p2align	4, 0x90
LBB2_25:                                ##   in Loop: Header=BB2_19 Depth=1
	vcvtsi2ss	%rax, %xmm12, %xmm0
	vmovss	%xmm0, (%r13,%r8,4)
	incq	%r8
	cmpq	%rdx, %r8
	je	LBB2_69
LBB2_19:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_24 Depth 2
	movq	(%rdi,%r8,8), %r10
	vpmovsxbq	(%r10), %zmm0
	vpmovsxbq	(%rsi), %zmm1
	vpmuldq	%zmm0, %zmm1, %zmm0
	cmpq	$8, %r9
	je	LBB2_22
## %bb.20:                              ##   in Loop: Header=BB2_19 Depth=1
	vpmovsxbq	8(%r10), %zmm1
	vpmovsxbq	8(%rsi), %zmm2
	vpmuldq	%zmm1, %zmm2, %zmm1
	vpaddq	%zmm0, %zmm1, %zmm0
	cmpq	$16, %r9
	je	LBB2_22
## %bb.21:                              ##   in Loop: Header=BB2_19 Depth=1
	vpmovsxbq	16(%r10), %zmm1
	vpmovsxbq	16(%rsi), %zmm2
	vpmuldq	%zmm1, %zmm2, %zmm1
	vpaddq	%zmm0, %zmm1, %zmm0
LBB2_22:                                ##   in Loop: Header=BB2_19 Depth=1
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddq	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rax
	cmpq	%rcx, %r9
	je	LBB2_25
## %bb.23:                              ##   in Loop: Header=BB2_19 Depth=1
	movq	%r9, %r11
	.p2align	4, 0x90
LBB2_24:                                ##   Parent Loop BB2_19 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r10,%r11), %rbx
	movsbq	(%rsi,%r11), %r14
	imulq	%rbx, %r14
	addq	%r14, %rax
	incq	%r11
	cmpq	%r11, %rcx
	jne	LBB2_24
	jmp	LBB2_25
LBB2_35:
	leaq	24(%rsi), %rax
	movq	%rax, -48(%rbp)                 ## 8-byte Spill
	movl	$2, %eax
	xorl	%r10d, %r10d
	vmovdqa64	LCPI2_0(%rip), %zmm0    ## zmm0 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	jmp	LBB2_36
	.p2align	4, 0x90
LBB2_42:                                ##   in Loop: Header=BB2_36 Depth=1
	vpaddd	%zmm4, %zmm3, %zmm3
	vextracti128	$1, %ymm3, %xmm4
	vpaddd	%xmm4, %xmm3, %xmm3
	vpshufd	$238, %xmm3, %xmm4              ## xmm4 = xmm3[2,3,2,3]
	vpaddd	%xmm4, %xmm3, %xmm3
	vpshufd	$85, %xmm3, %xmm4               ## xmm4 = xmm3[1,1,1,1]
	vpaddd	%xmm4, %xmm3, %xmm3
	vcvtdq2ps	%xmm3, %xmm3
	vmovd	%xmm3, (%r13,%r10,4)
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vcvtdq2ps	%xmm1, %xmm1
LBB2_56:                                ##   in Loop: Header=BB2_36 Depth=1
	vmovss	%xmm1, 4(%r13,%r10,4)
	leaq	2(%r8), %rax
	movq	%r8, %r10
	cmpq	%rdx, %rax
	ja	LBB2_2
LBB2_36:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_39 Depth 2
                                        ##     Child Loop BB2_40 Depth 2
                                        ##     Child Loop BB2_46 Depth 2
                                        ##     Child Loop BB2_48 Depth 2
                                        ##     Child Loop BB2_52 Depth 2
                                        ##     Child Loop BB2_54 Depth 2
	movq	%rax, %r8
	leaq	4(%r10), %rax
	cmpq	%rdx, %rax
	jae	LBB2_37
## %bb.57:                              ##   in Loop: Header=BB2_36 Depth=1
	movq	32(%rdi,%r10,8), %r15
	leaq	5(%r10), %rax
	cmpq	%rdx, %rax
	jb	LBB2_60
LBB2_59:                                ##   in Loop: Header=BB2_36 Depth=1
	xorl	%r12d, %r12d
	cmpq	$32, %rcx
	jb	LBB2_62
LBB2_38:                                ##   in Loop: Header=BB2_36 Depth=1
	movq	(%rdi,%r10,8), %rbx
	movq	8(%rdi,%r10,8), %r14
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%eax, %eax
	vpxor	%xmm3, %xmm3, %xmm3
	testq	%r15, %r15
	je	LBB2_40
	.p2align	4, 0x90
LBB2_39:                                ##   Parent Loop BB2_36 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovsxbw	(%rsi,%rax), %zmm2
	prefetcht0	(%r15,%rax)
	prefetcht0	(%r12,%rax)
	vpmovsxbw	(%rbx,%rax), %zmm4
	vpmullw	%zmm2, %zmm4, %zmm4
	vpmaddwd	%zmm0, %zmm4, %zmm4
	vpmovsxbw	(%r14,%rax), %zmm5
	vpaddd	%zmm3, %zmm4, %zmm3
	vpmullw	%zmm2, %zmm5, %zmm2
	vpmaddwd	%zmm0, %zmm2, %zmm2
	vpaddd	%zmm1, %zmm2, %zmm1
	leaq	32(%rax), %r11
	addq	$64, %rax
	cmpq	%rcx, %rax
	movq	%r11, %rax
	jbe	LBB2_39
	jmp	LBB2_41
	.p2align	4, 0x90
LBB2_40:                                ##   Parent Loop BB2_36 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovsxbw	(%rsi,%rax), %zmm2
	vpmovsxbw	(%rbx,%rax), %zmm4
	vpmullw	%zmm2, %zmm4, %zmm4
	vpmaddwd	%zmm0, %zmm4, %zmm4
	vpmovsxbw	(%r14,%rax), %zmm5
	vpaddd	%zmm3, %zmm4, %zmm3
	vpmullw	%zmm2, %zmm5, %zmm2
	vpmaddwd	%zmm0, %zmm2, %zmm2
	vpaddd	%zmm1, %zmm2, %zmm1
	leaq	32(%rax), %r11
	addq	$64, %rax
	cmpq	%rcx, %rax
	movq	%r11, %rax
	jbe	LBB2_40
	jmp	LBB2_41
	.p2align	4, 0x90
LBB2_37:                                ##   in Loop: Header=BB2_36 Depth=1
	xorl	%r15d, %r15d
	leaq	5(%r10), %rax
	cmpq	%rdx, %rax
	jae	LBB2_59
LBB2_60:                                ##   in Loop: Header=BB2_36 Depth=1
	movq	40(%rdi,%r10,8), %r12
	cmpq	$32, %rcx
	jae	LBB2_38
LBB2_62:                                ##   in Loop: Header=BB2_36 Depth=1
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm3, %xmm3, %xmm3
	xorl	%r11d, %r11d
LBB2_41:                                ##   in Loop: Header=BB2_36 Depth=1
	vextracti64x4	$1, %zmm3, %ymm4
	vextracti64x4	$1, %zmm1, %ymm2
	cmpq	%rcx, %r11
	jae	LBB2_42
## %bb.43:                              ##   in Loop: Header=BB2_36 Depth=1
	movq	(%rdi,%r10,8), %r14
	vpaddd	%zmm4, %zmm3, %zmm3
	vextracti128	$1, %ymm3, %xmm4
	vpaddd	%xmm4, %xmm3, %xmm3
	vpshufd	$238, %xmm3, %xmm4              ## xmm4 = xmm3[2,3,2,3]
	vpaddd	%xmm4, %xmm3, %xmm3
	vpshufd	$85, %xmm3, %xmm4               ## xmm4 = xmm3[1,1,1,1]
	vpaddd	%xmm4, %xmm3, %xmm3
	vmovd	%xmm3, %eax
	movslq	%eax, %r13
	movq	%rcx, %rbx
	subq	%r11, %rbx
	cmpq	$32, %rbx
	jae	LBB2_45
## %bb.44:                              ##   in Loop: Header=BB2_36 Depth=1
	movq	%r11, %r15
	jmp	LBB2_48
	.p2align	4, 0x90
LBB2_45:                                ##   in Loop: Header=BB2_36 Depth=1
	movq	%rbx, %r12
	andq	$-32, %r12
	leaq	(%r11,%r12), %r15
	vmovq	%r13, %xmm3
	leaq	(%r14,%r11), %r13
	addq	$24, %r13
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	leaq	(%rax,%r11), %r9
	vpxor	%xmm4, %xmm4, %xmm4
	xorl	%eax, %eax
	vpxor	%xmm5, %xmm5, %xmm5
	vpxor	%xmm6, %xmm6, %xmm6
	.p2align	4, 0x90
LBB2_46:                                ##   Parent Loop BB2_36 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovsxbq	-24(%r13,%rax), %zmm7
	vpmovsxbq	-16(%r13,%rax), %zmm8
	vpmovsxbq	-8(%r13,%rax), %zmm9
	vpmovsxbq	(%r13,%rax), %zmm10
	vpmovsxbq	-24(%r9,%rax), %zmm11
	vpmuldq	%zmm7, %zmm11, %zmm7
	vpaddq	%zmm3, %zmm7, %zmm3
	vpmovsxbq	-16(%r9,%rax), %zmm7
	vpmuldq	%zmm8, %zmm7, %zmm7
	vpaddq	%zmm4, %zmm7, %zmm4
	vpmovsxbq	-8(%r9,%rax), %zmm7
	vpmuldq	%zmm9, %zmm7, %zmm7
	vpaddq	%zmm5, %zmm7, %zmm5
	vpmovsxbq	(%r9,%rax), %zmm7
	vpmuldq	%zmm10, %zmm7, %zmm7
	vpaddq	%zmm6, %zmm7, %zmm6
	addq	$32, %rax
	cmpq	%rax, %r12
	jne	LBB2_46
## %bb.47:                              ##   in Loop: Header=BB2_36 Depth=1
	vpaddq	%zmm3, %zmm4, %zmm3
	vpaddq	%zmm3, %zmm5, %zmm3
	vpaddq	%zmm3, %zmm6, %zmm3
	vextracti64x4	$1, %zmm3, %ymm4
	vpaddq	%zmm4, %zmm3, %zmm3
	vextracti128	$1, %ymm3, %xmm4
	vpaddq	%xmm4, %xmm3, %xmm3
	vpshufd	$238, %xmm3, %xmm4              ## xmm4 = xmm3[2,3,2,3]
	vpaddq	%xmm4, %xmm3, %xmm3
	vmovq	%xmm3, %r13
	cmpq	%r12, %rbx
	je	LBB2_49
	.p2align	4, 0x90
LBB2_48:                                ##   Parent Loop BB2_36 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r14,%r15), %rax
	movsbq	(%rsi,%r15), %r9
	imulq	%rax, %r9
	addq	%r9, %r13
	incq	%r15
	cmpq	%r15, %rcx
	jne	LBB2_48
LBB2_49:                                ##   in Loop: Header=BB2_36 Depth=1
	vcvtsi2ss	%r13, %xmm12, %xmm3
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	vmovss	%xmm3, (%rax,%r10,4)
	movq	8(%rdi,%r10,8), %r14
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %eax
	movslq	%eax, %r13
	cmpq	$32, %rbx
	jae	LBB2_51
## %bb.50:                              ##   in Loop: Header=BB2_36 Depth=1
	movq	%r11, %r15
	jmp	LBB2_54
	.p2align	4, 0x90
LBB2_51:                                ##   in Loop: Header=BB2_36 Depth=1
	movq	%rbx, %r12
	andq	$-32, %r12
	leaq	(%r11,%r12), %r15
	vmovq	%r13, %xmm1
	leaq	(%r14,%r11), %r13
	addq	$24, %r13
	addq	-48(%rbp), %r11                 ## 8-byte Folded Reload
	vpxor	%xmm2, %xmm2, %xmm2
	xorl	%eax, %eax
	vxorps	%xmm3, %xmm3, %xmm3
	vpxor	%xmm4, %xmm4, %xmm4
	.p2align	4, 0x90
LBB2_52:                                ##   Parent Loop BB2_36 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovsxbq	-24(%r13,%rax), %zmm5
	vpmovsxbq	-16(%r13,%rax), %zmm6
	vpmovsxbq	-8(%r13,%rax), %zmm7
	vpmovsxbq	(%r13,%rax), %zmm8
	vpmovsxbq	-24(%r11,%rax), %zmm9
	vpmuldq	%zmm5, %zmm9, %zmm5
	vpaddq	%zmm1, %zmm5, %zmm1
	vpmovsxbq	-16(%r11,%rax), %zmm5
	vpmuldq	%zmm6, %zmm5, %zmm5
	vpaddq	%zmm2, %zmm5, %zmm2
	vpmovsxbq	-8(%r11,%rax), %zmm5
	vpmuldq	%zmm7, %zmm5, %zmm5
	vpaddq	%zmm3, %zmm5, %zmm3
	vpmovsxbq	(%r11,%rax), %zmm5
	vpmuldq	%zmm8, %zmm5, %zmm5
	vpaddq	%zmm4, %zmm5, %zmm4
	addq	$32, %rax
	cmpq	%rax, %r12
	jne	LBB2_52
## %bb.53:                              ##   in Loop: Header=BB2_36 Depth=1
	vpaddq	%zmm1, %zmm2, %zmm1
	vpaddq	%zmm1, %zmm3, %zmm1
	vpaddq	%zmm1, %zmm4, %zmm1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddq	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %r13
	cmpq	%r12, %rbx
	je	LBB2_55
	.p2align	4, 0x90
LBB2_54:                                ##   Parent Loop BB2_36 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r14,%r15), %rax
	movsbq	(%rsi,%r15), %r9
	imulq	%rax, %r9
	addq	%r9, %r13
	incq	%r15
	cmpq	%r15, %rcx
	jne	LBB2_54
LBB2_55:                                ##   in Loop: Header=BB2_36 Depth=1
	vcvtsi2ss	%r13, %xmm12, %xmm1
	movq	-56(%rbp), %r13                 ## 8-byte Reload
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	jmp	LBB2_56
LBB2_4:
	cmpq	$64, %rcx
	movl	$63, %r9d
	cmovaeq	%rcx, %r9
	andq	$-32, %r9
	movq	%rcx, %rax
	subq	%r9, %rax
	cmpq	$32, %rax
	jae	LBB2_5
## %bb.10:
	vmovdqa64	LCPI2_0(%rip), %zmm0    ## zmm0 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	jmp	LBB2_11
	.p2align	4, 0x90
LBB2_15:                                ##   in Loop: Header=BB2_11 Depth=1
	vcvtsi2ss	%rax, %xmm12, %xmm1
	vmovss	%xmm1, (%r13,%r8,4)
	incq	%r8
	cmpq	%rdx, %r8
	je	LBB2_69
LBB2_11:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_12 Depth 2
                                        ##     Child Loop BB2_14 Depth 2
	movq	(%rdi,%r8,8), %r9
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%r10d, %r10d
	.p2align	4, 0x90
LBB2_12:                                ##   Parent Loop BB2_11 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r10, %rax
	vpmovsxbw	(%rsi,%r10), %zmm2
	vpmovsxbw	(%r9,%r10), %zmm3
	vpmullw	%zmm2, %zmm3, %zmm2
	vpmaddwd	%zmm0, %zmm2, %zmm2
	vpaddd	%zmm1, %zmm2, %zmm1
	addq	$32, %r10
	addq	$64, %rax
	cmpq	%rcx, %rax
	jbe	LBB2_12
## %bb.13:                              ##   in Loop: Header=BB2_11 Depth=1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %eax
	cltq
	cmpq	%rcx, %r10
	jae	LBB2_15
	.p2align	4, 0x90
LBB2_14:                                ##   Parent Loop BB2_11 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r9,%r10), %r11
	movsbq	(%rsi,%r10), %rbx
	imulq	%r11, %rbx
	addq	%rbx, %rax
	incq	%r10
	cmpq	%r10, %rcx
	jne	LBB2_14
	jmp	LBB2_15
LBB2_5:
	movl	%ecx, %eax
	andl	$31, %eax
	movq	%rax, -72(%rbp)                 ## 8-byte Spill
	addq	%rax, %r9
	movl	$32, %r11d
	movq	%r9, -48(%rbp)                  ## 8-byte Spill
	subq	%r9, %r11
	leaq	(%rsi,%rcx), %rbx
	vmovdqa64	LCPI2_0(%rip), %zmm0    ## zmm0 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	jmp	LBB2_6
	.p2align	4, 0x90
LBB2_9:                                 ##   in Loop: Header=BB2_6 Depth=1
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
LBB2_68:                                ##   in Loop: Header=BB2_6 Depth=1
	vcvtsi2ss	%rax, %xmm12, %xmm1
	vmovss	%xmm1, (%r12,%r8,4)
	incq	%r8
	cmpq	%rdx, %r8
	je	LBB2_69
LBB2_6:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_7 Depth 2
                                        ##     Child Loop BB2_64 Depth 2
                                        ##     Child Loop BB2_67 Depth 2
	movq	(%rdi,%r8,8), %r14
	vpxor	%xmm1, %xmm1, %xmm1
	movl	$56, %eax
	movq	%r11, %r15
	xorl	%r9d, %r9d
	.p2align	4, 0x90
LBB2_7:                                 ##   Parent Loop BB2_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r9, %r13
	movq	%rax, %r12
	movq	%r15, %r10
	vpmovsxbw	(%rsi,%r9), %zmm2
	vpmovsxbw	(%r14,%r9), %zmm3
	vpmullw	%zmm2, %zmm3, %zmm2
	vpmaddwd	%zmm0, %zmm2, %zmm2
	vpaddd	%zmm1, %zmm2, %zmm1
	addq	$32, %r9
	addq	$64, %r13
	addq	$32, %rax
	addq	$32, %r15
	cmpq	%rcx, %r13
	jbe	LBB2_7
## %bb.8:                               ##   in Loop: Header=BB2_6 Depth=1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %eax
	cltq
	cmpq	%rcx, %r9
	jae	LBB2_9
## %bb.63:                              ##   in Loop: Header=BB2_6 Depth=1
	vmovq	%rax, %xmm1
	vpxor	%xmm2, %xmm2, %xmm2
	movq	-48(%rbp), %r13                 ## 8-byte Reload
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm4, %xmm4, %xmm4
	.p2align	4, 0x90
LBB2_64:                                ##   Parent Loop BB2_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovsxbq	-24(%r14,%r12), %zmm5
	vpmovsxbq	-16(%r14,%r12), %zmm6
	vpmovsxbq	-8(%r14,%r12), %zmm7
	vpmovsxbq	(%r14,%r12), %zmm8
	vpmovsxbq	-24(%rsi,%r12), %zmm9
	vpmuldq	%zmm5, %zmm9, %zmm5
	vpaddq	%zmm1, %zmm5, %zmm1
	vpmovsxbq	-16(%rsi,%r12), %zmm5
	vpmuldq	%zmm6, %zmm5, %zmm5
	vpaddq	%zmm2, %zmm5, %zmm2
	vpmovsxbq	-8(%rsi,%r12), %zmm5
	vpmuldq	%zmm7, %zmm5, %zmm5
	vpaddq	%zmm3, %zmm5, %zmm3
	vpmovsxbq	(%rsi,%r12), %zmm5
	vpmuldq	%zmm8, %zmm5, %zmm5
	vpaddq	%zmm4, %zmm5, %zmm4
	addq	$32, %r12
	addq	$32, %r13
	cmpq	%r13, %rcx
	jne	LBB2_64
## %bb.65:                              ##   in Loop: Header=BB2_6 Depth=1
	vpaddq	%zmm1, %zmm2, %zmm1
	vpaddq	%zmm1, %zmm3, %zmm1
	vpaddq	%zmm1, %zmm4, %zmm1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddq	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %rax
	cmpq	$0, -72(%rbp)                   ## 8-byte Folded Reload
	movq	-56(%rbp), %r12                 ## 8-byte Reload
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	je	LBB2_68
## %bb.66:                              ##   in Loop: Header=BB2_6 Depth=1
	addq	%rcx, %r14
	.p2align	4, 0x90
LBB2_67:                                ##   Parent Loop BB2_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r14,%r10), %r9
	movsbq	(%rbx,%r10), %r15
	imulq	%r9, %r15
	addq	%r15, %rax
	incq	%r10
	jne	LBB2_67
	jmp	LBB2_68
LBB2_69:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
LBB2_34:
	leaq	(,%r8,4), %rdi
	addq	%r13, %rdi
	subq	%r8, %rdx
	shlq	$2, %rdx
	movq	%rdx, %rsi
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	jmp	___bzero                        ## TAILCALL
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
