	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse232inner_product_int4_distance_sse2EPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
LCPI0_1:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse232inner_product_int4_distance_sse2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4sse232inner_product_int4_distance_sse2EPKvS3_mPf: ## @_ZN4zvec5turbo4sse232inner_product_int4_distance_sse2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$33, %rdx
	jb	LBB0_11
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	addq	$-32, %rdx
	movq	%rdx, %r10
	shrq	%r10
	pxor	%xmm0, %xmm0
	xorl	%r11d, %r11d
	cmpq	$32, %rdx
	jb	LBB0_4
## %bb.2:
	movdqa	LCPI0_0(%rip), %xmm1            ## xmm1 = [1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB0_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rax
	movdqu	(%rdi,%r11), %xmm5
	movdqa	%xmm5, %xmm2
	punpcklbw	%xmm5, %xmm3            ## xmm3 = xmm3[0],xmm5[0],xmm3[1],xmm5[1],xmm3[2],xmm5[2],xmm3[3],xmm5[3],xmm3[4],xmm5[4],xmm3[5],xmm5[5],xmm3[6],xmm5[6],xmm3[7],xmm5[7]
	punpckhbw	%xmm5, %xmm4            ## xmm4 = xmm4[8],xmm5[8],xmm4[9],xmm5[9],xmm4[10],xmm5[10],xmm4[11],xmm5[11],xmm4[12],xmm5[12],xmm4[13],xmm5[13],xmm4[14],xmm5[14],xmm4[15],xmm5[15]
	movdqa	%xmm5, %xmm6
	punpcklbw	%xmm6, %xmm6            ## xmm6 = xmm6[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm6
	psraw	$12, %xmm6
	movdqu	(%rsi,%r11), %xmm7
	movdqa	%xmm7, %xmm5
	punpcklbw	%xmm7, %xmm8            ## xmm8 = xmm8[0],xmm7[0],xmm8[1],xmm7[1],xmm8[2],xmm7[2],xmm8[3],xmm7[3],xmm8[4],xmm7[4],xmm8[5],xmm7[5],xmm8[6],xmm7[6],xmm8[7],xmm7[7]
	punpckhbw	%xmm7, %xmm9            ## xmm9 = xmm9[8],xmm7[8],xmm9[9],xmm7[9],xmm9[10],xmm7[10],xmm9[11],xmm7[11],xmm9[12],xmm7[12],xmm9[13],xmm7[13],xmm9[14],xmm7[14],xmm9[15],xmm7[15]
	punpcklbw	%xmm7, %xmm7            ## xmm7 = xmm7[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm7
	psraw	$12, %xmm7
	pmullw	%xmm6, %xmm7
	punpckhbw	%xmm2, %xmm2            ## xmm2 = xmm2[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm2
	psraw	$12, %xmm2
	psraw	$12, %xmm3
	psraw	$12, %xmm4
	punpckhbw	%xmm5, %xmm5            ## xmm5 = xmm5[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm5
	psraw	$12, %xmm5
	pmullw	%xmm2, %xmm5
	psraw	$12, %xmm8
	pmullw	%xmm3, %xmm8
	psraw	$12, %xmm9
	pmullw	%xmm4, %xmm9
	pmaddwd	%xmm1, %xmm7
	paddd	%xmm0, %xmm7
	pmaddwd	%xmm1, %xmm5
	pmaddwd	%xmm1, %xmm8
	paddd	%xmm5, %xmm8
	paddd	%xmm7, %xmm8
	pmaddwd	%xmm1, %xmm9
	movdqa	%xmm9, %xmm0
	paddd	%xmm8, %xmm0
	addq	$16, %r11
	addq	$32, %rax
	cmpq	%r10, %rax
	jbe	LBB0_3
LBB0_4:
	movq	%xmm0, %rax
	cltq
	pshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	movd	%xmm1, %r8d
	movslq	%r8d, %r8
	addq	%rax, %r8
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	movd	%xmm1, %eax
	cltq
	addq	%r8, %rax
	pshufd	$255, %xmm0, %xmm0              ## xmm0 = xmm0[3,3,3,3]
	movd	%xmm0, %r8d
	movslq	%r8d, %rbx
	addq	%rax, %rbx
	cmpq	%r10, %r11
	jae	LBB0_5
	.p2align	4, 0x90
LBB0_6:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %r14d
	movl	%r14d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r14b
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%r14b
	movsbq	%r9b, %r8
	movsbq	%al, %rax
	addq	%rbx, %rax
	addq	%r8, %rax
	incq	%r11
	movq	%rax, %rbx
	cmpq	%r11, %r10
	jne	LBB0_6
	jmp	LBB0_7
LBB0_5:
	movq	%rbx, %rax
LBB0_7:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	movss	(%rdi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%rsi,%r10), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm5
	mulss	%xmm4, %xmm5
	mulss	%xmm3, %xmm5
	mulss	%xmm2, %xmm4
	mulss	8(%rsi,%r10), %xmm4
	addss	%xmm5, %xmm4
	mulss	%xmm0, %xmm1
	mulss	8(%rdi,%r10), %xmm1
	addss	%xmm4, %xmm1
	testq	%rdx, %rdx
	js	LBB0_8
## %bb.9:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rdx, %xmm3
	jmp	LBB0_10
LBB0_8:
	andl	$1, %edx
	orq	%r10, %rdx
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rdx, %xmm3
	addss	%xmm3, %xmm3
LBB0_10:
	mulss	%xmm3, %xmm0
	mulss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	xorps	LCPI0_1(%rip), %xmm0
	movss	%xmm0, (%rcx)
	popq	%rbx
	popq	%r14
	popq	%rbp
LBB0_11:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse238inner_product_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse238inner_product_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4sse238inner_product_int4_batch_distance_sse2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4sse238inner_product_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$33, %rcx
	jb	LBB1_7
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %r13
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	addq	$-32, %r13
	movq	%r13, %rcx
	callq	__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKhmmPf
	testq	%r14, %r14
	je	LBB1_7
## %bb.2:
	movq	%r13, %rax
	shrq	%rax
	testq	%r13, %r13
	js	LBB1_3
## %bb.4:
	cvtsi2ss	%r13, %xmm0
	jmp	LBB1_5
LBB1_3:
	andl	$1, %r13d
	orq	%rax, %r13
	cvtsi2ss	%r13, %xmm0
	addss	%xmm0, %xmm0
LBB1_5:
	xorl	%ecx, %ecx
	movaps	LCPI1_0(%rip), %xmm1            ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r12,%rcx,8), %rdx
	movss	(%rdx,%rax), %xmm2              ## xmm2 = mem[0],zero,zero,zero
	movss	4(%rdx,%rax), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	movss	(%r15,%rax), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%r15,%rax), %xmm5             ## xmm5 = mem[0],zero,zero,zero
	movaps	%xmm2, %xmm6
	mulss	%xmm4, %xmm6
	mulss	%xmm3, %xmm4
	mulss	8(%r15,%rax), %xmm4
	mulss	(%rbx,%rcx,4), %xmm6
	addss	%xmm4, %xmm6
	mulss	%xmm5, %xmm2
	mulss	8(%rdx,%rax), %xmm2
	addss	%xmm6, %xmm2
	mulss	%xmm0, %xmm5
	mulss	%xmm3, %xmm5
	addss	%xmm2, %xmm5
	xorps	%xmm1, %xmm5
	movss	%xmm5, (%rbx,%rcx,4)
	incq	%rcx
	cmpq	%rcx, %r14
	jne	LBB1_6
LBB1_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKhmmPf
LCPI2_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4, 0x90
__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKhmmPf: ## @_ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKhmmPf
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, -48(%rbp)                 ## 8-byte Spill
	cmpq	$2, %rdx
	jae	LBB2_13
## %bb.1:
	xorl	%edi, %edi
LBB2_2:
	cmpq	%rdx, %rdi
	jae	LBB2_36
## %bb.3:
	movq	%rcx, %r10
	shrq	%r10
	cmpq	$32, %rcx
	jae	LBB2_4
## %bb.9:
	cmpq	$2, %rcx
	jae	LBB2_10
## %bb.37:
	leaq	(%r8,%rdi,4), %rax
	subq	%rdi, %rdx
	shlq	$2, %rdx
	movq	%rax, %rdi
	movq	%rdx, %rsi
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	___bzero                        ## TAILCALL
	.p2align	4, 0x90
LBB2_10:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_11 Depth 2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	(%rax,%rdi,8), %rbx
	xorl	%r15d, %r15d
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB2_11:                                ##   Parent Loop BB2_10 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r15), %r11d
	movl	%r11d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r15), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r11b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r11b
	movsbq	%r9b, %rcx
	movsbq	%al, %rax
	addq	%rax, %r14
	addq	%rcx, %r14
	incq	%r15
	cmpq	%r15, %r10
	jne	LBB2_11
## %bb.12:                              ##   in Loop: Header=BB2_10 Depth=1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%r14, %xmm0
	movss	%xmm0, (%r8,%rdi,4)
	incq	%rdi
	cmpq	%rdx, %rdi
	jne	LBB2_10
LBB2_36:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB2_13:
	movq	%rcx, %rbx
	shrq	%rbx
	movl	$2, %eax
	xorl	%r14d, %r14d
	movdqa	LCPI2_0(%rip), %xmm0            ## xmm0 = [1,1,1,1,1,1,1,1]
	movq	%rdx, -64(%rbp)                 ## 8-byte Spill
	movq	%r8, -56(%rbp)                  ## 8-byte Spill
	jmp	LBB2_14
	.p2align	4, 0x90
LBB2_18:                                ##   in Loop: Header=BB2_14 Depth=1
	movq	%xmm2, %rax
	cltq
	pshufd	$85, %xmm2, %xmm3               ## xmm3 = xmm2[1,1,1,1]
	movd	%xmm3, %r9d
	movslq	%r9d, %r9
	addq	%rax, %r9
	pshufd	$238, %xmm2, %xmm3              ## xmm3 = xmm2[2,3,2,3]
	movd	%xmm3, %eax
	cltq
	addq	%r9, %rax
	pshufd	$255, %xmm2, %xmm2              ## xmm2 = xmm2[3,3,3,3]
	movd	%xmm2, %r9d
	movslq	%r9d, %r9
	addq	%rax, %r9
	xorps	%xmm2, %xmm2
	cvtsi2ss	%r9, %xmm2
	movss	%xmm2, (%r8,%r14,4)
	movq	%xmm1, %rax
	cltq
	pshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	movd	%xmm2, %r9d
	movslq	%r9d, %r9
	addq	%rax, %r9
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	movd	%xmm2, %eax
	movslq	%eax, %r10
	addq	%r9, %r10
	pshufd	$255, %xmm1, %xmm1              ## xmm1 = xmm1[3,3,3,3]
	movd	%xmm1, %eax
	cltq
	addq	%r10, %rax
LBB2_19:                                ##   in Loop: Header=BB2_14 Depth=1
	xorps	%xmm1, %xmm1
	cvtsi2ss	%rax, %xmm1
	movss	%xmm1, 4(%r8,%r14,4)
	leaq	2(%rdi), %rax
	movq	%rdi, %r14
	cmpq	%rdx, %rax
	ja	LBB2_2
LBB2_14:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_25 Depth 2
                                        ##     Child Loop BB2_21 Depth 2
                                        ##     Child Loop BB2_23 Depth 2
	movq	%rax, %rdi
	leaq	4(%r14), %rax
	cmpq	%rdx, %rax
	jae	LBB2_15
## %bb.28:                              ##   in Loop: Header=BB2_14 Depth=1
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	32(%rax,%r14,8), %rax
	leaq	5(%r14), %r9
	cmpq	%rdx, %r9
	jb	LBB2_31
LBB2_30:                                ##   in Loop: Header=BB2_14 Depth=1
	xorl	%r9d, %r9d
	cmpq	$32, %rcx
	jb	LBB2_33
LBB2_24:                                ##   in Loop: Header=BB2_14 Depth=1
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	movq	(%rdx,%r14,8), %r10
	movq	8(%rdx,%r14,8), %r12
	pxor	%xmm1, %xmm1
	xorl	%r13d, %r13d
	pxor	%xmm2, %xmm2
	jmp	LBB2_25
	.p2align	4, 0x90
LBB2_27:                                ##   in Loop: Header=BB2_25 Depth=2
	movdqu	(%r10,%r13), %xmm7
	movdqa	%xmm7, %xmm8
	punpcklbw	%xmm7, %xmm9            ## xmm9 = xmm9[0],xmm7[0],xmm9[1],xmm7[1],xmm9[2],xmm7[2],xmm9[3],xmm7[3],xmm9[4],xmm7[4],xmm9[5],xmm7[5],xmm9[6],xmm7[6],xmm9[7],xmm7[7]
	punpckhbw	%xmm7, %xmm10           ## xmm10 = xmm10[8],xmm7[8],xmm10[9],xmm7[9],xmm10[10],xmm7[10],xmm10[11],xmm7[11],xmm10[12],xmm7[12],xmm10[13],xmm7[13],xmm10[14],xmm7[14],xmm10[15],xmm7[15]
	punpcklbw	%xmm7, %xmm7            ## xmm7 = xmm7[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	punpckhbw	%xmm8, %xmm8            ## xmm8 = xmm8[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm7
	psraw	$12, %xmm7
	psllw	$12, %xmm8
	psraw	$12, %xmm8
	psraw	$12, %xmm9
	psraw	$12, %xmm10
	pmullw	%xmm6, %xmm7
	pmaddwd	%xmm0, %xmm7
	paddd	%xmm7, %xmm2
	pmullw	%xmm3, %xmm8
	pmaddwd	%xmm0, %xmm8
	pmullw	%xmm5, %xmm9
	pmaddwd	%xmm0, %xmm9
	paddd	%xmm8, %xmm9
	paddd	%xmm2, %xmm9
	pmullw	%xmm4, %xmm10
	pmaddwd	%xmm0, %xmm10
	movdqa	%xmm10, %xmm2
	paddd	%xmm9, %xmm2
	movdqu	(%r12,%r13), %xmm7
	movdqa	%xmm7, %xmm8
	punpcklbw	%xmm7, %xmm9            ## xmm9 = xmm9[0],xmm7[0],xmm9[1],xmm7[1],xmm9[2],xmm7[2],xmm9[3],xmm7[3],xmm9[4],xmm7[4],xmm9[5],xmm7[5],xmm9[6],xmm7[6],xmm9[7],xmm7[7]
	punpckhbw	%xmm7, %xmm10           ## xmm10 = xmm10[8],xmm7[8],xmm10[9],xmm7[9],xmm10[10],xmm7[10],xmm10[11],xmm7[11],xmm10[12],xmm7[12],xmm10[13],xmm7[13],xmm10[14],xmm7[14],xmm10[15],xmm7[15]
	punpcklbw	%xmm7, %xmm7            ## xmm7 = xmm7[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	punpckhbw	%xmm8, %xmm8            ## xmm8 = xmm8[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm7
	psraw	$12, %xmm7
	psllw	$12, %xmm8
	psraw	$12, %xmm8
	psraw	$12, %xmm9
	psraw	$12, %xmm10
	pmullw	%xmm6, %xmm7
	pmaddwd	%xmm0, %xmm7
	paddd	%xmm7, %xmm1
	pmullw	%xmm3, %xmm8
	pmaddwd	%xmm0, %xmm8
	pmullw	%xmm5, %xmm9
	pmaddwd	%xmm0, %xmm9
	paddd	%xmm8, %xmm9
	paddd	%xmm1, %xmm9
	pmullw	%xmm4, %xmm10
	pmaddwd	%xmm0, %xmm10
	movdqa	%xmm10, %xmm1
	paddd	%xmm9, %xmm1
	leaq	16(%r13), %r11
	addq	$32, %r13
	cmpq	%rbx, %r13
	movq	%r11, %r13
	ja	LBB2_16
LBB2_25:                                ##   Parent Loop BB2_14 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movdqu	(%rsi,%r13), %xmm6
	movdqa	%xmm6, %xmm3
	punpcklbw	%xmm6, %xmm5            ## xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1],xmm5[2],xmm6[2],xmm5[3],xmm6[3],xmm5[4],xmm6[4],xmm5[5],xmm6[5],xmm5[6],xmm6[6],xmm5[7],xmm6[7]
	punpckhbw	%xmm6, %xmm4            ## xmm4 = xmm4[8],xmm6[8],xmm4[9],xmm6[9],xmm4[10],xmm6[10],xmm4[11],xmm6[11],xmm4[12],xmm6[12],xmm4[13],xmm6[13],xmm4[14],xmm6[14],xmm4[15],xmm6[15]
	punpcklbw	%xmm6, %xmm6            ## xmm6 = xmm6[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	punpckhbw	%xmm3, %xmm3            ## xmm3 = xmm3[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm6
	psraw	$12, %xmm6
	psllw	$12, %xmm3
	psraw	$12, %xmm3
	psraw	$12, %xmm5
	psraw	$12, %xmm4
	testq	%rax, %rax
	je	LBB2_27
## %bb.26:                              ##   in Loop: Header=BB2_25 Depth=2
	prefetcht0	(%rax,%r13)
	prefetcht0	(%r9,%r13)
	jmp	LBB2_27
	.p2align	4, 0x90
LBB2_15:                                ##   in Loop: Header=BB2_14 Depth=1
	xorl	%eax, %eax
	leaq	5(%r14), %r9
	cmpq	%rdx, %r9
	jae	LBB2_30
LBB2_31:                                ##   in Loop: Header=BB2_14 Depth=1
	movq	-48(%rbp), %r9                  ## 8-byte Reload
	movq	40(%r9,%r14,8), %r9
	cmpq	$32, %rcx
	jae	LBB2_24
LBB2_33:                                ##   in Loop: Header=BB2_14 Depth=1
	pxor	%xmm1, %xmm1
	pxor	%xmm2, %xmm2
	xorl	%r11d, %r11d
	cmpq	%rbx, %r11
	jae	LBB2_18
	jmp	LBB2_20
	.p2align	4, 0x90
LBB2_16:                                ##   in Loop: Header=BB2_14 Depth=1
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	cmpq	%rbx, %r11
	jae	LBB2_18
LBB2_20:                                ##   in Loop: Header=BB2_14 Depth=1
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	(%rax,%r14,8), %r12
	movq	%xmm2, %rax
	cltq
	pshufd	$85, %xmm2, %xmm3               ## xmm3 = xmm2[1,1,1,1]
	movd	%xmm3, %r9d
	movslq	%r9d, %r9
	addq	%rax, %r9
	pshufd	$238, %xmm2, %xmm3              ## xmm3 = xmm2[2,3,2,3]
	movd	%xmm3, %eax
	cltq
	addq	%r9, %rax
	pshufd	$255, %xmm2, %xmm2              ## xmm2 = xmm2[3,3,3,3]
	movd	%xmm2, %r9d
	movslq	%r9d, %r13
	addq	%rax, %r13
	movq	%r11, %r15
	.p2align	4, 0x90
LBB2_21:                                ##   Parent Loop BB2_14 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r12,%r15), %r8d
	movl	%r8d, %r10d
	shlb	$4, %r10b
	sarb	$4, %r10b
	movzbl	(%rsi,%r15), %r9d
	movl	%r9d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r10b
	movl	%eax, %r10d
	sarb	$4, %r8b
	sarb	$4, %r9b
	movl	%r9d, %eax
	mulb	%r8b
	movsbq	%r10b, %r8
	movsbq	%al, %rax
	addq	%rax, %r13
	addq	%r8, %r13
	incq	%r15
	cmpq	%r15, %rbx
	jne	LBB2_21
## %bb.22:                              ##   in Loop: Header=BB2_14 Depth=1
	xorps	%xmm2, %xmm2
	cvtsi2ss	%r13, %xmm2
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	movss	%xmm2, (%r8,%r14,4)
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	8(%rax,%r14,8), %r12
	movq	%xmm1, %rax
	cltq
	pshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	movd	%xmm2, %edx
	movslq	%edx, %rdx
	addq	%rax, %rdx
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	movd	%xmm2, %eax
	cltq
	addq	%rdx, %rax
	pshufd	$255, %xmm1, %xmm1              ## xmm1 = xmm1[3,3,3,3]
	movd	%xmm1, %edx
	movslq	%edx, %r15
	addq	%rax, %r15
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	.p2align	4, 0x90
LBB2_23:                                ##   Parent Loop BB2_14 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r12,%r11), %r13d
	movl	%r13d, %r10d
	shlb	$4, %r10b
	sarb	$4, %r10b
	movzbl	(%rsi,%r11), %r9d
	movl	%r9d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r10b
	movl	%eax, %r10d
	sarb	$4, %r13b
	sarb	$4, %r9b
	movl	%r9d, %eax
	mulb	%r13b
	movsbq	%r10b, %r9
	movsbq	%al, %rax
	addq	%r15, %rax
	addq	%r9, %rax
	incq	%r11
	movq	%rax, %r15
	cmpq	%r11, %rbx
	jne	LBB2_23
	jmp	LBB2_19
LBB2_4:
	movdqa	LCPI2_0(%rip), %xmm0            ## xmm0 = [1,1,1,1,1,1,1,1]
	jmp	LBB2_5
	.p2align	4, 0x90
LBB2_8:                                 ##   in Loop: Header=BB2_5 Depth=1
	movq	%r15, %rax
LBB2_35:                                ##   in Loop: Header=BB2_5 Depth=1
	xorps	%xmm1, %xmm1
	cvtsi2ss	%rax, %xmm1
	movss	%xmm1, (%r8,%rdi,4)
	incq	%rdi
	cmpq	%rdx, %rdi
	je	LBB2_36
LBB2_5:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_6 Depth 2
                                        ##     Child Loop BB2_34 Depth 2
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movq	(%rax,%rdi,8), %rbx
	xorps	%xmm1, %xmm1
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB2_6:                                 ##   Parent Loop BB2_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r14, %rax
	movdqu	(%rsi,%r14), %xmm5
	movdqa	%xmm5, %xmm2
	punpcklbw	%xmm5, %xmm3            ## xmm3 = xmm3[0],xmm5[0],xmm3[1],xmm5[1],xmm3[2],xmm5[2],xmm3[3],xmm5[3],xmm3[4],xmm5[4],xmm3[5],xmm5[5],xmm3[6],xmm5[6],xmm3[7],xmm5[7]
	punpckhbw	%xmm5, %xmm4            ## xmm4 = xmm4[8],xmm5[8],xmm4[9],xmm5[9],xmm4[10],xmm5[10],xmm4[11],xmm5[11],xmm4[12],xmm5[12],xmm4[13],xmm5[13],xmm4[14],xmm5[14],xmm4[15],xmm5[15]
	movdqa	%xmm5, %xmm6
	punpcklbw	%xmm6, %xmm6            ## xmm6 = xmm6[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm6
	psraw	$12, %xmm6
	movdqu	(%rbx,%r14), %xmm7
	movdqa	%xmm7, %xmm5
	punpcklbw	%xmm7, %xmm8            ## xmm8 = xmm8[0],xmm7[0],xmm8[1],xmm7[1],xmm8[2],xmm7[2],xmm8[3],xmm7[3],xmm8[4],xmm7[4],xmm8[5],xmm7[5],xmm8[6],xmm7[6],xmm8[7],xmm7[7]
	punpckhbw	%xmm7, %xmm9            ## xmm9 = xmm9[8],xmm7[8],xmm9[9],xmm7[9],xmm9[10],xmm7[10],xmm9[11],xmm7[11],xmm9[12],xmm7[12],xmm9[13],xmm7[13],xmm9[14],xmm7[14],xmm9[15],xmm7[15]
	punpcklbw	%xmm7, %xmm7            ## xmm7 = xmm7[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm7
	psraw	$12, %xmm7
	pmullw	%xmm6, %xmm7
	punpckhbw	%xmm2, %xmm2            ## xmm2 = xmm2[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm2
	psraw	$12, %xmm2
	psraw	$12, %xmm3
	psraw	$12, %xmm4
	punpckhbw	%xmm5, %xmm5            ## xmm5 = xmm5[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm5
	psraw	$12, %xmm5
	pmullw	%xmm2, %xmm5
	psraw	$12, %xmm8
	pmullw	%xmm3, %xmm8
	psraw	$12, %xmm9
	pmullw	%xmm4, %xmm9
	pmaddwd	%xmm0, %xmm7
	paddd	%xmm1, %xmm7
	pmaddwd	%xmm0, %xmm5
	pmaddwd	%xmm0, %xmm8
	paddd	%xmm5, %xmm8
	paddd	%xmm7, %xmm8
	pmaddwd	%xmm0, %xmm9
	movdqa	%xmm9, %xmm1
	paddd	%xmm8, %xmm1
	addq	$16, %r14
	addq	$32, %rax
	cmpq	%r10, %rax
	jbe	LBB2_6
## %bb.7:                               ##   in Loop: Header=BB2_5 Depth=1
	movq	%xmm1, %rax
	cltq
	pshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	movd	%xmm2, %ecx
	movslq	%ecx, %rcx
	addq	%rax, %rcx
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	movd	%xmm2, %eax
	cltq
	addq	%rcx, %rax
	pshufd	$255, %xmm1, %xmm1              ## xmm1 = xmm1[3,3,3,3]
	movd	%xmm1, %ecx
	movslq	%ecx, %r15
	addq	%rax, %r15
	cmpq	%r10, %r14
	jae	LBB2_8
	.p2align	4, 0x90
LBB2_34:                                ##   Parent Loop BB2_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r14), %r11d
	movl	%r11d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r14), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r11b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r11b
	movsbq	%r9b, %rcx
	movsbq	%al, %rax
	addq	%r15, %rax
	addq	%rcx, %rax
	incq	%r14
	movq	%rax, %r15
	cmpq	%r14, %r10
	jne	LBB2_34
	jmp	LBB2_35
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse236squared_euclidean_int4_distance_sse2EPKvS3_mPf
LCPI3_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI3_1:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse236squared_euclidean_int4_distance_sse2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4sse236squared_euclidean_int4_distance_sse2EPKvS3_mPf: ## @_ZN4zvec5turbo4sse236squared_euclidean_int4_distance_sse2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$33, %rdx
	jb	LBB3_11
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	addq	$-32, %rdx
	movq	%rdx, %r10
	shrq	%r10
	pxor	%xmm0, %xmm0
	xorl	%r11d, %r11d
	cmpq	$32, %rdx
	jb	LBB3_4
## %bb.2:
	movdqa	LCPI3_0(%rip), %xmm1            ## xmm1 = [1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB3_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rax
	movdqu	(%rdi,%r11), %xmm5
	movdqa	%xmm5, %xmm2
	punpcklbw	%xmm5, %xmm3            ## xmm3 = xmm3[0],xmm5[0],xmm3[1],xmm5[1],xmm3[2],xmm5[2],xmm3[3],xmm5[3],xmm3[4],xmm5[4],xmm3[5],xmm5[5],xmm3[6],xmm5[6],xmm3[7],xmm5[7]
	punpckhbw	%xmm5, %xmm4            ## xmm4 = xmm4[8],xmm5[8],xmm4[9],xmm5[9],xmm4[10],xmm5[10],xmm4[11],xmm5[11],xmm4[12],xmm5[12],xmm4[13],xmm5[13],xmm4[14],xmm5[14],xmm4[15],xmm5[15]
	movdqa	%xmm5, %xmm6
	punpcklbw	%xmm6, %xmm6            ## xmm6 = xmm6[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm6
	psraw	$12, %xmm6
	movdqu	(%rsi,%r11), %xmm7
	movdqa	%xmm7, %xmm5
	punpcklbw	%xmm7, %xmm8            ## xmm8 = xmm8[0],xmm7[0],xmm8[1],xmm7[1],xmm8[2],xmm7[2],xmm8[3],xmm7[3],xmm8[4],xmm7[4],xmm8[5],xmm7[5],xmm8[6],xmm7[6],xmm8[7],xmm7[7]
	punpckhbw	%xmm7, %xmm9            ## xmm9 = xmm9[8],xmm7[8],xmm9[9],xmm7[9],xmm9[10],xmm7[10],xmm9[11],xmm7[11],xmm9[12],xmm7[12],xmm9[13],xmm7[13],xmm9[14],xmm7[14],xmm9[15],xmm7[15]
	punpcklbw	%xmm7, %xmm7            ## xmm7 = xmm7[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm7
	psraw	$12, %xmm7
	pmullw	%xmm6, %xmm7
	punpckhbw	%xmm2, %xmm2            ## xmm2 = xmm2[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm2
	psraw	$12, %xmm2
	psraw	$12, %xmm3
	psraw	$12, %xmm4
	punpckhbw	%xmm5, %xmm5            ## xmm5 = xmm5[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm5
	psraw	$12, %xmm5
	pmullw	%xmm2, %xmm5
	psraw	$12, %xmm8
	pmullw	%xmm3, %xmm8
	psraw	$12, %xmm9
	pmullw	%xmm4, %xmm9
	pmaddwd	%xmm1, %xmm7
	paddd	%xmm0, %xmm7
	pmaddwd	%xmm1, %xmm5
	pmaddwd	%xmm1, %xmm8
	paddd	%xmm5, %xmm8
	paddd	%xmm7, %xmm8
	pmaddwd	%xmm1, %xmm9
	movdqa	%xmm9, %xmm0
	paddd	%xmm8, %xmm0
	addq	$16, %r11
	addq	$32, %rax
	cmpq	%r10, %rax
	jbe	LBB3_3
LBB3_4:
	movq	%xmm0, %rax
	cltq
	pshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	movd	%xmm1, %r8d
	movslq	%r8d, %r8
	addq	%rax, %r8
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	movd	%xmm1, %eax
	cltq
	addq	%r8, %rax
	pshufd	$255, %xmm0, %xmm0              ## xmm0 = xmm0[3,3,3,3]
	movd	%xmm0, %r8d
	movslq	%r8d, %rbx
	addq	%rax, %rbx
	cmpq	%r10, %r11
	jae	LBB3_5
	.p2align	4, 0x90
LBB3_6:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %r14d
	movl	%r14d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r14b
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%r14b
	movsbq	%r9b, %r8
	movsbq	%al, %rax
	addq	%rbx, %rax
	addq	%r8, %rax
	incq	%r11
	movq	%rax, %rbx
	cmpq	%r11, %r10
	jne	LBB3_6
	jmp	LBB3_7
LBB3_5:
	movq	%rbx, %rax
LBB3_7:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	movss	(%rsi,%r10), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm0, %xmm4
	mulss	%xmm0, %xmm4
	mulss	12(%rsi,%r10), %xmm4
	movss	(%rdi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm5
	mulss	%xmm1, %xmm5
	mulss	12(%rdi,%r10), %xmm5
	movss	4(%rdi,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	addss	%xmm4, %xmm5
	movss	LCPI3_1(%rip), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	mulss	%xmm1, %xmm4
	mulss	%xmm0, %xmm4
	mulss	%xmm3, %xmm4
	subss	4(%rsi,%r10), %xmm2
	addss	%xmm5, %xmm4
	movaps	%xmm2, %xmm3
	mulss	%xmm2, %xmm3
	testq	%rdx, %rdx
	js	LBB3_8
## %bb.9:
	xorps	%xmm5, %xmm5
	cvtsi2ss	%rdx, %xmm5
	jmp	LBB3_10
LBB3_8:
	andl	$1, %edx
	orq	%r10, %rdx
	xorps	%xmm5, %xmm5
	cvtsi2ss	%rdx, %xmm5
	addss	%xmm5, %xmm5
LBB3_10:
	mulss	%xmm5, %xmm3
	addss	%xmm4, %xmm3
	addss	%xmm2, %xmm2
	mulss	8(%rsi,%r10), %xmm0
	mulss	8(%rdi,%r10), %xmm1
	subss	%xmm0, %xmm1
	mulss	%xmm2, %xmm1
	addss	%xmm3, %xmm1
	movss	%xmm1, (%rcx)
	popq	%rbx
	popq	%r14
	popq	%rbp
LBB3_11:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse242squared_euclidean_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
LCPI4_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI4_1:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse242squared_euclidean_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4sse242squared_euclidean_int4_batch_distance_sse2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4sse242squared_euclidean_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$33, %rcx
	jb	LBB4_7
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %r13
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	addq	$-32, %r13
	movq	%r13, %rcx
	callq	__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKhmmPf
	testq	%r14, %r14
	je	LBB4_7
## %bb.2:
	movq	%r13, %rax
	shrq	%rax
	movss	(%r15,%rax), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm0, %xmm1
	mulss	%xmm0, %xmm1
	testq	%r13, %r13
	js	LBB4_3
## %bb.4:
	cvtsi2ss	%r13, %xmm2
	jmp	LBB4_5
LBB4_3:
	andl	$1, %r13d
	orq	%rax, %r13
	cvtsi2ss	%r13, %xmm2
	addss	%xmm2, %xmm2
LBB4_5:
	mulss	12(%r15,%rax), %xmm1
	xorps	LCPI4_0(%rip), %xmm0
	mulss	8(%r15,%rax), %xmm0
	xorl	%ecx, %ecx
	movss	LCPI4_1(%rip), %xmm3            ## xmm3 = mem[0],zero,zero,zero
	.p2align	4, 0x90
LBB4_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r12,%rcx,8), %rdx
	movss	(%rdx,%rax), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movaps	%xmm4, %xmm5
	mulss	%xmm4, %xmm5
	mulss	12(%rdx,%rax), %xmm5
	movss	4(%rdx,%rax), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	addss	%xmm1, %xmm5
	movaps	%xmm4, %xmm7
	mulss	%xmm3, %xmm7
	mulss	(%r15,%rax), %xmm7
	mulss	(%rbx,%rcx,4), %xmm7
	addss	%xmm5, %xmm7
	subss	4(%r15,%rax), %xmm6
	movaps	%xmm6, %xmm5
	mulss	%xmm6, %xmm5
	mulss	%xmm2, %xmm5
	addss	%xmm7, %xmm5
	addss	%xmm6, %xmm6
	mulss	8(%rdx,%rax), %xmm4
	addss	%xmm0, %xmm4
	mulss	%xmm6, %xmm4
	addss	%xmm5, %xmm4
	movss	%xmm4, (%rbx,%rcx,4)
	incq	%rcx
	cmpq	%rcx, %r14
	jne	LBB4_6
LBB4_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse225cosine_int4_distance_sse2EPKvS3_mPf
LCPI5_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
LCPI5_1:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse225cosine_int4_distance_sse2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4sse225cosine_int4_distance_sse2EPKvS3_mPf: ## @_ZN4zvec5turbo4sse225cosine_int4_distance_sse2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$41, %rdx
	jb	LBB5_11
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	addq	$-40, %rdx
	movq	%rdx, %r10
	shrq	%r10
	pxor	%xmm0, %xmm0
	xorl	%r11d, %r11d
	cmpq	$32, %rdx
	jb	LBB5_4
## %bb.2:
	movdqa	LCPI5_0(%rip), %xmm1            ## xmm1 = [1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB5_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r11, %rax
	movdqu	(%rdi,%r11), %xmm5
	movdqa	%xmm5, %xmm2
	punpcklbw	%xmm5, %xmm3            ## xmm3 = xmm3[0],xmm5[0],xmm3[1],xmm5[1],xmm3[2],xmm5[2],xmm3[3],xmm5[3],xmm3[4],xmm5[4],xmm3[5],xmm5[5],xmm3[6],xmm5[6],xmm3[7],xmm5[7]
	punpckhbw	%xmm5, %xmm4            ## xmm4 = xmm4[8],xmm5[8],xmm4[9],xmm5[9],xmm4[10],xmm5[10],xmm4[11],xmm5[11],xmm4[12],xmm5[12],xmm4[13],xmm5[13],xmm4[14],xmm5[14],xmm4[15],xmm5[15]
	movdqa	%xmm5, %xmm6
	punpcklbw	%xmm6, %xmm6            ## xmm6 = xmm6[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm6
	psraw	$12, %xmm6
	movdqu	(%rsi,%r11), %xmm7
	movdqa	%xmm7, %xmm5
	punpcklbw	%xmm7, %xmm8            ## xmm8 = xmm8[0],xmm7[0],xmm8[1],xmm7[1],xmm8[2],xmm7[2],xmm8[3],xmm7[3],xmm8[4],xmm7[4],xmm8[5],xmm7[5],xmm8[6],xmm7[6],xmm8[7],xmm7[7]
	punpckhbw	%xmm7, %xmm9            ## xmm9 = xmm9[8],xmm7[8],xmm9[9],xmm7[9],xmm9[10],xmm7[10],xmm9[11],xmm7[11],xmm9[12],xmm7[12],xmm9[13],xmm7[13],xmm9[14],xmm7[14],xmm9[15],xmm7[15]
	punpcklbw	%xmm7, %xmm7            ## xmm7 = xmm7[0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7]
	psllw	$12, %xmm7
	psraw	$12, %xmm7
	pmullw	%xmm6, %xmm7
	punpckhbw	%xmm2, %xmm2            ## xmm2 = xmm2[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm2
	psraw	$12, %xmm2
	psraw	$12, %xmm3
	psraw	$12, %xmm4
	punpckhbw	%xmm5, %xmm5            ## xmm5 = xmm5[8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15]
	psllw	$12, %xmm5
	psraw	$12, %xmm5
	pmullw	%xmm2, %xmm5
	psraw	$12, %xmm8
	pmullw	%xmm3, %xmm8
	psraw	$12, %xmm9
	pmullw	%xmm4, %xmm9
	pmaddwd	%xmm1, %xmm7
	paddd	%xmm0, %xmm7
	pmaddwd	%xmm1, %xmm5
	pmaddwd	%xmm1, %xmm8
	paddd	%xmm5, %xmm8
	paddd	%xmm7, %xmm8
	pmaddwd	%xmm1, %xmm9
	movdqa	%xmm9, %xmm0
	paddd	%xmm8, %xmm0
	addq	$16, %r11
	addq	$32, %rax
	cmpq	%r10, %rax
	jbe	LBB5_3
LBB5_4:
	movq	%xmm0, %rax
	cltq
	pshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	movd	%xmm1, %r8d
	movslq	%r8d, %r8
	addq	%rax, %r8
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	movd	%xmm1, %eax
	cltq
	addq	%r8, %rax
	pshufd	$255, %xmm0, %xmm0              ## xmm0 = xmm0[3,3,3,3]
	movd	%xmm0, %r8d
	movslq	%r8d, %rbx
	addq	%rax, %rbx
	cmpq	%r10, %r11
	jae	LBB5_5
	.p2align	4, 0x90
LBB5_6:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %r14d
	movl	%r14d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r14b
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%r14b
	movsbq	%r9b, %r8
	movsbq	%al, %rax
	addq	%rbx, %rax
	addq	%r8, %rax
	incq	%r11
	movq	%rax, %rbx
	cmpq	%r11, %r10
	jne	LBB5_6
	jmp	LBB5_7
LBB5_5:
	movq	%rbx, %rax
LBB5_7:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	movss	(%rdi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%rsi,%r10), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm5
	mulss	%xmm4, %xmm5
	mulss	%xmm3, %xmm5
	mulss	%xmm2, %xmm4
	mulss	8(%rsi,%r10), %xmm4
	addss	%xmm5, %xmm4
	mulss	%xmm0, %xmm1
	mulss	8(%rdi,%r10), %xmm1
	addss	%xmm4, %xmm1
	testq	%rdx, %rdx
	js	LBB5_8
## %bb.9:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rdx, %xmm3
	jmp	LBB5_10
LBB5_8:
	andl	$1, %edx
	orq	%r10, %rdx
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rdx, %xmm3
	addss	%xmm3, %xmm3
LBB5_10:
	mulss	%xmm3, %xmm0
	mulss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	xorps	LCPI5_1(%rip), %xmm0
	movss	%xmm0, (%rcx)
	popq	%rbx
	popq	%r14
	popq	%rbp
LBB5_11:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse231cosine_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
LCPI6_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse231cosine_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4sse231cosine_int4_batch_distance_sse2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4sse231cosine_int4_batch_distance_sse2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$41, %rcx
	jb	LBB6_7
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %r13
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	addq	$-40, %r13
	movq	%r13, %rcx
	callq	__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKhmmPf
	testq	%r14, %r14
	je	LBB6_7
## %bb.2:
	movq	%r13, %rax
	shrq	%rax
	testq	%r13, %r13
	js	LBB6_3
## %bb.4:
	cvtsi2ss	%r13, %xmm0
	jmp	LBB6_5
LBB6_3:
	andl	$1, %r13d
	orq	%rax, %r13
	cvtsi2ss	%r13, %xmm0
	addss	%xmm0, %xmm0
LBB6_5:
	xorl	%ecx, %ecx
	movaps	LCPI6_0(%rip), %xmm1            ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB6_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r12,%rcx,8), %rdx
	movss	(%rdx,%rax), %xmm2              ## xmm2 = mem[0],zero,zero,zero
	movss	4(%rdx,%rax), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	movss	(%r15,%rax), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%r15,%rax), %xmm5             ## xmm5 = mem[0],zero,zero,zero
	movaps	%xmm2, %xmm6
	mulss	%xmm4, %xmm6
	mulss	%xmm3, %xmm4
	mulss	8(%r15,%rax), %xmm4
	mulss	(%rbx,%rcx,4), %xmm6
	addss	%xmm4, %xmm6
	mulss	%xmm5, %xmm2
	mulss	8(%rdx,%rax), %xmm2
	addss	%xmm6, %xmm2
	mulss	%xmm0, %xmm5
	mulss	%xmm3, %xmm5
	addss	%xmm2, %xmm5
	xorps	%xmm1, %xmm5
	movss	%xmm5, (%rbx,%rcx,4)
	incq	%rcx
	cmpq	%rcx, %r14
	jne	LBB6_6
LBB6_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
