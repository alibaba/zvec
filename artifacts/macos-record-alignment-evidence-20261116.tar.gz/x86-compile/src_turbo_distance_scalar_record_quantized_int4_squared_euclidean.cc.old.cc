// Copyright 2025-present the zvec project
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "scalar/record_quantized_int4/squared_euclidean.h"
#include <cstdint>
#include "scalar/record_quantized_int4/common.h"

namespace zvec::turbo::scalar {

void squared_euclidean_int4_distance(const void *a, const void *b, size_t dim,
                                     float *distance) {
  // `dim` is the full encoded size in int4 units; the original vector
  // occupies dim-32 int4 units (i.e. (dim-32)/2 bytes).
  const int original_dim = static_cast<int>(dim) - 32;
  if (original_dim <= 0) {
    return;
  }
  const size_t p = static_cast<size_t>(original_dim) >> 1;  // params offset
  float ip = internal::ip_int4_scalar(a, b, original_dim);

  const float *a_tail =
      reinterpret_cast<const float *>(reinterpret_cast<const uint8_t *>(a) + p);
  const float *b_tail =
      reinterpret_cast<const float *>(reinterpret_cast<const uint8_t *>(b) + p);

  float ma = a_tail[0];
  float mb = a_tail[1];
  float ms = a_tail[2];
  float ms2 = a_tail[3];

  float qa = b_tail[0];
  float qb = b_tail[1];
  float qs = b_tail[2];
  float qs2 = b_tail[3];

  const float sum = qa * qs;
  const float sum2 = qa * qa * qs2;

  *distance = ma * ma * ms2 + sum2 - 2 * ma * qa * ip +
              (mb - qb) * (mb - qb) * original_dim +
              2 * (mb - qb) * (ms * ma - sum);
}

void squared_euclidean_int4_batch_distance(
    const void *const *vectors, const void *query, size_t n, size_t dim,
    float *distances, const void *const * /*extra_values*/) {
  for (size_t i = 0; i < n; ++i) {
    squared_euclidean_int4_distance(vectors[i], query, dim, &distances[i]);
  }
}

}  // namespace zvec::turbo::scalar
