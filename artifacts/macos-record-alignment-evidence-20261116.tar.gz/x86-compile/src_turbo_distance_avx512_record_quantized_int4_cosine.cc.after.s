	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__const
	.p2align	6, 0x0                          ## -- Begin function _ZN4zvec5turbo6avx51227cosine_int4_distance_avx512EPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI0_1:
	.space	16,240
LCPI0_2:
	.space	16,8
LCPI0_3:
	.space	16,15
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI0_4:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6avx51227cosine_int4_distance_avx512EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo6avx51227cosine_int4_distance_avx512EPKvS3_mPf: ## @_ZN4zvec5turbo6avx51227cosine_int4_distance_avx512EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$41, %rdx
	jb	LBB0_14
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	addq	$-40, %rdx
	movq	%rdx, %r10
	shrq	%r10
	vpxor	%xmm0, %xmm0, %xmm0
	cmpq	$64, %rdx
	jae	LBB0_3
## %bb.2:
	xorl	%eax, %eax
	jmp	LBB0_5
LBB0_3:
	xorl	%r8d, %r8d
	vmovdqa64	LCPI0_0(%rip), %zmm1    ## zmm1 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	vpmovzxbw	(%rdi,%r8), %zmm2       ## zmm2 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpmovzxbw	(%rsi,%r8), %zmm3       ## zmm3 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm2, %zmm4
	vpsraw	$12, %zmm4, %zmm4
	vpsllw	$12, %zmm3, %zmm5
	vpsraw	$12, %zmm5, %zmm5
	vpmullw	%zmm4, %zmm5, %zmm4
	vpsllw	$8, %zmm2, %zmm2
	vpsraw	$12, %zmm2, %zmm2
	vpsllw	$8, %zmm3, %zmm3
	vpsraw	$12, %zmm3, %zmm3
	vpmullw	%zmm2, %zmm3, %zmm2
	vpmaddwd	%zmm1, %zmm4, %zmm3
	vpaddd	%zmm0, %zmm3, %zmm0
	vpmaddwd	%zmm1, %zmm2, %zmm2
	vpaddd	%zmm2, %zmm0, %zmm0
	leaq	32(%r8), %rax
	addq	$64, %r8
	cmpq	%r10, %r8
	movq	%rax, %r8
	jbe	LBB0_4
LBB0_5:
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %r8d
	movslq	%r8d, %r9
	movq	%r10, %r11
	subq	%rax, %r11
	jbe	LBB0_13
## %bb.6:
	cmpq	$32, %r11
	jae	LBB0_8
## %bb.7:
	movq	%rax, %r11
	jmp	LBB0_11
LBB0_8:
	movl	%r10d, %r8d
	andl	$31, %r8d
	subq	%r8, %r11
	addq	%rax, %r11
	vmovq	%r9, %xmm0
	vpxor	%xmm1, %xmm1, %xmm1
	vmovdqa	LCPI0_1(%rip), %xmm2            ## xmm2 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI0_2(%rip), %xmm3            ## xmm3 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI0_3(%rip), %xmm4            ## xmm4 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vpxor	%xmm5, %xmm5, %xmm5
	vpxor	%xmm6, %xmm6, %xmm6
	.p2align	4, 0x90
LBB0_9:                                 ## =>This Inner Loop Header: Depth=1
	vmovq	(%rdi,%rax), %xmm7              ## xmm7 = mem[0],zero
	vmovq	8(%rdi,%rax), %xmm8             ## xmm8 = mem[0],zero
	vmovq	16(%rdi,%rax), %xmm9            ## xmm9 = mem[0],zero
	vmovq	24(%rdi,%rax), %xmm10           ## xmm10 = mem[0],zero
	vpsllw	$4, %xmm7, %xmm11
	vpand	%xmm2, %xmm11, %xmm11
	vpsrlw	$4, %xmm11, %xmm11
	vpxor	%xmm3, %xmm11, %xmm11
	vpsubb	%xmm3, %xmm11, %xmm11
	vpsllw	$4, %xmm8, %xmm12
	vpand	%xmm2, %xmm12, %xmm12
	vpsrlw	$4, %xmm12, %xmm12
	vpxor	%xmm3, %xmm12, %xmm12
	vpsubb	%xmm3, %xmm12, %xmm12
	vpsllw	$4, %xmm9, %xmm13
	vpand	%xmm2, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm3, %xmm13, %xmm13
	vpsubb	%xmm3, %xmm13, %xmm13
	vpsllw	$4, %xmm10, %xmm14
	vpand	%xmm2, %xmm14, %xmm14
	vpsrlw	$4, %xmm14, %xmm14
	vpxor	%xmm3, %xmm14, %xmm14
	vpsubb	%xmm3, %xmm14, %xmm14
	vpsrlw	$4, %xmm7, %xmm7
	vpternlogq	$108, %xmm4, %xmm3, %xmm7
	vpsubb	%xmm3, %xmm7, %xmm7
	vpsrlw	$4, %xmm8, %xmm8
	vpternlogq	$108, %xmm4, %xmm3, %xmm8
	vpsubb	%xmm3, %xmm8, %xmm8
	vpsrlw	$4, %xmm9, %xmm9
	vpternlogq	$108, %xmm4, %xmm3, %xmm9
	vpsubb	%xmm3, %xmm9, %xmm9
	vpsrlw	$4, %xmm10, %xmm10
	vpternlogq	$108, %xmm4, %xmm3, %xmm10
	vpsubb	%xmm3, %xmm10, %xmm10
	vmovq	(%rsi,%rax), %xmm15             ## xmm15 = mem[0],zero
	vmovq	8(%rsi,%rax), %xmm16            ## xmm16 = mem[0],zero
	vmovq	16(%rsi,%rax), %xmm17           ## xmm17 = mem[0],zero
	vmovq	24(%rsi,%rax), %xmm18           ## xmm18 = mem[0],zero
	vpsllw	$4, %xmm15, %xmm19
	vpandq	%xmm2, %xmm19, %xmm19
	vpsrlw	$4, %xmm19, %xmm19
	vpxorq	%xmm3, %xmm19, %xmm19
	vpsubb	%xmm3, %xmm19, %xmm19
	vpsllw	$4, %xmm16, %xmm20
	vpandq	%xmm2, %xmm20, %xmm20
	vpsrlw	$4, %xmm20, %xmm20
	vpxorq	%xmm3, %xmm20, %xmm20
	vpsubb	%xmm3, %xmm20, %xmm20
	vpsllw	$4, %xmm17, %xmm21
	vpandq	%xmm2, %xmm21, %xmm21
	vpsrlw	$4, %xmm21, %xmm21
	vpxorq	%xmm3, %xmm21, %xmm21
	vpsubb	%xmm3, %xmm21, %xmm21
	vpsllw	$4, %xmm18, %xmm22
	vpandq	%xmm2, %xmm22, %xmm22
	vpsrlw	$4, %xmm22, %xmm22
	vpxorq	%xmm3, %xmm22, %xmm22
	vpsubb	%xmm3, %xmm22, %xmm22
	vpsrlw	$4, %xmm15, %xmm15
	vpternlogq	$108, %xmm4, %xmm3, %xmm15
	vpsubb	%xmm3, %xmm15, %xmm15
	vpsrlw	$4, %xmm16, %xmm16
	vpternlogq	$108, %xmm4, %xmm3, %xmm16
	vpsubb	%xmm3, %xmm16, %xmm16
	vpsrlw	$4, %xmm17, %xmm17
	vpternlogq	$108, %xmm4, %xmm3, %xmm17
	vpsubb	%xmm3, %xmm17, %xmm17
	vpsrlw	$4, %xmm18, %xmm18
	vpternlogq	$108, %xmm4, %xmm3, %xmm18
	vpsubb	%xmm3, %xmm18, %xmm18
	vpmovzxbw	%xmm11, %xmm11          ## xmm11 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmovzxbw	%xmm19, %xmm19          ## xmm19 = xmm19[0],zero,xmm19[1],zero,xmm19[2],zero,xmm19[3],zero,xmm19[4],zero,xmm19[5],zero,xmm19[6],zero,xmm19[7],zero
	vpmullw	%xmm11, %xmm19, %xmm11
	vpmovwb	%xmm11, %xmm11
	vpmovzxbw	%xmm12, %xmm12          ## xmm12 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmovzxbw	%xmm20, %xmm19          ## xmm19 = xmm20[0],zero,xmm20[1],zero,xmm20[2],zero,xmm20[3],zero,xmm20[4],zero,xmm20[5],zero,xmm20[6],zero,xmm20[7],zero
	vpmullw	%xmm12, %xmm19, %xmm12
	vpmovwb	%xmm12, %xmm12
	vpmovzxbw	%xmm13, %xmm13          ## xmm13 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmovzxbw	%xmm21, %xmm19          ## xmm19 = xmm21[0],zero,xmm21[1],zero,xmm21[2],zero,xmm21[3],zero,xmm21[4],zero,xmm21[5],zero,xmm21[6],zero,xmm21[7],zero
	vpmullw	%xmm13, %xmm19, %xmm13
	vpmovwb	%xmm13, %xmm13
	vpmovzxbw	%xmm14, %xmm14          ## xmm14 = xmm14[0],zero,xmm14[1],zero,xmm14[2],zero,xmm14[3],zero,xmm14[4],zero,xmm14[5],zero,xmm14[6],zero,xmm14[7],zero
	vpmovzxbw	%xmm22, %xmm19          ## xmm19 = xmm22[0],zero,xmm22[1],zero,xmm22[2],zero,xmm22[3],zero,xmm22[4],zero,xmm22[5],zero,xmm22[6],zero,xmm22[7],zero
	vpmullw	%xmm14, %xmm19, %xmm14
	vpmovwb	%xmm14, %xmm14
	vpmovsxbq	%xmm11, %zmm11
	vpmovsxbq	%xmm12, %zmm12
	vpmovsxbq	%xmm13, %zmm13
	vpmovsxbq	%xmm14, %zmm14
	vpmovzxbw	%xmm7, %xmm7            ## xmm7 = xmm7[0],zero,xmm7[1],zero,xmm7[2],zero,xmm7[3],zero,xmm7[4],zero,xmm7[5],zero,xmm7[6],zero,xmm7[7],zero
	vpmovzxbw	%xmm15, %xmm15          ## xmm15 = xmm15[0],zero,xmm15[1],zero,xmm15[2],zero,xmm15[3],zero,xmm15[4],zero,xmm15[5],zero,xmm15[6],zero,xmm15[7],zero
	vpmullw	%xmm7, %xmm15, %xmm7
	vpmovwb	%xmm7, %xmm7
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm16, %xmm15          ## xmm15 = xmm16[0],zero,xmm16[1],zero,xmm16[2],zero,xmm16[3],zero,xmm16[4],zero,xmm16[5],zero,xmm16[6],zero,xmm16[7],zero
	vpmullw	%xmm8, %xmm15, %xmm8
	vpmovwb	%xmm8, %xmm8
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm17, %xmm15          ## xmm15 = xmm17[0],zero,xmm17[1],zero,xmm17[2],zero,xmm17[3],zero,xmm17[4],zero,xmm17[5],zero,xmm17[6],zero,xmm17[7],zero
	vpmullw	%xmm9, %xmm15, %xmm9
	vpmovwb	%xmm9, %xmm9
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmovzxbw	%xmm18, %xmm15          ## xmm15 = xmm18[0],zero,xmm18[1],zero,xmm18[2],zero,xmm18[3],zero,xmm18[4],zero,xmm18[5],zero,xmm18[6],zero,xmm18[7],zero
	vpmullw	%xmm10, %xmm15, %xmm10
	vpmovwb	%xmm10, %xmm10
	vpmovsxbq	%xmm7, %zmm7
	vpaddq	%zmm7, %zmm0, %zmm0
	vpaddq	%zmm11, %zmm0, %zmm0
	vpmovsxbq	%xmm8, %zmm7
	vpaddq	%zmm7, %zmm1, %zmm1
	vpaddq	%zmm12, %zmm1, %zmm1
	vpmovsxbq	%xmm9, %zmm7
	vpaddq	%zmm7, %zmm5, %zmm5
	vpaddq	%zmm13, %zmm5, %zmm5
	vpmovsxbq	%xmm10, %zmm7
	vpaddq	%zmm7, %zmm6, %zmm6
	vpaddq	%zmm14, %zmm6, %zmm6
	addq	$32, %rax
	cmpq	%rax, %r11
	jne	LBB0_9
## %bb.10:
	vpaddq	%zmm0, %zmm1, %zmm0
	vpaddq	%zmm0, %zmm5, %zmm0
	vpaddq	%zmm0, %zmm6, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddq	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r9
	testq	%r8, %r8
	je	LBB0_13
LBB0_11:
	movq	%r9, %rbx
	.p2align	4, 0x90
LBB0_12:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %r14d
	movl	%r14d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r14b
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%r14b
	movsbq	%r9b, %r8
	movsbq	%al, %r9
	addq	%rbx, %r9
	addq	%r8, %r9
	incq	%r11
	movq	%r9, %rbx
	cmpq	%r11, %r10
	jne	LBB0_12
LBB0_13:
	vcvtsi2ss	%r9, %xmm23, %xmm0
	vmovss	(%rdi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vmovss	4(%rdi,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vmovss	(%rsi,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	vmovss	4(%rsi,%r10), %xmm4             ## xmm4 = mem[0],zero,zero,zero
	vmulss	%xmm3, %xmm1, %xmm5
	vmulss	%xmm3, %xmm2, %xmm3
	vmulss	8(%rsi,%r10), %xmm3, %xmm3
	vfmadd231ss	%xmm5, %xmm0, %xmm3     ## xmm3 = (xmm0 * xmm5) + xmm3
	vmulss	%xmm4, %xmm1, %xmm0
	vfmadd132ss	8(%rdi,%r10), %xmm3, %xmm0 ## xmm0 = (xmm0 * mem) + xmm3
	vcvtusi2ss	%rdx, %xmm23, %xmm1
	vmulss	%xmm1, %xmm4, %xmm1
	vfmadd213ss	%xmm0, %xmm2, %xmm1     ## xmm1 = (xmm2 * xmm1) + xmm0
	vxorps	LCPI0_4(%rip){1to4}, %xmm1, %xmm0
	vmovss	%xmm0, (%rcx)
	popq	%rbx
	popq	%r14
	popq	%rbp
LBB0_14:
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	6, 0x0                          ## -- Begin function _ZN4zvec5turbo6avx51233cosine_int4_batch_distance_avx512EPKPKvS3_mmPfS5_
LCPI1_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI1_1:
	.space	16,240
LCPI1_2:
	.space	16,8
LCPI1_3:
	.space	16,15
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI1_4:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6avx51233cosine_int4_batch_distance_avx512EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo6avx51233cosine_int4_batch_distance_avx512EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo6avx51233cosine_int4_batch_distance_avx512EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$41, %rcx
	jb	LBB1_19
## %bb.1:
	movq	%rsi, %r13
	addq	$-40, %rcx
	movq	%rcx, -48(%rbp)                 ## 8-byte Spill
	cmpq	$2, %rdx
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movq	%rdx, -56(%rbp)                 ## 8-byte Spill
	movq	%rdi, -64(%rbp)                 ## 8-byte Spill
	jae	LBB1_25
## %bb.2:
	xorl	%r12d, %r12d
LBB1_3:
	movq	-48(%rbp), %rbx                 ## 8-byte Reload
	shrq	%rbx
	cmpq	%rdx, %r12
	movq	-72(%rbp), %r14                 ## 8-byte Reload
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	jae	LBB1_16
## %bb.4:
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	cmpq	$64, %rax
	jae	LBB1_5
## %bb.20:
	cmpq	$2, %rax
	jae	LBB1_22
## %bb.21:
	leaq	(%r14,%r12,4), %rdi
	movq	%rdx, %rsi
	subq	%r12, %rsi
	shlq	$2, %rsi
	callq	___bzero
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	jmp	LBB1_17
	.p2align	4, 0x90
LBB1_22:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_23 Depth 2
	movq	(%r15,%r12,8), %rsi
	xorl	%r8d, %r8d
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB1_23:                                ##   Parent Loop BB1_22 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rsi,%r8), %r9d
	movl	%r9d, %r10d
	shlb	$4, %r10b
	sarb	$4, %r10b
	movzbl	(%r13,%r8), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r10b
	movl	%eax, %r10d
	sarb	$4, %r9b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r9b
	movsbq	%r10b, %rcx
	movsbq	%al, %rax
	addq	%rax, %rdi
	addq	%rcx, %rdi
	incq	%r8
	cmpq	%r8, %rbx
	jne	LBB1_23
## %bb.24:                              ##   in Loop: Header=BB1_22 Depth=1
	vcvtsi2ss	%rdi, %xmm1, %xmm0
	vmovss	%xmm0, (%r14,%r12,4)
	incq	%r12
	cmpq	%rdx, %r12
	jne	LBB1_22
LBB1_16:
	testq	%rdx, %rdx
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	je	LBB1_19
LBB1_17:
	vmovss	(%r13,%rbx), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	vmovss	4(%r13,%rbx), %xmm1             ## xmm1 = mem[0],zero,zero,zero
	vmovss	8(%r13,%rbx), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vcvtusi2ss	%rax, %xmm24, %xmm3
	vmulss	%xmm3, %xmm1, %xmm3
	xorl	%eax, %eax
	vbroadcastss	LCPI1_4(%rip), %xmm4    ## xmm4 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_18:                                ## =>This Inner Loop Header: Depth=1
	movq	(%r15,%rax,8), %rcx
	vmovss	(%rcx,%rbx), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	vmovss	4(%rcx,%rbx), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	vmulss	%xmm5, %xmm0, %xmm7
	vmulss	%xmm6, %xmm0, %xmm8
	vmulss	%xmm8, %xmm2, %xmm8
	vfmadd231ss	(%r14,%rax,4), %xmm7, %xmm8 ## xmm8 = (xmm7 * mem) + xmm8
	vmulss	%xmm5, %xmm1, %xmm5
	vfmadd132ss	8(%rcx,%rbx), %xmm8, %xmm5 ## xmm5 = (xmm5 * mem) + xmm8
	vfmadd231ss	%xmm6, %xmm3, %xmm5     ## xmm5 = (xmm3 * xmm6) + xmm5
	vxorps	%xmm4, %xmm5, %xmm5
	vmovss	%xmm5, (%r14,%rax,4)
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB1_18
LBB1_19:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
LBB1_25:
	xorl	%r12d, %r12d
	movq	%rdi, %r15
	movq	%r8, %rbx
	jmp	LBB1_26
	.p2align	4, 0x90
LBB1_31:                                ##   in Loop: Header=BB1_26 Depth=1
	movq	40(%r15), %rax
LBB1_32:                                ##   in Loop: Header=BB1_26 Depth=1
	movq	%rax, -80(%rbp)
	movq	%r13, %rdi
	movq	%r15, %rsi
	leaq	-88(%rbp), %rdx
	movq	%rbx, %r8
	callq	__ZN4zvec5turbo6avx5128internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	addq	$2, %r12
	addq	$8, %rbx
	addq	$16, %r15
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %r14
	ja	LBB1_3
LBB1_26:                                ## =>This Inner Loop Header: Depth=1
	leaq	4(%r12), %r14
	cmpq	%rdx, %r14
	jae	LBB1_27
## %bb.28:                              ##   in Loop: Header=BB1_26 Depth=1
	movq	32(%r15), %rax
	jmp	LBB1_29
	.p2align	4, 0x90
LBB1_27:                                ##   in Loop: Header=BB1_26 Depth=1
	xorl	%eax, %eax
LBB1_29:                                ##   in Loop: Header=BB1_26 Depth=1
	movq	-48(%rbp), %rcx                 ## 8-byte Reload
	movq	%rax, -88(%rbp)
	leaq	5(%r12), %rax
	cmpq	%rdx, %rax
	jb	LBB1_31
## %bb.30:                              ##   in Loop: Header=BB1_26 Depth=1
	xorl	%eax, %eax
	jmp	LBB1_32
LBB1_5:
	cmpq	$64, %rbx
	movl	$63, %eax
	cmovaeq	%rbx, %rax
	andq	$-32, %rax
	movq	%rbx, %rsi
	subq	%rax, %rsi
	movl	%ebx, %edi
	andl	$31, %edi
	movq	%rsi, %r8
	subq	%rdi, %r8
	movq	%rbx, %r9
	andq	$-32, %r9
	subq	%rax, %r9
	vmovdqa64	LCPI1_0(%rip), %zmm0    ## zmm0 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vmovdqa	LCPI1_1(%rip), %xmm1            ## xmm1 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI1_2(%rip), %xmm2            ## xmm2 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI1_3(%rip), %xmm3            ## xmm3 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	jmp	LBB1_6
	.p2align	4, 0x90
LBB1_15:                                ##   in Loop: Header=BB1_6 Depth=1
	vcvtsi2ss	%rcx, %xmm24, %xmm4
	movq	-72(%rbp), %r14                 ## 8-byte Reload
	vmovss	%xmm4, (%r14,%r12,4)
	incq	%r12
	movq	-56(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %r12
	movq	-64(%rbp), %r15                 ## 8-byte Reload
	je	LBB1_16
LBB1_6:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_7 Depth 2
                                        ##     Child Loop BB1_11 Depth 2
                                        ##     Child Loop BB1_14 Depth 2
	movq	(%r15,%r12,8), %r10
	vpxor	%xmm4, %xmm4, %xmm4
	movl	$56, %ecx
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB1_7:                                 ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r11, %rdx
	movq	%rcx, %rax
	vpmovzxbw	(%r13,%r11), %zmm5      ## zmm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm5, %zmm6
	vpsraw	$12, %zmm6, %zmm6
	vpsllw	$8, %zmm5, %zmm5
	vpsraw	$12, %zmm5, %zmm5
	vpmovzxbw	(%r10,%r11), %zmm7      ## zmm7 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm7, %zmm8
	vpsraw	$12, %zmm8, %zmm8
	vpmullw	%zmm6, %zmm8, %zmm6
	vpsllw	$8, %zmm7, %zmm7
	vpsraw	$12, %zmm7, %zmm7
	vpmullw	%zmm5, %zmm7, %zmm5
	vpmaddwd	%zmm0, %zmm6, %zmm6
	vpaddd	%zmm4, %zmm6, %zmm4
	vpmaddwd	%zmm0, %zmm5, %zmm5
	vpaddd	%zmm5, %zmm4, %zmm4
	addq	$32, %r11
	addq	$64, %rdx
	addq	$32, %rcx
	cmpq	%rbx, %rdx
	jbe	LBB1_7
## %bb.8:                               ##   in Loop: Header=BB1_6 Depth=1
	vextracti64x4	$1, %zmm4, %ymm5
	vpaddd	%zmm5, %zmm4, %zmm4
	vextracti128	$1, %ymm4, %xmm5
	vpaddd	%xmm5, %xmm4, %xmm4
	vpshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	vpaddd	%xmm5, %xmm4, %xmm4
	vpshufd	$85, %xmm4, %xmm5               ## xmm5 = xmm4[1,1,1,1]
	vpaddd	%xmm5, %xmm4, %xmm4
	vmovd	%xmm4, %ecx
	movslq	%ecx, %rcx
	cmpq	%rbx, %r11
	jae	LBB1_15
## %bb.9:                               ##   in Loop: Header=BB1_6 Depth=1
	cmpq	$32, %rsi
	jb	LBB1_13
## %bb.10:                              ##   in Loop: Header=BB1_6 Depth=1
	addq	%r9, %r11
	vmovq	%rcx, %xmm4
	vpxor	%xmm5, %xmm5, %xmm5
	movq	%r8, %rcx
	vpxor	%xmm6, %xmm6, %xmm6
	vpxor	%xmm7, %xmm7, %xmm7
	.p2align	4, 0x90
LBB1_11:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovq	-24(%r10,%rax), %xmm8           ## xmm8 = mem[0],zero
	vmovq	-16(%r10,%rax), %xmm9           ## xmm9 = mem[0],zero
	vmovq	-8(%r10,%rax), %xmm10           ## xmm10 = mem[0],zero
	vmovq	(%r10,%rax), %xmm11             ## xmm11 = mem[0],zero
	vpsllw	$4, %xmm8, %xmm12
	vpand	%xmm1, %xmm12, %xmm12
	vpsrlw	$4, %xmm12, %xmm12
	vpxor	%xmm2, %xmm12, %xmm12
	vpsubb	%xmm2, %xmm12, %xmm12
	vpsllw	$4, %xmm9, %xmm13
	vpand	%xmm1, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm2, %xmm13, %xmm13
	vpsubb	%xmm2, %xmm13, %xmm13
	vpsllw	$4, %xmm10, %xmm14
	vpand	%xmm1, %xmm14, %xmm14
	vpsrlw	$4, %xmm14, %xmm14
	vpxor	%xmm2, %xmm14, %xmm14
	vpsubb	%xmm2, %xmm14, %xmm14
	vpsllw	$4, %xmm11, %xmm15
	vpand	%xmm1, %xmm15, %xmm15
	vpsrlw	$4, %xmm15, %xmm15
	vpxor	%xmm2, %xmm15, %xmm15
	vpsubb	%xmm2, %xmm15, %xmm15
	vpsrlw	$4, %xmm8, %xmm8
	vpternlogq	$108, %xmm3, %xmm2, %xmm8
	vpsubb	%xmm2, %xmm8, %xmm8
	vpsrlw	$4, %xmm9, %xmm9
	vpternlogq	$108, %xmm3, %xmm2, %xmm9
	vpsubb	%xmm2, %xmm9, %xmm9
	vpsrlw	$4, %xmm10, %xmm10
	vpternlogq	$108, %xmm3, %xmm2, %xmm10
	vpsubb	%xmm2, %xmm10, %xmm10
	vpsrlw	$4, %xmm11, %xmm11
	vpternlogq	$108, %xmm3, %xmm2, %xmm11
	vpsubb	%xmm2, %xmm11, %xmm11
	vmovq	-24(%r13,%rax), %xmm16          ## xmm16 = mem[0],zero
	vmovq	-16(%r13,%rax), %xmm17          ## xmm17 = mem[0],zero
	vmovq	-8(%r13,%rax), %xmm18           ## xmm18 = mem[0],zero
	vmovq	(%r13,%rax), %xmm19             ## xmm19 = mem[0],zero
	vpsllw	$4, %xmm16, %xmm20
	vpandq	%xmm1, %xmm20, %xmm20
	vpsrlw	$4, %xmm20, %xmm20
	vpxorq	%xmm2, %xmm20, %xmm20
	vpsubb	%xmm2, %xmm20, %xmm20
	vpsllw	$4, %xmm17, %xmm21
	vpandq	%xmm1, %xmm21, %xmm21
	vpsrlw	$4, %xmm21, %xmm21
	vpxorq	%xmm2, %xmm21, %xmm21
	vpsubb	%xmm2, %xmm21, %xmm21
	vpsllw	$4, %xmm18, %xmm22
	vpandq	%xmm1, %xmm22, %xmm22
	vpsrlw	$4, %xmm22, %xmm22
	vpxorq	%xmm2, %xmm22, %xmm22
	vpsubb	%xmm2, %xmm22, %xmm22
	vpsllw	$4, %xmm19, %xmm23
	vpandq	%xmm1, %xmm23, %xmm23
	vpsrlw	$4, %xmm23, %xmm23
	vpxorq	%xmm2, %xmm23, %xmm23
	vpsubb	%xmm2, %xmm23, %xmm23
	vpsrlw	$4, %xmm16, %xmm16
	vpternlogq	$108, %xmm3, %xmm2, %xmm16
	vpsubb	%xmm2, %xmm16, %xmm16
	vpsrlw	$4, %xmm17, %xmm17
	vpternlogq	$108, %xmm3, %xmm2, %xmm17
	vpsubb	%xmm2, %xmm17, %xmm17
	vpsrlw	$4, %xmm18, %xmm18
	vpternlogq	$108, %xmm3, %xmm2, %xmm18
	vpsubb	%xmm2, %xmm18, %xmm18
	vpsrlw	$4, %xmm19, %xmm19
	vpternlogq	$108, %xmm3, %xmm2, %xmm19
	vpsubb	%xmm2, %xmm19, %xmm19
	vpmovzxbw	%xmm12, %xmm12          ## xmm12 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmovzxbw	%xmm20, %xmm20          ## xmm20 = xmm20[0],zero,xmm20[1],zero,xmm20[2],zero,xmm20[3],zero,xmm20[4],zero,xmm20[5],zero,xmm20[6],zero,xmm20[7],zero
	vpmullw	%xmm12, %xmm20, %xmm12
	vpmovwb	%xmm12, %xmm12
	vpmovzxbw	%xmm13, %xmm13          ## xmm13 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmovzxbw	%xmm21, %xmm20          ## xmm20 = xmm21[0],zero,xmm21[1],zero,xmm21[2],zero,xmm21[3],zero,xmm21[4],zero,xmm21[5],zero,xmm21[6],zero,xmm21[7],zero
	vpmullw	%xmm13, %xmm20, %xmm13
	vpmovwb	%xmm13, %xmm13
	vpmovzxbw	%xmm14, %xmm14          ## xmm14 = xmm14[0],zero,xmm14[1],zero,xmm14[2],zero,xmm14[3],zero,xmm14[4],zero,xmm14[5],zero,xmm14[6],zero,xmm14[7],zero
	vpmovzxbw	%xmm22, %xmm20          ## xmm20 = xmm22[0],zero,xmm22[1],zero,xmm22[2],zero,xmm22[3],zero,xmm22[4],zero,xmm22[5],zero,xmm22[6],zero,xmm22[7],zero
	vpmullw	%xmm14, %xmm20, %xmm14
	vpmovwb	%xmm14, %xmm14
	vpmovzxbw	%xmm15, %xmm15          ## xmm15 = xmm15[0],zero,xmm15[1],zero,xmm15[2],zero,xmm15[3],zero,xmm15[4],zero,xmm15[5],zero,xmm15[6],zero,xmm15[7],zero
	vpmovzxbw	%xmm23, %xmm20          ## xmm20 = xmm23[0],zero,xmm23[1],zero,xmm23[2],zero,xmm23[3],zero,xmm23[4],zero,xmm23[5],zero,xmm23[6],zero,xmm23[7],zero
	vpmullw	%xmm15, %xmm20, %xmm15
	vpmovwb	%xmm15, %xmm15
	vpmovsxbq	%xmm12, %zmm12
	vpmovsxbq	%xmm13, %zmm13
	vpmovsxbq	%xmm14, %zmm14
	vpmovsxbq	%xmm15, %zmm15
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm16, %xmm16          ## xmm16 = xmm16[0],zero,xmm16[1],zero,xmm16[2],zero,xmm16[3],zero,xmm16[4],zero,xmm16[5],zero,xmm16[6],zero,xmm16[7],zero
	vpmullw	%xmm8, %xmm16, %xmm8
	vpmovwb	%xmm8, %xmm8
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm17, %xmm16          ## xmm16 = xmm17[0],zero,xmm17[1],zero,xmm17[2],zero,xmm17[3],zero,xmm17[4],zero,xmm17[5],zero,xmm17[6],zero,xmm17[7],zero
	vpmullw	%xmm9, %xmm16, %xmm9
	vpmovwb	%xmm9, %xmm9
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmovzxbw	%xmm18, %xmm16          ## xmm16 = xmm18[0],zero,xmm18[1],zero,xmm18[2],zero,xmm18[3],zero,xmm18[4],zero,xmm18[5],zero,xmm18[6],zero,xmm18[7],zero
	vpmullw	%xmm10, %xmm16, %xmm10
	vpmovwb	%xmm10, %xmm10
	vpmovzxbw	%xmm11, %xmm11          ## xmm11 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmovzxbw	%xmm19, %xmm16          ## xmm16 = xmm19[0],zero,xmm19[1],zero,xmm19[2],zero,xmm19[3],zero,xmm19[4],zero,xmm19[5],zero,xmm19[6],zero,xmm19[7],zero
	vpmullw	%xmm11, %xmm16, %xmm11
	vpmovwb	%xmm11, %xmm11
	vpmovsxbq	%xmm8, %zmm8
	vpaddq	%zmm8, %zmm4, %zmm4
	vpaddq	%zmm12, %zmm4, %zmm4
	vpmovsxbq	%xmm9, %zmm8
	vpaddq	%zmm8, %zmm5, %zmm5
	vpaddq	%zmm13, %zmm5, %zmm5
	vpmovsxbq	%xmm10, %zmm8
	vpaddq	%zmm8, %zmm6, %zmm6
	vpaddq	%zmm14, %zmm6, %zmm6
	vpmovsxbq	%xmm11, %zmm8
	vpaddq	%zmm8, %zmm7, %zmm7
	vpaddq	%zmm15, %zmm7, %zmm7
	addq	$32, %rax
	addq	$-32, %rcx
	jne	LBB1_11
## %bb.12:                              ##   in Loop: Header=BB1_6 Depth=1
	vpaddq	%zmm4, %zmm5, %zmm4
	vpaddq	%zmm4, %zmm6, %zmm4
	vpaddq	%zmm4, %zmm7, %zmm4
	vextracti64x4	$1, %zmm4, %ymm5
	vpaddq	%zmm5, %zmm4, %zmm4
	vextracti128	$1, %ymm4, %xmm5
	vpaddq	%xmm5, %xmm4, %xmm4
	vpshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	vpaddq	%xmm5, %xmm4, %xmm4
	vmovq	%xmm4, %rcx
	testq	%rdi, %rdi
	je	LBB1_15
LBB1_13:                                ##   in Loop: Header=BB1_6 Depth=1
	movq	%rcx, %r14
	.p2align	4, 0x90
LBB1_14:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%r10,%r11), %r15d
	movl	%r15d, %edx
	shlb	$4, %dl
	sarb	$4, %dl
	movzbl	(%r13,%r11), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%dl
	movl	%eax, %edx
	sarb	$4, %r15b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r15b
	movsbq	%dl, %rdx
	movsbq	%al, %rcx
	addq	%r14, %rcx
	addq	%rdx, %rcx
	incq	%r11
	movq	%rcx, %r14
	cmpq	%r11, %rbx
	jne	LBB1_14
	jmp	LBB1_15
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	6, 0x0                          ## -- Begin function _ZN4zvec5turbo6avx5128internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
LCPI2_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI2_1:
	.space	16,240
LCPI2_2:
	.space	16,8
LCPI2_3:
	.space	16,15
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6avx5128internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.weak_def_can_be_hidden	__ZN4zvec5turbo6avx5128internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.p2align	4, 0x90
__ZN4zvec5turbo6avx5128internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf: ## @_ZN4zvec5turbo6avx5128internal28raw_inner_product_batch_implILm2EEEvPKhPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %r9
	shrq	%r9
	cmpq	$64, %rcx
	jae	LBB2_2
## %bb.1:
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r11d, %r11d
	vpxor	%xmm1, %xmm1, %xmm1
	jmp	LBB2_7
LBB2_2:
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	LBB2_5
## %bb.3:
	movq	8(%rdx), %rcx
	movq	(%rsi), %rdx
	movq	8(%rsi), %r10
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%ebx, %ebx
	vmovdqa64	LCPI2_0(%rip), %zmm2    ## zmm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB2_4:                                 ## =>This Inner Loop Header: Depth=1
	vpmovzxbw	(%rdi,%rbx), %zmm3      ## zmm3 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$8, %zmm3, %zmm4
	prefetcht0	(%rax,%rbx)
	prefetcht0	(%rcx,%rbx)
	vpsllw	$12, %zmm3, %zmm3
	vpsraw	$12, %zmm3, %zmm3
	vpsraw	$12, %zmm4, %zmm4
	vpmovzxbw	(%rdx,%rbx), %zmm5      ## zmm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm5, %zmm6
	vpsraw	$12, %zmm6, %zmm6
	vpsllw	$8, %zmm5, %zmm5
	vpsraw	$12, %zmm5, %zmm5
	vpmullw	%zmm3, %zmm6, %zmm6
	vpmaddwd	%zmm2, %zmm6, %zmm6
	vpaddd	%zmm1, %zmm6, %zmm1
	vpmullw	%zmm4, %zmm5, %zmm5
	vpmaddwd	%zmm2, %zmm5, %zmm5
	vpaddd	%zmm5, %zmm1, %zmm1
	vpmovzxbw	(%r10,%rbx), %zmm5      ## zmm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm5, %zmm6
	vpsraw	$12, %zmm6, %zmm6
	vpsllw	$8, %zmm5, %zmm5
	vpsraw	$12, %zmm5, %zmm5
	vpmullw	%zmm3, %zmm6, %zmm3
	vpmaddwd	%zmm2, %zmm3, %zmm3
	vpaddd	%zmm0, %zmm3, %zmm0
	vpmullw	%zmm4, %zmm5, %zmm3
	vpmaddwd	%zmm2, %zmm3, %zmm3
	vpaddd	%zmm3, %zmm0, %zmm0
	leaq	32(%rbx), %r11
	addq	$64, %rbx
	cmpq	%r9, %rbx
	movq	%r11, %rbx
	jbe	LBB2_4
	jmp	LBB2_7
LBB2_5:
	movq	(%rsi), %rax
	movq	8(%rsi), %rcx
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%edx, %edx
	vmovdqa64	LCPI2_0(%rip), %zmm2    ## zmm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB2_6:                                 ## =>This Inner Loop Header: Depth=1
	vpmovzxbw	(%rdi,%rdx), %zmm3      ## zmm3 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm3, %zmm4
	vpsraw	$12, %zmm4, %zmm4
	vpsllw	$8, %zmm3, %zmm3
	vpsraw	$12, %zmm3, %zmm3
	vpmovzxbw	(%rax,%rdx), %zmm5      ## zmm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm5, %zmm6
	vpsraw	$12, %zmm6, %zmm6
	vpsllw	$8, %zmm5, %zmm5
	vpsraw	$12, %zmm5, %zmm5
	vpmullw	%zmm4, %zmm6, %zmm6
	vpmaddwd	%zmm2, %zmm6, %zmm6
	vpaddd	%zmm1, %zmm6, %zmm1
	vpmullw	%zmm3, %zmm5, %zmm5
	vpmaddwd	%zmm2, %zmm5, %zmm5
	vpaddd	%zmm5, %zmm1, %zmm1
	vpmovzxbw	(%rcx,%rdx), %zmm5      ## zmm5 = mem[0],zero,mem[1],zero,mem[2],zero,mem[3],zero,mem[4],zero,mem[5],zero,mem[6],zero,mem[7],zero,mem[8],zero,mem[9],zero,mem[10],zero,mem[11],zero,mem[12],zero,mem[13],zero,mem[14],zero,mem[15],zero,mem[16],zero,mem[17],zero,mem[18],zero,mem[19],zero,mem[20],zero,mem[21],zero,mem[22],zero,mem[23],zero,mem[24],zero,mem[25],zero,mem[26],zero,mem[27],zero,mem[28],zero,mem[29],zero,mem[30],zero,mem[31],zero
	vpsllw	$12, %zmm5, %zmm6
	vpsraw	$12, %zmm6, %zmm6
	vpsllw	$8, %zmm5, %zmm5
	vpsraw	$12, %zmm5, %zmm5
	vpmullw	%zmm4, %zmm6, %zmm4
	vpmaddwd	%zmm2, %zmm4, %zmm4
	vpaddd	%zmm0, %zmm4, %zmm0
	vpmullw	%zmm3, %zmm5, %zmm3
	vpmaddwd	%zmm2, %zmm3, %zmm3
	vpaddd	%zmm3, %zmm0, %zmm0
	leaq	32(%rdx), %r11
	addq	$64, %rdx
	cmpq	%r9, %rdx
	movq	%r11, %rdx
	jbe	LBB2_6
LBB2_7:
	movq	%r9, %r10
	subq	%r11, %r10
	jbe	LBB2_8
## %bb.9:
	movq	(%rsi), %rbx
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %eax
	movslq	%eax, %rcx
	cmpq	$32, %r10
	jae	LBB2_11
## %bb.10:
	movq	%r11, %r14
	jmp	LBB2_14
LBB2_8:
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vcvtdq2ps	%xmm1, %xmm1
	vmovss	%xmm1, (%r8)
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vcvtdq2ps	%xmm0, %xmm0
	jmp	LBB2_24
LBB2_11:
	movq	%r10, %rax
	andq	$-32, %rax
	leaq	(%r11,%rax), %r14
	vmovq	%rcx, %xmm1
	leaq	(%rbx,%r11), %rcx
	addq	$24, %rcx
	leaq	(%rdi,%r11), %rdx
	addq	$24, %rdx
	vpxor	%xmm2, %xmm2, %xmm2
	xorl	%r15d, %r15d
	vmovdqa	LCPI2_1(%rip), %xmm3            ## xmm3 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI2_2(%rip), %xmm4            ## xmm4 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI2_3(%rip), %xmm5            ## xmm5 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vpxor	%xmm6, %xmm6, %xmm6
	vpxor	%xmm7, %xmm7, %xmm7
	.p2align	4, 0x90
LBB2_12:                                ## =>This Inner Loop Header: Depth=1
	vmovq	-24(%rcx,%r15), %xmm8           ## xmm8 = mem[0],zero
	vmovq	-16(%rcx,%r15), %xmm9           ## xmm9 = mem[0],zero
	vmovq	-8(%rcx,%r15), %xmm10           ## xmm10 = mem[0],zero
	vmovq	(%rcx,%r15), %xmm11             ## xmm11 = mem[0],zero
	vpsllw	$4, %xmm8, %xmm12
	vpand	%xmm3, %xmm12, %xmm12
	vpsrlw	$4, %xmm12, %xmm12
	vpxor	%xmm4, %xmm12, %xmm12
	vpsubb	%xmm4, %xmm12, %xmm12
	vpsllw	$4, %xmm9, %xmm13
	vpand	%xmm3, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm4, %xmm13, %xmm13
	vpsubb	%xmm4, %xmm13, %xmm13
	vpsllw	$4, %xmm10, %xmm14
	vpand	%xmm3, %xmm14, %xmm14
	vpsrlw	$4, %xmm14, %xmm14
	vpxor	%xmm4, %xmm14, %xmm14
	vpsubb	%xmm4, %xmm14, %xmm14
	vpsllw	$4, %xmm11, %xmm15
	vpand	%xmm3, %xmm15, %xmm15
	vpsrlw	$4, %xmm15, %xmm15
	vpxor	%xmm4, %xmm15, %xmm15
	vpsubb	%xmm4, %xmm15, %xmm15
	vpsrlw	$4, %xmm8, %xmm8
	vpternlogq	$108, %xmm5, %xmm4, %xmm8
	vpsubb	%xmm4, %xmm8, %xmm8
	vpsrlw	$4, %xmm9, %xmm9
	vpternlogq	$108, %xmm5, %xmm4, %xmm9
	vpsubb	%xmm4, %xmm9, %xmm9
	vpsrlw	$4, %xmm10, %xmm10
	vpternlogq	$108, %xmm5, %xmm4, %xmm10
	vpsubb	%xmm4, %xmm10, %xmm10
	vpsrlw	$4, %xmm11, %xmm11
	vpternlogq	$108, %xmm5, %xmm4, %xmm11
	vpsubb	%xmm4, %xmm11, %xmm11
	vmovq	-24(%rdx,%r15), %xmm16          ## xmm16 = mem[0],zero
	vmovq	-16(%rdx,%r15), %xmm17          ## xmm17 = mem[0],zero
	vmovq	-8(%rdx,%r15), %xmm18           ## xmm18 = mem[0],zero
	vmovq	(%rdx,%r15), %xmm19             ## xmm19 = mem[0],zero
	vpsllw	$4, %xmm16, %xmm20
	vpandq	%xmm3, %xmm20, %xmm20
	vpsrlw	$4, %xmm20, %xmm20
	vpxorq	%xmm4, %xmm20, %xmm20
	vpsubb	%xmm4, %xmm20, %xmm20
	vpsllw	$4, %xmm17, %xmm21
	vpandq	%xmm3, %xmm21, %xmm21
	vpsrlw	$4, %xmm21, %xmm21
	vpxorq	%xmm4, %xmm21, %xmm21
	vpsubb	%xmm4, %xmm21, %xmm21
	vpsllw	$4, %xmm18, %xmm22
	vpandq	%xmm3, %xmm22, %xmm22
	vpsrlw	$4, %xmm22, %xmm22
	vpxorq	%xmm4, %xmm22, %xmm22
	vpsubb	%xmm4, %xmm22, %xmm22
	vpsllw	$4, %xmm19, %xmm23
	vpandq	%xmm3, %xmm23, %xmm23
	vpsrlw	$4, %xmm23, %xmm23
	vpxorq	%xmm4, %xmm23, %xmm23
	vpsubb	%xmm4, %xmm23, %xmm23
	vpsrlw	$4, %xmm16, %xmm16
	vpternlogq	$108, %xmm5, %xmm4, %xmm16
	vpsubb	%xmm4, %xmm16, %xmm16
	vpsrlw	$4, %xmm17, %xmm17
	vpternlogq	$108, %xmm5, %xmm4, %xmm17
	vpsubb	%xmm4, %xmm17, %xmm17
	vpsrlw	$4, %xmm18, %xmm18
	vpternlogq	$108, %xmm5, %xmm4, %xmm18
	vpsubb	%xmm4, %xmm18, %xmm18
	vpsrlw	$4, %xmm19, %xmm19
	vpternlogq	$108, %xmm5, %xmm4, %xmm19
	vpsubb	%xmm4, %xmm19, %xmm19
	vpmovzxbw	%xmm12, %xmm12          ## xmm12 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmovzxbw	%xmm20, %xmm20          ## xmm20 = xmm20[0],zero,xmm20[1],zero,xmm20[2],zero,xmm20[3],zero,xmm20[4],zero,xmm20[5],zero,xmm20[6],zero,xmm20[7],zero
	vpmullw	%xmm12, %xmm20, %xmm12
	vpmovwb	%xmm12, %xmm12
	vpmovzxbw	%xmm13, %xmm13          ## xmm13 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmovzxbw	%xmm21, %xmm20          ## xmm20 = xmm21[0],zero,xmm21[1],zero,xmm21[2],zero,xmm21[3],zero,xmm21[4],zero,xmm21[5],zero,xmm21[6],zero,xmm21[7],zero
	vpmullw	%xmm13, %xmm20, %xmm13
	vpmovwb	%xmm13, %xmm13
	vpmovzxbw	%xmm14, %xmm14          ## xmm14 = xmm14[0],zero,xmm14[1],zero,xmm14[2],zero,xmm14[3],zero,xmm14[4],zero,xmm14[5],zero,xmm14[6],zero,xmm14[7],zero
	vpmovzxbw	%xmm22, %xmm20          ## xmm20 = xmm22[0],zero,xmm22[1],zero,xmm22[2],zero,xmm22[3],zero,xmm22[4],zero,xmm22[5],zero,xmm22[6],zero,xmm22[7],zero
	vpmullw	%xmm14, %xmm20, %xmm14
	vpmovwb	%xmm14, %xmm14
	vpmovzxbw	%xmm15, %xmm15          ## xmm15 = xmm15[0],zero,xmm15[1],zero,xmm15[2],zero,xmm15[3],zero,xmm15[4],zero,xmm15[5],zero,xmm15[6],zero,xmm15[7],zero
	vpmovzxbw	%xmm23, %xmm20          ## xmm20 = xmm23[0],zero,xmm23[1],zero,xmm23[2],zero,xmm23[3],zero,xmm23[4],zero,xmm23[5],zero,xmm23[6],zero,xmm23[7],zero
	vpmullw	%xmm15, %xmm20, %xmm15
	vpmovwb	%xmm15, %xmm15
	vpmovsxbq	%xmm12, %zmm12
	vpmovsxbq	%xmm13, %zmm13
	vpmovsxbq	%xmm14, %zmm14
	vpmovsxbq	%xmm15, %zmm15
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm16, %xmm16          ## xmm16 = xmm16[0],zero,xmm16[1],zero,xmm16[2],zero,xmm16[3],zero,xmm16[4],zero,xmm16[5],zero,xmm16[6],zero,xmm16[7],zero
	vpmullw	%xmm8, %xmm16, %xmm8
	vpmovwb	%xmm8, %xmm8
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm17, %xmm16          ## xmm16 = xmm17[0],zero,xmm17[1],zero,xmm17[2],zero,xmm17[3],zero,xmm17[4],zero,xmm17[5],zero,xmm17[6],zero,xmm17[7],zero
	vpmullw	%xmm9, %xmm16, %xmm9
	vpmovwb	%xmm9, %xmm9
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmovzxbw	%xmm18, %xmm16          ## xmm16 = xmm18[0],zero,xmm18[1],zero,xmm18[2],zero,xmm18[3],zero,xmm18[4],zero,xmm18[5],zero,xmm18[6],zero,xmm18[7],zero
	vpmullw	%xmm10, %xmm16, %xmm10
	vpmovwb	%xmm10, %xmm10
	vpmovzxbw	%xmm11, %xmm11          ## xmm11 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmovzxbw	%xmm19, %xmm16          ## xmm16 = xmm19[0],zero,xmm19[1],zero,xmm19[2],zero,xmm19[3],zero,xmm19[4],zero,xmm19[5],zero,xmm19[6],zero,xmm19[7],zero
	vpmullw	%xmm11, %xmm16, %xmm11
	vpmovwb	%xmm11, %xmm11
	vpmovsxbq	%xmm8, %zmm8
	vpaddq	%zmm8, %zmm1, %zmm1
	vpaddq	%zmm12, %zmm1, %zmm1
	vpmovsxbq	%xmm9, %zmm8
	vpaddq	%zmm8, %zmm2, %zmm2
	vpaddq	%zmm13, %zmm2, %zmm2
	vpmovsxbq	%xmm10, %zmm8
	vpaddq	%zmm8, %zmm6, %zmm6
	vpaddq	%zmm14, %zmm6, %zmm6
	vpmovsxbq	%xmm11, %zmm8
	vpaddq	%zmm8, %zmm7, %zmm7
	vpaddq	%zmm15, %zmm7, %zmm7
	addq	$32, %r15
	cmpq	%r15, %rax
	jne	LBB2_12
## %bb.13:
	vpaddq	%zmm1, %zmm2, %zmm1
	vpaddq	%zmm1, %zmm6, %zmm1
	vpaddq	%zmm1, %zmm7, %zmm1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddq	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %rcx
	cmpq	%rax, %r10
	je	LBB2_16
LBB2_14:
	movq	%rcx, %r15
	.p2align	4, 0x90
LBB2_15:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%r14), %r12d
	movl	%r12d, %edx
	shlb	$4, %dl
	sarb	$4, %dl
	movzbl	(%rdi,%r14), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%dl
	movl	%eax, %edx
	sarb	$4, %r12b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r12b
	movsbq	%dl, %rdx
	movsbq	%al, %rcx
	addq	%r15, %rcx
	addq	%rdx, %rcx
	incq	%r14
	movq	%rcx, %r15
	cmpq	%r14, %r9
	jne	LBB2_15
LBB2_16:
	vcvtsi2ss	%rcx, %xmm24, %xmm1
	vmovss	%xmm1, (%r8)
	movq	8(%rsi), %rsi
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %eax
	movslq	%eax, %rcx
	cmpq	$32, %r10
	jae	LBB2_18
## %bb.17:
	movq	%r11, %rbx
	jmp	LBB2_21
LBB2_18:
	movq	%r10, %rax
	andq	$-32, %rax
	leaq	(%r11,%rax), %rbx
	vmovq	%rcx, %xmm0
	leaq	(%rsi,%r11), %rcx
	addq	$24, %rcx
	leaq	(%rdi,%r11), %rdx
	addq	$24, %rdx
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%r11d, %r11d
	vmovdqa	LCPI2_1(%rip), %xmm2            ## xmm2 = [240,240,240,240,240,240,240,240,240,240,240,240,240,240,240,240]
	vmovdqa	LCPI2_2(%rip), %xmm3            ## xmm3 = [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8]
	vmovdqa	LCPI2_3(%rip), %xmm4            ## xmm4 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vpxor	%xmm5, %xmm5, %xmm5
	vpxor	%xmm6, %xmm6, %xmm6
	.p2align	4, 0x90
LBB2_19:                                ## =>This Inner Loop Header: Depth=1
	vmovq	-24(%rcx,%r11), %xmm7           ## xmm7 = mem[0],zero
	vmovq	-16(%rcx,%r11), %xmm8           ## xmm8 = mem[0],zero
	vmovq	-8(%rcx,%r11), %xmm9            ## xmm9 = mem[0],zero
	vmovq	(%rcx,%r11), %xmm10             ## xmm10 = mem[0],zero
	vpsllw	$4, %xmm7, %xmm11
	vpand	%xmm2, %xmm11, %xmm11
	vpsrlw	$4, %xmm11, %xmm11
	vpxor	%xmm3, %xmm11, %xmm11
	vpsubb	%xmm3, %xmm11, %xmm11
	vpsllw	$4, %xmm8, %xmm12
	vpand	%xmm2, %xmm12, %xmm12
	vpsrlw	$4, %xmm12, %xmm12
	vpxor	%xmm3, %xmm12, %xmm12
	vpsubb	%xmm3, %xmm12, %xmm12
	vpsllw	$4, %xmm9, %xmm13
	vpand	%xmm2, %xmm13, %xmm13
	vpsrlw	$4, %xmm13, %xmm13
	vpxor	%xmm3, %xmm13, %xmm13
	vpsubb	%xmm3, %xmm13, %xmm13
	vpsllw	$4, %xmm10, %xmm14
	vpand	%xmm2, %xmm14, %xmm14
	vpsrlw	$4, %xmm14, %xmm14
	vpxor	%xmm3, %xmm14, %xmm14
	vpsubb	%xmm3, %xmm14, %xmm14
	vpsrlw	$4, %xmm7, %xmm7
	vpternlogq	$108, %xmm4, %xmm3, %xmm7
	vpsubb	%xmm3, %xmm7, %xmm7
	vpsrlw	$4, %xmm8, %xmm8
	vpternlogq	$108, %xmm4, %xmm3, %xmm8
	vpsubb	%xmm3, %xmm8, %xmm8
	vpsrlw	$4, %xmm9, %xmm9
	vpternlogq	$108, %xmm4, %xmm3, %xmm9
	vpsubb	%xmm3, %xmm9, %xmm9
	vpsrlw	$4, %xmm10, %xmm10
	vpternlogq	$108, %xmm4, %xmm3, %xmm10
	vpsubb	%xmm3, %xmm10, %xmm10
	vmovq	-24(%rdx,%r11), %xmm15          ## xmm15 = mem[0],zero
	vmovq	-16(%rdx,%r11), %xmm16          ## xmm16 = mem[0],zero
	vmovq	-8(%rdx,%r11), %xmm17           ## xmm17 = mem[0],zero
	vmovq	(%rdx,%r11), %xmm18             ## xmm18 = mem[0],zero
	vpsllw	$4, %xmm15, %xmm19
	vpandq	%xmm2, %xmm19, %xmm19
	vpsrlw	$4, %xmm19, %xmm19
	vpxorq	%xmm3, %xmm19, %xmm19
	vpsubb	%xmm3, %xmm19, %xmm19
	vpsllw	$4, %xmm16, %xmm20
	vpandq	%xmm2, %xmm20, %xmm20
	vpsrlw	$4, %xmm20, %xmm20
	vpxorq	%xmm3, %xmm20, %xmm20
	vpsubb	%xmm3, %xmm20, %xmm20
	vpsllw	$4, %xmm17, %xmm21
	vpandq	%xmm2, %xmm21, %xmm21
	vpsrlw	$4, %xmm21, %xmm21
	vpxorq	%xmm3, %xmm21, %xmm21
	vpsubb	%xmm3, %xmm21, %xmm21
	vpsllw	$4, %xmm18, %xmm22
	vpandq	%xmm2, %xmm22, %xmm22
	vpsrlw	$4, %xmm22, %xmm22
	vpxorq	%xmm3, %xmm22, %xmm22
	vpsubb	%xmm3, %xmm22, %xmm22
	vpsrlw	$4, %xmm15, %xmm15
	vpternlogq	$108, %xmm4, %xmm3, %xmm15
	vpsubb	%xmm3, %xmm15, %xmm15
	vpsrlw	$4, %xmm16, %xmm16
	vpternlogq	$108, %xmm4, %xmm3, %xmm16
	vpsubb	%xmm3, %xmm16, %xmm16
	vpsrlw	$4, %xmm17, %xmm17
	vpternlogq	$108, %xmm4, %xmm3, %xmm17
	vpsubb	%xmm3, %xmm17, %xmm17
	vpsrlw	$4, %xmm18, %xmm18
	vpternlogq	$108, %xmm4, %xmm3, %xmm18
	vpsubb	%xmm3, %xmm18, %xmm18
	vpmovzxbw	%xmm11, %xmm11          ## xmm11 = xmm11[0],zero,xmm11[1],zero,xmm11[2],zero,xmm11[3],zero,xmm11[4],zero,xmm11[5],zero,xmm11[6],zero,xmm11[7],zero
	vpmovzxbw	%xmm19, %xmm19          ## xmm19 = xmm19[0],zero,xmm19[1],zero,xmm19[2],zero,xmm19[3],zero,xmm19[4],zero,xmm19[5],zero,xmm19[6],zero,xmm19[7],zero
	vpmullw	%xmm11, %xmm19, %xmm11
	vpmovwb	%xmm11, %xmm11
	vpmovzxbw	%xmm12, %xmm12          ## xmm12 = xmm12[0],zero,xmm12[1],zero,xmm12[2],zero,xmm12[3],zero,xmm12[4],zero,xmm12[5],zero,xmm12[6],zero,xmm12[7],zero
	vpmovzxbw	%xmm20, %xmm19          ## xmm19 = xmm20[0],zero,xmm20[1],zero,xmm20[2],zero,xmm20[3],zero,xmm20[4],zero,xmm20[5],zero,xmm20[6],zero,xmm20[7],zero
	vpmullw	%xmm12, %xmm19, %xmm12
	vpmovwb	%xmm12, %xmm12
	vpmovzxbw	%xmm13, %xmm13          ## xmm13 = xmm13[0],zero,xmm13[1],zero,xmm13[2],zero,xmm13[3],zero,xmm13[4],zero,xmm13[5],zero,xmm13[6],zero,xmm13[7],zero
	vpmovzxbw	%xmm21, %xmm19          ## xmm19 = xmm21[0],zero,xmm21[1],zero,xmm21[2],zero,xmm21[3],zero,xmm21[4],zero,xmm21[5],zero,xmm21[6],zero,xmm21[7],zero
	vpmullw	%xmm13, %xmm19, %xmm13
	vpmovwb	%xmm13, %xmm13
	vpmovzxbw	%xmm14, %xmm14          ## xmm14 = xmm14[0],zero,xmm14[1],zero,xmm14[2],zero,xmm14[3],zero,xmm14[4],zero,xmm14[5],zero,xmm14[6],zero,xmm14[7],zero
	vpmovzxbw	%xmm22, %xmm19          ## xmm19 = xmm22[0],zero,xmm22[1],zero,xmm22[2],zero,xmm22[3],zero,xmm22[4],zero,xmm22[5],zero,xmm22[6],zero,xmm22[7],zero
	vpmullw	%xmm14, %xmm19, %xmm14
	vpmovwb	%xmm14, %xmm14
	vpmovsxbq	%xmm11, %zmm11
	vpmovsxbq	%xmm12, %zmm12
	vpmovsxbq	%xmm13, %zmm13
	vpmovsxbq	%xmm14, %zmm14
	vpmovzxbw	%xmm7, %xmm7            ## xmm7 = xmm7[0],zero,xmm7[1],zero,xmm7[2],zero,xmm7[3],zero,xmm7[4],zero,xmm7[5],zero,xmm7[6],zero,xmm7[7],zero
	vpmovzxbw	%xmm15, %xmm15          ## xmm15 = xmm15[0],zero,xmm15[1],zero,xmm15[2],zero,xmm15[3],zero,xmm15[4],zero,xmm15[5],zero,xmm15[6],zero,xmm15[7],zero
	vpmullw	%xmm7, %xmm15, %xmm7
	vpmovwb	%xmm7, %xmm7
	vpmovzxbw	%xmm8, %xmm8            ## xmm8 = xmm8[0],zero,xmm8[1],zero,xmm8[2],zero,xmm8[3],zero,xmm8[4],zero,xmm8[5],zero,xmm8[6],zero,xmm8[7],zero
	vpmovzxbw	%xmm16, %xmm15          ## xmm15 = xmm16[0],zero,xmm16[1],zero,xmm16[2],zero,xmm16[3],zero,xmm16[4],zero,xmm16[5],zero,xmm16[6],zero,xmm16[7],zero
	vpmullw	%xmm8, %xmm15, %xmm8
	vpmovwb	%xmm8, %xmm8
	vpmovzxbw	%xmm9, %xmm9            ## xmm9 = xmm9[0],zero,xmm9[1],zero,xmm9[2],zero,xmm9[3],zero,xmm9[4],zero,xmm9[5],zero,xmm9[6],zero,xmm9[7],zero
	vpmovzxbw	%xmm17, %xmm15          ## xmm15 = xmm17[0],zero,xmm17[1],zero,xmm17[2],zero,xmm17[3],zero,xmm17[4],zero,xmm17[5],zero,xmm17[6],zero,xmm17[7],zero
	vpmullw	%xmm9, %xmm15, %xmm9
	vpmovwb	%xmm9, %xmm9
	vpmovzxbw	%xmm10, %xmm10          ## xmm10 = xmm10[0],zero,xmm10[1],zero,xmm10[2],zero,xmm10[3],zero,xmm10[4],zero,xmm10[5],zero,xmm10[6],zero,xmm10[7],zero
	vpmovzxbw	%xmm18, %xmm15          ## xmm15 = xmm18[0],zero,xmm18[1],zero,xmm18[2],zero,xmm18[3],zero,xmm18[4],zero,xmm18[5],zero,xmm18[6],zero,xmm18[7],zero
	vpmullw	%xmm10, %xmm15, %xmm10
	vpmovwb	%xmm10, %xmm10
	vpmovsxbq	%xmm7, %zmm7
	vpaddq	%zmm7, %zmm0, %zmm0
	vpaddq	%zmm11, %zmm0, %zmm0
	vpmovsxbq	%xmm8, %zmm7
	vpaddq	%zmm7, %zmm1, %zmm1
	vpaddq	%zmm12, %zmm1, %zmm1
	vpmovsxbq	%xmm9, %zmm7
	vpaddq	%zmm7, %zmm5, %zmm5
	vpaddq	%zmm13, %zmm5, %zmm5
	vpmovsxbq	%xmm10, %zmm7
	vpaddq	%zmm7, %zmm6, %zmm6
	vpaddq	%zmm14, %zmm6, %zmm6
	addq	$32, %r11
	cmpq	%r11, %rax
	jne	LBB2_19
## %bb.20:
	vpaddq	%zmm0, %zmm1, %zmm0
	vpaddq	%zmm0, %zmm5, %zmm0
	vpaddq	%zmm0, %zmm6, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddq	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rcx
	cmpq	%rax, %r10
	je	LBB2_23
LBB2_21:
	movq	%rcx, %r10
	.p2align	4, 0x90
LBB2_22:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rsi,%rbx), %r11d
	movl	%r11d, %edx
	shlb	$4, %dl
	sarb	$4, %dl
	movzbl	(%rdi,%rbx), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%dl
	movl	%eax, %edx
	sarb	$4, %r11b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r11b
	movsbq	%dl, %rdx
	movsbq	%al, %rcx
	addq	%r10, %rcx
	addq	%rdx, %rcx
	incq	%rbx
	movq	%rcx, %r10
	cmpq	%rbx, %r9
	jne	LBB2_22
LBB2_23:
	vcvtsi2ss	%rcx, %xmm24, %xmm0
LBB2_24:
	vmovss	%xmm0, 4(%r8)
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
