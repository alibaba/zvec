	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo6scalar27inner_product_int8_distanceEPKvS3_mPf
LCPI0_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6scalar27inner_product_int8_distanceEPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo6scalar27inner_product_int8_distanceEPKvS3_mPf: ## @_ZN4zvec5turbo6scalar27inner_product_int8_distanceEPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpl	$21, %edx
	jl	LBB0_9
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	addl	$-20, %edx
	leaq	-1(%rdx), %r8
	movl	%edx, %eax
	andl	$3, %eax
	cmpq	$3, %r8
	jae	LBB0_3
## %bb.2:
	xorps	%xmm0, %xmm0
	xorl	%r8d, %r8d
	jmp	LBB0_5
LBB0_3:
	movl	%edx, %r9d
	andl	$-4, %r9d
	xorps	%xmm0, %xmm0
	xorl	%r8d, %r8d
	.p2align	4, 0x90
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	movsbl	(%rdi,%r8), %r10d
	movsbl	(%rsi,%r8), %r11d
	imull	%r10d, %r11d
	xorps	%xmm1, %xmm1
	cvtsi2ss	%r11d, %xmm1
	movsbl	1(%rdi,%r8), %r10d
	movsbl	1(%rsi,%r8), %r11d
	imull	%r10d, %r11d
	xorps	%xmm2, %xmm2
	cvtsi2ss	%r11d, %xmm2
	movsbl	2(%rdi,%r8), %r10d
	movsbl	2(%rsi,%r8), %r11d
	imull	%r10d, %r11d
	xorps	%xmm3, %xmm3
	cvtsi2ss	%r11d, %xmm3
	addss	%xmm0, %xmm1
	addss	%xmm1, %xmm2
	movsbl	3(%rdi,%r8), %r10d
	movsbl	3(%rsi,%r8), %r11d
	imull	%r10d, %r11d
	xorps	%xmm0, %xmm0
	cvtsi2ss	%r11d, %xmm0
	addss	%xmm2, %xmm3
	addss	%xmm3, %xmm0
	addq	$4, %r8
	cmpq	%r8, %r9
	jne	LBB0_4
LBB0_5:
	testq	%rax, %rax
	je	LBB0_8
## %bb.6:
	leaq	(%rsi,%r8), %r9
	addq	%rdi, %r8
	xorl	%r10d, %r10d
	.p2align	4, 0x90
LBB0_7:                                 ## =>This Inner Loop Header: Depth=1
	movsbl	(%r8,%r10), %r11d
	movsbl	(%r9,%r10), %ebx
	imull	%r11d, %ebx
	xorps	%xmm1, %xmm1
	cvtsi2ss	%ebx, %xmm1
	addss	%xmm1, %xmm0
	incq	%r10
	cmpq	%r10, %rax
	jne	LBB0_7
LBB0_8:
	movss	(%rdi,%rdx), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%rdx), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%rdx), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm4
	mulss	%xmm3, %xmm4
	mulss	%xmm2, %xmm3
	mulss	8(%rsi,%rdx), %xmm3
	movss	4(%rsi,%rdx), %xmm5             ## xmm5 = mem[0],zero,zero,zero
	mulss	%xmm5, %xmm1
	mulss	8(%rdi,%rdx), %xmm1
	mulss	%xmm0, %xmm4
	xorps	%xmm0, %xmm0
	cvtsi2ss	%edx, %xmm0
	addss	%xmm4, %xmm3
	addss	%xmm3, %xmm1
	mulss	%xmm5, %xmm0
	mulss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	xorps	LCPI0_0(%rip), %xmm0
	movss	%xmm0, (%rcx)
	popq	%rbx
	popq	%rbp
LBB0_9:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo6scalar33inner_product_int8_batch_distanceEPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6scalar33inner_product_int8_batch_distanceEPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo6scalar33inner_product_int8_batch_distanceEPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo6scalar33inner_product_int8_batch_distanceEPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r8, -48(%rbp)                  ## 8-byte Spill
	testq	%rdx, %rdx
	je	LBB1_9
## %bb.1:
	cmpl	$21, %ecx
	jge	LBB1_2
LBB1_9:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB1_2:
	addl	$-20, %ecx
	cvtsi2ss	%ecx, %xmm0
	leaq	-1(%rcx), %r8
	movl	%ecx, %r9d
	andl	$3, %r9d
	movl	%ecx, %r10d
	andl	$-4, %r10d
	xorl	%r11d, %r11d
	movaps	LCPI1_0(%rip), %xmm1            ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	jmp	LBB1_3
	.p2align	4, 0x90
LBB1_8:                                 ##   in Loop: Header=BB1_3 Depth=1
	movss	(%rbx,%rcx), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movss	4(%rbx,%rcx), %xmm4             ## xmm4 = mem[0],zero,zero,zero
	movss	(%rsi,%rcx), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	movss	4(%rsi,%rcx), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	movaps	%xmm3, %xmm7
	mulss	%xmm5, %xmm7
	mulss	%xmm2, %xmm7
	mulss	%xmm4, %xmm5
	mulss	8(%rsi,%rcx), %xmm5
	addss	%xmm7, %xmm5
	mulss	%xmm6, %xmm3
	mulss	8(%rbx,%rcx), %xmm3
	addss	%xmm5, %xmm3
	mulss	%xmm0, %xmm6
	mulss	%xmm4, %xmm6
	addss	%xmm3, %xmm6
	xorps	%xmm1, %xmm6
	movq	-48(%rbp), %rax                 ## 8-byte Reload
	movss	%xmm6, (%rax,%r11,4)
	incq	%r11
	cmpq	%rdx, %r11
	je	LBB1_9
LBB1_3:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_4 Depth 2
                                        ##     Child Loop BB1_7 Depth 2
	movq	(%rdi,%r11,8), %rbx
	xorps	%xmm2, %xmm2
	xorl	%r14d, %r14d
	cmpq	$3, %r8
	jb	LBB1_5
	.p2align	4, 0x90
LBB1_4:                                 ##   Parent Loop BB1_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbl	(%rbx,%r14), %r15d
	movsbl	(%rsi,%r14), %r12d
	imull	%r15d, %r12d
	xorps	%xmm3, %xmm3
	cvtsi2ss	%r12d, %xmm3
	movsbl	1(%rbx,%r14), %r15d
	movsbl	1(%rsi,%r14), %r12d
	imull	%r15d, %r12d
	xorps	%xmm4, %xmm4
	cvtsi2ss	%r12d, %xmm4
	movsbl	2(%rbx,%r14), %r15d
	movsbl	2(%rsi,%r14), %r12d
	imull	%r15d, %r12d
	xorps	%xmm5, %xmm5
	cvtsi2ss	%r12d, %xmm5
	addss	%xmm2, %xmm3
	addss	%xmm3, %xmm4
	movsbl	3(%rbx,%r14), %r15d
	movsbl	3(%rsi,%r14), %r12d
	imull	%r15d, %r12d
	xorps	%xmm2, %xmm2
	cvtsi2ss	%r12d, %xmm2
	addss	%xmm4, %xmm5
	addss	%xmm5, %xmm2
	addq	$4, %r14
	cmpq	%r14, %r10
	jne	LBB1_4
LBB1_5:                                 ##   in Loop: Header=BB1_3 Depth=1
	testq	%r9, %r9
	je	LBB1_8
## %bb.6:                               ##   in Loop: Header=BB1_3 Depth=1
	leaq	(%rsi,%r14), %r15
	addq	%rbx, %r14
	xorl	%r12d, %r12d
	.p2align	4, 0x90
LBB1_7:                                 ##   Parent Loop BB1_3 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbl	(%r14,%r12), %r13d
	movsbl	(%r15,%r12), %eax
	imull	%r13d, %eax
	xorps	%xmm3, %xmm3
	cvtsi2ss	%eax, %xmm3
	addss	%xmm3, %xmm2
	incq	%r12
	cmpq	%r12, %r9
	jne	LBB1_7
	jmp	LBB1_8
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
