	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo11avx512_vnni20cosine_int8_distanceEPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI0_1:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI0_2:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo11avx512_vnni20cosine_int8_distanceEPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo11avx512_vnni20cosine_int8_distanceEPKvS3_mPf: ## @_ZN4zvec5turbo11avx512_vnni20cosine_int8_distanceEPKvS3_mPf
	.cfi_startproc
## %bb.0:
	addl	$-24, %edx
	testl	%edx, %edx
	jle	LBB0_39
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	%edx, %r8d
	leaq	(%rdi,%r8), %rax
	movl	%r8d, %r9d
	andl	$-64, %r9d
	leaq	(%rdi,%r9), %r10
	movl	%esi, %r11d
	orl	%edi, %r11d
	testb	$31, %r11b
	je	LBB0_4
## %bb.2:
	testq	%r9, %r9
	je	LBB0_3
## %bb.13:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqa	LCPI0_0(%rip), %ymm2            ## ymm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	movq	%rsi, %r9
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB0_14:                                ## =>This Inner Loop Header: Depth=1
	vmovdqu	(%rdi), %ymm3
	vmovdqu	32(%rdi), %ymm4
	vmovdqu	(%r9), %ymm5
	vmovdqu	32(%r9), %ymm6
	vpsignb	%ymm5, %ymm3, %ymm3
	vpsignb	%ymm6, %ymm4, %ymm4
	vpabsb	%ymm5, %ymm5
	vpabsb	%ymm6, %ymm6
	vpmaddubsw	%ymm3, %ymm5, %ymm3
	vpdpwssd	%ymm2, %ymm3, %ymm0
	vpmaddubsw	%ymm4, %ymm6, %ymm3
	vpdpwssd	%ymm2, %ymm3, %ymm1
	addq	$64, %rdi
	addq	$64, %r9
	cmpq	%r10, %rdi
	jne	LBB0_14
## %bb.15:
	movq	%r10, %rdi
	addq	$32, %r10
	cmpq	%r10, %rax
	jb	LBB0_18
LBB0_17:
	vmovdqu	(%rdi), %ymm2
	vmovdqu	(%r9), %ymm3
	vpsignb	%ymm3, %ymm2, %ymm2
	vpabsb	%ymm3, %ymm3
	vpmaddubsw	%ymm2, %ymm3, %ymm2
	vpdpwssd	LCPI0_0(%rip), %ymm2, %ymm0
	addq	$32, %rdi
	addq	$32, %r9
LBB0_18:
	leaq	16(%rdi), %r10
	cmpq	%r10, %rax
	jb	LBB0_21
## %bb.19:
	vmovdqu	(%rdi), %xmm3
	vmovdqu	(%r9), %xmm2
	jmp	LBB0_20
LBB0_4:
	testq	%r9, %r9
	je	LBB0_5
## %bb.6:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqa	LCPI0_0(%rip), %ymm2            ## ymm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	movq	%rsi, %r9
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB0_7:                                 ## =>This Inner Loop Header: Depth=1
	vmovdqa	(%rdi), %ymm3
	vmovdqa	32(%rdi), %ymm4
	vmovdqa	(%r9), %ymm5
	vmovdqa	32(%r9), %ymm6
	vpsignb	%ymm5, %ymm3, %ymm3
	vpsignb	%ymm6, %ymm4, %ymm4
	vpabsb	%ymm5, %ymm5
	vpabsb	%ymm6, %ymm6
	vpmaddubsw	%ymm3, %ymm5, %ymm3
	vpdpwssd	%ymm2, %ymm3, %ymm0
	vpmaddubsw	%ymm4, %ymm6, %ymm3
	vpdpwssd	%ymm2, %ymm3, %ymm1
	addq	$64, %rdi
	addq	$64, %r9
	cmpq	%r10, %rdi
	jne	LBB0_7
## %bb.8:
	movq	%r10, %rdi
	addq	$32, %r10
	cmpq	%r10, %rax
	jb	LBB0_11
LBB0_10:
	vmovdqa	(%rdi), %ymm2
	vmovdqa	(%r9), %ymm3
	vpsignb	%ymm3, %ymm2, %ymm2
	vpabsb	%ymm3, %ymm3
	vpmaddubsw	%ymm2, %ymm3, %ymm2
	vpdpwssd	LCPI0_0(%rip), %ymm2, %ymm0
	addq	$32, %rdi
	addq	$32, %r9
LBB0_11:
	leaq	16(%rdi), %r10
	cmpq	%r10, %rax
	jb	LBB0_21
## %bb.12:
	vmovdqa	(%rdi), %xmm3
	vmovdqa	(%r9), %xmm2
LBB0_20:
	vpsignb	%xmm2, %xmm3, %xmm3
	vpabsb	%xmm2, %xmm2
	vpmaddubsw	%xmm3, %xmm2, %xmm2
	vpmaddwd	LCPI0_1(%rip), %xmm2, %xmm2
	vpaddd	%ymm2, %ymm0, %ymm0
	addq	$16, %r9
	movq	%r10, %rdi
LBB0_21:
	vpaddd	%ymm1, %ymm0, %ymm0
	vphaddd	%ymm0, %ymm0, %ymm0
	vphaddd	%ymm0, %ymm0, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm0, %xmm1, %xmm0
	vcvtdq2ps	%xmm0, %xmm0
	movq	%rdi, %r10
	notq	%r10
	addq	%rax, %r10
	cmpq	$14, %r10
	ja	LBB0_38
## %bb.22:
	leaq	LJTI0_0(%rip), %r11
	movslq	(%r11,%r10,4), %r10
	addq	%r11, %r10
	jmpq	*%r10
LBB0_23:
	movsbl	14(%rdi), %r10d
	movsbl	14(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_24:
	movsbl	13(%rdi), %r10d
	movsbl	13(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_25:
	movsbl	12(%rdi), %r10d
	movsbl	12(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_26:
	movsbl	11(%rdi), %r10d
	movsbl	11(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_27:
	movsbl	10(%rdi), %r10d
	movsbl	10(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_28:
	movsbl	9(%rdi), %r10d
	movsbl	9(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_29:
	movsbl	8(%rdi), %r10d
	movsbl	8(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_30:
	movsbl	7(%rdi), %r10d
	movsbl	7(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_31:
	movsbl	6(%rdi), %r10d
	movsbl	6(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_32:
	movsbl	5(%rdi), %r10d
	movsbl	5(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_33:
	movsbl	4(%rdi), %r10d
	movsbl	4(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_34:
	movsbl	3(%rdi), %r10d
	movsbl	3(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_35:
	movsbl	2(%rdi), %r10d
	movsbl	2(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_36:
	movsbl	1(%rdi), %r10d
	movsbl	1(%r9), %r11d
	imull	%r10d, %r11d
	vcvtsi2ss	%r11d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_37:
	movsbl	(%rdi), %edi
	movsbl	(%r9), %r9d
	imull	%edi, %r9d
	vcvtsi2ss	%r9d, %xmm7, %xmm1
	vaddss	%xmm1, %xmm0, %xmm0
LBB0_38:
	vmovss	%xmm0, (%rcx)
	vmovss	(%rax), %xmm1                   ## xmm1 = mem[0],zero,zero,zero
	vmovss	4(%rax), %xmm2                  ## xmm2 = mem[0],zero,zero,zero
	vmovss	(%rsi,%r8), %xmm3               ## xmm3 = mem[0],zero,zero,zero
	vmovss	4(%rsi,%r8), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	vmulss	%xmm3, %xmm1, %xmm5
	vmulss	%xmm3, %xmm2, %xmm3
	vmulss	8(%rsi,%r8), %xmm3, %xmm3
	vfmadd231ss	%xmm5, %xmm0, %xmm3     ## xmm3 = (xmm0 * xmm5) + xmm3
	vmulss	%xmm4, %xmm1, %xmm0
	vfmadd132ss	8(%rax), %xmm3, %xmm0   ## xmm0 = (xmm0 * mem) + xmm3
	vcvtsi2ss	%edx, %xmm7, %xmm1
	vmulss	%xmm1, %xmm4, %xmm1
	vfmadd213ss	%xmm0, %xmm2, %xmm1     ## xmm1 = (xmm2 * xmm1) + xmm0
	vxorps	LCPI0_2(%rip){1to4}, %xmm1, %xmm0
	vmovss	%xmm0, (%rcx)
	popq	%rbp
LBB0_39:
	vzeroupper
	retq
LBB0_3:
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r9
	addq	$32, %r10
	cmpq	%r10, %rax
	jae	LBB0_17
	jmp	LBB0_18
LBB0_5:
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r9
	addq	$32, %r10
	cmpq	%r10, %rax
	jae	LBB0_10
	jmp	LBB0_11
	.cfi_endproc
	.p2align	2, 0x90
	.data_region jt32
.set L0_0_set_37, LBB0_37-LJTI0_0
.set L0_0_set_36, LBB0_36-LJTI0_0
.set L0_0_set_35, LBB0_35-LJTI0_0
.set L0_0_set_34, LBB0_34-LJTI0_0
.set L0_0_set_33, LBB0_33-LJTI0_0
.set L0_0_set_32, LBB0_32-LJTI0_0
.set L0_0_set_31, LBB0_31-LJTI0_0
.set L0_0_set_30, LBB0_30-LJTI0_0
.set L0_0_set_29, LBB0_29-LJTI0_0
.set L0_0_set_28, LBB0_28-LJTI0_0
.set L0_0_set_27, LBB0_27-LJTI0_0
.set L0_0_set_26, LBB0_26-LJTI0_0
.set L0_0_set_25, LBB0_25-LJTI0_0
.set L0_0_set_24, LBB0_24-LJTI0_0
.set L0_0_set_23, LBB0_23-LJTI0_0
LJTI0_0:
	.long	L0_0_set_37
	.long	L0_0_set_36
	.long	L0_0_set_35
	.long	L0_0_set_34
	.long	L0_0_set_33
	.long	L0_0_set_32
	.long	L0_0_set_31
	.long	L0_0_set_30
	.long	L0_0_set_29
	.long	L0_0_set_28
	.long	L0_0_set_27
	.long	L0_0_set_26
	.long	L0_0_set_25
	.long	L0_0_set_24
	.long	L0_0_set_23
	.end_data_region
                                        ## -- End function
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0                          ## -- Begin function _ZN4zvec5turbo11avx512_vnni26cosine_int8_batch_distanceEPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0xc3000000                      ## float -128
LCPI1_1:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo11avx512_vnni26cosine_int8_batch_distanceEPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo11avx512_vnni26cosine_int8_batch_distanceEPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo11avx512_vnni26cosine_int8_batch_distanceEPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	addl	$-24, %ecx
	testl	%ecx, %ecx
	jle	LBB1_80
## %bb.1:
	movq	%rsi, %rbx
	movl	%ecx, %r10d
	cmpq	$2, %rdx
	movq	%rdx, -64(%rbp)                 ## 8-byte Spill
	movq	%r8, -56(%rbp)                  ## 8-byte Spill
	movq	%rdi, -48(%rbp)                 ## 8-byte Spill
	movq	%rcx, -88(%rbp)                 ## 8-byte Spill
	jae	LBB1_33
## %bb.2:
	xorl	%r9d, %r9d
LBB1_3:
	cmpq	%rdx, %r9
	jae	LBB1_77
## %bb.4:
	cmpl	$64, -88(%rbp)                  ## 4-byte Folded Reload
	jae	LBB1_5
## %bb.10:
	cmpq	$2, %r10
	movl	$1, %eax
	cmovaeq	%r10, %rax
	cmpq	$8, %rax
	jae	LBB1_11
## %bb.14:
	movq	%r9, %rcx
	notq	%rcx
	testb	$1, %dl
	je	LBB1_18
## %bb.15:
	movq	(%rdi,%r9,8), %r15
	xorl	%esi, %esi
	xorl	%r12d, %r12d
	.p2align	4, 0x90
LBB1_16:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%rsi), %r11d
	movsbl	(%r15,%rsi), %r14d
	imull	%r11d, %r14d
	addl	%r14d, %r12d
	incq	%rsi
	cmpq	%rsi, %rax
	jne	LBB1_16
## %bb.17:
	vcvtsi2ss	%r12d, %xmm16, %xmm0
	vmovss	%xmm0, (%r8,%r9,4)
	orq	$1, %r9
LBB1_18:
	addq	%rdx, %rcx
	je	LBB1_77
	.p2align	4, 0x90
LBB1_19:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_20 Depth 2
                                        ##     Child Loop BB1_22 Depth 2
	movq	(%rdi,%r9,8), %rcx
	xorl	%r14d, %r14d
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB1_20:                                ##   Parent Loop BB1_19 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r14), %r15d
	movsbl	(%rcx,%r14), %r11d
	imull	%r15d, %r11d
	addl	%r11d, %esi
	incq	%r14
	cmpq	%r14, %rax
	jne	LBB1_20
## %bb.21:                              ##   in Loop: Header=BB1_19 Depth=1
	vcvtsi2ss	%esi, %xmm16, %xmm0
	vmovss	%xmm0, (%r8,%r9,4)
	movq	8(%rdi,%r9,8), %rcx
	xorl	%r14d, %r14d
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB1_22:                                ##   Parent Loop BB1_19 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r14), %r15d
	movsbl	(%rcx,%r14), %r11d
	imull	%r15d, %r11d
	addl	%r11d, %esi
	incq	%r14
	cmpq	%r14, %rax
	jne	LBB1_22
## %bb.23:                              ##   in Loop: Header=BB1_19 Depth=1
	vcvtsi2ss	%esi, %xmm16, %xmm0
	vmovss	%xmm0, 4(%r8,%r9,4)
	addq	$2, %r9
	cmpq	%rdx, %r9
	jne	LBB1_19
LBB1_77:
	testq	%rdx, %rdx
	movq	-88(%rbp), %rax                 ## 8-byte Reload
	je	LBB1_80
## %bb.78:
	vmovss	(%rbx,%r10), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	vmovss	4(%rbx,%r10), %xmm1             ## xmm1 = mem[0],zero,zero,zero
	vmovss	8(%rbx,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vcvtsi2ss	%eax, %xmm16, %xmm3
	vmulss	%xmm3, %xmm1, %xmm3
	xorl	%eax, %eax
	vmovss	LCPI1_0(%rip), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	vbroadcastss	LCPI1_1(%rip), %xmm5    ## xmm5 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_79:                                ## =>This Inner Loop Header: Depth=1
	movq	(%rdi,%rax,8), %rcx
	vcvtsi2ssl	16(%rcx,%r10), %xmm16, %xmm6
	vmovss	(%rcx,%r10), %xmm7              ## xmm7 = mem[0],zero,zero,zero
	vmovss	4(%rcx,%r10), %xmm8             ## xmm8 = mem[0],zero,zero,zero
	vfmadd213ss	(%r8,%rax,4), %xmm4, %xmm6 ## xmm6 = (xmm4 * xmm6) + mem
	vmulss	%xmm7, %xmm0, %xmm9
	vmulss	%xmm8, %xmm0, %xmm10
	vmulss	%xmm10, %xmm2, %xmm10
	vfmadd231ss	%xmm9, %xmm6, %xmm10    ## xmm10 = (xmm6 * xmm9) + xmm10
	vmulss	%xmm7, %xmm1, %xmm6
	vfmadd132ss	8(%rcx,%r10), %xmm10, %xmm6 ## xmm6 = (xmm6 * mem) + xmm10
	vfmadd231ss	%xmm8, %xmm3, %xmm6     ## xmm6 = (xmm3 * xmm8) + xmm6
	vxorps	%xmm5, %xmm6, %xmm6
	vmovss	%xmm6, (%r8,%rax,4)
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB1_79
LBB1_80:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
LBB1_33:
	movl	%r10d, %eax
	andl	$63, %eax
	movq	%rax, -72(%rbp)                 ## 8-byte Spill
	movl	%r10d, %eax
	andl	$7, %eax
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
	movl	%r10d, %eax
	andl	$-64, %eax
	movq	%rax, -96(%rbp)                 ## 8-byte Spill
	movl	%r10d, %r14d
	andl	$-8, %r14d
	movl	$2, %eax
	xorl	%r9d, %r9d
	jmp	LBB1_34
	.p2align	4, 0x90
LBB1_56:                                ##   in Loop: Header=BB1_34 Depth=1
	vcvtsi2ss	%ecx, %xmm16, %xmm0
	vcvtsi2ss	%edx, %xmm16, %xmm1
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	vmovss	%xmm0, (%r8,%r15,4)
	vmovss	%xmm1, 4(%r8,%r15,4)
	leaq	2(%r9), %rax
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, %rax
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	ja	LBB1_3
LBB1_34:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_38 Depth 2
                                        ##     Child Loop BB1_42 Depth 2
                                        ##     Child Loop BB1_50 Depth 2
                                        ##     Child Loop BB1_54 Depth 2
                                        ##     Child Loop BB1_83 Depth 2
	movq	%r9, %r15
	movq	%rax, %r9
	leaq	4(%r15), %rax
	cmpq	%rdx, %rax
	jae	LBB1_35
## %bb.57:                              ##   in Loop: Header=BB1_34 Depth=1
	movq	32(%rdi,%r15,8), %r8
	movq	-88(%rbp), %rcx                 ## 8-byte Reload
	leaq	5(%r15), %rax
	cmpq	%rdx, %rax
	jb	LBB1_60
LBB1_59:                                ##   in Loop: Header=BB1_34 Depth=1
	xorl	%eax, %eax
	cmpl	$64, %ecx
	jb	LBB1_62
LBB1_36:                                ##   in Loop: Header=BB1_34 Depth=1
	movq	(%rdi,%r15,8), %rcx
	movq	8(%rdi,%r15,8), %rsi
	vpxor	%xmm1, %xmm1, %xmm1
	testq	%r8, %r8
	je	LBB1_41
## %bb.37:                              ##   in Loop: Header=BB1_34 Depth=1
	xorl	%r12d, %r12d
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	LBB1_38
	.p2align	4, 0x90
LBB1_40:                                ##   in Loop: Header=BB1_38 Depth=2
	vpdpbusd	%zmm3, %zmm2, %zmm0
	leaq	64(%r12), %r11
	subq	$-128, %r12
	cmpq	%r10, %r12
	movq	%r11, %r12
	ja	LBB1_45
LBB1_38:                                ##   Parent Loop BB1_34 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovdqu64	(%rbx,%r12), %zmm2
	vmovdqu64	(%rsi,%r12), %zmm3
	prefetcht0	(%r8,%r12)
	vpdpbusd	(%rcx,%r12), %zmm2, %zmm1
	testq	%rax, %rax
	je	LBB1_40
## %bb.39:                              ##   in Loop: Header=BB1_38 Depth=2
	prefetcht0	(%rax,%r12)
	jmp	LBB1_40
	.p2align	4, 0x90
LBB1_35:                                ##   in Loop: Header=BB1_34 Depth=1
	xorl	%r8d, %r8d
	movq	-88(%rbp), %rcx                 ## 8-byte Reload
	leaq	5(%r15), %rax
	cmpq	%rdx, %rax
	jae	LBB1_59
LBB1_60:                                ##   in Loop: Header=BB1_34 Depth=1
	movq	40(%rdi,%r15,8), %rax
	cmpl	$64, %ecx
	jae	LBB1_36
LBB1_62:                                ##   in Loop: Header=BB1_34 Depth=1
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r11d, %r11d
LBB1_45:                                ##   in Loop: Header=BB1_34 Depth=1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %ecx
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %edx
	cmpq	%r10, %r11
	jae	LBB1_56
## %bb.46:                              ##   in Loop: Header=BB1_34 Depth=1
	movq	(%rdi,%r15,8), %r12
	movq	8(%rdi,%r15,8), %r13
	movq	%r10, %rax
	subq	%r11, %rax
	cmpq	$8, %rax
	jae	LBB1_47
LBB1_82:                                ##   in Loop: Header=BB1_34 Depth=1
	movq	%r11, %rax
	jmp	LBB1_83
	.p2align	4, 0x90
LBB1_47:                                ##   in Loop: Header=BB1_34 Depth=1
	cmpq	$64, %rax
	jae	LBB1_49
## %bb.48:                              ##   in Loop: Header=BB1_34 Depth=1
	xorl	%esi, %esi
	jmp	LBB1_53
LBB1_41:                                ##   in Loop: Header=BB1_34 Depth=1
	xorl	%edx, %edx
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	LBB1_42
	.p2align	4, 0x90
LBB1_44:                                ##   in Loop: Header=BB1_42 Depth=2
	vpdpbusd	%zmm3, %zmm2, %zmm0
	leaq	64(%rdx), %r11
	subq	$-128, %rdx
	cmpq	%r10, %rdx
	movq	%r11, %rdx
	ja	LBB1_45
LBB1_42:                                ##   Parent Loop BB1_34 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovdqu64	(%rbx,%rdx), %zmm2
	vmovdqu64	(%rsi,%rdx), %zmm3
	vpdpbusd	(%rcx,%rdx), %zmm2, %zmm1
	testq	%rax, %rax
	je	LBB1_44
## %bb.43:                              ##   in Loop: Header=BB1_42 Depth=2
	prefetcht0	(%rax,%rdx)
	jmp	LBB1_44
LBB1_49:                                ##   in Loop: Header=BB1_34 Depth=1
	movq	%rax, %rsi
	movq	-72(%rbp), %rdi                 ## 8-byte Reload
	subq	%rdi, %rsi
	vmovd	%edx, %xmm0
	vmovd	%ecx, %xmm4
	vpxor	%xmm1, %xmm1, %xmm1
	movq	%r11, %rcx
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm5, %xmm5, %xmm5
	vpxor	%xmm6, %xmm6, %xmm6
	vpxor	%xmm7, %xmm7, %xmm7
	movq	-96(%rbp), %rdx                 ## 8-byte Reload
	.p2align	4, 0x90
LBB1_50:                                ##   Parent Loop BB1_34 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rbx,%rcx), %zmm8      ## zmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	16(%rbx,%rcx), %zmm9    ## zmm9 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	32(%rbx,%rcx), %zmm10   ## zmm10 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	48(%rbx,%rcx), %zmm11   ## zmm11 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovsxbd	(%r12,%rcx), %zmm12
	vpmovsxbd	16(%r12,%rcx), %zmm13
	vpmovsxbd	32(%r12,%rcx), %zmm14
	vpmovsxbd	48(%r12,%rcx), %zmm15
	vpdpwssd	%zmm8, %zmm12, %zmm4
	vpdpwssd	%zmm9, %zmm13, %zmm5
	vpdpwssd	%zmm10, %zmm14, %zmm6
	vpdpwssd	%zmm11, %zmm15, %zmm7
	vpmovsxbd	(%r13,%rcx), %zmm12
	vpmovsxbd	16(%r13,%rcx), %zmm13
	vpmovsxbd	32(%r13,%rcx), %zmm14
	vpmovsxbd	48(%r13,%rcx), %zmm15
	vpdpwssd	%zmm8, %zmm12, %zmm0
	vpdpwssd	%zmm9, %zmm13, %zmm1
	vpdpwssd	%zmm10, %zmm14, %zmm2
	vpdpwssd	%zmm11, %zmm15, %zmm3
	addq	$64, %rcx
	cmpq	%rcx, %rdx
	jne	LBB1_50
## %bb.51:                              ##   in Loop: Header=BB1_34 Depth=1
	vpaddd	%zmm4, %zmm5, %zmm4
	vpaddd	%zmm7, %zmm6, %zmm5
	vpaddd	%zmm5, %zmm4, %zmm4
	vextracti64x4	$1, %zmm4, %ymm5
	vpaddd	%zmm5, %zmm4, %zmm4
	vextracti128	$1, %ymm4, %xmm5
	vpaddd	%xmm5, %xmm4, %xmm4
	vpshufd	$238, %xmm4, %xmm5              ## xmm5 = xmm4[2,3,2,3]
	vpaddd	%xmm5, %xmm4, %xmm4
	vpshufd	$85, %xmm4, %xmm5               ## xmm5 = xmm4[1,1,1,1]
	vpaddd	%xmm5, %xmm4, %xmm4
	vmovd	%xmm4, %ecx
	vpaddd	%zmm0, %zmm1, %zmm0
	vpaddd	%zmm3, %zmm2, %zmm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %edx
	testq	%rdi, %rdi
	je	LBB1_56
## %bb.52:                              ##   in Loop: Header=BB1_34 Depth=1
	cmpl	$8, %edi
	jae	LBB1_53
## %bb.81:                              ##   in Loop: Header=BB1_34 Depth=1
	addq	%rsi, %r11
	jmp	LBB1_82
LBB1_53:                                ##   in Loop: Header=BB1_34 Depth=1
	movq	-80(%rbp), %rdi                 ## 8-byte Reload
	subq	%rdi, %rax
	addq	%r11, %rax
	vmovd	%edx, %xmm0
	vmovd	%ecx, %xmm1
	addq	%r11, %rsi
	.p2align	4, 0x90
LBB1_54:                                ##   Parent Loop BB1_34 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rbx,%rsi), %ymm2      ## ymm2 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero
	vpmovsxbd	(%r12,%rsi), %ymm3
	vpmovsxbd	(%r13,%rsi), %ymm4
	vpdpwssd	%ymm2, %ymm3, %ymm1
	vpdpwssd	%ymm2, %ymm4, %ymm0
	addq	$8, %rsi
	cmpq	%rsi, %r14
	jne	LBB1_54
## %bb.55:                              ##   in Loop: Header=BB1_34 Depth=1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %ecx
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %edx
	testq	%rdi, %rdi
	je	LBB1_56
	.p2align	4, 0x90
LBB1_83:                                ##   Parent Loop BB1_34 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%rax), %esi
	movsbl	(%r12,%rax), %r11d
	imull	%esi, %r11d
	addl	%r11d, %ecx
	movsbl	(%r13,%rax), %r11d
	imull	%esi, %r11d
	addl	%r11d, %edx
	incq	%rax
	cmpq	%rax, %r10
	jne	LBB1_83
	jmp	LBB1_56
LBB1_5:
	cmpq	$127, %r10
	movl	$127, %ecx
	cmovaq	%r10, %rcx
	andl	$-64, %ecx
	leaq	1(%rcx), %rax
	cmpq	%r10, %rax
	cmovbeq	%r10, %rax
	movq	%rax, %r11
	subq	%rcx, %r11
	movl	%eax, %edx
	andl	$63, %edx
	movq	%r11, %rsi
	movq	%rdx, -96(%rbp)                 ## 8-byte Spill
	subq	%rdx, %rsi
	movq	%rsi, -72(%rbp)                 ## 8-byte Spill
	movl	%eax, %r15d
	andl	$-8, %r15d
	subq	%rcx, %r15
	movq	%rax, %rdx
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
                                        ## kill: def $eax killed $eax killed $rax def $rax
	andl	$-64, %eax
	subq	%rcx, %rax
	movq	%rax, -104(%rbp)                ## 8-byte Spill
	jmp	LBB1_6
	.p2align	4, 0x90
LBB1_9:                                 ##   in Loop: Header=BB1_6 Depth=1
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
LBB1_76:                                ##   in Loop: Header=BB1_6 Depth=1
	vcvtsi2ss	%eax, %xmm16, %xmm0
	vmovss	%xmm0, (%r8,%r9,4)
	incq	%r9
	cmpq	%rdx, %r9
	je	LBB1_77
LBB1_6:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_7 Depth 2
                                        ##     Child Loop BB1_68 Depth 2
                                        ##     Child Loop BB1_73 Depth 2
                                        ##     Child Loop BB1_75 Depth 2
	movq	(%rdi,%r9,8), %r14
	vpxor	%xmm0, %xmm0, %xmm0
	movl	$112, %edx
	movq	%rbx, %rsi
	movq	%r14, %r13
	xorl	%r12d, %r12d
	.p2align	4, 0x90
LBB1_7:                                 ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r12, %rdi
	movq	%rdx, %rcx
	vmovdqu64	(%rbx,%r12), %zmm1
	vpdpbusd	(%r14,%r12), %zmm1, %zmm0
	addq	$64, %r12
	subq	$-128, %rdi
	addq	$64, %rdx
	addq	$64, %r13
	addq	$64, %rsi
	cmpq	%r10, %rdi
	jbe	LBB1_7
## %bb.8:                               ##   in Loop: Header=BB1_6 Depth=1
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %eax
	cmpq	%r10, %r12
	jae	LBB1_9
## %bb.63:                              ##   in Loop: Header=BB1_6 Depth=1
	cmpq	$8, %r11
	jae	LBB1_65
LBB1_64:                                ##   in Loop: Header=BB1_6 Depth=1
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	jmp	LBB1_75
	.p2align	4, 0x90
LBB1_65:                                ##   in Loop: Header=BB1_6 Depth=1
	cmpq	$64, %r11
	jae	LBB1_67
## %bb.66:                              ##   in Loop: Header=BB1_6 Depth=1
	xorl	%edi, %edi
	jmp	LBB1_72
LBB1_67:                                ##   in Loop: Header=BB1_6 Depth=1
	vmovd	%eax, %xmm0
	vpxor	%xmm1, %xmm1, %xmm1
	movq	-72(%rbp), %rdx                 ## 8-byte Reload
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	.p2align	4, 0x90
LBB1_68:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	-48(%rbx,%rcx), %zmm4   ## zmm4 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	-32(%rbx,%rcx), %zmm5   ## zmm5 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	-16(%rbx,%rcx), %zmm6   ## zmm6 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	(%rbx,%rcx), %zmm7      ## zmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovsxbd	-48(%r14,%rcx), %zmm8
	vpdpwssd	%zmm4, %zmm8, %zmm0
	vpmovsxbd	-32(%r14,%rcx), %zmm4
	vpdpwssd	%zmm5, %zmm4, %zmm1
	vpmovsxbd	-16(%r14,%rcx), %zmm4
	vpmovsxbd	(%r14,%rcx), %zmm5
	vpdpwssd	%zmm6, %zmm4, %zmm2
	vpdpwssd	%zmm7, %zmm5, %zmm3
	addq	$64, %rcx
	addq	$-64, %rdx
	jne	LBB1_68
## %bb.69:                              ##   in Loop: Header=BB1_6 Depth=1
	vpaddd	%zmm0, %zmm1, %zmm0
	vpaddd	%zmm3, %zmm2, %zmm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %eax
	movq	-96(%rbp), %rcx                 ## 8-byte Reload
	testq	%rcx, %rcx
	je	LBB1_9
## %bb.70:                              ##   in Loop: Header=BB1_6 Depth=1
	cmpl	$8, %ecx
	jae	LBB1_71
## %bb.84:                              ##   in Loop: Header=BB1_6 Depth=1
	addq	-104(%rbp), %r12                ## 8-byte Folded Reload
	jmp	LBB1_64
LBB1_71:                                ##   in Loop: Header=BB1_6 Depth=1
	movq	-72(%rbp), %rdi                 ## 8-byte Reload
LBB1_72:                                ##   in Loop: Header=BB1_6 Depth=1
	addq	%r15, %r12
	vmovd	%eax, %xmm0
	addq	%rdi, %r13
	addq	%rdi, %rsi
	movq	%r15, %rcx
	subq	%rdi, %rcx
	xorl	%edx, %edx
	.p2align	4, 0x90
LBB1_73:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rsi,%rdx), %ymm1      ## ymm1 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero
	vpmovsxbd	(%r13,%rdx), %ymm2
	vpdpwssd	%ymm1, %ymm2, %ymm0
	addq	$8, %rdx
	cmpq	%rdx, %rcx
	jne	LBB1_73
## %bb.74:                              ##   in Loop: Header=BB1_6 Depth=1
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %eax
	testb	$7, -80(%rbp)                   ## 1-byte Folded Reload
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	movq	-56(%rbp), %r8                  ## 8-byte Reload
	movq	-48(%rbp), %rdi                 ## 8-byte Reload
	je	LBB1_76
	.p2align	4, 0x90
LBB1_75:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r12), %ecx
	movsbl	(%r14,%r12), %esi
	imull	%ecx, %esi
	addl	%esi, %eax
	incq	%r12
	cmpq	%r10, %r12
	jb	LBB1_75
	jmp	LBB1_76
LBB1_11:
	movl	%eax, %r11d
	andl	$-64, %r11d
	movl	%eax, %esi
	andl	$-8, %esi
	jmp	LBB1_12
	.p2align	4, 0x90
LBB1_32:                                ##   in Loop: Header=BB1_12 Depth=1
	vcvtsi2ss	%r12d, %xmm16, %xmm0
	vmovss	%xmm0, (%r8,%r9,4)
	incq	%r9
	cmpq	%rdx, %r9
	je	LBB1_77
LBB1_12:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_25 Depth 2
                                        ##     Child Loop BB1_29 Depth 2
                                        ##     Child Loop BB1_31 Depth 2
	movq	(%rdi,%r9,8), %rcx
	cmpl	$64, %eax
	jae	LBB1_24
## %bb.13:                              ##   in Loop: Header=BB1_12 Depth=1
	xorl	%r12d, %r12d
	xorl	%r14d, %r14d
	jmp	LBB1_28
	.p2align	4, 0x90
LBB1_24:                                ##   in Loop: Header=BB1_12 Depth=1
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r14d, %r14d
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	.p2align	4, 0x90
LBB1_25:                                ##   Parent Loop BB1_12 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rbx,%r14), %zmm4      ## zmm4 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	16(%rbx,%r14), %zmm5    ## zmm5 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	32(%rbx,%r14), %zmm6    ## zmm6 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	48(%rbx,%r14), %zmm7    ## zmm7 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovsxbd	(%rcx,%r14), %zmm8
	vpdpwssd	%zmm4, %zmm8, %zmm0
	vpmovsxbd	16(%rcx,%r14), %zmm4
	vpdpwssd	%zmm5, %zmm4, %zmm1
	vpmovsxbd	32(%rcx,%r14), %zmm4
	vpmovsxbd	48(%rcx,%r14), %zmm5
	vpdpwssd	%zmm6, %zmm4, %zmm2
	vpdpwssd	%zmm7, %zmm5, %zmm3
	addq	$64, %r14
	cmpq	%r14, %r11
	jne	LBB1_25
## %bb.26:                              ##   in Loop: Header=BB1_12 Depth=1
	vpaddd	%zmm0, %zmm1, %zmm0
	vpaddd	%zmm3, %zmm2, %zmm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %r12d
	cmpq	%r11, %rax
	je	LBB1_32
## %bb.27:                              ##   in Loop: Header=BB1_12 Depth=1
	movq	%r11, %r14
	movq	%r11, %r13
	testb	$56, %al
	je	LBB1_31
LBB1_28:                                ##   in Loop: Header=BB1_12 Depth=1
	vmovd	%r12d, %xmm0
	.p2align	4, 0x90
LBB1_29:                                ##   Parent Loop BB1_12 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rbx,%r14), %ymm1      ## ymm1 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero
	vpmovsxbd	(%rcx,%r14), %ymm2
	vpdpwssd	%ymm1, %ymm2, %ymm0
	addq	$8, %r14
	cmpq	%r14, %rsi
	jne	LBB1_29
## %bb.30:                              ##   in Loop: Header=BB1_12 Depth=1
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %r12d
	movq	%rsi, %r13
	cmpq	%rsi, %rax
	je	LBB1_32
	.p2align	4, 0x90
LBB1_31:                                ##   Parent Loop BB1_12 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r13), %r14d
	movsbl	(%rcx,%r13), %r15d
	imull	%r14d, %r15d
	addl	%r15d, %r12d
	incq	%r13
	cmpq	%r13, %rax
	jne	LBB1_31
	jmp	LBB1_32
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN4zvec5turbo11avx512_vnni28cosine_int8_query_preprocessEPvm
LCPI2_0:
	.quad	-9187201950435737472            ## 0x8080808080808080
	.section	__TEXT,__const
	.p2align	6, 0x0
LCPI2_1:
	.space	64,128
LCPI2_2:
	.space	32,128
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo11avx512_vnni28cosine_int8_query_preprocessEPvm
	.p2align	4, 0x90
__ZN4zvec5turbo11avx512_vnni28cosine_int8_query_preprocessEPvm: ## @_ZN4zvec5turbo11avx512_vnni28cosine_int8_query_preprocessEPvm
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	cmpl	$25, %esi
	jl	LBB2_12
## %bb.1:
	movl	$4294967272, %eax               ## imm = 0xFFFFFFE8
	addq	%rax, %rsi
	movl	%esi, %eax
	cmpq	$64, %rax
	jae	LBB2_18
## %bb.2:
	xorl	%edx, %edx
	jmp	LBB2_3
LBB2_18:
	xorl	%ecx, %ecx
	vbroadcastsd	LCPI2_0(%rip), %zmm0    ## zmm0 = [9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144]
	.p2align	4, 0x90
LBB2_19:                                ## =>This Inner Loop Header: Depth=1
	vxorps	(%rdi,%rcx), %zmm0, %zmm1
	vmovups	%zmm1, (%rdi,%rcx)
	leaq	64(%rcx), %rdx
	subq	$-128, %rcx
	cmpq	%rax, %rcx
	movq	%rdx, %rcx
	jbe	LBB2_19
LBB2_3:
	movq	%rax, %rcx
	subq	%rdx, %rcx
	jbe	LBB2_12
## %bb.4:
	cmpq	$32, %rcx
	jae	LBB2_6
## %bb.5:
	movq	%rdx, %rcx
	jmp	LBB2_11
LBB2_6:
	cmpq	$256, %rcx                      ## imm = 0x100
	jae	LBB2_13
## %bb.7:
	xorl	%r8d, %r8d
	jmp	LBB2_8
LBB2_13:
	movq	%rcx, %r8
	andq	$-256, %r8
	leaq	(%rdx,%rdi), %r9
	addq	$192, %r9
	xorl	%r10d, %r10d
	vmovaps	LCPI2_1(%rip), %zmm0            ## zmm0 = [128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128]
	.p2align	4, 0x90
LBB2_14:                                ## =>This Inner Loop Header: Depth=1
	vxorps	-192(%r9,%r10), %zmm0, %zmm1
	vxorps	-128(%r9,%r10), %zmm0, %zmm2
	vxorps	-64(%r9,%r10), %zmm0, %zmm3
	vxorps	(%r9,%r10), %zmm0, %zmm4
	vmovups	%zmm1, -192(%r9,%r10)
	vmovups	%zmm2, -128(%r9,%r10)
	vmovups	%zmm3, -64(%r9,%r10)
	vmovups	%zmm4, (%r9,%r10)
	addq	$256, %r10                      ## imm = 0x100
	cmpq	%r10, %r8
	jne	LBB2_14
## %bb.15:
	cmpq	%r8, %rcx
	je	LBB2_12
## %bb.16:
	testb	$-32, %cl
	je	LBB2_17
LBB2_8:
	andl	$31, %esi
	subq	%rsi, %rcx
	addq	%rdx, %rcx
	addq	%rdx, %r8
	vmovaps	LCPI2_2(%rip), %ymm0            ## ymm0 = [128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128]
	.p2align	4, 0x90
LBB2_9:                                 ## =>This Inner Loop Header: Depth=1
	vxorps	(%rdi,%r8), %ymm0, %ymm1
	vmovups	%ymm1, (%rdi,%r8)
	addq	$32, %r8
	cmpq	%r8, %rcx
	jne	LBB2_9
## %bb.10:
	testq	%rsi, %rsi
	je	LBB2_12
	.p2align	4, 0x90
LBB2_11:                                ## =>This Inner Loop Header: Depth=1
	xorb	$-128, (%rdi,%rcx)
	incq	%rcx
	cmpq	%rcx, %rax
	jne	LBB2_11
LBB2_12:
	popq	%rbp
	vzeroupper
	retq
LBB2_17:
	addq	%r8, %rdx
	movq	%rdx, %rcx
	jmp	LBB2_11
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
