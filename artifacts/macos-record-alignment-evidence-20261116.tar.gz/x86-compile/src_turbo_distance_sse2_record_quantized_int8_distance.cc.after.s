	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse232inner_product_int8_distance_sse2EPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
LCPI0_1:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse232inner_product_int8_distance_sse2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4sse232inner_product_int8_distance_sse2EPKvS3_mPf: ## @_ZN4zvec5turbo4sse232inner_product_int8_distance_sse2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$21, %rdx
	jb	LBB0_13
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	leaq	-20(%rdx), %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	cmpq	$16, %rax
	jb	LBB0_4
## %bb.2:
	movdqa	LCPI0_0(%rip), %xmm1            ## xmm1 = [1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB0_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r8, %r9
	movdqu	(%rdi,%r8), %xmm2
	pxor	%xmm3, %xmm3
	pcmpgtb	%xmm2, %xmm3
	movdqa	%xmm2, %xmm4
	punpcklbw	%xmm3, %xmm4            ## xmm4 = xmm4[0],xmm3[0],xmm4[1],xmm3[1],xmm4[2],xmm3[2],xmm4[3],xmm3[3],xmm4[4],xmm3[4],xmm4[5],xmm3[5],xmm4[6],xmm3[6],xmm4[7],xmm3[7]
	punpckhbw	%xmm3, %xmm2            ## xmm2 = xmm2[8],xmm3[8],xmm2[9],xmm3[9],xmm2[10],xmm3[10],xmm2[11],xmm3[11],xmm2[12],xmm3[12],xmm2[13],xmm3[13],xmm2[14],xmm3[14],xmm2[15],xmm3[15]
	movdqu	(%rsi,%r8), %xmm3
	pxor	%xmm5, %xmm5
	pcmpgtb	%xmm3, %xmm5
	movdqa	%xmm3, %xmm6
	punpcklbw	%xmm5, %xmm6            ## xmm6 = xmm6[0],xmm5[0],xmm6[1],xmm5[1],xmm6[2],xmm5[2],xmm6[3],xmm5[3],xmm6[4],xmm5[4],xmm6[5],xmm5[5],xmm6[6],xmm5[6],xmm6[7],xmm5[7]
	pmullw	%xmm4, %xmm6
	punpckhbw	%xmm5, %xmm3            ## xmm3 = xmm3[8],xmm5[8],xmm3[9],xmm5[9],xmm3[10],xmm5[10],xmm3[11],xmm5[11],xmm3[12],xmm5[12],xmm3[13],xmm5[13],xmm3[14],xmm5[14],xmm3[15],xmm5[15]
	pmullw	%xmm2, %xmm3
	pmaddwd	%xmm1, %xmm6
	paddd	%xmm0, %xmm6
	pmaddwd	%xmm1, %xmm3
	movdqa	%xmm3, %xmm0
	paddd	%xmm6, %xmm0
	addq	$16, %r8
	addq	$32, %r9
	cmpq	%rax, %r9
	jbe	LBB0_3
LBB0_4:
	movq	%xmm0, %r9
	movslq	%r9d, %r9
	pshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	movd	%xmm1, %r10d
	movslq	%r10d, %r10
	addq	%r9, %r10
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	movd	%xmm1, %r9d
	movslq	%r9d, %r11
	addq	%r10, %r11
	pshufd	$255, %xmm0, %xmm0              ## xmm0 = xmm0[3,3,3,3]
	movd	%xmm0, %r9d
	movslq	%r9d, %r9
	addq	%r11, %r9
	cmpq	%rax, %r8
	jae	LBB0_9
## %bb.5:
	movq	%rdx, %r10
	subq	%r8, %r10
	addq	$-21, %r10
	andq	$3, %rdx
	je	LBB0_7
	.p2align	4, 0x90
LBB0_6:                                 ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %r11
	movsbq	(%rsi,%r8), %rbx
	imulq	%r11, %rbx
	addq	%rbx, %r9
	incq	%r8
	decq	%rdx
	jne	LBB0_6
LBB0_7:
	cmpq	$3, %r10
	jb	LBB0_9
	.p2align	4, 0x90
LBB0_8:                                 ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %rdx
	movsbq	(%rsi,%r8), %r10
	imulq	%rdx, %r10
	addq	%r9, %r10
	movsbq	1(%rdi,%r8), %rdx
	movsbq	1(%rsi,%r8), %r9
	imulq	%rdx, %r9
	addq	%r10, %r9
	movsbq	2(%rdi,%r8), %rdx
	movsbq	2(%rsi,%r8), %r10
	imulq	%rdx, %r10
	addq	%r9, %r10
	movsbq	3(%rdi,%r8), %rdx
	movsbq	3(%rsi,%r8), %r9
	imulq	%rdx, %r9
	addq	%r10, %r9
	addq	$4, %r8
	cmpq	%r8, %rax
	jne	LBB0_8
LBB0_9:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%r9, %xmm3
	movss	(%rdi,%rax), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%rax), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%rax), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%rsi,%rax), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm5
	mulss	%xmm4, %xmm5
	mulss	%xmm3, %xmm5
	mulss	%xmm2, %xmm4
	mulss	8(%rsi,%rax), %xmm4
	addss	%xmm5, %xmm4
	mulss	%xmm0, %xmm1
	mulss	8(%rdi,%rax), %xmm1
	addss	%xmm4, %xmm1
	testq	%rax, %rax
	js	LBB0_10
## %bb.11:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	jmp	LBB0_12
LBB0_10:
	movq	%rax, %rdx
	shrq	%rdx
	andl	$1, %eax
	orq	%rdx, %rax
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	addss	%xmm3, %xmm3
LBB0_12:
	mulss	%xmm3, %xmm0
	mulss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	xorps	LCPI0_1(%rip), %xmm0
	movss	%xmm0, (%rcx)
	popq	%rbx
	popq	%rbp
LBB0_13:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse238inner_product_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse238inner_product_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4sse238inner_product_int8_batch_distance_sse2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4sse238inner_product_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$21, %rcx
	jb	LBB1_7
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %r14
	movq	%rdx, %r15
	movq	%rsi, %r12
	movq	%rdi, %r13
	addq	$-20, %r14
	movq	%r14, %rcx
	callq	__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKammPf
	testq	%r15, %r15
	je	LBB1_7
## %bb.2:
	testq	%r14, %r14
	js	LBB1_3
## %bb.4:
	cvtsi2ss	%r14, %xmm0
	jmp	LBB1_5
LBB1_3:
	movq	%r14, %rax
	shrq	%rax
	movl	%r14d, %ecx
	andl	$1, %ecx
	orq	%rax, %rcx
	cvtsi2ss	%rcx, %xmm0
	addss	%xmm0, %xmm0
LBB1_5:
	xorl	%eax, %eax
	movaps	LCPI1_0(%rip), %xmm1            ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r13,%rax,8), %rcx
	movss	(%rcx,%r14), %xmm2              ## xmm2 = mem[0],zero,zero,zero
	movss	4(%rcx,%r14), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	movss	(%r12,%r14), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%r12,%r14), %xmm5             ## xmm5 = mem[0],zero,zero,zero
	movaps	%xmm2, %xmm6
	mulss	%xmm4, %xmm6
	mulss	%xmm3, %xmm4
	mulss	8(%r12,%r14), %xmm4
	mulss	(%rbx,%rax,4), %xmm6
	addss	%xmm4, %xmm6
	mulss	%xmm5, %xmm2
	mulss	8(%rcx,%r14), %xmm2
	addss	%xmm6, %xmm2
	mulss	%xmm0, %xmm5
	mulss	%xmm3, %xmm5
	addss	%xmm2, %xmm5
	xorps	%xmm1, %xmm5
	movss	%xmm5, (%rbx,%rax,4)
	incq	%rax
	cmpq	%rax, %r15
	jne	LBB1_6
LBB1_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKammPf
LCPI2_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	4, 0x90
__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKammPf: ## @_ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKammPf
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r8, %r13
	cmpq	$2, %rdx
	movq	%r8, -56(%rbp)                  ## 8-byte Spill
	movq	%rdx, -48(%rbp)                 ## 8-byte Spill
	jae	LBB2_19
## %bb.1:
	xorl	%r8d, %r8d
LBB2_2:
	cmpq	%rdx, %r8
	jae	LBB2_10
## %bb.3:
	cmpq	$16, %rcx
	jae	LBB2_4
## %bb.11:
	testq	%rcx, %rcx
	je	LBB2_47
## %bb.12:
	movl	%ecx, %r9d
	andl	$3, %r9d
	movq	%rcx, %r10
	andq	$-4, %r10
	movq	-56(%rbp), %rax                 ## 8-byte Reload
	jmp	LBB2_13
	.p2align	4, 0x90
LBB2_18:                                ##   in Loop: Header=BB2_13 Depth=1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%rbx, %xmm0
	movss	%xmm0, (%rax,%r8,4)
	incq	%r8
	cmpq	-48(%rbp), %r8                  ## 8-byte Folded Reload
	je	LBB2_10
LBB2_13:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_14 Depth 2
                                        ##     Child Loop BB2_17 Depth 2
	movq	(%rdi,%r8,8), %r11
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	cmpq	$4, %rcx
	jb	LBB2_15
	.p2align	4, 0x90
LBB2_14:                                ##   Parent Loop BB2_13 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r11,%r14), %r15
	movsbq	(%rsi,%r14), %r12
	imulq	%r15, %r12
	addq	%rbx, %r12
	movsbq	1(%r11,%r14), %rbx
	movsbq	1(%rsi,%r14), %r15
	imulq	%rbx, %r15
	addq	%r12, %r15
	movsbq	2(%r11,%r14), %rbx
	movsbq	2(%rsi,%r14), %r12
	imulq	%rbx, %r12
	addq	%r15, %r12
	movsbq	3(%r11,%r14), %r15
	movsbq	3(%rsi,%r14), %rbx
	imulq	%r15, %rbx
	addq	%r12, %rbx
	addq	$4, %r14
	cmpq	%r14, %r10
	jne	LBB2_14
LBB2_15:                                ##   in Loop: Header=BB2_13 Depth=1
	testq	%r9, %r9
	je	LBB2_18
## %bb.16:                              ##   in Loop: Header=BB2_13 Depth=1
	leaq	(%rsi,%r14), %r15
	addq	%r14, %r11
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB2_17:                                ##   Parent Loop BB2_13 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r11,%r14), %r12
	movsbq	(%r15,%r14), %r13
	imulq	%r12, %r13
	addq	%r13, %rbx
	incq	%r14
	cmpq	%r14, %r9
	jne	LBB2_17
	jmp	LBB2_18
LBB2_19:
	movl	%ecx, %eax
	andl	$3, %eax
	movq	%rax, -64(%rbp)                 ## 8-byte Spill
	movl	$2, %r11d
	xorl	%r8d, %r8d
	movdqa	LCPI2_0(%rip), %xmm0            ## xmm0 = [1,1,1,1,1,1,1,1]
	jmp	LBB2_20
	.p2align	4, 0x90
LBB2_24:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	%xmm2, %r11
	movslq	%r11d, %r11
	pshufd	$85, %xmm2, %xmm3               ## xmm3 = xmm2[1,1,1,1]
	movd	%xmm3, %ebx
	movslq	%ebx, %rbx
	addq	%r11, %rbx
	pshufd	$238, %xmm2, %xmm3              ## xmm3 = xmm2[2,3,2,3]
	movd	%xmm3, %r11d
	movslq	%r11d, %r11
	addq	%rbx, %r11
	pshufd	$255, %xmm2, %xmm2              ## xmm2 = xmm2[3,3,3,3]
	movd	%xmm2, %ebx
	movslq	%ebx, %rbx
	addq	%r11, %rbx
	xorps	%xmm2, %xmm2
	cvtsi2ss	%rbx, %xmm2
	movss	%xmm2, (%r13,%r10,4)
	movq	%xmm1, %r11
	movslq	%r11d, %r11
	pshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	movd	%xmm2, %ebx
	movslq	%ebx, %rbx
	addq	%r11, %rbx
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	movd	%xmm2, %r11d
	movslq	%r11d, %r11
	addq	%rbx, %r11
	pshufd	$255, %xmm1, %xmm1              ## xmm1 = xmm1[3,3,3,3]
	movd	%xmm1, %ebx
	movslq	%ebx, %r15
	addq	%r11, %r15
LBB2_25:                                ##   in Loop: Header=BB2_20 Depth=1
	xorps	%xmm1, %xmm1
	cvtsi2ss	%r15, %xmm1
	movss	%xmm1, 4(%r13,%r10,4)
	leaq	2(%r8), %r11
	cmpq	%rdx, %r11
	ja	LBB2_2
LBB2_20:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_38 Depth 2
                                        ##     Child Loop BB2_29 Depth 2
                                        ##     Child Loop BB2_31 Depth 2
                                        ##     Child Loop BB2_34 Depth 2
                                        ##     Child Loop BB2_36 Depth 2
	movq	%r8, %r10
	movq	%r11, %r8
	leaq	4(%r10), %r11
	cmpq	%rdx, %r11
	jae	LBB2_21
## %bb.41:                              ##   in Loop: Header=BB2_20 Depth=1
	movq	32(%rdi,%r10,8), %rbx
	leaq	5(%r10), %rax
	cmpq	%rdx, %rax
	jb	LBB2_44
LBB2_43:                                ##   in Loop: Header=BB2_20 Depth=1
	xorl	%r14d, %r14d
	cmpq	$16, %rcx
	jb	LBB2_46
LBB2_37:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	(%rdi,%r10,8), %r15
	movq	8(%rdi,%r10,8), %r12
	pxor	%xmm1, %xmm1
	xorl	%r13d, %r13d
	pxor	%xmm2, %xmm2
	jmp	LBB2_38
	.p2align	4, 0x90
LBB2_40:                                ##   in Loop: Header=BB2_38 Depth=2
	pxor	%xmm5, %xmm5
	pcmpgtb	%xmm3, %xmm5
	movdqa	%xmm3, %xmm4
	punpcklbw	%xmm5, %xmm4            ## xmm4 = xmm4[0],xmm5[0],xmm4[1],xmm5[1],xmm4[2],xmm5[2],xmm4[3],xmm5[3],xmm4[4],xmm5[4],xmm4[5],xmm5[5],xmm4[6],xmm5[6],xmm4[7],xmm5[7]
	punpckhbw	%xmm5, %xmm3            ## xmm3 = xmm3[8],xmm5[8],xmm3[9],xmm5[9],xmm3[10],xmm5[10],xmm3[11],xmm5[11],xmm3[12],xmm5[12],xmm3[13],xmm5[13],xmm3[14],xmm5[14],xmm3[15],xmm5[15]
	movdqa	%xmm2, %xmm5
	movdqu	(%r15,%r13), %xmm2
	pxor	%xmm6, %xmm6
	pcmpgtb	%xmm2, %xmm6
	movdqa	%xmm2, %xmm7
	punpcklbw	%xmm6, %xmm7            ## xmm7 = xmm7[0],xmm6[0],xmm7[1],xmm6[1],xmm7[2],xmm6[2],xmm7[3],xmm6[3],xmm7[4],xmm6[4],xmm7[5],xmm6[5],xmm7[6],xmm6[6],xmm7[7],xmm6[7]
	punpckhbw	%xmm6, %xmm2            ## xmm2 = xmm2[8],xmm6[8],xmm2[9],xmm6[9],xmm2[10],xmm6[10],xmm2[11],xmm6[11],xmm2[12],xmm6[12],xmm2[13],xmm6[13],xmm2[14],xmm6[14],xmm2[15],xmm6[15]
	pmullw	%xmm4, %xmm7
	pmaddwd	%xmm0, %xmm7
	paddd	%xmm7, %xmm5
	pmullw	%xmm3, %xmm2
	pmaddwd	%xmm0, %xmm2
	paddd	%xmm5, %xmm2
	movdqa	%xmm1, %xmm5
	movdqu	(%r12,%r13), %xmm1
	pxor	%xmm6, %xmm6
	pcmpgtb	%xmm1, %xmm6
	movdqa	%xmm1, %xmm7
	punpcklbw	%xmm6, %xmm7            ## xmm7 = xmm7[0],xmm6[0],xmm7[1],xmm6[1],xmm7[2],xmm6[2],xmm7[3],xmm6[3],xmm7[4],xmm6[4],xmm7[5],xmm6[5],xmm7[6],xmm6[6],xmm7[7],xmm6[7]
	punpckhbw	%xmm6, %xmm1            ## xmm1 = xmm1[8],xmm6[8],xmm1[9],xmm6[9],xmm1[10],xmm6[10],xmm1[11],xmm6[11],xmm1[12],xmm6[12],xmm1[13],xmm6[13],xmm1[14],xmm6[14],xmm1[15],xmm6[15]
	pmullw	%xmm4, %xmm7
	pmaddwd	%xmm0, %xmm7
	paddd	%xmm7, %xmm5
	pmullw	%xmm3, %xmm1
	pmaddwd	%xmm0, %xmm1
	paddd	%xmm5, %xmm1
	leaq	16(%r13), %r11
	addq	$32, %r13
	cmpq	%rcx, %r13
	movq	%r11, %r13
	ja	LBB2_22
LBB2_38:                                ##   Parent Loop BB2_20 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movdqu	(%rsi,%r13), %xmm3
	testq	%rbx, %rbx
	je	LBB2_40
## %bb.39:                              ##   in Loop: Header=BB2_38 Depth=2
	prefetcht0	(%rbx,%r13)
	prefetcht0	(%r14,%r13)
	jmp	LBB2_40
	.p2align	4, 0x90
LBB2_21:                                ##   in Loop: Header=BB2_20 Depth=1
	xorl	%ebx, %ebx
	leaq	5(%r10), %rax
	cmpq	%rdx, %rax
	jae	LBB2_43
LBB2_44:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	40(%rdi,%r10,8), %r14
	cmpq	$16, %rcx
	jae	LBB2_37
LBB2_46:                                ##   in Loop: Header=BB2_20 Depth=1
	pxor	%xmm1, %xmm1
	pxor	%xmm2, %xmm2
	xorl	%r11d, %r11d
	cmpq	%rcx, %r11
	jae	LBB2_24
	jmp	LBB2_26
	.p2align	4, 0x90
LBB2_22:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	-56(%rbp), %r13                 ## 8-byte Reload
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rcx, %r11
	jae	LBB2_24
LBB2_26:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	%xmm2, %rbx
	movslq	%ebx, %rbx
	pshufd	$85, %xmm2, %xmm3               ## xmm3 = xmm2[1,1,1,1]
	movd	%xmm3, %r14d
	movslq	%r14d, %r14
	addq	%rbx, %r14
	pshufd	$238, %xmm2, %xmm3              ## xmm3 = xmm2[2,3,2,3]
	movd	%xmm3, %ebx
	movslq	%ebx, %rbx
	addq	%r14, %rbx
	pshufd	$255, %xmm2, %xmm2              ## xmm2 = xmm2[3,3,3,3]
	movd	%xmm2, %r14d
	movslq	%r14d, %r14
	addq	%rbx, %r14
	movq	%r11, %rbx
	notq	%rbx
	addq	%rcx, %rbx
	movq	(%rdi,%r10,8), %r15
	movq	-64(%rbp), %rdx                 ## 8-byte Reload
	testq	%rdx, %rdx
	je	LBB2_27
## %bb.28:                              ##   in Loop: Header=BB2_20 Depth=1
	movq	%rdx, %r13
	movq	%r11, %r12
	.p2align	4, 0x90
LBB2_29:                                ##   Parent Loop BB2_20 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r15,%r12), %r9
	movsbq	(%rsi,%r12), %rax
	imulq	%r9, %rax
	addq	%rax, %r14
	incq	%r12
	decq	%r13
	jne	LBB2_29
## %bb.30:                              ##   in Loop: Header=BB2_20 Depth=1
	cmpq	$3, %rbx
	jb	LBB2_32
	.p2align	4, 0x90
LBB2_31:                                ##   Parent Loop BB2_20 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r15,%r12), %rax
	movsbq	(%rsi,%r12), %r9
	imulq	%rax, %r9
	addq	%r14, %r9
	movsbq	1(%r15,%r12), %rax
	movsbq	1(%rsi,%r12), %r14
	imulq	%rax, %r14
	addq	%r9, %r14
	movsbq	2(%r15,%r12), %rax
	movsbq	2(%rsi,%r12), %r9
	imulq	%rax, %r9
	addq	%r14, %r9
	movsbq	3(%r15,%r12), %rax
	movsbq	3(%rsi,%r12), %r14
	imulq	%rax, %r14
	addq	%r9, %r14
	addq	$4, %r12
	cmpq	%r12, %rcx
	jne	LBB2_31
LBB2_32:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	%xmm1, %rax
	cltq
	pshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	movd	%xmm2, %r9d
	movslq	%r9d, %r9
	addq	%rax, %r9
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	movd	%xmm2, %eax
	cltq
	addq	%r9, %rax
	pshufd	$255, %xmm1, %xmm1              ## xmm1 = xmm1[3,3,3,3]
	movd	%xmm1, %r9d
	movslq	%r9d, %r15
	xorps	%xmm1, %xmm1
	cvtsi2ss	%r14, %xmm1
	addq	%rax, %r15
	movq	-56(%rbp), %r13                 ## 8-byte Reload
	movss	%xmm1, (%r13,%r10,4)
	movq	8(%rdi,%r10,8), %r14
	testb	$3, %cl
	je	LBB2_35
## %bb.33:                              ##   in Loop: Header=BB2_20 Depth=1
	movq	%rdx, %r12
	.p2align	4, 0x90
LBB2_34:                                ##   Parent Loop BB2_20 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r14,%r11), %rax
	movsbq	(%rsi,%r11), %r9
	imulq	%rax, %r9
	addq	%r9, %r15
	incq	%r11
	decq	%r12
	jne	LBB2_34
LBB2_35:                                ##   in Loop: Header=BB2_20 Depth=1
	cmpq	$3, %rbx
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	jb	LBB2_25
	.p2align	4, 0x90
LBB2_36:                                ##   Parent Loop BB2_20 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r14,%r11), %rax
	movsbq	(%rsi,%r11), %r9
	imulq	%rax, %r9
	addq	%r15, %r9
	movsbq	1(%r14,%r11), %rax
	movsbq	1(%rsi,%r11), %rbx
	imulq	%rax, %rbx
	addq	%r9, %rbx
	movsbq	2(%r14,%r11), %rax
	movsbq	2(%rsi,%r11), %r9
	imulq	%rax, %r9
	addq	%rbx, %r9
	movsbq	3(%r14,%r11), %rax
	movsbq	3(%rsi,%r11), %r15
	imulq	%rax, %r15
	addq	%r9, %r15
	addq	$4, %r11
	cmpq	%r11, %rcx
	jne	LBB2_36
	jmp	LBB2_25
LBB2_27:                                ##   in Loop: Header=BB2_20 Depth=1
	movq	%r11, %r12
	cmpq	$3, %rbx
	jae	LBB2_31
	jmp	LBB2_32
LBB2_4:
	movdqa	LCPI2_0(%rip), %xmm0            ## xmm0 = [1,1,1,1,1,1,1,1]
	jmp	LBB2_5
	.p2align	4, 0x90
LBB2_9:                                 ##   in Loop: Header=BB2_5 Depth=1
	xorps	%xmm1, %xmm1
	cvtsi2ss	%r11, %xmm1
	movss	%xmm1, (%r13,%r8,4)
	incq	%r8
	cmpq	%rdx, %r8
	je	LBB2_10
LBB2_5:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB2_6 Depth 2
                                        ##     Child Loop BB2_8 Depth 2
	movq	(%rdi,%r8,8), %r9
	xorl	%r10d, %r10d
	xorps	%xmm1, %xmm1
	.p2align	4, 0x90
LBB2_6:                                 ##   Parent Loop BB2_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%r10, %r11
	movdqu	(%rsi,%r10), %xmm2
	pxor	%xmm3, %xmm3
	pcmpgtb	%xmm2, %xmm3
	movdqa	%xmm2, %xmm4
	punpcklbw	%xmm3, %xmm4            ## xmm4 = xmm4[0],xmm3[0],xmm4[1],xmm3[1],xmm4[2],xmm3[2],xmm4[3],xmm3[3],xmm4[4],xmm3[4],xmm4[5],xmm3[5],xmm4[6],xmm3[6],xmm4[7],xmm3[7]
	punpckhbw	%xmm3, %xmm2            ## xmm2 = xmm2[8],xmm3[8],xmm2[9],xmm3[9],xmm2[10],xmm3[10],xmm2[11],xmm3[11],xmm2[12],xmm3[12],xmm2[13],xmm3[13],xmm2[14],xmm3[14],xmm2[15],xmm3[15]
	movdqu	(%r9,%r10), %xmm3
	pxor	%xmm5, %xmm5
	pcmpgtb	%xmm3, %xmm5
	movdqa	%xmm3, %xmm6
	punpcklbw	%xmm5, %xmm6            ## xmm6 = xmm6[0],xmm5[0],xmm6[1],xmm5[1],xmm6[2],xmm5[2],xmm6[3],xmm5[3],xmm6[4],xmm5[4],xmm6[5],xmm5[5],xmm6[6],xmm5[6],xmm6[7],xmm5[7]
	pmullw	%xmm4, %xmm6
	punpckhbw	%xmm5, %xmm3            ## xmm3 = xmm3[8],xmm5[8],xmm3[9],xmm5[9],xmm3[10],xmm5[10],xmm3[11],xmm5[11],xmm3[12],xmm5[12],xmm3[13],xmm5[13],xmm3[14],xmm5[14],xmm3[15],xmm5[15]
	pmullw	%xmm2, %xmm3
	pmaddwd	%xmm0, %xmm6
	paddd	%xmm1, %xmm6
	pmaddwd	%xmm0, %xmm3
	movdqa	%xmm3, %xmm1
	paddd	%xmm6, %xmm1
	addq	$16, %r10
	addq	$32, %r11
	cmpq	%rcx, %r11
	jbe	LBB2_6
## %bb.7:                               ##   in Loop: Header=BB2_5 Depth=1
	movq	%xmm1, %rax
	cltq
	pshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	movd	%xmm2, %r11d
	movslq	%r11d, %r11
	addq	%rax, %r11
	pshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	movd	%xmm2, %eax
	cltq
	addq	%r11, %rax
	pshufd	$255, %xmm1, %xmm1              ## xmm1 = xmm1[3,3,3,3]
	movd	%xmm1, %r11d
	movslq	%r11d, %r11
	addq	%rax, %r11
	cmpq	%rcx, %r10
	jae	LBB2_9
	.p2align	4, 0x90
LBB2_8:                                 ##   Parent Loop BB2_5 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%r9,%r10), %rax
	movsbq	(%rsi,%r10), %rbx
	imulq	%rax, %rbx
	addq	%rbx, %r11
	incq	%r10
	cmpq	%r10, %rcx
	jne	LBB2_8
	jmp	LBB2_9
LBB2_10:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
LBB2_47:
	leaq	(,%r8,4), %rdi
	addq	%r13, %rdi
	subq	%r8, %rdx
	shlq	$2, %rdx
	movq	%rdx, %rsi
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	jmp	___bzero                        ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse236squared_euclidean_int8_distance_sse2EPKvS3_mPf
LCPI3_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI3_1:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse236squared_euclidean_int8_distance_sse2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4sse236squared_euclidean_int8_distance_sse2EPKvS3_mPf: ## @_ZN4zvec5turbo4sse236squared_euclidean_int8_distance_sse2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$21, %rdx
	jb	LBB3_13
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	leaq	-20(%rdx), %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	cmpq	$16, %rax
	jb	LBB3_4
## %bb.2:
	movdqa	LCPI3_0(%rip), %xmm1            ## xmm1 = [1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB3_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r8, %r9
	movdqu	(%rdi,%r8), %xmm2
	pxor	%xmm3, %xmm3
	pcmpgtb	%xmm2, %xmm3
	movdqa	%xmm2, %xmm4
	punpcklbw	%xmm3, %xmm4            ## xmm4 = xmm4[0],xmm3[0],xmm4[1],xmm3[1],xmm4[2],xmm3[2],xmm4[3],xmm3[3],xmm4[4],xmm3[4],xmm4[5],xmm3[5],xmm4[6],xmm3[6],xmm4[7],xmm3[7]
	punpckhbw	%xmm3, %xmm2            ## xmm2 = xmm2[8],xmm3[8],xmm2[9],xmm3[9],xmm2[10],xmm3[10],xmm2[11],xmm3[11],xmm2[12],xmm3[12],xmm2[13],xmm3[13],xmm2[14],xmm3[14],xmm2[15],xmm3[15]
	movdqu	(%rsi,%r8), %xmm3
	pxor	%xmm5, %xmm5
	pcmpgtb	%xmm3, %xmm5
	movdqa	%xmm3, %xmm6
	punpcklbw	%xmm5, %xmm6            ## xmm6 = xmm6[0],xmm5[0],xmm6[1],xmm5[1],xmm6[2],xmm5[2],xmm6[3],xmm5[3],xmm6[4],xmm5[4],xmm6[5],xmm5[5],xmm6[6],xmm5[6],xmm6[7],xmm5[7]
	pmullw	%xmm4, %xmm6
	punpckhbw	%xmm5, %xmm3            ## xmm3 = xmm3[8],xmm5[8],xmm3[9],xmm5[9],xmm3[10],xmm5[10],xmm3[11],xmm5[11],xmm3[12],xmm5[12],xmm3[13],xmm5[13],xmm3[14],xmm5[14],xmm3[15],xmm5[15]
	pmullw	%xmm2, %xmm3
	pmaddwd	%xmm1, %xmm6
	paddd	%xmm0, %xmm6
	pmaddwd	%xmm1, %xmm3
	movdqa	%xmm3, %xmm0
	paddd	%xmm6, %xmm0
	addq	$16, %r8
	addq	$32, %r9
	cmpq	%rax, %r9
	jbe	LBB3_3
LBB3_4:
	movq	%xmm0, %r9
	movslq	%r9d, %r9
	pshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	movd	%xmm1, %r10d
	movslq	%r10d, %r10
	addq	%r9, %r10
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	movd	%xmm1, %r9d
	movslq	%r9d, %r11
	addq	%r10, %r11
	pshufd	$255, %xmm0, %xmm0              ## xmm0 = xmm0[3,3,3,3]
	movd	%xmm0, %r9d
	movslq	%r9d, %r9
	addq	%r11, %r9
	cmpq	%rax, %r8
	jae	LBB3_9
## %bb.5:
	movq	%rdx, %r10
	subq	%r8, %r10
	addq	$-21, %r10
	andq	$3, %rdx
	je	LBB3_7
	.p2align	4, 0x90
LBB3_6:                                 ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %r11
	movsbq	(%rsi,%r8), %rbx
	imulq	%r11, %rbx
	addq	%rbx, %r9
	incq	%r8
	decq	%rdx
	jne	LBB3_6
LBB3_7:
	cmpq	$3, %r10
	jb	LBB3_9
	.p2align	4, 0x90
LBB3_8:                                 ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %rdx
	movsbq	(%rsi,%r8), %r10
	imulq	%rdx, %r10
	addq	%r9, %r10
	movsbq	1(%rdi,%r8), %rdx
	movsbq	1(%rsi,%r8), %r9
	imulq	%rdx, %r9
	addq	%r10, %r9
	movsbq	2(%rdi,%r8), %rdx
	movsbq	2(%rsi,%r8), %r10
	imulq	%rdx, %r10
	addq	%r9, %r10
	movsbq	3(%rdi,%r8), %rdx
	movsbq	3(%rsi,%r8), %r9
	imulq	%rdx, %r9
	addq	%r10, %r9
	addq	$4, %r8
	cmpq	%r8, %rax
	jne	LBB3_8
LBB3_9:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%r9, %xmm3
	movss	(%rsi,%rax), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm0, %xmm4
	mulss	%xmm0, %xmm4
	mulss	12(%rsi,%rax), %xmm4
	movss	(%rdi,%rax), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm5
	mulss	%xmm1, %xmm5
	mulss	12(%rdi,%rax), %xmm5
	movss	4(%rdi,%rax), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	addss	%xmm4, %xmm5
	movss	LCPI3_1(%rip), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	mulss	%xmm1, %xmm4
	mulss	%xmm0, %xmm4
	mulss	%xmm3, %xmm4
	subss	4(%rsi,%rax), %xmm2
	addss	%xmm5, %xmm4
	movaps	%xmm2, %xmm3
	mulss	%xmm2, %xmm3
	testq	%rax, %rax
	js	LBB3_10
## %bb.11:
	xorps	%xmm5, %xmm5
	cvtsi2ss	%rax, %xmm5
	jmp	LBB3_12
LBB3_10:
	movq	%rax, %rdx
	shrq	%rdx
	movl	%eax, %r8d
	andl	$1, %r8d
	orq	%rdx, %r8
	xorps	%xmm5, %xmm5
	cvtsi2ss	%r8, %xmm5
	addss	%xmm5, %xmm5
LBB3_12:
	mulss	%xmm5, %xmm3
	addss	%xmm4, %xmm3
	addss	%xmm2, %xmm2
	mulss	8(%rsi,%rax), %xmm0
	mulss	8(%rdi,%rax), %xmm1
	subss	%xmm0, %xmm1
	mulss	%xmm2, %xmm1
	addss	%xmm3, %xmm1
	movss	%xmm1, (%rcx)
	popq	%rbx
	popq	%rbp
LBB3_13:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse242squared_euclidean_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
LCPI4_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI4_1:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse242squared_euclidean_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4sse242squared_euclidean_int8_batch_distance_sse2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4sse242squared_euclidean_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$21, %rcx
	jb	LBB4_7
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %rax
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	leaq	-20(%rcx), %r13
	movq	%r13, %rcx
	movq	%rax, -48(%rbp)                 ## 8-byte Spill
	callq	__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKammPf
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	testq	%r14, %r14
	je	LBB4_7
## %bb.2:
	movss	-20(%r15,%rdx), %xmm0           ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm0, %xmm1
	mulss	%xmm0, %xmm1
	testq	%r13, %r13
	js	LBB4_3
## %bb.4:
	cvtsi2ss	%r13, %xmm2
	jmp	LBB4_5
LBB4_3:
	movq	%r13, %rax
	shrq	%rax
	movl	%r13d, %ecx
	andl	$1, %ecx
	orq	%rax, %rcx
	cvtsi2ss	%rcx, %xmm2
	addss	%xmm2, %xmm2
LBB4_5:
	mulss	-8(%r15,%rdx), %xmm1
	xorps	LCPI4_0(%rip), %xmm0
	mulss	8(%r15,%r13), %xmm0
	xorl	%eax, %eax
	movss	LCPI4_1(%rip), %xmm3            ## xmm3 = mem[0],zero,zero,zero
	.p2align	4, 0x90
LBB4_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r12,%rax,8), %rcx
	movss	(%rcx,%r13), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movaps	%xmm4, %xmm5
	mulss	%xmm4, %xmm5
	mulss	12(%rcx,%r13), %xmm5
	movss	4(%rcx,%r13), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	addss	%xmm1, %xmm5
	movaps	%xmm4, %xmm7
	mulss	%xmm3, %xmm7
	mulss	(%r15,%r13), %xmm7
	mulss	(%rbx,%rax,4), %xmm7
	addss	%xmm5, %xmm7
	subss	4(%r15,%r13), %xmm6
	movaps	%xmm6, %xmm5
	mulss	%xmm6, %xmm5
	mulss	%xmm2, %xmm5
	addss	%xmm7, %xmm5
	addss	%xmm6, %xmm6
	mulss	8(%rcx,%r13), %xmm4
	addss	%xmm0, %xmm4
	mulss	%xmm6, %xmm4
	addss	%xmm5, %xmm4
	movss	%xmm4, (%rbx,%rax,4)
	incq	%rax
	cmpq	%rax, %r14
	jne	LBB4_6
LBB4_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse225cosine_int8_distance_sse2EPKvS3_mPf
LCPI5_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
LCPI5_1:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse225cosine_int8_distance_sse2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4sse225cosine_int8_distance_sse2EPKvS3_mPf: ## @_ZN4zvec5turbo4sse225cosine_int8_distance_sse2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$25, %rdx
	jb	LBB5_13
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	leaq	-24(%rdx), %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	cmpq	$16, %rax
	jb	LBB5_4
## %bb.2:
	movdqa	LCPI5_0(%rip), %xmm1            ## xmm1 = [1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB5_3:                                 ## =>This Inner Loop Header: Depth=1
	movq	%r8, %r9
	movdqu	(%rdi,%r8), %xmm2
	pxor	%xmm3, %xmm3
	pcmpgtb	%xmm2, %xmm3
	movdqa	%xmm2, %xmm4
	punpcklbw	%xmm3, %xmm4            ## xmm4 = xmm4[0],xmm3[0],xmm4[1],xmm3[1],xmm4[2],xmm3[2],xmm4[3],xmm3[3],xmm4[4],xmm3[4],xmm4[5],xmm3[5],xmm4[6],xmm3[6],xmm4[7],xmm3[7]
	punpckhbw	%xmm3, %xmm2            ## xmm2 = xmm2[8],xmm3[8],xmm2[9],xmm3[9],xmm2[10],xmm3[10],xmm2[11],xmm3[11],xmm2[12],xmm3[12],xmm2[13],xmm3[13],xmm2[14],xmm3[14],xmm2[15],xmm3[15]
	movdqu	(%rsi,%r8), %xmm3
	pxor	%xmm5, %xmm5
	pcmpgtb	%xmm3, %xmm5
	movdqa	%xmm3, %xmm6
	punpcklbw	%xmm5, %xmm6            ## xmm6 = xmm6[0],xmm5[0],xmm6[1],xmm5[1],xmm6[2],xmm5[2],xmm6[3],xmm5[3],xmm6[4],xmm5[4],xmm6[5],xmm5[5],xmm6[6],xmm5[6],xmm6[7],xmm5[7]
	pmullw	%xmm4, %xmm6
	punpckhbw	%xmm5, %xmm3            ## xmm3 = xmm3[8],xmm5[8],xmm3[9],xmm5[9],xmm3[10],xmm5[10],xmm3[11],xmm5[11],xmm3[12],xmm5[12],xmm3[13],xmm5[13],xmm3[14],xmm5[14],xmm3[15],xmm5[15]
	pmullw	%xmm2, %xmm3
	pmaddwd	%xmm1, %xmm6
	paddd	%xmm0, %xmm6
	pmaddwd	%xmm1, %xmm3
	movdqa	%xmm3, %xmm0
	paddd	%xmm6, %xmm0
	addq	$16, %r8
	addq	$32, %r9
	cmpq	%rax, %r9
	jbe	LBB5_3
LBB5_4:
	movq	%xmm0, %r9
	movslq	%r9d, %r9
	pshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	movd	%xmm1, %r10d
	movslq	%r10d, %r10
	addq	%r9, %r10
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	movd	%xmm1, %r9d
	movslq	%r9d, %r11
	addq	%r10, %r11
	pshufd	$255, %xmm0, %xmm0              ## xmm0 = xmm0[3,3,3,3]
	movd	%xmm0, %r9d
	movslq	%r9d, %r9
	addq	%r11, %r9
	cmpq	%rax, %r8
	jae	LBB5_9
## %bb.5:
	movq	%rdx, %r10
	subq	%r8, %r10
	addq	$-25, %r10
	andq	$3, %rdx
	je	LBB5_7
	.p2align	4, 0x90
LBB5_6:                                 ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %r11
	movsbq	(%rsi,%r8), %rbx
	imulq	%r11, %rbx
	addq	%rbx, %r9
	incq	%r8
	decq	%rdx
	jne	LBB5_6
LBB5_7:
	cmpq	$3, %r10
	jb	LBB5_9
	.p2align	4, 0x90
LBB5_8:                                 ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %rdx
	movsbq	(%rsi,%r8), %r10
	imulq	%rdx, %r10
	addq	%r9, %r10
	movsbq	1(%rdi,%r8), %rdx
	movsbq	1(%rsi,%r8), %r9
	imulq	%rdx, %r9
	addq	%r10, %r9
	movsbq	2(%rdi,%r8), %rdx
	movsbq	2(%rsi,%r8), %r10
	imulq	%rdx, %r10
	addq	%r9, %r10
	movsbq	3(%rdi,%r8), %rdx
	movsbq	3(%rsi,%r8), %r9
	imulq	%rdx, %r9
	addq	%r10, %r9
	addq	$4, %r8
	cmpq	%r8, %rax
	jne	LBB5_8
LBB5_9:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%r9, %xmm3
	movss	(%rdi,%rax), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%rax), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%rax), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%rsi,%rax), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	movaps	%xmm1, %xmm5
	mulss	%xmm4, %xmm5
	mulss	%xmm3, %xmm5
	mulss	%xmm2, %xmm4
	mulss	8(%rsi,%rax), %xmm4
	addss	%xmm5, %xmm4
	mulss	%xmm0, %xmm1
	mulss	8(%rdi,%rax), %xmm1
	addss	%xmm4, %xmm1
	testq	%rax, %rax
	js	LBB5_10
## %bb.11:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	jmp	LBB5_12
LBB5_10:
	movq	%rax, %rdx
	shrq	%rdx
	andl	$1, %eax
	orq	%rdx, %rax
	xorps	%xmm3, %xmm3
	cvtsi2ss	%rax, %xmm3
	addss	%xmm3, %xmm3
LBB5_12:
	mulss	%xmm3, %xmm0
	mulss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	xorps	LCPI5_1(%rip), %xmm0
	movss	%xmm0, (%rcx)
	popq	%rbx
	popq	%rbp
LBB5_13:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## -- Begin function _ZN4zvec5turbo4sse231cosine_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
LCPI6_0:
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4sse231cosine_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4sse231cosine_int8_batch_distance_sse2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4sse231cosine_int8_batch_distance_sse2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$25, %rcx
	jb	LBB6_7
## %bb.1:
	movq	%r8, %rbx
	movq	%rcx, %r14
	movq	%rdx, %r15
	movq	%rsi, %r12
	movq	%rdi, %r13
	addq	$-24, %r14
	movq	%r14, %rcx
	callq	__ZN4zvec5turbo4sse212_GLOBAL__N_123raw_inner_product_batchEPKPKvPKammPf
	testq	%r15, %r15
	je	LBB6_7
## %bb.2:
	testq	%r14, %r14
	js	LBB6_3
## %bb.4:
	cvtsi2ss	%r14, %xmm0
	jmp	LBB6_5
LBB6_3:
	movq	%r14, %rax
	shrq	%rax
	movl	%r14d, %ecx
	andl	$1, %ecx
	orq	%rax, %rcx
	cvtsi2ss	%rcx, %xmm0
	addss	%xmm0, %xmm0
LBB6_5:
	xorl	%eax, %eax
	movaps	LCPI6_0(%rip), %xmm1            ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB6_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%r13,%rax,8), %rcx
	movss	(%rcx,%r14), %xmm2              ## xmm2 = mem[0],zero,zero,zero
	movss	4(%rcx,%r14), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	movss	(%r12,%r14), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movss	4(%r12,%r14), %xmm5             ## xmm5 = mem[0],zero,zero,zero
	movaps	%xmm2, %xmm6
	mulss	%xmm4, %xmm6
	mulss	%xmm3, %xmm4
	mulss	8(%r12,%r14), %xmm4
	mulss	(%rbx,%rax,4), %xmm6
	addss	%xmm4, %xmm6
	mulss	%xmm5, %xmm2
	mulss	8(%rcx,%r14), %xmm2
	addss	%xmm6, %xmm2
	mulss	%xmm0, %xmm5
	mulss	%xmm3, %xmm5
	addss	%xmm2, %xmm5
	xorps	%xmm1, %xmm5
	movss	%xmm5, (%rbx,%rax,4)
	incq	%rax
	cmpq	%rax, %r15
	jne	LBB6_6
LBB6_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
