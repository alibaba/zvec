	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0                          ## -- Begin function _ZN4zvec5turbo11avx512_vnni31squared_euclidean_int8_distanceEPKvS3_mPf
LCPI0_0:
	.long	2155905152                      ## 0x80808080
LCPI0_3:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
LCPI0_1:
	.space	16,128
LCPI0_2:
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.byte	128                             ## 0x80
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo11avx512_vnni31squared_euclidean_int8_distanceEPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo11avx512_vnni31squared_euclidean_int8_distanceEPKvS3_mPf: ## @_ZN4zvec5turbo11avx512_vnni31squared_euclidean_int8_distanceEPKvS3_mPf
	.cfi_startproc
## %bb.0:
	addl	$-20, %edx
	testl	%edx, %edx
	jle	LBB0_24
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%edx, %eax
	cmpl	$128, %edx
	jae	LBB0_5
## %bb.2:
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%r8d, %r8d
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	LBB0_3
LBB0_5:
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r9d, %r9d
	vpbroadcastd	LCPI0_0(%rip), %zmm2    ## zmm2 = [2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB0_6:                                 ## =>This Inner Loop Header: Depth=1
	vpxord	(%rdi,%r9), %zmm2, %zmm3
	vpdpbusd	(%rsi,%r9), %zmm3, %zmm0
	vpxord	64(%rdi,%r9), %zmm2, %zmm3
	vpdpbusd	64(%rsi,%r9), %zmm3, %zmm1
	leaq	128(%r9), %r8
	addq	$256, %r9                       ## imm = 0x100
	cmpq	%rax, %r9
	movq	%r8, %r9
	jbe	LBB0_6
LBB0_3:
	movq	%r8, %r9
	orq	$64, %r9
	cmpq	%rax, %r9
	jbe	LBB0_7
## %bb.4:
	movq	%r8, %r9
	jmp	LBB0_9
LBB0_7:
	vpbroadcastd	LCPI0_0(%rip), %zmm2    ## zmm2 = [2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152,2155905152]
	.p2align	4, 0x90
LBB0_8:                                 ## =>This Inner Loop Header: Depth=1
	vpxord	(%rdi,%r8), %zmm2, %zmm3
	vpdpbusd	(%rsi,%r8), %zmm3, %zmm0
	leaq	64(%r8), %r9
	subq	$-128, %r8
	cmpq	%rax, %r8
	movq	%r9, %r8
	jbe	LBB0_8
LBB0_9:
	vpaddd	%zmm1, %zmm0, %zmm0
	movl	16(%rsi,%rax), %r8d
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %ebx
	cmpq	%rax, %r9
	jae	LBB0_23
## %bb.10:
	movq	%rax, %r10
	subq	%r9, %r10
	cmpq	$8, %r10
	jae	LBB0_11
LBB0_21:
	movq	%r9, %r14
	jmp	LBB0_22
LBB0_11:
	cmpq	$64, %r10
	jae	LBB0_16
## %bb.12:
	xorl	%r11d, %r11d
	jmp	LBB0_13
LBB0_16:
	movq	%r10, %r11
	andq	$-64, %r11
	vmovd	%ebx, %xmm0
	leaq	(%rdi,%r9), %rbx
	addq	$48, %rbx
	leaq	(%rsi,%r9), %r14
	addq	$48, %r14
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%r15d, %r15d
	vmovdqa	LCPI0_1(%rip), %xmm2            ## xmm2 = [128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128]
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm4, %xmm4, %xmm4
	.p2align	4, 0x90
LBB0_17:                                ## =>This Inner Loop Header: Depth=1
	vpxor	-48(%rbx,%r15), %xmm2, %xmm5
	vpxor	-32(%rbx,%r15), %xmm2, %xmm6
	vpxor	-16(%rbx,%r15), %xmm2, %xmm7
	vpxor	(%rbx,%r15), %xmm2, %xmm8
	vpmovzxbd	%xmm5, %zmm5            ## zmm5 = xmm5[0],zero,zero,zero,xmm5[1],zero,zero,zero,xmm5[2],zero,zero,zero,xmm5[3],zero,zero,zero,xmm5[4],zero,zero,zero,xmm5[5],zero,zero,zero,xmm5[6],zero,zero,zero,xmm5[7],zero,zero,zero,xmm5[8],zero,zero,zero,xmm5[9],zero,zero,zero,xmm5[10],zero,zero,zero,xmm5[11],zero,zero,zero,xmm5[12],zero,zero,zero,xmm5[13],zero,zero,zero,xmm5[14],zero,zero,zero,xmm5[15],zero,zero,zero
	vpmovzxbd	%xmm6, %zmm6            ## zmm6 = xmm6[0],zero,zero,zero,xmm6[1],zero,zero,zero,xmm6[2],zero,zero,zero,xmm6[3],zero,zero,zero,xmm6[4],zero,zero,zero,xmm6[5],zero,zero,zero,xmm6[6],zero,zero,zero,xmm6[7],zero,zero,zero,xmm6[8],zero,zero,zero,xmm6[9],zero,zero,zero,xmm6[10],zero,zero,zero,xmm6[11],zero,zero,zero,xmm6[12],zero,zero,zero,xmm6[13],zero,zero,zero,xmm6[14],zero,zero,zero,xmm6[15],zero,zero,zero
	vpmovzxbd	%xmm7, %zmm7            ## zmm7 = xmm7[0],zero,zero,zero,xmm7[1],zero,zero,zero,xmm7[2],zero,zero,zero,xmm7[3],zero,zero,zero,xmm7[4],zero,zero,zero,xmm7[5],zero,zero,zero,xmm7[6],zero,zero,zero,xmm7[7],zero,zero,zero,xmm7[8],zero,zero,zero,xmm7[9],zero,zero,zero,xmm7[10],zero,zero,zero,xmm7[11],zero,zero,zero,xmm7[12],zero,zero,zero,xmm7[13],zero,zero,zero,xmm7[14],zero,zero,zero,xmm7[15],zero,zero,zero
	vpmovzxbd	%xmm8, %zmm8            ## zmm8 = xmm8[0],zero,zero,zero,xmm8[1],zero,zero,zero,xmm8[2],zero,zero,zero,xmm8[3],zero,zero,zero,xmm8[4],zero,zero,zero,xmm8[5],zero,zero,zero,xmm8[6],zero,zero,zero,xmm8[7],zero,zero,zero,xmm8[8],zero,zero,zero,xmm8[9],zero,zero,zero,xmm8[10],zero,zero,zero,xmm8[11],zero,zero,zero,xmm8[12],zero,zero,zero,xmm8[13],zero,zero,zero,xmm8[14],zero,zero,zero,xmm8[15],zero,zero,zero
	vpmovsxbd	-48(%r14,%r15), %zmm9
	vpdpwssd	%zmm9, %zmm5, %zmm0
	vpmovsxbd	-32(%r14,%r15), %zmm5
	vpdpwssd	%zmm5, %zmm6, %zmm1
	vpmovsxbd	-16(%r14,%r15), %zmm5
	vpmovsxbd	(%r14,%r15), %zmm6
	vpdpwssd	%zmm5, %zmm7, %zmm3
	vpdpwssd	%zmm6, %zmm8, %zmm4
	addq	$64, %r15
	cmpq	%r15, %r11
	jne	LBB0_17
## %bb.18:
	vpaddd	%zmm0, %zmm1, %zmm0
	vpaddd	%zmm4, %zmm3, %zmm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %ebx
	cmpq	%r11, %r10
	je	LBB0_23
## %bb.19:
	testb	$56, %r10b
	je	LBB0_20
LBB0_13:
	movq	%r10, %r15
	andq	$-8, %r15
	leaq	(%r9,%r15), %r14
	vmovd	%ebx, %xmm0
	leaq	(%rdi,%r9), %rbx
	addq	%rsi, %r9
	vmovdqa	LCPI0_2(%rip), %xmm1            ## xmm1 = <128,128,128,128,128,128,128,128,u,u,u,u,u,u,u,u>
	.p2align	4, 0x90
LBB0_14:                                ## =>This Inner Loop Header: Depth=1
	vmovq	(%rbx,%r11), %xmm2              ## xmm2 = mem[0],zero
	vpxor	%xmm1, %xmm2, %xmm2
	vpmovsxbd	(%r9,%r11), %ymm3
	vpmovzxbd	%xmm2, %ymm2            ## ymm2 = xmm2[0],zero,zero,zero,xmm2[1],zero,zero,zero,xmm2[2],zero,zero,zero,xmm2[3],zero,zero,zero,xmm2[4],zero,zero,zero,xmm2[5],zero,zero,zero,xmm2[6],zero,zero,zero,xmm2[7],zero,zero,zero
	vpdpwssd	%ymm3, %ymm2, %ymm0
	addq	$8, %r11
	cmpq	%r11, %r15
	jne	LBB0_14
## %bb.15:
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %ebx
	cmpq	%r15, %r10
	je	LBB0_23
	.p2align	4, 0x90
LBB0_22:                                ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r14), %r9d
	xorl	$128, %r9d
	movsbl	(%rsi,%r14), %r10d
	imull	%r9d, %r10d
	addl	%r10d, %ebx
	incq	%r14
	cmpq	%r14, %rax
	jne	LBB0_22
LBB0_23:
	shll	$7, %r8d
	subl	%r8d, %ebx
	vcvtsi2ss	%ebx, %xmm10, %xmm0
	vmovss	%xmm0, (%rcx)
	vmovss	(%rdi,%rax), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vmovss	4(%rdi,%rax), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vmovss	(%rsi,%rax), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	vmulss	%xmm3, %xmm3, %xmm4
	vmulss	12(%rsi,%rax), %xmm4, %xmm4
	vmulss	%xmm1, %xmm1, %xmm5
	vfmadd132ss	12(%rdi,%rax), %xmm4, %xmm5 ## xmm5 = (xmm5 * mem) + xmm4
	vmulss	LCPI0_3(%rip), %xmm1, %xmm4
	vmulss	%xmm3, %xmm4, %xmm4
	vfmadd213ss	%xmm5, %xmm0, %xmm4     ## xmm4 = (xmm0 * xmm4) + xmm5
	vsubss	4(%rsi,%rax), %xmm2, %xmm0
	vmulss	%xmm0, %xmm0, %xmm2
	vcvtsi2ss	%edx, %xmm10, %xmm5
	vfmadd213ss	%xmm4, %xmm2, %xmm5     ## xmm5 = (xmm2 * xmm5) + xmm4
	vaddss	%xmm0, %xmm0, %xmm0
	vmulss	8(%rsi,%rax), %xmm3, %xmm2
	vfmsub231ss	8(%rdi,%rax), %xmm1, %xmm2 ## xmm2 = (xmm1 * mem) - xmm2
	vfmadd213ss	%xmm5, %xmm0, %xmm2     ## xmm2 = (xmm0 * xmm2) + xmm5
	vmovss	%xmm2, (%rcx)
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
LBB0_24:
	vzeroupper
	retq
LBB0_20:
	addq	%r11, %r9
	jmp	LBB0_21
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0                          ## -- Begin function _ZN4zvec5turbo11avx512_vnni37squared_euclidean_int8_batch_distanceEPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0xc3000000                      ## float -128
LCPI1_1:
	.long	0x44700000                      ## float 960
LCPI1_2:
	.long	0x80000000                      ## float -0
LCPI1_3:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo11avx512_vnni37squared_euclidean_int8_batch_distanceEPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo11avx512_vnni37squared_euclidean_int8_batch_distanceEPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo11avx512_vnni37squared_euclidean_int8_batch_distanceEPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	andq	$-64, %rsp
	subq	$3136, %rsp                     ## imm = 0xC40
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	addl	$-20, %ecx
	testl	%ecx, %ecx
	jle	LBB1_305
## %bb.1:
	movl	%ecx, %eax
	vmovss	(%rsi,%rax), %xmm20             ## xmm20 = mem[0],zero,zero,zero
	vmovss	4(%rsi,%rax), %xmm21            ## xmm21 = mem[0],zero,zero,zero
	vmulss	8(%rsi,%rax), %xmm20, %xmm0
	vmovaps	%xmm0, 128(%rsp)                ## 16-byte Spill
	vmulss	%xmm20, %xmm20, %xmm0
	vmulss	12(%rsi,%rax), %xmm0, %xmm22
	cmpl	$960, %ecx                      ## imm = 0x3C0
	movq	%rdx, 56(%rsp)                  ## 8-byte Spill
	movq	%rdi, 64(%rsp)                  ## 8-byte Spill
	movq	%rcx, 72(%rsp)                  ## 8-byte Spill
	jne	LBB1_2
## %bb.3:
	cmpq	$4, %rdx
	jae	LBB1_10
## %bb.4:
	xorl	%r14d, %r14d
LBB1_5:
	leaq	(%rdi,%r14,8), %r10
	leaq	(%r8,%r14,4), %r8
	movq	72(%rsp), %rcx                  ## 8-byte Reload
	movq	%r8, 80(%rsp)                   ## 8-byte Spill
	leaq	2(%r14), %r15
	cmpq	%rdx, %r15
	ja	LBB1_239
	jmp	LBB1_7
LBB1_2:
	xorl	%r14d, %r14d
	movq	%rdi, %r10
	movq	%r8, 80(%rsp)                   ## 8-byte Spill
	leaq	2(%r14), %r15
	cmpq	%rdx, %r15
	jbe	LBB1_7
LBB1_239:
	cmpq	%rdx, %r14
	movq	72(%rsp), %rcx                  ## 8-byte Reload
	movq	80(%rsp), %r8                   ## 8-byte Reload
	jae	LBB1_305
## %bb.240:
	vcvtsi2ss	%ecx, %xmm23, %xmm4
	vmovdqa	128(%rsp), %xmm0                ## 16-byte Reload
	vpxord	LCPI1_2(%rip){1to4}, %xmm0, %xmm3
	cmpl	$64, %ecx
	jae	LBB1_241
## %bb.246:
	cmpq	$2, %rax
	movl	$1, %ecx
	cmovaeq	%rax, %rcx
	movl	%ecx, %r13d
	andl	$-64, %r13d
	movl	%ecx, %r9d
	andl	$-8, %r9d
	vmovss	LCPI1_0(%rip), %xmm0            ## xmm0 = mem[0],zero,zero,zero
	vmovss	LCPI1_3(%rip), %xmm1            ## xmm1 = mem[0],zero,zero,zero
	jmp	LBB1_247
	.p2align	4, 0x90
LBB1_259:                               ##   in Loop: Header=BB1_247 Depth=1
	vcvtsi2ss	%ebx, %xmm23, %xmm2
	movq	(%r10), %r11
	vmovss	(%r11,%rax), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	vcvtsi2ssl	16(%r11,%rax), %xmm14, %xmm6
	vmovss	4(%r11,%rax), %xmm7             ## xmm7 = mem[0],zero,zero,zero
	vmulss	%xmm5, %xmm5, %xmm8
	vfmadd132ss	12(%r11,%rax), %xmm22, %xmm8 ## xmm8 = (xmm8 * mem) + xmm22
	vfmadd132ss	%xmm0, %xmm2, %xmm6     ## xmm6 = (xmm6 * xmm0) + xmm2
	vmulss	%xmm1, %xmm5, %xmm2
	vmulss	%xmm2, %xmm20, %xmm2
	vfmadd213ss	%xmm8, %xmm6, %xmm2     ## xmm2 = (xmm6 * xmm2) + xmm8
	vsubss	%xmm21, %xmm7, %xmm6
	vmulss	%xmm6, %xmm6, %xmm7
	vfmadd213ss	%xmm2, %xmm4, %xmm7     ## xmm7 = (xmm4 * xmm7) + xmm2
	vaddss	%xmm6, %xmm6, %xmm2
	vfmadd132ss	8(%r11,%rax), %xmm3, %xmm5 ## xmm5 = (xmm5 * mem) + xmm3
	vfmadd213ss	%xmm7, %xmm2, %xmm5     ## xmm5 = (xmm2 * xmm5) + xmm7
	vmovss	%xmm5, (%r8)
	addq	$8, %r10
	addq	$4, %r8
	movq	%rdi, %r14
	incq	%r14
	cmpq	%rdx, %r14
	movq	64(%rsp), %rdi                  ## 8-byte Reload
	je	LBB1_305
LBB1_247:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_252 Depth 2
                                        ##     Child Loop BB1_256 Depth 2
                                        ##     Child Loop BB1_258 Depth 2
	movq	(%rdi,%r14,8), %r11
	cmpl	$8, %ecx
	jae	LBB1_249
## %bb.248:                             ##   in Loop: Header=BB1_247 Depth=1
	movq	%r14, %rdi
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	jmp	LBB1_258
	.p2align	4, 0x90
LBB1_249:                               ##   in Loop: Header=BB1_247 Depth=1
	cmpl	$64, %ecx
	jae	LBB1_251
## %bb.250:                             ##   in Loop: Header=BB1_247 Depth=1
	movq	%r14, %rdi
	xorl	%ebx, %ebx
	xorl	%r15d, %r15d
	jmp	LBB1_255
	.p2align	4, 0x90
LBB1_251:                               ##   in Loop: Header=BB1_247 Depth=1
	vxorps	%xmm2, %xmm2, %xmm2
	xorl	%ebx, %ebx
	vpxor	%xmm5, %xmm5, %xmm5
	vxorps	%xmm6, %xmm6, %xmm6
	vxorps	%xmm7, %xmm7, %xmm7
	.p2align	4, 0x90
LBB1_252:                               ##   Parent Loop BB1_247 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rsi,%rbx), %zmm8      ## zmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	16(%rsi,%rbx), %zmm9    ## zmm9 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	32(%rsi,%rbx), %zmm10   ## zmm10 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	48(%rsi,%rbx), %zmm11   ## zmm11 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovsxbd	(%r11,%rbx), %zmm12
	vpdpwssd	%zmm8, %zmm12, %zmm2
	vpmovsxbd	16(%r11,%rbx), %zmm8
	vpdpwssd	%zmm9, %zmm8, %zmm5
	vpmovsxbd	32(%r11,%rbx), %zmm8
	vpmovsxbd	48(%r11,%rbx), %zmm9
	vpdpwssd	%zmm10, %zmm8, %zmm6
	vpdpwssd	%zmm11, %zmm9, %zmm7
	addq	$64, %rbx
	cmpq	%rbx, %r13
	jne	LBB1_252
## %bb.253:                             ##   in Loop: Header=BB1_247 Depth=1
	vpaddd	%zmm2, %zmm5, %zmm2
	vpaddd	%zmm7, %zmm6, %zmm5
	vpaddd	%zmm5, %zmm2, %zmm2
	vextracti64x4	$1, %zmm2, %ymm5
	vpaddd	%zmm5, %zmm2, %zmm2
	vextracti128	$1, %ymm2, %xmm5
	vpaddd	%xmm5, %xmm2, %xmm2
	vpshufd	$238, %xmm2, %xmm5              ## xmm5 = xmm2[2,3,2,3]
	vpaddd	%xmm5, %xmm2, %xmm2
	vpshufd	$85, %xmm2, %xmm5               ## xmm5 = xmm2[1,1,1,1]
	vpaddd	%xmm5, %xmm2, %xmm2
	vmovd	%xmm2, %ebx
	movq	%r14, %rdi
	cmpq	%r13, %rcx
	je	LBB1_259
## %bb.254:                             ##   in Loop: Header=BB1_247 Depth=1
	movq	%r13, %r15
	movq	%r13, %r14
	testb	$56, %cl
	je	LBB1_258
LBB1_255:                               ##   in Loop: Header=BB1_247 Depth=1
	vmovd	%ebx, %xmm2
	.p2align	4, 0x90
LBB1_256:                               ##   Parent Loop BB1_247 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rsi,%r15), %ymm5      ## ymm5 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero
	vpmovsxbd	(%r11,%r15), %ymm6
	vpdpwssd	%ymm5, %ymm6, %ymm2
	addq	$8, %r15
	cmpq	%r15, %r9
	jne	LBB1_256
## %bb.257:                             ##   in Loop: Header=BB1_247 Depth=1
	vextracti128	$1, %ymm2, %xmm5
	vpaddd	%xmm5, %xmm2, %xmm2
	vpshufd	$238, %xmm2, %xmm5              ## xmm5 = xmm2[2,3,2,3]
	vpaddd	%xmm5, %xmm2, %xmm2
	vpshufd	$85, %xmm2, %xmm5               ## xmm5 = xmm2[1,1,1,1]
	vpaddd	%xmm5, %xmm2, %xmm2
	vmovd	%xmm2, %ebx
	movq	%r9, %r14
	cmpq	%r9, %rcx
	je	LBB1_259
	.p2align	4, 0x90
LBB1_258:                               ##   Parent Loop BB1_247 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rsi,%r14), %r15d
	movsbl	(%r11,%r14), %r12d
	imull	%r15d, %r12d
	addl	%r12d, %ebx
	incq	%r14
	cmpq	%r14, %rcx
	jne	LBB1_258
	jmp	LBB1_259
LBB1_7:
	xorl	%r9d, %r9d
	cmpl	$257, %ecx                      ## imm = 0x101
	setb	%r9b
	leaq	4(,%r9,4), %r9
	movq	%r9, 112(%rsp)                  ## 8-byte Spill
	vcvtsi2ss	%ecx, %xmm6, %xmm4
	vmovdqa	128(%rsp), %xmm0                ## 16-byte Reload
	vpxord	LCPI1_2(%rip){1to4}, %xmm0, %xmm5
	movl	%eax, %r11d
	andl	$63, %r11d
	movl	%eax, %ecx
	andl	$7, %ecx
	movq	%rcx, 96(%rsp)                  ## 8-byte Spill
	movl	%eax, %r8d
	andl	$-64, %r8d
	movl	%eax, %ebx
	andl	$-8, %ebx
	vmovss	LCPI1_0(%rip), %xmm6            ## xmm6 = mem[0],zero,zero,zero
	vmovss	LCPI1_3(%rip), %xmm7            ## xmm7 = mem[0],zero,zero,zero
	jmp	LBB1_8
	.p2align	4, 0x90
LBB1_276:                               ##   in Loop: Header=BB1_8 Depth=1
	vcvtsi2ss	%ecx, %xmm23, %xmm0
	vcvtsi2ss	%edi, %xmm23, %xmm1
	movq	(%r10), %rcx
	vmovss	(%rcx,%rax), %xmm2              ## xmm2 = mem[0],zero,zero,zero
	vmovss	4(%rcx,%rax), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	vcvtsi2ssl	16(%rcx,%rax), %xmm23, %xmm8
	vfmadd213ss	%xmm0, %xmm6, %xmm8     ## xmm8 = (xmm6 * xmm8) + xmm0
	vmulss	%xmm2, %xmm2, %xmm0
	vfmadd132ss	12(%rcx,%rax), %xmm22, %xmm0 ## xmm0 = (xmm0 * mem) + xmm22
	vmulss	%xmm7, %xmm2, %xmm9
	vmulss	%xmm9, %xmm20, %xmm9
	vfmadd213ss	%xmm0, %xmm8, %xmm9     ## xmm9 = (xmm8 * xmm9) + xmm0
	vsubss	%xmm21, %xmm3, %xmm0
	vmulss	%xmm0, %xmm0, %xmm3
	vfmadd213ss	%xmm9, %xmm4, %xmm3     ## xmm3 = (xmm4 * xmm3) + xmm9
	vfmadd132ss	8(%rcx,%rax), %xmm5, %xmm2 ## xmm2 = (xmm2 * mem) + xmm5
	vaddss	%xmm0, %xmm0, %xmm0
	vfmadd213ss	%xmm3, %xmm0, %xmm2     ## xmm2 = (xmm0 * xmm2) + xmm3
	movq	80(%rsp), %rdx                  ## 8-byte Reload
	vmovss	%xmm2, (%rdx)
	movq	8(%r10), %rcx
	vmovss	(%rcx,%rax), %xmm0              ## xmm0 = mem[0],zero,zero,zero
	vcvtsi2ssl	16(%rcx,%rax), %xmm23, %xmm2
	vmovss	4(%rcx,%rax), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	vmulss	%xmm0, %xmm0, %xmm8
	vfmadd132ss	12(%rcx,%rax), %xmm22, %xmm8 ## xmm8 = (xmm8 * mem) + xmm22
	vfmadd213ss	%xmm1, %xmm6, %xmm2     ## xmm2 = (xmm6 * xmm2) + xmm1
	vmulss	%xmm7, %xmm0, %xmm1
	vmulss	%xmm1, %xmm20, %xmm1
	vfmadd213ss	%xmm8, %xmm2, %xmm1     ## xmm1 = (xmm2 * xmm1) + xmm8
	vsubss	%xmm21, %xmm3, %xmm2
	vmulss	%xmm2, %xmm2, %xmm3
	vfmadd213ss	%xmm1, %xmm4, %xmm3     ## xmm3 = (xmm4 * xmm3) + xmm1
	vaddss	%xmm2, %xmm2, %xmm1
	vfmadd132ss	8(%rcx,%rax), %xmm5, %xmm0 ## xmm0 = (xmm0 * mem) + xmm5
	vfmadd213ss	%xmm3, %xmm1, %xmm0     ## xmm0 = (xmm1 * xmm0) + xmm3
	vmovss	%xmm0, 4(%rdx)
	addq	$8, %rdx
	movq	%rdx, 80(%rsp)                  ## 8-byte Spill
	addq	$16, %r10
	movq	88(%rsp), %r14                  ## 8-byte Reload
	leaq	2(%r14), %r15
	movq	56(%rsp), %rdx                  ## 8-byte Reload
	cmpq	%rdx, %r15
	movq	64(%rsp), %rdi                  ## 8-byte Reload
	ja	LBB1_239
LBB1_8:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_262 Depth 2
                                        ##     Child Loop BB1_266 Depth 2
                                        ##     Child Loop BB1_278 Depth 2
                                        ##     Child Loop BB1_274 Depth 2
                                        ##     Child Loop BB1_283 Depth 2
	movq	%r14, %r9
	movq	%r15, %r14
	movq	112(%rsp), %rcx                 ## 8-byte Reload
	addq	%r9, %rcx
	cmpq	%rdx, %rcx
	movq	%r15, 88(%rsp)                  ## 8-byte Spill
	jae	LBB1_9
## %bb.284:                             ##   in Loop: Header=BB1_8 Depth=1
	movq	(%rdi,%rcx,8), %r15
	leaq	1(%rcx), %r14
	cmpq	%rdx, %r14
	jb	LBB1_287
LBB1_286:                               ##   in Loop: Header=BB1_8 Depth=1
	xorl	%ecx, %ecx
	cmpl	$64, 72(%rsp)                   ## 4-byte Folded Reload
	jb	LBB1_289
LBB1_260:                               ##   in Loop: Header=BB1_8 Depth=1
	movq	(%rdi,%r9,8), %rdx
	movq	8(%rdi,%r9,8), %r14
	vxorps	%xmm1, %xmm1, %xmm1
	testq	%r15, %r15
	je	LBB1_265
## %bb.261:                             ##   in Loop: Header=BB1_8 Depth=1
	xorl	%r12d, %r12d
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	LBB1_262
	.p2align	4, 0x90
LBB1_264:                               ##   in Loop: Header=BB1_262 Depth=2
	vpdpbusd	%zmm3, %zmm2, %zmm0
	leaq	64(%r12), %r13
	subq	$-128, %r12
	cmpq	%rax, %r12
	movq	%r13, %r12
	ja	LBB1_269
LBB1_262:                               ##   Parent Loop BB1_8 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovdqu64	(%rsi,%r12), %zmm2
	vmovdqu64	(%r14,%r12), %zmm3
	prefetcht0	(%r15,%r12)
	vpdpbusd	(%rdx,%r12), %zmm2, %zmm1
	testq	%rcx, %rcx
	je	LBB1_264
## %bb.263:                             ##   in Loop: Header=BB1_262 Depth=2
	prefetcht0	(%rcx,%r12)
	jmp	LBB1_264
	.p2align	4, 0x90
LBB1_9:                                 ##   in Loop: Header=BB1_8 Depth=1
	xorl	%r15d, %r15d
	leaq	1(%rcx), %r14
	cmpq	%rdx, %r14
	jae	LBB1_286
LBB1_287:                               ##   in Loop: Header=BB1_8 Depth=1
	movq	8(%rdi,%rcx,8), %rcx
	cmpl	$64, 72(%rsp)                   ## 4-byte Folded Reload
	jae	LBB1_260
LBB1_289:                               ##   in Loop: Header=BB1_8 Depth=1
	vxorps	%xmm1, %xmm1, %xmm1
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r13d, %r13d
LBB1_269:                               ##   in Loop: Header=BB1_8 Depth=1
	vextracti64x4	$1, %zmm1, %ymm2
	vpaddd	%zmm2, %zmm1, %zmm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %ecx
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %edi
	cmpq	%rax, %r13
	jae	LBB1_276
## %bb.270:                             ##   in Loop: Header=BB1_8 Depth=1
	movq	64(%rsp), %rdx                  ## 8-byte Reload
	movq	(%rdx,%r9,8), %r14
	movq	8(%rdx,%r9,8), %r15
	movq	%rax, %r12
	subq	%r13, %r12
	cmpq	$8, %r12
	jae	LBB1_271
LBB1_282:                               ##   in Loop: Header=BB1_8 Depth=1
	movq	%r13, %r12
	jmp	LBB1_283
	.p2align	4, 0x90
LBB1_271:                               ##   in Loop: Header=BB1_8 Depth=1
	cmpq	$64, %r12
	jae	LBB1_277
## %bb.272:                             ##   in Loop: Header=BB1_8 Depth=1
	xorl	%edx, %edx
	jmp	LBB1_273
LBB1_265:                               ##   in Loop: Header=BB1_8 Depth=1
	xorl	%r15d, %r15d
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	LBB1_266
	.p2align	4, 0x90
LBB1_268:                               ##   in Loop: Header=BB1_266 Depth=2
	vpdpbusd	%zmm3, %zmm2, %zmm0
	leaq	64(%r15), %r13
	subq	$-128, %r15
	cmpq	%rax, %r15
	movq	%r13, %r15
	ja	LBB1_269
LBB1_266:                               ##   Parent Loop BB1_8 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovdqu64	(%rsi,%r15), %zmm2
	vmovdqu64	(%r14,%r15), %zmm3
	vpdpbusd	(%rdx,%r15), %zmm2, %zmm1
	testq	%rcx, %rcx
	je	LBB1_268
## %bb.267:                             ##   in Loop: Header=BB1_266 Depth=2
	prefetcht0	(%rcx,%r15)
	jmp	LBB1_268
LBB1_277:                               ##   in Loop: Header=BB1_8 Depth=1
	movq	%r12, %rdx
	subq	%r11, %rdx
	vmovd	%ecx, %xmm0
	vmovd	%edi, %xmm8
	vpxor	%xmm1, %xmm1, %xmm1
	movq	%r13, %rcx
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm9, %xmm9, %xmm9
	vpxor	%xmm10, %xmm10, %xmm10
	vpxor	%xmm11, %xmm11, %xmm11
	.p2align	4, 0x90
LBB1_278:                               ##   Parent Loop BB1_8 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rsi,%rcx), %zmm12     ## zmm12 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	16(%rsi,%rcx), %zmm13   ## zmm13 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	32(%rsi,%rcx), %zmm14   ## zmm14 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	48(%rsi,%rcx), %zmm15   ## zmm15 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovsxbd	(%r14,%rcx), %zmm16
	vpmovsxbd	16(%r14,%rcx), %zmm17
	vpmovsxbd	32(%r14,%rcx), %zmm18
	vpmovsxbd	48(%r14,%rcx), %zmm19
	vpdpwssd	%zmm12, %zmm16, %zmm0
	vpdpwssd	%zmm13, %zmm17, %zmm1
	vpdpwssd	%zmm14, %zmm18, %zmm2
	vpdpwssd	%zmm15, %zmm19, %zmm3
	vpmovsxbd	(%r15,%rcx), %zmm16
	vpmovsxbd	16(%r15,%rcx), %zmm17
	vpmovsxbd	32(%r15,%rcx), %zmm18
	vpmovsxbd	48(%r15,%rcx), %zmm19
	vpdpwssd	%zmm12, %zmm16, %zmm8
	vpdpwssd	%zmm13, %zmm17, %zmm9
	vpdpwssd	%zmm14, %zmm18, %zmm10
	vpdpwssd	%zmm15, %zmm19, %zmm11
	addq	$64, %rcx
	cmpq	%rcx, %r8
	jne	LBB1_278
## %bb.279:                             ##   in Loop: Header=BB1_8 Depth=1
	vpaddd	%zmm8, %zmm9, %zmm8
	vpaddd	%zmm11, %zmm10, %zmm9
	vpaddd	%zmm9, %zmm8, %zmm8
	vextracti64x4	$1, %zmm8, %ymm9
	vpaddd	%zmm9, %zmm8, %zmm8
	vextracti128	$1, %ymm8, %xmm9
	vpaddd	%xmm9, %xmm8, %xmm8
	vpshufd	$238, %xmm8, %xmm9              ## xmm9 = xmm8[2,3,2,3]
	vpaddd	%xmm9, %xmm8, %xmm8
	vpshufd	$85, %xmm8, %xmm9               ## xmm9 = xmm8[1,1,1,1]
	vpaddd	%xmm9, %xmm8, %xmm8
	vmovd	%xmm8, %edi
	vpaddd	%zmm0, %zmm1, %zmm0
	vpaddd	%zmm3, %zmm2, %zmm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %ecx
	testq	%r11, %r11
	je	LBB1_276
## %bb.280:                             ##   in Loop: Header=BB1_8 Depth=1
	cmpl	$8, %r11d
	jae	LBB1_273
## %bb.281:                             ##   in Loop: Header=BB1_8 Depth=1
	addq	%rdx, %r13
	jmp	LBB1_282
LBB1_273:                               ##   in Loop: Header=BB1_8 Depth=1
	subq	96(%rsp), %r12                  ## 8-byte Folded Reload
	addq	%r13, %r12
	vmovd	%ecx, %xmm0
	vmovd	%edi, %xmm1
	addq	%r13, %rdx
	.p2align	4, 0x90
LBB1_274:                               ##   Parent Loop BB1_8 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%rsi,%rdx), %ymm2      ## ymm2 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero
	vpmovsxbd	(%r14,%rdx), %ymm3
	vpmovsxbd	(%r15,%rdx), %ymm8
	vpdpwssd	%ymm2, %ymm3, %ymm0
	vpdpwssd	%ymm2, %ymm8, %ymm1
	addq	$8, %rdx
	cmpq	%rdx, %rbx
	jne	LBB1_274
## %bb.275:                             ##   in Loop: Header=BB1_8 Depth=1
	vextracti128	$1, %ymm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddd	%xmm2, %xmm1, %xmm1
	vpshufd	$85, %xmm1, %xmm2               ## xmm2 = xmm1[1,1,1,1]
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovd	%xmm1, %edi
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %ecx
	cmpq	$0, 96(%rsp)                    ## 8-byte Folded Reload
	je	LBB1_276
	.p2align	4, 0x90
LBB1_283:                               ##   Parent Loop BB1_8 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rsi,%r12), %edx
	movsbl	(%r14,%r12), %r13d
	imull	%edx, %r13d
	addl	%r13d, %ecx
	movsbl	(%r15,%r12), %r13d
	imull	%edx, %r13d
	addl	%r13d, %edi
	incq	%r12
	cmpq	%r12, %rax
	jne	LBB1_283
	jmp	LBB1_276
LBB1_10:
	vbroadcastss	%xmm21, %xmm0
	vmovaps	%xmm0, 112(%rsp)                ## 16-byte Spill
	vbroadcastss	%xmm22, %xmm0
	vmovaps	%xmm0, 96(%rsp)                 ## 16-byte Spill
	vbroadcastss	%xmm20, %xmm0
	vmovaps	%xmm0, 192(%rsp)                ## 16-byte Spill
	vbroadcastss	128(%rsp), %xmm0        ## 16-byte Folded Reload
	vmovaps	%xmm0, 240(%rsp)                ## 16-byte Spill
	xorl	%r14d, %r14d
	vbroadcastss	LCPI1_0(%rip), %xmm0    ## xmm0 = [-1.28E+2,-1.28E+2,-1.28E+2,-1.28E+2]
	vmovaps	%xmm0, 224(%rsp)                ## 16-byte Spill
	vbroadcastss	LCPI1_1(%rip), %xmm0    ## xmm0 = [9.6E+2,9.6E+2,9.6E+2,9.6E+2]
	vmovaps	%xmm0, 208(%rsp)                ## 16-byte Spill
	vmovaps	%xmm20, 176(%rsp)               ## 16-byte Spill
	vmovaps	%xmm21, 160(%rsp)               ## 16-byte Spill
	vmovaps	%xmm22, 144(%rsp)               ## 16-byte Spill
	jmp	LBB1_11
	.p2align	4, 0x90
LBB1_72:                                ##   in Loop: Header=BB1_11 Depth=1
	vpxor	%xmm10, %xmm10, %xmm10
	vpdpbusd	%zmm11, %zmm14, %zmm10
	vpxor	%xmm11, %xmm11, %xmm11
	vpdpbusd	%zmm12, %zmm14, %zmm11
	vpxor	%xmm12, %xmm12, %xmm12
	vpdpbusd	%zmm13, %zmm14, %zmm12
	vpxor	%xmm13, %xmm13, %xmm13
	vpdpbusd	3008(%rsp), %zmm14, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	2752(%rsp), %zmm15, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2816(%rsp), %zmm15, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2880(%rsp), %zmm15, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2944(%rsp), %zmm15, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	2496(%rsp), %zmm8, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	2560(%rsp), %zmm8, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	2624(%rsp), %zmm8, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	2688(%rsp), %zmm8, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	2240(%rsp), %zmm22, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2304(%rsp), %zmm22, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2368(%rsp), %zmm22, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2432(%rsp), %zmm22, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1984(%rsp), %zmm27, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2048(%rsp), %zmm27, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2112(%rsp), %zmm27, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2176(%rsp), %zmm27, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1728(%rsp), %zmm1, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	1792(%rsp), %zmm1, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	1856(%rsp), %zmm1, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	1920(%rsp), %zmm1, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	1472(%rsp), %zmm6, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	1536(%rsp), %zmm6, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	1600(%rsp), %zmm6, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	1664(%rsp), %zmm6, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	1216(%rsp), %zmm18, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	1280(%rsp), %zmm18, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1344(%rsp), %zmm18, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1408(%rsp), %zmm18, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	960(%rsp), %zmm23, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	1024(%rsp), %zmm23, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1088(%rsp), %zmm23, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1152(%rsp), %zmm23, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	704(%rsp), %zmm29, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	768(%rsp), %zmm29, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	832(%rsp), %zmm29, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	896(%rsp), %zmm29, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	448(%rsp), %zmm4, %zmm10        ## 64-byte Folded Reload
	vpdpbusd	512(%rsp), %zmm4, %zmm11        ## 64-byte Folded Reload
	vpdpbusd	576(%rsp), %zmm4, %zmm12        ## 64-byte Folded Reload
	vpdpbusd	640(%rsp), %zmm4, %zmm13        ## 64-byte Folded Reload
	vpdpbusd	%zmm21, %zmm17, %zmm10
	vpdpbusd	256(%rsp), %zmm17, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	320(%rsp), %zmm17, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	384(%rsp), %zmm17, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	%zmm30, %zmm24, %zmm10
	vpdpbusd	%zmm28, %zmm24, %zmm11
	vpdpbusd	%zmm26, %zmm24, %zmm12
	vpdpbusd	%zmm25, %zmm24, %zmm13
	vpdpbusd	%zmm0, %zmm31, %zmm10
	vpdpbusd	%zmm5, %zmm31, %zmm11
	vpdpbusd	%zmm3, %zmm31, %zmm12
	vpdpbusd	%zmm2, %zmm31, %zmm13
	vpdpbusd	%zmm20, %zmm16, %zmm10
	vpdpbusd	%zmm19, %zmm16, %zmm11
	vpdpbusd	%zmm9, %zmm16, %zmm12
	vpdpbusd	%zmm7, %zmm16, %zmm13
LBB1_73:                                ##   in Loop: Header=BB1_11 Depth=1
	movq	56(%rsp), %rdx                  ## 8-byte Reload
	vmovaps	176(%rsp), %xmm20               ## 16-byte Reload
	vmovaps	160(%rsp), %xmm21               ## 16-byte Reload
	vmovaps	144(%rsp), %xmm22               ## 16-byte Reload
	vextracti64x4	$1, %zmm10, %ymm0
	vpaddd	%ymm0, %ymm10, %ymm0
	vextracti64x4	$1, %zmm11, %ymm1
	vpaddd	%ymm1, %ymm11, %ymm1
	vphaddd	%ymm1, %ymm0, %ymm0
	vextracti64x4	$1, %zmm12, %ymm1
	vpaddd	%ymm1, %ymm12, %ymm1
	vextracti64x4	$1, %zmm13, %ymm2
	vpaddd	%ymm2, %ymm13, %ymm2
	vphaddd	%ymm2, %ymm1, %ymm1
	vphaddd	%ymm1, %ymm0, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovss	(%rbx,%rax), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vmovss	4(%rbx,%rax), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vmovss	8(%rbx,%rax), %xmm3             ## xmm3 = mem[0],zero,zero,zero
	vmovss	12(%rbx,%rax), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	vinsertps	$16, (%r14,%rax), %xmm1, %xmm1 ## xmm1 = xmm1[0],mem[0],xmm1[2,3]
	vinsertps	$32, (%r15,%rax), %xmm1, %xmm1 ## xmm1 = xmm1[0,1],mem[0],xmm1[3]
	vinsertps	$48, (%r12,%rax), %xmm1, %xmm1 ## xmm1 = xmm1[0,1,2],mem[0]
	vinsertps	$16, 4(%r14,%rax), %xmm2, %xmm2 ## xmm2 = xmm2[0],mem[0],xmm2[2,3]
	vinsertps	$32, 4(%r15,%rax), %xmm2, %xmm2 ## xmm2 = xmm2[0,1],mem[0],xmm2[3]
	vinsertps	$48, 4(%r12,%rax), %xmm2, %xmm2 ## xmm2 = xmm2[0,1,2],mem[0]
	vinsertps	$16, 8(%r14,%rax), %xmm3, %xmm3 ## xmm3 = xmm3[0],mem[0],xmm3[2,3]
	vinsertps	$32, 8(%r15,%rax), %xmm3, %xmm3 ## xmm3 = xmm3[0,1],mem[0],xmm3[3]
	vinsertps	$48, 8(%r12,%rax), %xmm3, %xmm3 ## xmm3 = xmm3[0,1,2],mem[0]
	vinsertps	$16, 12(%r14,%rax), %xmm4, %xmm4 ## xmm4 = xmm4[0],mem[0],xmm4[2,3]
	vinsertps	$32, 12(%r15,%rax), %xmm4, %xmm4 ## xmm4 = xmm4[0,1],mem[0],xmm4[3]
	vcvtdq2ps	%xmm0, %xmm0
	vinsertps	$48, 12(%r12,%rax), %xmm4, %xmm4 ## xmm4 = xmm4[0,1,2],mem[0]
	vmovd	16(%rbx,%rax), %xmm5            ## xmm5 = mem[0],zero,zero,zero
	vpinsrd	$1, 16(%r14,%rax), %xmm5, %xmm5
	vpinsrd	$2, 16(%r15,%rax), %xmm5, %xmm5
	vsubps	112(%rsp), %xmm2, %xmm2         ## 16-byte Folded Reload
	vpinsrd	$3, 16(%r12,%rax), %xmm5, %xmm5
	vcvtdq2ps	%xmm5, %xmm5
	vmulps	224(%rsp), %xmm5, %xmm5         ## 16-byte Folded Reload
	vaddps	%xmm5, %xmm0, %xmm0
	vmulps	%xmm1, %xmm1, %xmm5
	vmulps	%xmm4, %xmm5, %xmm4
	vaddps	96(%rsp), %xmm4, %xmm4          ## 16-byte Folded Reload
	vaddps	%xmm1, %xmm1, %xmm5
	vmulps	192(%rsp), %xmm5, %xmm5         ## 16-byte Folded Reload
	vmulps	%xmm0, %xmm5, %xmm0
	vsubps	%xmm0, %xmm4, %xmm0
	vmulps	%xmm2, %xmm2, %xmm4
	vmulps	208(%rsp), %xmm4, %xmm4         ## 16-byte Folded Reload
	vaddps	%xmm0, %xmm4, %xmm0
	vaddps	%xmm2, %xmm2, %xmm2
	vmulps	%xmm3, %xmm1, %xmm1
	vsubps	240(%rsp), %xmm1, %xmm1         ## 16-byte Folded Reload
	vmulps	%xmm1, %xmm2, %xmm1
	vaddps	%xmm0, %xmm1, %xmm0
	movq	80(%rsp), %rcx                  ## 8-byte Reload
	vmovups	%xmm0, (%r8,%rcx,4)
	incq	%r11
	cmpq	%rdx, %r11
	movq	64(%rsp), %rdi                  ## 8-byte Reload
	movq	88(%rsp), %r14                  ## 8-byte Reload
	ja	LBB1_5
LBB1_11:                                ## =>This Inner Loop Header: Depth=1
	movq	%r14, %r12
	leaq	4(%r14), %rbx
	cmpq	%rdx, %rbx
	jae	LBB1_12
## %bb.74:                              ##   in Loop: Header=BB1_11 Depth=1
	movq	32(%rdi,%r12,8), %r9
	leaq	1(%rbx), %r11
	cmpq	%rdx, %r11
	jb	LBB1_77
LBB1_76:                                ##   in Loop: Header=BB1_11 Depth=1
	xorl	%ecx, %ecx
	incq	%r11
	cmpq	%rdx, %r11
	jb	LBB1_80
LBB1_79:                                ##   in Loop: Header=BB1_11 Depth=1
	xorl	%r10d, %r10d
	incq	%r11
	cmpq	%rdx, %r11
	movq	%rbx, 88(%rsp)                  ## 8-byte Spill
	jb	LBB1_83
LBB1_82:                                ##   in Loop: Header=BB1_11 Depth=1
	xorl	%r13d, %r13d
	jmp	LBB1_84
	.p2align	4, 0x90
LBB1_12:                                ##   in Loop: Header=BB1_11 Depth=1
	xorl	%r9d, %r9d
	leaq	1(%rbx), %r11
	cmpq	%rdx, %r11
	jae	LBB1_76
LBB1_77:                                ##   in Loop: Header=BB1_11 Depth=1
	movq	40(%rdi,%r12,8), %rcx
	incq	%r11
	cmpq	%rdx, %r11
	jae	LBB1_79
LBB1_80:                                ##   in Loop: Header=BB1_11 Depth=1
	movq	48(%rdi,%r12,8), %r10
	incq	%r11
	cmpq	%rdx, %r11
	movq	%rbx, 88(%rsp)                  ## 8-byte Spill
	jae	LBB1_82
LBB1_83:                                ##   in Loop: Header=BB1_11 Depth=1
	movq	56(%rdi,%r12,8), %r13
LBB1_84:                                ##   in Loop: Header=BB1_11 Depth=1
	movq	(%rdi,%r12,8), %rbx
	movq	8(%rdi,%r12,8), %r14
	movq	16(%rdi,%r12,8), %r15
	movq	%r12, 80(%rsp)                  ## 8-byte Spill
	movq	24(%rdi,%r12,8), %r12
	testq	%r9, %r9
	je	LBB1_85
## %bb.176:                             ##   in Loop: Header=BB1_11 Depth=1
	testq	%rcx, %rcx
	je	LBB1_178
## %bb.177:                             ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	(%rsi), %zmm14
	vmovdqu64	(%rbx), %zmm11
	vmovdqu64	(%r14), %zmm12
	vmovdqu64	(%r15), %zmm13
	vmovups	(%r12), %zmm0
	vmovaps	%zmm0, 3008(%rsp)               ## 64-byte Spill
	prefetcht0	(%r9)
	prefetcht0	(%rcx)
	testq	%r10, %r10
	je	LBB1_14
## %bb.13:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%r10)
LBB1_14:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_16
## %bb.15:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%r13)
LBB1_16:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	64(%rsi), %zmm15
	vmovups	64(%rbx), %zmm0
	vmovaps	%zmm0, 2752(%rsp)               ## 64-byte Spill
	vmovups	64(%r14), %zmm0
	vmovaps	%zmm0, 2816(%rsp)               ## 64-byte Spill
	vmovups	64(%r15), %zmm0
	vmovaps	%zmm0, 2880(%rsp)               ## 64-byte Spill
	vmovups	64(%r12), %zmm0
	vmovaps	%zmm0, 2944(%rsp)               ## 64-byte Spill
	prefetcht0	64(%r9)
	prefetcht0	64(%rcx)
	testq	%r10, %r10
	je	LBB1_18
## %bb.17:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%r10)
LBB1_18:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_20
## %bb.19:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%r13)
LBB1_20:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	128(%rsi), %zmm8
	vmovups	128(%rbx), %zmm0
	vmovaps	%zmm0, 2496(%rsp)               ## 64-byte Spill
	vmovups	128(%r14), %zmm0
	vmovaps	%zmm0, 2560(%rsp)               ## 64-byte Spill
	vmovups	128(%r15), %zmm0
	vmovaps	%zmm0, 2624(%rsp)               ## 64-byte Spill
	vmovups	128(%r12), %zmm0
	vmovaps	%zmm0, 2688(%rsp)               ## 64-byte Spill
	prefetcht0	128(%r9)
	prefetcht0	128(%rcx)
	testq	%r10, %r10
	je	LBB1_22
## %bb.21:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%r10)
LBB1_22:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_24
## %bb.23:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%r13)
LBB1_24:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	192(%rsi), %zmm22
	vmovups	192(%rbx), %zmm0
	vmovaps	%zmm0, 2240(%rsp)               ## 64-byte Spill
	vmovups	192(%r14), %zmm0
	vmovaps	%zmm0, 2304(%rsp)               ## 64-byte Spill
	vmovups	192(%r15), %zmm0
	vmovaps	%zmm0, 2368(%rsp)               ## 64-byte Spill
	vmovups	192(%r12), %zmm0
	vmovaps	%zmm0, 2432(%rsp)               ## 64-byte Spill
	prefetcht0	192(%r9)
	prefetcht0	192(%rcx)
	testq	%r10, %r10
	je	LBB1_26
## %bb.25:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%r10)
LBB1_26:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_28
## %bb.27:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%r13)
LBB1_28:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	256(%rsi), %zmm27
	vmovups	256(%rbx), %zmm0
	vmovaps	%zmm0, 1984(%rsp)               ## 64-byte Spill
	vmovups	256(%r14), %zmm0
	vmovaps	%zmm0, 2048(%rsp)               ## 64-byte Spill
	vmovups	256(%r15), %zmm0
	vmovaps	%zmm0, 2112(%rsp)               ## 64-byte Spill
	vmovups	256(%r12), %zmm0
	vmovaps	%zmm0, 2176(%rsp)               ## 64-byte Spill
	prefetcht0	256(%r9)
	prefetcht0	256(%rcx)
	testq	%r10, %r10
	je	LBB1_30
## %bb.29:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%r10)
LBB1_30:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_32
## %bb.31:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%r13)
LBB1_32:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	320(%rsi), %zmm1
	vmovups	320(%rbx), %zmm0
	vmovaps	%zmm0, 1728(%rsp)               ## 64-byte Spill
	vmovups	320(%r14), %zmm0
	vmovaps	%zmm0, 1792(%rsp)               ## 64-byte Spill
	vmovups	320(%r15), %zmm0
	vmovaps	%zmm0, 1856(%rsp)               ## 64-byte Spill
	vmovups	320(%r12), %zmm0
	vmovaps	%zmm0, 1920(%rsp)               ## 64-byte Spill
	prefetcht0	320(%r9)
	prefetcht0	320(%rcx)
	testq	%r10, %r10
	je	LBB1_34
## %bb.33:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%r10)
LBB1_34:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_36
## %bb.35:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%r13)
LBB1_36:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	384(%rsi), %zmm6
	vmovups	384(%rbx), %zmm0
	vmovaps	%zmm0, 1472(%rsp)               ## 64-byte Spill
	vmovups	384(%r14), %zmm0
	vmovaps	%zmm0, 1536(%rsp)               ## 64-byte Spill
	vmovups	384(%r15), %zmm0
	vmovaps	%zmm0, 1600(%rsp)               ## 64-byte Spill
	vmovups	384(%r12), %zmm0
	vmovaps	%zmm0, 1664(%rsp)               ## 64-byte Spill
	prefetcht0	384(%r9)
	prefetcht0	384(%rcx)
	testq	%r10, %r10
	je	LBB1_38
## %bb.37:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%r10)
LBB1_38:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_40
## %bb.39:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%r13)
LBB1_40:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	448(%rsi), %zmm18
	vmovups	448(%rbx), %zmm0
	vmovaps	%zmm0, 1216(%rsp)               ## 64-byte Spill
	vmovups	448(%r14), %zmm0
	vmovaps	%zmm0, 1280(%rsp)               ## 64-byte Spill
	vmovups	448(%r15), %zmm0
	vmovaps	%zmm0, 1344(%rsp)               ## 64-byte Spill
	vmovups	448(%r12), %zmm0
	vmovaps	%zmm0, 1408(%rsp)               ## 64-byte Spill
	prefetcht0	448(%r9)
	prefetcht0	448(%rcx)
	testq	%r10, %r10
	je	LBB1_42
## %bb.41:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%r10)
LBB1_42:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_44
## %bb.43:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%r13)
LBB1_44:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	512(%rsi), %zmm23
	vmovups	512(%rbx), %zmm0
	vmovaps	%zmm0, 960(%rsp)                ## 64-byte Spill
	vmovups	512(%r14), %zmm0
	vmovaps	%zmm0, 1024(%rsp)               ## 64-byte Spill
	vmovups	512(%r15), %zmm0
	vmovaps	%zmm0, 1088(%rsp)               ## 64-byte Spill
	vmovups	512(%r12), %zmm0
	vmovaps	%zmm0, 1152(%rsp)               ## 64-byte Spill
	prefetcht0	512(%r9)
	prefetcht0	512(%rcx)
	testq	%r10, %r10
	je	LBB1_46
## %bb.45:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%r10)
LBB1_46:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_48
## %bb.47:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%r13)
LBB1_48:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	576(%rsi), %zmm29
	vmovups	576(%rbx), %zmm0
	vmovaps	%zmm0, 704(%rsp)                ## 64-byte Spill
	vmovups	576(%r14), %zmm0
	vmovaps	%zmm0, 768(%rsp)                ## 64-byte Spill
	vmovups	576(%r15), %zmm0
	vmovaps	%zmm0, 832(%rsp)                ## 64-byte Spill
	vmovups	576(%r12), %zmm0
	vmovaps	%zmm0, 896(%rsp)                ## 64-byte Spill
	prefetcht0	576(%r9)
	prefetcht0	576(%rcx)
	testq	%r10, %r10
	je	LBB1_50
## %bb.49:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%r10)
LBB1_50:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_52
## %bb.51:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%r13)
LBB1_52:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	640(%rsi), %zmm4
	vmovups	640(%rbx), %zmm0
	vmovaps	%zmm0, 448(%rsp)                ## 64-byte Spill
	vmovups	640(%r14), %zmm0
	vmovaps	%zmm0, 512(%rsp)                ## 64-byte Spill
	vmovups	640(%r15), %zmm0
	vmovaps	%zmm0, 576(%rsp)                ## 64-byte Spill
	vmovups	640(%r12), %zmm0
	vmovaps	%zmm0, 640(%rsp)                ## 64-byte Spill
	prefetcht0	640(%r9)
	prefetcht0	640(%rcx)
	testq	%r10, %r10
	je	LBB1_54
## %bb.53:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%r10)
LBB1_54:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_56
## %bb.55:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%r13)
LBB1_56:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	704(%rsi), %zmm17
	vmovdqu64	704(%rbx), %zmm21
	vmovups	704(%r14), %zmm0
	vmovaps	%zmm0, 256(%rsp)                ## 64-byte Spill
	vmovups	704(%r15), %zmm0
	vmovaps	%zmm0, 320(%rsp)                ## 64-byte Spill
	vmovups	704(%r12), %zmm0
	vmovaps	%zmm0, 384(%rsp)                ## 64-byte Spill
	prefetcht0	704(%r9)
	prefetcht0	704(%rcx)
	testq	%r10, %r10
	je	LBB1_58
## %bb.57:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%r10)
LBB1_58:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_60
## %bb.59:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%r13)
LBB1_60:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	768(%rsi), %zmm24
	vmovdqu64	768(%rbx), %zmm30
	vmovdqu64	768(%r14), %zmm28
	vmovdqu64	768(%r15), %zmm26
	vmovdqu64	768(%r12), %zmm25
	prefetcht0	768(%r9)
	prefetcht0	768(%rcx)
	testq	%r10, %r10
	je	LBB1_62
## %bb.61:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%r10)
LBB1_62:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_64
## %bb.63:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%r13)
LBB1_64:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	832(%rsi), %zmm31
	vmovdqu64	832(%rbx), %zmm0
	vmovdqu64	832(%r14), %zmm5
	vmovdqu64	832(%r15), %zmm3
	vmovdqu64	832(%r12), %zmm2
	prefetcht0	832(%r9)
	prefetcht0	832(%rcx)
	testq	%r10, %r10
	je	LBB1_66
## %bb.65:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%r10)
LBB1_66:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_68
## %bb.67:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%r13)
LBB1_68:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	896(%rsi), %zmm16
	vmovdqu64	896(%rbx), %zmm20
	vmovdqu64	896(%r14), %zmm19
	vmovdqu64	896(%r15), %zmm9
	vmovdqu64	896(%r12), %zmm7
	prefetcht0	896(%r9)
	prefetcht0	896(%rcx)
	testq	%r10, %r10
	je	LBB1_70
## %bb.69:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%r10)
LBB1_70:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_72
## %bb.71:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%r13)
	jmp	LBB1_72
	.p2align	4, 0x90
LBB1_85:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	(%rsi), %zmm14
	vmovdqu64	(%rbx), %zmm11
	vmovdqu64	(%r14), %zmm12
	vmovdqu64	(%r15), %zmm13
	vmovups	(%r12), %zmm0
	vmovaps	%zmm0, 3008(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_87
## %bb.86:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%rcx)
LBB1_87:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_89
## %bb.88:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%r10)
LBB1_89:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_91
## %bb.90:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%r13)
LBB1_91:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	64(%rsi), %zmm16
	vmovups	64(%rbx), %zmm0
	vmovaps	%zmm0, 2752(%rsp)               ## 64-byte Spill
	vmovups	64(%r14), %zmm0
	vmovaps	%zmm0, 2816(%rsp)               ## 64-byte Spill
	vmovups	64(%r15), %zmm0
	vmovaps	%zmm0, 2880(%rsp)               ## 64-byte Spill
	vmovups	64(%r12), %zmm0
	vmovaps	%zmm0, 2944(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_93
## %bb.92:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%rcx)
LBB1_93:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_95
## %bb.94:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%r10)
LBB1_95:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_97
## %bb.96:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%r13)
LBB1_97:                                ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	128(%rsi), %zmm21
	vmovups	128(%rbx), %zmm0
	vmovaps	%zmm0, 2496(%rsp)               ## 64-byte Spill
	vmovups	128(%r14), %zmm0
	vmovaps	%zmm0, 2560(%rsp)               ## 64-byte Spill
	vmovups	128(%r15), %zmm0
	vmovaps	%zmm0, 2624(%rsp)               ## 64-byte Spill
	vmovups	128(%r12), %zmm0
	vmovaps	%zmm0, 2688(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_99
## %bb.98:                              ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%rcx)
LBB1_99:                                ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_101
## %bb.100:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%r10)
LBB1_101:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_103
## %bb.102:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%r13)
LBB1_103:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	192(%rsi), %zmm26
	vmovups	192(%rbx), %zmm0
	vmovaps	%zmm0, 2240(%rsp)               ## 64-byte Spill
	vmovups	192(%r14), %zmm0
	vmovaps	%zmm0, 2304(%rsp)               ## 64-byte Spill
	vmovups	192(%r15), %zmm0
	vmovaps	%zmm0, 2368(%rsp)               ## 64-byte Spill
	vmovups	192(%r12), %zmm0
	vmovaps	%zmm0, 2432(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_105
## %bb.104:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%rcx)
LBB1_105:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_107
## %bb.106:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%r10)
LBB1_107:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_109
## %bb.108:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%r13)
LBB1_109:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	256(%rsi), %zmm31
	vmovups	256(%rbx), %zmm0
	vmovaps	%zmm0, 1984(%rsp)               ## 64-byte Spill
	vmovups	256(%r14), %zmm0
	vmovaps	%zmm0, 2048(%rsp)               ## 64-byte Spill
	vmovups	256(%r15), %zmm0
	vmovaps	%zmm0, 2112(%rsp)               ## 64-byte Spill
	vmovups	256(%r12), %zmm0
	vmovaps	%zmm0, 2176(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_111
## %bb.110:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%rcx)
LBB1_111:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_113
## %bb.112:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%r10)
LBB1_113:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_115
## %bb.114:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%r13)
LBB1_115:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	320(%rsi), %zmm7
	vmovups	320(%rbx), %zmm0
	vmovaps	%zmm0, 1728(%rsp)               ## 64-byte Spill
	vmovups	320(%r14), %zmm0
	vmovaps	%zmm0, 1792(%rsp)               ## 64-byte Spill
	vmovups	320(%r15), %zmm0
	vmovaps	%zmm0, 1856(%rsp)               ## 64-byte Spill
	vmovups	320(%r12), %zmm0
	vmovaps	%zmm0, 1920(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_117
## %bb.116:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%rcx)
LBB1_117:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_119
## %bb.118:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%r10)
LBB1_119:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_121
## %bb.120:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%r13)
LBB1_121:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	384(%rsi), %zmm18
	vmovups	384(%rbx), %zmm0
	vmovaps	%zmm0, 1472(%rsp)               ## 64-byte Spill
	vmovups	384(%r14), %zmm0
	vmovaps	%zmm0, 1536(%rsp)               ## 64-byte Spill
	vmovups	384(%r15), %zmm0
	vmovaps	%zmm0, 1600(%rsp)               ## 64-byte Spill
	vmovups	384(%r12), %zmm0
	vmovaps	%zmm0, 1664(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_123
## %bb.122:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%rcx)
LBB1_123:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_125
## %bb.124:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%r10)
LBB1_125:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_127
## %bb.126:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%r13)
LBB1_127:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	448(%rsi), %zmm24
	vmovups	448(%rbx), %zmm0
	vmovaps	%zmm0, 1216(%rsp)               ## 64-byte Spill
	vmovups	448(%r14), %zmm0
	vmovaps	%zmm0, 1280(%rsp)               ## 64-byte Spill
	vmovups	448(%r15), %zmm0
	vmovaps	%zmm0, 1344(%rsp)               ## 64-byte Spill
	vmovups	448(%r12), %zmm0
	vmovaps	%zmm0, 1408(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_129
## %bb.128:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%rcx)
LBB1_129:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_131
## %bb.130:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%r10)
LBB1_131:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_133
## %bb.132:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%r13)
LBB1_133:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	512(%rsi), %zmm1
	vmovups	512(%rbx), %zmm0
	vmovaps	%zmm0, 960(%rsp)                ## 64-byte Spill
	vmovups	512(%r14), %zmm0
	vmovaps	%zmm0, 1024(%rsp)               ## 64-byte Spill
	vmovups	512(%r15), %zmm0
	vmovaps	%zmm0, 1088(%rsp)               ## 64-byte Spill
	vmovups	512(%r12), %zmm0
	vmovaps	%zmm0, 1152(%rsp)               ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_135
## %bb.134:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%rcx)
LBB1_135:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_137
## %bb.136:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%r10)
LBB1_137:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_139
## %bb.138:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%r13)
LBB1_139:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	576(%rsi), %zmm0
	vmovups	576(%rbx), %zmm2
	vmovaps	%zmm2, 704(%rsp)                ## 64-byte Spill
	vmovups	576(%r14), %zmm2
	vmovaps	%zmm2, 768(%rsp)                ## 64-byte Spill
	vmovups	576(%r15), %zmm2
	vmovaps	%zmm2, 832(%rsp)                ## 64-byte Spill
	vmovups	576(%r12), %zmm2
	vmovaps	%zmm2, 896(%rsp)                ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_141
## %bb.140:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%rcx)
LBB1_141:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_143
## %bb.142:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%r10)
LBB1_143:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_145
## %bb.144:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%r13)
LBB1_145:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	640(%rsi), %zmm15
	vmovups	640(%rbx), %zmm2
	vmovaps	%zmm2, 448(%rsp)                ## 64-byte Spill
	vmovups	640(%r14), %zmm2
	vmovaps	%zmm2, 512(%rsp)                ## 64-byte Spill
	vmovups	640(%r15), %zmm2
	vmovaps	%zmm2, 576(%rsp)                ## 64-byte Spill
	vmovups	640(%r12), %zmm2
	vmovaps	%zmm2, 640(%rsp)                ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_147
## %bb.146:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%rcx)
LBB1_147:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_149
## %bb.148:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%r10)
LBB1_149:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_151
## %bb.150:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%r13)
LBB1_151:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	704(%rsi), %zmm23
	vmovdqu64	704(%rbx), %zmm29
	vmovups	704(%r14), %zmm2
	vmovaps	%zmm2, 256(%rsp)                ## 64-byte Spill
	vmovups	704(%r15), %zmm2
	vmovaps	%zmm2, 320(%rsp)                ## 64-byte Spill
	vmovups	704(%r12), %zmm2
	vmovaps	%zmm2, 384(%rsp)                ## 64-byte Spill
	testq	%rcx, %rcx
	je	LBB1_153
## %bb.152:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%rcx)
LBB1_153:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_155
## %bb.154:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%r10)
LBB1_155:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_157
## %bb.156:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%r13)
LBB1_157:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	768(%rsi), %zmm2
	vmovdqu64	768(%rbx), %zmm5
	vmovdqu64	768(%r14), %zmm4
	vmovdqu64	768(%r15), %zmm3
	vmovdqu64	768(%r12), %zmm30
	testq	%rcx, %rcx
	je	LBB1_159
## %bb.158:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%rcx)
LBB1_159:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_161
## %bb.160:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%r10)
LBB1_161:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_163
## %bb.162:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%r13)
LBB1_163:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	832(%rsi), %zmm6
	vmovdqu64	832(%rbx), %zmm19
	vmovdqu64	832(%r14), %zmm17
	vmovdqu64	832(%r15), %zmm9
	vmovdqu64	832(%r12), %zmm8
	testq	%rcx, %rcx
	je	LBB1_165
## %bb.164:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%rcx)
LBB1_165:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_167
## %bb.166:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%r10)
LBB1_167:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_169
## %bb.168:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%r13)
LBB1_169:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	896(%rsi), %zmm20
	vmovdqu64	896(%rbx), %zmm28
	vmovdqu64	896(%r14), %zmm27
	vmovdqu64	896(%r15), %zmm25
	vmovdqu64	896(%r12), %zmm22
	testq	%rcx, %rcx
	je	LBB1_171
## %bb.170:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%rcx)
LBB1_171:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r10, %r10
	je	LBB1_173
## %bb.172:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%r10)
LBB1_173:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_175
## %bb.174:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%r13)
LBB1_175:                               ##   in Loop: Header=BB1_11 Depth=1
	vpxor	%xmm10, %xmm10, %xmm10
	vpdpbusd	%zmm11, %zmm14, %zmm10
	vpxor	%xmm11, %xmm11, %xmm11
	vpdpbusd	%zmm12, %zmm14, %zmm11
	vpxor	%xmm12, %xmm12, %xmm12
	vpdpbusd	%zmm13, %zmm14, %zmm12
	vpxor	%xmm13, %xmm13, %xmm13
	vpdpbusd	3008(%rsp), %zmm14, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	2752(%rsp), %zmm16, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2816(%rsp), %zmm16, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2880(%rsp), %zmm16, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2944(%rsp), %zmm16, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	2496(%rsp), %zmm21, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2560(%rsp), %zmm21, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2624(%rsp), %zmm21, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2688(%rsp), %zmm21, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	2240(%rsp), %zmm26, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2304(%rsp), %zmm26, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2368(%rsp), %zmm26, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2432(%rsp), %zmm26, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1984(%rsp), %zmm31, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2048(%rsp), %zmm31, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2112(%rsp), %zmm31, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2176(%rsp), %zmm31, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1728(%rsp), %zmm7, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	1792(%rsp), %zmm7, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	1856(%rsp), %zmm7, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	1920(%rsp), %zmm7, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	1472(%rsp), %zmm18, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	1536(%rsp), %zmm18, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1600(%rsp), %zmm18, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1664(%rsp), %zmm18, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1216(%rsp), %zmm24, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	1280(%rsp), %zmm24, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1344(%rsp), %zmm24, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1408(%rsp), %zmm24, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	960(%rsp), %zmm1, %zmm10        ## 64-byte Folded Reload
	vpdpbusd	1024(%rsp), %zmm1, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	1088(%rsp), %zmm1, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	1152(%rsp), %zmm1, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	704(%rsp), %zmm0, %zmm10        ## 64-byte Folded Reload
	vpdpbusd	768(%rsp), %zmm0, %zmm11        ## 64-byte Folded Reload
	vpdpbusd	832(%rsp), %zmm0, %zmm12        ## 64-byte Folded Reload
	vpdpbusd	896(%rsp), %zmm0, %zmm13        ## 64-byte Folded Reload
	vpdpbusd	448(%rsp), %zmm15, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	512(%rsp), %zmm15, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	576(%rsp), %zmm15, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	640(%rsp), %zmm15, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	%zmm29, %zmm23, %zmm10
	vpdpbusd	256(%rsp), %zmm23, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	320(%rsp), %zmm23, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	384(%rsp), %zmm23, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	%zmm5, %zmm2, %zmm10
	vpdpbusd	%zmm4, %zmm2, %zmm11
	vpdpbusd	%zmm3, %zmm2, %zmm12
	vpdpbusd	%zmm30, %zmm2, %zmm13
	vpdpbusd	%zmm19, %zmm6, %zmm10
	vpdpbusd	%zmm17, %zmm6, %zmm11
	vpdpbusd	%zmm9, %zmm6, %zmm12
	vpdpbusd	%zmm8, %zmm6, %zmm13
	vpdpbusd	%zmm28, %zmm20, %zmm10
	vpdpbusd	%zmm27, %zmm20, %zmm11
	vpdpbusd	%zmm25, %zmm20, %zmm12
	vpdpbusd	%zmm22, %zmm20, %zmm13
	jmp	LBB1_73
	.p2align	4, 0x90
LBB1_178:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	(%rsi), %zmm3
	vmovdqu64	(%rbx), %zmm11
	vmovdqu64	(%r14), %zmm12
	vmovdqu64	(%r15), %zmm13
	vmovups	(%r12), %zmm0
	vmovaps	%zmm0, 3008(%rsp)               ## 64-byte Spill
	prefetcht0	(%r9)
	testq	%r10, %r10
	je	LBB1_180
## %bb.179:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%r10)
LBB1_180:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_182
## %bb.181:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	(%r13)
LBB1_182:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	64(%rsi), %zmm8
	vmovups	64(%rbx), %zmm0
	vmovaps	%zmm0, 2752(%rsp)               ## 64-byte Spill
	vmovups	64(%r14), %zmm0
	vmovaps	%zmm0, 2816(%rsp)               ## 64-byte Spill
	vmovups	64(%r15), %zmm0
	vmovaps	%zmm0, 2880(%rsp)               ## 64-byte Spill
	vmovups	64(%r12), %zmm0
	vmovaps	%zmm0, 2944(%rsp)               ## 64-byte Spill
	prefetcht0	64(%r9)
	testq	%r10, %r10
	je	LBB1_184
## %bb.183:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%r10)
LBB1_184:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_186
## %bb.185:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	64(%r13)
LBB1_186:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	128(%rsi), %zmm17
	vmovups	128(%rbx), %zmm0
	vmovaps	%zmm0, 2496(%rsp)               ## 64-byte Spill
	vmovups	128(%r14), %zmm0
	vmovaps	%zmm0, 2560(%rsp)               ## 64-byte Spill
	vmovups	128(%r15), %zmm0
	vmovaps	%zmm0, 2624(%rsp)               ## 64-byte Spill
	vmovups	128(%r12), %zmm0
	vmovaps	%zmm0, 2688(%rsp)               ## 64-byte Spill
	prefetcht0	128(%r9)
	testq	%r10, %r10
	je	LBB1_188
## %bb.187:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%r10)
LBB1_188:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_190
## %bb.189:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	128(%r13)
LBB1_190:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	192(%rsi), %zmm22
	vmovups	192(%rbx), %zmm0
	vmovaps	%zmm0, 2240(%rsp)               ## 64-byte Spill
	vmovups	192(%r14), %zmm0
	vmovaps	%zmm0, 2304(%rsp)               ## 64-byte Spill
	vmovups	192(%r15), %zmm0
	vmovaps	%zmm0, 2368(%rsp)               ## 64-byte Spill
	vmovups	192(%r12), %zmm0
	vmovaps	%zmm0, 2432(%rsp)               ## 64-byte Spill
	prefetcht0	192(%r9)
	testq	%r10, %r10
	je	LBB1_192
## %bb.191:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%r10)
LBB1_192:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_194
## %bb.193:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	192(%r13)
LBB1_194:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	256(%rsi), %zmm1
	vmovups	256(%rbx), %zmm0
	vmovaps	%zmm0, 1984(%rsp)               ## 64-byte Spill
	vmovups	256(%r14), %zmm0
	vmovaps	%zmm0, 2048(%rsp)               ## 64-byte Spill
	vmovups	256(%r15), %zmm0
	vmovaps	%zmm0, 2112(%rsp)               ## 64-byte Spill
	vmovups	256(%r12), %zmm0
	vmovaps	%zmm0, 2176(%rsp)               ## 64-byte Spill
	prefetcht0	256(%r9)
	testq	%r10, %r10
	je	LBB1_196
## %bb.195:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%r10)
LBB1_196:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_198
## %bb.197:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	256(%r13)
LBB1_198:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	320(%rsi), %zmm30
	vmovups	320(%rbx), %zmm0
	vmovaps	%zmm0, 1728(%rsp)               ## 64-byte Spill
	vmovups	320(%r14), %zmm0
	vmovaps	%zmm0, 1792(%rsp)               ## 64-byte Spill
	vmovups	320(%r15), %zmm0
	vmovaps	%zmm0, 1856(%rsp)               ## 64-byte Spill
	vmovups	320(%r12), %zmm0
	vmovaps	%zmm0, 1920(%rsp)               ## 64-byte Spill
	prefetcht0	320(%r9)
	testq	%r10, %r10
	je	LBB1_200
## %bb.199:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%r10)
LBB1_200:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_202
## %bb.201:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	320(%r13)
LBB1_202:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	384(%rsi), %zmm6
	vmovups	384(%rbx), %zmm0
	vmovaps	%zmm0, 1472(%rsp)               ## 64-byte Spill
	vmovups	384(%r14), %zmm0
	vmovaps	%zmm0, 1536(%rsp)               ## 64-byte Spill
	vmovups	384(%r15), %zmm0
	vmovaps	%zmm0, 1600(%rsp)               ## 64-byte Spill
	vmovups	384(%r12), %zmm0
	vmovaps	%zmm0, 1664(%rsp)               ## 64-byte Spill
	prefetcht0	384(%r9)
	testq	%r10, %r10
	je	LBB1_204
## %bb.203:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%r10)
LBB1_204:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_206
## %bb.205:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	384(%r13)
LBB1_206:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	448(%rsi), %zmm16
	vmovups	448(%rbx), %zmm0
	vmovaps	%zmm0, 1216(%rsp)               ## 64-byte Spill
	vmovups	448(%r14), %zmm0
	vmovaps	%zmm0, 1280(%rsp)               ## 64-byte Spill
	vmovups	448(%r15), %zmm0
	vmovaps	%zmm0, 1344(%rsp)               ## 64-byte Spill
	vmovups	448(%r12), %zmm0
	vmovaps	%zmm0, 1408(%rsp)               ## 64-byte Spill
	prefetcht0	448(%r9)
	testq	%r10, %r10
	je	LBB1_208
## %bb.207:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%r10)
LBB1_208:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_210
## %bb.209:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	448(%r13)
LBB1_210:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	512(%rsi), %zmm23
	vmovups	512(%rbx), %zmm0
	vmovaps	%zmm0, 960(%rsp)                ## 64-byte Spill
	vmovups	512(%r14), %zmm0
	vmovaps	%zmm0, 1024(%rsp)               ## 64-byte Spill
	vmovups	512(%r15), %zmm0
	vmovaps	%zmm0, 1088(%rsp)               ## 64-byte Spill
	vmovups	512(%r12), %zmm0
	vmovaps	%zmm0, 1152(%rsp)               ## 64-byte Spill
	prefetcht0	512(%r9)
	testq	%r10, %r10
	je	LBB1_212
## %bb.211:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%r10)
LBB1_212:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_214
## %bb.213:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	512(%r13)
LBB1_214:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	576(%rsi), %zmm27
	vmovups	576(%rbx), %zmm0
	vmovaps	%zmm0, 704(%rsp)                ## 64-byte Spill
	vmovups	576(%r14), %zmm0
	vmovaps	%zmm0, 768(%rsp)                ## 64-byte Spill
	vmovups	576(%r15), %zmm0
	vmovaps	%zmm0, 832(%rsp)                ## 64-byte Spill
	vmovups	576(%r12), %zmm0
	vmovaps	%zmm0, 896(%rsp)                ## 64-byte Spill
	prefetcht0	576(%r9)
	testq	%r10, %r10
	je	LBB1_216
## %bb.215:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%r10)
LBB1_216:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_218
## %bb.217:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	576(%r13)
LBB1_218:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	640(%rsi), %zmm4
	vmovups	640(%rbx), %zmm0
	vmovaps	%zmm0, 448(%rsp)                ## 64-byte Spill
	vmovups	640(%r14), %zmm0
	vmovaps	%zmm0, 512(%rsp)                ## 64-byte Spill
	vmovups	640(%r15), %zmm0
	vmovaps	%zmm0, 576(%rsp)                ## 64-byte Spill
	vmovups	640(%r12), %zmm0
	vmovaps	%zmm0, 640(%rsp)                ## 64-byte Spill
	prefetcht0	640(%r9)
	testq	%r10, %r10
	je	LBB1_220
## %bb.219:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%r10)
LBB1_220:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_222
## %bb.221:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	640(%r13)
LBB1_222:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	704(%rsi), %zmm15
	vmovdqu64	704(%rbx), %zmm21
	vmovups	704(%r14), %zmm0
	vmovaps	%zmm0, 256(%rsp)                ## 64-byte Spill
	vmovups	704(%r15), %zmm0
	vmovaps	%zmm0, 320(%rsp)                ## 64-byte Spill
	vmovups	704(%r12), %zmm0
	vmovaps	%zmm0, 384(%rsp)                ## 64-byte Spill
	prefetcht0	704(%r9)
	testq	%r10, %r10
	je	LBB1_224
## %bb.223:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%r10)
LBB1_224:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_226
## %bb.225:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	704(%r13)
LBB1_226:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	768(%rsi), %zmm24
	vmovdqu64	768(%rbx), %zmm28
	vmovdqu64	768(%r14), %zmm2
	vmovdqu64	768(%r15), %zmm26
	vmovdqu64	768(%r12), %zmm25
	prefetcht0	768(%r9)
	testq	%r10, %r10
	je	LBB1_228
## %bb.227:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%r10)
LBB1_228:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_230
## %bb.229:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	768(%r13)
LBB1_230:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	832(%rsi), %zmm29
	vmovdqu64	832(%rbx), %zmm7
	vmovdqu64	832(%r14), %zmm5
	vmovdqu64	832(%r15), %zmm0
	vmovdqu64	832(%r12), %zmm31
	prefetcht0	832(%r9)
	testq	%r10, %r10
	je	LBB1_232
## %bb.231:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%r10)
LBB1_232:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_234
## %bb.233:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	832(%r13)
LBB1_234:                               ##   in Loop: Header=BB1_11 Depth=1
	vmovdqu64	896(%rsi), %zmm9
	vmovdqu64	896(%rbx), %zmm20
	vmovdqu64	896(%r14), %zmm19
	vmovdqu64	896(%r15), %zmm18
	vmovdqu64	896(%r12), %zmm14
	prefetcht0	896(%r9)
	testq	%r10, %r10
	je	LBB1_236
## %bb.235:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%r10)
LBB1_236:                               ##   in Loop: Header=BB1_11 Depth=1
	testq	%r13, %r13
	je	LBB1_238
## %bb.237:                             ##   in Loop: Header=BB1_11 Depth=1
	prefetcht0	896(%r13)
LBB1_238:                               ##   in Loop: Header=BB1_11 Depth=1
	vpxor	%xmm10, %xmm10, %xmm10
	vpdpbusd	%zmm11, %zmm3, %zmm10
	vpxor	%xmm11, %xmm11, %xmm11
	vpdpbusd	%zmm12, %zmm3, %zmm11
	vpxor	%xmm12, %xmm12, %xmm12
	vpdpbusd	%zmm13, %zmm3, %zmm12
	vpxor	%xmm13, %xmm13, %xmm13
	vpdpbusd	3008(%rsp), %zmm3, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	2752(%rsp), %zmm8, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	2816(%rsp), %zmm8, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	2880(%rsp), %zmm8, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	2944(%rsp), %zmm8, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	2496(%rsp), %zmm17, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2560(%rsp), %zmm17, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2624(%rsp), %zmm17, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2688(%rsp), %zmm17, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	2240(%rsp), %zmm22, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	2304(%rsp), %zmm22, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	2368(%rsp), %zmm22, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	2432(%rsp), %zmm22, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1984(%rsp), %zmm1, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	2048(%rsp), %zmm1, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	2112(%rsp), %zmm1, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	2176(%rsp), %zmm1, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	1728(%rsp), %zmm30, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	1792(%rsp), %zmm30, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1856(%rsp), %zmm30, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1920(%rsp), %zmm30, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	1472(%rsp), %zmm6, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	1536(%rsp), %zmm6, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	1600(%rsp), %zmm6, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	1664(%rsp), %zmm6, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	1216(%rsp), %zmm16, %zmm10      ## 64-byte Folded Reload
	vpdpbusd	1280(%rsp), %zmm16, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1344(%rsp), %zmm16, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1408(%rsp), %zmm16, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	960(%rsp), %zmm23, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	1024(%rsp), %zmm23, %zmm11      ## 64-byte Folded Reload
	vpdpbusd	1088(%rsp), %zmm23, %zmm12      ## 64-byte Folded Reload
	vpdpbusd	1152(%rsp), %zmm23, %zmm13      ## 64-byte Folded Reload
	vpdpbusd	704(%rsp), %zmm27, %zmm10       ## 64-byte Folded Reload
	vpdpbusd	768(%rsp), %zmm27, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	832(%rsp), %zmm27, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	896(%rsp), %zmm27, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	448(%rsp), %zmm4, %zmm10        ## 64-byte Folded Reload
	vpdpbusd	512(%rsp), %zmm4, %zmm11        ## 64-byte Folded Reload
	vpdpbusd	576(%rsp), %zmm4, %zmm12        ## 64-byte Folded Reload
	vpdpbusd	640(%rsp), %zmm4, %zmm13        ## 64-byte Folded Reload
	vpdpbusd	%zmm21, %zmm15, %zmm10
	vpdpbusd	256(%rsp), %zmm15, %zmm11       ## 64-byte Folded Reload
	vpdpbusd	320(%rsp), %zmm15, %zmm12       ## 64-byte Folded Reload
	vpdpbusd	384(%rsp), %zmm15, %zmm13       ## 64-byte Folded Reload
	vpdpbusd	%zmm28, %zmm24, %zmm10
	vpdpbusd	%zmm2, %zmm24, %zmm11
	vpdpbusd	%zmm26, %zmm24, %zmm12
	vpdpbusd	%zmm25, %zmm24, %zmm13
	vpdpbusd	%zmm7, %zmm29, %zmm10
	vpdpbusd	%zmm5, %zmm29, %zmm11
	vpdpbusd	%zmm0, %zmm29, %zmm12
	vpdpbusd	%zmm31, %zmm29, %zmm13
	vpdpbusd	%zmm20, %zmm9, %zmm10
	vpdpbusd	%zmm19, %zmm9, %zmm11
	vpdpbusd	%zmm18, %zmm9, %zmm12
	vpdpbusd	%zmm14, %zmm9, %zmm13
	jmp	LBB1_73
LBB1_241:
	cmpq	$127, %rax
	movl	$127, %ecx
	cmovaq	%rax, %rcx
	andl	$-64, %ecx
	leaq	1(%rcx), %r9
	cmpq	%rax, %r9
	cmovbeq	%rax, %r9
	movq	%r9, %rdx
	subq	%rcx, %rdx
	movl	%r9d, %r11d
	andl	$63, %r11d
	movq	%rdx, %rbx
	movq	%r11, 96(%rsp)                  ## 8-byte Spill
	subq	%r11, %rbx
	movq	%rbx, 112(%rsp)                 ## 8-byte Spill
	movl	%r9d, %r11d
	andl	$-8, %r11d
	subq	%rcx, %r11
	movq	%r11, 72(%rsp)                  ## 8-byte Spill
	movq	%r9, %r11
	movq	%r9, 88(%rsp)                   ## 8-byte Spill
                                        ## kill: def $r9d killed $r9d killed $r9 def $r9
	andl	$-64, %r9d
	subq	%rcx, %r9
	movq	%r9, 192(%rsp)                  ## 8-byte Spill
	vmovss	LCPI1_0(%rip), %xmm5            ## xmm5 = mem[0],zero,zero,zero
	vmovss	LCPI1_3(%rip), %xmm6            ## xmm6 = mem[0],zero,zero,zero
	jmp	LBB1_242
	.p2align	4, 0x90
LBB1_245:                               ##   in Loop: Header=BB1_242 Depth=1
	movq	56(%rsp), %r9                   ## 8-byte Reload
	movq	64(%rsp), %rdi                  ## 8-byte Reload
LBB1_304:                               ##   in Loop: Header=BB1_242 Depth=1
	vcvtsi2ss	%r12d, %xmm13, %xmm0
	movq	(%r10), %rcx
	vmovss	(%rcx,%rax), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vcvtsi2ssl	16(%rcx,%rax), %xmm13, %xmm2
	vmovss	4(%rcx,%rax), %xmm7             ## xmm7 = mem[0],zero,zero,zero
	vmulss	%xmm1, %xmm1, %xmm8
	vfmadd132ss	12(%rcx,%rax), %xmm22, %xmm8 ## xmm8 = (xmm8 * mem) + xmm22
	vfmadd132ss	%xmm5, %xmm0, %xmm2     ## xmm2 = (xmm2 * xmm5) + xmm0
	vmulss	%xmm6, %xmm1, %xmm0
	vmulss	%xmm0, %xmm20, %xmm0
	vfmadd213ss	%xmm8, %xmm2, %xmm0     ## xmm0 = (xmm2 * xmm0) + xmm8
	vsubss	%xmm21, %xmm7, %xmm2
	vmulss	%xmm2, %xmm2, %xmm7
	vfmadd213ss	%xmm0, %xmm4, %xmm7     ## xmm7 = (xmm4 * xmm7) + xmm0
	vaddss	%xmm2, %xmm2, %xmm0
	vfmadd132ss	8(%rcx,%rax), %xmm3, %xmm1 ## xmm1 = (xmm1 * mem) + xmm3
	vfmadd213ss	%xmm7, %xmm0, %xmm1     ## xmm1 = (xmm0 * xmm1) + xmm7
	vmovss	%xmm1, (%r8)
	addq	$8, %r10
	addq	$4, %r8
	movq	%rbx, %r14
	incq	%r14
	cmpq	%r9, %r14
	je	LBB1_305
LBB1_242:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_243 Depth 2
                                        ##     Child Loop BB1_295 Depth 2
                                        ##     Child Loop BB1_301 Depth 2
                                        ##     Child Loop BB1_303 Depth 2
	movq	%r14, %rbx
	movq	(%rdi,%r14,8), %r14
	vpxor	%xmm0, %xmm0, %xmm0
	movl	$112, %edi
	movq	%rsi, %r13
	movq	%r14, %r15
	xorl	%ecx, %ecx
	.p2align	4, 0x90
LBB1_243:                               ##   Parent Loop BB1_242 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rcx, %r12
	movq	%rdi, %r11
	vmovdqu64	(%rsi,%rcx), %zmm1
	vpdpbusd	(%r14,%rcx), %zmm1, %zmm0
	addq	$64, %rcx
	subq	$-128, %r12
	addq	$64, %rdi
	addq	$64, %r15
	addq	$64, %r13
	cmpq	%rax, %r12
	jbe	LBB1_243
## %bb.244:                             ##   in Loop: Header=BB1_242 Depth=1
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %r12d
	cmpq	%rax, %rcx
	jae	LBB1_245
## %bb.290:                             ##   in Loop: Header=BB1_242 Depth=1
	cmpq	$8, %rdx
	jae	LBB1_292
## %bb.291:                             ##   in Loop: Header=BB1_242 Depth=1
	movq	56(%rsp), %r9                   ## 8-byte Reload
	movq	64(%rsp), %rdi                  ## 8-byte Reload
	jmp	LBB1_303
	.p2align	4, 0x90
LBB1_292:                               ##   in Loop: Header=BB1_242 Depth=1
	cmpq	$64, %rdx
	jae	LBB1_294
## %bb.293:                             ##   in Loop: Header=BB1_242 Depth=1
	xorl	%r11d, %r11d
	movq	64(%rsp), %rdi                  ## 8-byte Reload
	jmp	LBB1_300
LBB1_294:                               ##   in Loop: Header=BB1_242 Depth=1
	vmovd	%r12d, %xmm0
	vpxor	%xmm1, %xmm1, %xmm1
	movq	112(%rsp), %rdi                 ## 8-byte Reload
	vxorps	%xmm2, %xmm2, %xmm2
	vxorps	%xmm7, %xmm7, %xmm7
	movq	96(%rsp), %r9                   ## 8-byte Reload
	.p2align	4, 0x90
LBB1_295:                               ##   Parent Loop BB1_242 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	-48(%rsi,%r11), %zmm8   ## zmm8 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	-32(%rsi,%r11), %zmm9   ## zmm9 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	-16(%rsi,%r11), %zmm10  ## zmm10 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	(%rsi,%r11), %zmm11     ## zmm11 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovsxbd	-48(%r14,%r11), %zmm12
	vpdpwssd	%zmm8, %zmm12, %zmm0
	vpmovsxbd	-32(%r14,%r11), %zmm8
	vpdpwssd	%zmm9, %zmm8, %zmm1
	vpmovsxbd	-16(%r14,%r11), %zmm8
	vpmovsxbd	(%r14,%r11), %zmm9
	vpdpwssd	%zmm10, %zmm8, %zmm2
	vpdpwssd	%zmm11, %zmm9, %zmm7
	addq	$64, %r11
	addq	$-64, %rdi
	jne	LBB1_295
## %bb.296:                             ##   in Loop: Header=BB1_242 Depth=1
	vpaddd	%zmm0, %zmm1, %zmm0
	vpaddd	%zmm7, %zmm2, %zmm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti64x4	$1, %zmm0, %ymm1
	vpaddd	%zmm1, %zmm0, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %r12d
	testq	%r9, %r9
	movq	64(%rsp), %rdi                  ## 8-byte Reload
	je	LBB1_297
## %bb.298:                             ##   in Loop: Header=BB1_242 Depth=1
	cmpl	$8, %r9d
	jae	LBB1_299
## %bb.306:                             ##   in Loop: Header=BB1_242 Depth=1
	addq	192(%rsp), %rcx                 ## 8-byte Folded Reload
	movq	56(%rsp), %r9                   ## 8-byte Reload
	jmp	LBB1_303
LBB1_297:                               ##   in Loop: Header=BB1_242 Depth=1
	movq	56(%rsp), %r9                   ## 8-byte Reload
	jmp	LBB1_304
LBB1_299:                               ##   in Loop: Header=BB1_242 Depth=1
	movq	112(%rsp), %r11                 ## 8-byte Reload
LBB1_300:                               ##   in Loop: Header=BB1_242 Depth=1
	movq	72(%rsp), %r9                   ## 8-byte Reload
	addq	%r9, %rcx
	vmovd	%r12d, %xmm0
	addq	%r11, %r15
	addq	%r11, %r13
	subq	%r11, %r9
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB1_301:                               ##   Parent Loop BB1_242 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovzxbd	(%r13,%r11), %ymm1      ## ymm1 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero
	vpmovsxbd	(%r15,%r11), %ymm2
	vpdpwssd	%ymm1, %ymm2, %ymm0
	addq	$8, %r11
	cmpq	%r11, %r9
	jne	LBB1_301
## %bb.302:                             ##   in Loop: Header=BB1_242 Depth=1
	vextracti128	$1, %ymm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddd	%xmm1, %xmm0, %xmm0
	vpshufd	$85, %xmm0, %xmm1               ## xmm1 = xmm0[1,1,1,1]
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %r12d
	testb	$7, 88(%rsp)                    ## 1-byte Folded Reload
	movq	56(%rsp), %r9                   ## 8-byte Reload
	je	LBB1_304
	.p2align	4, 0x90
LBB1_303:                               ##   Parent Loop BB1_242 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rsi,%rcx), %r11d
	movsbl	(%r14,%rcx), %r15d
	imull	%r11d, %r15d
	addl	%r15d, %r12d
	incq	%rcx
	cmpq	%rax, %rcx
	jb	LBB1_303
	jmp	LBB1_304
LBB1_305:
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN4zvec5turbo11avx512_vnni39squared_euclidean_int8_query_preprocessEPvm
LCPI2_0:
	.quad	-9187201950435737472            ## 0x8080808080808080
	.section	__TEXT,__const
	.p2align	6, 0x0
LCPI2_1:
	.space	64,128
LCPI2_2:
	.space	32,128
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo11avx512_vnni39squared_euclidean_int8_query_preprocessEPvm
	.p2align	4, 0x90
__ZN4zvec5turbo11avx512_vnni39squared_euclidean_int8_query_preprocessEPvm: ## @_ZN4zvec5turbo11avx512_vnni39squared_euclidean_int8_query_preprocessEPvm
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	cmpl	$21, %esi
	jl	LBB2_12
## %bb.1:
	movl	$4294967276, %eax               ## imm = 0xFFFFFFEC
	addq	%rax, %rsi
	movl	%esi, %eax
	cmpq	$64, %rax
	jae	LBB2_18
## %bb.2:
	xorl	%edx, %edx
	jmp	LBB2_3
LBB2_18:
	xorl	%ecx, %ecx
	vbroadcastsd	LCPI2_0(%rip), %zmm0    ## zmm0 = [9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144,9259542123273814144]
	.p2align	4, 0x90
LBB2_19:                                ## =>This Inner Loop Header: Depth=1
	vxorps	(%rdi,%rcx), %zmm0, %zmm1
	vmovups	%zmm1, (%rdi,%rcx)
	leaq	64(%rcx), %rdx
	subq	$-128, %rcx
	cmpq	%rax, %rcx
	movq	%rdx, %rcx
	jbe	LBB2_19
LBB2_3:
	movq	%rax, %rcx
	subq	%rdx, %rcx
	jbe	LBB2_12
## %bb.4:
	cmpq	$32, %rcx
	jae	LBB2_6
## %bb.5:
	movq	%rdx, %rcx
	jmp	LBB2_11
LBB2_6:
	cmpq	$256, %rcx                      ## imm = 0x100
	jae	LBB2_13
## %bb.7:
	xorl	%r8d, %r8d
	jmp	LBB2_8
LBB2_13:
	movq	%rcx, %r8
	andq	$-256, %r8
	leaq	(%rdx,%rdi), %r9
	addq	$192, %r9
	xorl	%r10d, %r10d
	vmovaps	LCPI2_1(%rip), %zmm0            ## zmm0 = [128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128]
	.p2align	4, 0x90
LBB2_14:                                ## =>This Inner Loop Header: Depth=1
	vxorps	-192(%r9,%r10), %zmm0, %zmm1
	vxorps	-128(%r9,%r10), %zmm0, %zmm2
	vxorps	-64(%r9,%r10), %zmm0, %zmm3
	vxorps	(%r9,%r10), %zmm0, %zmm4
	vmovups	%zmm1, -192(%r9,%r10)
	vmovups	%zmm2, -128(%r9,%r10)
	vmovups	%zmm3, -64(%r9,%r10)
	vmovups	%zmm4, (%r9,%r10)
	addq	$256, %r10                      ## imm = 0x100
	cmpq	%r10, %r8
	jne	LBB2_14
## %bb.15:
	cmpq	%r8, %rcx
	je	LBB2_12
## %bb.16:
	testb	$-32, %cl
	je	LBB2_17
LBB2_8:
	andl	$31, %esi
	subq	%rsi, %rcx
	addq	%rdx, %rcx
	addq	%rdx, %r8
	vmovaps	LCPI2_2(%rip), %ymm0            ## ymm0 = [128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128]
	.p2align	4, 0x90
LBB2_9:                                 ## =>This Inner Loop Header: Depth=1
	vxorps	(%rdi,%r8), %ymm0, %ymm1
	vmovups	%ymm1, (%rdi,%r8)
	addq	$32, %r8
	cmpq	%r8, %rcx
	jne	LBB2_9
## %bb.10:
	testq	%rsi, %rsi
	je	LBB2_12
	.p2align	4, 0x90
LBB2_11:                                ## =>This Inner Loop Header: Depth=1
	xorb	$-128, (%rdi,%rcx)
	incq	%rcx
	cmpq	%rcx, %rax
	jne	LBB2_11
LBB2_12:
	popq	%rbp
	vzeroupper
	retq
LBB2_17:
	addq	%r8, %rdx
	movq	%rdx, %rcx
	jmp	LBB2_11
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
