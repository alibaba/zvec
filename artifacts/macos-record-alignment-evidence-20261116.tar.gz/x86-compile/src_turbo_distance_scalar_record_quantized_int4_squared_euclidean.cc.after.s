	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0                          ## -- Begin function _ZN4zvec5turbo6scalar31squared_euclidean_int4_distanceEPKvS3_mPf
LCPI0_0:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6scalar31squared_euclidean_int4_distanceEPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo6scalar31squared_euclidean_int4_distanceEPKvS3_mPf: ## @_ZN4zvec5turbo6scalar31squared_euclidean_int4_distanceEPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpl	$33, %edx
	jl	LBB0_5
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	.cfi_offset %rbx, -24
	addl	$-32, %edx
	movq	%rdx, %r10
	shrq	%r10
	xorps	%xmm0, %xmm0
	cmpl	$2, %edx
	jb	LBB0_4
## %bb.2:
	xorps	%xmm0, %xmm0
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB0_3:                                 ## =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r11), %ebx
	movl	%ebx, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r11), %r8d
	movl	%r8d, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %bl
	sarb	$4, %r8b
	movl	%r8d, %eax
	mulb	%bl
	movsbl	%r9b, %r8d
	movsbl	%al, %eax
	addl	%r8d, %eax
	xorps	%xmm1, %xmm1
	cvtsi2ss	%eax, %xmm1
	addss	%xmm1, %xmm0
	incq	%r11
	cmpq	%r11, %r10
	jne	LBB0_3
LBB0_4:
	movss	(%rdi,%r10), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi,%r10), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movaps	%xmm3, %xmm4
	mulss	%xmm3, %xmm4
	mulss	12(%rsi,%r10), %xmm4
	movaps	%xmm1, %xmm5
	mulss	%xmm1, %xmm5
	mulss	12(%rdi,%r10), %xmm5
	addss	%xmm4, %xmm5
	movss	LCPI0_0(%rip), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	mulss	%xmm1, %xmm4
	mulss	%xmm3, %xmm4
	mulss	%xmm0, %xmm4
	addss	%xmm5, %xmm4
	subss	4(%rsi,%r10), %xmm2
	movaps	%xmm2, %xmm0
	xorps	%xmm5, %xmm5
	cvtsi2ss	%edx, %xmm5
	mulss	%xmm2, %xmm0
	mulss	%xmm0, %xmm5
	addss	%xmm4, %xmm5
	addss	%xmm2, %xmm2
	mulss	8(%rsi,%r10), %xmm3
	mulss	8(%rdi,%r10), %xmm1
	subss	%xmm3, %xmm1
	mulss	%xmm2, %xmm1
	addss	%xmm5, %xmm1
	movss	%xmm1, (%rcx)
	popq	%rbx
	popq	%rbp
LBB0_5:
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0                          ## -- Begin function _ZN4zvec5turbo6scalar37squared_euclidean_int4_batch_distanceEPKPKvS3_mmPfS5_
LCPI1_0:
	.long	0xc0000000                      ## float -2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo6scalar37squared_euclidean_int4_batch_distanceEPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo6scalar37squared_euclidean_int4_batch_distanceEPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo6scalar37squared_euclidean_int4_batch_distanceEPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdx, %rdx
	je	LBB1_9
## %bb.1:
	cmpl	$33, %ecx
	jl	LBB1_9
## %bb.2:
	addl	$-32, %ecx
	movq	%rcx, %r10
	shrq	%r10
	cvtsi2ss	%ecx, %xmm0
	cmpl	$2, %ecx
	jae	LBB1_3
## %bb.7:
	xorl	%eax, %eax
	movss	LCPI1_0(%rip), %xmm1            ## xmm1 = mem[0],zero,zero,zero
	xorps	%xmm2, %xmm2
	.p2align	4, 0x90
LBB1_8:                                 ## =>This Inner Loop Header: Depth=1
	movq	(%rdi,%rax,8), %rcx
	movss	(%rcx,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movaps	%xmm4, %xmm5
	mulss	%xmm4, %xmm5
	mulss	12(%rsi,%r10), %xmm5
	movaps	%xmm3, %xmm6
	mulss	%xmm3, %xmm6
	mulss	12(%rcx,%r10), %xmm6
	movss	4(%rcx,%r10), %xmm7             ## xmm7 = mem[0],zero,zero,zero
	addss	%xmm5, %xmm6
	movaps	%xmm3, %xmm5
	mulss	%xmm1, %xmm5
	mulss	%xmm4, %xmm5
	mulss	%xmm2, %xmm5
	subss	4(%rsi,%r10), %xmm7
	addss	%xmm6, %xmm5
	movaps	%xmm7, %xmm6
	mulss	%xmm7, %xmm6
	mulss	%xmm0, %xmm6
	addss	%xmm5, %xmm6
	addss	%xmm7, %xmm7
	mulss	8(%rsi,%r10), %xmm4
	mulss	8(%rcx,%r10), %xmm3
	subss	%xmm4, %xmm3
	mulss	%xmm7, %xmm3
	addss	%xmm6, %xmm3
	movss	%xmm3, (%r8,%rax,4)
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB1_8
	jmp	LBB1_9
LBB1_3:
	xorl	%r11d, %r11d
	movss	LCPI1_0(%rip), %xmm1            ## xmm1 = mem[0],zero,zero,zero
	.p2align	4, 0x90
LBB1_4:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_5 Depth 2
	movq	(%rdi,%r11,8), %rbx
	xorps	%xmm2, %xmm2
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB1_5:                                 ##   Parent Loop BB1_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzbl	(%rbx,%r14), %r15d
	movl	%r15d, %r9d
	shlb	$4, %r9b
	sarb	$4, %r9b
	movzbl	(%rsi,%r14), %ecx
	movl	%ecx, %eax
	shlb	$4, %al
	sarb	$4, %al
	mulb	%r9b
	movl	%eax, %r9d
	sarb	$4, %r15b
	sarb	$4, %cl
	movl	%ecx, %eax
	mulb	%r15b
	movsbl	%r9b, %ecx
	movsbl	%al, %eax
	addl	%ecx, %eax
	xorps	%xmm3, %xmm3
	cvtsi2ss	%eax, %xmm3
	addss	%xmm3, %xmm2
	incq	%r14
	cmpq	%r14, %r10
	jne	LBB1_5
## %bb.6:                               ##   in Loop: Header=BB1_4 Depth=1
	movss	(%rbx,%r10), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	movss	(%rsi,%r10), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	movaps	%xmm4, %xmm5
	mulss	%xmm4, %xmm5
	mulss	12(%rsi,%r10), %xmm5
	movaps	%xmm3, %xmm6
	mulss	%xmm3, %xmm6
	mulss	12(%rbx,%r10), %xmm6
	movss	4(%rbx,%r10), %xmm7             ## xmm7 = mem[0],zero,zero,zero
	addss	%xmm5, %xmm6
	movaps	%xmm3, %xmm5
	mulss	%xmm1, %xmm5
	mulss	%xmm4, %xmm5
	mulss	%xmm2, %xmm5
	subss	4(%rsi,%r10), %xmm7
	addss	%xmm6, %xmm5
	movaps	%xmm7, %xmm2
	mulss	%xmm7, %xmm2
	mulss	%xmm0, %xmm2
	addss	%xmm5, %xmm2
	addss	%xmm7, %xmm7
	mulss	8(%rsi,%r10), %xmm4
	mulss	8(%rbx,%r10), %xmm3
	subss	%xmm4, %xmm3
	mulss	%xmm7, %xmm3
	addss	%xmm2, %xmm3
	movss	%xmm3, (%r8,%r11,4)
	incq	%r11
	cmpq	%rdx, %r11
	jne	LBB1_4
LBB1_9:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
