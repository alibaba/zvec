	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo4avx225cosine_int8_distance_avx2EPKvS3_mPf
LCPI0_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI0_1:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4avx225cosine_int8_distance_avx2EPKvS3_mPf
	.p2align	4, 0x90
__ZN4zvec5turbo4avx225cosine_int8_distance_avx2EPKvS3_mPf: ## @_ZN4zvec5turbo4avx225cosine_int8_distance_avx2EPKvS3_mPf
	.cfi_startproc
## %bb.0:
	cmpq	$25, %rdx
	jb	LBB0_17
## %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	addq	$-24, %rdx
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%eax, %eax
	cmpq	$16, %rdx
	jae	LBB0_3
## %bb.2:
	vpxor	%xmm1, %xmm1, %xmm1
	jmp	LBB0_6
LBB0_3:
	vmovdqa	LCPI0_0(%rip), %ymm1            ## ymm1 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	.p2align	4, 0x90
LBB0_4:                                 ## =>This Inner Loop Header: Depth=1
	movq	%rax, %r8
	vpmovsxbw	(%rdi,%rax), %ymm2
	vpmovsxbw	(%rsi,%rax), %ymm3
	vpmullw	%ymm2, %ymm3, %ymm2
	vpmaddwd	%ymm1, %ymm2, %ymm2
	vpaddd	%ymm0, %ymm2, %ymm0
	addq	$16, %rax
	addq	$32, %r8
	cmpq	%rdx, %r8
	jbe	LBB0_4
## %bb.5:
	vextracti128	$1, %ymm0, %xmm1
	vpmovsxdq	%xmm1, %ymm1
	vpmovsxdq	%xmm0, %ymm0
LBB0_6:
	vpaddq	%ymm1, %ymm0, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r10
	movq	%rdx, %r8
	subq	%rax, %r8
	jbe	LBB0_13
## %bb.7:
	cmpq	$16, %r8
	jae	LBB0_9
## %bb.8:
	movq	%rax, %r8
	jmp	LBB0_12
LBB0_9:
	movl	%edx, %r9d
	andl	$15, %r9d
	subq	%r9, %r8
	addq	%rax, %r8
	vmovq	%r10, %xmm0
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	.p2align	4, 0x90
LBB0_10:                                ## =>This Inner Loop Header: Depth=1
	vpmovsxbq	(%rdi,%rax), %ymm4
	vpmovsxbq	4(%rdi,%rax), %ymm5
	vpmovsxbq	8(%rdi,%rax), %ymm6
	vpmovsxbq	12(%rdi,%rax), %ymm7
	vpmovsxbq	(%rsi,%rax), %ymm8
	vpmuldq	%ymm4, %ymm8, %ymm4
	vpaddq	%ymm0, %ymm4, %ymm0
	vpmovsxbq	4(%rsi,%rax), %ymm4
	vpmuldq	%ymm5, %ymm4, %ymm4
	vpaddq	%ymm1, %ymm4, %ymm1
	vpmovsxbq	8(%rsi,%rax), %ymm4
	vpmuldq	%ymm6, %ymm4, %ymm4
	vpaddq	%ymm2, %ymm4, %ymm2
	vpmovsxbq	12(%rsi,%rax), %ymm4
	vpmuldq	%ymm7, %ymm4, %ymm4
	vpaddq	%ymm3, %ymm4, %ymm3
	addq	$16, %rax
	cmpq	%rax, %r8
	jne	LBB0_10
## %bb.11:
	vpaddq	%ymm0, %ymm1, %ymm0
	vpaddq	%ymm0, %ymm2, %ymm0
	vpaddq	%ymm0, %ymm3, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r10
	testq	%r9, %r9
	je	LBB0_13
	.p2align	4, 0x90
LBB0_12:                                ## =>This Inner Loop Header: Depth=1
	movsbq	(%rdi,%r8), %rax
	movsbq	(%rsi,%r8), %r9
	imulq	%rax, %r9
	addq	%r9, %r10
	incq	%r8
	cmpq	%r8, %rdx
	jne	LBB0_12
LBB0_13:
	vcvtsi2ss	%r10, %xmm9, %xmm2
	vmovss	(%rdi,%rdx), %xmm3              ## xmm3 = mem[0],zero,zero,zero
	vmovss	4(%rdi,%rdx), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	vmovss	(%rsi,%rdx), %xmm4              ## xmm4 = mem[0],zero,zero,zero
	vmovss	4(%rsi,%rdx), %xmm1             ## xmm1 = mem[0],zero,zero,zero
	vmulss	%xmm4, %xmm3, %xmm5
	vmulss	%xmm4, %xmm0, %xmm4
	vmulss	8(%rsi,%rdx), %xmm4, %xmm4
	vfmadd231ss	%xmm5, %xmm2, %xmm4     ## xmm4 = (xmm2 * xmm5) + xmm4
	vmulss	%xmm1, %xmm3, %xmm2
	vfmadd132ss	8(%rdi,%rdx), %xmm4, %xmm2 ## xmm2 = (xmm2 * mem) + xmm4
	testq	%rdx, %rdx
	js	LBB0_14
## %bb.15:
	vcvtsi2ss	%rdx, %xmm9, %xmm3
	jmp	LBB0_16
LBB0_14:
	movq	%rdx, %rax
	shrq	%rax
	andl	$1, %edx
	orq	%rax, %rdx
	vcvtsi2ss	%rdx, %xmm9, %xmm3
	vaddss	%xmm3, %xmm3, %xmm3
LBB0_16:
	vmulss	%xmm3, %xmm1, %xmm1
	vfmadd213ss	%xmm2, %xmm1, %xmm0     ## xmm0 = (xmm1 * xmm0) + xmm2
	vbroadcastss	LCPI0_1(%rip), %xmm1    ## xmm1 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	vxorps	%xmm1, %xmm0, %xmm0
	vmovss	%xmm0, (%rcx)
	popq	%rbp
LBB0_17:
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo4avx231cosine_int8_batch_distance_avx2EPKPKvS3_mmPfS5_
LCPI1_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__literal4,4byte_literals
	.p2align	2, 0x0
LCPI1_1:
	.long	0x80000000                      ## float -0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4avx231cosine_int8_batch_distance_avx2EPKPKvS3_mmPfS5_
	.p2align	4, 0x90
__ZN4zvec5turbo4avx231cosine_int8_batch_distance_avx2EPKPKvS3_mmPfS5_: ## @_ZN4zvec5turbo4avx231cosine_int8_batch_distance_avx2EPKPKvS3_mmPfS5_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$25, %rcx
	jb	LBB1_40
## %bb.1:
	movq	%rsi, %r13
	movq	%rcx, -56(%rbp)                 ## 8-byte Spill
	leaq	-24(%rcx), %r12
	cmpq	$2, %rdx
	movq	%rdx, -48(%rbp)                 ## 8-byte Spill
	movq	%r8, -72(%rbp)                  ## 8-byte Spill
	movq	%rdi, -64(%rbp)                 ## 8-byte Spill
	jae	LBB1_29
## %bb.2:
	xorl	%r10d, %r10d
LBB1_3:
	cmpq	%rdx, %r10
	movq	-72(%rbp), %rbx                 ## 8-byte Reload
	movq	-64(%rbp), %r14                 ## 8-byte Reload
	jae	LBB1_15
## %bb.4:
	cmpq	$16, %r12
	jae	LBB1_5
## %bb.18:
	testq	%r12, %r12
	je	LBB1_41
## %bb.19:
	movq	%r10, %rax
	notq	%rax
	testb	$1, %dl
	je	LBB1_23
## %bb.20:
	movq	(%r14,%r10,8), %rcx
	xorl	%r9d, %r9d
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB1_21:                                ## =>This Inner Loop Header: Depth=1
	movsbq	(%rcx,%r9), %rdi
	movsbq	(%r13,%r9), %r8
	imulq	%rdi, %r8
	addq	%r8, %rsi
	incq	%r9
	cmpq	%r9, %r12
	jne	LBB1_21
## %bb.22:
	vcvtsi2ss	%rsi, %xmm0, %xmm0
	vmovss	%xmm0, (%rbx,%r10,4)
	orq	$1, %r10
LBB1_23:
	addq	%rdx, %rax
	je	LBB1_15
	.p2align	4, 0x90
LBB1_24:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_25 Depth 2
                                        ##     Child Loop BB1_27 Depth 2
	movq	(%r14,%r10,8), %rax
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	.p2align	4, 0x90
LBB1_25:                                ##   Parent Loop BB1_24 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%rax,%r8), %rsi
	movsbq	(%r13,%r8), %rdi
	imulq	%rsi, %rdi
	addq	%rdi, %rcx
	incq	%r8
	cmpq	%r8, %r12
	jne	LBB1_25
## %bb.26:                              ##   in Loop: Header=BB1_24 Depth=1
	vcvtsi2ss	%rcx, %xmm1, %xmm0
	vmovss	%xmm0, (%rbx,%r10,4)
	movq	8(%r14,%r10,8), %rax
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	.p2align	4, 0x90
LBB1_27:                                ##   Parent Loop BB1_24 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%rax,%r8), %rsi
	movsbq	(%r13,%r8), %rdi
	imulq	%rsi, %rdi
	addq	%rdi, %rcx
	incq	%r8
	cmpq	%r8, %r12
	jne	LBB1_27
## %bb.28:                              ##   in Loop: Header=BB1_24 Depth=1
	vcvtsi2ss	%rcx, %xmm1, %xmm0
	vmovss	%xmm0, 4(%rbx,%r10,4)
	addq	$2, %r10
	cmpq	%rdx, %r10
	jne	LBB1_24
LBB1_15:
	testq	%rdx, %rdx
	je	LBB1_40
## %bb.16:
	vmovss	4(%r13,%r12), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	testq	%r12, %r12
	js	LBB1_17
LBB1_37:
	vcvtsi2ss	%r12, %xmm10, %xmm3
	jmp	LBB1_38
LBB1_29:
	xorl	%r10d, %r10d
	movq	%rdi, %r15
	movq	%r8, %rbx
	jmp	LBB1_30
	.p2align	4, 0x90
LBB1_35:                                ##   in Loop: Header=BB1_30 Depth=1
	movq	40(%r15), %rax
LBB1_36:                                ##   in Loop: Header=BB1_30 Depth=1
	movq	%rax, -88(%rbp)
	movq	%r13, %rdi
	movq	%r15, %rsi
	leaq	-96(%rbp), %rdx
	movq	%r12, %rcx
	movq	%rbx, %r8
	callq	__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKaPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	movq	%r14, %r10
	addq	$2, %r10
	addq	$8, %rbx
	addq	$16, %r15
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	cmpq	%rdx, -80(%rbp)                 ## 8-byte Folded Reload
	ja	LBB1_3
LBB1_30:                                ## =>This Inner Loop Header: Depth=1
	leaq	4(%r10), %rax
	movq	%rax, -80(%rbp)                 ## 8-byte Spill
	cmpq	%rdx, %rax
	jae	LBB1_31
## %bb.32:                              ##   in Loop: Header=BB1_30 Depth=1
	movq	32(%r15), %rax
	jmp	LBB1_33
	.p2align	4, 0x90
LBB1_31:                                ##   in Loop: Header=BB1_30 Depth=1
	xorl	%eax, %eax
LBB1_33:                                ##   in Loop: Header=BB1_30 Depth=1
	movq	%rax, -96(%rbp)
	leaq	5(%r10), %rax
	movq	%r10, %r14
	cmpq	%rdx, %rax
	jb	LBB1_35
## %bb.34:                              ##   in Loop: Header=BB1_30 Depth=1
	xorl	%eax, %eax
	jmp	LBB1_36
LBB1_5:
	movq	-56(%rbp), %rdi                 ## 8-byte Reload
	leaq	-40(%rdi), %rax
	leaq	-23(%rdi), %rcx
	cmpq	$33, %rcx
	movl	$32, %esi
	cmovaeq	%rcx, %rsi
	addq	$-17, %rsi
	andq	$-16, %rsi
	negq	%rsi
	leaq	(%rdi,%rsi), %rcx
	addq	$-40, %rcx
	andl	$15, %eax
	movq	%rcx, %r11
	subq	%rax, %r11
	vmovdqa	LCPI1_0(%rip), %ymm0            ## ymm0 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	jmp	LBB1_6
	.p2align	4, 0x90
LBB1_14:                                ##   in Loop: Header=BB1_6 Depth=1
	vcvtsi2ss	%r9, %xmm10, %xmm1
	movq	%r15, %r10
	vmovss	%xmm1, (%rbx,%r15,4)
	incq	%r10
	cmpq	%rdx, %r10
	je	LBB1_15
LBB1_6:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB1_7 Depth 2
                                        ##     Child Loop BB1_11 Depth 2
                                        ##     Child Loop BB1_13 Depth 2
	movq	%r10, %r15
	movq	(%r14,%r10,8), %rsi
	vpxor	%xmm1, %xmm1, %xmm1
	movl	$28, %r9d
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB1_7:                                 ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movq	%rdi, %r10
	vpmovsxbw	(%r13,%rdi), %ymm2
	vpmovsxbw	(%rsi,%rdi), %ymm3
	movq	%r9, %r8
	vpmullw	%ymm2, %ymm3, %ymm2
	vpmaddwd	%ymm0, %ymm2, %ymm2
	vpaddd	%ymm1, %ymm2, %ymm1
	addq	$16, %rdi
	addq	$32, %r10
	addq	$16, %r9
	cmpq	%r12, %r10
	jbe	LBB1_7
## %bb.8:                               ##   in Loop: Header=BB1_6 Depth=1
	vextracti128	$1, %ymm1, %xmm2
	vpmovsxdq	%xmm2, %ymm2
	vpmovsxdq	%xmm1, %ymm1
	vpaddq	%ymm2, %ymm1, %ymm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %r9
	cmpq	%r12, %rdi
	jae	LBB1_14
## %bb.9:                               ##   in Loop: Header=BB1_6 Depth=1
	cmpq	$16, %rcx
	jb	LBB1_13
## %bb.10:                              ##   in Loop: Header=BB1_6 Depth=1
	addq	%r11, %rdi
	vmovq	%r9, %xmm1
	vpxor	%xmm2, %xmm2, %xmm2
	movq	%r11, %r9
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm4, %xmm4, %xmm4
	.p2align	4, 0x90
LBB1_11:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vpmovsxbq	-12(%rsi,%r8), %ymm5
	vpmovsxbq	-8(%rsi,%r8), %ymm6
	vpmovsxbq	-4(%rsi,%r8), %ymm7
	vpmovsxbq	(%rsi,%r8), %ymm8
	vpmovsxbq	-12(%r13,%r8), %ymm9
	vpmuldq	%ymm5, %ymm9, %ymm5
	vpaddq	%ymm1, %ymm5, %ymm1
	vpmovsxbq	-8(%r13,%r8), %ymm5
	vpmuldq	%ymm6, %ymm5, %ymm5
	vpaddq	%ymm2, %ymm5, %ymm2
	vpmovsxbq	-4(%r13,%r8), %ymm5
	vpmuldq	%ymm7, %ymm5, %ymm5
	vpaddq	%ymm3, %ymm5, %ymm3
	vpmovsxbq	(%r13,%r8), %ymm5
	vpmuldq	%ymm8, %ymm5, %ymm5
	vpaddq	%ymm4, %ymm5, %ymm4
	addq	$16, %r8
	addq	$-16, %r9
	jne	LBB1_11
## %bb.12:                              ##   in Loop: Header=BB1_6 Depth=1
	vpaddq	%ymm1, %ymm2, %ymm1
	vpaddq	%ymm1, %ymm3, %ymm1
	vpaddq	%ymm1, %ymm4, %ymm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %r9
	testq	%rax, %rax
	je	LBB1_14
	.p2align	4, 0x90
LBB1_13:                                ##   Parent Loop BB1_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movsbq	(%rsi,%rdi), %r8
	movsbq	(%r13,%rdi), %r10
	imulq	%r8, %r10
	addq	%r10, %r9
	incq	%rdi
	cmpq	%rdi, %r12
	jne	LBB1_13
	jmp	LBB1_14
LBB1_41:
	leaq	(%rbx,%r10,4), %rdi
	movq	%rdx, %rsi
	subq	%r10, %rsi
	shlq	$2, %rsi
	callq	___bzero
	movq	-48(%rbp), %rdx                 ## 8-byte Reload
	vmovss	4(%r13,%r12), %xmm0             ## xmm0 = mem[0],zero,zero,zero
	testq	%r12, %r12
	jns	LBB1_37
LBB1_17:
	movq	%r12, %rax
	shrq	%rax
	movl	%r12d, %ecx
	andl	$1, %ecx
	orq	%rax, %rcx
	vcvtsi2ss	%rcx, %xmm10, %xmm1
	vaddss	%xmm1, %xmm1, %xmm3
LBB1_38:
	vmovss	(%r13,%r12), %xmm1              ## xmm1 = mem[0],zero,zero,zero
	vmovss	8(%r13,%r12), %xmm2             ## xmm2 = mem[0],zero,zero,zero
	vmulss	%xmm3, %xmm0, %xmm3
	xorl	%eax, %eax
	vbroadcastss	LCPI1_1(%rip), %xmm4    ## xmm4 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	.p2align	4, 0x90
LBB1_39:                                ## =>This Inner Loop Header: Depth=1
	movq	(%r14,%rax,8), %rcx
	vmovss	(%rcx,%r12), %xmm5              ## xmm5 = mem[0],zero,zero,zero
	vmovss	4(%rcx,%r12), %xmm6             ## xmm6 = mem[0],zero,zero,zero
	vmulss	%xmm5, %xmm1, %xmm7
	vmulss	%xmm6, %xmm1, %xmm8
	vmulss	%xmm2, %xmm8, %xmm8
	vfmadd231ss	(%rbx,%rax,4), %xmm7, %xmm8 ## xmm8 = (xmm7 * mem) + xmm8
	vmulss	%xmm5, %xmm0, %xmm5
	vfmadd132ss	8(%rcx,%r12), %xmm8, %xmm5 ## xmm5 = (xmm5 * mem) + xmm8
	vfmadd231ss	%xmm6, %xmm3, %xmm5     ## xmm5 = (xmm3 * xmm6) + xmm5
	vxorps	%xmm4, %xmm5, %xmm5
	vmovss	%xmm5, (%rbx,%rax,4)
	incq	%rax
	cmpq	%rax, %rdx
	jne	LBB1_39
LBB1_40:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__const
	.p2align	5, 0x0                          ## -- Begin function _ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKaPKPKvRNSt3__15arrayIS5_XT_EEEmPf
LCPI2_0:
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.short	1                               ## 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKaPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.weak_def_can_be_hidden	__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKaPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.p2align	4, 0x90
__ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKaPKPKvRNSt3__15arrayIS5_XT_EEEmPf: ## @_ZN4zvec5turbo4avx28internal28raw_inner_product_batch_implILm2EEEvPKaPKPKvRNSt3__15arrayIS5_XT_EEEmPf
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$16, %rcx
	jae	LBB2_2
## %bb.1:
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%eax, %eax
	vpxor	%xmm1, %xmm1, %xmm1
	jmp	LBB2_7
LBB2_2:
	movq	(%rdx), %r9
	testq	%r9, %r9
	je	LBB2_5
## %bb.3:
	movq	8(%rdx), %rdx
	movq	(%rsi), %r10
	movq	8(%rsi), %r11
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%eax, %eax
	vmovdqa	LCPI2_0(%rip), %ymm2            ## ymm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB2_4:                                 ## =>This Inner Loop Header: Depth=1
	movq	%rax, %rbx
	vpmovsxbw	(%rdi,%rax), %ymm3
	prefetcht0	(%r9,%rax)
	prefetcht0	(%rdx,%rax)
	vpmovsxbw	(%r10,%rax), %ymm4
	vpmullw	%ymm3, %ymm4, %ymm4
	vpmaddwd	%ymm2, %ymm4, %ymm4
	vpaddd	%ymm1, %ymm4, %ymm1
	vpmovsxbw	(%r11,%rax), %ymm4
	vpmullw	%ymm3, %ymm4, %ymm3
	vpmaddwd	%ymm2, %ymm3, %ymm3
	vpaddd	%ymm0, %ymm3, %ymm0
	addq	$16, %rax
	addq	$32, %rbx
	cmpq	%rcx, %rbx
	jbe	LBB2_4
	jmp	LBB2_7
LBB2_5:
	movq	(%rsi), %rdx
	movq	8(%rsi), %r9
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%eax, %eax
	vmovdqa	LCPI2_0(%rip), %ymm2            ## ymm2 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	vpxor	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB2_6:                                 ## =>This Inner Loop Header: Depth=1
	movq	%rax, %r10
	vpmovsxbw	(%rdi,%rax), %ymm3
	vpmovsxbw	(%rdx,%rax), %ymm4
	vpmullw	%ymm3, %ymm4, %ymm4
	vpmaddwd	%ymm2, %ymm4, %ymm4
	vpaddd	%ymm1, %ymm4, %ymm1
	vpmovsxbw	(%r9,%rax), %ymm4
	vpmullw	%ymm3, %ymm4, %ymm3
	vpmaddwd	%ymm2, %ymm3, %ymm3
	vpaddd	%ymm0, %ymm3, %ymm0
	addq	$16, %rax
	addq	$32, %r10
	cmpq	%rcx, %r10
	jbe	LBB2_6
LBB2_7:
	cmpq	%rcx, %rax
	jae	LBB2_8
## %bb.9:
	movq	(%rsi), %r9
	vmovq	%xmm1, %rdx
	movslq	%edx, %rdx
	vextracti128	$1, %ymm1, %xmm2
	vpalignr	$4, %xmm1, %xmm2, %xmm1         ## xmm1 = xmm1[4,5,6,7,8,9,10,11,12,13,14,15],xmm2[0,1,2,3]
	vpmovsxdq	%xmm1, %ymm1
	vpextrd	$3, %xmm2, %r10d
	movslq	%r10d, %r10
	vextracti128	$1, %ymm1, %xmm3
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm3              ## xmm3 = xmm1[2,3,2,3]
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$233, %xmm2, %xmm2              ## xmm2 = xmm2[1,2,2,3]
	vpmovsxdq	%xmm2, %xmm2
	vmovq	%r10, %xmm3
	vpunpcklqdq	%xmm3, %xmm1, %xmm1     ## xmm1 = xmm1[0],xmm3[0]
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %r11
	addq	%rdx, %r11
	movq	%rcx, %rdx
	subq	%rax, %rdx
	cmpq	$16, %rdx
	jae	LBB2_11
## %bb.10:
	movq	%rax, %r10
	jmp	LBB2_14
LBB2_8:
	vmovq	%xmm1, %rax
	cltq
	vextracti128	$1, %ymm1, %xmm2
	vpalignr	$4, %xmm1, %xmm2, %xmm1         ## xmm1 = xmm1[4,5,6,7,8,9,10,11,12,13,14,15],xmm2[0,1,2,3]
	vpmovsxdq	%xmm1, %ymm1
	vpextrd	$3, %xmm2, %ecx
	movslq	%ecx, %rcx
	vextracti128	$1, %ymm1, %xmm3
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm3              ## xmm3 = xmm1[2,3,2,3]
	vpaddq	%xmm3, %xmm1, %xmm1
	vpshufd	$233, %xmm2, %xmm2              ## xmm2 = xmm2[1,2,2,3]
	vpmovsxdq	%xmm2, %xmm2
	vmovq	%rcx, %xmm3
	vpunpcklqdq	%xmm3, %xmm1, %xmm1     ## xmm1 = xmm1[0],xmm3[0]
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %rcx
	addq	%rax, %rcx
	vcvtsi2ss	%rcx, %xmm5, %xmm1
	vmovss	%xmm1, (%r8)
	vmovq	%xmm0, %rax
	cltq
	vextracti128	$1, %ymm0, %xmm1
	vpalignr	$4, %xmm0, %xmm1, %xmm0         ## xmm0 = xmm0[4,5,6,7,8,9,10,11,12,13,14,15],xmm1[0,1,2,3]
	vpmovsxdq	%xmm0, %ymm0
	vpextrd	$3, %xmm1, %ecx
	movslq	%ecx, %rcx
	vextracti128	$1, %ymm0, %xmm2
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm2              ## xmm2 = xmm0[2,3,2,3]
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$233, %xmm1, %xmm1              ## xmm1 = xmm1[1,2,2,3]
	vpmovsxdq	%xmm1, %xmm1
	vmovq	%rcx, %xmm2
	vpunpcklqdq	%xmm2, %xmm0, %xmm0     ## xmm0 = xmm0[0],xmm2[0]
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rbx
	addq	%rax, %rbx
	jmp	LBB2_21
LBB2_11:
	movq	%rdx, %rbx
	andq	$-16, %rbx
	leaq	(%rax,%rbx), %r10
	vmovq	%r11, %xmm1
	leaq	(%r9,%rax), %r11
	addq	$12, %r11
	leaq	(%rdi,%rax), %r14
	addq	$12, %r14
	vpxor	%xmm2, %xmm2, %xmm2
	xorl	%r15d, %r15d
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm4, %xmm4, %xmm4
	.p2align	4, 0x90
LBB2_12:                                ## =>This Inner Loop Header: Depth=1
	vpmovsxbq	-12(%r11,%r15), %ymm5
	vpmovsxbq	-8(%r11,%r15), %ymm6
	vpmovsxbq	-4(%r11,%r15), %ymm7
	vpmovsxbq	(%r11,%r15), %ymm8
	vpmovsxbq	-12(%r14,%r15), %ymm9
	vpmuldq	%ymm5, %ymm9, %ymm5
	vpaddq	%ymm1, %ymm5, %ymm1
	vpmovsxbq	-8(%r14,%r15), %ymm5
	vpmuldq	%ymm6, %ymm5, %ymm5
	vpaddq	%ymm2, %ymm5, %ymm2
	vpmovsxbq	-4(%r14,%r15), %ymm5
	vpmuldq	%ymm7, %ymm5, %ymm5
	vpaddq	%ymm3, %ymm5, %ymm3
	vpmovsxbq	(%r14,%r15), %ymm5
	vpmuldq	%ymm8, %ymm5, %ymm5
	vpaddq	%ymm4, %ymm5, %ymm4
	addq	$16, %r15
	cmpq	%r15, %rbx
	jne	LBB2_12
## %bb.13:
	vpaddq	%ymm1, %ymm2, %ymm1
	vpaddq	%ymm1, %ymm3, %ymm1
	vpaddq	%ymm1, %ymm4, %ymm1
	vextracti128	$1, %ymm1, %xmm2
	vpaddq	%xmm2, %xmm1, %xmm1
	vpshufd	$238, %xmm1, %xmm2              ## xmm2 = xmm1[2,3,2,3]
	vpaddq	%xmm2, %xmm1, %xmm1
	vmovq	%xmm1, %r11
	cmpq	%rbx, %rdx
	je	LBB2_15
	.p2align	4, 0x90
LBB2_14:                                ## =>This Inner Loop Header: Depth=1
	movsbq	(%r9,%r10), %rbx
	movsbq	(%rdi,%r10), %r14
	imulq	%rbx, %r14
	addq	%r14, %r11
	incq	%r10
	cmpq	%r10, %rcx
	jne	LBB2_14
LBB2_15:
	vmovq	%xmm0, %r9
	movslq	%r9d, %r9
	vextracti128	$1, %ymm0, %xmm1
	vpalignr	$4, %xmm0, %xmm1, %xmm0         ## xmm0 = xmm0[4,5,6,7,8,9,10,11,12,13,14,15],xmm1[0,1,2,3]
	vpmovsxdq	%xmm0, %ymm0
	vpextrd	$3, %xmm1, %r10d
	movslq	%r10d, %r10
	vextracti128	$1, %ymm0, %xmm2
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm2              ## xmm2 = xmm0[2,3,2,3]
	vpaddq	%xmm2, %xmm0, %xmm0
	vpshufd	$233, %xmm1, %xmm1              ## xmm1 = xmm1[1,2,2,3]
	vpmovsxdq	%xmm1, %xmm1
	vmovq	%r10, %xmm2
	vpunpcklqdq	%xmm2, %xmm0, %xmm0     ## xmm0 = xmm0[0],xmm2[0]
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rbx
	vcvtsi2ss	%r11, %xmm10, %xmm0
	addq	%r9, %rbx
	vmovss	%xmm0, (%r8)
	movq	8(%rsi), %rsi
	cmpq	$16, %rdx
	jae	LBB2_17
## %bb.16:
	movq	%rax, %r9
	jmp	LBB2_20
LBB2_17:
	movq	%rdx, %r10
	andq	$-16, %r10
	leaq	(%rax,%r10), %r9
	vmovq	%rbx, %xmm0
	leaq	(%rsi,%rax), %r11
	addq	$12, %r11
	addq	%rdi, %rax
	addq	$12, %rax
	vpxor	%xmm1, %xmm1, %xmm1
	xorl	%ebx, %ebx
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm3, %xmm3, %xmm3
	.p2align	4, 0x90
LBB2_18:                                ## =>This Inner Loop Header: Depth=1
	vpmovsxbq	-12(%r11,%rbx), %ymm4
	vpmovsxbq	-8(%r11,%rbx), %ymm5
	vpmovsxbq	-4(%r11,%rbx), %ymm6
	vpmovsxbq	(%r11,%rbx), %ymm7
	vpmovsxbq	-12(%rax,%rbx), %ymm8
	vpmuldq	%ymm4, %ymm8, %ymm4
	vpaddq	%ymm0, %ymm4, %ymm0
	vpmovsxbq	-8(%rax,%rbx), %ymm4
	vpmuldq	%ymm5, %ymm4, %ymm4
	vpaddq	%ymm1, %ymm4, %ymm1
	vpmovsxbq	-4(%rax,%rbx), %ymm4
	vpmuldq	%ymm6, %ymm4, %ymm4
	vpaddq	%ymm2, %ymm4, %ymm2
	vpmovsxbq	(%rax,%rbx), %ymm4
	vpmuldq	%ymm7, %ymm4, %ymm4
	vpaddq	%ymm3, %ymm4, %ymm3
	addq	$16, %rbx
	cmpq	%rbx, %r10
	jne	LBB2_18
## %bb.19:
	vpaddq	%ymm0, %ymm1, %ymm0
	vpaddq	%ymm0, %ymm2, %ymm0
	vpaddq	%ymm0, %ymm3, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rbx
	cmpq	%r10, %rdx
	je	LBB2_21
	.p2align	4, 0x90
LBB2_20:                                ## =>This Inner Loop Header: Depth=1
	movsbq	(%rsi,%r9), %rax
	movsbq	(%rdi,%r9), %rdx
	imulq	%rax, %rdx
	addq	%rdx, %rbx
	incq	%r9
	cmpq	%r9, %rcx
	jne	LBB2_20
LBB2_21:
	vcvtsi2ss	%rbx, %xmm10, %xmm0
	vmovss	%xmm0, 4(%r8)
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
.subsections_via_symbols
