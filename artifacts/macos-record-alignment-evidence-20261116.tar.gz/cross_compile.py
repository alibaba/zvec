from pathlib import Path
import json,subprocess,shlex,re
root=Path(__file__).resolve().parent;repo=root.parent.parent/'zvec';out=root/'x86-compile';out.mkdir(exist_ok=True)
commands=json.loads((root.parent/'avx2_reverify_20261113/build/compile_commands.json').read_text())
files=[p for p in subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines() if p.endswith('.cc') and '/distance/' in p]
result=[]
for file in files:
 entry=next(x for x in commands if x['file']==str(repo/file));base=shlex.split(entry['command']);flags=[];i=1
 while i<len(base):
  x=base[i]
  if x in ['-o','-c']:i+=2;continue
  if x.startswith('-march=') or x.startswith('-DZVEC_HAVE_ARM_FP16_KERNEL'):i+=1;continue
  flags.append(x);i+=1
 arch=file.split('/')[3];flags+=['-arch','x86_64','-march=x86-64']
 if arch=='sse2':flags+=['-msse2']
 if arch in ['avx2','avx512','avx512_vnni']:flags+=['-mavx2','-mfma','-mf16c']
 if arch in ['avx512','avx512_vnni']:flags+=['-mavx512f','-mavx512bw','-mavx512dq','-mavx512vl']
 if arch=='avx512_vnni':flags+=['-mavx512vnni']
 name=file.replace('/','_');old=out/(name+'.old.cc');old.write_bytes(subprocess.check_output(['git','show','HEAD:'+file],cwd=repo))
 entries={}
 for version,source in [('before',old),('after',repo/file)]:
  asm=out/(name+'.'+version+'.s');cmd=[base[0],*flags,'-S',str(source),'-o',str(asm)]
  with (out/(name+'.'+version+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
  text=asm.read_text();entries[version]={'memcpy_calls':len(re.findall(r'\b(?:callq?|jmp)\s+_memcpy',text)),'assembly_lines':len(text.splitlines())}
 result.append(dict(file=file,**entries));print(file,entries,flush=True)
(root/'x86-compile.json').write_text(json.dumps(result,indent=2)+'\n')
