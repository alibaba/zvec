from pathlib import Path
import json,math,collections,hashlib,shutil
r=Path(__file__).resolve().parent;p=r/'performance'
correct=json.loads((r/'correctness.json').read_text());compat=correct.pop('legacy_ivf_comparison');counts={k:sum(v[k] for v in correct.values()) for k in ['passed','skipped','disabled','failed']}
san=json.loads((r/'ubsan.json').read_text());diagnostics=[d for v in san.values() for d in v['diagnostics']]
perf=json.loads((p/'performance.json').read_text());result=json.loads((p/'SUMMARY.json').read_text());cross=json.loads((r/'x86-compile.json').read_text())
groups={}
for rnd,rows in enumerate(perf['rounds'],1):
 d=collections.defaultdict(list)
 for row in rows:d[(row['type'],row['metric'])].append(row['speedup'])
 for k,v in d.items():groups.setdefault(k,[]).append(math.exp(sum(map(math.log,v))/len(v)))
status='MACOS_ALIGNMENT_FIXED_OTHER_UB_REMAINS' if not result['sustained_regressions'] and not counts['failed'] and not any('misaligned' in x for x in diagnostics) else 'REVIEW_REQUIRED'
summary=dict(status=status,normal=dict(programs=len(correct),**counts),compatibility=compat,ubsan=dict(programs=len(san),misaligned=sum('misaligned' in x for x in diagnostics),other_reports=diagnostics),performance=result,query_correctness=perf['correctness'],x86_cross_compile=dict(files=len(cross),same_optimized_assembly=sum(x['assembly_equal_except_file'] for x in cross),native_execution=False),performance_groups=[dict(type=k[0],metric=k[1],round1=v[0],round2=v[1]) for k,v in groups.items()])
(r/'SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
lines=['旧 record INT8/INT4 未对齐访问修复 — macOS ARM64 回归','2026-11-16','',f'结论：{status}',
'本轮仅修改元数据读写：固定大小 memcpy 替代 float*/int32_t* 解引用。',
'不加 padding、不转置、不改变记录格式、SIMD 累加、分数公式或 IVF 分派。',
'修改 RecordQuantizer 及 scalar/SSE2/AVX2/AVX512/VNNI 共 22 个距离文件，新增共享读取器。',
'NEON 距离文件本来使用安全读取，没有修改。','',
'正确性',f'- {len(correct)} 个相关程序：{counts}。',f'- 旧索引兼容：{compat["passed"]} 通过 / {compat["skipped"]} 跳过 / {compat["disabled"]} 禁用 / {compat["failed"]} 失败；使用原包 200 份 fixture。',
'- 新专项测试：量化/反量化逐字节验证、0..7 偏移、不同维度/尾长，',
'  single/batch/many 与 double 参考比较、输出哨兵、输入不变。macOS 实际执行 Scalar/AUTO/NEON。',
'- 首次新测试将 INT8 元数据 -0.0 误写为 +0.0；只改正预期的符号位，未放宽逐字节检查。',
'  初始失败日志保留在 alignment-initial-fixture-failure，最终结果在 correctness。','',
'UBSan',
'- 283 个 C/C++ 编译单元均有 -fsanitize=undefined，没有 fno-sanitize，alignment/vptr 保持开启。',
'- matrix、many_to_many、IVF legacy、IVF searcher、record alignment 共 5 个程序全部运行。',
'- 上轮相同 4 个程序有 13 条 RecordQuantizer 未对齐报告；本轮（含新增专项）为 0。',
'- 仍有 1 条既有 entropy_integer_quantizer/integer_quantizer.cc:352 NaN 转 signed char 报告。',
'  该文件未修改，此问题不在 packed metadata 修复范围内，不能称 sanitizer 全绿。',
'- macOS ASan runtime 先前已用空 main 确认不可用，本轮未计为 ASan 通过；交由 x86 原生复验。','',
'实际 IVF 查询性能',
'- 基线为 e2ac9ee0 的生产代码（已包含 AVX2）；复用已保存的 tools-bench 静态二进制，',
'  其所有 src/ 源码 SHA256 与 HEAD 一致，bench.cc 也与本轮一致。候选重新构建并静态链接。',
'- 每轮 288 项，50 ms 采样下限；第一轮 before→after，第二轮 after→before。',
f'- 任一轮超过 5% 回退的 {result["retake_cases"]} 项再交替复测两轮，持续回退 {len(result["sustained_regressions"])} 项。',
'- 无并发构建或其他主动压测；日常桌面/企业安全后台服务仍运行，结果按两轮和复测判定。',
'- 加速比 = 修复前耗时 / 修复后耗时；以下为组内几何平均，大于 1 为更快。','',
'类型 | 度量 | 第一轮 | 第二轮','--- | --- | --- | ---']
for k,v in groups.items():lines.append(f'{k[0]} | {k[1]} | {v[0]:.3f}x | {v[1]:.3f}x')
lines+=['',f'Top-K 对比：{perf["correctness"]}',f'持续回退明细：{result["sustained_regressions"]}','',
'x86 静态检查与待验',
'- 22 个距离文件按各自 ISA 交叉编译成功；去掉 .file 后优化汇编与修复前逐字相同。',
'- 固定大小 memcpy 均内联；没有新增 memcpy 调用。证据见 x86-compile.json 和对应汇编。',
'- 这不是原生 Linux x86 执行结果。服务器必须验证完整 ASan+UBSan、六种后端、旧索引和性能。',
'- 交接入口：scripts/ivf_interleaved_avx2_regression/RECORD_ALIGNMENT_zh.txt。',
'- 独立交接包含基线源码、相同测试补丁、生产修复补丁、完整源码哈希、fixtures 和工具。',
'- 修复尚未提交或推送；交接包冻结候选，不依赖远端 HEAD。','']
(r/'REPORT_zh.txt').write_text('\n'.join(lines))
print((r/'REPORT_zh.txt').read_text())
