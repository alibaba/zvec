	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 14, 5	sdk_version 14, 5
	.globl	__ZN4zvec5turbo6avx51238make_interleaved_many_to_many_distanceENS0_10MetricTypeENS0_8DataTypeEm ## -- Begin function _ZN4zvec5turbo6avx51238make_interleaved_many_to_many_distanceENS0_10MetricTypeENS0_8DataTypeEm
	.p2align	4, 0x90
__ZN4zvec5turbo6avx51238make_interleaved_many_to_many_distanceENS0_10MetricTypeENS0_8DataTypeEm: ## @_ZN4zvec5turbo6avx51238make_interleaved_many_to_many_distanceENS0_10MetricTypeENS0_8DataTypeEm
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, %rax
	cmpl	$2, %edx
	je	LBB0_19
## %bb.1:
	cmpl	$3, %edx
	jne	LBB0_35
## %bb.2:
	testl	%esi, %esi
	je	LBB0_12
## %bb.3:
	cmpl	$2, %esi
	jne	LBB0_35
## %bb.4:
	addq	$-2, %rcx
	cmpq	$30, %rcx
	ja	LBB0_35
## %bb.5:
	leaq	LJTI0_3(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
LBB0_6:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_19:
	testl	%esi, %esi
	je	LBB0_28
## %bb.20:
	cmpl	$2, %esi
	jne	LBB0_35
## %bb.21:
	addq	$-2, %rcx
	cmpq	$30, %rcx
	ja	LBB0_35
## %bb.22:
	leaq	LJTI0_1(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
LBB0_23:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_12:
	addq	$-2, %rcx
	cmpq	$30, %rcx
	ja	LBB0_35
## %bb.13:
	leaq	LJTI0_2(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
LBB0_14:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_28:
	addq	$-2, %rcx
	cmpq	$30, %rcx
	ja	LBB0_35
## %bb.29:
	leaq	LJTI0_0(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
LBB0_30:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_35:
	movq	$0, 32(%rax)
	popq	%rbp
	retq
LBB0_8:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_9:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_10:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_11:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_24:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_25:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_26:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_27:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_15:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_16:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_17:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_18:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_31:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_32:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_33:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	jmp	LBB0_7
LBB0_34:
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
LBB0_7:
	movq	%rcx, (%rax)
	movq	%rax, 32(%rax)
	popq	%rbp
	retq
	.cfi_endproc
	.p2align	2, 0x90
	.data_region jt32
.set L0_0_set_30, LBB0_30-LJTI0_0
.set L0_0_set_35, LBB0_35-LJTI0_0
.set L0_0_set_31, LBB0_31-LJTI0_0
.set L0_0_set_32, LBB0_32-LJTI0_0
.set L0_0_set_33, LBB0_33-LJTI0_0
.set L0_0_set_34, LBB0_34-LJTI0_0
LJTI0_0:
	.long	L0_0_set_30
	.long	L0_0_set_35
	.long	L0_0_set_31
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_32
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_33
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_35
	.long	L0_0_set_34
.set L0_1_set_23, LBB0_23-LJTI0_1
.set L0_1_set_35, LBB0_35-LJTI0_1
.set L0_1_set_24, LBB0_24-LJTI0_1
.set L0_1_set_25, LBB0_25-LJTI0_1
.set L0_1_set_26, LBB0_26-LJTI0_1
.set L0_1_set_27, LBB0_27-LJTI0_1
LJTI0_1:
	.long	L0_1_set_23
	.long	L0_1_set_35
	.long	L0_1_set_24
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_25
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_26
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_35
	.long	L0_1_set_27
.set L0_2_set_14, LBB0_14-LJTI0_2
.set L0_2_set_35, LBB0_35-LJTI0_2
.set L0_2_set_15, LBB0_15-LJTI0_2
.set L0_2_set_16, LBB0_16-LJTI0_2
.set L0_2_set_17, LBB0_17-LJTI0_2
.set L0_2_set_18, LBB0_18-LJTI0_2
LJTI0_2:
	.long	L0_2_set_14
	.long	L0_2_set_35
	.long	L0_2_set_15
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_16
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_17
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_35
	.long	L0_2_set_18
.set L0_3_set_6, LBB0_6-LJTI0_3
.set L0_3_set_35, LBB0_35-LJTI0_3
.set L0_3_set_8, LBB0_8-LJTI0_3
.set L0_3_set_9, LBB0_9-LJTI0_3
.set L0_3_set_10, LBB0_10-LJTI0_3
.set L0_3_set_11, LBB0_11-LJTI0_3
LJTI0_3:
	.long	L0_3_set_6
	.long	L0_3_set_35
	.long	L0_3_set_8
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_9
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_10
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_35
	.long	L0_3_set_11
	.end_data_region
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rsi
	cmpq	$2, %rdi
	jb	LBB7_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB7_3
## %bb.6:
	movq	%rcx, %r9
	andq	$-2, %r9
	leaq	8(%rax), %r10
	movl	$1, %ebx
	xorl	%r8d, %r8d
	movw	$3, %r11w
	jmp	LBB7_7
	.p2align	4, 0x90
LBB7_11:                                ##   in Loop: Header=BB7_7 Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm1, (%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%rbx,8) {%k1}
	addq	$2, %r8
	movq	%r8, %rbx
	orq	$1, %rbx
	cmpq	%rdi, %rbx
	jae	LBB7_12
LBB7_7:                                 ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB7_8 Depth 2
	movq	(%rdx,%r8,8), %r15
	movq	(%rdx,%rbx,8), %r14
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	cmpq	$1, %rcx
	je	LBB7_9
	.p2align	4, 0x90
LBB7_8:                                 ##   Parent Loop BB7_7 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	kmovw	%r11d, %k1
	vmovups	-8(%r10,%r12,8), %zmm2 {%k1} {z}
	vfnmadd231ps	(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	vmovups	(%r10,%r12,8), %zmm2 {%k1} {z}
	vfnmadd231ps	4(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	4(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	addq	$2, %r12
	cmpq	%r12, %r9
	jne	LBB7_8
LBB7_9:                                 ##   in Loop: Header=BB7_7 Depth=1
	testb	$1, %cl
	je	LBB7_11
## %bb.10:                              ##   in Loop: Header=BB7_7 Depth=1
	kmovw	%r11d, %k1
	vmovups	(%rax,%r12,8), %zmm2 {%k1} {z}
	vfnmadd231ps	(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	jmp	LBB7_11
LBB7_1:
	xorl	%r8d, %r8d
LBB7_12:
	cmpq	%rdi, %r8
	jae	LBB7_22
LBB7_13:
	leaq	(%rsi,%r8,8), %rsi
	testq	%rcx, %rcx
	je	LBB7_14
## %bb.15:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB7_17
## %bb.16:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB7_19
LBB7_3:
	movl	$1, %r8d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$3, %r9w
	.p2align	4, 0x90
LBB7_4:                                 ## =>This Inner Loop Header: Depth=1
	kmovw	%r9d, %k1
	vmovups	%zmm0, -8(%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%r8,8) {%k1}
	addq	$2, %r8
	cmpq	%rdi, %r8
	jb	LBB7_4
## %bb.5:
	decq	%r8
	cmpq	%rdi, %r8
	jb	LBB7_13
	jmp	LBB7_22
LBB7_14:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB7_21
LBB7_17:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	8(%rax), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	movw	$3, %r10w
	.p2align	4, 0x90
LBB7_18:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r10d, %k1
	vmovups	-8(%r9,%rdi,8), %zmm1 {%k1} {z}
	vfnmadd132ps	(%rdx,%rdi,4){1to16}, %zmm0, %zmm1 ## zmm1 = -(zmm1 * mem) + zmm0
	vmovups	(%r9,%rdi,8), %zmm0 {%k1} {z}
	vfnmadd132ps	4(%rdx,%rdi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm0 * mem) + zmm1
	addq	$2, %rdi
	cmpq	%rdi, %r8
	jne	LBB7_18
LBB7_19:
	testb	$1, %cl
	je	LBB7_21
## %bb.20:
	movw	$3, %cx
	kmovw	%ecx, %k1
	vmovups	(%rax,%rdi,8), %zmm1 {%k1} {z}
	vfnmadd231ps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm1 * mem) + zmm0
LBB7_21:
	movw	$3, %ax
	kmovw	%eax, %k1
	vmovups	%zmm0, (%rsi) {%k1}
LBB7_22:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB16_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB16_3
## %bb.5:
	movq	%rcx, %r9
	andq	$-2, %r9
	leaq	16(%rsi), %r10
	movl	$1, %ebx
	xorl	%r8d, %r8d
	movw	$15, %r11w
	jmp	LBB16_6
	.p2align	4, 0x90
LBB16_12:                               ##   in Loop: Header=BB16_6 Depth=1
	movq	%r8, %r14
	shlq	$4, %r14
	shlq	$4, %rbx
	kmovw	%r11d, %k1
	vmovups	%zmm1, (%rax,%r14) {%k1}
	vmovups	%zmm0, (%rax,%rbx) {%k1}
	addq	$2, %r8
	movq	%r8, %rbx
	orq	$1, %rbx
	cmpq	%rdi, %rbx
	jae	LBB16_13
LBB16_6:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB16_9 Depth 2
	movq	(%rdx,%r8,8), %r15
	movq	(%rdx,%rbx,8), %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	$1, %rcx
	jne	LBB16_8
## %bb.7:                               ##   in Loop: Header=BB16_6 Depth=1
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB16_10
	.p2align	4, 0x90
LBB16_8:                                ##   in Loop: Header=BB16_6 Depth=1
	movq	%r10, %r13
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB16_9:                                ##   Parent Loop BB16_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	kmovw	%r11d, %k1
	vmovups	-16(%r13), %zmm2 {%k1} {z}
	vfnmadd231ps	(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	vmovups	(%r13), %zmm2 {%k1} {z}
	vfnmadd231ps	4(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	4(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	addq	$2, %r12
	addq	$32, %r13
	cmpq	%r12, %r9
	jne	LBB16_9
LBB16_10:                               ##   in Loop: Header=BB16_6 Depth=1
	testb	$1, %cl
	je	LBB16_12
## %bb.11:                              ##   in Loop: Header=BB16_6 Depth=1
	movq	%r12, %r13
	shlq	$4, %r13
	kmovw	%r11d, %k1
	vmovups	(%rsi,%r13), %zmm2 {%k1} {z}
	vfnmadd231ps	(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	jmp	LBB16_12
LBB16_1:
	xorl	%r8d, %r8d
	jmp	LBB16_13
LBB16_3:
	leaq	16(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$15, %r11w
	.p2align	4, 0x90
LBB16_4:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -16(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$32, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB16_4
LBB16_13:
	cmpq	%rdi, %r8
	jae	LBB16_23
## %bb.14:
	movq	%r8, %rdi
	shlq	$4, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB16_15
## %bb.16:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB16_18
## %bb.17:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB16_20
LBB16_15:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB16_22
LBB16_18:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	16(%rsi), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	movw	$15, %r10w
	.p2align	4, 0x90
LBB16_19:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r10d, %k1
	vmovups	-16(%r9), %zmm1 {%k1} {z}
	vfnmadd132ps	(%rdx,%rdi,4){1to16}, %zmm0, %zmm1 ## zmm1 = -(zmm1 * mem) + zmm0
	vmovups	(%r9), %zmm0 {%k1} {z}
	vfnmadd132ps	4(%rdx,%rdi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm0 * mem) + zmm1
	addq	$2, %rdi
	addq	$32, %r9
	cmpq	%rdi, %r8
	jne	LBB16_19
LBB16_20:
	testb	$1, %cl
	je	LBB16_22
## %bb.21:
	movq	%rdi, %rcx
	shlq	$4, %rcx
	movw	$15, %r8w
	kmovw	%r8d, %k1
	vmovups	(%rsi,%rcx), %zmm1 {%k1} {z}
	vfnmadd231ps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm1 * mem) + zmm0
LBB16_22:
	movw	$15, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB16_23:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB25_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB25_3
## %bb.5:
	movq	%rcx, %r9
	andq	$-2, %r9
	leaq	32(%rsi), %r10
	movl	$1, %ebx
	xorl	%r8d, %r8d
	movw	$255, %r11w
	jmp	LBB25_6
	.p2align	4, 0x90
LBB25_12:                               ##   in Loop: Header=BB25_6 Depth=1
	movq	%r8, %r14
	shlq	$5, %r14
	shlq	$5, %rbx
	kmovw	%r11d, %k1
	vmovups	%zmm1, (%rax,%r14) {%k1}
	vmovups	%zmm0, (%rax,%rbx) {%k1}
	addq	$2, %r8
	movq	%r8, %rbx
	orq	$1, %rbx
	cmpq	%rdi, %rbx
	jae	LBB25_13
LBB25_6:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB25_9 Depth 2
	movq	(%rdx,%r8,8), %r15
	movq	(%rdx,%rbx,8), %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	$1, %rcx
	jne	LBB25_8
## %bb.7:                               ##   in Loop: Header=BB25_6 Depth=1
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB25_10
	.p2align	4, 0x90
LBB25_8:                                ##   in Loop: Header=BB25_6 Depth=1
	movq	%r10, %r13
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB25_9:                                ##   Parent Loop BB25_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	kmovw	%r11d, %k1
	vmovups	-32(%r13), %zmm2 {%k1} {z}
	vfnmadd231ps	(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	vmovups	(%r13), %zmm2 {%k1} {z}
	vfnmadd231ps	4(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	4(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	addq	$2, %r12
	addq	$64, %r13
	cmpq	%r12, %r9
	jne	LBB25_9
LBB25_10:                               ##   in Loop: Header=BB25_6 Depth=1
	testb	$1, %cl
	je	LBB25_12
## %bb.11:                              ##   in Loop: Header=BB25_6 Depth=1
	movq	%r12, %r13
	shlq	$5, %r13
	kmovw	%r11d, %k1
	vmovups	(%rsi,%r13), %zmm2 {%k1} {z}
	vfnmadd231ps	(%r15,%r12,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r14,%r12,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	jmp	LBB25_12
LBB25_1:
	xorl	%r8d, %r8d
	jmp	LBB25_13
LBB25_3:
	leaq	32(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$255, %r11w
	.p2align	4, 0x90
LBB25_4:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -32(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$64, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB25_4
LBB25_13:
	cmpq	%rdi, %r8
	jae	LBB25_23
## %bb.14:
	movq	%r8, %rdi
	shlq	$5, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB25_15
## %bb.16:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB25_18
## %bb.17:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB25_20
LBB25_15:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB25_22
LBB25_18:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	32(%rsi), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	movw	$255, %r10w
	.p2align	4, 0x90
LBB25_19:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r10d, %k1
	vmovups	-32(%r9), %zmm1 {%k1} {z}
	vfnmadd132ps	(%rdx,%rdi,4){1to16}, %zmm0, %zmm1 ## zmm1 = -(zmm1 * mem) + zmm0
	vmovups	(%r9), %zmm0 {%k1} {z}
	vfnmadd132ps	4(%rdx,%rdi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm0 * mem) + zmm1
	addq	$2, %rdi
	addq	$64, %r9
	cmpq	%rdi, %r8
	jne	LBB25_19
LBB25_20:
	testb	$1, %cl
	je	LBB25_22
## %bb.21:
	movq	%rdi, %rcx
	shlq	$5, %rcx
	movw	$255, %r8w
	kmovw	%r8d, %k1
	vmovups	(%rsi,%rcx), %zmm1 {%k1} {z}
	vfnmadd231ps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm1 * mem) + zmm0
LBB25_22:
	movw	$255, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB25_23:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB34_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB34_22
## %bb.3:
	movq	%rcx, %rsi
	andq	$-2, %rsi
	leaq	64(%rax), %rdi
	movl	$1, %r8d
	xorl	%r14d, %r14d
	jmp	LBB34_4
	.p2align	4, 0x90
LBB34_10:                               ##   in Loop: Header=BB34_4 Depth=1
	movq	%r14, %r9
	shlq	$6, %r9
	shlq	$6, %r8
	vmovups	%zmm1, (%rbx,%r9)
	vmovups	%zmm0, (%rbx,%r8)
	addq	$2, %r14
	movq	%r14, %r8
	orq	$1, %r8
	cmpq	%r15, %r8
	jae	LBB34_11
LBB34_4:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB34_7 Depth 2
	movq	(%rdx,%r14,8), %r10
	movq	(%rdx,%r8,8), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	$1, %rcx
	jne	LBB34_6
## %bb.5:                               ##   in Loop: Header=BB34_4 Depth=1
	xorl	%r11d, %r11d
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB34_8
	.p2align	4, 0x90
LBB34_6:                                ##   in Loop: Header=BB34_4 Depth=1
	movq	%rdi, %r12
	xorl	%r11d, %r11d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB34_7:                                ##   Parent Loop BB34_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovups	-64(%r12), %zmm2
	vmovups	(%r12), %zmm3
	vfnmadd231ps	(%r10,%r11,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r9,%r11,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	vfnmadd231ps	4(%r10,%r11,4){1to16}, %zmm3, %zmm1 ## zmm1 = -(zmm3 * mem) + zmm1
	vfnmadd231ps	4(%r9,%r11,4){1to16}, %zmm3, %zmm0 ## zmm0 = -(zmm3 * mem) + zmm0
	addq	$2, %r11
	subq	$-128, %r12
	cmpq	%r11, %rsi
	jne	LBB34_7
LBB34_8:                                ##   in Loop: Header=BB34_4 Depth=1
	testb	$1, %cl
	je	LBB34_10
## %bb.9:                               ##   in Loop: Header=BB34_4 Depth=1
	movq	%r11, %r12
	shlq	$6, %r12
	vmovups	(%rax,%r12), %zmm2
	vfnmadd231ps	(%r10,%r11,4){1to16}, %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r9,%r11,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	jmp	LBB34_10
LBB34_1:
	xorl	%r14d, %r14d
LBB34_11:
	cmpq	%r15, %r14
	jae	LBB34_21
## %bb.12:
	testq	%rcx, %rcx
	je	LBB34_13
## %bb.14:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB34_16
## %bb.15:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	jmp	LBB34_18
LBB34_22:
	leaq	-2(%r15), %r14
	movq	%r14, %rsi
	shlq	$6, %rsi
	andq	$-128, %rsi
	subq	$-128, %rsi
	movq	%rbx, %rdi
	callq	___bzero
	andq	$-2, %r14
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	%r15, %r14
	jb	LBB34_20
	jmp	LBB34_21
LBB34_13:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB34_20
LBB34_16:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	64(%rax), %r8
	vxorps	%xmm1, %xmm1, %xmm1
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB34_17:                               ## =>This Inner Loop Header: Depth=1
	vmovups	-64(%r8), %zmm0
	vmovups	(%r8), %zmm2
	vfnmadd132ps	(%rdx,%rsi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm0 * mem) + zmm1
	vfnmadd231ps	4(%rdx,%rsi,4){1to16}, %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	addq	$2, %rsi
	subq	$-128, %r8
	vmovaps	%zmm0, %zmm1
	cmpq	%rsi, %rdi
	jne	LBB34_17
LBB34_18:
	testb	$1, %cl
	je	LBB34_20
## %bb.19:
	movq	%rsi, %rcx
	shlq	$6, %rcx
	vmovups	(%rax,%rcx), %zmm1
	vfnmadd231ps	(%rdx,%rsi,4){1to16}, %zmm1, %zmm0 ## zmm0 = -(zmm1 * mem) + zmm0
LBB34_20:
	shlq	$6, %r14
	vmovups	%zmm0, (%rbx,%r14)
LBB34_21:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB43_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB43_18
## %bb.3:
	leaq	64(%rax), %rsi
	movl	$1, %edi
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB43_4:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB43_5 Depth 2
	movq	(%rdx,%r14,8), %r8
	movq	(%rdx,%rdi,8), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r10
	vxorps	%xmm2, %xmm2, %xmm2
	vxorps	%xmm1, %xmm1, %xmm1
	vxorps	%xmm3, %xmm3, %xmm3
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB43_5:                                ##   Parent Loop BB43_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vbroadcastss	(%r8,%r11,4), %zmm4
	vbroadcastss	(%r9,%r11,4), %zmm5
	vmovups	-64(%r10), %zmm6
	vmovups	(%r10), %zmm7
	vfnmadd231ps	%zmm4, %zmm6, %zmm2     ## zmm2 = -(zmm6 * zmm4) + zmm2
	vfnmadd231ps	%zmm6, %zmm5, %zmm3     ## zmm3 = -(zmm5 * zmm6) + zmm3
	vfnmadd231ps	%zmm4, %zmm7, %zmm0     ## zmm0 = -(zmm7 * zmm4) + zmm0
	vfnmadd231ps	%zmm5, %zmm7, %zmm1     ## zmm1 = -(zmm7 * zmm5) + zmm1
	incq	%r11
	subq	$-128, %r10
	cmpq	%r11, %rcx
	jne	LBB43_5
## %bb.6:                               ##   in Loop: Header=BB43_4 Depth=1
	movq	%r14, %r8
	shlq	$7, %r8
	shlq	$7, %rdi
	vmovups	%zmm2, (%rbx,%r8)
	vmovups	%zmm3, (%rbx,%rdi)
	vmovups	%zmm0, 64(%rbx,%r8)
	vmovups	%zmm1, 64(%rbx,%rdi)
	addq	$2, %r14
	movq	%r14, %rdi
	orq	$1, %rdi
	cmpq	%r15, %rdi
	jb	LBB43_4
## %bb.7:
	cmpq	%r15, %r14
	jb	LBB43_8
	jmp	LBB43_17
LBB43_1:
	xorl	%r14d, %r14d
	cmpq	%r15, %r14
	jae	LBB43_17
LBB43_8:
	testq	%rcx, %rcx
	je	LBB43_9
## %bb.10:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB43_12
## %bb.11:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB43_14
LBB43_18:
	leaq	-2(%r15), %r14
	andq	$-2, %r14
	movq	%r14, %rsi
	shlq	$7, %rsi
	addq	$256, %rsi                      ## imm = 0x100
	movq	%rbx, %rdi
	callq	___bzero
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	cmpq	%r15, %r14
	jb	LBB43_16
	jmp	LBB43_17
LBB43_9:
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB43_16
LBB43_12:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	192(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB43_13:                               ## =>This Inner Loop Header: Depth=1
	vbroadcastss	(%rdx,%rsi,4), %zmm2
	vfnmadd231ps	-192(%r8), %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	-128(%r8), %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
	vbroadcastss	4(%rdx,%rsi,4), %zmm2
	vfnmadd231ps	-64(%r8), %zmm2, %zmm1  ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	(%r8), %zmm2, %zmm0     ## zmm0 = -(zmm2 * mem) + zmm0
	addq	$2, %rsi
	addq	$256, %r8                       ## imm = 0x100
	cmpq	%rsi, %rdi
	jne	LBB43_13
LBB43_14:
	testb	$1, %cl
	je	LBB43_16
## %bb.15:
	vbroadcastss	(%rdx,%rsi,4), %zmm2
	shlq	$7, %rsi
	vfnmadd231ps	(%rax,%rsi), %zmm2, %zmm1 ## zmm1 = -(zmm2 * mem) + zmm1
	vfnmadd231ps	64(%rax,%rsi), %zmm2, %zmm0 ## zmm0 = -(zmm2 * mem) + zmm0
LBB43_16:
	shlq	$7, %r14
	vmovups	%zmm1, (%rbx,%r14)
	vmovups	%zmm0, 64(%rbx,%r14)
LBB43_17:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rsi
	cmpq	$2, %rdi
	jb	LBB52_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB52_3
## %bb.6:
	movq	%rcx, %r9
	andq	$-2, %r9
	leaq	8(%rax), %r10
	movl	$1, %ebx
	xorl	%r8d, %r8d
	movw	$3, %r11w
	jmp	LBB52_7
	.p2align	4, 0x90
LBB52_11:                               ##   in Loop: Header=BB52_7 Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm1, (%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%rbx,8) {%k1}
	addq	$2, %r8
	movq	%r8, %rbx
	orq	$1, %rbx
	cmpq	%rdi, %rbx
	jae	LBB52_12
LBB52_7:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB52_8 Depth 2
	movq	(%rdx,%r8,8), %r15
	movq	(%rdx,%rbx,8), %r14
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	cmpq	$1, %rcx
	je	LBB52_9
	.p2align	4, 0x90
LBB52_8:                                ##   Parent Loop BB52_7 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	kmovw	%r11d, %k1
	vmovups	-8(%r10,%r12,8), %zmm2 {%k1} {z}
	vsubps	(%r15,%r12,4){1to16}, %zmm2, %zmm3
	vfmadd213ps	%zmm1, %zmm3, %zmm3     ## zmm3 = (zmm3 * zmm3) + zmm1
	vsubps	(%r14,%r12,4){1to16}, %zmm2, %zmm2
	vfmadd213ps	%zmm0, %zmm2, %zmm2     ## zmm2 = (zmm2 * zmm2) + zmm0
	vmovups	(%r10,%r12,8), %zmm0 {%k1} {z}
	vsubps	4(%r15,%r12,4){1to16}, %zmm0, %zmm1
	vsubps	4(%r14,%r12,4){1to16}, %zmm0, %zmm0
	vfmadd213ps	%zmm3, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm3
	vfmadd213ps	%zmm2, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm2
	addq	$2, %r12
	cmpq	%r12, %r9
	jne	LBB52_8
LBB52_9:                                ##   in Loop: Header=BB52_7 Depth=1
	testb	$1, %cl
	je	LBB52_11
## %bb.10:                              ##   in Loop: Header=BB52_7 Depth=1
	kmovw	%r11d, %k1
	vmovups	(%rax,%r12,8), %zmm2 {%k1} {z}
	vsubps	(%r15,%r12,4){1to16}, %zmm2, %zmm3
	vfmadd231ps	%zmm3, %zmm3, %zmm1     ## zmm1 = (zmm3 * zmm3) + zmm1
	vsubps	(%r14,%r12,4){1to16}, %zmm2, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	jmp	LBB52_11
LBB52_1:
	xorl	%r8d, %r8d
LBB52_12:
	cmpq	%rdi, %r8
	jae	LBB52_22
LBB52_13:
	leaq	(%rsi,%r8,8), %rsi
	testq	%rcx, %rcx
	je	LBB52_14
## %bb.15:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB52_17
## %bb.16:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB52_19
LBB52_3:
	movl	$1, %r8d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$3, %r9w
	.p2align	4, 0x90
LBB52_4:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r9d, %k1
	vmovups	%zmm0, -8(%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%r8,8) {%k1}
	addq	$2, %r8
	cmpq	%rdi, %r8
	jb	LBB52_4
## %bb.5:
	decq	%r8
	cmpq	%rdi, %r8
	jb	LBB52_13
	jmp	LBB52_22
LBB52_14:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB52_21
LBB52_17:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	8(%rax), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	movw	$3, %r10w
	.p2align	4, 0x90
LBB52_18:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r10d, %k1
	vmovups	-8(%r9,%rdi,8), %zmm1 {%k1} {z}
	vsubps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	vmovups	(%r9,%rdi,8), %zmm0 {%k1} {z}
	vsubps	4(%rdx,%rdi,4){1to16}, %zmm0, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rdi
	cmpq	%rdi, %r8
	jne	LBB52_18
LBB52_19:
	testb	$1, %cl
	je	LBB52_21
## %bb.20:
	movw	$3, %cx
	kmovw	%ecx, %k1
	vmovups	(%rax,%rdi,8), %zmm1 {%k1} {z}
	vsubps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB52_21:
	movw	$3, %ax
	kmovw	%eax, %k1
	vmovups	%zmm0, (%rsi) {%k1}
LBB52_22:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB61_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB61_3
## %bb.5:
	movq	%rcx, %r9
	andq	$-2, %r9
	leaq	16(%rsi), %r10
	movl	$1, %ebx
	xorl	%r8d, %r8d
	movw	$15, %r11w
	jmp	LBB61_6
	.p2align	4, 0x90
LBB61_12:                               ##   in Loop: Header=BB61_6 Depth=1
	movq	%r8, %r14
	shlq	$4, %r14
	shlq	$4, %rbx
	kmovw	%r11d, %k1
	vmovups	%zmm1, (%rax,%r14) {%k1}
	vmovups	%zmm0, (%rax,%rbx) {%k1}
	addq	$2, %r8
	movq	%r8, %rbx
	orq	$1, %rbx
	cmpq	%rdi, %rbx
	jae	LBB61_13
LBB61_6:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB61_9 Depth 2
	movq	(%rdx,%r8,8), %r15
	movq	(%rdx,%rbx,8), %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	$1, %rcx
	jne	LBB61_8
## %bb.7:                               ##   in Loop: Header=BB61_6 Depth=1
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB61_10
	.p2align	4, 0x90
LBB61_8:                                ##   in Loop: Header=BB61_6 Depth=1
	movq	%r10, %r13
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB61_9:                                ##   Parent Loop BB61_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	kmovw	%r11d, %k1
	vmovups	-16(%r13), %zmm2 {%k1} {z}
	vsubps	(%r15,%r12,4){1to16}, %zmm2, %zmm3
	vsubps	(%r14,%r12,4){1to16}, %zmm2, %zmm2
	vfmadd213ps	%zmm1, %zmm3, %zmm3     ## zmm3 = (zmm3 * zmm3) + zmm1
	vmovups	(%r13), %zmm4 {%k1} {z}
	vsubps	4(%r15,%r12,4){1to16}, %zmm4, %zmm1
	vfmadd213ps	%zmm0, %zmm2, %zmm2     ## zmm2 = (zmm2 * zmm2) + zmm0
	vfmadd213ps	%zmm3, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm3
	vsubps	4(%r14,%r12,4){1to16}, %zmm4, %zmm0
	vfmadd213ps	%zmm2, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm2
	addq	$2, %r12
	addq	$32, %r13
	cmpq	%r12, %r9
	jne	LBB61_9
LBB61_10:                               ##   in Loop: Header=BB61_6 Depth=1
	testb	$1, %cl
	je	LBB61_12
## %bb.11:                              ##   in Loop: Header=BB61_6 Depth=1
	movq	%r12, %r13
	shlq	$4, %r13
	kmovw	%r11d, %k1
	vmovups	(%rsi,%r13), %zmm2 {%k1} {z}
	vsubps	(%r15,%r12,4){1to16}, %zmm2, %zmm3
	vfmadd231ps	%zmm3, %zmm3, %zmm1     ## zmm1 = (zmm3 * zmm3) + zmm1
	vsubps	(%r14,%r12,4){1to16}, %zmm2, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	jmp	LBB61_12
LBB61_1:
	xorl	%r8d, %r8d
	jmp	LBB61_13
LBB61_3:
	leaq	16(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$15, %r11w
	.p2align	4, 0x90
LBB61_4:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -16(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$32, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB61_4
LBB61_13:
	cmpq	%rdi, %r8
	jae	LBB61_23
## %bb.14:
	movq	%r8, %rdi
	shlq	$4, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB61_15
## %bb.16:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB61_18
## %bb.17:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB61_20
LBB61_15:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB61_22
LBB61_18:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	16(%rsi), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	movw	$15, %r10w
	.p2align	4, 0x90
LBB61_19:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r10d, %k1
	vmovups	-16(%r9), %zmm1 {%k1} {z}
	vsubps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	vmovups	(%r9), %zmm0 {%k1} {z}
	vsubps	4(%rdx,%rdi,4){1to16}, %zmm0, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rdi
	addq	$32, %r9
	cmpq	%rdi, %r8
	jne	LBB61_19
LBB61_20:
	testb	$1, %cl
	je	LBB61_22
## %bb.21:
	movq	%rdi, %rcx
	shlq	$4, %rcx
	movw	$15, %r8w
	kmovw	%r8d, %k1
	vmovups	(%rsi,%rcx), %zmm1 {%k1} {z}
	vsubps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB61_22:
	movw	$15, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB61_23:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB70_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB70_3
## %bb.5:
	movq	%rcx, %r9
	andq	$-2, %r9
	leaq	32(%rsi), %r10
	movl	$1, %ebx
	xorl	%r8d, %r8d
	movw	$255, %r11w
	jmp	LBB70_6
	.p2align	4, 0x90
LBB70_12:                               ##   in Loop: Header=BB70_6 Depth=1
	movq	%r8, %r14
	shlq	$5, %r14
	shlq	$5, %rbx
	kmovw	%r11d, %k1
	vmovups	%zmm1, (%rax,%r14) {%k1}
	vmovups	%zmm0, (%rax,%rbx) {%k1}
	addq	$2, %r8
	movq	%r8, %rbx
	orq	$1, %rbx
	cmpq	%rdi, %rbx
	jae	LBB70_13
LBB70_6:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB70_9 Depth 2
	movq	(%rdx,%r8,8), %r15
	movq	(%rdx,%rbx,8), %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	$1, %rcx
	jne	LBB70_8
## %bb.7:                               ##   in Loop: Header=BB70_6 Depth=1
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB70_10
	.p2align	4, 0x90
LBB70_8:                                ##   in Loop: Header=BB70_6 Depth=1
	movq	%r10, %r13
	xorl	%r12d, %r12d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB70_9:                                ##   Parent Loop BB70_6 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	kmovw	%r11d, %k1
	vmovups	-32(%r13), %zmm2 {%k1} {z}
	vsubps	(%r15,%r12,4){1to16}, %zmm2, %zmm3
	vsubps	(%r14,%r12,4){1to16}, %zmm2, %zmm2
	vfmadd213ps	%zmm1, %zmm3, %zmm3     ## zmm3 = (zmm3 * zmm3) + zmm1
	vmovups	(%r13), %zmm4 {%k1} {z}
	vsubps	4(%r15,%r12,4){1to16}, %zmm4, %zmm1
	vfmadd213ps	%zmm0, %zmm2, %zmm2     ## zmm2 = (zmm2 * zmm2) + zmm0
	vfmadd213ps	%zmm3, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm3
	vsubps	4(%r14,%r12,4){1to16}, %zmm4, %zmm0
	vfmadd213ps	%zmm2, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm2
	addq	$2, %r12
	addq	$64, %r13
	cmpq	%r12, %r9
	jne	LBB70_9
LBB70_10:                               ##   in Loop: Header=BB70_6 Depth=1
	testb	$1, %cl
	je	LBB70_12
## %bb.11:                              ##   in Loop: Header=BB70_6 Depth=1
	movq	%r12, %r13
	shlq	$5, %r13
	kmovw	%r11d, %k1
	vmovups	(%rsi,%r13), %zmm2 {%k1} {z}
	vsubps	(%r15,%r12,4){1to16}, %zmm2, %zmm3
	vfmadd231ps	%zmm3, %zmm3, %zmm1     ## zmm1 = (zmm3 * zmm3) + zmm1
	vsubps	(%r14,%r12,4){1to16}, %zmm2, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	jmp	LBB70_12
LBB70_1:
	xorl	%r8d, %r8d
	jmp	LBB70_13
LBB70_3:
	leaq	32(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$255, %r11w
	.p2align	4, 0x90
LBB70_4:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -32(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$64, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB70_4
LBB70_13:
	cmpq	%rdi, %r8
	jae	LBB70_23
## %bb.14:
	movq	%r8, %rdi
	shlq	$5, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB70_15
## %bb.16:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB70_18
## %bb.17:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB70_20
LBB70_15:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB70_22
LBB70_18:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	32(%rsi), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	movw	$255, %r10w
	.p2align	4, 0x90
LBB70_19:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r10d, %k1
	vmovups	-32(%r9), %zmm1 {%k1} {z}
	vsubps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	vmovups	(%r9), %zmm0 {%k1} {z}
	vsubps	4(%rdx,%rdi,4){1to16}, %zmm0, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rdi
	addq	$64, %r9
	cmpq	%rdi, %r8
	jne	LBB70_19
LBB70_20:
	testb	$1, %cl
	je	LBB70_22
## %bb.21:
	movq	%rdi, %rcx
	shlq	$5, %rcx
	movw	$255, %r8w
	kmovw	%r8d, %k1
	vmovups	(%rsi,%rcx), %zmm1 {%k1} {z}
	vsubps	(%rdx,%rdi,4){1to16}, %zmm1, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB70_22:
	movw	$255, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB70_23:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB79_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB79_22
## %bb.3:
	movq	%rcx, %rsi
	andq	$-2, %rsi
	leaq	64(%rax), %rdi
	movl	$1, %r8d
	xorl	%r14d, %r14d
	jmp	LBB79_4
	.p2align	4, 0x90
LBB79_10:                               ##   in Loop: Header=BB79_4 Depth=1
	movq	%r14, %r9
	shlq	$6, %r9
	shlq	$6, %r8
	vmovups	%zmm1, (%rbx,%r9)
	vmovups	%zmm0, (%rbx,%r8)
	addq	$2, %r14
	movq	%r14, %r8
	orq	$1, %r8
	cmpq	%r15, %r8
	jae	LBB79_11
LBB79_4:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB79_7 Depth 2
	movq	(%rdx,%r14,8), %r10
	movq	(%rdx,%r8,8), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	$1, %rcx
	jne	LBB79_6
## %bb.5:                               ##   in Loop: Header=BB79_4 Depth=1
	xorl	%r11d, %r11d
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB79_8
	.p2align	4, 0x90
LBB79_6:                                ##   in Loop: Header=BB79_4 Depth=1
	movq	%rdi, %r12
	xorl	%r11d, %r11d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB79_7:                                ##   Parent Loop BB79_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vmovups	-64(%r12), %zmm2
	vmovups	(%r12), %zmm3
	vsubps	(%r10,%r11,4){1to16}, %zmm2, %zmm4
	vfmadd213ps	%zmm1, %zmm4, %zmm4     ## zmm4 = (zmm4 * zmm4) + zmm1
	vsubps	(%r9,%r11,4){1to16}, %zmm2, %zmm2
	vsubps	4(%r10,%r11,4){1to16}, %zmm3, %zmm1
	vfmadd213ps	%zmm0, %zmm2, %zmm2     ## zmm2 = (zmm2 * zmm2) + zmm0
	vfmadd213ps	%zmm4, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm4
	vsubps	4(%r9,%r11,4){1to16}, %zmm3, %zmm0
	vfmadd213ps	%zmm2, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm2
	addq	$2, %r11
	subq	$-128, %r12
	cmpq	%r11, %rsi
	jne	LBB79_7
LBB79_8:                                ##   in Loop: Header=BB79_4 Depth=1
	testb	$1, %cl
	je	LBB79_10
## %bb.9:                               ##   in Loop: Header=BB79_4 Depth=1
	movq	%r11, %r12
	shlq	$6, %r12
	vmovups	(%rax,%r12), %zmm2
	vsubps	(%r10,%r11,4){1to16}, %zmm2, %zmm3
	vfmadd231ps	%zmm3, %zmm3, %zmm1     ## zmm1 = (zmm3 * zmm3) + zmm1
	vsubps	(%r9,%r11,4){1to16}, %zmm2, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	jmp	LBB79_10
LBB79_1:
	xorl	%r14d, %r14d
LBB79_11:
	cmpq	%r15, %r14
	jae	LBB79_21
## %bb.12:
	testq	%rcx, %rcx
	je	LBB79_13
## %bb.14:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB79_16
## %bb.15:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	jmp	LBB79_18
LBB79_22:
	leaq	-2(%r15), %r14
	movq	%r14, %rsi
	shlq	$6, %rsi
	andq	$-128, %rsi
	subq	$-128, %rsi
	movq	%rbx, %rdi
	callq	___bzero
	andq	$-2, %r14
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	%r15, %r14
	jb	LBB79_20
	jmp	LBB79_21
LBB79_13:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB79_20
LBB79_16:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	64(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB79_17:                               ## =>This Inner Loop Header: Depth=1
	vmovups	-64(%r8), %zmm1
	vsubps	(%rdx,%rsi,4){1to16}, %zmm1, %zmm1
	vmovups	(%r8), %zmm2
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	vsubps	4(%rdx,%rsi,4){1to16}, %zmm2, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rsi
	subq	$-128, %r8
	cmpq	%rsi, %rdi
	jne	LBB79_17
LBB79_18:
	testb	$1, %cl
	je	LBB79_20
## %bb.19:
	movq	%rsi, %rcx
	shlq	$6, %rcx
	vmovups	(%rax,%rcx), %zmm1
	vsubps	(%rdx,%rsi,4){1to16}, %zmm1, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB79_20:
	shlq	$6, %r14
	vmovups	%zmm0, (%rbx,%r14)
LBB79_21:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB88_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB88_18
## %bb.3:
	leaq	64(%rax), %rsi
	movl	$1, %edi
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB88_4:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB88_5 Depth 2
	movq	(%rdx,%r14,8), %r8
	movq	(%rdx,%rdi,8), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r10
	vxorps	%xmm2, %xmm2, %xmm2
	vxorps	%xmm1, %xmm1, %xmm1
	vxorps	%xmm3, %xmm3, %xmm3
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB88_5:                                ##   Parent Loop BB88_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	vbroadcastss	(%r8,%r11,4), %zmm4
	vbroadcastss	(%r9,%r11,4), %zmm5
	vmovups	-64(%r10), %zmm6
	vmovups	(%r10), %zmm7
	vsubps	%zmm4, %zmm6, %zmm8
	vfmadd231ps	%zmm8, %zmm8, %zmm2     ## zmm2 = (zmm8 * zmm8) + zmm2
	vsubps	%zmm5, %zmm6, %zmm6
	vfmadd231ps	%zmm6, %zmm6, %zmm3     ## zmm3 = (zmm6 * zmm6) + zmm3
	vsubps	%zmm4, %zmm7, %zmm4
	vfmadd231ps	%zmm4, %zmm4, %zmm0     ## zmm0 = (zmm4 * zmm4) + zmm0
	vsubps	%zmm5, %zmm7, %zmm4
	vfmadd231ps	%zmm4, %zmm4, %zmm1     ## zmm1 = (zmm4 * zmm4) + zmm1
	incq	%r11
	subq	$-128, %r10
	cmpq	%r11, %rcx
	jne	LBB88_5
## %bb.6:                               ##   in Loop: Header=BB88_4 Depth=1
	movq	%r14, %r8
	shlq	$7, %r8
	shlq	$7, %rdi
	vmovups	%zmm2, (%rbx,%r8)
	vmovups	%zmm3, (%rbx,%rdi)
	vmovups	%zmm0, 64(%rbx,%r8)
	vmovups	%zmm1, 64(%rbx,%rdi)
	addq	$2, %r14
	movq	%r14, %rdi
	orq	$1, %rdi
	cmpq	%r15, %rdi
	jb	LBB88_4
## %bb.7:
	cmpq	%r15, %r14
	jb	LBB88_8
	jmp	LBB88_17
LBB88_1:
	xorl	%r14d, %r14d
	cmpq	%r15, %r14
	jae	LBB88_17
LBB88_8:
	testq	%rcx, %rcx
	je	LBB88_9
## %bb.10:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB88_12
## %bb.11:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB88_14
LBB88_18:
	leaq	-2(%r15), %r14
	andq	$-2, %r14
	movq	%r14, %rsi
	shlq	$7, %rsi
	addq	$256, %rsi                      ## imm = 0x100
	movq	%rbx, %rdi
	callq	___bzero
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	cmpq	%r15, %r14
	jb	LBB88_16
	jmp	LBB88_17
LBB88_9:
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB88_16
LBB88_12:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	192(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB88_13:                               ## =>This Inner Loop Header: Depth=1
	vbroadcastss	(%rdx,%rsi,4), %zmm2
	vmovups	-192(%r8), %zmm3
	vmovups	-128(%r8), %zmm4
	vmovups	-64(%r8), %zmm5
	vmovups	(%r8), %zmm6
	vsubps	%zmm2, %zmm3, %zmm3
	vfmadd213ps	%zmm1, %zmm3, %zmm3     ## zmm3 = (zmm3 * zmm3) + zmm1
	vsubps	%zmm2, %zmm4, %zmm2
	vbroadcastss	4(%rdx,%rsi,4), %zmm4
	vfmadd213ps	%zmm0, %zmm2, %zmm2     ## zmm2 = (zmm2 * zmm2) + zmm0
	vsubps	%zmm4, %zmm5, %zmm1
	vfmadd213ps	%zmm3, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm3
	vsubps	%zmm4, %zmm6, %zmm0
	vfmadd213ps	%zmm2, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm2
	addq	$2, %rsi
	addq	$256, %r8                       ## imm = 0x100
	cmpq	%rsi, %rdi
	jne	LBB88_13
LBB88_14:
	testb	$1, %cl
	je	LBB88_16
## %bb.15:
	vbroadcastss	(%rdx,%rsi,4), %zmm2
	shlq	$7, %rsi
	vmovups	(%rax,%rsi), %zmm3
	vmovups	64(%rax,%rsi), %zmm4
	vsubps	%zmm2, %zmm3, %zmm3
	vfmadd231ps	%zmm3, %zmm3, %zmm1     ## zmm1 = (zmm3 * zmm3) + zmm1
	vsubps	%zmm2, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
LBB88_16:
	shlq	$7, %r14
	vmovups	%zmm1, (%rbx,%r14)
	vmovups	%zmm0, 64(%rbx,%r14)
LBB88_17:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rsi
	cmpq	$2, %rdi
	jb	LBB97_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB97_7
## %bb.3:
	movl	$1, %r10d
	xorl	%r8d, %r8d
	movw	$3, %r9w
	.p2align	4, 0x90
LBB97_4:                                ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB97_5 Depth 2
	movq	(%rdx,%r8,8), %r11
	movq	(%rdx,%r10,8), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%r14d, %r14d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB97_5:                                ##   Parent Loop BB97_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r11,%r14,2), %r15d
	vmovd	%r15d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%rbx,%r14,2), %r15d
	vmovd	%r15d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vmovss	(%rax,%r14,4), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm4, %zmm4
	vfnmadd231ps	%zmm2, %zmm4, %zmm1     ## zmm1 = -(zmm4 * zmm2) + zmm1
	vfnmadd231ps	%zmm3, %zmm4, %zmm0     ## zmm0 = -(zmm4 * zmm3) + zmm0
	incq	%r14
	cmpq	%r14, %rcx
	jne	LBB97_5
## %bb.6:                               ##   in Loop: Header=BB97_4 Depth=1
	kmovw	%r9d, %k1
	vmovups	%zmm1, (%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%r10,8) {%k1}
	addq	$2, %r8
	movq	%r8, %r10
	orq	$1, %r10
	cmpq	%rdi, %r10
	jb	LBB97_4
	jmp	LBB97_10
LBB97_1:
	xorl	%r8d, %r8d
LBB97_10:
	cmpq	%rdi, %r8
	jae	LBB97_20
LBB97_11:
	leaq	(%rsi,%r8,8), %rsi
	testq	%rcx, %rcx
	je	LBB97_12
## %bb.13:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB97_15
## %bb.14:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB97_17
LBB97_7:
	movl	$1, %r8d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$3, %r9w
	.p2align	4, 0x90
LBB97_8:                                ## =>This Inner Loop Header: Depth=1
	kmovw	%r9d, %k1
	vmovups	%zmm0, -8(%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%r8,8) {%k1}
	addq	$2, %r8
	cmpq	%rdi, %r8
	jb	LBB97_8
## %bb.9:
	decq	%r8
	cmpq	%rdi, %r8
	jb	LBB97_11
	jmp	LBB97_20
LBB97_12:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB97_19
LBB97_15:
	movq	%rcx, %r8
	andq	$-2, %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB97_16:                               ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovss	(%rax,%rdi,4), %xmm2            ## xmm2 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm2, %zmm2
	vfnmadd213ps	%zmm0, %zmm1, %zmm2     ## zmm2 = -(zmm1 * zmm2) + zmm0
	movzwl	2(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm1
	vmovss	4(%rax,%rdi,4), %xmm0           ## xmm0 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm0, %zmm0
	vfnmadd213ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm0) + zmm2
	addq	$2, %rdi
	cmpq	%rdi, %r8
	jne	LBB97_16
LBB97_17:
	testb	$1, %cl
	je	LBB97_19
## %bb.18:
	movzwl	(%rdx,%rdi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovss	(%rax,%rdi,4), %xmm2            ## xmm2 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm2, %zmm2
	vfnmadd231ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm2) + zmm0
LBB97_19:
	movw	$3, %ax
	kmovw	%eax, %k1
	vmovups	%zmm0, (%rsi) {%k1}
LBB97_20:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB106_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB106_7
## %bb.3:
	movl	$1, %r10d
	xorl	%r8d, %r8d
	movw	$15, %r9w
	.p2align	4, 0x90
LBB106_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB106_5 Depth 2
	movq	(%rdx,%r8,8), %r11
	movq	(%rdx,%r10,8), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%r14d, %r14d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB106_5:                               ##   Parent Loop BB106_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r11,%r14,2), %r15d
	vmovd	%r15d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%rbx,%r14,2), %r15d
	vmovd	%r15d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vmovsd	(%rsi,%r14,8), %xmm4            ## xmm4 = mem[0],zero
	vcvtph2ps	%ymm4, %zmm4
	vfnmadd231ps	%zmm2, %zmm4, %zmm1     ## zmm1 = -(zmm4 * zmm2) + zmm1
	vfnmadd231ps	%zmm3, %zmm4, %zmm0     ## zmm0 = -(zmm4 * zmm3) + zmm0
	incq	%r14
	cmpq	%r14, %rcx
	jne	LBB106_5
## %bb.6:                               ##   in Loop: Header=BB106_4 Depth=1
	movq	%r8, %r11
	shlq	$4, %r11
	shlq	$4, %r10
	kmovw	%r9d, %k1
	vmovups	%zmm1, (%rax,%r11) {%k1}
	vmovups	%zmm0, (%rax,%r10) {%k1}
	addq	$2, %r8
	movq	%r8, %r10
	orq	$1, %r10
	cmpq	%rdi, %r10
	jb	LBB106_4
	jmp	LBB106_9
LBB106_1:
	xorl	%r8d, %r8d
	jmp	LBB106_9
LBB106_7:
	leaq	16(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$15, %r11w
	.p2align	4, 0x90
LBB106_8:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -16(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$32, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB106_8
LBB106_9:
	cmpq	%rdi, %r8
	jae	LBB106_19
## %bb.10:
	movq	%r8, %rdi
	shlq	$4, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB106_11
## %bb.12:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB106_14
## %bb.13:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB106_16
LBB106_11:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB106_18
LBB106_14:
	movq	%rcx, %r8
	andq	$-2, %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB106_15:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovsd	(%rsi,%rdi,8), %xmm2            ## xmm2 = mem[0],zero
	vcvtph2ps	%ymm2, %zmm2
	vfnmadd213ps	%zmm0, %zmm1, %zmm2     ## zmm2 = -(zmm1 * zmm2) + zmm0
	movzwl	2(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm1
	vmovsd	8(%rsi,%rdi,8), %xmm0           ## xmm0 = mem[0],zero
	vcvtph2ps	%ymm0, %zmm0
	vfnmadd213ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm0) + zmm2
	addq	$2, %rdi
	cmpq	%rdi, %r8
	jne	LBB106_15
LBB106_16:
	testb	$1, %cl
	je	LBB106_18
## %bb.17:
	movzwl	(%rdx,%rdi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovsd	(%rsi,%rdi,8), %xmm2            ## xmm2 = mem[0],zero
	vcvtph2ps	%ymm2, %zmm2
	vfnmadd231ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm2) + zmm0
LBB106_18:
	movw	$15, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB106_19:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB115_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB115_7
## %bb.3:
	movl	$1, %r10d
	xorl	%r8d, %r8d
	movw	$255, %r9w
	.p2align	4, 0x90
LBB115_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB115_5 Depth 2
	movq	(%rdx,%r8,8), %r11
	movq	(%rdx,%r10,8), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r14
	xorl	%r15d, %r15d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB115_5:                               ##   Parent Loop BB115_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r11,%r15,2), %r12d
	vmovd	%r12d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%rbx,%r15,2), %r12d
	vmovd	%r12d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vmovups	(%r14), %xmm4
	vcvtph2ps	%ymm4, %zmm4
	vfnmadd231ps	%zmm2, %zmm4, %zmm1     ## zmm1 = -(zmm4 * zmm2) + zmm1
	vfnmadd231ps	%zmm3, %zmm4, %zmm0     ## zmm0 = -(zmm4 * zmm3) + zmm0
	incq	%r15
	addq	$16, %r14
	cmpq	%r15, %rcx
	jne	LBB115_5
## %bb.6:                               ##   in Loop: Header=BB115_4 Depth=1
	movq	%r8, %r11
	shlq	$5, %r11
	shlq	$5, %r10
	kmovw	%r9d, %k1
	vmovups	%zmm1, (%rax,%r11) {%k1}
	vmovups	%zmm0, (%rax,%r10) {%k1}
	addq	$2, %r8
	movq	%r8, %r10
	orq	$1, %r10
	cmpq	%rdi, %r10
	jb	LBB115_4
	jmp	LBB115_9
LBB115_1:
	xorl	%r8d, %r8d
	jmp	LBB115_9
LBB115_7:
	leaq	32(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$255, %r11w
	.p2align	4, 0x90
LBB115_8:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -32(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$64, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB115_8
LBB115_9:
	cmpq	%rdi, %r8
	jae	LBB115_19
## %bb.10:
	movq	%r8, %rdi
	shlq	$5, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB115_11
## %bb.12:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB115_14
## %bb.13:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB115_16
LBB115_11:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB115_18
LBB115_14:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	16(%rsi), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB115_15:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rdi,2), %r10d
	vmovd	%r10d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovups	-16(%r9), %xmm2
	vmovups	(%r9), %xmm3
	vcvtph2ps	%ymm2, %zmm2
	vfnmadd213ps	%zmm0, %zmm1, %zmm2     ## zmm2 = -(zmm1 * zmm2) + zmm0
	movzwl	2(%rdx,%rdi,2), %r10d
	vmovd	%r10d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm1
	vcvtph2ps	%ymm3, %zmm0
	vfnmadd213ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm0) + zmm2
	addq	$2, %rdi
	addq	$32, %r9
	cmpq	%rdi, %r8
	jne	LBB115_15
LBB115_16:
	testb	$1, %cl
	je	LBB115_18
## %bb.17:
	movzwl	(%rdx,%rdi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	shlq	$4, %rdi
	vmovups	(%rsi,%rdi), %xmm2
	vcvtph2ps	%ymm2, %zmm2
	vfnmadd231ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm2) + zmm0
LBB115_18:
	movw	$255, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB115_19:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB124_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB124_18
## %bb.3:
	movl	$1, %esi
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB124_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB124_5 Depth 2
	movq	(%rdx,%r14,8), %rdi
	movq	(%rdx,%rsi,8), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rax, %r9
	xorl	%r10d, %r10d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB124_5:                               ##   Parent Loop BB124_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%rdi,%r10,2), %r11d
	vmovd	%r11d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%r8,%r10,2), %r11d
	vmovd	%r11d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vcvtph2ps	(%r9), %zmm4
	vfnmadd231ps	%zmm2, %zmm4, %zmm1     ## zmm1 = -(zmm4 * zmm2) + zmm1
	vfnmadd231ps	%zmm3, %zmm4, %zmm0     ## zmm0 = -(zmm4 * zmm3) + zmm0
	incq	%r10
	addq	$32, %r9
	cmpq	%r10, %rcx
	jne	LBB124_5
## %bb.6:                               ##   in Loop: Header=BB124_4 Depth=1
	movq	%r14, %rdi
	shlq	$6, %rdi
	shlq	$6, %rsi
	vmovups	%zmm1, (%rbx,%rdi)
	vmovups	%zmm0, (%rbx,%rsi)
	addq	$2, %r14
	movq	%r14, %rsi
	orq	$1, %rsi
	cmpq	%r15, %rsi
	jb	LBB124_4
## %bb.7:
	cmpq	%r15, %r14
	jb	LBB124_8
	jmp	LBB124_17
LBB124_1:
	xorl	%r14d, %r14d
	cmpq	%r15, %r14
	jae	LBB124_17
LBB124_8:
	testq	%rcx, %rcx
	je	LBB124_9
## %bb.10:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB124_12
## %bb.11:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	jmp	LBB124_14
LBB124_18:
	leaq	-2(%r15), %r14
	movq	%r14, %rsi
	shlq	$6, %rsi
	andq	$-128, %rsi
	subq	$-128, %rsi
	movq	%rbx, %rdi
	callq	___bzero
	andq	$-2, %r14
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	%r15, %r14
	jb	LBB124_16
	jmp	LBB124_17
LBB124_9:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB124_16
LBB124_12:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	32(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB124_13:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vcvtph2ps	-32(%r8), %zmm2
	vbroadcastss	%xmm1, %zmm1
	vfnmadd213ps	%zmm0, %zmm1, %zmm2     ## zmm2 = -(zmm1 * zmm2) + zmm0
	movzwl	2(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm1
	vcvtph2ps	(%r8), %zmm0
	vfnmadd213ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm0) + zmm2
	addq	$2, %rsi
	addq	$64, %r8
	cmpq	%rsi, %rdi
	jne	LBB124_13
LBB124_14:
	testb	$1, %cl
	je	LBB124_16
## %bb.15:
	movzwl	(%rdx,%rsi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	shlq	$5, %rsi
	vcvtph2ps	(%rax,%rsi), %zmm2
	vfnmadd231ps	%zmm2, %zmm1, %zmm0     ## zmm0 = -(zmm1 * zmm2) + zmm0
LBB124_16:
	shlq	$6, %r14
	vmovups	%zmm0, (%rbx,%r14)
LBB124_17:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB133_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB133_18
## %bb.3:
	leaq	32(%rax), %rsi
	movl	$1, %edi
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB133_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB133_5 Depth 2
	movq	(%rdx,%r14,8), %r8
	movq	(%rdx,%rdi,8), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r10
	vxorps	%xmm2, %xmm2, %xmm2
	vxorps	%xmm1, %xmm1, %xmm1
	vxorps	%xmm3, %xmm3, %xmm3
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB133_5:                               ##   Parent Loop BB133_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r8,%r11,2), %r12d
	vmovd	%r12d, %xmm4
	vcvtph2ps	%xmm4, %xmm4
	vbroadcastss	%xmm4, %zmm4
	movzwl	(%r9,%r11,2), %r12d
	vmovd	%r12d, %xmm5
	vcvtph2ps	%xmm5, %xmm5
	vbroadcastss	%xmm5, %zmm5
	vcvtph2ps	-32(%r10), %zmm6
	vfnmadd231ps	%zmm4, %zmm6, %zmm2     ## zmm2 = -(zmm6 * zmm4) + zmm2
	vfnmadd231ps	%zmm6, %zmm5, %zmm3     ## zmm3 = -(zmm5 * zmm6) + zmm3
	vcvtph2ps	(%r10), %zmm6
	vfnmadd231ps	%zmm4, %zmm6, %zmm0     ## zmm0 = -(zmm6 * zmm4) + zmm0
	vfnmadd231ps	%zmm5, %zmm6, %zmm1     ## zmm1 = -(zmm6 * zmm5) + zmm1
	incq	%r11
	addq	$64, %r10
	cmpq	%r11, %rcx
	jne	LBB133_5
## %bb.6:                               ##   in Loop: Header=BB133_4 Depth=1
	movq	%r14, %r8
	shlq	$7, %r8
	shlq	$7, %rdi
	vmovups	%zmm2, (%rbx,%r8)
	vmovups	%zmm3, (%rbx,%rdi)
	vmovups	%zmm0, 64(%rbx,%r8)
	vmovups	%zmm1, 64(%rbx,%rdi)
	addq	$2, %r14
	movq	%r14, %rdi
	orq	$1, %rdi
	cmpq	%r15, %rdi
	jb	LBB133_4
## %bb.7:
	cmpq	%r15, %r14
	jb	LBB133_8
	jmp	LBB133_17
LBB133_1:
	xorl	%r14d, %r14d
	cmpq	%r15, %r14
	jae	LBB133_17
LBB133_8:
	testq	%rcx, %rcx
	je	LBB133_9
## %bb.10:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB133_12
## %bb.11:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB133_14
LBB133_18:
	leaq	-2(%r15), %r14
	andq	$-2, %r14
	movq	%r14, %rsi
	shlq	$7, %rsi
	addq	$256, %rsi                      ## imm = 0x100
	movq	%rbx, %rdi
	callq	___bzero
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	cmpq	%r15, %r14
	jb	LBB133_16
	jmp	LBB133_17
LBB133_9:
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB133_16
LBB133_12:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	96(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB133_13:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	vcvtph2ps	-96(%r8), %zmm3
	vfnmadd213ps	%zmm1, %zmm2, %zmm3     ## zmm3 = -(zmm2 * zmm3) + zmm1
	vcvtph2ps	-64(%r8), %zmm4
	vfnmadd213ps	%zmm0, %zmm2, %zmm4     ## zmm4 = -(zmm2 * zmm4) + zmm0
	movzwl	2(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vcvtph2ps	-32(%r8), %zmm1
	vbroadcastss	%xmm0, %zmm2
	vfnmadd213ps	%zmm3, %zmm2, %zmm1     ## zmm1 = -(zmm2 * zmm1) + zmm3
	vcvtph2ps	(%r8), %zmm0
	vfnmadd213ps	%zmm4, %zmm2, %zmm0     ## zmm0 = -(zmm2 * zmm0) + zmm4
	addq	$2, %rsi
	subq	$-128, %r8
	cmpq	%rsi, %rdi
	jne	LBB133_13
LBB133_14:
	testb	$1, %cl
	je	LBB133_16
## %bb.15:
	movzwl	(%rdx,%rsi,2), %ecx
	vmovd	%ecx, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	shlq	$6, %rsi
	vcvtph2ps	(%rax,%rsi), %zmm3
	vfnmadd231ps	%zmm3, %zmm2, %zmm1     ## zmm1 = -(zmm2 * zmm3) + zmm1
	vcvtph2ps	32(%rax,%rsi), %zmm3
	vfnmadd231ps	%zmm3, %zmm2, %zmm0     ## zmm0 = -(zmm2 * zmm3) + zmm0
LBB133_16:
	shlq	$7, %r14
	vmovups	%zmm1, (%rbx,%r14)
	vmovups	%zmm0, 64(%rbx,%r14)
LBB133_17:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rsi
	cmpq	$2, %rdi
	jb	LBB142_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB142_7
## %bb.3:
	movl	$1, %r10d
	xorl	%r8d, %r8d
	movw	$3, %r9w
	.p2align	4, 0x90
LBB142_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB142_5 Depth 2
	movq	(%rdx,%r8,8), %r11
	movq	(%rdx,%r10,8), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%r14d, %r14d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB142_5:                               ##   Parent Loop BB142_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r11,%r14,2), %r15d
	vmovd	%r15d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%rbx,%r14,2), %r15d
	vmovd	%r15d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vmovss	(%rax,%r14,4), %xmm4            ## xmm4 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm4, %zmm4
	vsubps	%zmm2, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm1     ## zmm1 = (zmm2 * zmm2) + zmm1
	vsubps	%zmm3, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	incq	%r14
	cmpq	%r14, %rcx
	jne	LBB142_5
## %bb.6:                               ##   in Loop: Header=BB142_4 Depth=1
	kmovw	%r9d, %k1
	vmovups	%zmm1, (%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%r10,8) {%k1}
	addq	$2, %r8
	movq	%r8, %r10
	orq	$1, %r10
	cmpq	%rdi, %r10
	jb	LBB142_4
	jmp	LBB142_10
LBB142_1:
	xorl	%r8d, %r8d
LBB142_10:
	cmpq	%rdi, %r8
	jae	LBB142_20
LBB142_11:
	leaq	(%rsi,%r8,8), %rsi
	testq	%rcx, %rcx
	je	LBB142_12
## %bb.13:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB142_15
## %bb.14:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB142_17
LBB142_7:
	movl	$1, %r8d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$3, %r9w
	.p2align	4, 0x90
LBB142_8:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r9d, %k1
	vmovups	%zmm0, -8(%rsi,%r8,8) {%k1}
	vmovups	%zmm0, (%rsi,%r8,8) {%k1}
	addq	$2, %r8
	cmpq	%rdi, %r8
	jb	LBB142_8
## %bb.9:
	decq	%r8
	cmpq	%rdi, %r8
	jb	LBB142_11
	jmp	LBB142_20
LBB142_12:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB142_19
LBB142_15:
	movq	%rcx, %r8
	andq	$-2, %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB142_16:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovss	(%rax,%rdi,4), %xmm2            ## xmm2 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	movzwl	2(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm0
	vmovss	4(%rax,%rdi,4), %xmm2           ## xmm2 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm0, %zmm2, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rdi
	cmpq	%rdi, %r8
	jne	LBB142_16
LBB142_17:
	testb	$1, %cl
	je	LBB142_19
## %bb.18:
	movzwl	(%rdx,%rdi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovss	(%rax,%rdi,4), %xmm2            ## xmm2 = mem[0],zero,zero,zero
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB142_19:
	movw	$3, %ax
	kmovw	%eax, %k1
	vmovups	%zmm0, (%rsi) {%k1}
LBB142_20:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB151_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB151_7
## %bb.3:
	movl	$1, %r10d
	xorl	%r8d, %r8d
	movw	$15, %r9w
	.p2align	4, 0x90
LBB151_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB151_5 Depth 2
	movq	(%rdx,%r8,8), %r11
	movq	(%rdx,%r10,8), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%r14d, %r14d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB151_5:                               ##   Parent Loop BB151_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r11,%r14,2), %r15d
	vmovd	%r15d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%rbx,%r14,2), %r15d
	vmovd	%r15d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vmovsd	(%rsi,%r14,8), %xmm4            ## xmm4 = mem[0],zero
	vcvtph2ps	%ymm4, %zmm4
	vsubps	%zmm2, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm1     ## zmm1 = (zmm2 * zmm2) + zmm1
	vsubps	%zmm3, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	incq	%r14
	cmpq	%r14, %rcx
	jne	LBB151_5
## %bb.6:                               ##   in Loop: Header=BB151_4 Depth=1
	movq	%r8, %r11
	shlq	$4, %r11
	shlq	$4, %r10
	kmovw	%r9d, %k1
	vmovups	%zmm1, (%rax,%r11) {%k1}
	vmovups	%zmm0, (%rax,%r10) {%k1}
	addq	$2, %r8
	movq	%r8, %r10
	orq	$1, %r10
	cmpq	%rdi, %r10
	jb	LBB151_4
	jmp	LBB151_9
LBB151_1:
	xorl	%r8d, %r8d
	jmp	LBB151_9
LBB151_7:
	leaq	16(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$15, %r11w
	.p2align	4, 0x90
LBB151_8:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -16(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$32, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB151_8
LBB151_9:
	cmpq	%rdi, %r8
	jae	LBB151_19
## %bb.10:
	movq	%r8, %rdi
	shlq	$4, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB151_11
## %bb.12:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB151_14
## %bb.13:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB151_16
LBB151_11:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB151_18
LBB151_14:
	movq	%rcx, %r8
	andq	$-2, %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB151_15:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovsd	(%rsi,%rdi,8), %xmm2            ## xmm2 = mem[0],zero
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	movzwl	2(%rdx,%rdi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm0
	vmovsd	8(%rsi,%rdi,8), %xmm2           ## xmm2 = mem[0],zero
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm0, %zmm2, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rdi
	cmpq	%rdi, %r8
	jne	LBB151_15
LBB151_16:
	testb	$1, %cl
	je	LBB151_18
## %bb.17:
	movzwl	(%rdx,%rdi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovsd	(%rsi,%rdi,8), %xmm2            ## xmm2 = mem[0],zero
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB151_18:
	movw	$15, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB151_19:
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rsi
	movq	(%rdx), %rdx
	movq	(%rcx), %rdi
	movq	(%r8), %rcx
	movq	(%r9), %rax
	cmpq	$2, %rdi
	jb	LBB160_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB160_7
## %bb.3:
	movl	$1, %r10d
	xorl	%r8d, %r8d
	movw	$255, %r9w
	.p2align	4, 0x90
LBB160_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB160_5 Depth 2
	movq	(%rdx,%r8,8), %r11
	movq	(%rdx,%r10,8), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r14
	xorl	%r15d, %r15d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB160_5:                               ##   Parent Loop BB160_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r11,%r15,2), %r12d
	vmovd	%r12d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%rbx,%r15,2), %r12d
	vmovd	%r12d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vbroadcastss	%xmm3, %zmm3
	vmovups	(%r14), %xmm4
	vcvtph2ps	%ymm4, %zmm4
	vsubps	%zmm2, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm1     ## zmm1 = (zmm2 * zmm2) + zmm1
	vsubps	%zmm3, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	incq	%r15
	addq	$16, %r14
	cmpq	%r15, %rcx
	jne	LBB160_5
## %bb.6:                               ##   in Loop: Header=BB160_4 Depth=1
	movq	%r8, %r11
	shlq	$5, %r11
	shlq	$5, %r10
	kmovw	%r9d, %k1
	vmovups	%zmm1, (%rax,%r11) {%k1}
	vmovups	%zmm0, (%rax,%r10) {%k1}
	addq	$2, %r8
	movq	%r8, %r10
	orq	$1, %r10
	cmpq	%rdi, %r10
	jb	LBB160_4
	jmp	LBB160_9
LBB160_1:
	xorl	%r8d, %r8d
	jmp	LBB160_9
LBB160_7:
	leaq	32(%rax), %r9
	xorl	%r10d, %r10d
	vxorps	%xmm0, %xmm0, %xmm0
	movw	$255, %r11w
	.p2align	4, 0x90
LBB160_8:                               ## =>This Inner Loop Header: Depth=1
	kmovw	%r11d, %k1
	vmovups	%zmm0, -32(%r9) {%k1}
	vmovups	%zmm0, (%r9) {%k1}
	leaq	2(%r10), %r8
	addq	$64, %r9
	addq	$3, %r10
	cmpq	%rdi, %r10
	movq	%r8, %r10
	jb	LBB160_8
LBB160_9:
	cmpq	%rdi, %r8
	jae	LBB160_19
## %bb.10:
	movq	%r8, %rdi
	shlq	$5, %rdi
	addq	%rdi, %rax
	testq	%rcx, %rcx
	je	LBB160_11
## %bb.12:
	movq	(%rdx,%r8,8), %rdx
	cmpq	$1, %rcx
	jne	LBB160_14
## %bb.13:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	jmp	LBB160_16
LBB160_11:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB160_18
LBB160_14:
	movq	%rcx, %r8
	andq	$-2, %r8
	leaq	16(%rsi), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%edi, %edi
	.p2align	4, 0x90
LBB160_15:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rdi,2), %r10d
	vmovd	%r10d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vmovups	-16(%r9), %xmm2
	vmovups	(%r9), %xmm3
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	movzwl	2(%rdx,%rdi,2), %r10d
	vmovd	%r10d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm0
	vcvtph2ps	%ymm3, %zmm2
	vsubps	%zmm0, %zmm2, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rdi
	addq	$32, %r9
	cmpq	%rdi, %r8
	jne	LBB160_15
LBB160_16:
	testb	$1, %cl
	je	LBB160_18
## %bb.17:
	movzwl	(%rdx,%rdi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	shlq	$4, %rdi
	vmovups	(%rsi,%rdi), %xmm2
	vcvtph2ps	%ymm2, %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB160_18:
	movw	$255, %cx
	kmovw	%ecx, %k1
	vmovups	%zmm0, (%rax) {%k1}
LBB160_19:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB169_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB169_18
## %bb.3:
	movl	$1, %esi
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB169_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB169_5 Depth 2
	movq	(%rdx,%r14,8), %rdi
	movq	(%rdx,%rsi,8), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rax, %r9
	xorl	%r10d, %r10d
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB169_5:                               ##   Parent Loop BB169_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%rdi,%r10,2), %r11d
	vmovd	%r11d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	movzwl	(%r8,%r10,2), %r11d
	vmovd	%r11d, %xmm3
	vcvtph2ps	%xmm3, %xmm3
	vcvtph2ps	(%r9), %zmm4
	vbroadcastss	%xmm3, %zmm3
	vsubps	%zmm2, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm1     ## zmm1 = (zmm2 * zmm2) + zmm1
	vsubps	%zmm3, %zmm4, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
	incq	%r10
	addq	$32, %r9
	cmpq	%r10, %rcx
	jne	LBB169_5
## %bb.6:                               ##   in Loop: Header=BB169_4 Depth=1
	movq	%r14, %rdi
	shlq	$6, %rdi
	shlq	$6, %rsi
	vmovups	%zmm1, (%rbx,%rdi)
	vmovups	%zmm0, (%rbx,%rsi)
	addq	$2, %r14
	movq	%r14, %rsi
	orq	$1, %rsi
	cmpq	%r15, %rsi
	jb	LBB169_4
## %bb.7:
	cmpq	%r15, %r14
	jb	LBB169_8
	jmp	LBB169_17
LBB169_1:
	xorl	%r14d, %r14d
	cmpq	%r15, %r14
	jae	LBB169_17
LBB169_8:
	testq	%rcx, %rcx
	je	LBB169_9
## %bb.10:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB169_12
## %bb.11:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	jmp	LBB169_14
LBB169_18:
	leaq	-2(%r15), %r14
	movq	%r14, %rsi
	shlq	$6, %rsi
	andq	$-128, %rsi
	subq	$-128, %rsi
	movq	%rbx, %rdi
	callq	___bzero
	andq	$-2, %r14
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	cmpq	%r15, %r14
	jb	LBB169_16
	jmp	LBB169_17
LBB169_9:
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	LBB169_16
LBB169_12:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	32(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	.p2align	4, 0x90
LBB169_13:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	vcvtph2ps	-32(%r8), %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd213ps	%zmm0, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm0
	movzwl	2(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm0
	vcvtph2ps	(%r8), %zmm2
	vsubps	%zmm0, %zmm2, %zmm0
	vfmadd213ps	%zmm1, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm1
	addq	$2, %rsi
	addq	$64, %r8
	cmpq	%rsi, %rdi
	jne	LBB169_13
LBB169_14:
	testb	$1, %cl
	je	LBB169_16
## %bb.15:
	movzwl	(%rdx,%rsi,2), %ecx
	vmovd	%ecx, %xmm1
	vcvtph2ps	%xmm1, %xmm1
	vbroadcastss	%xmm1, %zmm1
	shlq	$5, %rsi
	vcvtph2ps	(%rax,%rsi), %zmm2
	vsubps	%zmm1, %zmm2, %zmm1
	vfmadd231ps	%zmm1, %zmm1, %zmm0     ## zmm0 = (zmm1 * zmm1) + zmm0
LBB169_16:
	shlq	$6, %r14
	vmovups	%zmm0, (%rbx,%r14)
LBB169_17:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$16, %edi
	callq	__Znwm
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rcx
	movq	%rcx, (%rax)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE+16(%rip), %rax
	movq	%rax, (%rsi)
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	jmp	__ZdlPv                         ## TAILCALL
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_: ## @_ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	movq	(%rcx), %r15
	movq	(%r8), %rcx
	movq	(%r9), %rbx
	cmpq	$2, %r15
	jb	LBB178_1
## %bb.2:
	testq	%rcx, %rcx
	je	LBB178_18
## %bb.3:
	leaq	32(%rax), %rsi
	movl	$1, %edi
	xorl	%r14d, %r14d
	.p2align	4, 0x90
LBB178_4:                               ## =>This Loop Header: Depth=1
                                        ##     Child Loop BB178_5 Depth 2
	movq	(%rdx,%r14,8), %r8
	movq	(%rdx,%rdi,8), %r9
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rsi, %r10
	vxorps	%xmm2, %xmm2, %xmm2
	vxorps	%xmm1, %xmm1, %xmm1
	vxorps	%xmm3, %xmm3, %xmm3
	xorl	%r11d, %r11d
	.p2align	4, 0x90
LBB178_5:                               ##   Parent Loop BB178_4 Depth=1
                                        ## =>  This Inner Loop Header: Depth=2
	movzwl	(%r8,%r11,2), %r12d
	vmovd	%r12d, %xmm4
	vcvtph2ps	%xmm4, %xmm4
	vbroadcastss	%xmm4, %zmm4
	movzwl	(%r9,%r11,2), %r12d
	vmovd	%r12d, %xmm5
	vcvtph2ps	%xmm5, %xmm5
	vbroadcastss	%xmm5, %zmm5
	vcvtph2ps	-32(%r10), %zmm6
	vsubps	%zmm4, %zmm6, %zmm7
	vfmadd231ps	%zmm7, %zmm7, %zmm2     ## zmm2 = (zmm7 * zmm7) + zmm2
	vsubps	%zmm5, %zmm6, %zmm6
	vcvtph2ps	(%r10), %zmm7
	vfmadd231ps	%zmm6, %zmm6, %zmm3     ## zmm3 = (zmm6 * zmm6) + zmm3
	vsubps	%zmm4, %zmm7, %zmm4
	vfmadd231ps	%zmm4, %zmm4, %zmm0     ## zmm0 = (zmm4 * zmm4) + zmm0
	vsubps	%zmm5, %zmm7, %zmm4
	vfmadd231ps	%zmm4, %zmm4, %zmm1     ## zmm1 = (zmm4 * zmm4) + zmm1
	incq	%r11
	addq	$64, %r10
	cmpq	%r11, %rcx
	jne	LBB178_5
## %bb.6:                               ##   in Loop: Header=BB178_4 Depth=1
	movq	%r14, %r8
	shlq	$7, %r8
	shlq	$7, %rdi
	vmovups	%zmm2, (%rbx,%r8)
	vmovups	%zmm3, (%rbx,%rdi)
	vmovups	%zmm0, 64(%rbx,%r8)
	vmovups	%zmm1, 64(%rbx,%rdi)
	addq	$2, %r14
	movq	%r14, %rdi
	orq	$1, %rdi
	cmpq	%r15, %rdi
	jb	LBB178_4
## %bb.7:
	cmpq	%r15, %r14
	jb	LBB178_8
	jmp	LBB178_17
LBB178_1:
	xorl	%r14d, %r14d
	cmpq	%r15, %r14
	jae	LBB178_17
LBB178_8:
	testq	%rcx, %rcx
	je	LBB178_9
## %bb.10:
	movq	(%rdx,%r14,8), %rdx
	cmpq	$1, %rcx
	jne	LBB178_12
## %bb.11:
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB178_14
LBB178_18:
	leaq	-2(%r15), %r14
	andq	$-2, %r14
	movq	%r14, %rsi
	shlq	$7, %rsi
	addq	$256, %rsi                      ## imm = 0x100
	movq	%rbx, %rdi
	callq	___bzero
	addq	$2, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	cmpq	%r15, %r14
	jb	LBB178_16
	jmp	LBB178_17
LBB178_9:
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	jmp	LBB178_16
LBB178_12:
	movq	%rcx, %rdi
	andq	$-2, %rdi
	leaq	96(%rax), %r8
	vxorps	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vxorps	%xmm1, %xmm1, %xmm1
	.p2align	4, 0x90
LBB178_13:                              ## =>This Inner Loop Header: Depth=1
	movzwl	(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	vcvtph2ps	-96(%r8), %zmm3
	vsubps	%zmm2, %zmm3, %zmm3
	vfmadd213ps	%zmm1, %zmm3, %zmm3     ## zmm3 = (zmm3 * zmm3) + zmm1
	vcvtph2ps	-64(%r8), %zmm1
	vsubps	%zmm2, %zmm1, %zmm2
	vfmadd213ps	%zmm0, %zmm2, %zmm2     ## zmm2 = (zmm2 * zmm2) + zmm0
	movzwl	2(%rdx,%rsi,2), %r9d
	vmovd	%r9d, %xmm0
	vcvtph2ps	%xmm0, %xmm0
	vbroadcastss	%xmm0, %zmm0
	vcvtph2ps	-32(%r8), %zmm1
	vsubps	%zmm0, %zmm1, %zmm1
	vfmadd213ps	%zmm3, %zmm1, %zmm1     ## zmm1 = (zmm1 * zmm1) + zmm3
	vcvtph2ps	(%r8), %zmm3
	vsubps	%zmm0, %zmm3, %zmm0
	vfmadd213ps	%zmm2, %zmm0, %zmm0     ## zmm0 = (zmm0 * zmm0) + zmm2
	addq	$2, %rsi
	subq	$-128, %r8
	cmpq	%rsi, %rdi
	jne	LBB178_13
LBB178_14:
	testb	$1, %cl
	je	LBB178_16
## %bb.15:
	movzwl	(%rdx,%rsi,2), %ecx
	vmovd	%ecx, %xmm2
	vcvtph2ps	%xmm2, %xmm2
	vbroadcastss	%xmm2, %zmm2
	shlq	$6, %rsi
	vcvtph2ps	(%rax,%rsi), %zmm3
	vsubps	%zmm2, %zmm3, %zmm3
	vfmadd231ps	%zmm3, %zmm3, %zmm1     ## zmm1 = (zmm3 * zmm3) + zmm1
	vcvtph2ps	32(%rax,%rsi), %zmm3
	vsubps	%zmm2, %zmm3, %zmm2
	vfmadd231ps	%zmm2, %zmm2, %zmm0     ## zmm0 = (zmm2 * zmm2) + zmm0
LBB178_16:
	shlq	$7, %r14
	vmovups	%zmm1, (%rbx,%r14)
	vmovups	%zmm0, 64(%rbx,%r14)
LBB178_17:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 8(%rsi)
	leaq	8(%rdi), %rcx
	cmoveq	%rcx, %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.p2align	4, 0x90                         ## -- Begin function _ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv: ## @_ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_(%rip), %rax
	popq	%rbp
	retq
	.cfi_endproc
                                        ## -- End function
	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.globl	__ZTSNSt3__110__function6__baseIFvPKvPKS3_mmPfEEE ## @_ZTSNSt3__110__function6__baseIFvPKvPKS3_mmPfEEE
	.weak_definition	__ZTSNSt3__110__function6__baseIFvPKvPKS3_mmPfEEE
__ZTSNSt3__110__function6__baseIFvPKvPKS3_mmPfEEE:
	.asciz	"NSt3__110__function6__baseIFvPKvPKS3_mmPfEEE"

	.section	__DATA,__const
	.globl	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE ## @_ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE
	.weak_definition	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE
	.p2align	3, 0x0
__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7__cloneEPNS0_6__baseISE_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EclEOSA_OSC_OmSM_OSD_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_NS_9allocatorISG_EESE_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelIfLm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKS8_mmPfEEEvEUlS8_SA_mmSB_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE2EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE2EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm2ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm2ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm4ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm4ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm8ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm8ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm16ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm16ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

	.p2align	3, 0x0                          ## @_ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTVNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	0
	.quad	__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED1Ev
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_ED0Ev
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEv
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7__cloneEPNS0_6__baseISG_EE
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E7destroyEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E18destroy_deallocateEv
	.quad	__ZNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EclEOSC_OSE_OmSO_OSF_
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E6targetERKSt9type_info
	.quad	__ZNKSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_E11target_typeEv

	.section	__TEXT,__const
__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE: ## @_ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.asciz	"NSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
__ZTINSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTSNSt3__110__function6__funcIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS2_6ailego7Float16ELm32ELNS3_10MetricTypeE0EEENS_8functionIFvPKvPKSC_mmPfEEEvEUlSC_SE_mmSF_E_NS_9allocatorISI_EESG_EE
	.quad	__ZTINSt3__110__function6__baseIFvPKvPKS3_mmPfEEE

	.section	__TEXT,__const
__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_: ## @_ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
	.asciz	"ZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_"

	.section	__DATA,__const
	.p2align	3, 0x0                          ## @_ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_
__ZTIZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTSZN4zvec5turbo6avx51212_GLOBAL__N_16kernelINS_6ailego7Float16ELm32ELNS0_10MetricTypeE0EEENSt3__18functionIFvPKvPKSA_mmPfEEEvEUlSA_SC_mmSD_E_

.subsections_via_symbols
