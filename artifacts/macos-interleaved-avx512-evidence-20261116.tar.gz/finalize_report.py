from pathlib import Path
import json,math,collections,hashlib,shutil,platform,sys
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';p=r/'performance'
correct=json.loads((r/'correctness.json').read_text());compat=correct.pop('legacy_ivf_comparison');counts={k:sum(v[k] for v in correct.values()) for k in ['passed','skipped','disabled','failed']}
san=json.loads((r/'ubsan.json').read_text());diagnostics=[d for v in san.values() for d in v['diagnostics']]
perf=json.loads((p/'performance.json').read_text());result=json.loads((p/'SUMMARY.json').read_text())
groups={}
for rnd,rows in enumerate(perf['rounds'],1):
 d=collections.defaultdict(list)
 for row in rows:d[(row['type'],row['metric'])].append(row['speedup'])
 for key,values in d.items():groups.setdefault(key,[]).append(math.exp(sum(map(math.log,values))/len(values)))
status='MACOS_REGRESSION_PASS_EXISTING_UB_REMAINS' if not result['sustained_regressions'] and all(v['ok'] for v in correct.values()) and compat['ok'] and len(diagnostics)==1 and 'integer_quantizer.cc:352' in diagnostics[0] else 'REVIEW_REQUIRED'
summary=dict(status=status,baseline_commit='5f489fd4debbf4efc0b32d4e0e90d0741dc65a02',native_avx512_executed=False,normal=dict(programs=len(correct),**counts),compatibility=compat,ubsan=dict(programs=len(san),diagnostics=diagnostics),performance=result,query_correctness=perf['correctness'],performance_groups=[dict(type=k[0],metric=k[1],round1=v[0],round2=v[1]) for k,v in groups.items()])
(r/'SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
(r/'environment.json').write_text(json.dumps(dict(platform=platform.platform(),machine=platform.machine(),python=sys.version),indent=2)+'\n')
lines=['AVX512 交错布局联合内核 — macOS ARM64 回归','2026-11-16','',f'结论：{status}',
'生产改动仅四个文件：新增 AVX512 .cc/.h、Turbo 分派表、按 ISA 的 CMake 编译选项。',
'IVF 调用点不变；新增 FP32/FP16、IP/L2 联合计算；不转置、不分配；FP16 转 FP32 累加。',
'AUTO 在支持的 x86 上优先 AVX512，否则继续 AVX2/NEON。macOS ARM64 继续使用 NEON。','',
'正确性',f'- 53 个相关程序：{counts}。',f'- 旧索引兼容：{compat["passed"]} 通过 / {compat["skipped"]} 跳过 / {compat["disabled"]} 禁用 / {compat["failed"]} 失败。',
'- 强制 AVX512 专项在 ARM64 上按预期跳过，不计为 AVX512 正确性通过。',
'- 新测试覆盖行数/查询数/维度尾部、无分配、输入不变、输出哨兵、double 参考、',
'  AVX512 与 AVX2 完全相等、AUTO 优先级及 CPU 特性缺失时回退；x86 必须实际执行。',
'- 最终 matrix 测试重新构建/执行于 final-matrix-normal 和 final-matrix-ubsan；',
'  correctness.json/ubsan.json 已使用这两份最终结果。','',
'UBSan',
'- 5 个相关程序全插桩；没有新增报告、旧 record 对齐报告为 0。',
'- 仍有此前 entropy_integer_quantizer/integer_quantizer.cc:352 的 NaN 转 signed char 报告。',
'  因此不是 sanitizer 全绿；本轮未修改该文件。原始日志完整保留。',
'- 本轮 macOS 运行 UBSan，未运行 ASan；原生 x86 必须运行完整 ASan+UBSan。','',
'实际 IVF 查询性能',
'- 基线 5f489fd4 在任何生产修改前从本地源码构建并静态链接；候选单独静态链接。',
'- 基线/候选二进制 SHA256 见 performance/provenance.json；两边使用同一 bench.cc。',
'- 每轮 288 项，5 个 >=50ms 样本取中位数。首轮 before→after，次轮 after→before。',
f'- 任一轮 >5% 的 {result["retake_cases"]} 项逐项交替复测两轮；持续回退 {len(result["sustained_regressions"])} 项。',
'- 构建和 UBSan 均结束后开始计时；日常桌面后台服务仍在运行，未进行 CPU 绑核。',
'- 是构造的旧交错索引上真实 search_impl 查询，完整块为 32 行；不覆盖全部生产数据集，',
'  不代表 2/4/8/16 行内核的性能已测，也不代表 AVX512 在服务器上更快。',
'- 比值 = 基线耗时 / 候选耗时，表内为组内几何平均，>1 为更快。','',
'类型 | 度量 | 第一轮 | 第二轮','--- | --- | --- | ---']
for key,values in groups.items():lines.append(f'{key[0]} | {key[1]} | {values[0]:.3f}x | {values[1]:.3f}x')
lines+=['',f'Top-K：{perf["correctness"]}',f'持续回退：{result["sustained_regressions"]}','',
'x86 静态检查及交接',
'- 新内核以 Apple Clang x86_64、-march=x86-64 -mavx512f -mf16c 交叉编译通过。',
'- 优化汇编可见 ZMM FMA、FP16→FP32 转换；这不是原生 x86 执行证据。',
'- 新文件 clang-format 18、全部修改 C++ 文件格式检查及 git diff --check 通过。',
'- 交接包内完整 SHA256 和前后源码集合/文件 hash 自检通过；同一测试补丁用于双方。',
'- 入口 scripts/ivf_interleaved_avx2_regression/AVX512_AGENT_zh.txt；',
'  独立包 artifacts/ivf-interleaved-avx512-handoff-20261116.tar.gz 及 .sha256。',
'- 要求原生 x86 强制 AVX512/AVX2、AUTO 分派、旧索引、ASan+UBSan、两轮长采样，',
'  以及实际 IVF 叶子扫描命中新 AVX512 联合内核的调用栈或 perf 证据。',
'- 本轮代码、说明和包尚未提交/推送。','']
(r/'REPORT_zh.txt').write_text('\n'.join(lines))
dest=repo/'scripts/ivf_interleaved_avx2_regression/reports/avx512_macos_20261116';dest.mkdir(parents=True,exist_ok=True)
for name in ['REPORT_zh.txt','SUMMARY.json']:shutil.copy2(r/name,dest/name)
for name in ['PERFORMANCE.csv','retake-PERFORMANCE.csv']:shutil.copy2(p/name,dest/name)
print((r/'REPORT_zh.txt').read_text())
