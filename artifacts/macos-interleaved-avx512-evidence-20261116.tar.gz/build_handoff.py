from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';out=r/'handoff';out.mkdir(exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='5f489fd4debbf4efc0b32d4e0e90d0741dc65a02'
subprocess.run(['git','archive','--format=tar.gz','--output='+str(out/'source-base.tar.gz'),head,'src','tests','cmake','.clang-format','CMakeLists.txt'],cwd=repo,check=True)
def new_patch(name):
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',name],cwd=repo,stdout=subprocess.PIPE)
 assert p.returncode==1;return p.stdout
name='tests/turbo/turbo_matrix_test.cc';(out/'baseline-vs-head.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',name],cwd=repo))
new_files=['src/turbo/distance/avx512/interleaved_many_to_many.'+ext for ext in ['cc','h']]
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)+b''.join(new_patch(name) for name in new_files)
(out/'candidate-vs-baseline.patch').write_bytes(patch)
with tarfile.open(out/'source-base.tar.gz') as t:base={x.name:digest(t.extractfile(x).read()) for x in t.getmembers() if x.isfile()}
base[name]=digest((repo/name).read_bytes());dump(out/'before-source-sha256.json',base)
after=dict(base)
changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=repo,text=True).splitlines()+new_files
for name in changed:after[name]=digest((repo/name).read_bytes())
dump(out/'after-source-sha256.json',after)
shutil.copytree(r.parent/'ivf_interleaved_avx2_20261113/handoff/old-index-fixtures',out/'old-index-fixtures',dirs_exist_ok=True)
tools=out/'tools';tools.mkdir(exist_ok=True)
for name in ['reverify.py','run.py','CMakeLists.txt','bench.cc','benchmark_clock.h','dispatch_probe.cc','legacy_compatibility.cc','validation-fixes.patch','validation-fixes.json','REVERIFY_zh.txt','avx512.py','AVX512_AGENT_zh.txt']:
 shutil.copy2(repo/'scripts/ivf_interleaved_avx2_regression'/name,tools/name)
shutil.copy2(tools/'AVX512_AGENT_zh.txt',out/'START_HERE_zh.txt')
dump(out/'avx512-manifest.json',dict(baseline_commit=head,candidate='baseline + candidate-vs-baseline.patch; frozen AVX512 joint kernel',test_patch_sha256=digest((out/'baseline-vs-head.patch').read_bytes()),production_patch_sha256=digest(patch),production_files=changed,performance_scope='actual search_impl on legacy interleaved IVF; 32-row blocks'))
(out/'SHA256SUMS').write_text(''.join(digest(p.read_bytes())+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
archive=repo/'artifacts/ivf-interleaved-avx512-handoff-20261116.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(out.iterdir()):t.add(p,arcname=p.name)
Path(str(archive)+'.sha256').write_text(digest(archive.read_bytes())+'  '+archive.name+'\n')
print(archive);print(Path(str(archive)+'.sha256').read_text())
