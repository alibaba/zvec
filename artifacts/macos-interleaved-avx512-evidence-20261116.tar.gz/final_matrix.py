from pathlib import Path
import sys,json
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'))
import run as k,reverify as v
for name,build,folder,san in [('normal','build','bin',False),('ubsan','build-ubsan','bin-ubsan',True)]:
 b=r.parent/'avx2_reverify_20261113'/build
 targets=['turbo_matrix_test']+([] if san else ['ivf_interleaved_bench','interleaved_dispatch_probe'])
 k.run(['cmake','--build',b,'--parallel','4','--target',*k.LIBS,*targets],r/'final-build.log')
 for t in targets:k.static_link(b,t,r/folder/t,r/'final-link.log')
 result=v.test(r/folder/'turbo_matrix_test',r/('final-matrix-'+name),san)
 file=r/('ubsan.json' if san else 'correctness.json');obj=json.loads(file.read_text());obj['turbo_matrix_test']=result;k.dump(file,obj)
 if not san:k.run([r/folder/'interleaved_dispatch_probe'],r/'final-dispatch.log')
print('DONE')
