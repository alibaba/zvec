from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';out=r/'handoff';out.mkdir(exist_ok=True)
base_commit='5f489fd4debbf4efc0b32d4e0e90d0741dc65a02';previous='54e990b774b91d1c8e71d0ef0e66161432ea73e9'
def digest(data):return hashlib.sha256(data).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==previous
subprocess.run(['git','archive','--format=tar.gz','--output='+str(out/'source-base.tar.gz'),base_commit,'src','tests','cmake','.clang-format','CMakeLists.txt'],cwd=repo,check=True)
test='tests/turbo/turbo_matrix_test.cc'
(out/'baseline-vs-head.patch').write_bytes(subprocess.check_output(['git','diff','--binary',base_commit,'--',test],cwd=repo))
patch=subprocess.check_output(['git','diff','--binary',base_commit,'--','src'],cwd=repo)
(out/'candidate-vs-baseline.patch').write_bytes(patch)
policy_patch=subprocess.check_output(['git','diff','--binary',previous,'--','src'],cwd=repo)
(out/'policy-fix-vs-54e990b7.patch').write_bytes(policy_patch)
with tarfile.open(out/'source-base.tar.gz') as t:base={x.name:digest(t.extractfile(x).read()) for x in t.getmembers() if x.isfile()}
base[test]=digest((repo/test).read_bytes());dump(out/'before-source-sha256.json',base)
after=dict(base);changed=subprocess.check_output(['git','diff','--name-only',base_commit,'--','src'],cwd=repo,text=True).splitlines()
for name in changed:after[name]=digest((repo/name).read_bytes())
dump(out/'after-source-sha256.json',after)
shutil.copytree(r.parent/'ivf_interleaved_avx2_20261113/handoff/old-index-fixtures',out/'old-index-fixtures',dirs_exist_ok=True)
tools=out/'tools';tools.mkdir(exist_ok=True)
for name in ['reverify.py','run.py','CMakeLists.txt','bench.cc','benchmark_clock.h','dispatch_probe.cc','legacy_compatibility.cc','validation-fixes.patch','validation-fixes.json','REVERIFY_zh.txt','avx512.py','focused_fp16_ip.py','AVX512_FP16_IP_REVERIFY_zh.txt']:
 shutil.copy2(repo/'scripts/ivf_interleaved_avx2_regression'/name,tools/name)
shutil.copy2(tools/'AVX512_FP16_IP_REVERIFY_zh.txt',out/'START_HERE_zh.txt')
dump(out/'avx512-manifest.json',dict(baseline_commit=base_commit,previous_candidate_commit=previous,dispatch_policy='fp16_ip_auto_avx2',candidate='frozen candidate-vs-baseline.patch',test_patch_sha256=digest((out/'baseline-vs-head.patch').read_bytes()),production_patch_sha256=digest(patch),policy_fix_sha256=digest(policy_patch),production_files=changed,performance_scope='actual legacy interleaved IVF search_impl; full 32-row blocks; focused five-case 6-block ABBA/BAAB+AA'))
(out/'SHA256SUMS').write_text(''.join(digest(p.read_bytes())+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
archive=repo/'artifacts/ivf-avx512-fp16-ip-auto-handoff-20261117.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(out.iterdir()):t.add(p,arcname=p.name)
Path(str(archive)+'.sha256').write_text(digest(archive.read_bytes())+'  '+archive.name+'\n')
print(archive);print(Path(str(archive)+'.sha256').read_text())
