from pathlib import Path
import sys,json
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'))
import run as k,reverify as v
out=r/'performance';out.mkdir()
k.dump(out/'provenance.json',dict(baseline_commit='54e990b774b91d1c8e71d0ef0e66161432ea73e9',baseline_sha256=v.digest(r/'bin-before/ivf_interleaved_bench'),candidate_sha256=v.digest(r/'bin/ivf_interleaved_bench'),sample_ms=50,baseline_build='Built and statically linked from clean tracked HEAD before production edits'))
result=v.benchmark(out,{'before':r/'bin-before','after':r/'bin'},None,50)
k.dump(out/'SUMMARY.json',result);print(result,flush=True)
