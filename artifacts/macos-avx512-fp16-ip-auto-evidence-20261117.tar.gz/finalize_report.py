from pathlib import Path
import json,math,collections,hashlib,shutil,platform
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';p=r/'performance'
correct=json.loads((r/'correctness.json').read_text());compat=correct.pop('legacy_ivf_comparison');counts={k:sum(v[k] for v in correct.values()) for k in ['passed','skipped','disabled','failed']}
san=json.loads((r/'ubsan.json').read_text());diagnostics=[d for v in san.values() for d in v['diagnostics']]
perf=json.loads((p/'performance.json').read_text());result=json.loads((p/'SUMMARY.json').read_text());groups={}
for rnd,rows in enumerate(perf['rounds'],1):
 d=collections.defaultdict(list)
 for row in rows:d[(row['type'],row['metric'])].append(row['speedup'])
 for key,values in d.items():groups.setdefault(key,[]).append(math.exp(sum(map(math.log,values))/len(values)))
status='MACOS_REGRESSION_PASS_EXISTING_UB_REMAINS' if not result['sustained_regressions'] and all(v['ok'] for v in correct.values()) and compat['ok'] and len(diagnostics)==1 and 'integer_quantizer.cc:352' in diagnostics[0] else 'REVIEW_REQUIRED'
summary=dict(status=status,baseline_commit='54e990b774b91d1c8e71d0ef0e66161432ea73e9',production_change='6 added lines in src/turbo/turbo.cc; AUTO skips AVX512 for FP16 IP only',native_x86_executed=False,normal=dict(programs=len(correct),**counts),compatibility=compat,ubsan=dict(programs=len(san),diagnostics=diagnostics),performance=result,query_correctness=perf['correctness'],performance_groups=[dict(type=k[0],metric=k[1],round1=v[0],round2=v[1]) for k,v in groups.items()])
(r/'SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
(r/'environment.json').write_text(json.dumps(dict(platform=platform.platform(),machine=platform.machine()),indent=2)+'\n')
lines=['FP16 IP AUTO 选择 AVX2 — macOS ARM64 回归','2026-11-17','',f'结论：{status}',
'生产代码仅 src/turbo/turbo.cc 增加6行：AUTO 的 FP16/IP 跳过 AVX512 项。',
'显式 AVX512 入口和四种 FP32/FP16 IP/L2 内核保留；FP32 IP/L2、FP16 L2 的 AUTO 仍优先 AVX512。',
'未改变距离算法、布局、转置、累加顺序、IVF调用点；macOS ARM64 仍使用 NEON。','',
'正确性',f'- {len(correct)} 个相关程序：{counts}。',f'- 旧索引兼容：{compat["passed"]}通过 /{compat["skipped"]}跳过 /{compat["disabled"]}禁用 /0失败。',
'- 新 Avx512Fp16IpAutoUsesAvx2 在 ARM64 上跳过，不能算 x86 数值/分派已验证。',
'- x86 新专项覆盖2/4/8/16/32行的AUTO=AVX2、显式AVX512保留，缺AVX2/FMA时不自动回到AVX512。',
'- 继续保留显式 AVX512/AVX2 数值对比、边界、无分配、FP32累加和旧索引测试。','',
'UBSan',
'- 5个程序全插桩，无新增报告；旧record对齐报告为0。',
'- 仍有既有 entropy_integer_quantizer/integer_quantizer.cc:352 NaN转signed char报告。',
'  不是 sanitizer 全绿；本轮不修改此文件，日志原样保留。',
'- 本轮macOS未运行ASan，服务器要求完整ASan+UBSan，不关闭alignment/vptr等检查。','',
'实际查询性能',
'- macOS基线为54e990b7；在修改前构建并静态链接，与候选使用同一bench.cc。',
'- 两轮各288项，5个>=50ms样本取中位数；before→after / after→before。',
f'- 任一轮>5%的{result["retake_cases"]}项逐项交替复测两轮，持续回退{len(result["sustained_regressions"])}项。',
'- 全部构建、正确性和UBSan测试结束后计时；无其他主动压测，桌面后台服务仍运行，未绑核。',
'- 测试为构造的旧交错索引上真实IVF search_impl查询，完整块32行，不能外推全部生产数据集。',
'- 加速比=基线耗时/候选耗时，组内几何平均，>1更快。','',
'类型 | 度量 | 第一轮 | 第二轮','--- | --- | --- | ---']
for key,values in groups.items():lines.append(f'{key[0]} | {key[1]} | {values[0]:.3f}x | {values[1]:.3f}x')
lines+=['',f'Top-K：{perf["correctness"]}',f'持续回退：{result["sustained_regressions"]}','',
'工具与交接',
'- clang-format 18、clang-tidy（turbo.cc/matrix测试）、git diff --check通过。',
'- 新长采样脚本的合成检查：正常数据PASS、性能回退REVIEW、分数不一致FAIL；',
'  这些只是工具检查，不是原生x86性能证据。',
'- x86主对照5f489fd4→冻结修复候选（与macOS本轮54e990b7基线不同，口径明确）。',
'- 两版相同测试补丁；包内完整文件集合/SHA256自检，显式分派探针校验新策略。',
'- 服务器强制五场景>=1000ms、6组ABBA/BAAB+AA，验证恢复到原AVX2基线，',
'  不能仅与已知较慢的54e990b7相比。还必须确认FP32的AVX512收益保留。',
'- 入口：scripts/ivf_interleaved_avx2_regression/AVX512_FP16_IP_REVERIFY_zh.txt。',
'- 包：artifacts/ivf-avx512-fp16-ip-auto-handoff-20261117.tar.gz及.sha256。',
'- 本轮代码、macOS报告/证据及x86交接包随本次提交归档；原生x86复验仍待执行。','']
(r/'REPORT_zh.txt').write_text('\n'.join(lines))
dest=repo/'scripts/ivf_interleaved_avx2_regression/reports/avx512_fp16_ip_auto_macos_20261117';dest.mkdir(parents=True,exist_ok=True)
for name in ['REPORT_zh.txt','SUMMARY.json']:shutil.copy2(r/name,dest/name)
for name in ['PERFORMANCE.csv','retake-PERFORMANCE.csv']:shutil.copy2(p/name,dest/name)
print((r/'REPORT_zh.txt').read_text())
