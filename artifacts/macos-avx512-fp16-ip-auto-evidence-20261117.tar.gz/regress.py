from pathlib import Path
import json,sys,os
r=Path(__file__).resolve().parent;repo=r.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'))
import run as kit
import reverify as verify
b=r.parent/'avx2_reverify_20261113/build';sb=r.parent/'avx2_reverify_20261113/build-ubsan'
paths=['tests/turbo','tests/core/metric','tests/core/algorithm/flat','tests/core/algorithm/ivf'];targets=sorted(p.stem for folder in paths for p in (repo/folder).glob('*_test.cc'))
kit.run(['cmake','--build',b,'--parallel','4','--target',*kit.LIBS,*targets,'legacy_ivf_comparison','ivf_interleaved_bench','interleaved_dispatch_probe'],r/'build.log')
bin=r/'bin';bin.mkdir(exist_ok=True);results={}
for target in targets+['legacy_ivf_comparison']:
 kit.static_link(b,target,bin/target,r/'link.log')
 if target=='legacy_ivf_comparison':os.environ['ZVEC_LEGACY_READ_FIXTURES']=str(r.parent/'ivf_interleaved_avx2_20261113/handoff/old-index-fixtures')
 results[target]=verify.test(bin/target,r/'correctness'/target)
 kit.dump(r/'correctness.json',results);print(target,{k:v for k,v in results[target].items() if k!='diagnostics'},flush=True)
os.environ.pop('ZVEC_LEGACY_READ_FIXTURES',None)
kit.static_link(b,'interleaved_dispatch_probe',bin/'interleaved_dispatch_probe',r/'link.log')
kit.run([bin/'interleaved_dispatch_probe'],r/'dispatch.log')
kit.static_link(b,'ivf_interleaved_bench',bin/'ivf_interleaved_bench',r/'link.log')
kit.run(['cmake','-S',repo/'scripts/ivf_interleaved_avx2_regression','-B',sb,'-DVALIDATION_SANITIZE=ON','-DVALIDATION_SANITIZERS=undefined'],r/'configure-ubsan.log')
sans=[*verify.SAN_TESTS,'turbo_record_alignment_test'];kit.run(['cmake','--build',sb,'--parallel','4','--target',*kit.LIBS,*sans],r/'build-ubsan.log')
commands=json.loads((sb/'compile_commands.json').read_text());missing=[x['file'] for x in commands if '-fsanitize=undefined' not in x['command'] or '-fno-sanitize=' in x['command']];assert not missing
kit.dump(r/'instrumentation.json',dict(translation_units=len(commands),missing=missing))
sbin=r/'bin-ubsan';sbin.mkdir(exist_ok=True);san={}
for target in sans:
 kit.static_link(sb,target,sbin/target,r/'link-ubsan.log')
 san[target]=verify.test(sbin/target,r/'ubsan'/target,True);kit.dump(r/'ubsan.json',san)
 print('UBSAN',target,{k:v for k,v in san[target].items() if k!='diagnostics'},'diagnostics',len(san[target]['diagnostics']),flush=True)
print('DONE',flush=True)
