from pathlib import Path
import sys,json,contextlib,io
from unittest.mock import patch
root=Path(__file__).resolve().parent;repo=root.parent.parent/'zvec';sys.path.insert(0,str(repo/'scripts/ivf_interleaved_avx2_regression'))
import focused_fp16_ip as f
results=root/'synthetic-tool-selftest/input'
for side in ['before','after']:
 p=results/('bin-'+side)/'ivf_interleaved_bench';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(side)
(results/'indexes').mkdir(exist_ok=True)
checks=[]
for name,ns,mismatch,expected in [('equal',100,False,'PASS_FOCUSED'),('regression',120,False,'PERFORMANCE_REVIEW_REQUIRED'),('score_mismatch',100,True,'FAIL')]:
 out=root/'synthetic-tool-selftest'/name
 def run(cmd,log,cwd,env,cpu):
  after='bin-after' in str(cmd[0]);value=ns if after else 100
  with (cwd/'timings.csv').open('a') as file:file.write(env['BENCH_CASE']+','+str(value)+',100\n')
  (cwd/'query_results.txt').write_text('case,0,42,'+('2' if after and mismatch else '1')+'\n');log.write_text('Synthetic test; no benchmark executed\n')
 with patch.object(f.sys,'argv',['focused','--results',str(results),'--out',str(out),'--cpu','9']),patch.object(f.sys,'platform','linux'),patch.object(f.platform,'machine',return_value='x86_64'),patch.object(f.os,'sched_getaffinity',return_value={9},create=True),patch.object(f.kit,'run',side_effect=run),contextlib.redirect_stdout(io.StringIO()):
  try:code=f.main()
  except RuntimeError as exc:
   if not mismatch:raise
   code='expected correctness exception'
 summary=json.loads((out/'SUMMARY.json').read_text());assert summary['status']==expected
 checks.append(dict(case=name,status=summary['status'],exit=code))
(root/'tool-selftest.json').write_text(json.dumps(dict(synthetic_only=True,checks=checks),indent=2)+'\n');print(checks)
